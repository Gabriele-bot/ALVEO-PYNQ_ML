# pyxbcmc

## Overview

Python module (pyxbcmc.py) to provide register read/write access to xbcmc cards over PCIe.

Primarily developed for interaction with the CMC register map, available methods include:
* get_bars()
* print_bars()
* cmc_gpio_read(bar)
* cmc_gpio_write(bar, value, mask=0xffffffff)
* cmc_reg_read(bar, regname)
* cmc_reg_read_dict(bar)
* cmc_reg_decode(bar, regname)
* cmc_reg_write(bar, regname, value, mask=0xffffffff)
* cmc_reg_write_with_mask(bar, regname, value, mask)
* cmc_reg_dump(bar, reg_offset, reg_len)
* cmc_coverage_capture(bar)
* cmc_stop(bar)
* cmc_load_firmware_image(bar, image):

Includes a number of utilities that can be used from the command line:

cmc_board_info.py: Request Board Info from SC
cmc_clear.py: Reset error flags in error reg
cmc_coverage.py: Reports message/sensor/error coverage counters
cmc_csdr.py: Requests CSDR stored data
cmc_debug_capture.py: Capture selected message & contents from SC
cmc_diagnose.py: To read diagnostic registers and split any with multiple fields into decoded key/value pairs
cmc_feature_enable.py: Enables/disables Mutex access
cmc_fsm_info.py: Prints info from the FSM's including Current/Previous states, Last event & Thread activity counters
cmc_hw_build_info.py: Prints the hw build info including tools, version & changelist no's
cmc_load.py: The CMC firmware load can be updated by downloading a new image file (.bin)
cmc_memdump.py: Dump contents of CMC memory
cmc_peek.py: To read register
cmc_poke.py: To write to register (with optional bitmask)
cmc_qsfp_control.py: Read/write to qsfp i2c registers
cmc_qsfp_low_speed.py: Single Byte read/write
cmc_regdump.py: Raw register dump, accepts "--offset" and "--bytes" arguments, byte order can be swapped via "--endian"
cmc_sensor_table.py: Sensors in tabular form
cmc_sensors.py: Prints sensor values (instantaneous, mean and max) from register map
cmc_snapshot.py: To get a full snapshot for debug (including diagnostics, coverage counters, sensor readings, message trace and register map dump)
cmc_thread_info.py: Prints the current & max times for threads to schedule in us
cmc_trace.py: Prints trace of last 32 transmit and receive messages in chronological order



Note:
Where ``-c 5e`` is the PCI bus of the target card. You can quickly check that by running ``$ xbmgmt flash --scan``.
The type of card will be confirmed by the output:
```console
pyxbcmc: U50 XDMA on PCI bus 0000:5e:00.0 found
```

```console
$ sudo ./cmc_peek.py -c 5e CMC_VERSION_REG
0x1ecf1d

$ sudo ./cmc_poke.py -c 5e CMC_VERSION_REG 0x0defaced 0xffffffff
0xdefaced

$ sudo ./cmc_regdump.py --offset=0x0 --bytes=128
xbcmc_BAR@0xF0000000
  0xF0120000: 74736574 001ecf1d 11000a00 00000000
  0xF0120010: 00000000 00000000 00000000 00000000
  0xF0120020: 00002fcb 00002f9a 00002f9c 00000d27
  0xF0120030: 00000d14 00000d10 00000ce9 00000cdd
  0xF0120040: 00000cde 00003061 0000302b 00003009
  0xF0120050: 000009c4 000009c0 000009c0 000015ca
  0xF0120060: 00001596 0000158d 000004bb 000004b0
  0xF0120070: 000004ae 00000736 00000727 00000725

$ sudo ./cmc_diagnose.py -c 5e --status --control
xbcmc_BAR@0xF0000000
  STATUS
    sc_mode: NORMAL
    sc_version: 1
    sc_status: SAT_SUCCESS
    cmc_proc_state: WAIT_EVENT
    cmc_proc_event: PROCESS_CAGE
    cmc_paused: False
    cmc_stopped: False
    cmc_init_done: False
  CONTROL
    reboot: False
    host_proc: False
    stop: False
    pause: False
    reset_error: False
    reset_sensor: False

$ sudo ./cmc_coverage.py -c 5e --satellite
xbcmc_BAR@0xF0000000
  SAT_MSG
    SAT_COMMS_ALERT_REQ: 0
    SAT_COMMS_ALERT_RESP: 0
    SAT_COMMS_BOARD_INFO_REQ: 2
    SAT_COMMS_BOARD_INFO_RESP: 2
    SAT_COMMS_BSL_BAUD: 0
    SAT_COMMS_BSL_CRC_CHECK_32: 398
    SAT_COMMS_BSL_LOAD_PC_32: 1
    SAT_COMMS_BSL_MASS_ERASE: 1
    SAT_COMMS_BSL_PW: 1
    SAT_COMMS_BSL_RESET: 0
    SAT_COMMS_BSL_RX_BLOCK_32: 398
    SAT_COMMS_BSL_SYNC: 3
    SAT_COMMS_BSL_TX_BLOCK_32: 0
    SAT_COMMS_BSL_VERS: 0
    SAT_COMMS_CAGE_IO_EVENT: 4
    SAT_COMMS_DEBUG_UART_EN: 0
    SAT_COMMS_DEBUG_UART_EN_RESP: 0
    SAT_COMMS_EN_BSL: 1
    SAT_COMMS_FPGA_I2C_BUS_ARB: 2
    SAT_COMMS_MSG_ERR: 0
    SAT_COMMS_MSG_GOOD: 7
    SAT_COMMS_NULL: 0
    SAT_COMMS_POWER_SNSR_REQ: 289417
    SAT_COMMS_POWER_SNSR_RESP: 289417
    SAT_COMMS_SET_VERS: 0
    SAT_COMMS_TEMP_SNSR_REQ: 289417
    SAT_COMMS_TEMP_SNSR_RESP: 289417
    SAT_COMMS_VERS_REQ: 2
    SAT_COMMS_VERS_RESP: 2
    SAT_COMMS_VOLT_SNSR_REQ: 289417
    SAT_COMMS_VOLT_SNSR_RESP: 289417
  SAT_ERR
    SAT_COMMS_BAD_CHAN_STATE: 0
    SAT_COMMS_BAD_MSG_ID: 0
    SAT_COMMS_BAD_VERSION: 0
    SAT_COMMS_CHKSUM_ERR: 0
    SAT_COMMS_EOP_ERR: 0
    SAT_COMMS_ESQ_SEQ_ERR: 0
    SAT_COMMS_SOP_ERR: 0
```

To get a full snapshot for debug (including diagnosis, coverage counters, sensor readings and register map dump):
```console
$ sudo ./cmc_snapshot.py -c 5e
Writing snapshot to /tmp/cmc_snapshot.20190201.1616.log
```

The CMC firmware load can be updated by downloading a new image file (.bin):
```console
$ sudo ./cmc_load.py ../CMC/release/cmc.bin -c 5e
Info: CMC stopped
Info: Enabling reset
Info: Loading firmware image
Info: Releasing reset
Info: Waiting for CMC to start
Info: CMC running
Info: SC comms established
Info: CMC firmware loaded successfully
```

## Copyright

� Copyright 2019 Xilinx, Inc. All rights reserved.

This file contains confidential and proprietary information of Xilinx, Inc.
and is protected under U.S. and international copyright and other intellectual
property laws.


DISCLAIMER

This disclaimer is not a license and does not grant any rights to the materials
distributed herewith. Except as otherwise provided in a valid license issued
to you by Xilinx, and to the maximum extent permitted by applicable law:

(1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND WITH ALL FAULTS,
AND XILINX HEREBY DISCLAIMS ALL WARRANTIES AND CONDITIONS, EXPRESS, IMPLIED,
OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
NON-INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and

(2) Xilinx shall not be liable (whether in contract or tort, including negligence,
or under any other theory of liability) for any loss or damage of any kind or
nature related to, arising under or in connection with these materials,
including for any direct, or any indirect, special, incidental, or consequential
loss or damage (including loss of data, profits, goodwill, or any type of loss or
damage suffered as a result of any action brought by a third party) even if such
damage or loss was reasonably foreseeable or Xilinx had been advised of the
possibility of the same.


CRITICAL APPLICATIONS

Xilinx products are not designed or intended to be fail-safe, or for use in
any application requiring fail-safe performance, such as life-support or safety
devices or systems, Class III medical devices, nuclear facilities, applications
related to the deployment of airbags, or any other applications that could lead
to death, personal injury, or severe property or environmental damage (individually
and collectively, "Critical Applications"). Customer assumes the sole risk and
liability of any use of Xilinx products in Critical Applications, subject
only to applicable laws and regulations governing limitations on product liability.


THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS PART OF THIS FILE AT ALL TIMES.
