#!/usr/bin/env python
# -*- coding: utf-8 -*-

################################################################################################
#                                                                                              #
# © Copyright 2019 Xilinx, Inc. All rights reserved.                                           #
#                                                                                              #
# This file contains confidential and proprietary information of Xilinx, Inc.                  #
# and is protected under U.S. and international copyright and other intellectual               #
# property laws.                                                                               #
#                                                                                              #
#                                                                                              #
# DISCLAIMER                                                                                   #
#                                                                                              #
# This disclaimer is not a license and does not grant any rights to the materials              #
# distributed herewith. Except as otherwise provided in a valid license issued                 #
# to you by Xilinx, and to the maximum extent permitted by applicable law:                     #
#                                                                                              #
# (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND WITH ALL FAULTS,                          #
# AND XILINX HEREBY DISCLAIMS ALL WARRANTIES AND CONDITIONS, EXPRESS, IMPLIED,                 #
# OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,                    #
# NON-INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and                                 #
#                                                                                              #
# (2) Xilinx shall not be liable (whether in contract or tort, including negligence,           #
# or under any other theory of liability) for any loss or damage of any kind or                #
# nature related to, arising under or in connection with these materials,                      #
# including for any direct, or any indirect, special, incidental, or consequential             #
# loss or damage (including loss of data, profits, goodwill, or any type of loss or            #
# damage suffered as a result of any action brought by a third party) even if such             #
# damage or loss was reasonably foreseeable or Xilinx had been advised of the                  #
# possibility of the same.                                                                     #
#                                                                                              #
#                                                                                              #
# CRITICAL APPLICATIONS                                                                        #
#                                                                                              #
# Xilinx products are not designed or intended to be fail-safe, or for use in                  #
# any application requiring fail-safe performance, such as life-support or safety              #
# devices or systems, Class III medical devices, nuclear facilities, applications              #
# related to the deployment of airbags, or any other applications that could lead              #
# to death, personal injury, or severe property or environmental damage (individually          #
# and collectively, "Critical Applications"). Customer assumes the sole risk and               #
# liability of any use of Xilinx products in Critical Applications, subject                    #
# only to applicable laws and regulations governing limitations on product liability.          #
#                                                                                              #
#                                                                                              #
# THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS PART OF THIS FILE AT ALL TIMES.     #
#                                                                                              #
################################################################################################

#
# RCS Keyword Metadata
# 
# $Change: 3034927 $
# $Date: 2020/10/14 $
# $Revision: #1 $
#

"""CMC Sensor Table"""

import argparse
import pyxbcmc
from prettytable import PrettyTable

def print_sensors(card_bus):
    """Read sensor registers and print fields"""
    sensors = [

        "CMC_12V_PEX_MAX_REG",                 # 000
        "CMC_12V_PEX_AVG_REG",                 # 001
        "CMC_12V_PEX_INS_REG",                 # 002
        
        "CMC_3V3_PEX_MAX_REG",                 # 003
        "CMC_3V3_PEX_AVG_REG",                 # 004
        "CMC_3V3_PEX_INS_REG",                 # 005
        
        "CMC_3V3_AUX_MAX_REG",                 # 006
        "CMC_3V3_AUX_AVG_REG",                 # 007
        "CMC_3V3_AUX_INS_REG",                 # 008
        
        "CMC_12V_AUX_MAX_REG",                 # 009
        "CMC_12V_AUX_AVG_REG",                 # 010
        "CMC_12V_AUX_INS_REG",                 # 011
        
        "CMC_DDR4_VPP_BTM_MAX_REG",            # 012
        "CMC_DDR4_VPP_BTM_AVG_REG",            # 013
        "CMC_DDR4_VPP_BTM_INS_REG",            # 014
        
        "CMC_SYS_5V5_MAX_REG",                 # 015
        "CMC_SYS_5V5_AVG_REG",                 # 016
        "CMC_SYS_5V5_INS_REG",                 # 017
        
        "CMC_VCC1V2_TOP_MAX_REG",              # 018
        "CMC_VCC1V2_TOP_AVG_REG",              # 019
        "CMC_VCC1V2_TOP_INS_REG",              # 020
        
        "CMC_VCC1V8_MAX_REG",                  # 021
        "CMC_VCC1V8_AVG_REG",                  # 022
        "CMC_VCC1V8_INS_REG",                  # 023
        
        "CMC_VCC0V85_MAX_REG",                 # 024
        "CMC_VCC0V85_AVG_REG",                 # 025
        "CMC_VCC0V85_INS_REG",                 # 026
        
        "CMC_DDR4_VPP_TOP_MAX_REG",            # 027
        "CMC_DDR4_VPP_TOP_AVG_REG",            # 028
        "CMC_DDR4_VPP_TOP_INS_REG",            # 029
        
        "CMC_MGT0V9AVCC_MAX_REG",              # 030
        "CMC_MGT0V9AVCC_AVG_REG",              # 031
        "CMC_MGT0V9AVCC_INS_REG",              # 032
        
        "CMC_12V_SW_MAX_REG",                  # 033
        "CMC_12V_SW_AVG_REG",                  # 034
        "CMC_12V_SW_INS_REG",                  # 035
        
        "CMC_MGTAVTT_MAX_REG",                 # 036
        "CMC_MGTAVTT_AVG_REG",                 # 037
        "CMC_MGTAVTT_INS_REG",                 # 038
        
        "CMC_VCC1V2_BTM_MAX_REG",              # 039
        "CMC_VCC1V2_BTM_AVG_REG",              # 040
        "CMC_VCC1V2_BTM_INS_REG",              # 041
        
        "CMC_12VPEX_I_IN_MAX_REG",             # 042
        "CMC_12VPEX_I_IN_AVG_REG",             # 043
        "CMC_12VPEX_I_IN_INS_REG",             # 044
        
        "CMC_12V_AUX_I_IN_MAX_REG",            # 045
        "CMC_12V_AUX_I_IN_AVG_REG",            # 046
        "CMC_12V_AUX_I_IN_INS_REG",            # 047
        
        "CMC_VCCINT_MAX_REG",                  # 048
        "CMC_VCCINT_AVG_REG",                  # 049
        "CMC_VCCINT_INS_REG",                  # 050
        
        "CMC_I_VCCINT_MAX_REG",                # 051
        "CMC_I_VCCINT_AVG_REG",                # 052
        "CMC_I_VCCINT_INS_REG",                # 053
        
        "CMC_FPGA_TEMP_MAX_REG",               # 054
        "CMC_FPGA_TEMP_AVG_REG",               # 055
        "CMC_FPGA_TEMP_INS_REG",               # 056
        
        "CMC_FAN_TEMP_MAX_REG",                # 057
        "CMC_FAN_TEMP_AVG_REG",                # 058
        "CMC_FAN_TEMP_INS_REG",                # 059
        
        "CMC_DIMM_TEMP0_MAX_REG",              # 060
        "CMC_DIMM_TEMP0_AVG_REG",              # 061
        "CMC_DIMM_TEMP0_INS_REG",              # 062
        
        "CMC_DIMM_TEMP1_MAX_REG",              # 063
        "CMC_DIMM_TEMP1_AVG_REG",              # 064
        "CMC_DIMM_TEMP1_INS_REG",              # 065
        
        "CMC_DIMM_TEMP2_MAX_REG",              # 066
        "CMC_DIMM_TEMP2_AVG_REG",              # 067
        "CMC_DIMM_TEMP2_INS_REG",              # 068
        
        "CMC_DIMM_TEMP3_MAX_REG",              # 069
        "CMC_DIMM_TEMP3_AVG_REG",              # 070
        "CMC_DIMM_TEMP3_INS_REG",              # 071
        
        "CMC_SE98_TEMP0_MAX_REG",              # 072
        "CMC_SE98_TEMP0_AVG_REG",              # 073
        "CMC_SE98_TEMP0_INS_REG",              # 074
        
        "CMC_SE98_TEMP1_MAX_REG",              # 075
        "CMC_SE98_TEMP1_AVG_REG",              # 076
        "CMC_SE98_TEMP1_INS_REG",              # 077
        
        "CMC_SE98_TEMP2_MAX_REG",              # 078
        "CMC_SE98_TEMP2_AVG_REG",              # 079
        "CMC_SE98_TEMP2_INS_REG",              # 080
        
        "CMC_FAN_SPEED_MAX_REG",               # 081
        "CMC_FAN_SPEED_AVG_REG",               # 082
        "CMC_FAN_SPEED_INS_REG",               # 083
        
        "CMC_CAGE_TEMP0_MAX_REG",              # 084
        "CMC_CAGE_TEMP0_AVG_REG",              # 085
        "CMC_CAGE_TEMP0_INS_REG",              # 086
        
        "CMC_CAGE_TEMP1_MAX_REG",              # 087
        "CMC_CAGE_TEMP1_AVG_REG",              # 088
        "CMC_CAGE_TEMP1_INS_REG",              # 089
        
        "CMC_CAGE_TEMP2_MAX_REG",              # 090
        "CMC_CAGE_TEMP2_AVG_REG",              # 091
        "CMC_CAGE_TEMP2_INS_REG",              # 092
        
        "CMC_CAGE_TEMP3_MAX_REG",              # 093
        "CMC_CAGE_TEMP3_AVG_REG",              # 094
        "CMC_CAGE_TEMP3_INS_REG",              # 095
             
        "CMC_HBM_TEMP_1_MAX_REG",              # 096
        "CMC_HBM_TEMP_1_AVG_REG",              # 097
        "CMC_HBM_TEMP_1_INS_REG",              # 098
        
        "CMC_VCC3V3_MAX_REG",                  # 099
        "CMC_VCC3V3_AVG_REG",                  # 100
        "CMC_VCC3V3_INS_REG",                  # 101
        
        "CMC_3V3PEX_I_IN_MAX_REG",             # 102
        "CMC_3V3PEX_I_IN_AVG_REG",             # 103
        "CMC_3V3PEX_I_IN_INS_REG",             # 104
        
        "CMC_I_VCC0V85_MAX_REG",               # 105
        "CMC_I_VCC0V85_AVG_REG",               # 106
        "CMC_I_VCC0V85_INS_REG",               # 107
        
        "CMC_HBM_1V2_MAX_REG",                 # 108
        "CMC_HBM_1V2_AVG_REG",                 # 109
        "CMC_HBM_1V2_INS_REG",                 # 110
        
        "CMC_VPP2V5_MAX_REG",                  # 111
        "CMC_VPP2V5_AVG_REG",                  # 112
        "CMC_VPP2V5_INS_REG",                  # 113
        
        "CMC_VCC_INT_BRAM_MAX_REG",            # 114
        "CMC_VCC_INT_BRAM_AVG_REG",            # 115
        "CMC_VCC_INT_BRAM_INS_REG",            # 116
        
        "CMC_HBM_TEMP_2_MAX_REG",              # 117
        "CMC_HBM_TEMP_2_AVG_REG",              # 118
        "CMC_HBM_TEMP_2_INS_REG",              # 119
        
        "CMC_12V_AUX1_MAX_REG",                # 120
        "CMC_12V_AUX1_AVG_REG",                # 121
        "CMC_12V_AUX1_INS_REG",                 # 122

        "CMC_VCCINT_TEMP_MAX_REG",             # 123
        "CMC_VCCINT_TEMP_AVG_REG",             # 124
        "CMC_VCCINT_TEMP_INS_REG",              # 125

        "CMC_PEX_12V_POWER_MAX_REG",           # 126
        "CMC_PEX_12V_POWER_AVG_REG",           # 127
        "CMC_PEX_12V_POWER_INS_REG",            # 128

        "CMC_PEX_3V3_POWER_MAX_REG",           # 129
        "CMC_PEX_3V3_POWER_AVG_REG",           # 130
        "CMC_PEX_3V3_POWER_INS_REG",           # 131

        "CMC_AUX_3V3_POWER_MAX_REG",           # 132
        "CMC_AUX_3V3_POWER_AVG_REG",           # 132
        "CMC_AUX_3V3_POWER_INS_REG",           # 134

        "CMC_VCC1V2_I_MAX_REG",           # 135
        "CMC_VCC1V2_I_AVG_REG",           # 136
        "CMC_VCC1V2_I_INS_REG",           # 137

        "CMC_V12_IN_I_MAX_REG",           # 138
        "CMC_V12_IN_I_AVG_REG",           # 139
        "CMC_V12_IN_I_INS_REG",           # 140

        "CMC_V12_IN_AUX0_I_MAX_REG",           # 141
        "CMC_V12_IN_AUX0_I_AVG_REG",           # 142
        "CMC_V12_IN_AUX0_I_INS_REG",           # 143

        "CMC_V12_IN_AUX1_I_MAX_REG",           # 144
        "CMC_V12_IN_AUX1_I_AVG_REG",           # 145
        "CMC_V12_IN_AUX1_I_INS_REG",           # 146

        "CMC_VCCAUX_MAX_REG",           # 147
        "CMC_VCCAUX_AVG_REG",           # 148
        "CMC_VCCAUX_INS_REG",           # 149

        "CMC_VCCAUX_PMC_MAX_REG",           # 150
        "CMC_VCCAUX_PMC_AVG_REG",           # 151
        "CMC_VCCAUX_PMC_INS_REG",           # 152

        "CMC_VCCRAM_MAX_REG",           # 153
        "CMC_VCCRAM_AVG_REG",           # 154
        "CMC_VCCRAM_INS_REG",           # 155

        "CMC_POWER_GOOD_MAX_REG",           # 156
        "CMC_POWER_GOOD_AVG_REG",           # 157
        "CMC_POWER_GOOD_INS_REG"
    ]

    resultsTable = []

    x = PrettyTable()

    x.field_names = ["Sensor", "Instantaneous", "Average", "Maximum"]

    x.align["Sensor"]="l"
    x.align["Instantaneous"]="r"
    x.align["Average"]="r"
    x.align["Maximum"]="r"

    for thread_register in sensors:
        thread_value=xbcmc_test.cmc_reg_read(card_bus, thread_register)
        resultsTable.append(thread_value)


    if((0!=resultsTable[2]) or (0!=resultsTable[1]) or (0!=resultsTable[0])):
        x.add_row(["12V_PEX",       resultsTable[2],    resultsTable[1],     resultsTable[0]])
    
    if((0!=resultsTable[5]) or (0!=resultsTable[4]) or (0!=resultsTable[3])):
        x.add_row(["3V3_PEX",       resultsTable[5],    resultsTable[4],     resultsTable[3]])
    
    if((0!=resultsTable[8]) or (0!=resultsTable[7]) or (0!=resultsTable[6])):
        x.add_row(["3V3_AUX",       resultsTable[8],    resultsTable[7],     resultsTable[6]])
        
    if((0!=resultsTable[11]) or (0!=resultsTable[10]) or (0!=resultsTable[9])):
        x.add_row(["12V_AUX0",      resultsTable[11],   resultsTable[10],    resultsTable[9]])  

    if((0!=resultsTable[14]) or (0!=resultsTable[12]) or (0!=resultsTable[12])):
        x.add_row(["DDR4_VPP_BTM",  resultsTable[14],   resultsTable[13],    resultsTable[12]]) 

    if((0!=resultsTable[17]) or (0!=resultsTable[16]) or (0!=resultsTable[15])):
        x.add_row(["SYS_5V5",       resultsTable[17],   resultsTable[16],    resultsTable[15]]) 

    if((0!=resultsTable[20]) or (0!=resultsTable[19]) or (0!=resultsTable[18])):
        x.add_row(["VCC1V2_TOP",    resultsTable[20],   resultsTable[19],    resultsTable[18]]) 

    if((0!=resultsTable[23]) or (0!=resultsTable[22]) or (0!=resultsTable[21])):
        x.add_row(["VCC1V8",        resultsTable[23],   resultsTable[22],    resultsTable[21]]) 

    if((0!=resultsTable[26]) or (0!=resultsTable[25]) or (0!=resultsTable[24])):
        x.add_row(["VCC0V85",       resultsTable[26],   resultsTable[25],    resultsTable[24]]) 

    if((0!=resultsTable[29]) or (0!=resultsTable[28]) or (0!=resultsTable[27])):
        x.add_row(["DDR4_VPP_TOP",  resultsTable[29],   resultsTable[28],    resultsTable[27]]) 

    if((0!=resultsTable[32]) or (0!=resultsTable[31]) or (0!=resultsTable[30])):
        x.add_row(["MGT0V9AVCC",    resultsTable[32],   resultsTable[31],    resultsTable[30]])

    if((0!=resultsTable[35]) or (0!=resultsTable[34]) or (0!=resultsTable[33])):
        x.add_row(["12V_SW",        resultsTable[35],   resultsTable[34],    resultsTable[33]]) 

    if((0!=resultsTable[38]) or (0!=resultsTable[37]) or (0!=resultsTable[36])):
        x.add_row(["MGTAVTT",       resultsTable[38],   resultsTable[37],    resultsTable[36]]) 

    if((0!=resultsTable[41]) or (0!=resultsTable[40]) or (0!=resultsTable[39])):
        x.add_row(["VCC1V2_BTM",    resultsTable[41],   resultsTable[40],    resultsTable[39]]) 

    if((0!=resultsTable[44]) or (0!=resultsTable[43]) or (0!=resultsTable[42])):
        x.add_row(["12VPEX_I_IN",   resultsTable[44],   resultsTable[43],    resultsTable[42]]) 

    if((0!=resultsTable[47]) or (0!=resultsTable[46]) or (0!=resultsTable[45])):
        x.add_row(["12V_AUX_I_IN",  resultsTable[47],   resultsTable[46],    resultsTable[45]]) 

    if((0!=resultsTable[50]) or (0!=resultsTable[49]) or (0!=resultsTable[48])):
        x.add_row(["VCCINT",        resultsTable[50],   resultsTable[49],    resultsTable[48]]) 

    if((0!=resultsTable[53]) or (0!=resultsTable[52]) or (0!=resultsTable[51])):
        x.add_row(["I_VCCINT",      resultsTable[53],   resultsTable[52],    resultsTable[51]]) 

    if((0!=resultsTable[56]) or (0!=resultsTable[55]) or (0!=resultsTable[54])):
        x.add_row(["FPGA_TEMP",     resultsTable[56],   resultsTable[55],    resultsTable[54]]) 

    if((0!=resultsTable[59]) or (0!=resultsTable[58]) or (0!=resultsTable[57])):
        x.add_row(["FAN_TEMP",      resultsTable[59],   resultsTable[58],    resultsTable[57]]) 

    if((0!=resultsTable[62]) or (0!=resultsTable[61]) or (0!=resultsTable[60])):
        x.add_row(["DIMM_TEMP0",    resultsTable[62],   resultsTable[61],    resultsTable[60]]) 

    if((0!=resultsTable[65]) or (0!=resultsTable[64]) or (0!=resultsTable[63])):
        x.add_row(["DIMM_TEMP1",    resultsTable[65],   resultsTable[64],    resultsTable[63]]) 

    if((0!=resultsTable[68]) or (0!=resultsTable[67]) or (0!=resultsTable[66])):
        x.add_row(["DIMM_TEMP2",    resultsTable[68],   resultsTable[67],    resultsTable[66]]) 

    if((0!=resultsTable[71]) or (0!=resultsTable[70]) or (0!=resultsTable[69])):
        x.add_row(["DIMM_TEMP3",    resultsTable[71],   resultsTable[70],    resultsTable[69]]) 

    if((0!=resultsTable[74]) or (0!=resultsTable[73]) or (0!=resultsTable[72])):
        x.add_row(["SE98_TEMP0",    resultsTable[74],   resultsTable[73],    resultsTable[72]]) 

    if((0!=resultsTable[77]) or (0!=resultsTable[76]) or (0!=resultsTable[75])):
        x.add_row(["SE98_TEMP1",    resultsTable[77],   resultsTable[76],    resultsTable[75]]) 

    if((0!=resultsTable[80]) or (0!=resultsTable[79]) or (0!=resultsTable[78])):
        x.add_row(["SE98_TEMP2",    resultsTable[80],   resultsTable[79],    resultsTable[78]]) 

    if((0!=resultsTable[83]) or (0!=resultsTable[82]) or (0!=resultsTable[81])):
        x.add_row(["FAN_SPEED",     resultsTable[83],   resultsTable[82],    resultsTable[81]]) 

    if((0!=resultsTable[86]) or (0!=resultsTable[85]) or (0!=resultsTable[84])):
        x.add_row(["CAGE_TEMP0",    resultsTable[86],   resultsTable[85],    resultsTable[84]]) 

    if((0!=resultsTable[89]) or (0!=resultsTable[88]) or (0!=resultsTable[87])):
        x.add_row(["CAGE_TEMP1",    resultsTable[89],   resultsTable[88],    resultsTable[87]]) 

    if((0!=resultsTable[92]) or (0!=resultsTable[91]) or (0!=resultsTable[90])):
        x.add_row(["CAGE_TEMP2",    resultsTable[92],   resultsTable[91],    resultsTable[90]]) 

    if((0!=resultsTable[95]) or (0!=resultsTable[94]) or (0!=resultsTable[93])):
        x.add_row(["CAGE_TEMP3",    resultsTable[95],   resultsTable[94],    resultsTable[93]]) 

    if((0!=resultsTable[98]) or (0!=resultsTable[97]) or (0!=resultsTable[96])):
        x.add_row(["HBM_TEMP_1",    resultsTable[98],   resultsTable[97],    resultsTable[96]]) 

    if((0!=resultsTable[101]) or (0!=resultsTable[100]) or (0!=resultsTable[99])):
        x.add_row(["VCC3V3",        resultsTable[101],  resultsTable[100],   resultsTable[99]]) 

    if((0!=resultsTable[104]) or (0!=resultsTable[103]) or (0!=resultsTable[102])):
        x.add_row(["3V3PEX_I_IN",   resultsTable[104],  resultsTable[103],   resultsTable[102]]) 

    if((0!=resultsTable[107]) or (0!=resultsTable[106]) or (0!=resultsTable[105])):
        x.add_row(["I_VCC0V85",     resultsTable[107],  resultsTable[106],   resultsTable[105]]) 

    if((0!=resultsTable[110]) or (0!=resultsTable[109]) or (0!=resultsTable[108])):
        x.add_row(["HBM_1V2",       resultsTable[110],  resultsTable[109],   resultsTable[108]]) 

    if((0!=resultsTable[113]) or (0!=resultsTable[112]) or (0!=resultsTable[111])):
        x.add_row(["VPP2V5",        resultsTable[113],  resultsTable[112],   resultsTable[111]]) 

    if((0!=resultsTable[116]) or (0!=resultsTable[115]) or (0!=resultsTable[114])):
        x.add_row(["VCC_INT_BRAM",  resultsTable[116],  resultsTable[115],   resultsTable[114]]) 

    if((0!=resultsTable[119]) or (0!=resultsTable[118]) or (0!=resultsTable[117])):
        x.add_row(["HBM_TEMP_2",    resultsTable[119],  resultsTable[118],   resultsTable[117]]) 

    if((0!=resultsTable[122]) or (0!=resultsTable[121]) or (0!=resultsTable[120])):
        x.add_row(["12V_AUX1",      resultsTable[122],  resultsTable[121],   resultsTable[120]]) 
        
    if((0!=resultsTable[125]) or (0!=resultsTable[124]) or (0!=resultsTable[123])):
        x.add_row(["VCCINT_TEMP",    resultsTable[125],  resultsTable[124],   resultsTable[123]]) 

    if((0!=resultsTable[128]) or (0!=resultsTable[127]) or (0!=resultsTable[126])):
        x.add_row(["PEX_12V_POWER",    resultsTable[128],  resultsTable[127],   resultsTable[126]]) 
        
    if((0!=resultsTable[131]) or (0!=resultsTable[130]) or (0!=resultsTable[129])):
        x.add_row(["PEX_3V3_POWER",    resultsTable[131],  resultsTable[130],   resultsTable[129]]) 

    if((0!=resultsTable[134]) or (0!=resultsTable[133]) or (0!=resultsTable[132])):
        x.add_row(["AUX_3V3_I",        resultsTable[134],  resultsTable[133],   resultsTable[132]]) 

    if((0!=resultsTable[137]) or (0!=resultsTable[136]) or (0!=resultsTable[135])):
        x.add_row(["VCC1V2_I",   resultsTable[137],  resultsTable[136],   resultsTable[135]]) 

    if((0!=resultsTable[140]) or (0!=resultsTable[139]) or (0!=resultsTable[138])):
        x.add_row(["V12_IN_I",     resultsTable[140],  resultsTable[139],   resultsTable[138]]) 

    if((0!=resultsTable[143]) or (0!=resultsTable[142]) or (0!=resultsTable[141])):
        x.add_row(["V12_IN_AUX0_I",       resultsTable[143],  resultsTable[142],   resultsTable[141]]) 

    if((0!=resultsTable[146]) or (0!=resultsTable[145]) or (0!=resultsTable[144])):
        x.add_row(["V12_IN_AUX1_I",        resultsTable[146],  resultsTable[145],   resultsTable[144]]) 

    if((0!=resultsTable[149]) or (0!=resultsTable[148]) or (0!=resultsTable[147])):
        x.add_row(["VCCAUX",  resultsTable[149],  resultsTable[148],   resultsTable[147]]) 

    if((0!=resultsTable[152]) or (0!=resultsTable[151]) or (0!=resultsTable[150])):
        x.add_row(["VCCAUX_PMC",    resultsTable[152],  resultsTable[151],   resultsTable[150]]) 

    if((0!=resultsTable[155]) or (0!=resultsTable[154]) or (0!=resultsTable[153])):
        x.add_row(["VCCRAM",      resultsTable[155],  resultsTable[154],   resultsTable[153]]) 
        
    if((0!=resultsTable[158]) or (0!=resultsTable[157]) or (0!=resultsTable[156])):
        x.add_row(["POWER_GOOD",    resultsTable[158],  resultsTable[157],   resultsTable[156]]) 

    print(x)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', '--card', action='store', dest='card', type=str, default='0', help='card\'s PCI bus number')
    args = parser.parse_args()

    if (args.card == '0'):
        print("Please specify card by PCI bus number - '-c <bus_no>' or '--card <bus_no>'")
        raise SystemExit
    else:
        xbcmc_test = pyxbcmc.xbcmc(args.card)
        print_sensors(args.card)


