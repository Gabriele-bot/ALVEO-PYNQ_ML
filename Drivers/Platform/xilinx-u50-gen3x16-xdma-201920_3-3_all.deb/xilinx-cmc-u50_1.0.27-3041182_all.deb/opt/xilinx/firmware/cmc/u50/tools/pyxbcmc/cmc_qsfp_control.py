#!/usr/bin/env python
# -*- coding: utf-8 -*-

################################################################################################
#                                                                                              #
# © Copyright 2019 Xilinx, Inc. All rights reserved.                                           #
#                                                                                              #
# This file contains confidential and proprietary information of Xilinx, Inc.                  #
# and is protected under U.S. and international copyright and other intellectual               #
# property laws.                                                                               #
#                                                                                              #
#                                                                                              #
# DISCLAIMER                                                                                   #
#                                                                                              #
# This disclaimer is not a license and does not grant any rights to the materials              #
# distributed herewith. Except as otherwise provided in a valid license issued                 #
# to you by Xilinx, and to the maximum extent permitted by applicable law:                     #
#                                                                                              #
# (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND WITH ALL FAULTS,                          #
# AND XILINX HEREBY DISCLAIMS ALL WARRANTIES AND CONDITIONS, EXPRESS, IMPLIED,                 #
# OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,                    #
# NON-INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and                                 #
#                                                                                              #
# (2) Xilinx shall not be liable (whether in contract or tort, including negligence,           #
# or under any other theory of liability) for any loss or damage of any kind or                #
# nature related to, arising under or in connection with these materials,                      #
# including for any direct, or any indirect, special, incidental, or consequential             #
# loss or damage (including loss of data, profits, goodwill, or any type of loss or            #
# damage suffered as a result of any action brought by a third party) even if such             #
# damage or loss was reasonably foreseeable or Xilinx had been advised of the                  #
# possibility of the same.                                                                     #
#                                                                                              #
#                                                                                              #
# CRITICAL APPLICATIONS                                                                        #
#                                                                                              #
# Xilinx products are not designed or intended to be fail-safe, or for use in                  #
# any application requiring fail-safe performance, such as life-support or safety              #
# devices or systems, Class III medical devices, nuclear facilities, applications              #
# related to the deployment of airbags, or any other applications that could lead              #
# to death, personal injury, or severe property or environmental damage (individually          #
# and collectively, "Critical Applications"). Customer assumes the sole risk and               #
# liability of any use of Xilinx products in Critical Applications, subject                    #
# only to applicable laws and regulations governing limitations on product liability.          #
#                                                                                              #
#                                                                                              #
# THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS PART OF THIS FILE AT ALL TIMES.     #
#                                                                                              #
################################################################################################

#
# RCS Keyword Metadata
# 
# $Change: 3034927 $
# $Date: 2020/10/14 $
# $Revision: #1 $
#

"""CMC qsfp"""

import argparse
import pyxbcmc
import time 

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', '--card', action='store', dest='card', type=str, default='0', help='card\'s PCI bus number')
    parser.add_argument('-q', '--qsfp', action='store', dest='qsfp', type=lambda x:int(x,0), default=0, help='qsfp')
    parser.add_argument('-p', '--page', action='store', dest='page', type=lambda x:int(x,0), default=0, help='page')
    parser.add_argument('-u', '--upper', action='store', dest='upper', type=lambda x:int(x,0), default=0, help='upper')
    parser.add_argument('-w1', '--word1', action='store', dest='word1', type=lambda x:int(x,0), default=0x00AAAA00, help='word1')
    parser.add_argument('-w2', '--word2', action='store', dest='word2', type=lambda x:int(x,0), default=0x00000000, help='word2')
    parser.add_argument('-w3', '--word3', action='store', dest='word3', type=lambda x:int(x,0), default=0x00000000, help='word3')
    parser.add_argument('-w4', '--word4', action='store', dest='word4', type=lambda x:int(x,0), default=0x000000FF, help='word4')
    parser.add_argument('-o', '--offset', action='store', dest='offset', type=lambda x:int(x,0), default=0x1000, help='offset')
    parser.add_argument('-b', '--bytes', action='store', dest='bytes', type=lambda x:int(x,0), default=140, help='bytes')
    parser.add_argument('-e', '--endian', action='store_true', dest='endian_swap', default=False, help='endian swap')
    parser.add_argument('-rw', '--rw', action='store', dest='rw', type=str, default='r', help='read write')

    args = parser.parse_args()

    if (args.card == '0'):
        print("Please specify card by PCI bus number - '-c <bus_no>' or '--card <bus_no>'")
        raise SystemExit
    else:
        xbcmc_test = pyxbcmc.xbcmc(args.card)

    xbcmc_test.cmc_reg_clear_100(args.card, "CMC_WHICH_PAGE_REG")
        
    if (args.rw == 'w'):

        #xbcmc_test.cmc_reg_write_with_mask(args.card, "CMC_HOST_MSG_REG", 0x0B000000, 0xffffffff)
        xbcmc_test.cmc_reg_write_with_mask(args.card, "CMC_HOST_MSG_REG", 0x0C<<24, 0xffffffff)
        xbcmc_test.cmc_reg_write_with_mask(args.card, "CMC_WHICH_QSFP_REG", args.qsfp, 0xffffffff)
        xbcmc_test.cmc_reg_write_with_mask(args.card, "CMC_QSFP_CONTROL_BYTES_SIZE", 13, 0xffffffff)
        xbcmc_test.cmc_reg_write_with_mask(args.card, "CMC_QSFP_CONTROL_BYTES1", args.word1, 0xffffffff)
        xbcmc_test.cmc_reg_write_with_mask(args.card, "CMC_QSFP_CONTROL_BYTES2", args.word2, 0xffffffff)
        xbcmc_test.cmc_reg_write_with_mask(args.card, "CMC_QSFP_CONTROL_BYTES3", args.word3, 0xffffffff)
        xbcmc_test.cmc_reg_write_with_mask(args.card, "CMC_QSFP_CONTROL_BYTES4", args.word4, 0xffffffff)
        xbcmc_test.cmc_reg_write_with_mask(args.card, "CMC_CONTROL_REG", 0x20, 0x20)

    elif (args.rw == 'r'):


        #xbcmc_test.cmc_reg_write_with_mask(args.card, "CMC_HOST_MSG_REG", 0x0B000000, 0xffffffff)
        xbcmc_test.cmc_reg_write_with_mask(args.card, "CMC_HOST_MSG_REG", 0x0B<<24, 0xffffffff)
        xbcmc_test.cmc_reg_write_with_mask(args.card, "CMC_WHICH_QSFP_REG", args.qsfp, 0xffffffff)
        xbcmc_test.cmc_reg_write_with_mask(args.card, "CMC_WHICH_PAGE_REG", args.page, 0xffffffff)
        xbcmc_test.cmc_reg_write_with_mask(args.card, "CMC_WHICH_UPPER_REG", args.upper, 0xffffffff)
        xbcmc_test.cmc_reg_write_with_mask(args.card, "CMC_CONTROL_REG", 0x20, 0x20)


    while(xbcmc_test.cmc_reg_read(args.card, "CMC_CONTROL_REG") == 0x20):
            time.sleep(0.1)


    if(xbcmc_test.cmc_reg_read(args.card, "CMC_HOST_MSG_ERROR_REG") == 0x0):
       print('QSFP complete')
    else:
       print('QSFP failed %x',xbcmc_test.cmc_reg_read(args.card, "CMC_HOST_MSG_ERROR_REG"))


    xbcmc_test.cmc_reg_dump(args.card, args.offset, 160, False)


