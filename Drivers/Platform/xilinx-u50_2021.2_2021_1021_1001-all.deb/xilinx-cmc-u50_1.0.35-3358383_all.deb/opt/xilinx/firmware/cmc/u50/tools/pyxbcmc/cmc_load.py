#!/usr/bin/env python
# -*- coding: utf-8 -*-

################################################################################################
#                                                                                              #
# © Copyright 2019 Xilinx, Inc. All rights reserved.                                           #
#                                                                                              #
# This file contains confidential and proprietary information of Xilinx, Inc.                  #
# and is protected under U.S. and international copyright and other intellectual               #
# property laws.                                                                               #
#                                                                                              #
#                                                                                              #
# DISCLAIMER                                                                                   #
#                                                                                              #
# This disclaimer is not a license and does not grant any rights to the materials              #
# distributed herewith. Except as otherwise provided in a valid license issued                 #
# to you by Xilinx, and to the maximum extent permitted by applicable law:                     #
#                                                                                              #
# (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND WITH ALL FAULTS,                          #
# AND XILINX HEREBY DISCLAIMS ALL WARRANTIES AND CONDITIONS, EXPRESS, IMPLIED,                 #
# OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,                    #
# NON-INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and                                 #
#                                                                                              #
# (2) Xilinx shall not be liable (whether in contract or tort, including negligence,           #
# or under any other theory of liability) for any loss or damage of any kind or                #
# nature related to, arising under or in connection with these materials,                      #
# including for any direct, or any indirect, special, incidental, or consequential             #
# loss or damage (including loss of data, profits, goodwill, or any type of loss or            #
# damage suffered as a result of any action brought by a third party) even if such             #
# damage or loss was reasonably foreseeable or Xilinx had been advised of the                  #
# possibility of the same.                                                                     #
#                                                                                              #
#                                                                                              #
# CRITICAL APPLICATIONS                                                                        #
#                                                                                              #
# Xilinx products are not designed or intended to be fail-safe, or for use in                  #
# any application requiring fail-safe performance, such as life-support or safety              #
# devices or systems, Class III medical devices, nuclear facilities, applications              #
# related to the deployment of airbags, or any other applications that could lead              #
# to death, personal injury, or severe property or environmental damage (individually          #
# and collectively, "Critical Applications"). Customer assumes the sole risk and               #
# liability of any use of Xilinx products in Critical Applications, subject                    #
# only to applicable laws and regulations governing limitations on product liability.          #
#                                                                                              #
#                                                                                              #
# THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS PART OF THIS FILE AT ALL TIMES.     #
#                                                                                              #
################################################################################################

#
# RCS Keyword Metadata
# 
# $Change: 3034927 $
# $Date: 2020/10/14 $
# $Revision: #1 $
#

"""CMC firmware load utility"""

import argparse
import os.path
import pyxbcmc
from time import sleep

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', '--card', action='store', dest='card', type=str, default='0', help='card\'s PCI bus number')
    parser.add_argument("image", help="firmware image binary")
    args = parser.parse_args()

    xbcmc_test = pyxbcmc.xbcmc(args.card)

    if (False == os.path.isfile(args.image)):
        print("Error: Unable to load firmare image %s" % (args.image))
        raise SystemExit(1)
    else:
        timeout_sec = 10
        interval_sec = 1
        interval_sec_comms = 3

        # stop processor if not held in reset
        gpio_value = xbcmc_test.cmc_gpio_read(args.card, "MB_CTRL")
        if (0x1 == gpio_value):
            xbcmc_test.cmc_stop(args.card)

            cmc_timeout = True
            for i in range(int(timeout_sec/interval_sec)):
                sleep(interval_sec)
                if (xbcmc_test.cmc_reg_decode(args.card, "CMC_STATUS_REG")["cmc_stopped"]):
                    cmc_timeout = False
                    break

            if (cmc_timeout):
                print("Warning: Failed to stop CMC")
            else:
                print("Info: CMC stopped")

        # load firmware image to processor memory
        print("Info: Enabling reset and loading firmware image")
        xbcmc_test.cmc_gpio_write(args.card, "MB_CTRL", 0x0)
        xbcmc_test.cmc_load_firmware_image(args.card, args.image)
        xbcmc_test.cmc_gpio_write(args.card, "MB_CTRL", 0x1)
        print("Info: Releasing reset")

        # check running
        print("Info: Waiting for CMC to start")
        cmc_timeout = True
        for i in range(int(timeout_sec/interval_sec)):
            sleep(interval_sec)
            # gpio reset release can see register bits held at 1, catch decode errors
            try:
                status_fields = xbcmc_test.cmc_reg_decode(args.card, "CMC_STATUS_REG")
                if (status_fields["cmc_init_done"]):
                    cmc_timeout = False
                    break
            except KeyError:
                pass

        if (cmc_timeout):
            print("Error: Failed to start CMC")
            raise SystemExit(1)
        else:
            print("Info: CMC running")

        # check comms link established with SC
        sleep(interval_sec_comms)
        fsm_fields = xbcmc_test.cmc_fsm_info_decode(args.card, "W_LINK_STATE_CURRENT")
        if ("S_LINK_USER_IS_REMOTE_SENSOR_SUPERVISOR_LINK_OPERATING" in fsm_fields["LS_Current"]):
            print("Info: SC comms established")
            print("Info: CMC firmware loaded successfully")
        else:
            print("Error: Failed to establish comms with SC")
            print("Error: Link State Is " + fsm_fields["LS_Current"])
            raise SystemExit(1)
