# -*- coding: utf-8 -*-

################################################################################################
#                                                                                              #
# © Copyright 2019 Xilinx, Inc. All rights reserved.                                           #
#                                                                                              #
# This file contains confidential and proprietary information of Xilinx, Inc.                  #
# and is protected under U.S. and international copyright and other intellectual               #
# property laws.                                                                               #
#                                                                                              #
#                                                                                              #
# DISCLAIMER                                                                                   #
#                                                                                              #
# This disclaimer is not a license and does not grant any rights to the materials              #
# distributed herewith. Except as otherwise provided in a valid license issued                 #
# to you by Xilinx, and to the maximum extent permitted by applicable law:                     #
#                                                                                              #
# (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND WITH ALL FAULTS,                          #
# AND XILINX HEREBY DISCLAIMS ALL WARRANTIES AND CONDITIONS, EXPRESS, IMPLIED,                 #
# OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,                    #
# NON-INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and                                 #
#                                                                                              #
# (2) Xilinx shall not be liable (whether in contract or tort, including negligence,           #
# or under any other theory of liability) for any loss or damage of any kind or                #
# nature related to, arising under or in connection with these materials,                      #
# including for any direct, or any indirect, special, incidental, or consequential             #
# loss or damage (including loss of data, profits, goodwill, or any type of loss or            #
# damage suffered as a result of any action brought by a third party) even if such             #
# damage or loss was reasonably foreseeable or Xilinx had been advised of the                  #
# possibility of the same.                                                                     #
#                                                                                              #
#                                                                                              #
# CRITICAL APPLICATIONS                                                                        #
#                                                                                              #
# Xilinx products are not designed or intended to be fail-safe, or for use in                  #
# any application requiring fail-safe performance, such as life-support or safety              #
# devices or systems, Class III medical devices, nuclear facilities, applications              #
# related to the deployment of airbags, or any other applications that could lead              #
# to death, personal injury, or severe property or environmental damage (individually          #
# and collectively, "Critical Applications"). Customer assumes the sole risk and               #
# liability of any use of Xilinx products in Critical Applications, subject                    #
# only to applicable laws and regulations governing limitations on product liability.          #
#                                                                                              #
#                                                                                              #
# THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS PART OF THIS FILE AT ALL TIMES.     #
#                                                                                              #
################################################################################################


#
# RCS Keyword Metadata
# 
# $Change: 3358330 $
# $Date: 2021/10/06 $
# $Revision: #36 $
#



"""xbcmc Utility Module """

from mmap import mmap, ACCESS_READ, ACCESS_WRITE
from os.path import getsize
from re import compile
from struct import pack, unpack
from subprocess import check_output
from time import sleep
import os, getpass

class xbcmc:
    """xbcmc Utilities"""

    ## In case of no root access (bbrobot running the script), this variable
    # will be used to switch I/O to 'devmem2'
    root_access = True

    ## PCIe ID dictionary : 
    # [0] "DEVICE_NAME", 
    # [1] cmc_base_addr,
    # [2] cmc_regmap_offset,
    # [3] cmc_lmb_offset,
    # [4] cmc_lmb_bytes,
    # [5] cmc_gpio["MB_CTRL"],
    # [6] physical function number where CMC 'lives': [0000:ab:00.x] (0: management, 1: user)

    PCIe_IDs_dict = {
        '0x5000': ("U200 XDMA", 0x01E00000, 0x8000, 0x20000, 0x1FFFF, 0x1000, '0'),
        '0x5004': ("U250 XDMA", 0x01E00000, 0x8000, 0x20000, 0x1FFFF, 0x1000, '0'),
        '0x5008': ("U280 U280-ES1 XDMA", 0x01E00000, 0x8000, 0x20000, 0x1FFFF, 0x1000, '0'),
        '0x500c': ("U280 XDMA", 0x01E00000, 0x8000, 0x20000, 0x1FFFF, 0x1000, '0'),
        '0x5010': ("U200 QDMA", 0x01E00000, 0x8000, 0x20000, 0x1FFFF, 0x1000, '0'),
        '0x5014': ("U250 QDMA", 0x01E00000, 0x8000, 0x20000, 0x1FFFF, 0x1000, '0'),
        '0x5020': ("U50 XDMA", 0x01E00000, 0x8000, 0x20000, 0x1FFFF, 0x1000, '0'),
        '0x5028': ("V350 XDMA", 0x3000000, 0x0, 0x20000, 0x1FFFF, 0x1000, '0'),
        '0x5050': ("U25", 0x01E00000, 0x8000, 0x20000, 0x1FFFF, 0x1000, '0'),
        '0x503d': ("U30 XDMA", 0x120000, 0x0, 0x20000, 0x1FFFF, 0x1000, '1'),
        '0x513c': ("U30 XDMA", 0x120000, 0x0, 0x20000, 0x1FFFF, 0x1000, '0'),
        '0x5044': ("VCK5000 XDMA", 0x6000000, 0x0, 0x20000, 0x1FFFF, 0x1000, '0'),
        '0x5058': ("U55N", 0x01E00000, 0x8000, 0x20000, 0x1FFFF, 0x1000, '0'),
        '0x505c': ("U55", 0x01E00000, 0x8000, 0x20000, 0x1FFFF, 0x1000, '0'),
        '0x6987': ("U.2", 0, 0x120000, 0x140000, 0x20000, 0x131000, '0'),
        '0x5060': ("U50lv XDMA", 0x01E00000, 0x8000, 0x20000, 0x1FFFF, 0x1000, '0'),
        '0x506c': ("U50C", 0x01E00000, 0x8000, 0x20000, 0x1FFFF, 0x1000, '0'),
        '0x8888': ("CMS EXDES", 0x00000000, 0x28000, 0x00000000, 0x1FFFF, 0x20000, '0'),
        '0x504e': ("U26", 0x01E00000, 0x8000, 0x20000, 0x1FFFF, 0x1000, '0'),
        '0x5074': ("X3", 0x01E00000, 0x8000, 0x20000, 0x1FFFF, 0x1000, '0'),
		'0x5078': ("V65 XDMA", 0x6000000, 0x0, 0x20000, 0x1FFFF, 0x1000, '0')
    };

    # cmc: card management controller
    cmc_base_addr = 0x01E00000
    cmc_freq_hz = 50925925

    cmc_gpio = {
        "MB_CTRL": 0x1000, # offset is 0x1000 in confluence CMC Subsystem V2.1 +0x01E00000 (Build dependent)
        "MUTEX_GRANT": 0x2000 # offset is 0x2000 in confluence CMC Subsystem V2.1 +0x01E00000 (Build dependent)
    }

    cmc_lmb_bytes = 0x1FFFF

    python_tools = "0x0C010028" # Should be in line with Core Version


    cmc_magic_val = 0x74736574
    cmc_regmap_bytes = 0x2000
    cmc_regmap = {
        # versions
        "CMC_MAGIC_REG":    0x0000,
        "CMC_VERSION_REG":  0x0004,
        # csr
        "CMC_STATUS_REG":       0x0008,
        "CMC_ERROR_REG":        0x000C,
        "CMC_FEATURE_REG":      0x0010,
        "CMC_PROFILE_NAME_REG": 0x0014,
        "CMC_CONTROL_REG":      0x0018,
        "CMC_STOP_CONFIRM_REG": 0x001C,
        "CMC_STATUS2_REG":      0x030C,
        # sensors >> TODO: could calculate offsets based on sensor id
        "CMC_12V_PEX_MAX_REG":          0x0020,
        "CMC_12V_PEX_AVG_REG":          0x0024,
        "CMC_12V_PEX_INS_REG":          0x0028,
        "CMC_3V3_PEX_MAX_REG":          0x002C,
        "CMC_3V3_PEX_AVG_REG":          0x0030,
        "CMC_3V3_PEX_INS_REG":          0x0034,
        "CMC_3V3_AUX_MAX_REG":          0x0038,
        "CMC_3V3_AUX_AVG_REG":          0x003C,
        "CMC_3V3_AUX_INS_REG":          0x0040,
        "CMC_12V_AUX_MAX_REG":          0x0044,
        "CMC_12V_AUX_AVG_REG":          0x0048,
        "CMC_12V_AUX_INS_REG":          0x004C,
        "CMC_DDR4_VPP_BTM_MAX_REG":     0x0050,
        "CMC_DDR4_VPP_BTM_AVG_REG":     0x0054,
        "CMC_DDR4_VPP_BTM_INS_REG":     0x0058,
        "CMC_SYS_5V5_MAX_REG":          0x005C,
        "CMC_SYS_5V5_AVG_REG":          0x0060,
        "CMC_SYS_5V5_INS_REG":          0x0064,
        "CMC_VCC1V2_TOP_MAX_REG":       0x0068,
        "CMC_VCC1V2_TOP_AVG_REG":       0x006C,
        "CMC_VCC1V2_TOP_INS_REG":       0x0070,
        "CMC_VCC1V8_MAX_REG":           0x0074,
        "CMC_VCC1V8_AVG_REG":           0x0078,
        "CMC_VCC1V8_INS_REG":           0x007C,
        "CMC_VCC0V85_MAX_REG":          0x0080,
        "CMC_VCC0V85_AVG_REG":          0x0084,
        "CMC_VCC0V85_INS_REG":          0x0088,
        "CMC_DDR4_VPP_TOP_MAX_REG":     0x008C,
        "CMC_DDR4_VPP_TOP_AVG_REG":     0x0090,
        "CMC_DDR4_VPP_TOP_INS_REG":     0x0094,
        "CMC_MGT0V9AVCC_MAX_REG":       0x0098,
        "CMC_MGT0V9AVCC_AVG_REG":       0x009C,
        "CMC_MGT0V9AVCC_INS_REG":       0x00A0,
        "CMC_12V_SW_MAX_REG":           0x00A4,
        "CMC_12V_SW_AVG_REG":           0x00A8,
        "CMC_12V_SW_INS_REG":           0x00AC,
        "CMC_MGTAVTT_MAX_REG":          0x00B0,
        "CMC_MGTAVTT_AVG_REG":          0x00B4,
        "CMC_MGTAVTT_INS_REG":          0x00B8,
        "CMC_VCC1V2_BTM_MAX_REG":       0x00BC,
        "CMC_VCC1V2_BTM_AVG_REG":       0x00C0,
        "CMC_VCC1V2_BTM_INS_REG":       0x00C4,
        "CMC_12VPEX_I_IN_MAX_REG":      0x00C8,
        "CMC_12VPEX_I_IN_AVG_REG":      0x00CC,
        "CMC_12VPEX_I_IN_INS_REG":      0x00D0,
        "CMC_12V_AUX_I_IN_MAX_REG":     0x00D4,
        "CMC_12V_AUX_I_IN_AVG_REG":     0x00D8,
        "CMC_12V_AUX_I_IN_INS_REG":     0x00DC,
        "CMC_VCCINT_MAX_REG":           0x00E0,
        "CMC_VCCINT_AVG_REG":           0x00E4,
        "CMC_VCCINT_INS_REG":           0x00E8,
        "CMC_I_VCCINT_MAX_REG":         0x00EC,
        "CMC_I_VCCINT_AVG_REG":         0x00F0,
        "CMC_I_VCCINT_INS_REG":         0x00F4,
        "CMC_FPGA_TEMP_MAX_REG":        0x00F8,
        "CMC_FPGA_TEMP_AVG_REG":        0x00FC,
        "CMC_FPGA_TEMP_INS_REG":        0x0100,
        "CMC_FAN_TEMP_MAX_REG":         0x0104,
        "CMC_FAN_TEMP_AVG_REG":         0x0108,
        "CMC_FAN_TEMP_INS_REG":         0x010C,
        "CMC_DIMM_TEMP0_MAX_REG":       0x0110,
        "CMC_DIMM_TEMP0_AVG_REG":       0x0114,
        "CMC_DIMM_TEMP0_INS_REG":       0x0118,
        "CMC_DIMM_TEMP1_MAX_REG":       0x011C,
        "CMC_DIMM_TEMP1_AVG_REG":       0x0120,
        "CMC_DIMM_TEMP1_INS_REG":       0x0124,
        "CMC_DIMM_TEMP2_MAX_REG":       0x0128,
        "CMC_DIMM_TEMP2_AVG_REG":       0x012C,
        "CMC_DIMM_TEMP2_INS_REG":       0x0130,
        "CMC_DIMM_TEMP3_MAX_REG":       0x0134,
        "CMC_DIMM_TEMP3_AVG_REG":       0x0138,
        "CMC_DIMM_TEMP3_INS_REG":       0x013C,
        "CMC_SE98_TEMP0_MAX_REG":       0x0140,
        "CMC_SE98_TEMP0_AVG_REG":       0x0144,
        "CMC_SE98_TEMP0_INS_REG":       0x0148,
        "CMC_SE98_TEMP1_MAX_REG":       0x014C,
        "CMC_SE98_TEMP1_AVG_REG":       0x0150,
        "CMC_SE98_TEMP1_INS_REG":       0x0154,
        "CMC_SE98_TEMP2_MAX_REG":       0x0158,
        "CMC_SE98_TEMP2_AVG_REG":       0x015C,
        "CMC_SE98_TEMP2_INS_REG":       0x0160,
        "CMC_FAN_SPEED_MAX_REG":        0x0164,
        "CMC_FAN_SPEED_AVG_REG":        0x0168,
        "CMC_FAN_SPEED_INS_REG":        0x016C,
        "CMC_CAGE_TEMP0_MAX_REG":       0x0170,
        "CMC_CAGE_TEMP0_AVG_REG":       0x0174,
        "CMC_CAGE_TEMP0_INS_REG":       0x0178,
        "CMC_CAGE_TEMP1_MAX_REG":       0x017C,
        "CMC_CAGE_TEMP1_AVG_REG":       0x0180,
        "CMC_CAGE_TEMP1_INS_REG":       0x0184,
        "CMC_CAGE_TEMP2_MAX_REG":       0x0188,
        "CMC_CAGE_TEMP2_AVG_REG":       0x018C,
        "CMC_CAGE_TEMP2_INS_REG":       0x0190,
        "CMC_CAGE_TEMP3_MAX_REG":       0x0194,
        "CMC_CAGE_TEMP3_AVG_REG":       0x0198,
        "CMC_CAGE_TEMP3_INS_REG":       0x019C,
        "CMC_MAC0_0_REG":               0x01A0,
        "CMC_MAC0_1_REG":               0x01A4,
        "CMC_MAC1_0_REG":               0x01A8,
        "CMC_MAC1_1_REG":               0x01AC,
        "CMC_MAC2_0_REG":               0x01B0,
        "CMC_MAC2_1_REG":               0x01B4,
        "CMC_MAC3_0_REG":               0x01B8,
        "CMC_MAC3_1_REG":               0x01BC,
        "CMC_MAC4_0_REG":               0x01C0,
        "CMC_MAC4_1_REG":               0x01C4,
        "CMC_MAC5_0_REG":               0x01C8,
        "CMC_MAC5_1_REG":               0x01CC,
        "CMC_MAC6_0_REG":               0x01D0,
        "CMC_MAC6_1_REG":               0x01D4,
        "CMC_MAC7_0_REG":               0x01D8,
        "CMC_MAC7_1_REG":               0x01DC,
        "CMC_HBM_TEMP_1_MAX_REG":       0x0260,
        "CMC_HBM_TEMP_1_AVG_REG":       0x0264,
        "CMC_HBM_TEMP_1_INS_REG":       0x0268,
        "CMC_VCC3V3_MAX_REG":           0x026C,
        "CMC_VCC3V3_AVG_REG":           0x0270,
        "CMC_VCC3V3_INS_REG":           0x0274,
        "CMC_3V3PEX_I_IN_MAX_REG":      0x0278,
        "CMC_3V3PEX_I_IN_AVG_REG":      0x027C,
        "CMC_3V3PEX_I_IN_INS_REG":      0x0280,
        "CMC_I_VCC0V85_MAX_REG":        0x0284,
        "CMC_I_VCC0V85_AVG_REG":        0x0288,
        "CMC_I_VCC0V85_INS_REG":        0x028C,
        "CMC_HBM_1V2_MAX_REG":          0x0290,
        "CMC_HBM_1V2_AVG_REG":          0x0294,
        "CMC_HBM_1V2_INS_REG":          0x0298,
        "CMC_VPP2V5_MAX_REG":           0x029C,
        "CMC_VPP2V5_AVG_REG":           0x02A0,
        "CMC_VPP2V5_INS_REG":           0x02A4,
        "CMC_VCC_INT_BRAM_MAX_REG":     0x02A8,
        "CMC_VCC_INT_BRAM_AVG_REG":     0x02AC,
        "CMC_VCC_INT_BRAM_INS_REG":     0x02B0,
        "CMC_HBM_TEMP_2_MAX_REG":       0x02B4,
        "CMC_HBM_TEMP_2_AVG_REG":       0x02B8,
        "CMC_HBM_TEMP_2_INS_REG":       0x02BC,
        "CMC_12V_AUX1_MAX_REG":         0x02C0,
        "CMC_12V_AUX1_AVG_REG":         0x02C4,
        "CMC_12V_AUX1_INS_REG":         0x02C8,
        "CMC_VCCINT_TEMP_MAX_REG":      0x02CC,
        "CMC_VCCINT_TEMP_AVG_REG":      0x02D0,
        "CMC_VCCINT_TEMP_INS_REG":      0x02D4,
        "CMC_PEX_12V_POWER_MAX_REG":    0x02D8,
        "CMC_PEX_12V_POWER_AVG_REG":    0x02DC,
        "CMC_PEX_12V_POWER_INS_REG":    0x02E0,
        "CMC_PEX_3V3_POWER_MAX_REG":    0x02E4,
        "CMC_PEX_3V3_POWER_AVG_REG":    0x02E8,
        "CMC_PEX_3V3_POWER_INS_REG":    0x02EC,
        "CMC_AUX_3V3_POWER_MAX_REG":    0x02F0,
        "CMC_AUX_3V3_POWER_AVG_REG":    0x02F4,
        "CMC_AUX_3V3_POWER_INS_REG":    0x02F8,
		
		# host message
        "CMC_HEARTBEAT_REG":            0x02FC,
        "CMC_HOST_MSG_OFFSET_REG":      0x0300,
        "CMC_HOST_MSG_ERROR_REG":       0x0304,
        "CMC_HEARTBEAT_ERR_CODE_REG":   0x0310,
		
        "CMC_VCC1V2_I_MAX_REG":         0x0314,
        "CMC_VCC1V2_I_AVG_REG":         0x0318,
        "CMC_VCC1V2_I_INS_REG":         0x031C,
        "CMC_V12_IN_I_MAX_REG":         0x0320,
        "CMC_V12_IN_I_AVG_REG":         0x0324,
        "CMC_V12_IN_I_INS_REG":         0x0328,
        "CMC_V12_IN_AUX0_I_MAX_REG":    0x032C,
        "CMC_V12_IN_AUX0_I_AVG_REG":    0x0330,
        "CMC_V12_IN_AUX0_I_INS_REG":    0x0334,
        "CMC_V12_IN_AUX1_I_MAX_REG":    0x0338,
        "CMC_V12_IN_AUX1_I_AVG_REG":    0x033C,
        "CMC_V12_IN_AUX1_I_INS_REG":    0x0340,
        "CMC_VCCAUX_MAX_REG":           0x0344,
        "CMC_VCCAUX_AVG_REG":           0x0348,
        "CMC_VCCAUX_INS_REG":           0x034C,
        "CMC_VCCAUX_PMC_MAX_REG":       0x0350,
        "CMC_VCCAUX_PMC_AVG_REG":       0x0354,
        "CMC_VCCAUX_PMC_INS_REG":       0x0358,
        "CMC_VCCRAM_MAX_REG":           0x035C,
        "CMC_VCCRAM_AVG_REG":           0x0360,
        "CMC_VCCRAM_INS_REG":           0x0364,
        "CMC_POWER_GOOD_MAX_REG":       0x0368,		#0x46
        "CMC_POWER_GOOD_AVG_REG":       0x036C,
        "CMC_POWER_GOOD_INS_REG":       0x0370,
		"CMC_VCCINT_POWER_MAX_REG":     0x0374,		#0x47
        "CMC_VCCINT_POWER_AVG_REG":     0x0378,
        "CMC_VCCINT_POWER_INS_REG":     0x037C,		
		"CMC_VCCINT_VCU_0V9_MAX_REG":  	0x0380,		#0x48
        "CMC_VCCINT_VCU_0V9_AVG_REG":  	0x0384,
        "CMC_VCCINT_VCU_0V9_INS_REG":  	0x0388,		
		"CMC_1V2_VCCIO_MAX_REG":        0x038C,		#0x49
        "CMC_1V2_VCCIO_AVG_REG":        0x0390,
        "CMC_1V2_VCCIO_INS_REG":        0x0394,		
		"CMC_GTAVCC_MAX_REG":           0x0398,		#0x4A
        "CMC_GTAVCC_AVG_REG":           0x039C,
        "CMC_GTAVCC_INS_REG":           0x03A0,
													#0x4B NEW_MAC_SCHEME   
													
		"CMC_VCCSOC_MAX_REG":           0x03B0,		#0x4C
        "CMC_VCCSOC_AVG_REG":           0x03B4,
        "CMC_VCCSOC_INS_REG":           0x03B8,
		"CMC_VCC_5V0_MAX_REG":          0x03BC,		#0x4D
        "CMC_VCC_5V0_AVG_REG":          0x03C0,
        "CMC_VCC_5V0_INS_REG":          0x03C4,
		"CMC_2V5_VPP23_MAX_REG":        0x03C8,		#0x4E
        "CMC_2V5_VPP23_AVG_REG":        0x03CC,
        "CMC_2V5_VPP23_INS_REG":        0x03D0,
		"CMC_GTVCC_AUX_MAX_REG":        0x03D4,		#0x4F
        "CMC_GTVCC_AUX_AVG_REG":        0x03D8,
        "CMC_GTVCC_AUX_INS_REG":        0x03DC,
        


        "W_LINK_STATE_LAST_EVENT":                          0x04D0,
        "W_LINK_STATE_CURRENT":                             0x04D4,
        "W_LINK_STATE_PREVIOUS":                            0x04D8,
        "W_LINK_STATE_FSM_ILLEGAL_STATE":                   0x04DC,
        "W_LINK_STATE_UNEXPECTED_EVENT":                    0x04E0,
        "W_LINK_STATE_UNEXPECTED_ACTION":                   0x04E4,
        "W_LINK_STATE_FSM_FAILED_TO_ADD_EVENT":             0x04E8,
        "W_BOOTLOADER_LAST_EVENT":                          0x04EC,
        "W_BOOTLOADER_CURRENT":                             0x04F0,
        "W_BOOTLOADER_PREVIOUS":                            0x04F4,
        "W_BOOTLOADER_FSM_ILLEGAL_STATE":                   0x04F8,
        "W_BOOTLOADER_UNEXPECTED_EVENT":                    0x04FC,
        "W_BOOTLOADER_UNEXPECTED_ACTION":                   0x0500,
        "W_BOOTLOADER_FSM_FAILED_TO_ADD_EVENT":             0x0504,
        "W_THREAD_LOOP_ACTIVITY":                           0x0508,
        "W_THREAD_TIMER":                                   0x050C,
        "W_THREAD_WATCHDOG":                                0x0510,
        "W_THREAD_HOST_USER_PROXY":                         0x0514,
        "W_THREAD_LOCAL_BOOTLOADER":                        0x0518,
        "W_THREAD_LOCAL_LINK_SUPERVISOR":                   0x051C,
        "W_THREAD_LOCAL_SENSOR_SUPERVISOR":                 0x0520,
        "W_THREAD_LINK_RECEIVE":                            0x0524,
        "W_THREAD_LINK_PROTOCOL_LOGGER":                    0x0528,
        "W_THREAD_MUTEX_OBSERVER":                          0x052C,
        "W_THREAD_X2_COMMS":                                0x0530,
        "W_SENSOR_SUPERVISOR_LAST_EVENT":                   0x0534,
        "W_SENSOR_SUPERVISOR_CURRENT":                      0x0538,
        "W_SENSOR_SUPERVISOR_PREVIOUS":                     0x053C,
        "W_SENSOR_SUPERVISOR_FSM_ILLEGAL_STATE":            0x0540,
        "W_SENSOR_SUPERVISOR_UNEXPECTED_EVENT":             0x0544,
        "W_SENSOR_SUPERVISOR_UNEXPECTED_ACTION":            0x0548,
        "W_SENSOR_SUPERVISOR_FSM_FAILED_TO_ADD_EVENT":      0x054C,
        "W_SENSOR_SUPERVISOR_MESSAGE_VERSION_UNSUPPORTED":  0x0550,
        "W_HOST_PROXY_LAST_EVENT":                          0x0554,
        "W_HOST_PROXY_CURRENT":                             0x0558,
        "W_HOST_PROXY_PREVIOUS":                            0x055C,
        "W_HOST_PROXY_FSM_ILLEGAL_STATE":                   0x0560,
        "W_HOST_PROXY_UNEXPECTED_EVENT":                    0x0564,
        "W_HOST_PROXY_UNEXPECTED_ACTION":                   0x0568,
        "W_HOST_PROXY_FSM_FAILED_TO_ADD_EVENT":             0x056C,
        "W_HOST_PROXY_UNRECOGNISED_REMOTE_COMMAND":         0x0570,
        "W_HOST_PROXY_UNEXPECTED_LOCAL_ACTION":             0x0574,
        "W_HOST_PROXY_UNEXPECTED_REMOTE_ACTION":            0x0578,
        "W_LINK_RECEIVE_NO_ROOM_FOR_OCTET":                 0x057C,
        
        # 2nd RAM area
        "W_INTERRUPT_ENTER":                                0x0C94,
        "W_INTERRUPT_EXIT":                                 0x0C98,
        "W_INTERRUPT_SOURCE_UART_LITE_SATELLITE":           0x0C9C,
        "W_INTERRUPT_SOURCE_CAGE_IO":                       0x0CA0,
        "W_INTERRUPT_SOURCE_WDT":                           0x0CA4,
        "W_INTERRUPT_SOURCE_GPIO_SATELLITE":                0x0CA8,
        "W_HEARTBEAT_SINGLE_SNSR_ERR_CNT":                  0x0CAC,
        "W_INTERRUPT_IGNORED_SOURCES":                      0x0CB0,
        "W_SENSOR_RELAY_TRY_ADD_FAIL":                      0x0CB4,
        "W_SENSOR_RELAY_TRY_REMOVE_FAIL":                   0x0CB8,
        "W_SENSOR_ERROR_COUNT_REG":                         0x0CBC,
        "W_BOARDINFO_SIZE_ERROR_COUNT_REG":                 0x0CC0,
        "W_LINK_RECEIVE_GOOD_MSG_UNHANDLED_MSG_ID":         0x0CC4,
        "W_LINK_RECEIVE_ERR_MSG_UNHANDLED_MSG_ID":          0x0CC8,
        "W_LINK_RECEIVE_MSG_RECEIVED_UNKNOWN_MSG_ID":       0x0CCC,
        "W_LINK_RECEIVE_NEGOTIATED_VERSION":                0x0CD0,
        "W_HBM_SUPPORTED":                                  0x0CD4,
        "W_HBM_PAYLOAD":                                    0x0CD8,
        "W_HEARTBEAT_MULTIPLE_SNSR_ERR_CNT":                0x0CDC,
        "W_SCHEDULER_ENTER":                                0x0CE0,
        "W_SCHEDULER_EXIT":                                 0x0CE4,
        "W_HOST_REGISTER_RANGE_VIOLATION":                  0x0CE8,
        "W_RUNTIME_THREAD_LOOP_ACTIVITY":                   0x0CEC,
        "W_RUNTIME_THREAD_TIMER":                           0x0CF0,
        "W_RUNTIME_THREAD_WATCHDOG":                        0x0CF4,
        "W_RUNTIME_THREAD_HOST_USER_PROXY":                 0x0CF8,
        "W_RUNTIME_THREAD_LOCAL_BOOTLOADER":                0x0CFC,
        "W_RUNTIME_THREAD_LOCAL_LINK_SUPERVISOR":           0x0D00,
        "W_RUNTIME_THREAD_LOCAL_SENSOR_SUPERVISOR":         0x0D04,
        "W_RUNTIME_THREAD_LINK_RECEIVE":                    0x0D08,
        "W_RUNTIME_THREAD_LINK_PROTOCOL_LOGGER":            0x0D0C,
        "W_RUNTIME_THREAD_MUTEX_OBSERVER":                  0x0D10,
        "W_RUNTIME_THREAD_X2_COMMS":                        0x0D14,
        "W_MAX_RUNTIME_THREAD_LOOP_ACTIVITY":               0x0D18,
        "W_MAX_RUNTIME_THREAD_TIMER":                       0x0D1C,
        "W_MAX_RUNTIME_THREAD_WATCHDOG":                    0x0D20,
        "W_MAX_RUNTIME_THREAD_HOST_USER_PROXY":             0x0D24,
        "W_MAX_RUNTIME_THREAD_LOCAL_BOOTLOADER":            0x0D28,
        "W_MAX_RUNTIME_THREAD_LOCAL_LINK_SUPERVISOR":       0x0D2C,
        "W_MAX_RUNTIME_THREAD_LOCAL_SENSOR_SUPERVISOR":     0x0D30,
        "W_MAX_RUNTIME_THREAD_LINK_RECEIVE":                0x0D34,
        "W_MAX_RUNTIME_THREAD_LINK_PROTOCOL_LOGGER":        0x0D38,
        "W_MAX_RUNTIME_THREAD_MUTEX_OBSERVER":              0x0D3C,
        "W_MAX_RUNTIME_THREAD_X2_COMMS":                    0x0D40,
        "W_ARBITRARY_TIME_DIFFERENCE_CURRENT":              0x0D44,
        "W_ARBITRARY_TIME_DIFFERENCE_MAX":                  0x0D48,
        "W_SENSOR_SUPERVISOR_LATE_MESSAGE_ARRIVAL":         0x0D4C,
        "W_SENSOR_SUPERVISOR_MESSAGE_DIDNT_ARRIVE":         0x0D50,
        "W_LINK_RECEIVE_DEBUG_CAPTURE_POSITION":            0x0D54,
        "W_MUTEX_REACHOUT_GRANTED":                         0x0D58,
        "W_MUTEX_ACCESSING_REACHOUT_INTERFACE":             0x0D5C,
        "W_X2_COMMS_FSM_LAST_EVENT":                        0x0D60,
        "W_X2_COMMS_FSM_CURRENT_STATE":                     0x0D64,
        "W_X2_COMMS_FSM_PREVIOUS_STATE":                    0x0D68,
        "W_X2_COMMS_FSM_ILLEGAL_STATE":                     0x0D6C,
        "W_X2_COMMS_FSM_UNEXPECTED_EVENT":                  0x0D70,
        "W_X2_COMMS_FSM_UNEXPECTED_ACTION":                 0x0D74,
        "W_X2_COMMS_FSM_FAILED_TO_ADD_EVENT":               0x0D78,
        "W_X2_COMMS_REQUEST_ALREADY_IN_PROGRESS":           0x0D7C,
        "W_X2_COMMS_RESPONSE_SEQUENCE_TIMEOUT":             0x0D80,
        "W_INTERRUPT_SOURCE_I2C":                           0x0D84,
        "W_I2C_STATUS_HANDLER_COUNT":                       0x0D88,
        "W_I2C_MASTER_WRITE_TO_SLAVE_COUNT":                0x0D8C,
        "W_I2C_MASTER_READ_FROM_SLAVE_COUNT":               0x0D90,
        "W_INVALID_SENSOR_ID_RECEIVED":                     0x0D94,
        "W_INVALID_SENSOR_ID_FOR_PROFILE_0_31_RECEIVED":    0x0D98,
        "W_INVALID_SENSOR_ID_FOR_PROFILE_32_63_RECEIVED":   0x0D9C,
        "W_INVALID_SENSOR_ID_FOR_PROFILE_64_95_RECEIVED":   0x0DA0,
        "W_INVALID_SENSOR_ID_FOR_PROFILE_96_127_RECEIVED":  0x0DA4,
        "W_CSDR_EXPECTED_MSG_DIDNT_ARRIVE":                 0x0DA8,
        "W_CSDR_ERROR_IN_MESSAGE":                          0x0DAC,
        "W_SUC_TRANSPORT_TX_INVALID_STATE":                 0x0DB0,
        "W_SUC_TRANSPORT_RX_INVALID_START_BYTE" :           0x0DB4,
        "W_SUC_TRANSPORT_RX_FAILED_VALIDATION" :            0x0DB8,
        "W_SUC_TRANSPORT_RX_HEADER_CRC_FAILED" :            0x0DBC,
        "W_SUC_TRANSPORT_RX_PAYLOAD_CRC_FAILED" :           0x0DC0,
        "W_SUC_TRANSPORT_RX_INVALID_STATE" :                0x0DC4,
        "W_INVALID_SENSOR_SIZE" :                           0x0DC8,
        "W_STACK_FILL_PERCENTAGE" :                         0x0DCC,
        "W_SUC_BYTES_RX" :                                  0x0DD0,

        # 3rd RAM area (for clock throttling)
        "W_CT_MODE":                                        0x1C00,
        "W_CT_BOARDMEASUREDPOWER":                          0x1C04,
        "W_CT_USERNORMALIZEDPOWER":                         0x1C08,
        "W_CT_XRTSUPPLIEDBOARDTHROTTLINGTHRESHOLDPOWER":    0x1C0C,
        "W_CT_BOARDNORMALIZEDPOWER":                        0x1C10,
        "W_CT_KERNELPOWER":                                 0x1C14,
        "W_CT_KERNELTARGET":                                0x1C18,
        "W_CT_IDLEPOWER":                                   0x1C1C,
        "W_CT_ACTIVITY":                                    0x1C20,
        "W_CT_RATECURRENT":                                 0x1C24,
        "W_CT_RATELINEAR":                                  0x1C28,
        "W_CT_0_VOLTAGESENSORID":                           0x1C2C,
        "W_CT_0_CURRENTSENSORID":                           0x1C30,
        "W_CT_0_DUPLICATEREADINGCURRENT":                   0x1C34,
        "W_CT_0_LATESTREADINGCURRENT":                      0x1C38,
        "W_CT_0_LATESTREADINGVOLTAGE":                      0x1C3C,
        "W_CT_0_LATESTREADINGTHRESHCURRENT":                0x1C40,
        "W_CT_0_NOMINALVOLTAGE":                            0x1C44,
        "W_CT_0_MEASUREDPOWER":                             0x1C48,
        "W_CT_0_THROTTLEDTHRESHOLDPOWER":                   0x1C4C,
        "W_CT_0_CONTRIBUTESTOBOARDTHROTTLINGPOWER":         0x1C50,
        "W_CT_0_RAILNORMALIZEDPOWER":                       0x1C54,
        "W_CT_1_VOLTAGESENSORID":                           0x1C58,
        "W_CT_1_CURRENTSENSORID":                           0x1C5C,
        "W_CT_1_DUPLICATEREADINGCURRENT":                   0x1C60,
        "W_CT_1_LATESTREADINGCURRENT":                      0x1C64,
        "W_CT_1_LATESTREADINGVOLTAGE":                      0x1C68,
        "W_CT_1_LATESTREADINGTHRESHCURRENT":                0x1C6C,
        "W_CT_1_NOMINALVOLTAGE":                            0x1C70,
        "W_CT_1_MEASUREDPOWER":                             0x1C74,
        "W_CT_1_THROTTLEDTHRESHOLDPOWER":                   0x1C78,
        "W_CT_1_CONTRIBUTESTOBOARDTHROTTLINGPOWER":         0x1C7C,
        "W_CT_1_RAILNORMALIZEDPOWER":                       0x1C80,
        "W_CT_2_VOLTAGESENSORID":                           0x1C84,
        "W_CT_2_CURRENTSENSORID":                           0x1C88,
        "W_CT_2_DUPLICATEREADINGCURRENT":                   0x1C8C,
        "W_CT_2_LATESTREADINGCURRENT":                      0x1C90,
        "W_CT_2_LATESTREADINGVOLTAGE":                      0x1C94,
        "W_CT_2_LATESTREADINGTHRESHCURRENT":                0x1C98,
        "W_CT_2_NOMINALVOLTAGE":                            0x1C9C,
        "W_CT_2_MEASUREDPOWER":                             0x1CA0,
        "W_CT_2_THROTTLEDTHRESHOLDPOWER":                   0x1CA4,
        "W_CT_2_CONTRIBUTESTOBOARDTHROTTLINGPOWER":         0x1CA8,
        "W_CT_2_RAILNORMALIZEDPOWER":                       0x1CAC,
        "W_CT_FPGAMEASUREDTEMP":                            0x1CB0,
        "W_CT_FPGATHROTTLINGTEMPLIMIT":                     0x1CB4,
        "W_CT_BVCCINTTHERMALTHROTTLINGENABLED":             0x1CB8,
        "W_CT_VCCINTMEASUREDTEMP":                          0x1CBC,
        "W_CT_VCCINTTHROTTLINGTEMPLIMIT":                   0x1CC0,
        "W_CT_BUSERTHROTTLINGTEMPLIMITENABLED":             0x1CC4,
        "W_CT_XRTSUPPLIEDUSERTHROTTLINGTEMPLIMIT":          0x1CC8,
        "W_CT_THERMALTHROTTLINGTHRESHOLDPOWER":             0x1CCC,
        "W_CT_THERMALNORMALISEDPOWER":                      0x1CD0,
        "W_CT_VCCINTTHERMALNORMALISEDPOWER":                0x1CD4,
        "W_CT_THERMALTHROTTLINGLOOPJUSTENABLED":            0x1CD8,
        "W_CT_INTEGTAIONSUM":                               0x1CDC,
        "W_CT_TEMPGAINKPFPGA":                              0x1CE0,
        "W_CT_TEMPGAINKI":                                  0x1CE4,
        "W_CT_TEMPGAINKPVCCINT":                            0x1CE8,
        "W_CT_TEMPGAINKAW":                                 0x1CEC,

        "CMC_SC_MSG_COVERAGE_REG":                          0x0580,
        "CMC_SC_SNSR_COVERAGE_REG":                         0x09C0,


        # New Feature Support Area 
        "HOST_REGISTER_LOCATION_NEW_FEATURE_REGISTER_00" :  0x0B20,
        "HOST_REGISTER_LOCATION_NEW_FEATURE_REGISTER_01" :  0x0B24,
        "HOST_REGISTER_LOCATION_NEW_FEATURE_REGISTER_02" :  0x0B28,

        # Thresholds Area 
        "HOST_REGISTER_ALERT_RESP_WARNING_REG" :            0x0BA0,
        "HOST_REGISTER_ALERT_RESP_CRITICAL_REG" :           0x0BA4,
        "HOST_REGISTER_SNSR_STATE_BASE_REG" :               0x0BA8,
        
        #CLOCK THROTTLING DEBUG
        "HOST_REGISTER_CT_KP_FPGA" :                        0x0BEC,
        "HOST_REGISTER_CT_KI" :                             0x0BF0,
        "HOST_REGISTER_CT_KAW" :                            0x0BF4,
        "HOST_REGISTER_CT_KP_VCCINT" :                      0x0BF8,
        "HOST_REGISTER_CT_MUTEX" :                          0x0BFC,
        "HOST_REGISTER_CT_DEBUG" :                          0x0C00,
            
        "CMC_CORE_VERSION_REG":                             0x0C4C,
                
        # OEM ID
        "CMC_OEM_ID_REG":                                   0x0C50,
        
        # ECC & PCIe Error Counts
        "ECC_UE_ERROR_COUNT":                               0x0E50,
        "ECC_CE_ERROR_COUNT":                               0x0E54,
        "PCIE_SURPRISE_DOWN_ERROR_COUNT":                   0x0E58,
        "PCIE_UNSUPPORTED_REQUEST_COUNT":                   0x0E5C,
        "PCIE_RECEIVER_ERROR_COUNT":                        0x0E60,
        "PCIE_REPLAY_TIMER_TIMEOUT_COUNT":                  0x0E64,
        
        # hw build info                    
        "SHELL_TOOLS_VERSION":                              0x0EB8,
        "SHELL_BUILD_VERSION":                              0x0EBC,
        "SHELL_SS_PATCH_CORE_REVISION":                     0x0EC0,
        "SHELL_PERFORCE_CL":                                0x0EC4,
        "SHELL_RESERVED_TAG":                               0x0EC8,
        
        # coverage        
        "CMC_HOST_MSG_COVERAGE_REG":                        0x0EC8,
        "CMC_HOST_ERR_COVERAGE_REG":                        0x0EE0,
        
        # debug message buffer
        "CMC_DEBUG_BUFFER_REG":                             0x1900,

        # host message buffer
        "CMC_HOST_MSG_REG":                                 0x1000,
        "CMC_WHICH_QSFP_REG":                               0x1004,
        "CMC_WHICH_PAGE_REG":                               0x1008,
        "CMC_WHICH_UPPER_REG":                              0x100C,
        "CMC_WHICH_BYTE_OFFSET":                            0x1010,
        "CMC_WHICH_BYTE_VALUE":                             0x1014,
        "CMC_QSFP_CONTROL_BYTES_SIZE":                      0x1008,
        "CMC_QSFP_CONTROL_BYTES1":                          0x100C,
        "CMC_QSFP_CONTROL_BYTES2":                          0x1010,
        "CMC_QSFP_CONTROL_BYTES3":                          0x1014,
        "CMC_QSFP_CONTROL_BYTES4":                          0x1018,

        # message traces
        "CMC_SAT_MSG_TRACE_REG":                            0x1E00

    }

    cmc_power_modes = {
        0: "75W",
        1: "150W",
        2: "225W",
        3: "300W"
    }

    # sc: satellite controller
    sc_max_msg_size = 0x400

    sc_msg_codes = {
        0x00: "SAT_COMMS_NULL",
        0x01: "SAT_COMMS_EN_BSL",
        0x02: "SAT_COMMS_ALERT_REQ",
        0x03: "SAT_COMMS_VERS_REQ",
        0x04: "SAT_COMMS_SET_VERS",
        0x05: "SAT_COMMS_BOARD_INFO_REQ",
        0x06: "SAT_COMMS_VOLT_SNSR_REQ",
        0x07: "SAT_COMMS_POWER_SNSR_REQ",
        0x08: "SAT_COMMS_TEMP_SNSR_REQ",
        0x09: "SAT_COMMS_DEBUG_UART_EN",
        0x0A: "SAT_COMMS_FPGA_I2C_BUS_ARB",
        0x0B: "SAT_COMMS_CAGE_IO_EVENT",
        0x0C: "SAT_COMMS_QSFP_INFO",
        0x0D: "SAT_COMMS_SNSR_PUSH",
        0x0E: "SAT_COMMS_GET_MCTP_MSG",
        0x0F: "SAT_COMMS_SEND_MCTP_RESP",
        0x10: "SAT_COMMS_SEND_VDM_MSG",
        0x11: "SAT_COMMS_GET_VDM_RESP",
        0x12: "SAT_COMMS_FEATURE_REQ",
        0x13: "SAT_COMMS_SET_FEATURE",
        0x14: "SAT_COMMS_SNSR_STATE_REQ",
        0x15: "SAT_COMMS_SNSR_POLL_FREQ_REQ",
        0x16: "SAT_COMMS_SC_FW_SECTOR_INFO_REQ",
        0x17: "SAT_COMMS_SC_FW_SECTOR_INFO_RESP",
        0x18: "SAT_COMMS_SNSR_POWER_THROTTLING_THRESHOLDS_REQ",
        0x19: "SAT_COMMS_SNSR_POWER_THROTTLING_THRESHOLDS_RESP",
        0x20: "SAT_COMMS_SNSR_TEMP_THROTTLING_THRESHOLDS_REQ",
        0x21: "SAT_COMMS_SNSR_TEMP_THROTTLING_THRESHOLDS_RESP",
        0x22: "SAT_COMMS_CSDR_REQ",
        0x23: "SAT_COMMS_CSDR_RESP",
        0x26: "SAT_COMMS_ECC_ERROR_REPORT",
        0x27: "SAT_COMMS_PCIE_ERROR_REPORT",
        0x28: "SAT_COMMS_KEEPALIVE",
        0x29: "SAT_COMMS_READ_QSFP_DIAGNOSTICS_REQ",
        0x2A: "SAT_COMMS_READ_QSFP_DIAGNOSTICS_RESP",
#        0x2B: "SAT_COMMS_QSFP_WRITE_CONTROL_FUNCTION_BYTES_REQ",
        0x2C: "SAT_COMMS_QSFP_VALIDATE_LOW_SPEED_WRITE_IO_REQ",
        0x2D: "SAT_COMMS_QSFP_VALIDATE_LOW_SPEED_READ_IO_REQ",
        0x2E: "SAT_COMMS_QSFP_VALIDATE_LOW_SPEED_READ_IO_RESP",
        0x2F: "SAT_COMMS_QSPI_STATUS_REQ",
        0x30: "SAT_COMMS_QSPI_STATUS_RESP",
        0x31: "SAT_COMMS_QSFP_BYTE_WRITE_REQ",
        0x32: "SAT_COMMS_QSFP_BYTE_READ_REQ",
        0x33: "SAT_COMMS_QSFP_BYTE_READ_RESP",
        #
        0x42: "SAT_COMMS_BSL_SYNC",
        0x43: "SAT_COMMS_BSL_RESET",
        0x44: "SAT_COMMS_BSL_PW",
        0x45: "SAT_COMMS_BSL_BAUD",
        0x46: "SAT_COMMS_BSL_VERS",
        0x47: "SAT_COMMS_BSL_MASS_ERASE",
        0x48: "SAT_COMMS_BSL_RX_BLOCK_32",
        0x49: "SAT_COMMS_BSL_CRC_CHECK_32",
        0x4A: "SAT_COMMS_BSL_TX_BLOCK_32",
        0x4B: "SAT_COMMS_BSL_LOAD_PC_32",
        0x4C: "SAT_COMMS_BSL_ERASE_SECTOR_32",
        #
        0x51: "SAT_COMMS_SUC_OPEN_REQ",
        0x52: "SAT_COMMS_SUC_WRITE_REQ",
        0x55: "SAT_COMMS_SUC_CLOSE_REQ",
        0x58: "SAT_COMMS_SUC_REBOOT_REQ",
        #
        0x6F: "SAT_COMMS_SEND_OEM_CMD",
        #
        0x82: "SAT_COMMS_ALERT_RESP",
        0x83: "SAT_COMMS_VERS_RESP",
        0x85: "SAT_COMMS_BOARD_INFO_RESP",
        0x86: "SAT_COMMS_VOLT_SNSR_RESP",
        0x87: "SAT_COMMS_POWER_SNSR_RESP",
        0x88: "SAT_COMMS_TEMP_SNSR_RESP",
        0x89: "SAT_COMMS_DEBUG_UART_EN_RESP",
        0x8C: "SAT_COMMS_QSFP_INFO_RESP",
        #
        0x8E: "SAT_COMMS_GET_MCTP_MSG_RESP",
        0x90: "SAT_COMMS_SNSR_STATE_RESP",
        0x91: "SAT_COMMS_GET_VDM_RESP_RESP",
        0x92: "SAT_COMMS_FEATURE_RESP",
        0x93: "SAT_COMMS_SNSR_POLL_FREQ_RESP",
        #
        0xD1: "SAT_COMMS_SUC_OPEN_RESP", 
        #
        0xEF: "SAT_COMMS_SEND_OEM_CMD_RESP",
        #
        0xFE: "SAT_COMMS_MSG_GOOD",
        0xFF: "SAT_COMMS_MSG_ERR"
    }

    sc_bsl_msg_codes = {
        0x00: "BSL_RESP_SUCCESS",
        0x04: "BSL_RESP_LOCKED",
        0x05: "BSL_RESP_PW_ERR",
        0x07: "BSL_RESP_UNKNOWN_CMD",
        0x15: "BSL_MASS_ERASE_MESSAGE_ID",
        0x19: "BSL_VERS_MESSAGE_ID",
        0x20: "BSL_RX_BLOCK_32_MESSAGE_ID",
        0x21: "BSL_PW_MESSAGE_ID",
        0x25: "BSL_RST_MESSAGE_ID",
        0x26: "BSL_CRC_CHECK_32_MESSAGE_ID",
        0x27: "BSL_LOAD_PC_32_MESSAGE_ID",
        0x28: "BSL_TX_BLOCK_32_MESSAGE_ID",
        0x3A: "BSL_RESP_DATA_CMD",
        0x3B: "BSL_RESP_MESG_CMD",
        0x52: "BSL_BAUD_MESSAGE_ID"
    }

    sc_sensor_codes = {
        0x00: "SNSR_ID_12V_PEX",
        0x01: "SNSR_ID_3V3_PEX",
        0x02: "SNSR_ID_3V3_AUX",
        0x03: "SNSR_ID_12V_AUX0",
        0x04: "SNSR_ID_DDR4_VPP_BTM",
        0x05: "SNSR_ID_SYS_5V5",
        0x06: "SNSR_ID_VCC1V2_TOP",
        0x07: "SNSR_ID_VCC1V8",
        0x08: "SNSR_ID_VCC0V85",
        0x09: "SNSR_ID_DDR4_VPP_TOP",
        0x0A: "SNSR_ID_MGT0V9AVCC",
        0x0B: "SNSR_ID_12V_SW",
        0x0C: "SNSR_ID_MGTAVTT",
        0x0D: "SNSR_ID_VCC1V2_BTM",
        0x0E: "SNSR_ID_12VPEX_I_IN",
        0x0F: "SNSR_ID_12V_AUX_I_IN",
        0x10: "SNSR_ID_VCCINT",
        0x11: "SNSR_ID_VCCINT_I",
        0x12: "SNSR_ID_FPGA_TEMP",
        0x13: "SNSR_ID_FAN_TEMP",
        0x14: "SNSR_ID_DIMM_TEMP0",
        0x15: "SNSR_ID_DIMM_TEMP1",
        0x16: "SNSR_ID_DIMM_TEMP2",
        0x17: "SNSR_ID_DIMM_TEMP3",
        0x18: "SNSR_ID_SE98_TEMP0",
        0x19: "SNSR_ID_SE98_TEMP1",
        0x1A: "SNSR_ID_SE98_TEMP2",
        0x1B: "SNSR_ID_FAN_SPEED",
        0x1C: "SNSR_ID_CAGE_TEMP0",
        0x1D: "SNSR_ID_CAGE_TEMP1",
        0x1E: "SNSR_ID_CAGE_TEMP2",
        0x1F: "SNSR_ID_CAGE_TEMP3",
        0x21: "SNSR_ID_BOARD_SN",
        0x22: "SNSR_ID_MAC_ADDRESS0",
        0x23: "SNSR_ID_MAC_ADDRESS1",
        0x24: "SNSR_ID_MAC_ADDRESS2",
        0x25: "SNSR_ID_MAC_ADDRESS3",
        0x26: "SNSR_ID_BOARD_REV",
        0x27: "SNSR_ID_BOARD_NAME",
        0x28: "SNSR_ID_SAT_VERSION",
        0x29: "SNSR_ID_TOTAL_POWER_AVAIL",
        0x2A: "SNSR_ID_FAN_PRESENCE",
        0x2B: "SNSR_ID_CONFIG_MODE",
        0x2C: "SNSR_ID_MAC_ADDRESS4",
        0x2D: "SNSR_ID_MAC_ADDRESS5",
        0x2E: "SNSR_ID_MAC_ADDRESS6",
        0x2F: "SNSR_ID_MAC_ADDRESS7",
        0x30: "SNSR_ID_HBM_TEMP_1",
        0x31: "SNSR_ID_VCC3V3",
        0x32: "SNSR_ID_3V3PEX_I_IN",
        0x33: "SNSR_ID_VCC0V85_I",
        0x34: "SNSR_ID_HBM_1V2",
        0x35: "SNSR_ID_VPP2V5",
        0x36: "SNSR_ID_VCCINT_BRAM",
        0x37: "SNSR_ID_HBM_TEMP_2",
        0x38: "SNSR_ID_12V_AUX1",
        0x39: "SNSR_ID_VCCINT_TEMP",
        0x3A: "SNSR_ID_PEX_12V_POWER",
        0x3B: "SNSR_ID_PEX_3V3_POWER",
        0x3C: "SNSR_ID_AUX_3V3_POWER",
        0x3F: "SNSR_ID_VCC1V2_I",
        0x40: "SNSR_ID_V12_IN_I",
        0x41: "SNSR_ID_V12_IN_AUX0_I",
        0x42: "SNSR_ID_V12_IN_AUX1_I",
        0x43: "SNSR_ID_VCCAUX",
        0x44: "SNSR_ID_VCCAUX_PMC",
        0x45: "SNSR_ID_VCCRAM",
        0x46: "SNSR_ID_POWER_GOOD",
        0x47: "SNSR_ID_VCCINT_POWER",
        0x48: "SNSR_ID_VCCINT_VCU_0V9",
        0x4B: "SNSR_ID_NEW_MAC_SCHEME"

    };

    host_msg_codes = {
        1: "CMC_OP_MSP432_FW_SEC",
        2: "CMC_OP_MSP432_FW_DATA",
        3: "CMC_OP_MSP432_JUMP",
        4: "CMC_OP_BOARD_INFO_REQ",
        5: "CMC_OP_MSP432_FW_ERASE"
    }

    host_error_codes = {
        #0 : "CMC_HOST_MSG_NO_ERR",
        1 : "CMC_HOST_MSG_BAD_OPCODE_ERR",
        2 : "CMC_HOST_MSG_BRD_INFO_MISSING_ERR",
        3 : "CMC_HOST_MSG_LENGTH_ERR",
        4 : "CMC_HOST_MSG_SAT_FW_WRITE_FAIL",
        5 : "CMC_HOST_MSG_SAT_FW_UPDATE_FAIL",
        6 : "CMC_HOST_MSG_SAT_FW_LOAD_FAIL",
        7 : "CMC_HOST_MSG_SAT_FW_ERASE_FAIL"
    }

    heartbeat_error_codes = {
        0 : "NO_ERR",
        1 : "SINGLE_SENSOR_NOT_RECEIVED",
        2 : "MULTIPLE_SENSORS_NOT_RECEIVED"
    }

    power_codes = {
        0 : "75W",
        1 : "150W",
        2 : "225W",
        3 : "300W"
    }

    sc_modes = {
        0: "UNKNOWN",
        1: "NORMAL",
        2: "BSL_MODE_UNSYNCED",
        3: "BSL_MODE_SYNCED",
        4: "BSL_MODE_SYNCED_SC_NOT_UPGRADABLE",
        5: "NORMAL_MODE_SC_NOT_UPGRADABLE"
    }

    sc_err_codes = {
        0: "SAT_COMMS_OK",
        1: "SAT_COMMS_CHKSUM_ERR",
        2: "SAT_COMMS_EOP_ERR",
        3: "SAT_COMMS_SOP_ERR",
        4: "SAT_COMMS_ESQ_SEQ_ERR",
        5: "SAT_COMMS_BAD_MSG_ID",
        6: "SAT_COMMS_BAD_VERSION",
        7: "SAT_COMMS_BAD_CHAN_STATE"
    }

    eeprom_config_modes = {
        0 : "Slave_Serial_x1",
        1 : "Slave_Select_Map_x8",
        2 : "Slave_Select_Map_x16",
        3 : "Slave_Select_Map_x32",
        4 : "JTag_Boundary_Scan_x1",
        5 : "Master_SPI_x1",
        6 : "Master_SPI_x2",
        7 : "Master_SPI_x4",
        8 : "Master_SPI_x8",
        9 : "Master_BPI_x8",
       10 : "Master_BPI_x16",
       11 : "Master_Serial_x1",
       12 : "Master_Select_Map_x8",
       13 : "Master_Select_Map_x16",
       14 : "Reserved",
       15 : "Reserved"
    }

    link_state_states = {
        0: "S_INITIAL                                                  ",
        1: "S_DETERMINE_LINK_USER                                      ",
        2: "S_LINK_USER_IS_REMOTE_SENSOR_SUPERVISOR                    ",
        3: "S_LINK_USER_IS_REMOTE_BOOTLOADER                           ",
        4: "S_LINK_USER_IS_REMOTE_SENSOR_SUPERVISOR_LINK_OPERATING     ",
        5: "S_WAITING_FOR_REMOTE_BOOTLOADER_RESPONSE                   ",
        6: "S_LINK_USER_IS_REMOTE_SENSOR_SUPERVISOR_SUC                ",
        7: "S_MAX_STATES                                               "
    }

    link_state_events = {
        0x00: "NULL                                                     ",
        0x01: "E_LS_RESET_REQUEST                                       ",
        0x02: "E_LS_T_RESPONSE_EXPIRY                                   ",
        0x03: "E_LS_LINK_USER_IS_REMOTE_SENSOR_SUPERVISOR               ",
        0x04: "E_LS_LINK_USER_IS_REMOTE_BOOTLOADER                      ",
        0x05: "E_LS_LINK_USER_TO_BOOTLOADER_REQUEST                     ",
        0x06: "E_LS_LINK_OFFERED_VERSION_ACKNOWLEDGE                    ",
        0x07: "E_LS_LINK_OFFERED_VERSION_DECLINED                       ",
        0x08: "E_LS_LINK_ACCEPTED_PROTOCOL_VERSION_RANGE_RESPONSE       ",
        0x09: "E_LS_LINK_ACCEPTED_PROTOCOL_VERSION_RANGE_RESPONSE_FAILED",
        0x0A: "E_LS_T_BSL_EXPIRY                                        ",
        0x0B: "E_LS_ENABLE_BSL_RESPONSE                                 ",
        0x0C: "E_LS_ENABLE_BSL_RESPONSE_FAILED                          ",
        0x0D: "E_LS_LINK_I2C_ACKNOWLEDGE                                ",
        0x0E: "E_LS_LINK_I2C_FAILED                                     "
    };

    host_proxy_states = {
        0: "S_HP_INITIAL                                                ",
        1: "S_HP_WAITING_FOR_BOOTLOADER                                 ",
        2: "S_HP_BOOTLOADER                                             ",
        3: "S_HP_TRANSACTION_RUNNING                                    ",
        4: "S_HP_MAX_STATES                                             "
    }                                                                   

    host_proxy_events = {                                               
        0x00: "NULL                                                     ",
        0x01: "E_HP_LOCAL_OPERATION_REQUEST                             ",
        0x02: "E_HP_REMOTE_OPERATION_REQUEST                            ",
        0x03: "E_HP_REMOTE_OPERATION_FAILED                             ",
        0x04: "E_HP_TRANSACTION_TIMER_EXPIRY                            ",
        0x05: "E_HP_REMOTE_OPERATION_SUCCESS                            ",
        0x06: "E_HP_LINK_USER_IS_BOOTLOADER                             ",
        0x07: "E_HP_LINK_USER_IS_SENSOR_SUPERVISOR                      ",
        0x08: "E_HP_REQUESTED_LINK_USER_AS_BOOTLOADER                   ",
        0x09: "E_HP_LINK_USER_IS_SENSOR_SUPERVISOR_SUC                  "
    };

    bootloader_states = {                                               
        0: "S_LB_INITIAL                                                ",
        1: "S_LB_AWAITING_COMMAND                                       ",
        2: "S_LB_AWAITING_PASSWORD_RESPONSE                             ",
        3: "S_LB_AWAITING_ERASE_RESPONSE                                ",
        4: "S_LB_AWAITING_FRAME_RESPONSE                                ",
        5: "S_LB_AWAITING_CHECKSUM_RESPONSE                             ",
        6: "S_LB_AWAITING_UPDATE_RESPONSE                               ",
        7: "S_LB_WAITING_FOR_FIRMWARE_RESTART                           ",
        8: "S_LB_WAITING_FOR_LINK_USER_CONFIRMATION                     ",
        9: "S_LB_BOOTLOAD_SEQUENCE_FAIL                                 ",
       10: "S_LB_AWAITING_FINAL_FRAME_DECISION                          ",
       11: "S_LB_AWAITING_SUC_OPEN_RESPONSE                             ",
       12: "S_LB_AWAITING_SUC_WRITE_RESPONSE                            ",
       13: "S_LB_AWAITING_SUC_FINAL_FRAME_DECISION                      ",
       14: "S_LB_AWAITING_SUC_CLOSE_RESPONSE                            ",
       15: "S_LB_AWAITING_SUC_REBOOT_RESPONSE                           ",
       16: "S_LB_MAX_STATES                                             "
    }                                                                   

    bootloader_events = {                                               
        0x00: "NULL                                                     ",
        0x01: "E_LB_ACTIVATE_BOOTLOADER                                 ",
        0x02: "E_LB_RESET_BOOTLOADER                                    ",
        0x03: "E_LB_COMMAND_ERASE_FIRMWARE_SEQUENCE                     ",
        0x04: "E_LB_COMMAND_RESTART_FIRMWARE                            ",
        0x05: "E_LB_COMMAND_UPDATE_FIRMWARE                             ",
        0x06: "E_LB_T_RESPONSE_TIMEOUT                                  ",
        0x07: "E_LB_T_RESTART_DELAY_TIMEOUT                             ",
        0x08: "E_LB_REMOTE_ACK                                          ",
        0x09: "E_LB_REMOTE_NAK                                          ",
        0x0A: "E_LB_LINK_USER_IS_BOOTLOADER                             ",
        0x0B: "E_LB_LINK_USER_IS_SENSOR_SUPERVISOR                      ",
        0x0C: "E_LB_REMOTE_ACK_FRAMES_REMAINING                         ",
        0x0D: "E_LB_REMOTE_ACK_NO_FRAMES_REMAINING                      ",
        0x0E: "E_LB_LINK_USER_IS_SENSOR_SUPERVISOR_SUC                  ",
        0x0F: "E_LB_SUC_OPEN_RESPONSE                                   ",
        0x10: "E_LB_SUC_OPEN_RESPONSE_FAILED                            ",
        0X11: "E_LB_SUC_WRITE_RESPONSE                                  ",
        0x12: "E_LB_SUC_WRITE_RESPONSE_FAILED                           ",
        0x13: "E_LB_SUC_CLOSE_RESPONSE                                  ",
        0x14: "E_LB_SUC_CLOSE_RESPONSE_FAILED                           ",
        0x15: "E_LB_SUC_REBOOT_RESPONSE_FAILED                          ",
        0x16: "E_LB_SUC_WRITE_FRAMES_REMAINING                          ",
        0x17: "E_LB_SUC_WRITE_NO_FRAMES_REMAINING                       "
    };

    sensor_supervisor_states = {                                        
        0: "S_SS_INITIAL                                                ",
        1: "S_SS_FETCHING_BOARD_INFORMATION                             ",
        2: "S_SS_FETCHING_SENSOR_VOLTAGE                                ",
        3: "S_SS_FETCHING_SENSOR_POWER                                  ",
        4: "S_SS_FETCHING_SENSOR_TEMPERATURE                            ",
        5: "S_SS_FETCHING_POWER_THROTTLING_THRESHOLDS                   ",
        6: "S_SS_FETCHING_TEMP_THROTTLING_THRESHOLDS                    ",
        7: "S_SS_RELAYING_HBM                                           ",
        8: "S_SS_RELAYING_CAGE_INFORMATION                              ",
        9: "S_SS_RELAYING_CAGE_INFORMATION_COMPLETE                     ",
       10: "S_SS_AWAITING_ALERT_RESPONSE                                ",
       11: "S_SS_AWAITING_SENSOR_STATE_RESPONSE                         ",
       12: "S_SS_FETCHING_OEM                                           ",
       13: "S_SS_DEBUG_UART_ENABLE                                      ",
       14: "S_SS_RELAY_PCIE                                             ",
       15: "S_SS_RELAY_ECC                                              ",
       16: "S_SS_KEEPALIVE                                              ",
       17: "S_SS_COLLECT_CSDR                                           ",
       18: "S_SS_QSFP_REQUEST                                           ",
	   19: "S_SS_QSPI_STATUS_REQUEST                                    ",
       20: "S_SS_MAX_STATES                                             "
    }

    sensor_supervisor_events = {
        0x00: "NULL                                                     ",
        0x01: "E_SS_T_SENSOR_EXPIRY                                     ",
        0x02: "E_SS_LINK_IS_AVAILABLE                                   ",
        0x03: "E_SS_LINK_IS_UNAVAILABLE                                 ",
        0x04: "E_SS_RELAYING_CAGE_INFORMATION_DONE                      ",
        0x05: "E_SS_GPIO_INTERRUPT_ARRIVAL                              ",
        0x06: "E_SS_MESSAGE_ARRIVAL                                     ",
        0x07: "E_SS_T_ENABLE_UART_NOT_REQUIRED                          ",
        0x08: "E_SS_DEBUG_UART_RESPONSE_ARRIVAL                         "
    };




    watchpoints = [
        "W_LINK_STATE_LAST_EVENT",                  
        "W_LINK_STATE_CURRENT",                 
        "W_LINK_STATE_PREVIOUS",                
        "W_LINK_STATE_FSM_ILLEGAL_STATE",           
        "W_LINK_STATE_UNEXPECTED_EVENT",            
        "W_LINK_STATE_UNEXPECTED_ACTION",           
        "W_LINK_STATE_FSM_FAILED_TO_ADD_EVENT",         
        "W_BOOTLOADER_LAST_EVENT",                  
        "W_BOOTLOADER_CURRENT",                 
        "W_BOOTLOADER_PREVIOUS",                
        "W_BOOTLOADER_FSM_ILLEGAL_STATE",           
        "W_BOOTLOADER_UNEXPECTED_EVENT",            
        "W_BOOTLOADER_UNEXPECTED_ACTION",           
        "W_BOOTLOADER_FSM_FAILED_TO_ADD_EVENT",         
        "W_THREAD_LOOP_ACTIVITY",                   
        "W_THREAD_TIMER",                       
        "W_THREAD_WATCHDOG",                    
        "W_THREAD_HOST_USER_PROXY",                 
        "W_THREAD_LOCAL_BOOTLOADER",                
        "W_THREAD_LOCAL_LINK_SUPERVISOR",           
        "W_THREAD_LOCAL_SENSOR_SUPERVISOR",         
        "W_THREAD_LINK_RECEIVE",                
        "W_THREAD_LINK_PROTOCOL_LOGGER",            
        "W_THREAD_MUTEX_OBSERVER",       
        "W_THREAD_X2_COMMS",             
        "W_SENSOR_SUPERVISOR_LAST_EVENT",  
        "W_SENSOR_SUPERVISOR_CURRENT",   
        "W_SENSOR_SUPERVISOR_PREVIOUS",                                 
        "W_SENSOR_SUPERVISOR_FSM_ILLEGAL_STATE",         
        "W_SENSOR_SUPERVISOR_UNEXPECTED_EVENT",          
        "W_SENSOR_SUPERVISOR_UNEXPECTED_ACTION",         
        "W_SENSOR_SUPERVISOR_FSM_FAILED_TO_ADD_EVENT",   
        "W_SENSOR_SUPERVISOR_MESSAGE_VERSION_UNSUPPORTED",
        "W_HOST_PROXY_LAST_EVENT",                  
        "W_HOST_PROXY_CURRENT",                  
        "W_HOST_PROXY_PREVIOUS",                 
        "W_HOST_PROXY_FSM_ILLEGAL_STATE",            
        "W_HOST_PROXY_UNEXPECTED_EVENT",             
        "W_HOST_PROXY_UNEXPECTED_ACTION",            
        "W_HOST_PROXY_FSM_FAILED_TO_ADD_EVENT",          
        "W_HOST_PROXY_UNRECOGNISED_REMOTE_COMMAND",      
        "W_HOST_PROXY_UNEXPECTED_LOCAL_ACTION",          
        "W_HOST_PROXY_UNEXPECTED_REMOTE_ACTION",         
        "W_LINK_RECEIVE_NO_ROOM_FOR_OCTET",          
        "W_INTERRUPT_ENTER",                     
        "W_INTERRUPT_EXIT",                      
        "W_INTERRUPT_SOURCE_UART_LITE_SATELLITE",        
        "W_INTERRUPT_SOURCE_CAGE_IO",                
        "W_INTERRUPT_SOURCE_WDT",                
        "W_INTERRUPT_SOURCE_GPIO_SATELLITE",         
        "W_HEARTBEAT_SINGLE_SNSR_ERR_CNT",         
        "W_INTERRUPT_IGNORED_SOURCES",               
        "W_SENSOR_RELAY_TRY_ADD_FAIL",               
        "W_SENSOR_RELAY_TRY_REMOVE_FAIL",            
        "W_SENSOR_ERROR_COUNT_REG",                  
        "W_BOARDINFO_SIZE_ERROR_COUNT_REG",          
        "W_LINK_RECEIVE_GOOD_MSG_UNHANDLED_MSG_ID",      
        "W_LINK_RECEIVE_ERR_MSG_UNHANDLED_MSG_ID",       
        "W_LINK_RECEIVE_MSG_RECEIVED_UNKNOWN_MSG_ID",    
        "W_LINK_RECEIVE_NEGOTIATED_VERSION",         
        "W_HBM_SUPPORTED",
        "W_HBM_PAYLOAD",
        "W_HEARTBEAT_MULTIPLE_SNSR_ERR_CNT",
        "W_SCHEDULER_ENTER",                     
        "W_SCHEDULER_EXIT",                      
        "W_HOST_REGISTER_RANGE_VIOLATION",           
        "W_RUNTIME_THREAD_LOOP_ACTIVITY",            
        "W_RUNTIME_THREAD_TIMER",                
        "W_RUNTIME_THREAD_WATCHDOG",                 
        "W_RUNTIME_THREAD_HOST_USER_PROXY",          
        "W_RUNTIME_THREAD_LOCAL_BOOTLOADER",         
        "W_RUNTIME_THREAD_LOCAL_LINK_SUPERVISOR",        
        "W_RUNTIME_THREAD_LOCAL_SENSOR_SUPERVISOR",      
        "W_RUNTIME_THREAD_LINK_RECEIVE",             
        "W_RUNTIME_THREAD_LINK_PROTOCOL_LOGGER",         
        "W_RUNTIME_THREAD_MUTEX_OBSERVER",           
        "W_RUNTIME_THREAD_X2_COMMS",                             
        "W_MAX_RUNTIME_THREAD_LOOP_ACTIVITY",        
        "W_MAX_RUNTIME_THREAD_TIMER",                
        "W_MAX_RUNTIME_THREAD_WATCHDOG",             
        "W_MAX_RUNTIME_THREAD_HOST_USER_PROXY",          
        "W_MAX_RUNTIME_THREAD_LOCAL_BOOTLOADER",         
        "W_MAX_RUNTIME_THREAD_LOCAL_LINK_SUPERVISOR",    
        "W_MAX_RUNTIME_THREAD_LOCAL_SENSOR_SUPERVISOR",  
        "W_MAX_RUNTIME_THREAD_LINK_RECEIVE",         
        "W_MAX_RUNTIME_THREAD_LINK_PROTOCOL_LOGGER",     
        "W_MAX_RUNTIME_THREAD_MUTEX_OBSERVER",           
        "W_MAX_RUNTIME_THREAD_X2_COMMS",                          
        "W_ARBITRARY_TIME_DIFFERENCE_CURRENT",           
        "W_ARBITRARY_TIME_DIFFERENCE_MAX",           
        "W_SENSOR_SUPERVISOR_LATE_MESSAGE_ARRIVAL",      
        "W_SENSOR_SUPERVISOR_MESSAGE_DIDNT_ARRIVE",      
        "W_LINK_RECEIVE_DEBUG_CAPTURE_POSITION",      
        "W_MUTEX_REACHOUT_GRANTED",
        "W_MUTEX_ACCESSING_REACHOUT_INTERFACE",    
        "W_X2_COMMS_FSM_LAST_EVENT",           
        "W_X2_COMMS_FSM_CURRENT_STATE",        
        "W_X2_COMMS_FSM_PREVIOUS_STATE",       
        "W_X2_COMMS_FSM_ILLEGAL_STATE",        
        "W_X2_COMMS_FSM_UNEXPECTED_EVENT",     
        "W_X2_COMMS_FSM_UNEXPECTED_ACTION",    
        "W_X2_COMMS_FSM_FAILED_TO_ADD_EVENT",  
        "W_X2_COMMS_REQUEST_ALREADY_IN_PROGRESS",
        "W_X2_COMMS_RESPONSE_SEQUENCE_TIMEOUT",       
        "W_INTERRUPT_SOURCE_I2C",
        "W_I2C_STATUS_HANDLER_COUNT",
        "W_I2C_MASTER_WRITE_TO_SLAVE_COUNT",    
        "W_I2C_MASTER_READ_FROM_SLAVE_COUNT",
        "W_INVALID_SENSOR_ID_RECEIVED",
        "W_INVALID_SENSOR_ID_FOR_PROFILE_0_31_RECEIVED",
        "W_INVALID_SENSOR_ID_FOR_PROFILE_32_63_RECEIVED",
        "W_INVALID_SENSOR_ID_FOR_PROFILE_64_95_RECEIVED",
        "W_INVALID_SENSOR_ID_FOR_PROFILE_96_127_RECEIVED",
        "W_CSDR_EXPECTED_MSG_DIDNT_ARRIVE",
        "W_CSDR_ERROR_IN_MESSAGE",
        "W_SUC_TRANSPORT_TX_INVALID_STATE",
        "W_SUC_TRANSPORT_RX_INVALID_START_BYTE",
        "W_SUC_TRANSPORT_RX_FAILED_VALIDATION",
        "W_SUC_TRANSPORT_RX_HEADER_CRC_FAILED",
        "W_SUC_TRANSPORT_RX_PAYLOAD_CRC_FAILED",
        "W_SUC_TRANSPORT_RX_INVALID_STATE",
        "W_INVALID_SENSOR_SIZE",
        "W_STACK_FILL_PERCENTAGE",
        "W_SUC_BYTES_RX",

        "W_CT_MODE",        
        "W_CT_BOARDMEASUREDPOWER",                   
        "W_CT_USERNORMALIZEDPOWER",                  
        "W_CT_XRTSUPPLIEDBOARDTHROTTLINGTHRESHOLDPOWER", 
        "W_CT_BOARDNORMALIZEDPOWER",                 
        "W_CT_KERNELPOWER",                      
        "W_CT_KERNELTARGET",                     
        "W_CT_IDLEPOWER",                        
        "W_CT_ACTIVITY",                         
        "W_CT_RATECURRENT",                      
        "W_CT_RATELINEAR",                      
        "W_CT_0_VOLTAGESENSORID",                
        "W_CT_0_CURRENTSENSORID",                
        "W_CT_0_DUPLICATEREADINGCURRENT",             
        "W_CT_0_LATESTREADINGCURRENT",                         
        "W_CT_0_LATESTREADINGVOLTAGE",                     
        "W_CT_0_LATESTREADINGTHRESHCURRENT",        
        "W_CT_0_NOMINALVOLTAGE",                 
        "W_CT_0_MEASUREDPOWER",                  
        "W_CT_0_THROTTLEDTHRESHOLDPOWER",            
        "W_CT_0_CONTRIBUTESTOBOARDTHROTTLINGPOWER",     
        "W_CT_0_RAILNORMALIZEDPOWER",                
        "W_CT_1_VOLTAGESENSORID",                
        "W_CT_1_CURRENTSENSORID",                
        "W_CT_1_DUPLICATEREADINGCURRENT",             
        "W_CT_1_LATESTREADINGCURRENT",                           
        "W_CT_1_LATESTREADINGVOLTAGE",                 
        "W_CT_1_LATESTREADINGTHRESHCURRENT",        
        "W_CT_1_NOMINALVOLTAGE",                 
        "W_CT_1_MEASUREDPOWER",                  
        "W_CT_1_THROTTLEDTHRESHOLDPOWER",            
        "W_CT_1_CONTRIBUTESTOBOARDTHROTTLINGPOWER",     
        "W_CT_1_RAILNORMALIZEDPOWER",       
        "W_CT_2_VOLTAGESENSORID",                
        "W_CT_2_CURRENTSENSORID",                
        "W_CT_2_DUPLICATEREADINGCURRENT",             
        "W_CT_2_LATESTREADINGCURRENT",                        
        "W_CT_2_LATESTREADINGVOLTAGE",                    
        "W_CT_2_LATESTREADINGTHRESHCURRENT",        
        "W_CT_2_NOMINALVOLTAGE",                 
        "W_CT_2_MEASUREDPOWER",                  
        "W_CT_2_THROTTLEDTHRESHOLDPOWER",            
        "W_CT_2_CONTRIBUTESTOBOARDTHROTTLINGPOWER",
        "W_CT_2_RAILNORMALIZEDPOWER",    
        "W_CT_FPGAMEASUREDTEMP",                  
        "W_CT_FPGATHROTTLINGTEMPLIMIT",           
        "W_CT_BVCCINTTHERMALTHROTTLINGENABLED",   
        "W_CT_VCCINTMEASUREDTEMP",                
        "W_CT_VCCINTTHROTTLINGTEMPLIMIT",         
        "W_CT_BUSERTHROTTLINGTEMPLIMITENABLED",   
        "W_CT_XRTSUPPLIEDUSERTHROTTLINGTEMPLIMIT",
        "W_CT_THERMALTHROTTLINGTHRESHOLDPOWER",
        "W_CT_THERMALNORMALISEDPOWER",
        "W_CT_VCCINTTHERMALNORMALISEDPOWER",
        "W_CT_THERMALTHROTTLINGLOOPJUSTENABLED",
        "W_CT_INTEGTAIONSUM",
        "W_CT_TEMPGAINKPFPGA",
        "W_CT_TEMPGAINKI",
        "W_CT_TEMPGAINKPVCCINT",
        "W_CT_TEMPGAINKAW"
    ]

    def __init__(self, card_bus):
        """Constructor for xbcmc Utilities"""
        if getpass.getuser() == 'bbrobot':
            print('bbrobot is running the script. Switch I/O access to \'devmem2\'')
            self.root_access = False
        self.bars = self.mount_bar(card_bus)

    def sysfs_read(self,path):
        try:
            with open(path) as fd:
                for line in fd:
                    sysfs_data = line.rstrip("\n\r")
        except IOError:
            print ("PCI bus number input does not correspond to an installed device")
            raise SystemExit(1)
        return sysfs_data

    def mount_bar(self, card_bus):
        vendor_id = self.sysfs_read('/sys/bus/pci/devices/0000:' + card_bus + ':00.0/vendor')
        device_id = self.sysfs_read('/sys/bus/pci/devices/0000:' + card_bus + ':00.0/device')
        subsystem_device = self.sysfs_read('/sys/bus/pci/devices/0000:' + card_bus + ':00.0/subsystem_device')

        if vendor_id == '0x10ee' and (subsystem_device == '0x000e' or subsystem_device == '0x1351' or subsystem_device == '0x0007'): # 0x1351 for U.2 0x0007 CMS
            if device_id in self.PCIe_IDs_dict:
                self.cmc_base_addr = self.PCIe_IDs_dict[device_id][1]
                self.cmc_regmap_offset = self.PCIe_IDs_dict[device_id][2]
                self.cmc_lmb_offset = self.PCIe_IDs_dict[device_id][3]
                self.cmc_lmb_bytes = self.PCIe_IDs_dict[device_id][4]
                self.cmc_gpio["MB_CTRL"] = self.PCIe_IDs_dict[device_id][5]
                self.cmc_phys_fun = self.PCIe_IDs_dict[device_id][6]
                print("pyxbcmc: "+self.PCIe_IDs_dict[device_id][0]+" on PCI bus 0000:" + card_bus + ":00."+self.cmc_phys_fun+" found")
            else:
                print("PCI bus number input does not correspond to a supported Xilinx device")
                raise SystemExit(1)
        else:
            print("PCI bus number input does not correspond to a Xilinx device")
            raise SystemExit(1)

        ## Check for magic number
        magic_reg_val = self.cmc_reg_read(card_bus, "CMC_MAGIC_REG")
        if magic_reg_val != self.cmc_magic_val:
            print("Magic value mismatch on 0000:" + card_bus + ":00."+self.cmc_phys_fun+" Read: 0x%X" % magic_reg_val)
            print("Exiting...")
            raise SystemExit(1)

    def cmc_gpio_read(self, card_bus, gpio_name):
        """Read CMC GPIO, return result"""
        gpio_address = self.cmc_base_addr + self.cmc_gpio[gpio_name]
        if self.root_access == True:
            try:
                with open("/sys/bus/pci/devices/0000:" + card_bus +":00."+self.cmc_phys_fun+"/resource0", "rb") as m:
                    cmc_mm = mmap(m.fileno(), 0x4, offset=gpio_address, access=ACCESS_READ)

                    # extract gpio value
                    value = unpack("<L", cmc_mm[0:4])[0]

                    # release
                    cmc_mm.close()
            except IOError:
                print("Error: Unable to map to device memory, sudo permission required")
                return -1

        else:
            bar_address = self.cmc_get_bar_address(card_bus)
            gpio_address = gpio_address + bar_address
            value = self.cmc_devmem2_read(gpio_address)            

        return value

    def cmc_gpio_write(self, card_bus, gpio_name, value, mask=0xffffffff):
        """Write value to CMC GPIO"""
        gpio_address = self.cmc_base_addr + self.cmc_gpio[gpio_name]
        if self.root_access == True:
            try:
                 with open("/sys/bus/pci/devices/0000:" + card_bus +":00."+self.cmc_phys_fun+"/resource0", "r+b" ) as m:
                    cmc_mm = mmap(m.fileno(), 0x4, offset=gpio_address,  access=ACCESS_WRITE)

                    # update gpio value
                    readback = unpack("<L", cmc_mm[0:4])[0]
                    value_masked = (readback & ~mask) | (value & mask)
                    cmc_mm[0:4] = pack("<L", value_masked)

                    # release
                    cmc_mm.close()
            except IOError:
                print("Error: Unable to map to device memory, sudo permission required")
                return -1

        else:
            bar_address = self.cmc_get_bar_address(card_bus)
            gpio_address = gpio_address + bar_address
            self.cmc_devmem2_write(gpio_address, value, mask)
        return

    def cmc_get_bar_address(self, card_bus):
        
        resource_output = os.popen('cat /sys/bus/pci/devices/0000:' + card_bus + ':00.'+self.cmc_phys_fun+'/resource').read()
        bar_address = resource_output.split()[0]
        return int(bar_address, 16)

    def cmc_devmem2_read(self, offset):

        devmem_output = os.popen('/tools/xgs/bin/sudo devmem2 ' + str(offset)).read()
        devmem_output_split = devmem_output.split(': ')
        value = devmem_output_split[1].rstrip()
        return int(value, 16)

    def cmc_devmem2_write(self, offset, value, mask=0xffffffff):

        readback = self.cmc_devmem2_read(offset)
        value_masked = (readback & ~mask) | (value & mask)
        devmem_output = os.popen('/tools/xgs/bin/sudo devmem2 ' + str(offset) + ' w ' + str(value_masked)).read()

    def cmc_reg_read(self, card_bus, regname):
        """Read CMC register (string key), return result"""
        cmc_mm_offset = self.cmc_base_addr + self.cmc_regmap_offset
        try:
            reg_address = self.cmc_regmap[regname]
        except KeyError:
            print("Error: Unknown register name %s" % regname)
            return -1

        if self.root_access == True:
            try:
                with open("/sys/bus/pci/devices/0000:" + card_bus +":00."+self.cmc_phys_fun+"/resource0", "rb") as f:
                    # map the full cmc register map to ensure alignment on page boundary
                    cmc_mm = mmap(f.fileno(), self.cmc_regmap_bytes, offset=cmc_mm_offset, access=ACCESS_READ)

                    # extract register value
                    value = unpack("<L", cmc_mm[reg_address:reg_address+4])[0]

                    # release
                    cmc_mm.close()
            except IOError:
                print("Error: Unable to map to device memory, sudo permission required")
                return -1

        else:
            bar_address = self.cmc_get_bar_address(card_bus)
            cmc_mm_offset = cmc_mm_offset + bar_address
            value = self.cmc_devmem2_read(cmc_mm_offset + reg_address)
        return value

    def cmc_reg_read_dict(self, card_bus):
        cmc_regval = {}
        cmc_mm_offset = self.cmc_base_addr + self.cmc_regmap_offset

        if self.root_access == True:
            try:
                with open("/sys/bus/pci/devices/0000:" + card_bus +":00."+self.cmc_phys_fun+"/resource0", "rb") as f:
                    # map the full cmc register map to ensure alignment on page boundary
                    cmc_mm = mmap(f.fileno(), self.cmc_regmap_bytes, offset=cmc_mm_offset, access=ACCESS_READ)

                    # iterate through register keys, add values to return dictionary
                    for reg in self.cmc_regmap:
                        reg_address = self.cmc_regmap[reg]
                        cmc_regval[reg] = unpack("<L", cmc_mm[reg_address:reg_address+4])[0]

                    # release
                    cmc_mm.close()
            except IOError:
                print("Error: Unable to map to device memory, sudo permission required")
                return -1

        else:
            bar_address = self.cmc_get_bar_address(card_bus)
            cmc_mm_offset = cmc_mm_offset + bar_address
            # iterate through register keys, add values to return dictionary
            for reg in self.cmc_regmap:
                reg_address = self.cmc_regmap[reg]
                cmc_regval[reg] = self.cmc_devmem2_read(cmc_mm_offset + reg_address)

        return cmc_regval

    def cmc_reg_decode(self, card_bus, regname):
        """Decode register into individual fields, return result (dict)"""
        reg_value = self.cmc_reg_read(card_bus, regname)

        reg_fields = {}
        try:
            if (reg_value >= 0):
                if ("CMC_VERSION_REG" == regname):
                    # raw value, no decode required
                    reg_fields["cmc_version"] = hex(reg_value)
                elif ("CMC_STATUS_REG" == regname):
                    # multiple bit fields
                    reg_fields["sc_mode"] = self.sc_modes[(reg_value & (0b1111<<28))>>28] # 31:28
                    reg_fields["comms_version"] = (reg_value & (0b1111<<24))>>24 # 27:24
                    reg_fields["cmc_power"] = self.cmc_power_modes[(reg_value & (0b11<<10))>>10] # 11:10
                    # single bit fields
                    reg_fields["wdt_reset"] = bool(reg_value & (0b1<<3))
                    reg_fields["cmc_stopped"] = bool(reg_value & (0b1<<1))
                    reg_fields["cmc_init_done"] = bool(reg_value & 0b1)
                elif ("CMC_STATUS2_REG" == regname):
                    # single bit fields
                    reg_fields["cmc_snsr_data_available"] = bool(reg_value & 0b1)
                elif ("CMC_HEARTBEAT_REG" == regname):
                    # raw value, no decode required
                    reg_fields["cmc_heartbeat"] = hex(reg_value)
                elif ("CMC_HEARTBEAT_ERR_CODE_REG" == regname):
                    # multiple bit fields
                    if (0 == reg_value):
                        reg_fields["last_sensor_not_received"] = "NONE"
                    else:
                        reg_fields["last_sensor_not_received"] = self.sc_sensor_codes[(reg_value & (0b11111111<<16))>>16] # 23:16
                    reg_fields["no_of_sensors_not_received"] = (reg_value & (0b11111111<<24))>>24 # 31:24
                    reg_fields["heartbeat_err_code"] = self.heartbeat_error_codes[(reg_value & (0b1111111111111111<<0))>>0] # 15:0
                elif ("CMC_ERROR_REG" == regname):
                    # single bit fields
                    reg_fields["sc"] = bool(reg_value & (0b1<<27))
                    reg_fields["packet"] = bool(reg_value & (0b1<<26))
                    # multiple bit fields
                    reg_fields["sc_err_code"] = self.sc_err_codes[(reg_value & (0b111111<<20))>>28] # 25:20
                elif ("CMC_CORE_VERSION_REG" == regname):
                    # single bit fields
                    reg_fields["core_version"] = hex(reg_value)
                elif ("CMC_PROFILE_NAME_REG" == regname):
                    # raw value, no decode required
                    name_ascii = ''
                    y1 = chr((reg_value >> 24) & 0xFF)
                    y2 = chr((reg_value >> 16) & 0xFF)
                    y3 = chr((reg_value >> 8) & 0xFF)
                    y4 = chr(reg_value & 0xFF)
                    name_ascii = y1 + y2 + y3 + y4
                    reg_fields["profile"] = name_ascii
                elif ("CMC_CONTROL_REG" == regname):
                    # single bit fields
                    reg_fields["sat_debug_uart"] = bool(reg_value & (0b1<<31))
                    reg_fields["debug_packet_capture"] = bool(reg_value & (0b1<<30))
                    reg_fields["clk_scaling_enabled (CMS)"] = bool(reg_value & (0b1<<28))
                    reg_fields["hbm_support_enabled (CMS)"] = bool(reg_value & (0b1<<27))
                    reg_fields["debug_packet_capture_msg_id"] = hex((reg_value & (0b11111111<<8))>>8) # 15:8
                    reg_fields["reboot"] = bool(reg_value & (0b1<<6))
                    reg_fields["host_proc"] = bool(reg_value & (0b1<<5))
                    reg_fields["stop"] = bool(reg_value & (0b1<<3))
                    reg_fields["reset_error"] = bool(reg_value & (0b1<<1))
                    reg_fields["reset_sensor"] = bool(reg_value & 0b1)
                elif ("CMC_STOP_CONFIRM_REG" == regname):
                    # single bit fields
                    reg_fields["stop_confirm"] = bool(reg_value & 0b1)
                elif ("CMC_HOST_MSG_OFFSET_REG" == regname):
                    # raw value, no decode required
                    reg_fields["host_msg_offset"] = reg_value
                elif ("CMC_HOST_MSG_ERROR_REG" == regname):
                    # multiple bit fields
                    if (0 == reg_value):
                        reg_fields["host_msg_error"] = "HOST_MSG_NO_ERR"
                    else:
                        reg_fields["host_msg_error"] = self.host_error_codes[reg_value]
                elif ("CMC_HOST_STATUS_REG" == regname):
                    # raw value, no decode required
                    reg_fields["host_status"] = hex(reg_value)
                elif ("SHELL_TOOLS_VERSION" == regname):
                    # raw value, no decode required
                    reg_fields["shell_tools"] = hex(reg_value)
                elif ("SHELL_BUILD_VERSION" == regname):
                    # raw value, no decode required
                    reg_fields["shell_build"] = hex(reg_value)
                elif ("SHELL_SS_PATCH_CORE_REVISION" == regname):
                    # raw value, no decode required
                    reg_fields["shell_patch_core"] = reg_value
                elif ("SHELL_PERFORCE_CL" == regname):
                    # raw value, no decode required
                    reg_fields["shell_p4v_cl"] = reg_value
                elif ("SHELL_RESERVED_TAG" == regname):
                    if reg_value != 0:
                        hex_value = hex(reg_value)
                        hex_string = hex_value[2:]
                        ascii_string = hex_string.decode("hex")
                        reg_value_with_ascii = '(' + str(reg_value) + ')' + str(ascii_string)
                    # raw value, no decode required
                    else:
                        reg_value_with_ascii = reg_value
                    reg_fields["shell_reserved"] = reg_value_with_ascii
                elif ("HOST_REGISTER_ALERT_RESP_WARNING_REG" == regname):
                    # single bit fields
                    reg_fields["HBM_Temp[1]"] = bool(reg_value & (0b1<<11))
                    reg_fields["HBM_Temp[0]"] = bool(reg_value & (0b1<<10))
                    reg_fields["QSFP_Temp[1]"] = bool(reg_value & (0b1<<9))
                    reg_fields["QSFP_Temp[0]"] = bool(reg_value & (0b1<<8))
                    reg_fields["DIMM_temp[2]"] = bool(reg_value & (0b1<<7))
                    reg_fields["DIMM_temp[1]"] = bool(reg_value & (0b1<<6))
                    reg_fields["DIMM_temp[0]"] = bool(reg_value & (0b1<<5))
                    reg_fields["SE98A_temp[2]"] = bool(reg_value & (0b1<<4))
                    reg_fields["SE98A_temp[1]"] = bool(reg_value & (0b1<<3))
                    reg_fields["SE98A_temp[0]"] = bool(reg_value & (0b1<<2))
                    reg_fields["LM96063 Local Temp"] = bool(reg_value & (0b1<<1))
                    reg_fields["FPGA Temp"] = bool(reg_value & 0b1)
                elif ("HOST_REGISTER_ALERT_RESP_CRITICAL_REG" == regname):
                    # single bit fields
                    reg_fields["HBM_Temp[1]"] = bool(reg_value & (0b1<<11))
                    reg_fields["HBM_Temp[0]"] = bool(reg_value & (0b1<<10))
                    reg_fields["QSFP_Temp[1]"] = bool(reg_value & (0b1<<9))
                    reg_fields["QSFP_Temp[0]"] = bool(reg_value & (0b1<<8))
                    reg_fields["DIMM_temp[2]"] = bool(reg_value & (0b1<<7))
                    reg_fields["DIMM_temp[1]"] = bool(reg_value & (0b1<<6))
                    reg_fields["DIMM_temp[0]"] = bool(reg_value & (0b1<<5))
                    reg_fields["SE98A_temp[2]"] = bool(reg_value & (0b1<<4))
                    reg_fields["SE98A_temp[1]"] = bool(reg_value & (0b1<<3))
                    reg_fields["SE98A_temp[0]"] = bool(reg_value & (0b1<<2))
                    reg_fields["LM96063 Local Temp"] = bool(reg_value & (0b1<<1))
                    reg_fields["FPGA Temp"] = bool(reg_value & 0b1)
        except KeyError:
            print("Warning: Invalid field decode [%s=0x%X]" % (regname, reg_value))

        return reg_fields

    def cmc_reg_clear_100(self, card_bus, regname ):
        """Write value to CMC register (string key)"""
        cmc_mm_offset = self.cmc_base_addr + self.cmc_regmap_offset

        try:
            reg_address = self.cmc_regmap[regname]
        except KeyError:
            print("Error: Unknown register name %s" % regname)
            return -1
        if self.root_access == True:
            try:
                 with open("/sys/bus/pci/devices/0000:" + card_bus +":00."+self.cmc_phys_fun+"/resource0", "r+b") as m:
                    # map the full cmc register map to ensure alignment on page boundary
                    cmc_mm = mmap(m.fileno(), self.cmc_regmap_bytes, offset=cmc_mm_offset, access=ACCESS_WRITE)

                    for i in range(reg_address, reg_address+0x100, 4):
                        address = cmc_mm_offset + i
                 #       value = unpack("%sL" % "<", cmc_mm[i:i+4])[0]
                        cmc_mm[i:i+4] = pack("<L", 0)

                    # update register value
                    #readback = unpack("<L", cmc_mm[reg_address:reg_address+4])[0]

                    # release
                    cmc_mm.close()
            except IOError:
                print("Error: Unable to map to device memory, sudo permission required")
                return -1

        else:
            bar_address = self.cmc_get_bar_address(card_bus)
            cmc_mm_offset = cmc_mm_offset + bar_address
            self.cmc_devmem2_write(cmc_mm_offset, value, mask)
        # TODO: added due to buffered readback, improve by adding memory flush
        sleep(1)
        return

    def cmc_reg_write(self, card_bus, regname, value, mask=0xffffffff):
        """Write value to CMC register (string key)"""
        cmc_mm_offset = self.cmc_base_addr + self.cmc_regmap_offset

        try:
            reg_address = self.cmc_regmap[regname]
        except KeyError:
            print("Error: Unknown register name %s" % regname)
            return -1
        if self.root_access == True:
            try:
                 with open("/sys/bus/pci/devices/0000:" + card_bus +":00."+self.cmc_phys_fun+"/resource0", "r+b") as m:
                    # map the full cmc register map to ensure alignment on page boundary
                    cmc_mm = mmap(m.fileno(), self.cmc_regmap_bytes, offset=cmc_mm_offset, access=ACCESS_WRITE)

                    # update register value
                    readback = unpack("<L", cmc_mm[reg_address:reg_address+4])[0]
                    value_masked = (readback & ~mask) | (value & mask)
                    cmc_mm[reg_address:reg_address+4] = pack("<L", value_masked)

                    # release
                    cmc_mm.close()
            except IOError:
                print("Error: Unable to map to device memory, sudo permission required")
                return -1

        else:
            bar_address = self.cmc_get_bar_address(card_bus)
            cmc_mm_offset = cmc_mm_offset + bar_address
            self.cmc_devmem2_write(cmc_mm_offset, value, mask)
        # TODO: added due to buffered readback, improve by adding memory flush
        sleep(1)
        return

    def cmc_reg_write_with_mask(self, card_bus, regname, value, mask):
        """Write value to CMC register (string key) using bitmask"""
        try:
            regmap_address = self.cmc_regmap[regname]
        except:
            print("Error: Unknown register name %s" % regname)
            return -1

        self.cmc_reg_write(card_bus, regname, value, mask=mask)

        return

    def cmc_reg_dump(self, card_bus, reg_offset, reg_len, endian_swap=False):
        """Print register dump based on offset and length supplied"""
        cmc_mm_offset = self.cmc_base_addr + self.cmc_regmap_offset

        # default is little endian, use big endian if requested via arg
        # used for message buffers in regmap, stored in "network" order
        endianness = ">" if endian_swap else "<"

        if self.root_access == True:
            try:
                with open("/sys/bus/pci/devices/0000:" + card_bus +":00."+self.cmc_phys_fun+"/resource0", "rb") as m:
                    # map the full cmc register map to ensure alignment on page boundary
                    cmc_mm = mmap(m.fileno(), self.cmc_regmap_bytes, offset=cmc_mm_offset, access=ACCESS_READ)

                    # extract requested offset region in map
                    dump_str = ""
                    for i in range(reg_offset, reg_offset+reg_len, 4):
                        address = cmc_mm_offset + i
                        value = unpack("%sL" % endianness, cmc_mm[i:i+4])[0]

                        if (0 == (i % 16)):
                            if (dump_str):
                                print(dump_str)
                            dump_str = ("  0x%08X: %08x" % (address, value))
                        else:
                            dump_str += (" %08x" % value)

                    print(dump_str)

                    # release
                    cmc_mm.close()
            except IOError:
                print("Error: Unable to map to device memory, sudo permission required")
                return -1
        else:
            bar_address = self.cmc_get_bar_address(card_bus)
            cmc_mm_offset = cmc_mm_offset + bar_address

            # extract requested offset region in map
            dump_str = ""
            for i in range(reg_offset, reg_offset+reg_len, 4):
                address = cmc_mm_offset + i
                #value = self.cmc_devmem2_read(address)
                value = unpack("<I", pack("%sI" % endianness, self.cmc_devmem2_read(address)))[0]

                if (0 == (i % 16)):
                    if (dump_str):
                        print(dump_str)
                    dump_str = ("  0x%08X: %08x" % (address, value))
                else:
                    dump_str += (" %08x" % value)

            print(dump_str)

        return


    def cmc_mem_dump(self, card_bus, mem_offset, mem_len, endian_swap=False):
        """Print memory dump based on offset and length supplied"""
        cmc_mm_offset = self.cmc_base_addr + self.cmc_lmb_offset

        # default is little endian, use big endian if requested via arg
        # used for message buffers in regmap, stored in "network" order
        endianness = ">" if endian_swap else "<"

        if self.root_access == True:
            try:
                 with open("/sys/bus/pci/devices/0000:" + card_bus +":00."+self.cmc_phys_fun+"/resource0", "r+b" ) as m:
                    # map the cmc processor memory
                    cmc_mm = mmap(m.fileno(), self.cmc_lmb_bytes, offset=cmc_mm_offset, access=ACCESS_READ)

                    # extract requested offset region in map
                    dump_str = ""
                    for i in range(mem_offset, mem_offset+mem_len, 4):
                        address = cmc_mm_offset + i
                        value = unpack("%sL" % endianness, cmc_mm[i:i+4])[0]

                        if (0 == (i % 16)):
                            if (dump_str):
                                print(dump_str)
                            dump_str = ("  0x%08X: %08x" % (address, value))
                        else:
                            dump_str += (" %08x" % value)

                    print(dump_str)

                    # release
                    cmc_mm.close()
            except IOError:
                print("Error: Unable to map to device memory, sudo permission required")
                return -1
        else:
            print("Error: Unable to map to device memory, sudo permission required")
            return -1

        return

    def cmc_coverage_capture(self, card_bus):
        """Retrieve coverage counters from register map and return as dictionary"""
        cmc_mm_offset = self.cmc_base_addr + self.cmc_regmap_offset
        cmc_coverage = {}

        if self.root_access == True:
            try:
                with open("/sys/bus/pci/devices/0000:" + card_bus +":00."+self.cmc_phys_fun+"/resource0", "rb") as m:
                    # map the full cmc register map to ensure alignment on page boundary
                    cmc_mm = mmap(m.fileno(), self.cmc_regmap_bytes, offset=cmc_mm_offset, access=ACCESS_READ)

                    for category in ["HOST_MSG", "HOST_ERR", "SAT_MSG", "SENSOR"]:
                        # configure encoding and offset based on category
                        if ("HOST_MSG" == category):
                            coverage_encoding = self.host_msg_codes
                            coverage_base = self.cmc_regmap["CMC_HOST_MSG_COVERAGE_REG"]
                        elif ("HOST_ERR" == category):
                            coverage_encoding = self.host_error_codes
                            coverage_base = self.cmc_regmap["CMC_HOST_ERR_COVERAGE_REG"]
                        elif ("SAT_MSG" == category):
                            coverage_encoding = self.sc_msg_codes
                            coverage_base = self.cmc_regmap["CMC_SC_MSG_COVERAGE_REG"]
                        elif ("SENSOR" == category):
                            coverage_encoding = self.sc_sensor_codes
                            coverage_base = self.cmc_regmap["CMC_SC_SNSR_COVERAGE_REG"]

                        # extract individual coverage counters, add to category dictionary
                        category_coverage = {}
                        for code in coverage_encoding:
                            coverage_offset = coverage_base + (code << 2)
                            coverage_value = unpack("<L", cmc_mm[coverage_offset:coverage_offset+4])[0]
                            category_coverage[coverage_encoding[code]] = coverage_value

                        # add completef category to overall coverage, return is dictionary of dictionaries
                        cmc_coverage[category] = category_coverage

                    # release
                    cmc_mm.close()
            except IOError:
                print("Error: Unable to map to device memory, sudo permission required")
                return -1
        else:
            bar_address = self.cmc_get_bar_address(card_bus)
            cmc_mm_offset = cmc_mm_offset + bar_address
            for category in ["HOST_MSG", "HOST_ERR", "SAT_MSG", "SENSOR"]:
                # configure encoding and offset based on category
                if ("HOST_MSG" == category):
                    coverage_encoding = self.host_msg_codes
                    coverage_base = self.cmc_regmap["CMC_HOST_MSG_COVERAGE_REG"]
                elif ("HOST_ERR" == category):
                    coverage_encoding = self.host_error_codes
                    coverage_base = self.cmc_regmap["CMC_HOST_ERR_COVERAGE_REG"]
                elif ("SAT_MSG" == category):
                    coverage_encoding = self.sc_msg_codes
                    coverage_base = self.cmc_regmap["CMC_SC_MSG_COVERAGE_REG"]
                elif ("SENSOR" == category):
                    coverage_encoding = self.sc_sensor_codes
                    coverage_base = self.cmc_regmap["CMC_SC_SNSR_COVERAGE_REG"]

                # extract individual coverage counters, add to category dictionary
                category_coverage = {}
                for code in coverage_encoding:
                    coverage_offset = coverage_base + (code << 2)
                    coverage_value = self.cmc_devmem2_read(cmc_mm_offset + coverage_offset)
                    category_coverage[coverage_encoding[code]] = coverage_value

                # add completef category to overall coverage, return is dictionary of dictionaries
                cmc_coverage[category] = category_coverage            

        return cmc_coverage

    def cmc_watchpoint_capture(self, card_bus):
        watchpoints_dict = {}
        for watchpoint_register in self.watchpoints:
            watchpoints_dict[watchpoint_register] = self.cmc_reg_read(card_bus, watchpoint_register)
        return watchpoints_dict

    def cmc_stop(self, card_bus):
        """Stop CMC processor"""
        self.cmc_reg_write_with_mask(card_bus, "CMC_CONTROL_REG", 0b1<<3, 0b1<<3)
        self.cmc_reg_write_with_mask(card_bus, "CMC_STOP_CONFIRM_REG", 0b1, 0b1)

        return

    def cmc_debug_capture(self, card_bus):
        """Arm CMC debug message capture"""
        self.cmc_reg_write_with_mask(card_bus, "CMC_CONTROL_REG", 0b1<<30, 0b1<<30)

        return

    def cmc_load_firmware_image(self, card_bus, image):
        """Load firmware image to CMC processor memory"""
        cmc_mm_offset = self.cmc_base_addr + self.cmc_lmb_offset
        if self.root_access == True:
            try:
                 with open("/sys/bus/pci/devices/0000:" + card_bus +":00."+self.cmc_phys_fun+"/resource0", "r+b" ) as m:
                    # map the cmc processor memory
                    cmc_mm = mmap(m.fileno(), self.cmc_lmb_bytes, offset=cmc_mm_offset, access=ACCESS_WRITE)

                    # map the firmware image file and copy to cmc processor memory
                    with open(image, "rb") as f:                     
                        image_bytes = getsize(image)
                        image_mm = mmap(f.fileno(), getsize(image), access=ACCESS_READ)

                        # TODO: microblaze bin files always 32b/4B aligned?
                        for i in range(0, image_bytes, 4):
                            readback = unpack("<L", image_mm[i:i+4])[0]
                            cmc_mm[i:i+4] = pack("<L", readback)

                    # release
                    image_mm.close()
                    cmc_mm.close()
            except IOError:
                print("Error: Unable to map to device memory, sudo permission required")
                return -1

        else:
            bar_address = self.cmc_get_bar_address(card_bus)
            cmc_mm_offset = cmc_mm_offset + bar_address
            with open(image, "rb") as f:
                image_bytes = getsize(image)
                for i in range(0, image_bytes, 4):
                    image_chunk = f.read(4)
                    if not image_chunk:
                        break
                    readback = unpack("<L", image_chunk)[0]
                    print("Writing chunk " + str(i/4) + " out of " + str(image_bytes))
                    self.cmc_devmem2_write(cmc_mm_offset+i, readback)
        return

    def cmc_message_trace_capture(self, card_bus):
        """Retrieve message trace and return as list"""
        cmc_mm_offset = self.cmc_base_addr + self.cmc_regmap_offset
        msg_trace_offset = self.cmc_regmap["CMC_SAT_MSG_TRACE_REG"]
        msg_trace_bytes = (32*4*2)
        msg_trace = []

        try:
            with open("/sys/bus/pci/devices/0000:" + card_bus +":00."+self.cmc_phys_fun+"/resource0", "rb") as m:
                # map the full cmc register map to ensure alignment on page boundary
                cmc_mm = mmap(m.fileno(), self.cmc_regmap_bytes, offset=cmc_mm_offset, access=ACCESS_READ)

                ##msg_direction = "TX"
                for i in range(msg_trace_offset, msg_trace_offset+msg_trace_bytes, 4):
                    value = unpack("<L", cmc_mm[i:i+4])[0]

                    # decode trace into fields
                    try:
                        msg_trace_item = {}
                        msg_trace_item['TIMESTAMP'] = (value&0xff000000)>>24
                        msg_trace_item['PREV_STATE'] = self.sensor_supervisor_states[(value&0x0000ff00)>>8]
                        msg_trace_item['CURR_STATE'] = self.sensor_supervisor_states[(value&0x000000ff)]
                        # TX messages always use SAT message ID encoding but RX messages can be either SAT or BSL message ID encoding depending on mode
                        if (msg_trace_item['CURR_STATE'] == 0x00):
                            msg_trace_item['ID'] = self.sc_bsl_msg_codes[(value&0x00ff0000)>>16]
                        else:
                            msg_trace_item['ID'] = self.sc_msg_codes[(value&0x00ff0000)>>16]
                    
                        msg_trace.append(msg_trace_item)
                    except KeyError:
                        print("Warning: Invalid trace decode [0x%X]" % (value))
                        msg_trace_item['ID'] = "DECODE_ERR"
                        msg_trace_item['PREV_STATE'] = "DECODE_ERR"
                        msg_trace_item['CURR_STATE'] = "DECODE_ERR"
                        msg_trace.append(msg_trace_item)

                # release
                cmc_mm.close()
        except IOError:
            print("Error: Unable to map to device memory, sudo permission required")
            return -1

        return msg_trace

    def cmc_board_info_decode(self, card_bus):
        """Decode board info from host message buffer into dictionary"""
        cmc_mm_offset = self.cmc_base_addr + self.cmc_regmap_offset

        index = 0
        board_info = {}

        try:
            with open("/sys/bus/pci/devices/0000:" + card_bus +":00."+self.cmc_phys_fun+"/resource0", "rb") as m:
                # map the full cmc register map to ensure alignment on page boundary
                cmc_mm = mmap(m.fileno(), self.cmc_regmap_bytes, offset=cmc_mm_offset, access=ACCESS_READ)

                # jump to host message header
                index += self.cmc_regmap["CMC_HOST_MSG_REG"]
                message_header = unpack("<L", cmc_mm[index:index+4])[0]
                message_opcode = (message_header & (0b11111111<<24))>>24 # 31:24
                message_len = message_header & 0b11111111111 # 11:0
                index += 4

                # loop over payload for key/value pairs
                while(index < (message_len+self.cmc_regmap["CMC_HOST_MSG_REG"])):
                    #field_key = unpack("<B", cmc_mm[index])[0]
                    try:
                        field_key = ord(cmc_mm[index])
                    except TypeError:
                        field_key = cmc_mm[index]
                    index += 1

                    if ('SNSR_ID_NEW_MAC_SCHEME' in self.sc_sensor_codes[field_key]):
                        #field_len = unpack("<B", cmc_mm[index])[0]
                        try:
                            field_len = ord(cmc_mm[index])
                        except TypeError:
                            field_len = cmc_mm[index]
                        index += 1
                        field_value = 0
                        field_ascii = ''
                        name_ascii = ''
                        for i in range(field_len):
                            #byte = unpack("<B", cmc_mm[index+i])[0]
                            try:
                                byte = ord(cmc_mm[index+i])
                            except TypeError:
                                byte = cmc_mm[index+i]
                            field_value = (field_value<<8) + byte
                    else:
                        #field_len = unpack("<B", cmc_mm[index])[0]
                        try:
                            field_len = ord(cmc_mm[index])
                        except TypeError:
                            field_len = cmc_mm[index]
                        index += 1
                        field_value = 0
                        field_ascii = ''
                        name_ascii = ''
                        for i in range(field_len):
                            #byte = unpack("<B", cmc_mm[index+i])[0]
                            try:
                                byte = ord(cmc_mm[index+i])
                            except TypeError:
                                byte = cmc_mm[index+i]
                            field_value = (field_value<<8) + byte
                            field_ascii += chr(byte)
                    index += field_len

                    if ('SNSR_ID_TOTAL_POWER_AVAIL' in self.sc_sensor_codes[field_key]):
                        board_info[self.sc_sensor_codes[field_key]] = self.power_codes[field_value]
                    elif ('SNSR_ID_CONFIG_MODE' in self.sc_sensor_codes[field_key]):
                        board_info[self.sc_sensor_codes[field_key]] = self.eeprom_config_modes[field_value]
                    elif ('SNSR_ID_NEW_MAC_SCHEME' in self.sc_sensor_codes[field_key]):
                        board_info[self.sc_sensor_codes[field_key]] = field_value
                    else:
                        board_info[self.sc_sensor_codes[field_key]] = field_ascii

                # release
                cmc_mm.close()
        except IOError:
            print("Error: Unable to map to device memory, sudo permission required")
            return -1

        return board_info

    def cmc_fsm_info_decode(self, card_bus, regname):
        """Decode register into individual fields, return result (dict)"""
        reg_value = self.cmc_reg_read(card_bus, regname)

        reg_fields = {}
        try:
            if (reg_value >= 0):
                if ("W_LINK_STATE_CURRENT" == regname):
                    reg_fields["LS_Current"] = self.link_state_states[reg_value]
                elif ("W_LINK_STATE_PREVIOUS" == regname):
                    reg_fields["LS_Previous"] = self.link_state_states[reg_value]
                elif ("W_LINK_STATE_LAST_EVENT" == regname):
                    reg_fields["LS_Event"] = self.link_state_events[reg_value]
                elif ("W_THREAD_LOCAL_LINK_SUPERVISOR" == regname):
                    reg_fields["LS_Thread_Count"] = reg_value
                elif ("W_BOOTLOADER_CURRENT" == regname):
                    reg_fields["BL_Current"] = self.bootloader_states[reg_value]
                elif ("W_BOOTLOADER_PREVIOUS" == regname):
                    reg_fields["BL_Previous"] = self.bootloader_states[reg_value]
                elif ("W_BOOTLOADER_LAST_EVENT" == regname):
                    reg_fields["BL_Event"] = self.bootloader_events[reg_value]
                elif ("W_THREAD_LOCAL_BOOTLOADER" == regname):
                    reg_fields["BL_Thread_Count"] = reg_value
                elif ("W_SENSOR_SUPERVISOR_CURRENT" == regname):
                    reg_fields["SS_Current"] = self.sensor_supervisor_states[reg_value]
                elif ("W_SENSOR_SUPERVISOR_PREVIOUS" == regname):
                    reg_fields["SS_Previous"] = self.sensor_supervisor_states[reg_value]
                elif ("W_SENSOR_SUPERVISOR_LAST_EVENT" == regname):
                    reg_fields["SS_Event"] = self.sensor_supervisor_events[reg_value]
                elif ("W_THREAD_LOCAL_SENSOR_SUPERVISOR" == regname):
                    reg_fields["SS_Thread_Count"] = reg_value
                elif ("W_HOST_PROXY_CURRENT" == regname):
                    reg_fields["HP_Current"] = self.host_proxy_states[reg_value]
                elif ("W_HOST_PROXY_PREVIOUS" == regname):
                    reg_fields["HP_Previous"] = self.host_proxy_states[reg_value]
                elif ("W_HOST_PROXY_LAST_EVENT" == regname):
                    reg_fields["HP_Event"] = self.host_proxy_events[reg_value]
                elif ("W_THREAD_HOST_USER_PROXY" == regname):
                    reg_fields["HP_Thread_Count"] = reg_value
        except KeyError:
            print("Warning: Unknown field decode [%s=0x%X]" % (regname, reg_value))

        return reg_fields
