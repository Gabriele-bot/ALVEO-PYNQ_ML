#include "dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1530_fu_72612_p2() {
    mul_ln1118_1530_fu_72612_p2 = (!mul_ln1118_1530_fu_72612_p0.read().is_01() || !mul_ln1118_1530_fu_72612_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1530_fu_72612_p0.read()) * sc_bigint<5>(mul_ln1118_1530_fu_72612_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1531_fu_72633_p0() {
    mul_ln1118_1531_fu_72633_p0 =  (sc_lv<3>) (sext_ln1116_131_fu_45810_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1531_fu_72633_p1() {
    mul_ln1118_1531_fu_72633_p1 = tmp_1531_reg_112286.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1531_fu_72633_p2() {
    mul_ln1118_1531_fu_72633_p2 = (!mul_ln1118_1531_fu_72633_p0.read().is_01() || !mul_ln1118_1531_fu_72633_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1531_fu_72633_p0.read()) * sc_bigint<5>(mul_ln1118_1531_fu_72633_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1532_fu_72654_p0() {
    mul_ln1118_1532_fu_72654_p0 =  (sc_lv<3>) (sext_ln1116_132_fu_45834_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1532_fu_72654_p1() {
    mul_ln1118_1532_fu_72654_p1 = tmp_1532_reg_112291.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1532_fu_72654_p2() {
    mul_ln1118_1532_fu_72654_p2 = (!mul_ln1118_1532_fu_72654_p0.read().is_01() || !mul_ln1118_1532_fu_72654_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1532_fu_72654_p0.read()) * sc_bigint<5>(mul_ln1118_1532_fu_72654_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1533_fu_72675_p0() {
    mul_ln1118_1533_fu_72675_p0 =  (sc_lv<3>) (sext_ln1116_133_fu_45858_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1533_fu_72675_p1() {
    mul_ln1118_1533_fu_72675_p1 = tmp_1533_reg_112296.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1533_fu_72675_p2() {
    mul_ln1118_1533_fu_72675_p2 = (!mul_ln1118_1533_fu_72675_p0.read().is_01() || !mul_ln1118_1533_fu_72675_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1533_fu_72675_p0.read()) * sc_bigint<5>(mul_ln1118_1533_fu_72675_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1534_fu_72696_p0() {
    mul_ln1118_1534_fu_72696_p0 =  (sc_lv<3>) (sext_ln1116_134_fu_45882_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1534_fu_72696_p1() {
    mul_ln1118_1534_fu_72696_p1 = tmp_1534_reg_112301.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1534_fu_72696_p2() {
    mul_ln1118_1534_fu_72696_p2 = (!mul_ln1118_1534_fu_72696_p0.read().is_01() || !mul_ln1118_1534_fu_72696_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1534_fu_72696_p0.read()) * sc_bigint<5>(mul_ln1118_1534_fu_72696_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1535_fu_72705_p0() {
    mul_ln1118_1535_fu_72705_p0 =  (sc_lv<3>) (sext_ln1116_135_fu_45894_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1535_fu_72705_p1() {
    mul_ln1118_1535_fu_72705_p1 = tmp_1535_reg_112306.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1535_fu_72705_p2() {
    mul_ln1118_1535_fu_72705_p2 = (!mul_ln1118_1535_fu_72705_p0.read().is_01() || !mul_ln1118_1535_fu_72705_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1535_fu_72705_p0.read()) * sc_bigint<5>(mul_ln1118_1535_fu_72705_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1536_fu_72726_p0() {
    mul_ln1118_1536_fu_72726_p0 =  (sc_lv<3>) (sext_ln1116_136_fu_45918_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1536_fu_72726_p1() {
    mul_ln1118_1536_fu_72726_p1 = tmp_1536_reg_112311.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1536_fu_72726_p2() {
    mul_ln1118_1536_fu_72726_p2 = (!mul_ln1118_1536_fu_72726_p0.read().is_01() || !mul_ln1118_1536_fu_72726_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1536_fu_72726_p0.read()) * sc_bigint<5>(mul_ln1118_1536_fu_72726_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1537_fu_72747_p0() {
    mul_ln1118_1537_fu_72747_p0 =  (sc_lv<3>) (sext_ln1116_137_fu_45942_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1537_fu_72747_p1() {
    mul_ln1118_1537_fu_72747_p1 = tmp_1537_reg_112316.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1537_fu_72747_p2() {
    mul_ln1118_1537_fu_72747_p2 = (!mul_ln1118_1537_fu_72747_p0.read().is_01() || !mul_ln1118_1537_fu_72747_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1537_fu_72747_p0.read()) * sc_bigint<5>(mul_ln1118_1537_fu_72747_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1538_fu_72756_p0() {
    mul_ln1118_1538_fu_72756_p0 =  (sc_lv<3>) (sext_ln1116_138_fu_45954_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1538_fu_72756_p1() {
    mul_ln1118_1538_fu_72756_p1 = tmp_1538_reg_112321.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1538_fu_72756_p2() {
    mul_ln1118_1538_fu_72756_p2 = (!mul_ln1118_1538_fu_72756_p0.read().is_01() || !mul_ln1118_1538_fu_72756_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1538_fu_72756_p0.read()) * sc_bigint<5>(mul_ln1118_1538_fu_72756_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1539_fu_72777_p0() {
    mul_ln1118_1539_fu_72777_p0 =  (sc_lv<3>) (sext_ln1116_139_fu_45978_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1539_fu_72777_p1() {
    mul_ln1118_1539_fu_72777_p1 = tmp_1539_reg_112326.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1539_fu_72777_p2() {
    mul_ln1118_1539_fu_72777_p2 = (!mul_ln1118_1539_fu_72777_p0.read().is_01() || !mul_ln1118_1539_fu_72777_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1539_fu_72777_p0.read()) * sc_bigint<5>(mul_ln1118_1539_fu_72777_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_153_fu_46233_p0() {
    mul_ln1118_153_fu_46233_p0 =  (sc_lv<3>) (sext_ln1116_153_fu_46227_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_153_fu_46233_p1() {
    mul_ln1118_153_fu_46233_p1 = tmp_153_reg_105120.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_153_fu_46233_p2() {
    mul_ln1118_153_fu_46233_p2 = (!mul_ln1118_153_fu_46233_p0.read().is_01() || !mul_ln1118_153_fu_46233_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_153_fu_46233_p0.read()) * sc_bigint<5>(mul_ln1118_153_fu_46233_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1540_fu_94391_p0() {
    mul_ln1118_1540_fu_94391_p0 =  (sc_lv<3>) (sext_ln1116_140_reg_114908.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1540_fu_94391_p1() {
    mul_ln1118_1540_fu_94391_p1 = tmp_1540_reg_112331_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1540_fu_94391_p2() {
    mul_ln1118_1540_fu_94391_p2 = (!mul_ln1118_1540_fu_94391_p0.read().is_01() || !mul_ln1118_1540_fu_94391_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1540_fu_94391_p0.read()) * sc_bigint<5>(mul_ln1118_1540_fu_94391_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1541_fu_72798_p0() {
    mul_ln1118_1541_fu_72798_p0 =  (sc_lv<3>) (sext_ln1116_141_fu_46005_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1541_fu_72798_p1() {
    mul_ln1118_1541_fu_72798_p1 = tmp_1541_reg_112336.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1541_fu_72798_p2() {
    mul_ln1118_1541_fu_72798_p2 = (!mul_ln1118_1541_fu_72798_p0.read().is_01() || !mul_ln1118_1541_fu_72798_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1541_fu_72798_p0.read()) * sc_bigint<5>(mul_ln1118_1541_fu_72798_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1542_fu_72819_p0() {
    mul_ln1118_1542_fu_72819_p0 =  (sc_lv<3>) (sext_ln1116_142_fu_46029_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1542_fu_72819_p1() {
    mul_ln1118_1542_fu_72819_p1 = tmp_1542_reg_112341.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1542_fu_72819_p2() {
    mul_ln1118_1542_fu_72819_p2 = (!mul_ln1118_1542_fu_72819_p0.read().is_01() || !mul_ln1118_1542_fu_72819_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1542_fu_72819_p0.read()) * sc_bigint<5>(mul_ln1118_1542_fu_72819_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1543_fu_94411_p0() {
    mul_ln1118_1543_fu_94411_p0 =  (sc_lv<3>) (sext_ln1116_143_reg_114921.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1543_fu_94411_p1() {
    mul_ln1118_1543_fu_94411_p1 = tmp_1543_reg_112346_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1543_fu_94411_p2() {
    mul_ln1118_1543_fu_94411_p2 = (!mul_ln1118_1543_fu_94411_p0.read().is_01() || !mul_ln1118_1543_fu_94411_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1543_fu_94411_p0.read()) * sc_bigint<5>(mul_ln1118_1543_fu_94411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1544_fu_72840_p0() {
    mul_ln1118_1544_fu_72840_p0 =  (sc_lv<3>) (sext_ln1116_144_fu_46056_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1544_fu_72840_p1() {
    mul_ln1118_1544_fu_72840_p1 = tmp_1544_reg_112351.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1544_fu_72840_p2() {
    mul_ln1118_1544_fu_72840_p2 = (!mul_ln1118_1544_fu_72840_p0.read().is_01() || !mul_ln1118_1544_fu_72840_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1544_fu_72840_p0.read()) * sc_bigint<5>(mul_ln1118_1544_fu_72840_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1545_fu_72861_p0() {
    mul_ln1118_1545_fu_72861_p0 =  (sc_lv<3>) (sext_ln1116_145_fu_46080_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1545_fu_72861_p1() {
    mul_ln1118_1545_fu_72861_p1 = tmp_1545_reg_112356.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1545_fu_72861_p2() {
    mul_ln1118_1545_fu_72861_p2 = (!mul_ln1118_1545_fu_72861_p0.read().is_01() || !mul_ln1118_1545_fu_72861_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1545_fu_72861_p0.read()) * sc_bigint<5>(mul_ln1118_1545_fu_72861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1546_fu_72882_p0() {
    mul_ln1118_1546_fu_72882_p0 =  (sc_lv<3>) (sext_ln1116_146_fu_46104_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1546_fu_72882_p1() {
    mul_ln1118_1546_fu_72882_p1 = tmp_1546_reg_112361.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1546_fu_72882_p2() {
    mul_ln1118_1546_fu_72882_p2 = (!mul_ln1118_1546_fu_72882_p0.read().is_01() || !mul_ln1118_1546_fu_72882_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1546_fu_72882_p0.read()) * sc_bigint<5>(mul_ln1118_1546_fu_72882_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1547_fu_72891_p0() {
    mul_ln1118_1547_fu_72891_p0 =  (sc_lv<3>) (sext_ln1116_147_fu_46116_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1547_fu_72891_p1() {
    mul_ln1118_1547_fu_72891_p1 = tmp_1547_reg_112366.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1547_fu_72891_p2() {
    mul_ln1118_1547_fu_72891_p2 = (!mul_ln1118_1547_fu_72891_p0.read().is_01() || !mul_ln1118_1547_fu_72891_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1547_fu_72891_p0.read()) * sc_bigint<5>(mul_ln1118_1547_fu_72891_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1548_fu_72912_p0() {
    mul_ln1118_1548_fu_72912_p0 =  (sc_lv<3>) (sext_ln1116_148_fu_46140_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1548_fu_72912_p1() {
    mul_ln1118_1548_fu_72912_p1 = tmp_1548_reg_112371.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1548_fu_72912_p2() {
    mul_ln1118_1548_fu_72912_p2 = (!mul_ln1118_1548_fu_72912_p0.read().is_01() || !mul_ln1118_1548_fu_72912_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1548_fu_72912_p0.read()) * sc_bigint<5>(mul_ln1118_1548_fu_72912_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1549_fu_72933_p0() {
    mul_ln1118_1549_fu_72933_p0 =  (sc_lv<3>) (sext_ln1116_149_fu_46164_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1549_fu_72933_p1() {
    mul_ln1118_1549_fu_72933_p1 = tmp_1549_reg_112376.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1549_fu_72933_p2() {
    mul_ln1118_1549_fu_72933_p2 = (!mul_ln1118_1549_fu_72933_p0.read().is_01() || !mul_ln1118_1549_fu_72933_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1549_fu_72933_p0.read()) * sc_bigint<5>(mul_ln1118_1549_fu_72933_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_154_fu_46257_p0() {
    mul_ln1118_154_fu_46257_p0 =  (sc_lv<3>) (sext_ln1116_154_fu_46251_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_154_fu_46257_p1() {
    mul_ln1118_154_fu_46257_p1 = tmp_154_reg_105130.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_154_fu_46257_p2() {
    mul_ln1118_154_fu_46257_p2 = (!mul_ln1118_154_fu_46257_p0.read().is_01() || !mul_ln1118_154_fu_46257_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_154_fu_46257_p0.read()) * sc_bigint<5>(mul_ln1118_154_fu_46257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1550_fu_72942_p0() {
    mul_ln1118_1550_fu_72942_p0 =  (sc_lv<3>) (sext_ln1116_150_fu_46176_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1550_fu_72942_p1() {
    mul_ln1118_1550_fu_72942_p1 = tmp_1550_reg_112381.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1550_fu_72942_p2() {
    mul_ln1118_1550_fu_72942_p2 = (!mul_ln1118_1550_fu_72942_p0.read().is_01() || !mul_ln1118_1550_fu_72942_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1550_fu_72942_p0.read()) * sc_bigint<5>(mul_ln1118_1550_fu_72942_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1551_fu_72963_p0() {
    mul_ln1118_1551_fu_72963_p0 =  (sc_lv<3>) (sext_ln1116_151_fu_46200_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1551_fu_72963_p1() {
    mul_ln1118_1551_fu_72963_p1 = tmp_1551_reg_112386.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1551_fu_72963_p2() {
    mul_ln1118_1551_fu_72963_p2 = (!mul_ln1118_1551_fu_72963_p0.read().is_01() || !mul_ln1118_1551_fu_72963_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1551_fu_72963_p0.read()) * sc_bigint<5>(mul_ln1118_1551_fu_72963_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1552_fu_94453_p0() {
    mul_ln1118_1552_fu_94453_p0 =  (sc_lv<3>) (sext_ln1116_152_reg_114944.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1552_fu_94453_p1() {
    mul_ln1118_1552_fu_94453_p1 = tmp_1552_reg_112391_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1552_fu_94453_p2() {
    mul_ln1118_1552_fu_94453_p2 = (!mul_ln1118_1552_fu_94453_p0.read().is_01() || !mul_ln1118_1552_fu_94453_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1552_fu_94453_p0.read()) * sc_bigint<5>(mul_ln1118_1552_fu_94453_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1553_fu_72984_p0() {
    mul_ln1118_1553_fu_72984_p0 =  (sc_lv<3>) (sext_ln1116_153_fu_46227_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1553_fu_72984_p1() {
    mul_ln1118_1553_fu_72984_p1 = tmp_1553_reg_112396.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1553_fu_72984_p2() {
    mul_ln1118_1553_fu_72984_p2 = (!mul_ln1118_1553_fu_72984_p0.read().is_01() || !mul_ln1118_1553_fu_72984_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1553_fu_72984_p0.read()) * sc_bigint<5>(mul_ln1118_1553_fu_72984_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1554_fu_73005_p0() {
    mul_ln1118_1554_fu_73005_p0 =  (sc_lv<3>) (sext_ln1116_154_fu_46251_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1554_fu_73005_p1() {
    mul_ln1118_1554_fu_73005_p1 = tmp_1554_reg_112401.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1554_fu_73005_p2() {
    mul_ln1118_1554_fu_73005_p2 = (!mul_ln1118_1554_fu_73005_p0.read().is_01() || !mul_ln1118_1554_fu_73005_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1554_fu_73005_p0.read()) * sc_bigint<5>(mul_ln1118_1554_fu_73005_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1555_fu_73026_p0() {
    mul_ln1118_1555_fu_73026_p0 =  (sc_lv<3>) (sext_ln1116_155_fu_46275_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1555_fu_73026_p1() {
    mul_ln1118_1555_fu_73026_p1 = tmp_1555_reg_112406.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1555_fu_73026_p2() {
    mul_ln1118_1555_fu_73026_p2 = (!mul_ln1118_1555_fu_73026_p0.read().is_01() || !mul_ln1118_1555_fu_73026_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1555_fu_73026_p0.read()) * sc_bigint<5>(mul_ln1118_1555_fu_73026_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1556_fu_73047_p0() {
    mul_ln1118_1556_fu_73047_p0 =  (sc_lv<3>) (sext_ln1116_156_fu_46299_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1556_fu_73047_p1() {
    mul_ln1118_1556_fu_73047_p1 = tmp_1556_reg_112411.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1556_fu_73047_p2() {
    mul_ln1118_1556_fu_73047_p2 = (!mul_ln1118_1556_fu_73047_p0.read().is_01() || !mul_ln1118_1556_fu_73047_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1556_fu_73047_p0.read()) * sc_bigint<5>(mul_ln1118_1556_fu_73047_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1557_fu_73068_p0() {
    mul_ln1118_1557_fu_73068_p0 =  (sc_lv<3>) (sext_ln1116_157_fu_46323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1557_fu_73068_p1() {
    mul_ln1118_1557_fu_73068_p1 = tmp_1557_reg_112416.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1557_fu_73068_p2() {
    mul_ln1118_1557_fu_73068_p2 = (!mul_ln1118_1557_fu_73068_p0.read().is_01() || !mul_ln1118_1557_fu_73068_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1557_fu_73068_p0.read()) * sc_bigint<5>(mul_ln1118_1557_fu_73068_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1558_fu_73089_p0() {
    mul_ln1118_1558_fu_73089_p0 =  (sc_lv<3>) (sext_ln1116_158_fu_46347_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1558_fu_73089_p1() {
    mul_ln1118_1558_fu_73089_p1 = tmp_1558_reg_112421.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1558_fu_73089_p2() {
    mul_ln1118_1558_fu_73089_p2 = (!mul_ln1118_1558_fu_73089_p0.read().is_01() || !mul_ln1118_1558_fu_73089_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1558_fu_73089_p0.read()) * sc_bigint<5>(mul_ln1118_1558_fu_73089_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1559_fu_73110_p0() {
    mul_ln1118_1559_fu_73110_p0 =  (sc_lv<3>) (sext_ln1116_159_fu_46371_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1559_fu_73110_p1() {
    mul_ln1118_1559_fu_73110_p1 = tmp_1559_reg_112426.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1559_fu_73110_p2() {
    mul_ln1118_1559_fu_73110_p2 = (!mul_ln1118_1559_fu_73110_p0.read().is_01() || !mul_ln1118_1559_fu_73110_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1559_fu_73110_p0.read()) * sc_bigint<5>(mul_ln1118_1559_fu_73110_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_155_fu_46281_p0() {
    mul_ln1118_155_fu_46281_p0 =  (sc_lv<3>) (sext_ln1116_155_fu_46275_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_155_fu_46281_p1() {
    mul_ln1118_155_fu_46281_p1 = tmp_155_reg_105140.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_155_fu_46281_p2() {
    mul_ln1118_155_fu_46281_p2 = (!mul_ln1118_155_fu_46281_p0.read().is_01() || !mul_ln1118_155_fu_46281_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_155_fu_46281_p0.read()) * sc_bigint<5>(mul_ln1118_155_fu_46281_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1560_fu_73119_p0() {
    mul_ln1118_1560_fu_73119_p0 =  (sc_lv<3>) (sext_ln1116_160_fu_46383_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1560_fu_73119_p1() {
    mul_ln1118_1560_fu_73119_p1 = tmp_1560_reg_112431.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1560_fu_73119_p2() {
    mul_ln1118_1560_fu_73119_p2 = (!mul_ln1118_1560_fu_73119_p0.read().is_01() || !mul_ln1118_1560_fu_73119_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1560_fu_73119_p0.read()) * sc_bigint<5>(mul_ln1118_1560_fu_73119_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1561_fu_73140_p0() {
    mul_ln1118_1561_fu_73140_p0 =  (sc_lv<3>) (sext_ln1116_161_fu_46407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1561_fu_73140_p1() {
    mul_ln1118_1561_fu_73140_p1 = tmp_1561_reg_112436.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1561_fu_73140_p2() {
    mul_ln1118_1561_fu_73140_p2 = (!mul_ln1118_1561_fu_73140_p0.read().is_01() || !mul_ln1118_1561_fu_73140_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1561_fu_73140_p0.read()) * sc_bigint<5>(mul_ln1118_1561_fu_73140_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1562_fu_73161_p0() {
    mul_ln1118_1562_fu_73161_p0 =  (sc_lv<3>) (sext_ln1116_162_fu_46431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1562_fu_73161_p1() {
    mul_ln1118_1562_fu_73161_p1 = tmp_1562_reg_112441.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1562_fu_73161_p2() {
    mul_ln1118_1562_fu_73161_p2 = (!mul_ln1118_1562_fu_73161_p0.read().is_01() || !mul_ln1118_1562_fu_73161_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1562_fu_73161_p0.read()) * sc_bigint<5>(mul_ln1118_1562_fu_73161_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1563_fu_73170_p0() {
    mul_ln1118_1563_fu_73170_p0 =  (sc_lv<3>) (sext_ln1116_163_fu_46443_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1563_fu_73170_p1() {
    mul_ln1118_1563_fu_73170_p1 = tmp_1563_reg_112446.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1563_fu_73170_p2() {
    mul_ln1118_1563_fu_73170_p2 = (!mul_ln1118_1563_fu_73170_p0.read().is_01() || !mul_ln1118_1563_fu_73170_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1563_fu_73170_p0.read()) * sc_bigint<5>(mul_ln1118_1563_fu_73170_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1564_fu_73191_p0() {
    mul_ln1118_1564_fu_73191_p0 =  (sc_lv<3>) (sext_ln1116_164_fu_46467_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1564_fu_73191_p1() {
    mul_ln1118_1564_fu_73191_p1 = tmp_1564_reg_112451.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1564_fu_73191_p2() {
    mul_ln1118_1564_fu_73191_p2 = (!mul_ln1118_1564_fu_73191_p0.read().is_01() || !mul_ln1118_1564_fu_73191_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1564_fu_73191_p0.read()) * sc_bigint<5>(mul_ln1118_1564_fu_73191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1565_fu_94495_p0() {
    mul_ln1118_1565_fu_94495_p0 =  (sc_lv<3>) (sext_ln1116_165_reg_114967.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1565_fu_94495_p1() {
    mul_ln1118_1565_fu_94495_p1 = tmp_1565_reg_112456_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1565_fu_94495_p2() {
    mul_ln1118_1565_fu_94495_p2 = (!mul_ln1118_1565_fu_94495_p0.read().is_01() || !mul_ln1118_1565_fu_94495_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1565_fu_94495_p0.read()) * sc_bigint<5>(mul_ln1118_1565_fu_94495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1566_fu_73212_p0() {
    mul_ln1118_1566_fu_73212_p0 =  (sc_lv<3>) (sext_ln1116_166_fu_46494_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1566_fu_73212_p1() {
    mul_ln1118_1566_fu_73212_p1 = tmp_1566_reg_112461.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1566_fu_73212_p2() {
    mul_ln1118_1566_fu_73212_p2 = (!mul_ln1118_1566_fu_73212_p0.read().is_01() || !mul_ln1118_1566_fu_73212_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1566_fu_73212_p0.read()) * sc_bigint<5>(mul_ln1118_1566_fu_73212_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1567_fu_73233_p0() {
    mul_ln1118_1567_fu_73233_p0 =  (sc_lv<3>) (sext_ln1116_167_fu_46518_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1567_fu_73233_p1() {
    mul_ln1118_1567_fu_73233_p1 = tmp_1567_reg_112466.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1567_fu_73233_p2() {
    mul_ln1118_1567_fu_73233_p2 = (!mul_ln1118_1567_fu_73233_p0.read().is_01() || !mul_ln1118_1567_fu_73233_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1567_fu_73233_p0.read()) * sc_bigint<5>(mul_ln1118_1567_fu_73233_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1568_fu_94515_p0() {
    mul_ln1118_1568_fu_94515_p0 =  (sc_lv<3>) (sext_ln1116_168_reg_114980.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1568_fu_94515_p1() {
    mul_ln1118_1568_fu_94515_p1 = tmp_1568_reg_112471_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1568_fu_94515_p2() {
    mul_ln1118_1568_fu_94515_p2 = (!mul_ln1118_1568_fu_94515_p0.read().is_01() || !mul_ln1118_1568_fu_94515_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1568_fu_94515_p0.read()) * sc_bigint<5>(mul_ln1118_1568_fu_94515_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1569_fu_73254_p0() {
    mul_ln1118_1569_fu_73254_p0 =  (sc_lv<3>) (sext_ln1116_169_fu_46545_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1569_fu_73254_p1() {
    mul_ln1118_1569_fu_73254_p1 = tmp_1569_reg_112476.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1569_fu_73254_p2() {
    mul_ln1118_1569_fu_73254_p2 = (!mul_ln1118_1569_fu_73254_p0.read().is_01() || !mul_ln1118_1569_fu_73254_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1569_fu_73254_p0.read()) * sc_bigint<5>(mul_ln1118_1569_fu_73254_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_156_fu_46305_p0() {
    mul_ln1118_156_fu_46305_p0 =  (sc_lv<3>) (sext_ln1116_156_fu_46299_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_156_fu_46305_p1() {
    mul_ln1118_156_fu_46305_p1 = tmp_156_reg_105150.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_156_fu_46305_p2() {
    mul_ln1118_156_fu_46305_p2 = (!mul_ln1118_156_fu_46305_p0.read().is_01() || !mul_ln1118_156_fu_46305_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_156_fu_46305_p0.read()) * sc_bigint<5>(mul_ln1118_156_fu_46305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1570_fu_73275_p0() {
    mul_ln1118_1570_fu_73275_p0 =  (sc_lv<3>) (sext_ln1116_170_fu_46569_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1570_fu_73275_p1() {
    mul_ln1118_1570_fu_73275_p1 = tmp_1570_reg_112481.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1570_fu_73275_p2() {
    mul_ln1118_1570_fu_73275_p2 = (!mul_ln1118_1570_fu_73275_p0.read().is_01() || !mul_ln1118_1570_fu_73275_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1570_fu_73275_p0.read()) * sc_bigint<5>(mul_ln1118_1570_fu_73275_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1571_fu_73296_p0() {
    mul_ln1118_1571_fu_73296_p0 =  (sc_lv<3>) (sext_ln1116_171_fu_46593_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1571_fu_73296_p1() {
    mul_ln1118_1571_fu_73296_p1 = tmp_1571_reg_112486.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1571_fu_73296_p2() {
    mul_ln1118_1571_fu_73296_p2 = (!mul_ln1118_1571_fu_73296_p0.read().is_01() || !mul_ln1118_1571_fu_73296_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1571_fu_73296_p0.read()) * sc_bigint<5>(mul_ln1118_1571_fu_73296_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1572_fu_73305_p0() {
    mul_ln1118_1572_fu_73305_p0 =  (sc_lv<3>) (sext_ln1116_172_fu_46605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1572_fu_73305_p1() {
    mul_ln1118_1572_fu_73305_p1 = tmp_1572_reg_112491.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1572_fu_73305_p2() {
    mul_ln1118_1572_fu_73305_p2 = (!mul_ln1118_1572_fu_73305_p0.read().is_01() || !mul_ln1118_1572_fu_73305_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1572_fu_73305_p0.read()) * sc_bigint<5>(mul_ln1118_1572_fu_73305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1573_fu_73326_p0() {
    mul_ln1118_1573_fu_73326_p0 =  (sc_lv<3>) (sext_ln1116_173_fu_46629_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1573_fu_73326_p1() {
    mul_ln1118_1573_fu_73326_p1 = tmp_1573_reg_112496.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1573_fu_73326_p2() {
    mul_ln1118_1573_fu_73326_p2 = (!mul_ln1118_1573_fu_73326_p0.read().is_01() || !mul_ln1118_1573_fu_73326_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1573_fu_73326_p0.read()) * sc_bigint<5>(mul_ln1118_1573_fu_73326_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1574_fu_73347_p0() {
    mul_ln1118_1574_fu_73347_p0 =  (sc_lv<3>) (sext_ln1116_174_fu_46653_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1574_fu_73347_p1() {
    mul_ln1118_1574_fu_73347_p1 = tmp_1574_reg_112501.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1574_fu_73347_p2() {
    mul_ln1118_1574_fu_73347_p2 = (!mul_ln1118_1574_fu_73347_p0.read().is_01() || !mul_ln1118_1574_fu_73347_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1574_fu_73347_p0.read()) * sc_bigint<5>(mul_ln1118_1574_fu_73347_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1575_fu_73356_p0() {
    mul_ln1118_1575_fu_73356_p0 =  (sc_lv<3>) (sext_ln1116_175_fu_46665_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1575_fu_73356_p1() {
    mul_ln1118_1575_fu_73356_p1 = tmp_1575_reg_112506.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1575_fu_73356_p2() {
    mul_ln1118_1575_fu_73356_p2 = (!mul_ln1118_1575_fu_73356_p0.read().is_01() || !mul_ln1118_1575_fu_73356_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1575_fu_73356_p0.read()) * sc_bigint<5>(mul_ln1118_1575_fu_73356_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1576_fu_73377_p0() {
    mul_ln1118_1576_fu_73377_p0 =  (sc_lv<3>) (sext_ln1116_176_fu_46689_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1576_fu_73377_p1() {
    mul_ln1118_1576_fu_73377_p1 = tmp_1576_reg_112511.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1576_fu_73377_p2() {
    mul_ln1118_1576_fu_73377_p2 = (!mul_ln1118_1576_fu_73377_p0.read().is_01() || !mul_ln1118_1576_fu_73377_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1576_fu_73377_p0.read()) * sc_bigint<5>(mul_ln1118_1576_fu_73377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1577_fu_73398_p0() {
    mul_ln1118_1577_fu_73398_p0 =  (sc_lv<3>) (sext_ln1116_177_fu_46713_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1577_fu_73398_p1() {
    mul_ln1118_1577_fu_73398_p1 = tmp_1577_reg_112516.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1577_fu_73398_p2() {
    mul_ln1118_1577_fu_73398_p2 = (!mul_ln1118_1577_fu_73398_p0.read().is_01() || !mul_ln1118_1577_fu_73398_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1577_fu_73398_p0.read()) * sc_bigint<5>(mul_ln1118_1577_fu_73398_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1578_fu_73407_p0() {
    mul_ln1118_1578_fu_73407_p0 =  (sc_lv<3>) (sext_ln1116_178_fu_46725_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1578_fu_73407_p1() {
    mul_ln1118_1578_fu_73407_p1 = tmp_1578_reg_112521.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1578_fu_73407_p2() {
    mul_ln1118_1578_fu_73407_p2 = (!mul_ln1118_1578_fu_73407_p0.read().is_01() || !mul_ln1118_1578_fu_73407_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1578_fu_73407_p0.read()) * sc_bigint<5>(mul_ln1118_1578_fu_73407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1579_fu_73428_p0() {
    mul_ln1118_1579_fu_73428_p0 =  (sc_lv<3>) (sext_ln1116_179_fu_46749_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1579_fu_73428_p1() {
    mul_ln1118_1579_fu_73428_p1 = tmp_1579_reg_112526.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1579_fu_73428_p2() {
    mul_ln1118_1579_fu_73428_p2 = (!mul_ln1118_1579_fu_73428_p0.read().is_01() || !mul_ln1118_1579_fu_73428_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1579_fu_73428_p0.read()) * sc_bigint<5>(mul_ln1118_1579_fu_73428_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_157_fu_46329_p0() {
    mul_ln1118_157_fu_46329_p0 =  (sc_lv<3>) (sext_ln1116_157_fu_46323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_157_fu_46329_p1() {
    mul_ln1118_157_fu_46329_p1 = tmp_157_reg_105160.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_157_fu_46329_p2() {
    mul_ln1118_157_fu_46329_p2 = (!mul_ln1118_157_fu_46329_p0.read().is_01() || !mul_ln1118_157_fu_46329_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_157_fu_46329_p0.read()) * sc_bigint<5>(mul_ln1118_157_fu_46329_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1580_fu_73449_p0() {
    mul_ln1118_1580_fu_73449_p0 =  (sc_lv<3>) (sext_ln1116_180_fu_46773_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1580_fu_73449_p1() {
    mul_ln1118_1580_fu_73449_p1 = tmp_1580_reg_112531.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1580_fu_73449_p2() {
    mul_ln1118_1580_fu_73449_p2 = (!mul_ln1118_1580_fu_73449_p0.read().is_01() || !mul_ln1118_1580_fu_73449_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1580_fu_73449_p0.read()) * sc_bigint<5>(mul_ln1118_1580_fu_73449_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1581_fu_73470_p0() {
    mul_ln1118_1581_fu_73470_p0 =  (sc_lv<3>) (sext_ln1116_181_fu_46797_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1581_fu_73470_p1() {
    mul_ln1118_1581_fu_73470_p1 = tmp_1581_reg_112536.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1581_fu_73470_p2() {
    mul_ln1118_1581_fu_73470_p2 = (!mul_ln1118_1581_fu_73470_p0.read().is_01() || !mul_ln1118_1581_fu_73470_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1581_fu_73470_p0.read()) * sc_bigint<5>(mul_ln1118_1581_fu_73470_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1582_fu_73491_p0() {
    mul_ln1118_1582_fu_73491_p0 =  (sc_lv<3>) (sext_ln1116_182_fu_46821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1582_fu_73491_p1() {
    mul_ln1118_1582_fu_73491_p1 = tmp_1582_reg_112541.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1582_fu_73491_p2() {
    mul_ln1118_1582_fu_73491_p2 = (!mul_ln1118_1582_fu_73491_p0.read().is_01() || !mul_ln1118_1582_fu_73491_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1582_fu_73491_p0.read()) * sc_bigint<5>(mul_ln1118_1582_fu_73491_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1583_fu_73512_p0() {
    mul_ln1118_1583_fu_73512_p0 =  (sc_lv<3>) (sext_ln1116_183_fu_46845_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1583_fu_73512_p1() {
    mul_ln1118_1583_fu_73512_p1 = tmp_1583_reg_112546.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1583_fu_73512_p2() {
    mul_ln1118_1583_fu_73512_p2 = (!mul_ln1118_1583_fu_73512_p0.read().is_01() || !mul_ln1118_1583_fu_73512_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1583_fu_73512_p0.read()) * sc_bigint<5>(mul_ln1118_1583_fu_73512_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1584_fu_73533_p0() {
    mul_ln1118_1584_fu_73533_p0 =  (sc_lv<3>) (sext_ln1116_184_fu_46869_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1584_fu_73533_p1() {
    mul_ln1118_1584_fu_73533_p1 = tmp_1584_reg_112551.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1584_fu_73533_p2() {
    mul_ln1118_1584_fu_73533_p2 = (!mul_ln1118_1584_fu_73533_p0.read().is_01() || !mul_ln1118_1584_fu_73533_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1584_fu_73533_p0.read()) * sc_bigint<5>(mul_ln1118_1584_fu_73533_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1585_fu_73542_p0() {
    mul_ln1118_1585_fu_73542_p0 =  (sc_lv<3>) (sext_ln1116_185_fu_46881_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1585_fu_73542_p1() {
    mul_ln1118_1585_fu_73542_p1 = tmp_1585_reg_112556.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1585_fu_73542_p2() {
    mul_ln1118_1585_fu_73542_p2 = (!mul_ln1118_1585_fu_73542_p0.read().is_01() || !mul_ln1118_1585_fu_73542_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1585_fu_73542_p0.read()) * sc_bigint<5>(mul_ln1118_1585_fu_73542_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1586_fu_73563_p0() {
    mul_ln1118_1586_fu_73563_p0 =  (sc_lv<3>) (sext_ln1116_186_fu_46905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1586_fu_73563_p1() {
    mul_ln1118_1586_fu_73563_p1 = tmp_1586_reg_112561.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1586_fu_73563_p2() {
    mul_ln1118_1586_fu_73563_p2 = (!mul_ln1118_1586_fu_73563_p0.read().is_01() || !mul_ln1118_1586_fu_73563_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1586_fu_73563_p0.read()) * sc_bigint<5>(mul_ln1118_1586_fu_73563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1587_fu_73584_p0() {
    mul_ln1118_1587_fu_73584_p0 =  (sc_lv<3>) (sext_ln1116_187_fu_46929_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1587_fu_73584_p1() {
    mul_ln1118_1587_fu_73584_p1 = tmp_1587_reg_112566.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1587_fu_73584_p2() {
    mul_ln1118_1587_fu_73584_p2 = (!mul_ln1118_1587_fu_73584_p0.read().is_01() || !mul_ln1118_1587_fu_73584_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1587_fu_73584_p0.read()) * sc_bigint<5>(mul_ln1118_1587_fu_73584_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1588_fu_73593_p0() {
    mul_ln1118_1588_fu_73593_p0 =  (sc_lv<3>) (sext_ln1116_188_fu_46941_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1588_fu_73593_p1() {
    mul_ln1118_1588_fu_73593_p1 = tmp_1588_reg_112571.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1588_fu_73593_p2() {
    mul_ln1118_1588_fu_73593_p2 = (!mul_ln1118_1588_fu_73593_p0.read().is_01() || !mul_ln1118_1588_fu_73593_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1588_fu_73593_p0.read()) * sc_bigint<5>(mul_ln1118_1588_fu_73593_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1589_fu_73614_p0() {
    mul_ln1118_1589_fu_73614_p0 =  (sc_lv<3>) (sext_ln1116_189_fu_46965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1589_fu_73614_p1() {
    mul_ln1118_1589_fu_73614_p1 = tmp_1589_reg_112576.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1589_fu_73614_p2() {
    mul_ln1118_1589_fu_73614_p2 = (!mul_ln1118_1589_fu_73614_p0.read().is_01() || !mul_ln1118_1589_fu_73614_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1589_fu_73614_p0.read()) * sc_bigint<5>(mul_ln1118_1589_fu_73614_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_158_fu_46353_p0() {
    mul_ln1118_158_fu_46353_p0 =  (sc_lv<3>) (sext_ln1116_158_fu_46347_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_158_fu_46353_p1() {
    mul_ln1118_158_fu_46353_p1 = tmp_158_reg_105170.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_158_fu_46353_p2() {
    mul_ln1118_158_fu_46353_p2 = (!mul_ln1118_158_fu_46353_p0.read().is_01() || !mul_ln1118_158_fu_46353_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_158_fu_46353_p0.read()) * sc_bigint<5>(mul_ln1118_158_fu_46353_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1590_fu_94590_p0() {
    mul_ln1118_1590_fu_94590_p0 =  (sc_lv<3>) (sext_ln1116_190_reg_115018.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1590_fu_94590_p1() {
    mul_ln1118_1590_fu_94590_p1 = tmp_1590_reg_112581_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1590_fu_94590_p2() {
    mul_ln1118_1590_fu_94590_p2 = (!mul_ln1118_1590_fu_94590_p0.read().is_01() || !mul_ln1118_1590_fu_94590_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1590_fu_94590_p0.read()) * sc_bigint<5>(mul_ln1118_1590_fu_94590_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1591_fu_73635_p0() {
    mul_ln1118_1591_fu_73635_p0 =  (sc_lv<3>) (sext_ln1116_191_fu_46992_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1591_fu_73635_p1() {
    mul_ln1118_1591_fu_73635_p1 = tmp_1591_reg_112586.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1591_fu_73635_p2() {
    mul_ln1118_1591_fu_73635_p2 = (!mul_ln1118_1591_fu_73635_p0.read().is_01() || !mul_ln1118_1591_fu_73635_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1591_fu_73635_p0.read()) * sc_bigint<5>(mul_ln1118_1591_fu_73635_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1592_fu_73656_p0() {
    mul_ln1118_1592_fu_73656_p0 =  (sc_lv<3>) (sext_ln1116_192_fu_47016_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1592_fu_73656_p1() {
    mul_ln1118_1592_fu_73656_p1 = tmp_1592_reg_112591.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1592_fu_73656_p2() {
    mul_ln1118_1592_fu_73656_p2 = (!mul_ln1118_1592_fu_73656_p0.read().is_01() || !mul_ln1118_1592_fu_73656_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1592_fu_73656_p0.read()) * sc_bigint<5>(mul_ln1118_1592_fu_73656_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1593_fu_94610_p0() {
    mul_ln1118_1593_fu_94610_p0 =  (sc_lv<3>) (sext_ln1116_193_reg_115031.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1593_fu_94610_p1() {
    mul_ln1118_1593_fu_94610_p1 = tmp_1593_reg_112596_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1593_fu_94610_p2() {
    mul_ln1118_1593_fu_94610_p2 = (!mul_ln1118_1593_fu_94610_p0.read().is_01() || !mul_ln1118_1593_fu_94610_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1593_fu_94610_p0.read()) * sc_bigint<5>(mul_ln1118_1593_fu_94610_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1594_fu_73677_p0() {
    mul_ln1118_1594_fu_73677_p0 =  (sc_lv<3>) (sext_ln1116_194_fu_47043_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1594_fu_73677_p1() {
    mul_ln1118_1594_fu_73677_p1 = tmp_1594_reg_112601.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1594_fu_73677_p2() {
    mul_ln1118_1594_fu_73677_p2 = (!mul_ln1118_1594_fu_73677_p0.read().is_01() || !mul_ln1118_1594_fu_73677_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1594_fu_73677_p0.read()) * sc_bigint<5>(mul_ln1118_1594_fu_73677_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1595_fu_73698_p0() {
    mul_ln1118_1595_fu_73698_p0 =  (sc_lv<3>) (sext_ln1116_195_fu_47067_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1595_fu_73698_p1() {
    mul_ln1118_1595_fu_73698_p1 = tmp_1595_reg_112606.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1595_fu_73698_p2() {
    mul_ln1118_1595_fu_73698_p2 = (!mul_ln1118_1595_fu_73698_p0.read().is_01() || !mul_ln1118_1595_fu_73698_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1595_fu_73698_p0.read()) * sc_bigint<5>(mul_ln1118_1595_fu_73698_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1596_fu_73719_p0() {
    mul_ln1118_1596_fu_73719_p0 =  (sc_lv<3>) (sext_ln1116_196_fu_47091_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1596_fu_73719_p1() {
    mul_ln1118_1596_fu_73719_p1 = tmp_1596_reg_112611.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1596_fu_73719_p2() {
    mul_ln1118_1596_fu_73719_p2 = (!mul_ln1118_1596_fu_73719_p0.read().is_01() || !mul_ln1118_1596_fu_73719_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1596_fu_73719_p0.read()) * sc_bigint<5>(mul_ln1118_1596_fu_73719_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1597_fu_73728_p0() {
    mul_ln1118_1597_fu_73728_p0 =  (sc_lv<3>) (sext_ln1116_197_fu_47103_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1597_fu_73728_p1() {
    mul_ln1118_1597_fu_73728_p1 = tmp_1597_reg_112616.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1597_fu_73728_p2() {
    mul_ln1118_1597_fu_73728_p2 = (!mul_ln1118_1597_fu_73728_p0.read().is_01() || !mul_ln1118_1597_fu_73728_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1597_fu_73728_p0.read()) * sc_bigint<5>(mul_ln1118_1597_fu_73728_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1598_fu_73749_p0() {
    mul_ln1118_1598_fu_73749_p0 =  (sc_lv<3>) (sext_ln1116_198_fu_47127_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1598_fu_73749_p1() {
    mul_ln1118_1598_fu_73749_p1 = tmp_1598_reg_112621.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1598_fu_73749_p2() {
    mul_ln1118_1598_fu_73749_p2 = (!mul_ln1118_1598_fu_73749_p0.read().is_01() || !mul_ln1118_1598_fu_73749_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1598_fu_73749_p0.read()) * sc_bigint<5>(mul_ln1118_1598_fu_73749_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1599_fu_73770_p0() {
    mul_ln1118_1599_fu_73770_p0 =  (sc_lv<3>) (sext_ln1116_199_fu_47151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1599_fu_73770_p1() {
    mul_ln1118_1599_fu_73770_p1 = tmp_1599_reg_112626.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1599_fu_73770_p2() {
    mul_ln1118_1599_fu_73770_p2 = (!mul_ln1118_1599_fu_73770_p0.read().is_01() || !mul_ln1118_1599_fu_73770_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1599_fu_73770_p0.read()) * sc_bigint<5>(mul_ln1118_1599_fu_73770_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_159_fu_46377_p0() {
    mul_ln1118_159_fu_46377_p0 =  (sc_lv<3>) (sext_ln1116_159_fu_46371_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_159_fu_46377_p1() {
    mul_ln1118_159_fu_46377_p1 = tmp_159_reg_105180.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_159_fu_46377_p2() {
    mul_ln1118_159_fu_46377_p2 = (!mul_ln1118_159_fu_46377_p0.read().is_01() || !mul_ln1118_159_fu_46377_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_159_fu_46377_p0.read()) * sc_bigint<5>(mul_ln1118_159_fu_46377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_15_fu_82086_p0() {
    mul_ln1118_15_fu_82086_p0 =  (sc_lv<3>) (sext_ln1116_15_fu_82080_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_15_fu_82086_p1() {
    mul_ln1118_15_fu_82086_p1 = tmp_16_reg_103740_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_15_fu_82086_p2() {
    mul_ln1118_15_fu_82086_p2 = (!mul_ln1118_15_fu_82086_p0.read().is_01() || !mul_ln1118_15_fu_82086_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_15_fu_82086_p0.read()) * sc_bigint<5>(mul_ln1118_15_fu_82086_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1600_fu_73779_p0() {
    mul_ln1118_1600_fu_73779_p0 =  (sc_lv<3>) (sext_ln1116_200_fu_47163_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1600_fu_73779_p1() {
    mul_ln1118_1600_fu_73779_p1 = tmp_1600_reg_112631.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1600_fu_73779_p2() {
    mul_ln1118_1600_fu_73779_p2 = (!mul_ln1118_1600_fu_73779_p0.read().is_01() || !mul_ln1118_1600_fu_73779_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1600_fu_73779_p0.read()) * sc_bigint<5>(mul_ln1118_1600_fu_73779_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1601_fu_73800_p0() {
    mul_ln1118_1601_fu_73800_p0 =  (sc_lv<3>) (sext_ln1116_201_fu_47187_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1601_fu_73800_p1() {
    mul_ln1118_1601_fu_73800_p1 = tmp_1601_reg_112636.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1601_fu_73800_p2() {
    mul_ln1118_1601_fu_73800_p2 = (!mul_ln1118_1601_fu_73800_p0.read().is_01() || !mul_ln1118_1601_fu_73800_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1601_fu_73800_p0.read()) * sc_bigint<5>(mul_ln1118_1601_fu_73800_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1602_fu_73821_p0() {
    mul_ln1118_1602_fu_73821_p0 =  (sc_lv<3>) (sext_ln1116_202_fu_47211_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1602_fu_73821_p1() {
    mul_ln1118_1602_fu_73821_p1 = tmp_1602_reg_112641.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1602_fu_73821_p2() {
    mul_ln1118_1602_fu_73821_p2 = (!mul_ln1118_1602_fu_73821_p0.read().is_01() || !mul_ln1118_1602_fu_73821_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1602_fu_73821_p0.read()) * sc_bigint<5>(mul_ln1118_1602_fu_73821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1603_fu_73830_p0() {
    mul_ln1118_1603_fu_73830_p0 =  (sc_lv<3>) (sext_ln1116_203_fu_47223_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1603_fu_73830_p1() {
    mul_ln1118_1603_fu_73830_p1 = tmp_1603_reg_112646.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1603_fu_73830_p2() {
    mul_ln1118_1603_fu_73830_p2 = (!mul_ln1118_1603_fu_73830_p0.read().is_01() || !mul_ln1118_1603_fu_73830_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1603_fu_73830_p0.read()) * sc_bigint<5>(mul_ln1118_1603_fu_73830_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1604_fu_73851_p0() {
    mul_ln1118_1604_fu_73851_p0 =  (sc_lv<3>) (sext_ln1116_204_fu_47247_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1604_fu_73851_p1() {
    mul_ln1118_1604_fu_73851_p1 = tmp_1604_reg_112651.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1604_fu_73851_p2() {
    mul_ln1118_1604_fu_73851_p2 = (!mul_ln1118_1604_fu_73851_p0.read().is_01() || !mul_ln1118_1604_fu_73851_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1604_fu_73851_p0.read()) * sc_bigint<5>(mul_ln1118_1604_fu_73851_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1605_fu_73872_p0() {
    mul_ln1118_1605_fu_73872_p0 =  (sc_lv<3>) (sext_ln1116_205_fu_47271_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1605_fu_73872_p1() {
    mul_ln1118_1605_fu_73872_p1 = tmp_1605_reg_112656.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1605_fu_73872_p2() {
    mul_ln1118_1605_fu_73872_p2 = (!mul_ln1118_1605_fu_73872_p0.read().is_01() || !mul_ln1118_1605_fu_73872_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1605_fu_73872_p0.read()) * sc_bigint<5>(mul_ln1118_1605_fu_73872_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1606_fu_73893_p0() {
    mul_ln1118_1606_fu_73893_p0 =  (sc_lv<3>) (sext_ln1116_206_fu_47295_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1606_fu_73893_p1() {
    mul_ln1118_1606_fu_73893_p1 = tmp_1606_reg_112661.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1606_fu_73893_p2() {
    mul_ln1118_1606_fu_73893_p2 = (!mul_ln1118_1606_fu_73893_p0.read().is_01() || !mul_ln1118_1606_fu_73893_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1606_fu_73893_p0.read()) * sc_bigint<5>(mul_ln1118_1606_fu_73893_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1607_fu_73914_p0() {
    mul_ln1118_1607_fu_73914_p0 =  (sc_lv<3>) (sext_ln1116_207_fu_47319_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1607_fu_73914_p1() {
    mul_ln1118_1607_fu_73914_p1 = tmp_1607_reg_112666.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1607_fu_73914_p2() {
    mul_ln1118_1607_fu_73914_p2 = (!mul_ln1118_1607_fu_73914_p0.read().is_01() || !mul_ln1118_1607_fu_73914_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1607_fu_73914_p0.read()) * sc_bigint<5>(mul_ln1118_1607_fu_73914_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1608_fu_73935_p0() {
    mul_ln1118_1608_fu_73935_p0 =  (sc_lv<3>) (sext_ln1116_208_fu_47343_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1608_fu_73935_p1() {
    mul_ln1118_1608_fu_73935_p1 = tmp_1608_reg_112671.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1608_fu_73935_p2() {
    mul_ln1118_1608_fu_73935_p2 = (!mul_ln1118_1608_fu_73935_p0.read().is_01() || !mul_ln1118_1608_fu_73935_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1608_fu_73935_p0.read()) * sc_bigint<5>(mul_ln1118_1608_fu_73935_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1609_fu_74388_p0() {
    mul_ln1118_1609_fu_74388_p0 =  (sc_lv<3>) (sext_ln1116_fu_43407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1609_fu_74388_p1() {
    mul_ln1118_1609_fu_74388_p1 = tmp_1609_reg_112676.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1609_fu_74388_p2() {
    mul_ln1118_1609_fu_74388_p2 = (!mul_ln1118_1609_fu_74388_p0.read().is_01() || !mul_ln1118_1609_fu_74388_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1609_fu_74388_p0.read()) * sc_bigint<5>(mul_ln1118_1609_fu_74388_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_160_fu_46389_p0() {
    mul_ln1118_160_fu_46389_p0 =  (sc_lv<3>) (sext_ln1116_160_fu_46383_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_160_fu_46389_p1() {
    mul_ln1118_160_fu_46389_p1 = tmp_160_reg_105190.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_160_fu_46389_p2() {
    mul_ln1118_160_fu_46389_p2 = (!mul_ln1118_160_fu_46389_p0.read().is_01() || !mul_ln1118_160_fu_46389_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_160_fu_46389_p0.read()) * sc_bigint<5>(mul_ln1118_160_fu_46389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1610_fu_74397_p0() {
    mul_ln1118_1610_fu_74397_p0 =  (sc_lv<3>) (sext_ln1116_10_fu_43419_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1610_fu_74397_p1() {
    mul_ln1118_1610_fu_74397_p1 = tmp_1610_reg_112681.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1610_fu_74397_p2() {
    mul_ln1118_1610_fu_74397_p2 = (!mul_ln1118_1610_fu_74397_p0.read().is_01() || !mul_ln1118_1610_fu_74397_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1610_fu_74397_p0.read()) * sc_bigint<5>(mul_ln1118_1610_fu_74397_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1611_fu_74418_p0() {
    mul_ln1118_1611_fu_74418_p0 =  (sc_lv<3>) (sext_ln1116_11_fu_43443_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1611_fu_74418_p1() {
    mul_ln1118_1611_fu_74418_p1 = tmp_1611_reg_112686.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1611_fu_74418_p2() {
    mul_ln1118_1611_fu_74418_p2 = (!mul_ln1118_1611_fu_74418_p0.read().is_01() || !mul_ln1118_1611_fu_74418_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1611_fu_74418_p0.read()) * sc_bigint<5>(mul_ln1118_1611_fu_74418_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1612_fu_74439_p0() {
    mul_ln1118_1612_fu_74439_p0 =  (sc_lv<3>) (sext_ln1116_12_fu_43467_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1612_fu_74439_p1() {
    mul_ln1118_1612_fu_74439_p1 = tmp_1612_reg_112691.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1612_fu_74439_p2() {
    mul_ln1118_1612_fu_74439_p2 = (!mul_ln1118_1612_fu_74439_p0.read().is_01() || !mul_ln1118_1612_fu_74439_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1612_fu_74439_p0.read()) * sc_bigint<5>(mul_ln1118_1612_fu_74439_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1613_fu_74448_p0() {
    mul_ln1118_1613_fu_74448_p0 =  (sc_lv<3>) (sext_ln1116_13_fu_43479_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1613_fu_74448_p1() {
    mul_ln1118_1613_fu_74448_p1 = tmp_1613_reg_112696.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1613_fu_74448_p2() {
    mul_ln1118_1613_fu_74448_p2 = (!mul_ln1118_1613_fu_74448_p0.read().is_01() || !mul_ln1118_1613_fu_74448_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1613_fu_74448_p0.read()) * sc_bigint<5>(mul_ln1118_1613_fu_74448_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1614_fu_74469_p0() {
    mul_ln1118_1614_fu_74469_p0 =  (sc_lv<3>) (sext_ln1116_14_fu_43503_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1614_fu_74469_p1() {
    mul_ln1118_1614_fu_74469_p1 = tmp_1614_reg_112701.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1614_fu_74469_p2() {
    mul_ln1118_1614_fu_74469_p2 = (!mul_ln1118_1614_fu_74469_p0.read().is_01() || !mul_ln1118_1614_fu_74469_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1614_fu_74469_p0.read()) * sc_bigint<5>(mul_ln1118_1614_fu_74469_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1615_fu_95593_p0() {
    mul_ln1118_1615_fu_95593_p0 =  (sc_lv<3>) (sext_ln1116_15_fu_82080_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1615_fu_95593_p1() {
    mul_ln1118_1615_fu_95593_p1 = tmp_1615_reg_112706_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1615_fu_95593_p2() {
    mul_ln1118_1615_fu_95593_p2 = (!mul_ln1118_1615_fu_95593_p0.read().is_01() || !mul_ln1118_1615_fu_95593_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1615_fu_95593_p0.read()) * sc_bigint<5>(mul_ln1118_1615_fu_95593_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1616_fu_74490_p0() {
    mul_ln1118_1616_fu_74490_p0 =  (sc_lv<3>) (sext_ln1116_16_fu_43527_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1616_fu_74490_p1() {
    mul_ln1118_1616_fu_74490_p1 = tmp_1616_reg_112711.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1616_fu_74490_p2() {
    mul_ln1118_1616_fu_74490_p2 = (!mul_ln1118_1616_fu_74490_p0.read().is_01() || !mul_ln1118_1616_fu_74490_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1616_fu_74490_p0.read()) * sc_bigint<5>(mul_ln1118_1616_fu_74490_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1617_fu_74511_p0() {
    mul_ln1118_1617_fu_74511_p0 =  (sc_lv<3>) (sext_ln1116_17_fu_43551_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1617_fu_74511_p1() {
    mul_ln1118_1617_fu_74511_p1 = tmp_1617_reg_112716.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1617_fu_74511_p2() {
    mul_ln1118_1617_fu_74511_p2 = (!mul_ln1118_1617_fu_74511_p0.read().is_01() || !mul_ln1118_1617_fu_74511_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1617_fu_74511_p0.read()) * sc_bigint<5>(mul_ln1118_1617_fu_74511_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1618_fu_95614_p0() {
    mul_ln1118_1618_fu_95614_p0 =  (sc_lv<3>) (sext_ln1116_18_fu_82104_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1618_fu_95614_p1() {
    mul_ln1118_1618_fu_95614_p1 = tmp_1618_reg_112721_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1618_fu_95614_p2() {
    mul_ln1118_1618_fu_95614_p2 = (!mul_ln1118_1618_fu_95614_p0.read().is_01() || !mul_ln1118_1618_fu_95614_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1618_fu_95614_p0.read()) * sc_bigint<5>(mul_ln1118_1618_fu_95614_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1619_fu_74532_p0() {
    mul_ln1118_1619_fu_74532_p0 =  (sc_lv<3>) (sext_ln1116_19_fu_43575_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1619_fu_74532_p1() {
    mul_ln1118_1619_fu_74532_p1 = tmp_1619_reg_112726.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1619_fu_74532_p2() {
    mul_ln1118_1619_fu_74532_p2 = (!mul_ln1118_1619_fu_74532_p0.read().is_01() || !mul_ln1118_1619_fu_74532_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1619_fu_74532_p0.read()) * sc_bigint<5>(mul_ln1118_1619_fu_74532_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_161_fu_46413_p0() {
    mul_ln1118_161_fu_46413_p0 =  (sc_lv<3>) (sext_ln1116_161_fu_46407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_161_fu_46413_p1() {
    mul_ln1118_161_fu_46413_p1 = tmp_161_reg_105200.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_161_fu_46413_p2() {
    mul_ln1118_161_fu_46413_p2 = (!mul_ln1118_161_fu_46413_p0.read().is_01() || !mul_ln1118_161_fu_46413_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_161_fu_46413_p0.read()) * sc_bigint<5>(mul_ln1118_161_fu_46413_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1620_fu_74553_p0() {
    mul_ln1118_1620_fu_74553_p0 =  (sc_lv<3>) (sext_ln1116_20_fu_43599_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1620_fu_74553_p1() {
    mul_ln1118_1620_fu_74553_p1 = tmp_1620_reg_112731.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1620_fu_74553_p2() {
    mul_ln1118_1620_fu_74553_p2 = (!mul_ln1118_1620_fu_74553_p0.read().is_01() || !mul_ln1118_1620_fu_74553_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1620_fu_74553_p0.read()) * sc_bigint<5>(mul_ln1118_1620_fu_74553_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1621_fu_74574_p0() {
    mul_ln1118_1621_fu_74574_p0 =  (sc_lv<3>) (sext_ln1116_21_fu_43623_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1621_fu_74574_p1() {
    mul_ln1118_1621_fu_74574_p1 = tmp_1621_reg_112736.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1621_fu_74574_p2() {
    mul_ln1118_1621_fu_74574_p2 = (!mul_ln1118_1621_fu_74574_p0.read().is_01() || !mul_ln1118_1621_fu_74574_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1621_fu_74574_p0.read()) * sc_bigint<5>(mul_ln1118_1621_fu_74574_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1622_fu_74583_p0() {
    mul_ln1118_1622_fu_74583_p0 =  (sc_lv<3>) (sext_ln1116_22_fu_43635_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1622_fu_74583_p1() {
    mul_ln1118_1622_fu_74583_p1 = tmp_1622_reg_112741.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1622_fu_74583_p2() {
    mul_ln1118_1622_fu_74583_p2 = (!mul_ln1118_1622_fu_74583_p0.read().is_01() || !mul_ln1118_1622_fu_74583_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1622_fu_74583_p0.read()) * sc_bigint<5>(mul_ln1118_1622_fu_74583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1623_fu_74604_p0() {
    mul_ln1118_1623_fu_74604_p0 =  (sc_lv<3>) (sext_ln1116_23_fu_43659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1623_fu_74604_p1() {
    mul_ln1118_1623_fu_74604_p1 = tmp_1623_reg_112746.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1623_fu_74604_p2() {
    mul_ln1118_1623_fu_74604_p2 = (!mul_ln1118_1623_fu_74604_p0.read().is_01() || !mul_ln1118_1623_fu_74604_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1623_fu_74604_p0.read()) * sc_bigint<5>(mul_ln1118_1623_fu_74604_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1624_fu_74625_p0() {
    mul_ln1118_1624_fu_74625_p0 =  (sc_lv<3>) (sext_ln1116_24_fu_43683_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1624_fu_74625_p1() {
    mul_ln1118_1624_fu_74625_p1 = tmp_1624_reg_112751.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1624_fu_74625_p2() {
    mul_ln1118_1624_fu_74625_p2 = (!mul_ln1118_1624_fu_74625_p0.read().is_01() || !mul_ln1118_1624_fu_74625_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1624_fu_74625_p0.read()) * sc_bigint<5>(mul_ln1118_1624_fu_74625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1625_fu_74634_p0() {
    mul_ln1118_1625_fu_74634_p0 =  (sc_lv<3>) (sext_ln1116_25_fu_43695_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1625_fu_74634_p1() {
    mul_ln1118_1625_fu_74634_p1 = tmp_1625_reg_112756.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1625_fu_74634_p2() {
    mul_ln1118_1625_fu_74634_p2 = (!mul_ln1118_1625_fu_74634_p0.read().is_01() || !mul_ln1118_1625_fu_74634_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1625_fu_74634_p0.read()) * sc_bigint<5>(mul_ln1118_1625_fu_74634_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1626_fu_74655_p0() {
    mul_ln1118_1626_fu_74655_p0 =  (sc_lv<3>) (sext_ln1116_26_fu_43719_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1626_fu_74655_p1() {
    mul_ln1118_1626_fu_74655_p1 = tmp_1626_reg_112761.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1626_fu_74655_p2() {
    mul_ln1118_1626_fu_74655_p2 = (!mul_ln1118_1626_fu_74655_p0.read().is_01() || !mul_ln1118_1626_fu_74655_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1626_fu_74655_p0.read()) * sc_bigint<5>(mul_ln1118_1626_fu_74655_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1627_fu_74676_p0() {
    mul_ln1118_1627_fu_74676_p0 =  (sc_lv<3>) (sext_ln1116_27_fu_43743_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1627_fu_74676_p1() {
    mul_ln1118_1627_fu_74676_p1 = tmp_1627_reg_112766.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1627_fu_74676_p2() {
    mul_ln1118_1627_fu_74676_p2 = (!mul_ln1118_1627_fu_74676_p0.read().is_01() || !mul_ln1118_1627_fu_74676_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1627_fu_74676_p0.read()) * sc_bigint<5>(mul_ln1118_1627_fu_74676_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1628_fu_74685_p0() {
    mul_ln1118_1628_fu_74685_p0 =  (sc_lv<3>) (sext_ln1116_28_fu_43755_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1628_fu_74685_p1() {
    mul_ln1118_1628_fu_74685_p1 = tmp_1628_reg_112771.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1628_fu_74685_p2() {
    mul_ln1118_1628_fu_74685_p2 = (!mul_ln1118_1628_fu_74685_p0.read().is_01() || !mul_ln1118_1628_fu_74685_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1628_fu_74685_p0.read()) * sc_bigint<5>(mul_ln1118_1628_fu_74685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1629_fu_74706_p0() {
    mul_ln1118_1629_fu_74706_p0 =  (sc_lv<3>) (sext_ln1116_29_fu_43779_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1629_fu_74706_p1() {
    mul_ln1118_1629_fu_74706_p1 = tmp_1629_reg_112776.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1629_fu_74706_p2() {
    mul_ln1118_1629_fu_74706_p2 = (!mul_ln1118_1629_fu_74706_p0.read().is_01() || !mul_ln1118_1629_fu_74706_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1629_fu_74706_p0.read()) * sc_bigint<5>(mul_ln1118_1629_fu_74706_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_162_fu_46437_p0() {
    mul_ln1118_162_fu_46437_p0 =  (sc_lv<3>) (sext_ln1116_162_fu_46431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_162_fu_46437_p1() {
    mul_ln1118_162_fu_46437_p1 = tmp_162_reg_105210.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_162_fu_46437_p2() {
    mul_ln1118_162_fu_46437_p2 = (!mul_ln1118_162_fu_46437_p0.read().is_01() || !mul_ln1118_162_fu_46437_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_162_fu_46437_p0.read()) * sc_bigint<5>(mul_ln1118_162_fu_46437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1630_fu_74727_p0() {
    mul_ln1118_1630_fu_74727_p0 =  (sc_lv<3>) (sext_ln1116_30_fu_43803_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1630_fu_74727_p1() {
    mul_ln1118_1630_fu_74727_p1 = tmp_1630_reg_112781.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1630_fu_74727_p2() {
    mul_ln1118_1630_fu_74727_p2 = (!mul_ln1118_1630_fu_74727_p0.read().is_01() || !mul_ln1118_1630_fu_74727_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1630_fu_74727_p0.read()) * sc_bigint<5>(mul_ln1118_1630_fu_74727_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1631_fu_74748_p0() {
    mul_ln1118_1631_fu_74748_p0 =  (sc_lv<3>) (sext_ln1116_31_fu_43827_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1631_fu_74748_p1() {
    mul_ln1118_1631_fu_74748_p1 = tmp_1631_reg_112786.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1631_fu_74748_p2() {
    mul_ln1118_1631_fu_74748_p2 = (!mul_ln1118_1631_fu_74748_p0.read().is_01() || !mul_ln1118_1631_fu_74748_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1631_fu_74748_p0.read()) * sc_bigint<5>(mul_ln1118_1631_fu_74748_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1632_fu_74769_p0() {
    mul_ln1118_1632_fu_74769_p0 =  (sc_lv<3>) (sext_ln1116_32_fu_43851_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1632_fu_74769_p1() {
    mul_ln1118_1632_fu_74769_p1 = tmp_1632_reg_112791.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1632_fu_74769_p2() {
    mul_ln1118_1632_fu_74769_p2 = (!mul_ln1118_1632_fu_74769_p0.read().is_01() || !mul_ln1118_1632_fu_74769_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1632_fu_74769_p0.read()) * sc_bigint<5>(mul_ln1118_1632_fu_74769_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1633_fu_74790_p0() {
    mul_ln1118_1633_fu_74790_p0 =  (sc_lv<3>) (sext_ln1116_33_fu_43875_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1633_fu_74790_p1() {
    mul_ln1118_1633_fu_74790_p1 = tmp_1633_reg_112796.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1633_fu_74790_p2() {
    mul_ln1118_1633_fu_74790_p2 = (!mul_ln1118_1633_fu_74790_p0.read().is_01() || !mul_ln1118_1633_fu_74790_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1633_fu_74790_p0.read()) * sc_bigint<5>(mul_ln1118_1633_fu_74790_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1634_fu_74811_p0() {
    mul_ln1118_1634_fu_74811_p0 =  (sc_lv<3>) (sext_ln1116_34_fu_43899_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1634_fu_74811_p1() {
    mul_ln1118_1634_fu_74811_p1 = tmp_1634_reg_112801.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1634_fu_74811_p2() {
    mul_ln1118_1634_fu_74811_p2 = (!mul_ln1118_1634_fu_74811_p0.read().is_01() || !mul_ln1118_1634_fu_74811_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1634_fu_74811_p0.read()) * sc_bigint<5>(mul_ln1118_1634_fu_74811_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1635_fu_74820_p0() {
    mul_ln1118_1635_fu_74820_p0 =  (sc_lv<3>) (sext_ln1116_35_fu_43911_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1635_fu_74820_p1() {
    mul_ln1118_1635_fu_74820_p1 = tmp_1635_reg_112806.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1635_fu_74820_p2() {
    mul_ln1118_1635_fu_74820_p2 = (!mul_ln1118_1635_fu_74820_p0.read().is_01() || !mul_ln1118_1635_fu_74820_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1635_fu_74820_p0.read()) * sc_bigint<5>(mul_ln1118_1635_fu_74820_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1636_fu_74841_p0() {
    mul_ln1118_1636_fu_74841_p0 =  (sc_lv<3>) (sext_ln1116_36_fu_43935_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1636_fu_74841_p1() {
    mul_ln1118_1636_fu_74841_p1 = tmp_1636_reg_112811.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1636_fu_74841_p2() {
    mul_ln1118_1636_fu_74841_p2 = (!mul_ln1118_1636_fu_74841_p0.read().is_01() || !mul_ln1118_1636_fu_74841_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1636_fu_74841_p0.read()) * sc_bigint<5>(mul_ln1118_1636_fu_74841_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1637_fu_74862_p0() {
    mul_ln1118_1637_fu_74862_p0 =  (sc_lv<3>) (sext_ln1116_37_fu_43959_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1637_fu_74862_p1() {
    mul_ln1118_1637_fu_74862_p1 = tmp_1637_reg_112816.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1637_fu_74862_p2() {
    mul_ln1118_1637_fu_74862_p2 = (!mul_ln1118_1637_fu_74862_p0.read().is_01() || !mul_ln1118_1637_fu_74862_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1637_fu_74862_p0.read()) * sc_bigint<5>(mul_ln1118_1637_fu_74862_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1638_fu_74871_p0() {
    mul_ln1118_1638_fu_74871_p0 =  (sc_lv<3>) (sext_ln1116_38_fu_43971_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1638_fu_74871_p1() {
    mul_ln1118_1638_fu_74871_p1 = tmp_1638_reg_112821.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1638_fu_74871_p2() {
    mul_ln1118_1638_fu_74871_p2 = (!mul_ln1118_1638_fu_74871_p0.read().is_01() || !mul_ln1118_1638_fu_74871_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1638_fu_74871_p0.read()) * sc_bigint<5>(mul_ln1118_1638_fu_74871_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1639_fu_74892_p0() {
    mul_ln1118_1639_fu_74892_p0 =  (sc_lv<3>) (sext_ln1116_39_fu_43995_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1639_fu_74892_p1() {
    mul_ln1118_1639_fu_74892_p1 = tmp_1639_reg_112826.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1639_fu_74892_p2() {
    mul_ln1118_1639_fu_74892_p2 = (!mul_ln1118_1639_fu_74892_p0.read().is_01() || !mul_ln1118_1639_fu_74892_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1639_fu_74892_p0.read()) * sc_bigint<5>(mul_ln1118_1639_fu_74892_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_163_fu_46449_p0() {
    mul_ln1118_163_fu_46449_p0 =  (sc_lv<3>) (sext_ln1116_163_fu_46443_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_163_fu_46449_p1() {
    mul_ln1118_163_fu_46449_p1 = tmp_163_reg_105220.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_163_fu_46449_p2() {
    mul_ln1118_163_fu_46449_p2 = (!mul_ln1118_163_fu_46449_p0.read().is_01() || !mul_ln1118_163_fu_46449_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_163_fu_46449_p0.read()) * sc_bigint<5>(mul_ln1118_163_fu_46449_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1640_fu_95690_p0() {
    mul_ln1118_1640_fu_95690_p0 =  (sc_lv<3>) (sext_ln1116_40_reg_114696.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1640_fu_95690_p1() {
    mul_ln1118_1640_fu_95690_p1 = tmp_1640_reg_112831_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1640_fu_95690_p2() {
    mul_ln1118_1640_fu_95690_p2 = (!mul_ln1118_1640_fu_95690_p0.read().is_01() || !mul_ln1118_1640_fu_95690_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1640_fu_95690_p0.read()) * sc_bigint<5>(mul_ln1118_1640_fu_95690_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1641_fu_74913_p0() {
    mul_ln1118_1641_fu_74913_p0 =  (sc_lv<3>) (sext_ln1116_41_fu_44022_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1641_fu_74913_p1() {
    mul_ln1118_1641_fu_74913_p1 = tmp_1641_reg_112836.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1641_fu_74913_p2() {
    mul_ln1118_1641_fu_74913_p2 = (!mul_ln1118_1641_fu_74913_p0.read().is_01() || !mul_ln1118_1641_fu_74913_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1641_fu_74913_p0.read()) * sc_bigint<5>(mul_ln1118_1641_fu_74913_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1642_fu_74934_p0() {
    mul_ln1118_1642_fu_74934_p0 =  (sc_lv<3>) (sext_ln1116_42_fu_44046_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1642_fu_74934_p1() {
    mul_ln1118_1642_fu_74934_p1 = tmp_1642_reg_112841.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1642_fu_74934_p2() {
    mul_ln1118_1642_fu_74934_p2 = (!mul_ln1118_1642_fu_74934_p0.read().is_01() || !mul_ln1118_1642_fu_74934_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1642_fu_74934_p0.read()) * sc_bigint<5>(mul_ln1118_1642_fu_74934_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1643_fu_95710_p0() {
    mul_ln1118_1643_fu_95710_p0 =  (sc_lv<3>) (sext_ln1116_43_reg_114709.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1643_fu_95710_p1() {
    mul_ln1118_1643_fu_95710_p1 = tmp_1643_reg_112846_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1643_fu_95710_p2() {
    mul_ln1118_1643_fu_95710_p2 = (!mul_ln1118_1643_fu_95710_p0.read().is_01() || !mul_ln1118_1643_fu_95710_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1643_fu_95710_p0.read()) * sc_bigint<5>(mul_ln1118_1643_fu_95710_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1644_fu_74955_p0() {
    mul_ln1118_1644_fu_74955_p0 =  (sc_lv<3>) (sext_ln1116_44_fu_44073_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1644_fu_74955_p1() {
    mul_ln1118_1644_fu_74955_p1 = tmp_1644_reg_112851.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1644_fu_74955_p2() {
    mul_ln1118_1644_fu_74955_p2 = (!mul_ln1118_1644_fu_74955_p0.read().is_01() || !mul_ln1118_1644_fu_74955_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1644_fu_74955_p0.read()) * sc_bigint<5>(mul_ln1118_1644_fu_74955_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1645_fu_74976_p0() {
    mul_ln1118_1645_fu_74976_p0 =  (sc_lv<3>) (sext_ln1116_45_fu_44097_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1645_fu_74976_p1() {
    mul_ln1118_1645_fu_74976_p1 = tmp_1645_reg_112856.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1645_fu_74976_p2() {
    mul_ln1118_1645_fu_74976_p2 = (!mul_ln1118_1645_fu_74976_p0.read().is_01() || !mul_ln1118_1645_fu_74976_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1645_fu_74976_p0.read()) * sc_bigint<5>(mul_ln1118_1645_fu_74976_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1646_fu_74997_p0() {
    mul_ln1118_1646_fu_74997_p0 =  (sc_lv<3>) (sext_ln1116_46_fu_44121_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1646_fu_74997_p1() {
    mul_ln1118_1646_fu_74997_p1 = tmp_1646_reg_112861.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1646_fu_74997_p2() {
    mul_ln1118_1646_fu_74997_p2 = (!mul_ln1118_1646_fu_74997_p0.read().is_01() || !mul_ln1118_1646_fu_74997_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1646_fu_74997_p0.read()) * sc_bigint<5>(mul_ln1118_1646_fu_74997_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1647_fu_75006_p0() {
    mul_ln1118_1647_fu_75006_p0 =  (sc_lv<3>) (sext_ln1116_47_fu_44133_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1647_fu_75006_p1() {
    mul_ln1118_1647_fu_75006_p1 = tmp_1647_reg_112866.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1647_fu_75006_p2() {
    mul_ln1118_1647_fu_75006_p2 = (!mul_ln1118_1647_fu_75006_p0.read().is_01() || !mul_ln1118_1647_fu_75006_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1647_fu_75006_p0.read()) * sc_bigint<5>(mul_ln1118_1647_fu_75006_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1648_fu_75027_p0() {
    mul_ln1118_1648_fu_75027_p0 =  (sc_lv<3>) (sext_ln1116_48_fu_44157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1648_fu_75027_p1() {
    mul_ln1118_1648_fu_75027_p1 = tmp_1648_reg_112871.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1648_fu_75027_p2() {
    mul_ln1118_1648_fu_75027_p2 = (!mul_ln1118_1648_fu_75027_p0.read().is_01() || !mul_ln1118_1648_fu_75027_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1648_fu_75027_p0.read()) * sc_bigint<5>(mul_ln1118_1648_fu_75027_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1649_fu_75048_p0() {
    mul_ln1118_1649_fu_75048_p0 =  (sc_lv<3>) (sext_ln1116_49_fu_44181_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1649_fu_75048_p1() {
    mul_ln1118_1649_fu_75048_p1 = tmp_1649_reg_112876.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1649_fu_75048_p2() {
    mul_ln1118_1649_fu_75048_p2 = (!mul_ln1118_1649_fu_75048_p0.read().is_01() || !mul_ln1118_1649_fu_75048_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1649_fu_75048_p0.read()) * sc_bigint<5>(mul_ln1118_1649_fu_75048_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_164_fu_46473_p0() {
    mul_ln1118_164_fu_46473_p0 =  (sc_lv<3>) (sext_ln1116_164_fu_46467_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_164_fu_46473_p1() {
    mul_ln1118_164_fu_46473_p1 = tmp_164_reg_105230.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_164_fu_46473_p2() {
    mul_ln1118_164_fu_46473_p2 = (!mul_ln1118_164_fu_46473_p0.read().is_01() || !mul_ln1118_164_fu_46473_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_164_fu_46473_p0.read()) * sc_bigint<5>(mul_ln1118_164_fu_46473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1650_fu_75057_p0() {
    mul_ln1118_1650_fu_75057_p0 =  (sc_lv<3>) (sext_ln1116_50_fu_44193_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1650_fu_75057_p1() {
    mul_ln1118_1650_fu_75057_p1 = tmp_1650_reg_112881.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1650_fu_75057_p2() {
    mul_ln1118_1650_fu_75057_p2 = (!mul_ln1118_1650_fu_75057_p0.read().is_01() || !mul_ln1118_1650_fu_75057_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1650_fu_75057_p0.read()) * sc_bigint<5>(mul_ln1118_1650_fu_75057_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1651_fu_75078_p0() {
    mul_ln1118_1651_fu_75078_p0 =  (sc_lv<3>) (sext_ln1116_51_fu_44217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1651_fu_75078_p1() {
    mul_ln1118_1651_fu_75078_p1 = tmp_1651_reg_112886.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1651_fu_75078_p2() {
    mul_ln1118_1651_fu_75078_p2 = (!mul_ln1118_1651_fu_75078_p0.read().is_01() || !mul_ln1118_1651_fu_75078_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1651_fu_75078_p0.read()) * sc_bigint<5>(mul_ln1118_1651_fu_75078_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1652_fu_95752_p0() {
    mul_ln1118_1652_fu_95752_p0 =  (sc_lv<3>) (sext_ln1116_52_reg_114732.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1652_fu_95752_p1() {
    mul_ln1118_1652_fu_95752_p1 = tmp_1652_reg_112891_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1652_fu_95752_p2() {
    mul_ln1118_1652_fu_95752_p2 = (!mul_ln1118_1652_fu_95752_p0.read().is_01() || !mul_ln1118_1652_fu_95752_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1652_fu_95752_p0.read()) * sc_bigint<5>(mul_ln1118_1652_fu_95752_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1653_fu_75099_p0() {
    mul_ln1118_1653_fu_75099_p0 =  (sc_lv<3>) (sext_ln1116_53_fu_44244_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1653_fu_75099_p1() {
    mul_ln1118_1653_fu_75099_p1 = tmp_1653_reg_112896.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1653_fu_75099_p2() {
    mul_ln1118_1653_fu_75099_p2 = (!mul_ln1118_1653_fu_75099_p0.read().is_01() || !mul_ln1118_1653_fu_75099_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1653_fu_75099_p0.read()) * sc_bigint<5>(mul_ln1118_1653_fu_75099_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1654_fu_75120_p0() {
    mul_ln1118_1654_fu_75120_p0 =  (sc_lv<3>) (sext_ln1116_54_fu_44268_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1654_fu_75120_p1() {
    mul_ln1118_1654_fu_75120_p1 = tmp_1654_reg_112901.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1654_fu_75120_p2() {
    mul_ln1118_1654_fu_75120_p2 = (!mul_ln1118_1654_fu_75120_p0.read().is_01() || !mul_ln1118_1654_fu_75120_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1654_fu_75120_p0.read()) * sc_bigint<5>(mul_ln1118_1654_fu_75120_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1655_fu_75141_p0() {
    mul_ln1118_1655_fu_75141_p0 =  (sc_lv<3>) (sext_ln1116_55_fu_44292_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1655_fu_75141_p1() {
    mul_ln1118_1655_fu_75141_p1 = tmp_1655_reg_112906.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1655_fu_75141_p2() {
    mul_ln1118_1655_fu_75141_p2 = (!mul_ln1118_1655_fu_75141_p0.read().is_01() || !mul_ln1118_1655_fu_75141_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1655_fu_75141_p0.read()) * sc_bigint<5>(mul_ln1118_1655_fu_75141_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1656_fu_75162_p0() {
    mul_ln1118_1656_fu_75162_p0 =  (sc_lv<3>) (sext_ln1116_56_fu_44316_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1656_fu_75162_p1() {
    mul_ln1118_1656_fu_75162_p1 = tmp_1656_reg_112911.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1656_fu_75162_p2() {
    mul_ln1118_1656_fu_75162_p2 = (!mul_ln1118_1656_fu_75162_p0.read().is_01() || !mul_ln1118_1656_fu_75162_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1656_fu_75162_p0.read()) * sc_bigint<5>(mul_ln1118_1656_fu_75162_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1657_fu_75183_p0() {
    mul_ln1118_1657_fu_75183_p0 =  (sc_lv<3>) (sext_ln1116_57_fu_44340_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1657_fu_75183_p1() {
    mul_ln1118_1657_fu_75183_p1 = tmp_1657_reg_112916.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1657_fu_75183_p2() {
    mul_ln1118_1657_fu_75183_p2 = (!mul_ln1118_1657_fu_75183_p0.read().is_01() || !mul_ln1118_1657_fu_75183_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1657_fu_75183_p0.read()) * sc_bigint<5>(mul_ln1118_1657_fu_75183_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1658_fu_75204_p0() {
    mul_ln1118_1658_fu_75204_p0 =  (sc_lv<3>) (sext_ln1116_58_fu_44364_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1658_fu_75204_p1() {
    mul_ln1118_1658_fu_75204_p1 = tmp_1658_reg_112921.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1658_fu_75204_p2() {
    mul_ln1118_1658_fu_75204_p2 = (!mul_ln1118_1658_fu_75204_p0.read().is_01() || !mul_ln1118_1658_fu_75204_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1658_fu_75204_p0.read()) * sc_bigint<5>(mul_ln1118_1658_fu_75204_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1659_fu_75225_p0() {
    mul_ln1118_1659_fu_75225_p0 =  (sc_lv<3>) (sext_ln1116_59_fu_44388_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1659_fu_75225_p1() {
    mul_ln1118_1659_fu_75225_p1 = tmp_1659_reg_112926.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1659_fu_75225_p2() {
    mul_ln1118_1659_fu_75225_p2 = (!mul_ln1118_1659_fu_75225_p0.read().is_01() || !mul_ln1118_1659_fu_75225_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1659_fu_75225_p0.read()) * sc_bigint<5>(mul_ln1118_1659_fu_75225_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_165_fu_82679_p0() {
    mul_ln1118_165_fu_82679_p0 =  (sc_lv<3>) (sext_ln1116_165_reg_114967.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_165_fu_82679_p1() {
    mul_ln1118_165_fu_82679_p1 = tmp_165_reg_105240_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_165_fu_82679_p2() {
    mul_ln1118_165_fu_82679_p2 = (!mul_ln1118_165_fu_82679_p0.read().is_01() || !mul_ln1118_165_fu_82679_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_165_fu_82679_p0.read()) * sc_bigint<5>(mul_ln1118_165_fu_82679_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1660_fu_75234_p0() {
    mul_ln1118_1660_fu_75234_p0 =  (sc_lv<3>) (sext_ln1116_60_fu_44400_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1660_fu_75234_p1() {
    mul_ln1118_1660_fu_75234_p1 = tmp_1660_reg_112931.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1660_fu_75234_p2() {
    mul_ln1118_1660_fu_75234_p2 = (!mul_ln1118_1660_fu_75234_p0.read().is_01() || !mul_ln1118_1660_fu_75234_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1660_fu_75234_p0.read()) * sc_bigint<5>(mul_ln1118_1660_fu_75234_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1661_fu_75255_p0() {
    mul_ln1118_1661_fu_75255_p0 =  (sc_lv<3>) (sext_ln1116_61_fu_44424_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1661_fu_75255_p1() {
    mul_ln1118_1661_fu_75255_p1 = tmp_1661_reg_112936.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1661_fu_75255_p2() {
    mul_ln1118_1661_fu_75255_p2 = (!mul_ln1118_1661_fu_75255_p0.read().is_01() || !mul_ln1118_1661_fu_75255_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1661_fu_75255_p0.read()) * sc_bigint<5>(mul_ln1118_1661_fu_75255_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1662_fu_75276_p0() {
    mul_ln1118_1662_fu_75276_p0 =  (sc_lv<3>) (sext_ln1116_62_fu_44448_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1662_fu_75276_p1() {
    mul_ln1118_1662_fu_75276_p1 = tmp_1662_reg_112941.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1662_fu_75276_p2() {
    mul_ln1118_1662_fu_75276_p2 = (!mul_ln1118_1662_fu_75276_p0.read().is_01() || !mul_ln1118_1662_fu_75276_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1662_fu_75276_p0.read()) * sc_bigint<5>(mul_ln1118_1662_fu_75276_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1663_fu_75285_p0() {
    mul_ln1118_1663_fu_75285_p0 =  (sc_lv<3>) (sext_ln1116_63_fu_44460_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1663_fu_75285_p1() {
    mul_ln1118_1663_fu_75285_p1 = tmp_1663_reg_112946.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1663_fu_75285_p2() {
    mul_ln1118_1663_fu_75285_p2 = (!mul_ln1118_1663_fu_75285_p0.read().is_01() || !mul_ln1118_1663_fu_75285_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1663_fu_75285_p0.read()) * sc_bigint<5>(mul_ln1118_1663_fu_75285_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1664_fu_75306_p0() {
    mul_ln1118_1664_fu_75306_p0 =  (sc_lv<3>) (sext_ln1116_64_fu_44484_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1664_fu_75306_p1() {
    mul_ln1118_1664_fu_75306_p1 = tmp_1664_reg_112951.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1664_fu_75306_p2() {
    mul_ln1118_1664_fu_75306_p2 = (!mul_ln1118_1664_fu_75306_p0.read().is_01() || !mul_ln1118_1664_fu_75306_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1664_fu_75306_p0.read()) * sc_bigint<5>(mul_ln1118_1664_fu_75306_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1665_fu_95794_p0() {
    mul_ln1118_1665_fu_95794_p0 =  (sc_lv<3>) (sext_ln1116_65_reg_114755.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1665_fu_95794_p1() {
    mul_ln1118_1665_fu_95794_p1 = tmp_1665_reg_112956_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1665_fu_95794_p2() {
    mul_ln1118_1665_fu_95794_p2 = (!mul_ln1118_1665_fu_95794_p0.read().is_01() || !mul_ln1118_1665_fu_95794_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1665_fu_95794_p0.read()) * sc_bigint<5>(mul_ln1118_1665_fu_95794_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1666_fu_75327_p0() {
    mul_ln1118_1666_fu_75327_p0 =  (sc_lv<3>) (sext_ln1116_66_fu_44511_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1666_fu_75327_p1() {
    mul_ln1118_1666_fu_75327_p1 = tmp_1666_reg_112961.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1666_fu_75327_p2() {
    mul_ln1118_1666_fu_75327_p2 = (!mul_ln1118_1666_fu_75327_p0.read().is_01() || !mul_ln1118_1666_fu_75327_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1666_fu_75327_p0.read()) * sc_bigint<5>(mul_ln1118_1666_fu_75327_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1667_fu_75348_p0() {
    mul_ln1118_1667_fu_75348_p0 =  (sc_lv<3>) (sext_ln1116_67_fu_44535_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1667_fu_75348_p1() {
    mul_ln1118_1667_fu_75348_p1 = tmp_1667_reg_112966.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1667_fu_75348_p2() {
    mul_ln1118_1667_fu_75348_p2 = (!mul_ln1118_1667_fu_75348_p0.read().is_01() || !mul_ln1118_1667_fu_75348_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1667_fu_75348_p0.read()) * sc_bigint<5>(mul_ln1118_1667_fu_75348_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1668_fu_95814_p0() {
    mul_ln1118_1668_fu_95814_p0 =  (sc_lv<3>) (sext_ln1116_68_reg_114768.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1668_fu_95814_p1() {
    mul_ln1118_1668_fu_95814_p1 = tmp_1668_reg_112971_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1668_fu_95814_p2() {
    mul_ln1118_1668_fu_95814_p2 = (!mul_ln1118_1668_fu_95814_p0.read().is_01() || !mul_ln1118_1668_fu_95814_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1668_fu_95814_p0.read()) * sc_bigint<5>(mul_ln1118_1668_fu_95814_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1669_fu_75369_p0() {
    mul_ln1118_1669_fu_75369_p0 =  (sc_lv<3>) (sext_ln1116_69_fu_44562_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1669_fu_75369_p1() {
    mul_ln1118_1669_fu_75369_p1 = tmp_1669_reg_112976.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1669_fu_75369_p2() {
    mul_ln1118_1669_fu_75369_p2 = (!mul_ln1118_1669_fu_75369_p0.read().is_01() || !mul_ln1118_1669_fu_75369_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1669_fu_75369_p0.read()) * sc_bigint<5>(mul_ln1118_1669_fu_75369_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_166_fu_46500_p0() {
    mul_ln1118_166_fu_46500_p0 =  (sc_lv<3>) (sext_ln1116_166_fu_46494_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_166_fu_46500_p1() {
    mul_ln1118_166_fu_46500_p1 = tmp_166_reg_105250.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_166_fu_46500_p2() {
    mul_ln1118_166_fu_46500_p2 = (!mul_ln1118_166_fu_46500_p0.read().is_01() || !mul_ln1118_166_fu_46500_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_166_fu_46500_p0.read()) * sc_bigint<5>(mul_ln1118_166_fu_46500_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1670_fu_75390_p0() {
    mul_ln1118_1670_fu_75390_p0 =  (sc_lv<3>) (sext_ln1116_70_fu_44586_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1670_fu_75390_p1() {
    mul_ln1118_1670_fu_75390_p1 = tmp_1670_reg_112981.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1670_fu_75390_p2() {
    mul_ln1118_1670_fu_75390_p2 = (!mul_ln1118_1670_fu_75390_p0.read().is_01() || !mul_ln1118_1670_fu_75390_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1670_fu_75390_p0.read()) * sc_bigint<5>(mul_ln1118_1670_fu_75390_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1671_fu_75411_p0() {
    mul_ln1118_1671_fu_75411_p0 =  (sc_lv<3>) (sext_ln1116_71_fu_44610_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1671_fu_75411_p1() {
    mul_ln1118_1671_fu_75411_p1 = tmp_1671_reg_112986.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1671_fu_75411_p2() {
    mul_ln1118_1671_fu_75411_p2 = (!mul_ln1118_1671_fu_75411_p0.read().is_01() || !mul_ln1118_1671_fu_75411_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1671_fu_75411_p0.read()) * sc_bigint<5>(mul_ln1118_1671_fu_75411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1672_fu_75420_p0() {
    mul_ln1118_1672_fu_75420_p0 =  (sc_lv<3>) (sext_ln1116_72_fu_44622_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1672_fu_75420_p1() {
    mul_ln1118_1672_fu_75420_p1 = tmp_1672_reg_112991.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1672_fu_75420_p2() {
    mul_ln1118_1672_fu_75420_p2 = (!mul_ln1118_1672_fu_75420_p0.read().is_01() || !mul_ln1118_1672_fu_75420_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1672_fu_75420_p0.read()) * sc_bigint<5>(mul_ln1118_1672_fu_75420_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1673_fu_75441_p0() {
    mul_ln1118_1673_fu_75441_p0 =  (sc_lv<3>) (sext_ln1116_73_fu_44646_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1673_fu_75441_p1() {
    mul_ln1118_1673_fu_75441_p1 = tmp_1673_reg_112996.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1673_fu_75441_p2() {
    mul_ln1118_1673_fu_75441_p2 = (!mul_ln1118_1673_fu_75441_p0.read().is_01() || !mul_ln1118_1673_fu_75441_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1673_fu_75441_p0.read()) * sc_bigint<5>(mul_ln1118_1673_fu_75441_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1674_fu_75462_p0() {
    mul_ln1118_1674_fu_75462_p0 =  (sc_lv<3>) (sext_ln1116_74_fu_44670_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1674_fu_75462_p1() {
    mul_ln1118_1674_fu_75462_p1 = tmp_1674_reg_113001.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1674_fu_75462_p2() {
    mul_ln1118_1674_fu_75462_p2 = (!mul_ln1118_1674_fu_75462_p0.read().is_01() || !mul_ln1118_1674_fu_75462_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1674_fu_75462_p0.read()) * sc_bigint<5>(mul_ln1118_1674_fu_75462_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1675_fu_75471_p0() {
    mul_ln1118_1675_fu_75471_p0 =  (sc_lv<3>) (sext_ln1116_75_fu_44682_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1675_fu_75471_p1() {
    mul_ln1118_1675_fu_75471_p1 = tmp_1675_reg_113006.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1675_fu_75471_p2() {
    mul_ln1118_1675_fu_75471_p2 = (!mul_ln1118_1675_fu_75471_p0.read().is_01() || !mul_ln1118_1675_fu_75471_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1675_fu_75471_p0.read()) * sc_bigint<5>(mul_ln1118_1675_fu_75471_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1676_fu_75492_p0() {
    mul_ln1118_1676_fu_75492_p0 =  (sc_lv<3>) (sext_ln1116_76_fu_44706_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1676_fu_75492_p1() {
    mul_ln1118_1676_fu_75492_p1 = tmp_1676_reg_113011.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1676_fu_75492_p2() {
    mul_ln1118_1676_fu_75492_p2 = (!mul_ln1118_1676_fu_75492_p0.read().is_01() || !mul_ln1118_1676_fu_75492_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1676_fu_75492_p0.read()) * sc_bigint<5>(mul_ln1118_1676_fu_75492_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1677_fu_75513_p0() {
    mul_ln1118_1677_fu_75513_p0 =  (sc_lv<3>) (sext_ln1116_77_fu_44730_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1677_fu_75513_p1() {
    mul_ln1118_1677_fu_75513_p1 = tmp_1677_reg_113016.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1677_fu_75513_p2() {
    mul_ln1118_1677_fu_75513_p2 = (!mul_ln1118_1677_fu_75513_p0.read().is_01() || !mul_ln1118_1677_fu_75513_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1677_fu_75513_p0.read()) * sc_bigint<5>(mul_ln1118_1677_fu_75513_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1678_fu_75522_p0() {
    mul_ln1118_1678_fu_75522_p0 =  (sc_lv<3>) (sext_ln1116_78_fu_44742_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1678_fu_75522_p1() {
    mul_ln1118_1678_fu_75522_p1 = tmp_1678_reg_113021.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1678_fu_75522_p2() {
    mul_ln1118_1678_fu_75522_p2 = (!mul_ln1118_1678_fu_75522_p0.read().is_01() || !mul_ln1118_1678_fu_75522_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1678_fu_75522_p0.read()) * sc_bigint<5>(mul_ln1118_1678_fu_75522_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1679_fu_75543_p0() {
    mul_ln1118_1679_fu_75543_p0 =  (sc_lv<3>) (sext_ln1116_79_fu_44766_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1679_fu_75543_p1() {
    mul_ln1118_1679_fu_75543_p1 = tmp_1679_reg_113026.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1679_fu_75543_p2() {
    mul_ln1118_1679_fu_75543_p2 = (!mul_ln1118_1679_fu_75543_p0.read().is_01() || !mul_ln1118_1679_fu_75543_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1679_fu_75543_p0.read()) * sc_bigint<5>(mul_ln1118_1679_fu_75543_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_167_fu_46524_p0() {
    mul_ln1118_167_fu_46524_p0 =  (sc_lv<3>) (sext_ln1116_167_fu_46518_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_167_fu_46524_p1() {
    mul_ln1118_167_fu_46524_p1 = tmp_167_reg_105260.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_167_fu_46524_p2() {
    mul_ln1118_167_fu_46524_p2 = (!mul_ln1118_167_fu_46524_p0.read().is_01() || !mul_ln1118_167_fu_46524_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_167_fu_46524_p0.read()) * sc_bigint<5>(mul_ln1118_167_fu_46524_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1680_fu_75564_p0() {
    mul_ln1118_1680_fu_75564_p0 =  (sc_lv<3>) (sext_ln1116_80_fu_44790_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1680_fu_75564_p1() {
    mul_ln1118_1680_fu_75564_p1 = tmp_1680_reg_113031.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1680_fu_75564_p2() {
    mul_ln1118_1680_fu_75564_p2 = (!mul_ln1118_1680_fu_75564_p0.read().is_01() || !mul_ln1118_1680_fu_75564_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1680_fu_75564_p0.read()) * sc_bigint<5>(mul_ln1118_1680_fu_75564_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1681_fu_75585_p0() {
    mul_ln1118_1681_fu_75585_p0 =  (sc_lv<3>) (sext_ln1116_81_fu_44814_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1681_fu_75585_p1() {
    mul_ln1118_1681_fu_75585_p1 = tmp_1681_reg_113036.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1681_fu_75585_p2() {
    mul_ln1118_1681_fu_75585_p2 = (!mul_ln1118_1681_fu_75585_p0.read().is_01() || !mul_ln1118_1681_fu_75585_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1681_fu_75585_p0.read()) * sc_bigint<5>(mul_ln1118_1681_fu_75585_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1682_fu_75606_p0() {
    mul_ln1118_1682_fu_75606_p0 =  (sc_lv<3>) (sext_ln1116_82_fu_44838_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1682_fu_75606_p1() {
    mul_ln1118_1682_fu_75606_p1 = tmp_1682_reg_113041.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1682_fu_75606_p2() {
    mul_ln1118_1682_fu_75606_p2 = (!mul_ln1118_1682_fu_75606_p0.read().is_01() || !mul_ln1118_1682_fu_75606_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1682_fu_75606_p0.read()) * sc_bigint<5>(mul_ln1118_1682_fu_75606_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1683_fu_75627_p0() {
    mul_ln1118_1683_fu_75627_p0 =  (sc_lv<3>) (sext_ln1116_83_fu_44862_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1683_fu_75627_p1() {
    mul_ln1118_1683_fu_75627_p1 = tmp_1683_reg_113046.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1683_fu_75627_p2() {
    mul_ln1118_1683_fu_75627_p2 = (!mul_ln1118_1683_fu_75627_p0.read().is_01() || !mul_ln1118_1683_fu_75627_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1683_fu_75627_p0.read()) * sc_bigint<5>(mul_ln1118_1683_fu_75627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1684_fu_75648_p0() {
    mul_ln1118_1684_fu_75648_p0 =  (sc_lv<3>) (sext_ln1116_84_fu_44886_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1684_fu_75648_p1() {
    mul_ln1118_1684_fu_75648_p1 = tmp_1684_reg_113051.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1684_fu_75648_p2() {
    mul_ln1118_1684_fu_75648_p2 = (!mul_ln1118_1684_fu_75648_p0.read().is_01() || !mul_ln1118_1684_fu_75648_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1684_fu_75648_p0.read()) * sc_bigint<5>(mul_ln1118_1684_fu_75648_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1685_fu_75657_p0() {
    mul_ln1118_1685_fu_75657_p0 =  (sc_lv<3>) (sext_ln1116_85_fu_44898_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1685_fu_75657_p1() {
    mul_ln1118_1685_fu_75657_p1 = tmp_1685_reg_113056.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1685_fu_75657_p2() {
    mul_ln1118_1685_fu_75657_p2 = (!mul_ln1118_1685_fu_75657_p0.read().is_01() || !mul_ln1118_1685_fu_75657_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1685_fu_75657_p0.read()) * sc_bigint<5>(mul_ln1118_1685_fu_75657_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1686_fu_75678_p0() {
    mul_ln1118_1686_fu_75678_p0 =  (sc_lv<3>) (sext_ln1116_86_fu_44922_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1686_fu_75678_p1() {
    mul_ln1118_1686_fu_75678_p1 = tmp_1686_reg_113061.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1686_fu_75678_p2() {
    mul_ln1118_1686_fu_75678_p2 = (!mul_ln1118_1686_fu_75678_p0.read().is_01() || !mul_ln1118_1686_fu_75678_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1686_fu_75678_p0.read()) * sc_bigint<5>(mul_ln1118_1686_fu_75678_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1687_fu_75699_p0() {
    mul_ln1118_1687_fu_75699_p0 =  (sc_lv<3>) (sext_ln1116_87_fu_44946_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1687_fu_75699_p1() {
    mul_ln1118_1687_fu_75699_p1 = tmp_1687_reg_113066.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1687_fu_75699_p2() {
    mul_ln1118_1687_fu_75699_p2 = (!mul_ln1118_1687_fu_75699_p0.read().is_01() || !mul_ln1118_1687_fu_75699_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1687_fu_75699_p0.read()) * sc_bigint<5>(mul_ln1118_1687_fu_75699_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1688_fu_75708_p0() {
    mul_ln1118_1688_fu_75708_p0 =  (sc_lv<3>) (sext_ln1116_88_fu_44958_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1688_fu_75708_p1() {
    mul_ln1118_1688_fu_75708_p1 = tmp_1688_reg_113071.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1688_fu_75708_p2() {
    mul_ln1118_1688_fu_75708_p2 = (!mul_ln1118_1688_fu_75708_p0.read().is_01() || !mul_ln1118_1688_fu_75708_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1688_fu_75708_p0.read()) * sc_bigint<5>(mul_ln1118_1688_fu_75708_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1689_fu_75729_p0() {
    mul_ln1118_1689_fu_75729_p0 =  (sc_lv<3>) (sext_ln1116_89_fu_44982_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1689_fu_75729_p1() {
    mul_ln1118_1689_fu_75729_p1 = tmp_1689_reg_113076.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1689_fu_75729_p2() {
    mul_ln1118_1689_fu_75729_p2 = (!mul_ln1118_1689_fu_75729_p0.read().is_01() || !mul_ln1118_1689_fu_75729_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1689_fu_75729_p0.read()) * sc_bigint<5>(mul_ln1118_1689_fu_75729_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_168_fu_82699_p0() {
    mul_ln1118_168_fu_82699_p0 =  (sc_lv<3>) (sext_ln1116_168_reg_114980.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_168_fu_82699_p1() {
    mul_ln1118_168_fu_82699_p1 = tmp_168_reg_105270_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_168_fu_82699_p2() {
    mul_ln1118_168_fu_82699_p2 = (!mul_ln1118_168_fu_82699_p0.read().is_01() || !mul_ln1118_168_fu_82699_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_168_fu_82699_p0.read()) * sc_bigint<5>(mul_ln1118_168_fu_82699_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1690_fu_95889_p0() {
    mul_ln1118_1690_fu_95889_p0 =  (sc_lv<3>) (sext_ln1116_90_reg_114806.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1690_fu_95889_p1() {
    mul_ln1118_1690_fu_95889_p1 = tmp_1690_reg_113081_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1690_fu_95889_p2() {
    mul_ln1118_1690_fu_95889_p2 = (!mul_ln1118_1690_fu_95889_p0.read().is_01() || !mul_ln1118_1690_fu_95889_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1690_fu_95889_p0.read()) * sc_bigint<5>(mul_ln1118_1690_fu_95889_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1691_fu_75750_p0() {
    mul_ln1118_1691_fu_75750_p0 =  (sc_lv<3>) (sext_ln1116_91_fu_45009_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1691_fu_75750_p1() {
    mul_ln1118_1691_fu_75750_p1 = tmp_1691_reg_113086.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1691_fu_75750_p2() {
    mul_ln1118_1691_fu_75750_p2 = (!mul_ln1118_1691_fu_75750_p0.read().is_01() || !mul_ln1118_1691_fu_75750_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1691_fu_75750_p0.read()) * sc_bigint<5>(mul_ln1118_1691_fu_75750_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1692_fu_75771_p0() {
    mul_ln1118_1692_fu_75771_p0 =  (sc_lv<3>) (sext_ln1116_92_fu_45033_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1692_fu_75771_p1() {
    mul_ln1118_1692_fu_75771_p1 = tmp_1692_reg_113091.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1692_fu_75771_p2() {
    mul_ln1118_1692_fu_75771_p2 = (!mul_ln1118_1692_fu_75771_p0.read().is_01() || !mul_ln1118_1692_fu_75771_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1692_fu_75771_p0.read()) * sc_bigint<5>(mul_ln1118_1692_fu_75771_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1693_fu_95909_p0() {
    mul_ln1118_1693_fu_95909_p0 =  (sc_lv<3>) (sext_ln1116_93_reg_114819.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1693_fu_95909_p1() {
    mul_ln1118_1693_fu_95909_p1 = tmp_1693_reg_113096_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1693_fu_95909_p2() {
    mul_ln1118_1693_fu_95909_p2 = (!mul_ln1118_1693_fu_95909_p0.read().is_01() || !mul_ln1118_1693_fu_95909_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1693_fu_95909_p0.read()) * sc_bigint<5>(mul_ln1118_1693_fu_95909_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1694_fu_75792_p0() {
    mul_ln1118_1694_fu_75792_p0 =  (sc_lv<3>) (sext_ln1116_94_fu_45060_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1694_fu_75792_p1() {
    mul_ln1118_1694_fu_75792_p1 = tmp_1694_reg_113101.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1694_fu_75792_p2() {
    mul_ln1118_1694_fu_75792_p2 = (!mul_ln1118_1694_fu_75792_p0.read().is_01() || !mul_ln1118_1694_fu_75792_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1694_fu_75792_p0.read()) * sc_bigint<5>(mul_ln1118_1694_fu_75792_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1695_fu_75813_p0() {
    mul_ln1118_1695_fu_75813_p0 =  (sc_lv<3>) (sext_ln1116_95_fu_45084_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1695_fu_75813_p1() {
    mul_ln1118_1695_fu_75813_p1 = tmp_1695_reg_113106.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1695_fu_75813_p2() {
    mul_ln1118_1695_fu_75813_p2 = (!mul_ln1118_1695_fu_75813_p0.read().is_01() || !mul_ln1118_1695_fu_75813_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1695_fu_75813_p0.read()) * sc_bigint<5>(mul_ln1118_1695_fu_75813_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1696_fu_75834_p0() {
    mul_ln1118_1696_fu_75834_p0 =  (sc_lv<3>) (sext_ln1116_96_fu_45108_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1696_fu_75834_p1() {
    mul_ln1118_1696_fu_75834_p1 = tmp_1696_reg_113111.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1696_fu_75834_p2() {
    mul_ln1118_1696_fu_75834_p2 = (!mul_ln1118_1696_fu_75834_p0.read().is_01() || !mul_ln1118_1696_fu_75834_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1696_fu_75834_p0.read()) * sc_bigint<5>(mul_ln1118_1696_fu_75834_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1697_fu_75843_p0() {
    mul_ln1118_1697_fu_75843_p0 =  (sc_lv<3>) (sext_ln1116_97_fu_45120_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1697_fu_75843_p1() {
    mul_ln1118_1697_fu_75843_p1 = tmp_1697_reg_113116.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1697_fu_75843_p2() {
    mul_ln1118_1697_fu_75843_p2 = (!mul_ln1118_1697_fu_75843_p0.read().is_01() || !mul_ln1118_1697_fu_75843_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1697_fu_75843_p0.read()) * sc_bigint<5>(mul_ln1118_1697_fu_75843_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1698_fu_75864_p0() {
    mul_ln1118_1698_fu_75864_p0 =  (sc_lv<3>) (sext_ln1116_98_fu_45144_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1698_fu_75864_p1() {
    mul_ln1118_1698_fu_75864_p1 = tmp_1698_reg_113121.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1698_fu_75864_p2() {
    mul_ln1118_1698_fu_75864_p2 = (!mul_ln1118_1698_fu_75864_p0.read().is_01() || !mul_ln1118_1698_fu_75864_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1698_fu_75864_p0.read()) * sc_bigint<5>(mul_ln1118_1698_fu_75864_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1699_fu_75885_p0() {
    mul_ln1118_1699_fu_75885_p0 =  (sc_lv<3>) (sext_ln1116_99_fu_45168_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1699_fu_75885_p1() {
    mul_ln1118_1699_fu_75885_p1 = tmp_1699_reg_113126.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1699_fu_75885_p2() {
    mul_ln1118_1699_fu_75885_p2 = (!mul_ln1118_1699_fu_75885_p0.read().is_01() || !mul_ln1118_1699_fu_75885_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1699_fu_75885_p0.read()) * sc_bigint<5>(mul_ln1118_1699_fu_75885_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_169_fu_46551_p0() {
    mul_ln1118_169_fu_46551_p0 =  (sc_lv<3>) (sext_ln1116_169_fu_46545_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_169_fu_46551_p1() {
    mul_ln1118_169_fu_46551_p1 = tmp_169_reg_105280.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_169_fu_46551_p2() {
    mul_ln1118_169_fu_46551_p2 = (!mul_ln1118_169_fu_46551_p0.read().is_01() || !mul_ln1118_169_fu_46551_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_169_fu_46551_p0.read()) * sc_bigint<5>(mul_ln1118_169_fu_46551_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_16_fu_43533_p0() {
    mul_ln1118_16_fu_43533_p0 =  (sc_lv<3>) (sext_ln1116_16_fu_43527_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_16_fu_43533_p1() {
    mul_ln1118_16_fu_43533_p1 = tmp_17_reg_103750.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_16_fu_43533_p2() {
    mul_ln1118_16_fu_43533_p2 = (!mul_ln1118_16_fu_43533_p0.read().is_01() || !mul_ln1118_16_fu_43533_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_16_fu_43533_p0.read()) * sc_bigint<5>(mul_ln1118_16_fu_43533_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1700_fu_75894_p0() {
    mul_ln1118_1700_fu_75894_p0 =  (sc_lv<3>) (sext_ln1116_100_fu_45180_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1700_fu_75894_p1() {
    mul_ln1118_1700_fu_75894_p1 = tmp_1700_reg_113131.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1700_fu_75894_p2() {
    mul_ln1118_1700_fu_75894_p2 = (!mul_ln1118_1700_fu_75894_p0.read().is_01() || !mul_ln1118_1700_fu_75894_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1700_fu_75894_p0.read()) * sc_bigint<5>(mul_ln1118_1700_fu_75894_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1701_fu_75915_p0() {
    mul_ln1118_1701_fu_75915_p0 =  (sc_lv<3>) (sext_ln1116_101_fu_45204_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1701_fu_75915_p1() {
    mul_ln1118_1701_fu_75915_p1 = tmp_1701_reg_113136.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1701_fu_75915_p2() {
    mul_ln1118_1701_fu_75915_p2 = (!mul_ln1118_1701_fu_75915_p0.read().is_01() || !mul_ln1118_1701_fu_75915_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1701_fu_75915_p0.read()) * sc_bigint<5>(mul_ln1118_1701_fu_75915_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1702_fu_75936_p0() {
    mul_ln1118_1702_fu_75936_p0 =  (sc_lv<3>) (sext_ln1116_102_fu_45228_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1702_fu_75936_p1() {
    mul_ln1118_1702_fu_75936_p1 = tmp_1702_reg_113141.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1702_fu_75936_p2() {
    mul_ln1118_1702_fu_75936_p2 = (!mul_ln1118_1702_fu_75936_p0.read().is_01() || !mul_ln1118_1702_fu_75936_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1702_fu_75936_p0.read()) * sc_bigint<5>(mul_ln1118_1702_fu_75936_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1703_fu_75945_p0() {
    mul_ln1118_1703_fu_75945_p0 =  (sc_lv<3>) (sext_ln1116_103_fu_45240_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1703_fu_75945_p1() {
    mul_ln1118_1703_fu_75945_p1 = tmp_1703_reg_113146.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1703_fu_75945_p2() {
    mul_ln1118_1703_fu_75945_p2 = (!mul_ln1118_1703_fu_75945_p0.read().is_01() || !mul_ln1118_1703_fu_75945_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1703_fu_75945_p0.read()) * sc_bigint<5>(mul_ln1118_1703_fu_75945_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1704_fu_75966_p0() {
    mul_ln1118_1704_fu_75966_p0 =  (sc_lv<3>) (sext_ln1116_104_fu_45264_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1704_fu_75966_p1() {
    mul_ln1118_1704_fu_75966_p1 = tmp_1704_reg_113151.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1704_fu_75966_p2() {
    mul_ln1118_1704_fu_75966_p2 = (!mul_ln1118_1704_fu_75966_p0.read().is_01() || !mul_ln1118_1704_fu_75966_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1704_fu_75966_p0.read()) * sc_bigint<5>(mul_ln1118_1704_fu_75966_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1705_fu_75987_p0() {
    mul_ln1118_1705_fu_75987_p0 =  (sc_lv<3>) (sext_ln1116_105_fu_45288_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1705_fu_75987_p1() {
    mul_ln1118_1705_fu_75987_p1 = tmp_1705_reg_113156.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1705_fu_75987_p2() {
    mul_ln1118_1705_fu_75987_p2 = (!mul_ln1118_1705_fu_75987_p0.read().is_01() || !mul_ln1118_1705_fu_75987_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1705_fu_75987_p0.read()) * sc_bigint<5>(mul_ln1118_1705_fu_75987_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1706_fu_76008_p0() {
    mul_ln1118_1706_fu_76008_p0 =  (sc_lv<3>) (sext_ln1116_106_fu_45312_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1706_fu_76008_p1() {
    mul_ln1118_1706_fu_76008_p1 = tmp_1706_reg_113161.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1706_fu_76008_p2() {
    mul_ln1118_1706_fu_76008_p2 = (!mul_ln1118_1706_fu_76008_p0.read().is_01() || !mul_ln1118_1706_fu_76008_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1706_fu_76008_p0.read()) * sc_bigint<5>(mul_ln1118_1706_fu_76008_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1707_fu_76029_p0() {
    mul_ln1118_1707_fu_76029_p0 =  (sc_lv<3>) (sext_ln1116_107_fu_45336_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1707_fu_76029_p1() {
    mul_ln1118_1707_fu_76029_p1 = tmp_1707_reg_113166.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1707_fu_76029_p2() {
    mul_ln1118_1707_fu_76029_p2 = (!mul_ln1118_1707_fu_76029_p0.read().is_01() || !mul_ln1118_1707_fu_76029_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1707_fu_76029_p0.read()) * sc_bigint<5>(mul_ln1118_1707_fu_76029_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1708_fu_76050_p0() {
    mul_ln1118_1708_fu_76050_p0 =  (sc_lv<3>) (sext_ln1116_108_fu_45360_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1708_fu_76050_p1() {
    mul_ln1118_1708_fu_76050_p1 = tmp_1708_reg_113171.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1708_fu_76050_p2() {
    mul_ln1118_1708_fu_76050_p2 = (!mul_ln1118_1708_fu_76050_p0.read().is_01() || !mul_ln1118_1708_fu_76050_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1708_fu_76050_p0.read()) * sc_bigint<5>(mul_ln1118_1708_fu_76050_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1709_fu_76071_p0() {
    mul_ln1118_1709_fu_76071_p0 =  (sc_lv<3>) (sext_ln1116_109_fu_45384_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1709_fu_76071_p1() {
    mul_ln1118_1709_fu_76071_p1 = tmp_1709_reg_113176.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1709_fu_76071_p2() {
    mul_ln1118_1709_fu_76071_p2 = (!mul_ln1118_1709_fu_76071_p0.read().is_01() || !mul_ln1118_1709_fu_76071_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1709_fu_76071_p0.read()) * sc_bigint<5>(mul_ln1118_1709_fu_76071_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_170_fu_46575_p0() {
    mul_ln1118_170_fu_46575_p0 =  (sc_lv<3>) (sext_ln1116_170_fu_46569_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_170_fu_46575_p1() {
    mul_ln1118_170_fu_46575_p1 = tmp_170_reg_105290.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_170_fu_46575_p2() {
    mul_ln1118_170_fu_46575_p2 = (!mul_ln1118_170_fu_46575_p0.read().is_01() || !mul_ln1118_170_fu_46575_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_170_fu_46575_p0.read()) * sc_bigint<5>(mul_ln1118_170_fu_46575_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1710_fu_76080_p0() {
    mul_ln1118_1710_fu_76080_p0 =  (sc_lv<3>) (sext_ln1116_110_fu_45396_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1710_fu_76080_p1() {
    mul_ln1118_1710_fu_76080_p1 = tmp_1710_reg_113181.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1710_fu_76080_p2() {
    mul_ln1118_1710_fu_76080_p2 = (!mul_ln1118_1710_fu_76080_p0.read().is_01() || !mul_ln1118_1710_fu_76080_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1710_fu_76080_p0.read()) * sc_bigint<5>(mul_ln1118_1710_fu_76080_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1711_fu_76101_p0() {
    mul_ln1118_1711_fu_76101_p0 =  (sc_lv<3>) (sext_ln1116_111_fu_45420_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1711_fu_76101_p1() {
    mul_ln1118_1711_fu_76101_p1 = tmp_1711_reg_113186.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1711_fu_76101_p2() {
    mul_ln1118_1711_fu_76101_p2 = (!mul_ln1118_1711_fu_76101_p0.read().is_01() || !mul_ln1118_1711_fu_76101_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1711_fu_76101_p0.read()) * sc_bigint<5>(mul_ln1118_1711_fu_76101_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1712_fu_76122_p0() {
    mul_ln1118_1712_fu_76122_p0 =  (sc_lv<3>) (sext_ln1116_112_fu_45444_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1712_fu_76122_p1() {
    mul_ln1118_1712_fu_76122_p1 = tmp_1712_reg_113191.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1712_fu_76122_p2() {
    mul_ln1118_1712_fu_76122_p2 = (!mul_ln1118_1712_fu_76122_p0.read().is_01() || !mul_ln1118_1712_fu_76122_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1712_fu_76122_p0.read()) * sc_bigint<5>(mul_ln1118_1712_fu_76122_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1713_fu_76131_p0() {
    mul_ln1118_1713_fu_76131_p0 =  (sc_lv<3>) (sext_ln1116_113_fu_45456_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1713_fu_76131_p1() {
    mul_ln1118_1713_fu_76131_p1 = tmp_1713_reg_113196.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1713_fu_76131_p2() {
    mul_ln1118_1713_fu_76131_p2 = (!mul_ln1118_1713_fu_76131_p0.read().is_01() || !mul_ln1118_1713_fu_76131_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1713_fu_76131_p0.read()) * sc_bigint<5>(mul_ln1118_1713_fu_76131_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1714_fu_76152_p0() {
    mul_ln1118_1714_fu_76152_p0 =  (sc_lv<3>) (sext_ln1116_114_fu_45480_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1714_fu_76152_p1() {
    mul_ln1118_1714_fu_76152_p1 = tmp_1714_reg_113201.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1714_fu_76152_p2() {
    mul_ln1118_1714_fu_76152_p2 = (!mul_ln1118_1714_fu_76152_p0.read().is_01() || !mul_ln1118_1714_fu_76152_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1714_fu_76152_p0.read()) * sc_bigint<5>(mul_ln1118_1714_fu_76152_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1715_fu_95984_p0() {
    mul_ln1118_1715_fu_95984_p0 =  (sc_lv<3>) (sext_ln1116_115_reg_114857.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1715_fu_95984_p1() {
    mul_ln1118_1715_fu_95984_p1 = tmp_1715_reg_113206_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1715_fu_95984_p2() {
    mul_ln1118_1715_fu_95984_p2 = (!mul_ln1118_1715_fu_95984_p0.read().is_01() || !mul_ln1118_1715_fu_95984_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1715_fu_95984_p0.read()) * sc_bigint<5>(mul_ln1118_1715_fu_95984_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1716_fu_76173_p0() {
    mul_ln1118_1716_fu_76173_p0 =  (sc_lv<3>) (sext_ln1116_116_fu_45507_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1716_fu_76173_p1() {
    mul_ln1118_1716_fu_76173_p1 = tmp_1716_reg_113211.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1716_fu_76173_p2() {
    mul_ln1118_1716_fu_76173_p2 = (!mul_ln1118_1716_fu_76173_p0.read().is_01() || !mul_ln1118_1716_fu_76173_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1716_fu_76173_p0.read()) * sc_bigint<5>(mul_ln1118_1716_fu_76173_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1717_fu_76194_p0() {
    mul_ln1118_1717_fu_76194_p0 =  (sc_lv<3>) (sext_ln1116_117_fu_45531_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1717_fu_76194_p1() {
    mul_ln1118_1717_fu_76194_p1 = tmp_1717_reg_113216.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1717_fu_76194_p2() {
    mul_ln1118_1717_fu_76194_p2 = (!mul_ln1118_1717_fu_76194_p0.read().is_01() || !mul_ln1118_1717_fu_76194_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1717_fu_76194_p0.read()) * sc_bigint<5>(mul_ln1118_1717_fu_76194_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1718_fu_96004_p0() {
    mul_ln1118_1718_fu_96004_p0 =  (sc_lv<3>) (sext_ln1116_118_reg_114870.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1718_fu_96004_p1() {
    mul_ln1118_1718_fu_96004_p1 = tmp_1718_reg_113221_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1718_fu_96004_p2() {
    mul_ln1118_1718_fu_96004_p2 = (!mul_ln1118_1718_fu_96004_p0.read().is_01() || !mul_ln1118_1718_fu_96004_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1718_fu_96004_p0.read()) * sc_bigint<5>(mul_ln1118_1718_fu_96004_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1719_fu_76215_p0() {
    mul_ln1118_1719_fu_76215_p0 =  (sc_lv<3>) (sext_ln1116_119_fu_45558_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1719_fu_76215_p1() {
    mul_ln1118_1719_fu_76215_p1 = tmp_1719_reg_113226.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1719_fu_76215_p2() {
    mul_ln1118_1719_fu_76215_p2 = (!mul_ln1118_1719_fu_76215_p0.read().is_01() || !mul_ln1118_1719_fu_76215_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1719_fu_76215_p0.read()) * sc_bigint<5>(mul_ln1118_1719_fu_76215_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_171_fu_46599_p0() {
    mul_ln1118_171_fu_46599_p0 =  (sc_lv<3>) (sext_ln1116_171_fu_46593_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_171_fu_46599_p1() {
    mul_ln1118_171_fu_46599_p1 = tmp_171_reg_105300.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_171_fu_46599_p2() {
    mul_ln1118_171_fu_46599_p2 = (!mul_ln1118_171_fu_46599_p0.read().is_01() || !mul_ln1118_171_fu_46599_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_171_fu_46599_p0.read()) * sc_bigint<5>(mul_ln1118_171_fu_46599_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1720_fu_76236_p0() {
    mul_ln1118_1720_fu_76236_p0 =  (sc_lv<3>) (sext_ln1116_120_fu_45582_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1720_fu_76236_p1() {
    mul_ln1118_1720_fu_76236_p1 = tmp_1720_reg_113231.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1720_fu_76236_p2() {
    mul_ln1118_1720_fu_76236_p2 = (!mul_ln1118_1720_fu_76236_p0.read().is_01() || !mul_ln1118_1720_fu_76236_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1720_fu_76236_p0.read()) * sc_bigint<5>(mul_ln1118_1720_fu_76236_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1721_fu_76257_p0() {
    mul_ln1118_1721_fu_76257_p0 =  (sc_lv<3>) (sext_ln1116_121_fu_45606_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1721_fu_76257_p1() {
    mul_ln1118_1721_fu_76257_p1 = tmp_1721_reg_113236.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1721_fu_76257_p2() {
    mul_ln1118_1721_fu_76257_p2 = (!mul_ln1118_1721_fu_76257_p0.read().is_01() || !mul_ln1118_1721_fu_76257_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1721_fu_76257_p0.read()) * sc_bigint<5>(mul_ln1118_1721_fu_76257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1722_fu_76266_p0() {
    mul_ln1118_1722_fu_76266_p0 =  (sc_lv<3>) (sext_ln1116_122_fu_45618_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1722_fu_76266_p1() {
    mul_ln1118_1722_fu_76266_p1 = tmp_1722_reg_113241.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1722_fu_76266_p2() {
    mul_ln1118_1722_fu_76266_p2 = (!mul_ln1118_1722_fu_76266_p0.read().is_01() || !mul_ln1118_1722_fu_76266_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1722_fu_76266_p0.read()) * sc_bigint<5>(mul_ln1118_1722_fu_76266_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1723_fu_76287_p0() {
    mul_ln1118_1723_fu_76287_p0 =  (sc_lv<3>) (sext_ln1116_123_fu_45642_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1723_fu_76287_p1() {
    mul_ln1118_1723_fu_76287_p1 = tmp_1723_reg_113246.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1723_fu_76287_p2() {
    mul_ln1118_1723_fu_76287_p2 = (!mul_ln1118_1723_fu_76287_p0.read().is_01() || !mul_ln1118_1723_fu_76287_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1723_fu_76287_p0.read()) * sc_bigint<5>(mul_ln1118_1723_fu_76287_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1724_fu_76308_p0() {
    mul_ln1118_1724_fu_76308_p0 =  (sc_lv<3>) (sext_ln1116_124_fu_45666_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1724_fu_76308_p1() {
    mul_ln1118_1724_fu_76308_p1 = tmp_1724_reg_113251.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1724_fu_76308_p2() {
    mul_ln1118_1724_fu_76308_p2 = (!mul_ln1118_1724_fu_76308_p0.read().is_01() || !mul_ln1118_1724_fu_76308_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1724_fu_76308_p0.read()) * sc_bigint<5>(mul_ln1118_1724_fu_76308_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1725_fu_76317_p0() {
    mul_ln1118_1725_fu_76317_p0 =  (sc_lv<3>) (sext_ln1116_125_fu_45678_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1725_fu_76317_p1() {
    mul_ln1118_1725_fu_76317_p1 = tmp_1725_reg_113256.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1725_fu_76317_p2() {
    mul_ln1118_1725_fu_76317_p2 = (!mul_ln1118_1725_fu_76317_p0.read().is_01() || !mul_ln1118_1725_fu_76317_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1725_fu_76317_p0.read()) * sc_bigint<5>(mul_ln1118_1725_fu_76317_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1726_fu_76338_p0() {
    mul_ln1118_1726_fu_76338_p0 =  (sc_lv<3>) (sext_ln1116_126_fu_45702_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1726_fu_76338_p1() {
    mul_ln1118_1726_fu_76338_p1 = tmp_1726_reg_113261.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1726_fu_76338_p2() {
    mul_ln1118_1726_fu_76338_p2 = (!mul_ln1118_1726_fu_76338_p0.read().is_01() || !mul_ln1118_1726_fu_76338_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1726_fu_76338_p0.read()) * sc_bigint<5>(mul_ln1118_1726_fu_76338_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1727_fu_76359_p0() {
    mul_ln1118_1727_fu_76359_p0 =  (sc_lv<3>) (sext_ln1116_127_fu_45726_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1727_fu_76359_p1() {
    mul_ln1118_1727_fu_76359_p1 = tmp_1727_reg_113266.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1727_fu_76359_p2() {
    mul_ln1118_1727_fu_76359_p2 = (!mul_ln1118_1727_fu_76359_p0.read().is_01() || !mul_ln1118_1727_fu_76359_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1727_fu_76359_p0.read()) * sc_bigint<5>(mul_ln1118_1727_fu_76359_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1728_fu_76368_p0() {
    mul_ln1118_1728_fu_76368_p0 =  (sc_lv<3>) (sext_ln1116_128_fu_45738_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1728_fu_76368_p1() {
    mul_ln1118_1728_fu_76368_p1 = tmp_1728_reg_113271.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1728_fu_76368_p2() {
    mul_ln1118_1728_fu_76368_p2 = (!mul_ln1118_1728_fu_76368_p0.read().is_01() || !mul_ln1118_1728_fu_76368_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1728_fu_76368_p0.read()) * sc_bigint<5>(mul_ln1118_1728_fu_76368_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1729_fu_76389_p0() {
    mul_ln1118_1729_fu_76389_p0 =  (sc_lv<3>) (sext_ln1116_129_fu_45762_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1729_fu_76389_p1() {
    mul_ln1118_1729_fu_76389_p1 = tmp_1729_reg_113276.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1729_fu_76389_p2() {
    mul_ln1118_1729_fu_76389_p2 = (!mul_ln1118_1729_fu_76389_p0.read().is_01() || !mul_ln1118_1729_fu_76389_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1729_fu_76389_p0.read()) * sc_bigint<5>(mul_ln1118_1729_fu_76389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_172_fu_46611_p0() {
    mul_ln1118_172_fu_46611_p0 =  (sc_lv<3>) (sext_ln1116_172_fu_46605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_172_fu_46611_p1() {
    mul_ln1118_172_fu_46611_p1 = tmp_172_reg_105310.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_172_fu_46611_p2() {
    mul_ln1118_172_fu_46611_p2 = (!mul_ln1118_172_fu_46611_p0.read().is_01() || !mul_ln1118_172_fu_46611_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_172_fu_46611_p0.read()) * sc_bigint<5>(mul_ln1118_172_fu_46611_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1730_fu_76410_p0() {
    mul_ln1118_1730_fu_76410_p0 =  (sc_lv<3>) (sext_ln1116_130_fu_45786_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1730_fu_76410_p1() {
    mul_ln1118_1730_fu_76410_p1 = tmp_1730_reg_113281.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1730_fu_76410_p2() {
    mul_ln1118_1730_fu_76410_p2 = (!mul_ln1118_1730_fu_76410_p0.read().is_01() || !mul_ln1118_1730_fu_76410_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1730_fu_76410_p0.read()) * sc_bigint<5>(mul_ln1118_1730_fu_76410_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1731_fu_76431_p0() {
    mul_ln1118_1731_fu_76431_p0 =  (sc_lv<3>) (sext_ln1116_131_fu_45810_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1731_fu_76431_p1() {
    mul_ln1118_1731_fu_76431_p1 = tmp_1731_reg_113286.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1731_fu_76431_p2() {
    mul_ln1118_1731_fu_76431_p2 = (!mul_ln1118_1731_fu_76431_p0.read().is_01() || !mul_ln1118_1731_fu_76431_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1731_fu_76431_p0.read()) * sc_bigint<5>(mul_ln1118_1731_fu_76431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1732_fu_76452_p0() {
    mul_ln1118_1732_fu_76452_p0 =  (sc_lv<3>) (sext_ln1116_132_fu_45834_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1732_fu_76452_p1() {
    mul_ln1118_1732_fu_76452_p1 = tmp_1732_reg_113291.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1732_fu_76452_p2() {
    mul_ln1118_1732_fu_76452_p2 = (!mul_ln1118_1732_fu_76452_p0.read().is_01() || !mul_ln1118_1732_fu_76452_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1732_fu_76452_p0.read()) * sc_bigint<5>(mul_ln1118_1732_fu_76452_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1733_fu_76473_p0() {
    mul_ln1118_1733_fu_76473_p0 =  (sc_lv<3>) (sext_ln1116_133_fu_45858_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1733_fu_76473_p1() {
    mul_ln1118_1733_fu_76473_p1 = tmp_1733_reg_113296.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1733_fu_76473_p2() {
    mul_ln1118_1733_fu_76473_p2 = (!mul_ln1118_1733_fu_76473_p0.read().is_01() || !mul_ln1118_1733_fu_76473_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1733_fu_76473_p0.read()) * sc_bigint<5>(mul_ln1118_1733_fu_76473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1734_fu_76494_p0() {
    mul_ln1118_1734_fu_76494_p0 =  (sc_lv<3>) (sext_ln1116_134_fu_45882_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1734_fu_76494_p1() {
    mul_ln1118_1734_fu_76494_p1 = tmp_1734_reg_113301.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1734_fu_76494_p2() {
    mul_ln1118_1734_fu_76494_p2 = (!mul_ln1118_1734_fu_76494_p0.read().is_01() || !mul_ln1118_1734_fu_76494_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1734_fu_76494_p0.read()) * sc_bigint<5>(mul_ln1118_1734_fu_76494_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1735_fu_76503_p0() {
    mul_ln1118_1735_fu_76503_p0 =  (sc_lv<3>) (sext_ln1116_135_fu_45894_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1735_fu_76503_p1() {
    mul_ln1118_1735_fu_76503_p1 = tmp_1735_reg_113306.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1735_fu_76503_p2() {
    mul_ln1118_1735_fu_76503_p2 = (!mul_ln1118_1735_fu_76503_p0.read().is_01() || !mul_ln1118_1735_fu_76503_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1735_fu_76503_p0.read()) * sc_bigint<5>(mul_ln1118_1735_fu_76503_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1736_fu_76524_p0() {
    mul_ln1118_1736_fu_76524_p0 =  (sc_lv<3>) (sext_ln1116_136_fu_45918_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1736_fu_76524_p1() {
    mul_ln1118_1736_fu_76524_p1 = tmp_1736_reg_113311.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1736_fu_76524_p2() {
    mul_ln1118_1736_fu_76524_p2 = (!mul_ln1118_1736_fu_76524_p0.read().is_01() || !mul_ln1118_1736_fu_76524_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1736_fu_76524_p0.read()) * sc_bigint<5>(mul_ln1118_1736_fu_76524_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1737_fu_76545_p0() {
    mul_ln1118_1737_fu_76545_p0 =  (sc_lv<3>) (sext_ln1116_137_fu_45942_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1737_fu_76545_p1() {
    mul_ln1118_1737_fu_76545_p1 = tmp_1737_reg_113316.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1737_fu_76545_p2() {
    mul_ln1118_1737_fu_76545_p2 = (!mul_ln1118_1737_fu_76545_p0.read().is_01() || !mul_ln1118_1737_fu_76545_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1737_fu_76545_p0.read()) * sc_bigint<5>(mul_ln1118_1737_fu_76545_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1738_fu_76554_p0() {
    mul_ln1118_1738_fu_76554_p0 =  (sc_lv<3>) (sext_ln1116_138_fu_45954_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1738_fu_76554_p1() {
    mul_ln1118_1738_fu_76554_p1 = tmp_1738_reg_113321.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1738_fu_76554_p2() {
    mul_ln1118_1738_fu_76554_p2 = (!mul_ln1118_1738_fu_76554_p0.read().is_01() || !mul_ln1118_1738_fu_76554_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1738_fu_76554_p0.read()) * sc_bigint<5>(mul_ln1118_1738_fu_76554_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1739_fu_76575_p0() {
    mul_ln1118_1739_fu_76575_p0 =  (sc_lv<3>) (sext_ln1116_139_fu_45978_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1739_fu_76575_p1() {
    mul_ln1118_1739_fu_76575_p1 = tmp_1739_reg_113326.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1739_fu_76575_p2() {
    mul_ln1118_1739_fu_76575_p2 = (!mul_ln1118_1739_fu_76575_p0.read().is_01() || !mul_ln1118_1739_fu_76575_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1739_fu_76575_p0.read()) * sc_bigint<5>(mul_ln1118_1739_fu_76575_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_173_fu_46635_p0() {
    mul_ln1118_173_fu_46635_p0 =  (sc_lv<3>) (sext_ln1116_173_fu_46629_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_173_fu_46635_p1() {
    mul_ln1118_173_fu_46635_p1 = tmp_173_reg_105320.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_173_fu_46635_p2() {
    mul_ln1118_173_fu_46635_p2 = (!mul_ln1118_173_fu_46635_p0.read().is_01() || !mul_ln1118_173_fu_46635_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_173_fu_46635_p0.read()) * sc_bigint<5>(mul_ln1118_173_fu_46635_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1740_fu_96079_p0() {
    mul_ln1118_1740_fu_96079_p0 =  (sc_lv<3>) (sext_ln1116_140_reg_114908.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1740_fu_96079_p1() {
    mul_ln1118_1740_fu_96079_p1 = tmp_1740_reg_113331_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1740_fu_96079_p2() {
    mul_ln1118_1740_fu_96079_p2 = (!mul_ln1118_1740_fu_96079_p0.read().is_01() || !mul_ln1118_1740_fu_96079_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1740_fu_96079_p0.read()) * sc_bigint<5>(mul_ln1118_1740_fu_96079_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1741_fu_76596_p0() {
    mul_ln1118_1741_fu_76596_p0 =  (sc_lv<3>) (sext_ln1116_141_fu_46005_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1741_fu_76596_p1() {
    mul_ln1118_1741_fu_76596_p1 = tmp_1741_reg_113336.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1741_fu_76596_p2() {
    mul_ln1118_1741_fu_76596_p2 = (!mul_ln1118_1741_fu_76596_p0.read().is_01() || !mul_ln1118_1741_fu_76596_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1741_fu_76596_p0.read()) * sc_bigint<5>(mul_ln1118_1741_fu_76596_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1742_fu_76617_p0() {
    mul_ln1118_1742_fu_76617_p0 =  (sc_lv<3>) (sext_ln1116_142_fu_46029_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1742_fu_76617_p1() {
    mul_ln1118_1742_fu_76617_p1 = tmp_1742_reg_113341.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1742_fu_76617_p2() {
    mul_ln1118_1742_fu_76617_p2 = (!mul_ln1118_1742_fu_76617_p0.read().is_01() || !mul_ln1118_1742_fu_76617_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1742_fu_76617_p0.read()) * sc_bigint<5>(mul_ln1118_1742_fu_76617_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1743_fu_96099_p0() {
    mul_ln1118_1743_fu_96099_p0 =  (sc_lv<3>) (sext_ln1116_143_reg_114921.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1743_fu_96099_p1() {
    mul_ln1118_1743_fu_96099_p1 = tmp_1743_reg_113346_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1743_fu_96099_p2() {
    mul_ln1118_1743_fu_96099_p2 = (!mul_ln1118_1743_fu_96099_p0.read().is_01() || !mul_ln1118_1743_fu_96099_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1743_fu_96099_p0.read()) * sc_bigint<5>(mul_ln1118_1743_fu_96099_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1744_fu_76638_p0() {
    mul_ln1118_1744_fu_76638_p0 =  (sc_lv<3>) (sext_ln1116_144_fu_46056_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1744_fu_76638_p1() {
    mul_ln1118_1744_fu_76638_p1 = tmp_1744_reg_113351.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1744_fu_76638_p2() {
    mul_ln1118_1744_fu_76638_p2 = (!mul_ln1118_1744_fu_76638_p0.read().is_01() || !mul_ln1118_1744_fu_76638_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1744_fu_76638_p0.read()) * sc_bigint<5>(mul_ln1118_1744_fu_76638_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1745_fu_76659_p0() {
    mul_ln1118_1745_fu_76659_p0 =  (sc_lv<3>) (sext_ln1116_145_fu_46080_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1745_fu_76659_p1() {
    mul_ln1118_1745_fu_76659_p1 = tmp_1745_reg_113356.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1745_fu_76659_p2() {
    mul_ln1118_1745_fu_76659_p2 = (!mul_ln1118_1745_fu_76659_p0.read().is_01() || !mul_ln1118_1745_fu_76659_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1745_fu_76659_p0.read()) * sc_bigint<5>(mul_ln1118_1745_fu_76659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1746_fu_76680_p0() {
    mul_ln1118_1746_fu_76680_p0 =  (sc_lv<3>) (sext_ln1116_146_fu_46104_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1746_fu_76680_p1() {
    mul_ln1118_1746_fu_76680_p1 = tmp_1746_reg_113361.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1746_fu_76680_p2() {
    mul_ln1118_1746_fu_76680_p2 = (!mul_ln1118_1746_fu_76680_p0.read().is_01() || !mul_ln1118_1746_fu_76680_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1746_fu_76680_p0.read()) * sc_bigint<5>(mul_ln1118_1746_fu_76680_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1747_fu_76689_p0() {
    mul_ln1118_1747_fu_76689_p0 =  (sc_lv<3>) (sext_ln1116_147_fu_46116_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1747_fu_76689_p1() {
    mul_ln1118_1747_fu_76689_p1 = tmp_1747_reg_113366.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1747_fu_76689_p2() {
    mul_ln1118_1747_fu_76689_p2 = (!mul_ln1118_1747_fu_76689_p0.read().is_01() || !mul_ln1118_1747_fu_76689_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1747_fu_76689_p0.read()) * sc_bigint<5>(mul_ln1118_1747_fu_76689_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1748_fu_76710_p0() {
    mul_ln1118_1748_fu_76710_p0 =  (sc_lv<3>) (sext_ln1116_148_fu_46140_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1748_fu_76710_p1() {
    mul_ln1118_1748_fu_76710_p1 = tmp_1748_reg_113371.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1748_fu_76710_p2() {
    mul_ln1118_1748_fu_76710_p2 = (!mul_ln1118_1748_fu_76710_p0.read().is_01() || !mul_ln1118_1748_fu_76710_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1748_fu_76710_p0.read()) * sc_bigint<5>(mul_ln1118_1748_fu_76710_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1749_fu_76731_p0() {
    mul_ln1118_1749_fu_76731_p0 =  (sc_lv<3>) (sext_ln1116_149_fu_46164_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1749_fu_76731_p1() {
    mul_ln1118_1749_fu_76731_p1 = tmp_1749_reg_113376.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1749_fu_76731_p2() {
    mul_ln1118_1749_fu_76731_p2 = (!mul_ln1118_1749_fu_76731_p0.read().is_01() || !mul_ln1118_1749_fu_76731_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1749_fu_76731_p0.read()) * sc_bigint<5>(mul_ln1118_1749_fu_76731_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_174_fu_46659_p0() {
    mul_ln1118_174_fu_46659_p0 =  (sc_lv<3>) (sext_ln1116_174_fu_46653_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_174_fu_46659_p1() {
    mul_ln1118_174_fu_46659_p1 = tmp_174_reg_105330.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_174_fu_46659_p2() {
    mul_ln1118_174_fu_46659_p2 = (!mul_ln1118_174_fu_46659_p0.read().is_01() || !mul_ln1118_174_fu_46659_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_174_fu_46659_p0.read()) * sc_bigint<5>(mul_ln1118_174_fu_46659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1750_fu_76740_p0() {
    mul_ln1118_1750_fu_76740_p0 =  (sc_lv<3>) (sext_ln1116_150_fu_46176_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1750_fu_76740_p1() {
    mul_ln1118_1750_fu_76740_p1 = tmp_1750_reg_113381.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1750_fu_76740_p2() {
    mul_ln1118_1750_fu_76740_p2 = (!mul_ln1118_1750_fu_76740_p0.read().is_01() || !mul_ln1118_1750_fu_76740_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1750_fu_76740_p0.read()) * sc_bigint<5>(mul_ln1118_1750_fu_76740_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1751_fu_76761_p0() {
    mul_ln1118_1751_fu_76761_p0 =  (sc_lv<3>) (sext_ln1116_151_fu_46200_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1751_fu_76761_p1() {
    mul_ln1118_1751_fu_76761_p1 = tmp_1751_reg_113386.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1751_fu_76761_p2() {
    mul_ln1118_1751_fu_76761_p2 = (!mul_ln1118_1751_fu_76761_p0.read().is_01() || !mul_ln1118_1751_fu_76761_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1751_fu_76761_p0.read()) * sc_bigint<5>(mul_ln1118_1751_fu_76761_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1752_fu_96141_p0() {
    mul_ln1118_1752_fu_96141_p0 =  (sc_lv<3>) (sext_ln1116_152_reg_114944.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1752_fu_96141_p1() {
    mul_ln1118_1752_fu_96141_p1 = tmp_1752_reg_113391_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1752_fu_96141_p2() {
    mul_ln1118_1752_fu_96141_p2 = (!mul_ln1118_1752_fu_96141_p0.read().is_01() || !mul_ln1118_1752_fu_96141_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1752_fu_96141_p0.read()) * sc_bigint<5>(mul_ln1118_1752_fu_96141_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1753_fu_76782_p0() {
    mul_ln1118_1753_fu_76782_p0 =  (sc_lv<3>) (sext_ln1116_153_fu_46227_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1753_fu_76782_p1() {
    mul_ln1118_1753_fu_76782_p1 = tmp_1753_reg_113396.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1753_fu_76782_p2() {
    mul_ln1118_1753_fu_76782_p2 = (!mul_ln1118_1753_fu_76782_p0.read().is_01() || !mul_ln1118_1753_fu_76782_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1753_fu_76782_p0.read()) * sc_bigint<5>(mul_ln1118_1753_fu_76782_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1754_fu_76803_p0() {
    mul_ln1118_1754_fu_76803_p0 =  (sc_lv<3>) (sext_ln1116_154_fu_46251_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1754_fu_76803_p1() {
    mul_ln1118_1754_fu_76803_p1 = tmp_1754_reg_113401.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1754_fu_76803_p2() {
    mul_ln1118_1754_fu_76803_p2 = (!mul_ln1118_1754_fu_76803_p0.read().is_01() || !mul_ln1118_1754_fu_76803_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1754_fu_76803_p0.read()) * sc_bigint<5>(mul_ln1118_1754_fu_76803_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1755_fu_76824_p0() {
    mul_ln1118_1755_fu_76824_p0 =  (sc_lv<3>) (sext_ln1116_155_fu_46275_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1755_fu_76824_p1() {
    mul_ln1118_1755_fu_76824_p1 = tmp_1755_reg_113406.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1755_fu_76824_p2() {
    mul_ln1118_1755_fu_76824_p2 = (!mul_ln1118_1755_fu_76824_p0.read().is_01() || !mul_ln1118_1755_fu_76824_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1755_fu_76824_p0.read()) * sc_bigint<5>(mul_ln1118_1755_fu_76824_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1756_fu_76845_p0() {
    mul_ln1118_1756_fu_76845_p0 =  (sc_lv<3>) (sext_ln1116_156_fu_46299_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1756_fu_76845_p1() {
    mul_ln1118_1756_fu_76845_p1 = tmp_1756_reg_113411.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1756_fu_76845_p2() {
    mul_ln1118_1756_fu_76845_p2 = (!mul_ln1118_1756_fu_76845_p0.read().is_01() || !mul_ln1118_1756_fu_76845_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1756_fu_76845_p0.read()) * sc_bigint<5>(mul_ln1118_1756_fu_76845_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1757_fu_76866_p0() {
    mul_ln1118_1757_fu_76866_p0 =  (sc_lv<3>) (sext_ln1116_157_fu_46323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1757_fu_76866_p1() {
    mul_ln1118_1757_fu_76866_p1 = tmp_1757_reg_113416.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1757_fu_76866_p2() {
    mul_ln1118_1757_fu_76866_p2 = (!mul_ln1118_1757_fu_76866_p0.read().is_01() || !mul_ln1118_1757_fu_76866_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1757_fu_76866_p0.read()) * sc_bigint<5>(mul_ln1118_1757_fu_76866_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1758_fu_76887_p0() {
    mul_ln1118_1758_fu_76887_p0 =  (sc_lv<3>) (sext_ln1116_158_fu_46347_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1758_fu_76887_p1() {
    mul_ln1118_1758_fu_76887_p1 = tmp_1758_reg_113421.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1758_fu_76887_p2() {
    mul_ln1118_1758_fu_76887_p2 = (!mul_ln1118_1758_fu_76887_p0.read().is_01() || !mul_ln1118_1758_fu_76887_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1758_fu_76887_p0.read()) * sc_bigint<5>(mul_ln1118_1758_fu_76887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1759_fu_76908_p0() {
    mul_ln1118_1759_fu_76908_p0 =  (sc_lv<3>) (sext_ln1116_159_fu_46371_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1759_fu_76908_p1() {
    mul_ln1118_1759_fu_76908_p1 = tmp_1759_reg_113426.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1759_fu_76908_p2() {
    mul_ln1118_1759_fu_76908_p2 = (!mul_ln1118_1759_fu_76908_p0.read().is_01() || !mul_ln1118_1759_fu_76908_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1759_fu_76908_p0.read()) * sc_bigint<5>(mul_ln1118_1759_fu_76908_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_175_fu_46671_p0() {
    mul_ln1118_175_fu_46671_p0 =  (sc_lv<3>) (sext_ln1116_175_fu_46665_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_175_fu_46671_p1() {
    mul_ln1118_175_fu_46671_p1 = tmp_175_reg_105340.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_175_fu_46671_p2() {
    mul_ln1118_175_fu_46671_p2 = (!mul_ln1118_175_fu_46671_p0.read().is_01() || !mul_ln1118_175_fu_46671_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_175_fu_46671_p0.read()) * sc_bigint<5>(mul_ln1118_175_fu_46671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1760_fu_76917_p0() {
    mul_ln1118_1760_fu_76917_p0 =  (sc_lv<3>) (sext_ln1116_160_fu_46383_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1760_fu_76917_p1() {
    mul_ln1118_1760_fu_76917_p1 = tmp_1760_reg_113431.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1760_fu_76917_p2() {
    mul_ln1118_1760_fu_76917_p2 = (!mul_ln1118_1760_fu_76917_p0.read().is_01() || !mul_ln1118_1760_fu_76917_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1760_fu_76917_p0.read()) * sc_bigint<5>(mul_ln1118_1760_fu_76917_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1761_fu_76938_p0() {
    mul_ln1118_1761_fu_76938_p0 =  (sc_lv<3>) (sext_ln1116_161_fu_46407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1761_fu_76938_p1() {
    mul_ln1118_1761_fu_76938_p1 = tmp_1761_reg_113436.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1761_fu_76938_p2() {
    mul_ln1118_1761_fu_76938_p2 = (!mul_ln1118_1761_fu_76938_p0.read().is_01() || !mul_ln1118_1761_fu_76938_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1761_fu_76938_p0.read()) * sc_bigint<5>(mul_ln1118_1761_fu_76938_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1762_fu_76959_p0() {
    mul_ln1118_1762_fu_76959_p0 =  (sc_lv<3>) (sext_ln1116_162_fu_46431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1762_fu_76959_p1() {
    mul_ln1118_1762_fu_76959_p1 = tmp_1762_reg_113441.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1762_fu_76959_p2() {
    mul_ln1118_1762_fu_76959_p2 = (!mul_ln1118_1762_fu_76959_p0.read().is_01() || !mul_ln1118_1762_fu_76959_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1762_fu_76959_p0.read()) * sc_bigint<5>(mul_ln1118_1762_fu_76959_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1763_fu_76968_p0() {
    mul_ln1118_1763_fu_76968_p0 =  (sc_lv<3>) (sext_ln1116_163_fu_46443_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1763_fu_76968_p1() {
    mul_ln1118_1763_fu_76968_p1 = tmp_1763_reg_113446.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1763_fu_76968_p2() {
    mul_ln1118_1763_fu_76968_p2 = (!mul_ln1118_1763_fu_76968_p0.read().is_01() || !mul_ln1118_1763_fu_76968_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1763_fu_76968_p0.read()) * sc_bigint<5>(mul_ln1118_1763_fu_76968_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1764_fu_76989_p0() {
    mul_ln1118_1764_fu_76989_p0 =  (sc_lv<3>) (sext_ln1116_164_fu_46467_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1764_fu_76989_p1() {
    mul_ln1118_1764_fu_76989_p1 = tmp_1764_reg_113451.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1764_fu_76989_p2() {
    mul_ln1118_1764_fu_76989_p2 = (!mul_ln1118_1764_fu_76989_p0.read().is_01() || !mul_ln1118_1764_fu_76989_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1764_fu_76989_p0.read()) * sc_bigint<5>(mul_ln1118_1764_fu_76989_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1765_fu_96183_p0() {
    mul_ln1118_1765_fu_96183_p0 =  (sc_lv<3>) (sext_ln1116_165_reg_114967.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1765_fu_96183_p1() {
    mul_ln1118_1765_fu_96183_p1 = tmp_1765_reg_113456_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1765_fu_96183_p2() {
    mul_ln1118_1765_fu_96183_p2 = (!mul_ln1118_1765_fu_96183_p0.read().is_01() || !mul_ln1118_1765_fu_96183_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1765_fu_96183_p0.read()) * sc_bigint<5>(mul_ln1118_1765_fu_96183_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1766_fu_77010_p0() {
    mul_ln1118_1766_fu_77010_p0 =  (sc_lv<3>) (sext_ln1116_166_fu_46494_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1766_fu_77010_p1() {
    mul_ln1118_1766_fu_77010_p1 = tmp_1766_reg_113461.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1766_fu_77010_p2() {
    mul_ln1118_1766_fu_77010_p2 = (!mul_ln1118_1766_fu_77010_p0.read().is_01() || !mul_ln1118_1766_fu_77010_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1766_fu_77010_p0.read()) * sc_bigint<5>(mul_ln1118_1766_fu_77010_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1767_fu_77031_p0() {
    mul_ln1118_1767_fu_77031_p0 =  (sc_lv<3>) (sext_ln1116_167_fu_46518_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1767_fu_77031_p1() {
    mul_ln1118_1767_fu_77031_p1 = tmp_1767_reg_113466.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1767_fu_77031_p2() {
    mul_ln1118_1767_fu_77031_p2 = (!mul_ln1118_1767_fu_77031_p0.read().is_01() || !mul_ln1118_1767_fu_77031_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1767_fu_77031_p0.read()) * sc_bigint<5>(mul_ln1118_1767_fu_77031_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1768_fu_96203_p0() {
    mul_ln1118_1768_fu_96203_p0 =  (sc_lv<3>) (sext_ln1116_168_reg_114980.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1768_fu_96203_p1() {
    mul_ln1118_1768_fu_96203_p1 = tmp_1768_reg_113471_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1768_fu_96203_p2() {
    mul_ln1118_1768_fu_96203_p2 = (!mul_ln1118_1768_fu_96203_p0.read().is_01() || !mul_ln1118_1768_fu_96203_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1768_fu_96203_p0.read()) * sc_bigint<5>(mul_ln1118_1768_fu_96203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1769_fu_77052_p0() {
    mul_ln1118_1769_fu_77052_p0 =  (sc_lv<3>) (sext_ln1116_169_fu_46545_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1769_fu_77052_p1() {
    mul_ln1118_1769_fu_77052_p1 = tmp_1769_reg_113476.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1769_fu_77052_p2() {
    mul_ln1118_1769_fu_77052_p2 = (!mul_ln1118_1769_fu_77052_p0.read().is_01() || !mul_ln1118_1769_fu_77052_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1769_fu_77052_p0.read()) * sc_bigint<5>(mul_ln1118_1769_fu_77052_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_176_fu_46695_p0() {
    mul_ln1118_176_fu_46695_p0 =  (sc_lv<3>) (sext_ln1116_176_fu_46689_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_176_fu_46695_p1() {
    mul_ln1118_176_fu_46695_p1 = tmp_176_reg_105350.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_176_fu_46695_p2() {
    mul_ln1118_176_fu_46695_p2 = (!mul_ln1118_176_fu_46695_p0.read().is_01() || !mul_ln1118_176_fu_46695_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_176_fu_46695_p0.read()) * sc_bigint<5>(mul_ln1118_176_fu_46695_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1770_fu_77073_p0() {
    mul_ln1118_1770_fu_77073_p0 =  (sc_lv<3>) (sext_ln1116_170_fu_46569_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1770_fu_77073_p1() {
    mul_ln1118_1770_fu_77073_p1 = tmp_1770_reg_113481.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1770_fu_77073_p2() {
    mul_ln1118_1770_fu_77073_p2 = (!mul_ln1118_1770_fu_77073_p0.read().is_01() || !mul_ln1118_1770_fu_77073_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1770_fu_77073_p0.read()) * sc_bigint<5>(mul_ln1118_1770_fu_77073_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1771_fu_77094_p0() {
    mul_ln1118_1771_fu_77094_p0 =  (sc_lv<3>) (sext_ln1116_171_fu_46593_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1771_fu_77094_p1() {
    mul_ln1118_1771_fu_77094_p1 = tmp_1771_reg_113486.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1771_fu_77094_p2() {
    mul_ln1118_1771_fu_77094_p2 = (!mul_ln1118_1771_fu_77094_p0.read().is_01() || !mul_ln1118_1771_fu_77094_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1771_fu_77094_p0.read()) * sc_bigint<5>(mul_ln1118_1771_fu_77094_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1772_fu_77103_p0() {
    mul_ln1118_1772_fu_77103_p0 =  (sc_lv<3>) (sext_ln1116_172_fu_46605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1772_fu_77103_p1() {
    mul_ln1118_1772_fu_77103_p1 = tmp_1772_reg_113491.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1772_fu_77103_p2() {
    mul_ln1118_1772_fu_77103_p2 = (!mul_ln1118_1772_fu_77103_p0.read().is_01() || !mul_ln1118_1772_fu_77103_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1772_fu_77103_p0.read()) * sc_bigint<5>(mul_ln1118_1772_fu_77103_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1773_fu_77124_p0() {
    mul_ln1118_1773_fu_77124_p0 =  (sc_lv<3>) (sext_ln1116_173_fu_46629_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1773_fu_77124_p1() {
    mul_ln1118_1773_fu_77124_p1 = tmp_1773_reg_113496.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1773_fu_77124_p2() {
    mul_ln1118_1773_fu_77124_p2 = (!mul_ln1118_1773_fu_77124_p0.read().is_01() || !mul_ln1118_1773_fu_77124_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1773_fu_77124_p0.read()) * sc_bigint<5>(mul_ln1118_1773_fu_77124_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1774_fu_77145_p0() {
    mul_ln1118_1774_fu_77145_p0 =  (sc_lv<3>) (sext_ln1116_174_fu_46653_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1774_fu_77145_p1() {
    mul_ln1118_1774_fu_77145_p1 = tmp_1774_reg_113501.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1774_fu_77145_p2() {
    mul_ln1118_1774_fu_77145_p2 = (!mul_ln1118_1774_fu_77145_p0.read().is_01() || !mul_ln1118_1774_fu_77145_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1774_fu_77145_p0.read()) * sc_bigint<5>(mul_ln1118_1774_fu_77145_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1775_fu_77154_p0() {
    mul_ln1118_1775_fu_77154_p0 =  (sc_lv<3>) (sext_ln1116_175_fu_46665_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1775_fu_77154_p1() {
    mul_ln1118_1775_fu_77154_p1 = tmp_1775_reg_113506.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1775_fu_77154_p2() {
    mul_ln1118_1775_fu_77154_p2 = (!mul_ln1118_1775_fu_77154_p0.read().is_01() || !mul_ln1118_1775_fu_77154_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1775_fu_77154_p0.read()) * sc_bigint<5>(mul_ln1118_1775_fu_77154_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1776_fu_77175_p0() {
    mul_ln1118_1776_fu_77175_p0 =  (sc_lv<3>) (sext_ln1116_176_fu_46689_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1776_fu_77175_p1() {
    mul_ln1118_1776_fu_77175_p1 = tmp_1776_reg_113511.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1776_fu_77175_p2() {
    mul_ln1118_1776_fu_77175_p2 = (!mul_ln1118_1776_fu_77175_p0.read().is_01() || !mul_ln1118_1776_fu_77175_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1776_fu_77175_p0.read()) * sc_bigint<5>(mul_ln1118_1776_fu_77175_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1777_fu_77196_p0() {
    mul_ln1118_1777_fu_77196_p0 =  (sc_lv<3>) (sext_ln1116_177_fu_46713_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1777_fu_77196_p1() {
    mul_ln1118_1777_fu_77196_p1 = tmp_1777_reg_113516.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1777_fu_77196_p2() {
    mul_ln1118_1777_fu_77196_p2 = (!mul_ln1118_1777_fu_77196_p0.read().is_01() || !mul_ln1118_1777_fu_77196_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1777_fu_77196_p0.read()) * sc_bigint<5>(mul_ln1118_1777_fu_77196_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1778_fu_77205_p0() {
    mul_ln1118_1778_fu_77205_p0 =  (sc_lv<3>) (sext_ln1116_178_fu_46725_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1778_fu_77205_p1() {
    mul_ln1118_1778_fu_77205_p1 = tmp_1778_reg_113521.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1778_fu_77205_p2() {
    mul_ln1118_1778_fu_77205_p2 = (!mul_ln1118_1778_fu_77205_p0.read().is_01() || !mul_ln1118_1778_fu_77205_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1778_fu_77205_p0.read()) * sc_bigint<5>(mul_ln1118_1778_fu_77205_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1779_fu_77226_p0() {
    mul_ln1118_1779_fu_77226_p0 =  (sc_lv<3>) (sext_ln1116_179_fu_46749_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1779_fu_77226_p1() {
    mul_ln1118_1779_fu_77226_p1 = tmp_1779_reg_113526.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1779_fu_77226_p2() {
    mul_ln1118_1779_fu_77226_p2 = (!mul_ln1118_1779_fu_77226_p0.read().is_01() || !mul_ln1118_1779_fu_77226_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1779_fu_77226_p0.read()) * sc_bigint<5>(mul_ln1118_1779_fu_77226_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_177_fu_46719_p0() {
    mul_ln1118_177_fu_46719_p0 =  (sc_lv<3>) (sext_ln1116_177_fu_46713_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_177_fu_46719_p1() {
    mul_ln1118_177_fu_46719_p1 = tmp_177_reg_105360.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_177_fu_46719_p2() {
    mul_ln1118_177_fu_46719_p2 = (!mul_ln1118_177_fu_46719_p0.read().is_01() || !mul_ln1118_177_fu_46719_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_177_fu_46719_p0.read()) * sc_bigint<5>(mul_ln1118_177_fu_46719_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1780_fu_77247_p0() {
    mul_ln1118_1780_fu_77247_p0 =  (sc_lv<3>) (sext_ln1116_180_fu_46773_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1780_fu_77247_p1() {
    mul_ln1118_1780_fu_77247_p1 = tmp_1780_reg_113531.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1780_fu_77247_p2() {
    mul_ln1118_1780_fu_77247_p2 = (!mul_ln1118_1780_fu_77247_p0.read().is_01() || !mul_ln1118_1780_fu_77247_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1780_fu_77247_p0.read()) * sc_bigint<5>(mul_ln1118_1780_fu_77247_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1781_fu_77268_p0() {
    mul_ln1118_1781_fu_77268_p0 =  (sc_lv<3>) (sext_ln1116_181_fu_46797_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1781_fu_77268_p1() {
    mul_ln1118_1781_fu_77268_p1 = tmp_1781_reg_113536.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1781_fu_77268_p2() {
    mul_ln1118_1781_fu_77268_p2 = (!mul_ln1118_1781_fu_77268_p0.read().is_01() || !mul_ln1118_1781_fu_77268_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1781_fu_77268_p0.read()) * sc_bigint<5>(mul_ln1118_1781_fu_77268_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1782_fu_77289_p0() {
    mul_ln1118_1782_fu_77289_p0 =  (sc_lv<3>) (sext_ln1116_182_fu_46821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1782_fu_77289_p1() {
    mul_ln1118_1782_fu_77289_p1 = tmp_1782_reg_113541.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1782_fu_77289_p2() {
    mul_ln1118_1782_fu_77289_p2 = (!mul_ln1118_1782_fu_77289_p0.read().is_01() || !mul_ln1118_1782_fu_77289_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1782_fu_77289_p0.read()) * sc_bigint<5>(mul_ln1118_1782_fu_77289_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1783_fu_77310_p0() {
    mul_ln1118_1783_fu_77310_p0 =  (sc_lv<3>) (sext_ln1116_183_fu_46845_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1783_fu_77310_p1() {
    mul_ln1118_1783_fu_77310_p1 = tmp_1783_reg_113546.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1783_fu_77310_p2() {
    mul_ln1118_1783_fu_77310_p2 = (!mul_ln1118_1783_fu_77310_p0.read().is_01() || !mul_ln1118_1783_fu_77310_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1783_fu_77310_p0.read()) * sc_bigint<5>(mul_ln1118_1783_fu_77310_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1784_fu_77331_p0() {
    mul_ln1118_1784_fu_77331_p0 =  (sc_lv<3>) (sext_ln1116_184_fu_46869_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1784_fu_77331_p1() {
    mul_ln1118_1784_fu_77331_p1 = tmp_1784_reg_113551.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1784_fu_77331_p2() {
    mul_ln1118_1784_fu_77331_p2 = (!mul_ln1118_1784_fu_77331_p0.read().is_01() || !mul_ln1118_1784_fu_77331_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1784_fu_77331_p0.read()) * sc_bigint<5>(mul_ln1118_1784_fu_77331_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1785_fu_77340_p0() {
    mul_ln1118_1785_fu_77340_p0 =  (sc_lv<3>) (sext_ln1116_185_fu_46881_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1785_fu_77340_p1() {
    mul_ln1118_1785_fu_77340_p1 = tmp_1785_reg_113556.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1785_fu_77340_p2() {
    mul_ln1118_1785_fu_77340_p2 = (!mul_ln1118_1785_fu_77340_p0.read().is_01() || !mul_ln1118_1785_fu_77340_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1785_fu_77340_p0.read()) * sc_bigint<5>(mul_ln1118_1785_fu_77340_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1786_fu_77361_p0() {
    mul_ln1118_1786_fu_77361_p0 =  (sc_lv<3>) (sext_ln1116_186_fu_46905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1786_fu_77361_p1() {
    mul_ln1118_1786_fu_77361_p1 = tmp_1786_reg_113561.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1786_fu_77361_p2() {
    mul_ln1118_1786_fu_77361_p2 = (!mul_ln1118_1786_fu_77361_p0.read().is_01() || !mul_ln1118_1786_fu_77361_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1786_fu_77361_p0.read()) * sc_bigint<5>(mul_ln1118_1786_fu_77361_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1787_fu_77382_p0() {
    mul_ln1118_1787_fu_77382_p0 =  (sc_lv<3>) (sext_ln1116_187_fu_46929_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1787_fu_77382_p1() {
    mul_ln1118_1787_fu_77382_p1 = tmp_1787_reg_113566.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1787_fu_77382_p2() {
    mul_ln1118_1787_fu_77382_p2 = (!mul_ln1118_1787_fu_77382_p0.read().is_01() || !mul_ln1118_1787_fu_77382_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1787_fu_77382_p0.read()) * sc_bigint<5>(mul_ln1118_1787_fu_77382_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1788_fu_77391_p0() {
    mul_ln1118_1788_fu_77391_p0 =  (sc_lv<3>) (sext_ln1116_188_fu_46941_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1788_fu_77391_p1() {
    mul_ln1118_1788_fu_77391_p1 = tmp_1788_reg_113571.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1788_fu_77391_p2() {
    mul_ln1118_1788_fu_77391_p2 = (!mul_ln1118_1788_fu_77391_p0.read().is_01() || !mul_ln1118_1788_fu_77391_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1788_fu_77391_p0.read()) * sc_bigint<5>(mul_ln1118_1788_fu_77391_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1789_fu_77412_p0() {
    mul_ln1118_1789_fu_77412_p0 =  (sc_lv<3>) (sext_ln1116_189_fu_46965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1789_fu_77412_p1() {
    mul_ln1118_1789_fu_77412_p1 = tmp_1789_reg_113576.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1789_fu_77412_p2() {
    mul_ln1118_1789_fu_77412_p2 = (!mul_ln1118_1789_fu_77412_p0.read().is_01() || !mul_ln1118_1789_fu_77412_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1789_fu_77412_p0.read()) * sc_bigint<5>(mul_ln1118_1789_fu_77412_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_178_fu_46731_p0() {
    mul_ln1118_178_fu_46731_p0 =  (sc_lv<3>) (sext_ln1116_178_fu_46725_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_178_fu_46731_p1() {
    mul_ln1118_178_fu_46731_p1 = tmp_178_reg_105370.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_178_fu_46731_p2() {
    mul_ln1118_178_fu_46731_p2 = (!mul_ln1118_178_fu_46731_p0.read().is_01() || !mul_ln1118_178_fu_46731_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_178_fu_46731_p0.read()) * sc_bigint<5>(mul_ln1118_178_fu_46731_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1790_fu_96278_p0() {
    mul_ln1118_1790_fu_96278_p0 =  (sc_lv<3>) (sext_ln1116_190_reg_115018.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1790_fu_96278_p1() {
    mul_ln1118_1790_fu_96278_p1 = tmp_1790_reg_113581_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1790_fu_96278_p2() {
    mul_ln1118_1790_fu_96278_p2 = (!mul_ln1118_1790_fu_96278_p0.read().is_01() || !mul_ln1118_1790_fu_96278_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1790_fu_96278_p0.read()) * sc_bigint<5>(mul_ln1118_1790_fu_96278_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1791_fu_77433_p0() {
    mul_ln1118_1791_fu_77433_p0 =  (sc_lv<3>) (sext_ln1116_191_fu_46992_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1791_fu_77433_p1() {
    mul_ln1118_1791_fu_77433_p1 = tmp_1791_reg_113586.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1791_fu_77433_p2() {
    mul_ln1118_1791_fu_77433_p2 = (!mul_ln1118_1791_fu_77433_p0.read().is_01() || !mul_ln1118_1791_fu_77433_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1791_fu_77433_p0.read()) * sc_bigint<5>(mul_ln1118_1791_fu_77433_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1792_fu_77454_p0() {
    mul_ln1118_1792_fu_77454_p0 =  (sc_lv<3>) (sext_ln1116_192_fu_47016_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1792_fu_77454_p1() {
    mul_ln1118_1792_fu_77454_p1 = tmp_1792_reg_113591.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1792_fu_77454_p2() {
    mul_ln1118_1792_fu_77454_p2 = (!mul_ln1118_1792_fu_77454_p0.read().is_01() || !mul_ln1118_1792_fu_77454_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1792_fu_77454_p0.read()) * sc_bigint<5>(mul_ln1118_1792_fu_77454_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1793_fu_96298_p0() {
    mul_ln1118_1793_fu_96298_p0 =  (sc_lv<3>) (sext_ln1116_193_reg_115031.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1793_fu_96298_p1() {
    mul_ln1118_1793_fu_96298_p1 = tmp_1793_reg_113596_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1793_fu_96298_p2() {
    mul_ln1118_1793_fu_96298_p2 = (!mul_ln1118_1793_fu_96298_p0.read().is_01() || !mul_ln1118_1793_fu_96298_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1793_fu_96298_p0.read()) * sc_bigint<5>(mul_ln1118_1793_fu_96298_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1794_fu_77475_p0() {
    mul_ln1118_1794_fu_77475_p0 =  (sc_lv<3>) (sext_ln1116_194_fu_47043_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1794_fu_77475_p1() {
    mul_ln1118_1794_fu_77475_p1 = tmp_1794_reg_113601.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1794_fu_77475_p2() {
    mul_ln1118_1794_fu_77475_p2 = (!mul_ln1118_1794_fu_77475_p0.read().is_01() || !mul_ln1118_1794_fu_77475_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1794_fu_77475_p0.read()) * sc_bigint<5>(mul_ln1118_1794_fu_77475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1795_fu_77496_p0() {
    mul_ln1118_1795_fu_77496_p0 =  (sc_lv<3>) (sext_ln1116_195_fu_47067_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1795_fu_77496_p1() {
    mul_ln1118_1795_fu_77496_p1 = tmp_1795_reg_113606.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1795_fu_77496_p2() {
    mul_ln1118_1795_fu_77496_p2 = (!mul_ln1118_1795_fu_77496_p0.read().is_01() || !mul_ln1118_1795_fu_77496_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1795_fu_77496_p0.read()) * sc_bigint<5>(mul_ln1118_1795_fu_77496_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1796_fu_77517_p0() {
    mul_ln1118_1796_fu_77517_p0 =  (sc_lv<3>) (sext_ln1116_196_fu_47091_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1796_fu_77517_p1() {
    mul_ln1118_1796_fu_77517_p1 = tmp_1796_reg_113611.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1796_fu_77517_p2() {
    mul_ln1118_1796_fu_77517_p2 = (!mul_ln1118_1796_fu_77517_p0.read().is_01() || !mul_ln1118_1796_fu_77517_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1796_fu_77517_p0.read()) * sc_bigint<5>(mul_ln1118_1796_fu_77517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1797_fu_77526_p0() {
    mul_ln1118_1797_fu_77526_p0 =  (sc_lv<3>) (sext_ln1116_197_fu_47103_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1797_fu_77526_p1() {
    mul_ln1118_1797_fu_77526_p1 = tmp_1797_reg_113616.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1797_fu_77526_p2() {
    mul_ln1118_1797_fu_77526_p2 = (!mul_ln1118_1797_fu_77526_p0.read().is_01() || !mul_ln1118_1797_fu_77526_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1797_fu_77526_p0.read()) * sc_bigint<5>(mul_ln1118_1797_fu_77526_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1798_fu_77547_p0() {
    mul_ln1118_1798_fu_77547_p0 =  (sc_lv<3>) (sext_ln1116_198_fu_47127_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1798_fu_77547_p1() {
    mul_ln1118_1798_fu_77547_p1 = tmp_1798_reg_113621.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1798_fu_77547_p2() {
    mul_ln1118_1798_fu_77547_p2 = (!mul_ln1118_1798_fu_77547_p0.read().is_01() || !mul_ln1118_1798_fu_77547_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1798_fu_77547_p0.read()) * sc_bigint<5>(mul_ln1118_1798_fu_77547_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1799_fu_77568_p0() {
    mul_ln1118_1799_fu_77568_p0 =  (sc_lv<3>) (sext_ln1116_199_fu_47151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1799_fu_77568_p1() {
    mul_ln1118_1799_fu_77568_p1 = tmp_1799_reg_113626.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1799_fu_77568_p2() {
    mul_ln1118_1799_fu_77568_p2 = (!mul_ln1118_1799_fu_77568_p0.read().is_01() || !mul_ln1118_1799_fu_77568_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1799_fu_77568_p0.read()) * sc_bigint<5>(mul_ln1118_1799_fu_77568_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_179_fu_46755_p0() {
    mul_ln1118_179_fu_46755_p0 =  (sc_lv<3>) (sext_ln1116_179_fu_46749_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_179_fu_46755_p1() {
    mul_ln1118_179_fu_46755_p1 = tmp_179_reg_105380.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_179_fu_46755_p2() {
    mul_ln1118_179_fu_46755_p2 = (!mul_ln1118_179_fu_46755_p0.read().is_01() || !mul_ln1118_179_fu_46755_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_179_fu_46755_p0.read()) * sc_bigint<5>(mul_ln1118_179_fu_46755_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_17_fu_43557_p0() {
    mul_ln1118_17_fu_43557_p0 =  (sc_lv<3>) (sext_ln1116_17_fu_43551_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_17_fu_43557_p1() {
    mul_ln1118_17_fu_43557_p1 = tmp_18_reg_103760.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_17_fu_43557_p2() {
    mul_ln1118_17_fu_43557_p2 = (!mul_ln1118_17_fu_43557_p0.read().is_01() || !mul_ln1118_17_fu_43557_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_17_fu_43557_p0.read()) * sc_bigint<5>(mul_ln1118_17_fu_43557_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1800_fu_77577_p0() {
    mul_ln1118_1800_fu_77577_p0 =  (sc_lv<3>) (sext_ln1116_200_fu_47163_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1800_fu_77577_p1() {
    mul_ln1118_1800_fu_77577_p1 = tmp_1800_reg_113631.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1800_fu_77577_p2() {
    mul_ln1118_1800_fu_77577_p2 = (!mul_ln1118_1800_fu_77577_p0.read().is_01() || !mul_ln1118_1800_fu_77577_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1800_fu_77577_p0.read()) * sc_bigint<5>(mul_ln1118_1800_fu_77577_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1801_fu_77598_p0() {
    mul_ln1118_1801_fu_77598_p0 =  (sc_lv<3>) (sext_ln1116_201_fu_47187_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1801_fu_77598_p1() {
    mul_ln1118_1801_fu_77598_p1 = tmp_1801_reg_113636.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1801_fu_77598_p2() {
    mul_ln1118_1801_fu_77598_p2 = (!mul_ln1118_1801_fu_77598_p0.read().is_01() || !mul_ln1118_1801_fu_77598_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1801_fu_77598_p0.read()) * sc_bigint<5>(mul_ln1118_1801_fu_77598_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1802_fu_77619_p0() {
    mul_ln1118_1802_fu_77619_p0 =  (sc_lv<3>) (sext_ln1116_202_fu_47211_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1802_fu_77619_p1() {
    mul_ln1118_1802_fu_77619_p1 = tmp_1802_reg_113641.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1802_fu_77619_p2() {
    mul_ln1118_1802_fu_77619_p2 = (!mul_ln1118_1802_fu_77619_p0.read().is_01() || !mul_ln1118_1802_fu_77619_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1802_fu_77619_p0.read()) * sc_bigint<5>(mul_ln1118_1802_fu_77619_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1803_fu_77628_p0() {
    mul_ln1118_1803_fu_77628_p0 =  (sc_lv<3>) (sext_ln1116_203_fu_47223_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1803_fu_77628_p1() {
    mul_ln1118_1803_fu_77628_p1 = tmp_1803_reg_113646.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1803_fu_77628_p2() {
    mul_ln1118_1803_fu_77628_p2 = (!mul_ln1118_1803_fu_77628_p0.read().is_01() || !mul_ln1118_1803_fu_77628_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1803_fu_77628_p0.read()) * sc_bigint<5>(mul_ln1118_1803_fu_77628_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1804_fu_77649_p0() {
    mul_ln1118_1804_fu_77649_p0 =  (sc_lv<3>) (sext_ln1116_204_fu_47247_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1804_fu_77649_p1() {
    mul_ln1118_1804_fu_77649_p1 = tmp_1804_reg_113651.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1804_fu_77649_p2() {
    mul_ln1118_1804_fu_77649_p2 = (!mul_ln1118_1804_fu_77649_p0.read().is_01() || !mul_ln1118_1804_fu_77649_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1804_fu_77649_p0.read()) * sc_bigint<5>(mul_ln1118_1804_fu_77649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1805_fu_77670_p0() {
    mul_ln1118_1805_fu_77670_p0 =  (sc_lv<3>) (sext_ln1116_205_fu_47271_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1805_fu_77670_p1() {
    mul_ln1118_1805_fu_77670_p1 = tmp_1805_reg_113656.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1805_fu_77670_p2() {
    mul_ln1118_1805_fu_77670_p2 = (!mul_ln1118_1805_fu_77670_p0.read().is_01() || !mul_ln1118_1805_fu_77670_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1805_fu_77670_p0.read()) * sc_bigint<5>(mul_ln1118_1805_fu_77670_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1806_fu_77691_p0() {
    mul_ln1118_1806_fu_77691_p0 =  (sc_lv<3>) (sext_ln1116_206_fu_47295_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1806_fu_77691_p1() {
    mul_ln1118_1806_fu_77691_p1 = tmp_1806_reg_113661.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1806_fu_77691_p2() {
    mul_ln1118_1806_fu_77691_p2 = (!mul_ln1118_1806_fu_77691_p0.read().is_01() || !mul_ln1118_1806_fu_77691_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1806_fu_77691_p0.read()) * sc_bigint<5>(mul_ln1118_1806_fu_77691_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1807_fu_77712_p0() {
    mul_ln1118_1807_fu_77712_p0 =  (sc_lv<3>) (sext_ln1116_207_fu_47319_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1807_fu_77712_p1() {
    mul_ln1118_1807_fu_77712_p1 = tmp_1807_reg_113666.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1807_fu_77712_p2() {
    mul_ln1118_1807_fu_77712_p2 = (!mul_ln1118_1807_fu_77712_p0.read().is_01() || !mul_ln1118_1807_fu_77712_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1807_fu_77712_p0.read()) * sc_bigint<5>(mul_ln1118_1807_fu_77712_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1808_fu_77733_p0() {
    mul_ln1118_1808_fu_77733_p0 =  (sc_lv<3>) (sext_ln1116_208_fu_47343_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1808_fu_77733_p1() {
    mul_ln1118_1808_fu_77733_p1 = tmp_1808_reg_113671.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1808_fu_77733_p2() {
    mul_ln1118_1808_fu_77733_p2 = (!mul_ln1118_1808_fu_77733_p0.read().is_01() || !mul_ln1118_1808_fu_77733_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1808_fu_77733_p0.read()) * sc_bigint<5>(mul_ln1118_1808_fu_77733_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1809_fu_78186_p0() {
    mul_ln1118_1809_fu_78186_p0 =  (sc_lv<3>) (sext_ln1116_fu_43407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1809_fu_78186_p1() {
    mul_ln1118_1809_fu_78186_p1 = tmp_1809_reg_113676.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1809_fu_78186_p2() {
    mul_ln1118_1809_fu_78186_p2 = (!mul_ln1118_1809_fu_78186_p0.read().is_01() || !mul_ln1118_1809_fu_78186_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1809_fu_78186_p0.read()) * sc_bigint<5>(mul_ln1118_1809_fu_78186_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_180_fu_46779_p0() {
    mul_ln1118_180_fu_46779_p0 =  (sc_lv<3>) (sext_ln1116_180_fu_46773_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_180_fu_46779_p1() {
    mul_ln1118_180_fu_46779_p1 = tmp_180_reg_105390.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_180_fu_46779_p2() {
    mul_ln1118_180_fu_46779_p2 = (!mul_ln1118_180_fu_46779_p0.read().is_01() || !mul_ln1118_180_fu_46779_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_180_fu_46779_p0.read()) * sc_bigint<5>(mul_ln1118_180_fu_46779_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1810_fu_78195_p0() {
    mul_ln1118_1810_fu_78195_p0 =  (sc_lv<3>) (sext_ln1116_10_fu_43419_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1810_fu_78195_p1() {
    mul_ln1118_1810_fu_78195_p1 = tmp_1810_reg_113681.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1810_fu_78195_p2() {
    mul_ln1118_1810_fu_78195_p2 = (!mul_ln1118_1810_fu_78195_p0.read().is_01() || !mul_ln1118_1810_fu_78195_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1810_fu_78195_p0.read()) * sc_bigint<5>(mul_ln1118_1810_fu_78195_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1811_fu_78216_p0() {
    mul_ln1118_1811_fu_78216_p0 =  (sc_lv<3>) (sext_ln1116_11_fu_43443_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1811_fu_78216_p1() {
    mul_ln1118_1811_fu_78216_p1 = tmp_1811_reg_113686.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1811_fu_78216_p2() {
    mul_ln1118_1811_fu_78216_p2 = (!mul_ln1118_1811_fu_78216_p0.read().is_01() || !mul_ln1118_1811_fu_78216_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1811_fu_78216_p0.read()) * sc_bigint<5>(mul_ln1118_1811_fu_78216_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1812_fu_78237_p0() {
    mul_ln1118_1812_fu_78237_p0 =  (sc_lv<3>) (sext_ln1116_12_fu_43467_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1812_fu_78237_p1() {
    mul_ln1118_1812_fu_78237_p1 = tmp_1812_reg_113691.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1812_fu_78237_p2() {
    mul_ln1118_1812_fu_78237_p2 = (!mul_ln1118_1812_fu_78237_p0.read().is_01() || !mul_ln1118_1812_fu_78237_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1812_fu_78237_p0.read()) * sc_bigint<5>(mul_ln1118_1812_fu_78237_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1813_fu_78246_p0() {
    mul_ln1118_1813_fu_78246_p0 =  (sc_lv<3>) (sext_ln1116_13_fu_43479_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1813_fu_78246_p1() {
    mul_ln1118_1813_fu_78246_p1 = tmp_1813_reg_113696.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1813_fu_78246_p2() {
    mul_ln1118_1813_fu_78246_p2 = (!mul_ln1118_1813_fu_78246_p0.read().is_01() || !mul_ln1118_1813_fu_78246_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1813_fu_78246_p0.read()) * sc_bigint<5>(mul_ln1118_1813_fu_78246_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1814_fu_78267_p0() {
    mul_ln1118_1814_fu_78267_p0 =  (sc_lv<3>) (sext_ln1116_14_fu_43503_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1814_fu_78267_p1() {
    mul_ln1118_1814_fu_78267_p1 = tmp_1814_reg_113701.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1814_fu_78267_p2() {
    mul_ln1118_1814_fu_78267_p2 = (!mul_ln1118_1814_fu_78267_p0.read().is_01() || !mul_ln1118_1814_fu_78267_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1814_fu_78267_p0.read()) * sc_bigint<5>(mul_ln1118_1814_fu_78267_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1815_fu_97281_p0() {
    mul_ln1118_1815_fu_97281_p0 =  (sc_lv<3>) (sext_ln1116_15_fu_82080_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1815_fu_97281_p1() {
    mul_ln1118_1815_fu_97281_p1 = tmp_1815_reg_113706_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1815_fu_97281_p2() {
    mul_ln1118_1815_fu_97281_p2 = (!mul_ln1118_1815_fu_97281_p0.read().is_01() || !mul_ln1118_1815_fu_97281_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1815_fu_97281_p0.read()) * sc_bigint<5>(mul_ln1118_1815_fu_97281_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1816_fu_78288_p0() {
    mul_ln1118_1816_fu_78288_p0 =  (sc_lv<3>) (sext_ln1116_16_fu_43527_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1816_fu_78288_p1() {
    mul_ln1118_1816_fu_78288_p1 = tmp_1816_reg_113711.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1816_fu_78288_p2() {
    mul_ln1118_1816_fu_78288_p2 = (!mul_ln1118_1816_fu_78288_p0.read().is_01() || !mul_ln1118_1816_fu_78288_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1816_fu_78288_p0.read()) * sc_bigint<5>(mul_ln1118_1816_fu_78288_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1817_fu_78309_p0() {
    mul_ln1118_1817_fu_78309_p0 =  (sc_lv<3>) (sext_ln1116_17_fu_43551_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1817_fu_78309_p1() {
    mul_ln1118_1817_fu_78309_p1 = tmp_1817_reg_113716.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1817_fu_78309_p2() {
    mul_ln1118_1817_fu_78309_p2 = (!mul_ln1118_1817_fu_78309_p0.read().is_01() || !mul_ln1118_1817_fu_78309_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1817_fu_78309_p0.read()) * sc_bigint<5>(mul_ln1118_1817_fu_78309_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1818_fu_97302_p0() {
    mul_ln1118_1818_fu_97302_p0 =  (sc_lv<3>) (sext_ln1116_18_fu_82104_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1818_fu_97302_p1() {
    mul_ln1118_1818_fu_97302_p1 = tmp_1818_reg_113721_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1818_fu_97302_p2() {
    mul_ln1118_1818_fu_97302_p2 = (!mul_ln1118_1818_fu_97302_p0.read().is_01() || !mul_ln1118_1818_fu_97302_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1818_fu_97302_p0.read()) * sc_bigint<5>(mul_ln1118_1818_fu_97302_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1819_fu_78330_p0() {
    mul_ln1118_1819_fu_78330_p0 =  (sc_lv<3>) (sext_ln1116_19_fu_43575_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1819_fu_78330_p1() {
    mul_ln1118_1819_fu_78330_p1 = tmp_1819_reg_113726.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1819_fu_78330_p2() {
    mul_ln1118_1819_fu_78330_p2 = (!mul_ln1118_1819_fu_78330_p0.read().is_01() || !mul_ln1118_1819_fu_78330_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1819_fu_78330_p0.read()) * sc_bigint<5>(mul_ln1118_1819_fu_78330_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_181_fu_46803_p0() {
    mul_ln1118_181_fu_46803_p0 =  (sc_lv<3>) (sext_ln1116_181_fu_46797_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_181_fu_46803_p1() {
    mul_ln1118_181_fu_46803_p1 = tmp_181_reg_105400.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_181_fu_46803_p2() {
    mul_ln1118_181_fu_46803_p2 = (!mul_ln1118_181_fu_46803_p0.read().is_01() || !mul_ln1118_181_fu_46803_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_181_fu_46803_p0.read()) * sc_bigint<5>(mul_ln1118_181_fu_46803_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1820_fu_78351_p0() {
    mul_ln1118_1820_fu_78351_p0 =  (sc_lv<3>) (sext_ln1116_20_fu_43599_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1820_fu_78351_p1() {
    mul_ln1118_1820_fu_78351_p1 = tmp_1820_reg_113731.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1820_fu_78351_p2() {
    mul_ln1118_1820_fu_78351_p2 = (!mul_ln1118_1820_fu_78351_p0.read().is_01() || !mul_ln1118_1820_fu_78351_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1820_fu_78351_p0.read()) * sc_bigint<5>(mul_ln1118_1820_fu_78351_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1821_fu_78372_p0() {
    mul_ln1118_1821_fu_78372_p0 =  (sc_lv<3>) (sext_ln1116_21_fu_43623_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1821_fu_78372_p1() {
    mul_ln1118_1821_fu_78372_p1 = tmp_1821_reg_113736.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1821_fu_78372_p2() {
    mul_ln1118_1821_fu_78372_p2 = (!mul_ln1118_1821_fu_78372_p0.read().is_01() || !mul_ln1118_1821_fu_78372_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1821_fu_78372_p0.read()) * sc_bigint<5>(mul_ln1118_1821_fu_78372_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1822_fu_78381_p0() {
    mul_ln1118_1822_fu_78381_p0 =  (sc_lv<3>) (sext_ln1116_22_fu_43635_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1822_fu_78381_p1() {
    mul_ln1118_1822_fu_78381_p1 = tmp_1822_reg_113741.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1822_fu_78381_p2() {
    mul_ln1118_1822_fu_78381_p2 = (!mul_ln1118_1822_fu_78381_p0.read().is_01() || !mul_ln1118_1822_fu_78381_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1822_fu_78381_p0.read()) * sc_bigint<5>(mul_ln1118_1822_fu_78381_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1823_fu_78402_p0() {
    mul_ln1118_1823_fu_78402_p0 =  (sc_lv<3>) (sext_ln1116_23_fu_43659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1823_fu_78402_p1() {
    mul_ln1118_1823_fu_78402_p1 = tmp_1823_reg_113746.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1823_fu_78402_p2() {
    mul_ln1118_1823_fu_78402_p2 = (!mul_ln1118_1823_fu_78402_p0.read().is_01() || !mul_ln1118_1823_fu_78402_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1823_fu_78402_p0.read()) * sc_bigint<5>(mul_ln1118_1823_fu_78402_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1824_fu_78423_p0() {
    mul_ln1118_1824_fu_78423_p0 =  (sc_lv<3>) (sext_ln1116_24_fu_43683_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1824_fu_78423_p1() {
    mul_ln1118_1824_fu_78423_p1 = tmp_1824_reg_113751.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1824_fu_78423_p2() {
    mul_ln1118_1824_fu_78423_p2 = (!mul_ln1118_1824_fu_78423_p0.read().is_01() || !mul_ln1118_1824_fu_78423_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1824_fu_78423_p0.read()) * sc_bigint<5>(mul_ln1118_1824_fu_78423_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1825_fu_78432_p0() {
    mul_ln1118_1825_fu_78432_p0 =  (sc_lv<3>) (sext_ln1116_25_fu_43695_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1825_fu_78432_p1() {
    mul_ln1118_1825_fu_78432_p1 = tmp_1825_reg_113756.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1825_fu_78432_p2() {
    mul_ln1118_1825_fu_78432_p2 = (!mul_ln1118_1825_fu_78432_p0.read().is_01() || !mul_ln1118_1825_fu_78432_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1825_fu_78432_p0.read()) * sc_bigint<5>(mul_ln1118_1825_fu_78432_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1826_fu_78453_p0() {
    mul_ln1118_1826_fu_78453_p0 =  (sc_lv<3>) (sext_ln1116_26_fu_43719_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1826_fu_78453_p1() {
    mul_ln1118_1826_fu_78453_p1 = tmp_1826_reg_113761.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1826_fu_78453_p2() {
    mul_ln1118_1826_fu_78453_p2 = (!mul_ln1118_1826_fu_78453_p0.read().is_01() || !mul_ln1118_1826_fu_78453_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1826_fu_78453_p0.read()) * sc_bigint<5>(mul_ln1118_1826_fu_78453_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1827_fu_78474_p0() {
    mul_ln1118_1827_fu_78474_p0 =  (sc_lv<3>) (sext_ln1116_27_fu_43743_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1827_fu_78474_p1() {
    mul_ln1118_1827_fu_78474_p1 = tmp_1827_reg_113766.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1827_fu_78474_p2() {
    mul_ln1118_1827_fu_78474_p2 = (!mul_ln1118_1827_fu_78474_p0.read().is_01() || !mul_ln1118_1827_fu_78474_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1827_fu_78474_p0.read()) * sc_bigint<5>(mul_ln1118_1827_fu_78474_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1828_fu_78483_p0() {
    mul_ln1118_1828_fu_78483_p0 =  (sc_lv<3>) (sext_ln1116_28_fu_43755_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1828_fu_78483_p1() {
    mul_ln1118_1828_fu_78483_p1 = tmp_1828_reg_113771.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1828_fu_78483_p2() {
    mul_ln1118_1828_fu_78483_p2 = (!mul_ln1118_1828_fu_78483_p0.read().is_01() || !mul_ln1118_1828_fu_78483_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1828_fu_78483_p0.read()) * sc_bigint<5>(mul_ln1118_1828_fu_78483_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1829_fu_78504_p0() {
    mul_ln1118_1829_fu_78504_p0 =  (sc_lv<3>) (sext_ln1116_29_fu_43779_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1829_fu_78504_p1() {
    mul_ln1118_1829_fu_78504_p1 = tmp_1829_reg_113776.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1829_fu_78504_p2() {
    mul_ln1118_1829_fu_78504_p2 = (!mul_ln1118_1829_fu_78504_p0.read().is_01() || !mul_ln1118_1829_fu_78504_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1829_fu_78504_p0.read()) * sc_bigint<5>(mul_ln1118_1829_fu_78504_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_182_fu_46827_p0() {
    mul_ln1118_182_fu_46827_p0 =  (sc_lv<3>) (sext_ln1116_182_fu_46821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_182_fu_46827_p1() {
    mul_ln1118_182_fu_46827_p1 = tmp_182_reg_105410.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_182_fu_46827_p2() {
    mul_ln1118_182_fu_46827_p2 = (!mul_ln1118_182_fu_46827_p0.read().is_01() || !mul_ln1118_182_fu_46827_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_182_fu_46827_p0.read()) * sc_bigint<5>(mul_ln1118_182_fu_46827_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1830_fu_78525_p0() {
    mul_ln1118_1830_fu_78525_p0 =  (sc_lv<3>) (sext_ln1116_30_fu_43803_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1830_fu_78525_p1() {
    mul_ln1118_1830_fu_78525_p1 = tmp_1830_reg_113781.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1830_fu_78525_p2() {
    mul_ln1118_1830_fu_78525_p2 = (!mul_ln1118_1830_fu_78525_p0.read().is_01() || !mul_ln1118_1830_fu_78525_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1830_fu_78525_p0.read()) * sc_bigint<5>(mul_ln1118_1830_fu_78525_p1.read());
}

}

