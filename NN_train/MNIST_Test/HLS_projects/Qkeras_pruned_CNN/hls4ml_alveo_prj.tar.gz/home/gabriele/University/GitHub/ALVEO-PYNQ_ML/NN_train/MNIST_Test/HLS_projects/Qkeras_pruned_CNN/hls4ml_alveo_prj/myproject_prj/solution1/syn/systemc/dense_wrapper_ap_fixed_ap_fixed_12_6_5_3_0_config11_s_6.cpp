#include "dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_260_V_read286_phi_reg_20012() {
    ap_phi_reg_pp0_iter0_data_260_V_read286_phi_reg_20012 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_261_V_read287_phi_reg_20024() {
    ap_phi_reg_pp0_iter0_data_261_V_read287_phi_reg_20024 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_262_V_read288_phi_reg_20036() {
    ap_phi_reg_pp0_iter0_data_262_V_read288_phi_reg_20036 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_263_V_read289_phi_reg_20048() {
    ap_phi_reg_pp0_iter0_data_263_V_read289_phi_reg_20048 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_264_V_read290_phi_reg_20060() {
    ap_phi_reg_pp0_iter0_data_264_V_read290_phi_reg_20060 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_265_V_read291_phi_reg_20072() {
    ap_phi_reg_pp0_iter0_data_265_V_read291_phi_reg_20072 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_266_V_read292_phi_reg_20084() {
    ap_phi_reg_pp0_iter0_data_266_V_read292_phi_reg_20084 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_267_V_read293_phi_reg_20096() {
    ap_phi_reg_pp0_iter0_data_267_V_read293_phi_reg_20096 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_268_V_read294_phi_reg_20108() {
    ap_phi_reg_pp0_iter0_data_268_V_read294_phi_reg_20108 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_269_V_read295_phi_reg_20120() {
    ap_phi_reg_pp0_iter0_data_269_V_read295_phi_reg_20120 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_26_V_read52_phi_reg_17204() {
    ap_phi_reg_pp0_iter0_data_26_V_read52_phi_reg_17204 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_270_V_read296_phi_reg_20132() {
    ap_phi_reg_pp0_iter0_data_270_V_read296_phi_reg_20132 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_271_V_read297_phi_reg_20144() {
    ap_phi_reg_pp0_iter0_data_271_V_read297_phi_reg_20144 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_272_V_read298_phi_reg_20156() {
    ap_phi_reg_pp0_iter0_data_272_V_read298_phi_reg_20156 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_273_V_read299_phi_reg_20168() {
    ap_phi_reg_pp0_iter0_data_273_V_read299_phi_reg_20168 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_274_V_read300_phi_reg_20180() {
    ap_phi_reg_pp0_iter0_data_274_V_read300_phi_reg_20180 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_275_V_read301_phi_reg_20192() {
    ap_phi_reg_pp0_iter0_data_275_V_read301_phi_reg_20192 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_276_V_read302_phi_reg_20204() {
    ap_phi_reg_pp0_iter0_data_276_V_read302_phi_reg_20204 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_277_V_read303_phi_reg_20216() {
    ap_phi_reg_pp0_iter0_data_277_V_read303_phi_reg_20216 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_278_V_read304_phi_reg_20228() {
    ap_phi_reg_pp0_iter0_data_278_V_read304_phi_reg_20228 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_279_V_read305_phi_reg_20240() {
    ap_phi_reg_pp0_iter0_data_279_V_read305_phi_reg_20240 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_27_V_read53_phi_reg_17216() {
    ap_phi_reg_pp0_iter0_data_27_V_read53_phi_reg_17216 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_280_V_read306_phi_reg_20252() {
    ap_phi_reg_pp0_iter0_data_280_V_read306_phi_reg_20252 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_281_V_read307_phi_reg_20264() {
    ap_phi_reg_pp0_iter0_data_281_V_read307_phi_reg_20264 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_282_V_read308_phi_reg_20276() {
    ap_phi_reg_pp0_iter0_data_282_V_read308_phi_reg_20276 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_283_V_read309_phi_reg_20288() {
    ap_phi_reg_pp0_iter0_data_283_V_read309_phi_reg_20288 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_284_V_read310_phi_reg_20300() {
    ap_phi_reg_pp0_iter0_data_284_V_read310_phi_reg_20300 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_285_V_read311_phi_reg_20312() {
    ap_phi_reg_pp0_iter0_data_285_V_read311_phi_reg_20312 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_286_V_read312_phi_reg_20324() {
    ap_phi_reg_pp0_iter0_data_286_V_read312_phi_reg_20324 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_287_V_read313_phi_reg_20336() {
    ap_phi_reg_pp0_iter0_data_287_V_read313_phi_reg_20336 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_288_V_read314_phi_reg_20348() {
    ap_phi_reg_pp0_iter0_data_288_V_read314_phi_reg_20348 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_289_V_read315_phi_reg_20360() {
    ap_phi_reg_pp0_iter0_data_289_V_read315_phi_reg_20360 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_28_V_read54_phi_reg_17228() {
    ap_phi_reg_pp0_iter0_data_28_V_read54_phi_reg_17228 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_290_V_read316_phi_reg_20372() {
    ap_phi_reg_pp0_iter0_data_290_V_read316_phi_reg_20372 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_291_V_read317_phi_reg_20384() {
    ap_phi_reg_pp0_iter0_data_291_V_read317_phi_reg_20384 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_292_V_read318_phi_reg_20396() {
    ap_phi_reg_pp0_iter0_data_292_V_read318_phi_reg_20396 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_293_V_read319_phi_reg_20408() {
    ap_phi_reg_pp0_iter0_data_293_V_read319_phi_reg_20408 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_294_V_read320_phi_reg_20420() {
    ap_phi_reg_pp0_iter0_data_294_V_read320_phi_reg_20420 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_295_V_read321_phi_reg_20432() {
    ap_phi_reg_pp0_iter0_data_295_V_read321_phi_reg_20432 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_296_V_read322_phi_reg_20444() {
    ap_phi_reg_pp0_iter0_data_296_V_read322_phi_reg_20444 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_297_V_read323_phi_reg_20456() {
    ap_phi_reg_pp0_iter0_data_297_V_read323_phi_reg_20456 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_298_V_read324_phi_reg_20468() {
    ap_phi_reg_pp0_iter0_data_298_V_read324_phi_reg_20468 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_299_V_read325_phi_reg_20480() {
    ap_phi_reg_pp0_iter0_data_299_V_read325_phi_reg_20480 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_29_V_read55_phi_reg_17240() {
    ap_phi_reg_pp0_iter0_data_29_V_read55_phi_reg_17240 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_2_V_read28_phi_reg_16916() {
    ap_phi_reg_pp0_iter0_data_2_V_read28_phi_reg_16916 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_300_V_read326_phi_reg_20492() {
    ap_phi_reg_pp0_iter0_data_300_V_read326_phi_reg_20492 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_301_V_read327_phi_reg_20504() {
    ap_phi_reg_pp0_iter0_data_301_V_read327_phi_reg_20504 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_302_V_read328_phi_reg_20516() {
    ap_phi_reg_pp0_iter0_data_302_V_read328_phi_reg_20516 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_303_V_read329_phi_reg_20528() {
    ap_phi_reg_pp0_iter0_data_303_V_read329_phi_reg_20528 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_304_V_read330_phi_reg_20540() {
    ap_phi_reg_pp0_iter0_data_304_V_read330_phi_reg_20540 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_305_V_read331_phi_reg_20552() {
    ap_phi_reg_pp0_iter0_data_305_V_read331_phi_reg_20552 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_306_V_read332_phi_reg_20564() {
    ap_phi_reg_pp0_iter0_data_306_V_read332_phi_reg_20564 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_307_V_read333_phi_reg_20576() {
    ap_phi_reg_pp0_iter0_data_307_V_read333_phi_reg_20576 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_308_V_read334_phi_reg_20588() {
    ap_phi_reg_pp0_iter0_data_308_V_read334_phi_reg_20588 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_309_V_read335_phi_reg_20600() {
    ap_phi_reg_pp0_iter0_data_309_V_read335_phi_reg_20600 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_30_V_read56_phi_reg_17252() {
    ap_phi_reg_pp0_iter0_data_30_V_read56_phi_reg_17252 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_310_V_read336_phi_reg_20612() {
    ap_phi_reg_pp0_iter0_data_310_V_read336_phi_reg_20612 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_311_V_read337_phi_reg_20624() {
    ap_phi_reg_pp0_iter0_data_311_V_read337_phi_reg_20624 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_312_V_read338_phi_reg_20636() {
    ap_phi_reg_pp0_iter0_data_312_V_read338_phi_reg_20636 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_313_V_read339_phi_reg_20648() {
    ap_phi_reg_pp0_iter0_data_313_V_read339_phi_reg_20648 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_314_V_read340_phi_reg_20660() {
    ap_phi_reg_pp0_iter0_data_314_V_read340_phi_reg_20660 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_315_V_read341_phi_reg_20672() {
    ap_phi_reg_pp0_iter0_data_315_V_read341_phi_reg_20672 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_316_V_read342_phi_reg_20684() {
    ap_phi_reg_pp0_iter0_data_316_V_read342_phi_reg_20684 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_317_V_read343_phi_reg_20696() {
    ap_phi_reg_pp0_iter0_data_317_V_read343_phi_reg_20696 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_318_V_read344_phi_reg_20708() {
    ap_phi_reg_pp0_iter0_data_318_V_read344_phi_reg_20708 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_319_V_read345_phi_reg_20720() {
    ap_phi_reg_pp0_iter0_data_319_V_read345_phi_reg_20720 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_31_V_read57_phi_reg_17264() {
    ap_phi_reg_pp0_iter0_data_31_V_read57_phi_reg_17264 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_320_V_read346_phi_reg_20732() {
    ap_phi_reg_pp0_iter0_data_320_V_read346_phi_reg_20732 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_321_V_read347_phi_reg_20744() {
    ap_phi_reg_pp0_iter0_data_321_V_read347_phi_reg_20744 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_322_V_read348_phi_reg_20756() {
    ap_phi_reg_pp0_iter0_data_322_V_read348_phi_reg_20756 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_323_V_read349_phi_reg_20768() {
    ap_phi_reg_pp0_iter0_data_323_V_read349_phi_reg_20768 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_324_V_read350_phi_reg_20780() {
    ap_phi_reg_pp0_iter0_data_324_V_read350_phi_reg_20780 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_325_V_read351_phi_reg_20792() {
    ap_phi_reg_pp0_iter0_data_325_V_read351_phi_reg_20792 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_326_V_read352_phi_reg_20804() {
    ap_phi_reg_pp0_iter0_data_326_V_read352_phi_reg_20804 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_327_V_read353_phi_reg_20816() {
    ap_phi_reg_pp0_iter0_data_327_V_read353_phi_reg_20816 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_328_V_read354_phi_reg_20828() {
    ap_phi_reg_pp0_iter0_data_328_V_read354_phi_reg_20828 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_329_V_read355_phi_reg_20840() {
    ap_phi_reg_pp0_iter0_data_329_V_read355_phi_reg_20840 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_32_V_read58_phi_reg_17276() {
    ap_phi_reg_pp0_iter0_data_32_V_read58_phi_reg_17276 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_330_V_read356_phi_reg_20852() {
    ap_phi_reg_pp0_iter0_data_330_V_read356_phi_reg_20852 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_331_V_read357_phi_reg_20864() {
    ap_phi_reg_pp0_iter0_data_331_V_read357_phi_reg_20864 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_332_V_read358_phi_reg_20876() {
    ap_phi_reg_pp0_iter0_data_332_V_read358_phi_reg_20876 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_333_V_read359_phi_reg_20888() {
    ap_phi_reg_pp0_iter0_data_333_V_read359_phi_reg_20888 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_334_V_read360_phi_reg_20900() {
    ap_phi_reg_pp0_iter0_data_334_V_read360_phi_reg_20900 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_335_V_read361_phi_reg_20912() {
    ap_phi_reg_pp0_iter0_data_335_V_read361_phi_reg_20912 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_336_V_read362_phi_reg_20924() {
    ap_phi_reg_pp0_iter0_data_336_V_read362_phi_reg_20924 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_337_V_read363_phi_reg_20936() {
    ap_phi_reg_pp0_iter0_data_337_V_read363_phi_reg_20936 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_338_V_read364_phi_reg_20948() {
    ap_phi_reg_pp0_iter0_data_338_V_read364_phi_reg_20948 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_339_V_read365_phi_reg_20960() {
    ap_phi_reg_pp0_iter0_data_339_V_read365_phi_reg_20960 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_33_V_read59_phi_reg_17288() {
    ap_phi_reg_pp0_iter0_data_33_V_read59_phi_reg_17288 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_340_V_read366_phi_reg_20972() {
    ap_phi_reg_pp0_iter0_data_340_V_read366_phi_reg_20972 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_341_V_read367_phi_reg_20984() {
    ap_phi_reg_pp0_iter0_data_341_V_read367_phi_reg_20984 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_342_V_read368_phi_reg_20996() {
    ap_phi_reg_pp0_iter0_data_342_V_read368_phi_reg_20996 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_343_V_read369_phi_reg_21008() {
    ap_phi_reg_pp0_iter0_data_343_V_read369_phi_reg_21008 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_344_V_read370_phi_reg_21020() {
    ap_phi_reg_pp0_iter0_data_344_V_read370_phi_reg_21020 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_345_V_read371_phi_reg_21032() {
    ap_phi_reg_pp0_iter0_data_345_V_read371_phi_reg_21032 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_346_V_read372_phi_reg_21044() {
    ap_phi_reg_pp0_iter0_data_346_V_read372_phi_reg_21044 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_347_V_read373_phi_reg_21056() {
    ap_phi_reg_pp0_iter0_data_347_V_read373_phi_reg_21056 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_348_V_read374_phi_reg_21068() {
    ap_phi_reg_pp0_iter0_data_348_V_read374_phi_reg_21068 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_349_V_read375_phi_reg_21080() {
    ap_phi_reg_pp0_iter0_data_349_V_read375_phi_reg_21080 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_34_V_read60_phi_reg_17300() {
    ap_phi_reg_pp0_iter0_data_34_V_read60_phi_reg_17300 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_350_V_read376_phi_reg_21092() {
    ap_phi_reg_pp0_iter0_data_350_V_read376_phi_reg_21092 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_351_V_read377_phi_reg_21104() {
    ap_phi_reg_pp0_iter0_data_351_V_read377_phi_reg_21104 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_352_V_read378_phi_reg_21116() {
    ap_phi_reg_pp0_iter0_data_352_V_read378_phi_reg_21116 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_353_V_read379_phi_reg_21128() {
    ap_phi_reg_pp0_iter0_data_353_V_read379_phi_reg_21128 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_354_V_read380_phi_reg_21140() {
    ap_phi_reg_pp0_iter0_data_354_V_read380_phi_reg_21140 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_355_V_read381_phi_reg_21152() {
    ap_phi_reg_pp0_iter0_data_355_V_read381_phi_reg_21152 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_356_V_read382_phi_reg_21164() {
    ap_phi_reg_pp0_iter0_data_356_V_read382_phi_reg_21164 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_357_V_read383_phi_reg_21176() {
    ap_phi_reg_pp0_iter0_data_357_V_read383_phi_reg_21176 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_358_V_read384_phi_reg_21188() {
    ap_phi_reg_pp0_iter0_data_358_V_read384_phi_reg_21188 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_359_V_read385_phi_reg_21200() {
    ap_phi_reg_pp0_iter0_data_359_V_read385_phi_reg_21200 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_35_V_read61_phi_reg_17312() {
    ap_phi_reg_pp0_iter0_data_35_V_read61_phi_reg_17312 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_360_V_read386_phi_reg_21212() {
    ap_phi_reg_pp0_iter0_data_360_V_read386_phi_reg_21212 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_361_V_read387_phi_reg_21224() {
    ap_phi_reg_pp0_iter0_data_361_V_read387_phi_reg_21224 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_362_V_read388_phi_reg_21236() {
    ap_phi_reg_pp0_iter0_data_362_V_read388_phi_reg_21236 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_363_V_read389_phi_reg_21248() {
    ap_phi_reg_pp0_iter0_data_363_V_read389_phi_reg_21248 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_364_V_read390_phi_reg_21260() {
    ap_phi_reg_pp0_iter0_data_364_V_read390_phi_reg_21260 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_365_V_read391_phi_reg_21272() {
    ap_phi_reg_pp0_iter0_data_365_V_read391_phi_reg_21272 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_366_V_read392_phi_reg_21284() {
    ap_phi_reg_pp0_iter0_data_366_V_read392_phi_reg_21284 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_367_V_read393_phi_reg_21296() {
    ap_phi_reg_pp0_iter0_data_367_V_read393_phi_reg_21296 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_368_V_read394_phi_reg_21308() {
    ap_phi_reg_pp0_iter0_data_368_V_read394_phi_reg_21308 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_369_V_read395_phi_reg_21320() {
    ap_phi_reg_pp0_iter0_data_369_V_read395_phi_reg_21320 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_36_V_read62_phi_reg_17324() {
    ap_phi_reg_pp0_iter0_data_36_V_read62_phi_reg_17324 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_370_V_read396_phi_reg_21332() {
    ap_phi_reg_pp0_iter0_data_370_V_read396_phi_reg_21332 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_371_V_read397_phi_reg_21344() {
    ap_phi_reg_pp0_iter0_data_371_V_read397_phi_reg_21344 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_372_V_read398_phi_reg_21356() {
    ap_phi_reg_pp0_iter0_data_372_V_read398_phi_reg_21356 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_373_V_read399_phi_reg_21368() {
    ap_phi_reg_pp0_iter0_data_373_V_read399_phi_reg_21368 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_374_V_read400_phi_reg_21380() {
    ap_phi_reg_pp0_iter0_data_374_V_read400_phi_reg_21380 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_375_V_read401_phi_reg_21392() {
    ap_phi_reg_pp0_iter0_data_375_V_read401_phi_reg_21392 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_376_V_read402_phi_reg_21404() {
    ap_phi_reg_pp0_iter0_data_376_V_read402_phi_reg_21404 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_377_V_read403_phi_reg_21416() {
    ap_phi_reg_pp0_iter0_data_377_V_read403_phi_reg_21416 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_378_V_read404_phi_reg_21428() {
    ap_phi_reg_pp0_iter0_data_378_V_read404_phi_reg_21428 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_379_V_read405_phi_reg_21440() {
    ap_phi_reg_pp0_iter0_data_379_V_read405_phi_reg_21440 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_37_V_read63_phi_reg_17336() {
    ap_phi_reg_pp0_iter0_data_37_V_read63_phi_reg_17336 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_380_V_read406_phi_reg_21452() {
    ap_phi_reg_pp0_iter0_data_380_V_read406_phi_reg_21452 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_381_V_read407_phi_reg_21464() {
    ap_phi_reg_pp0_iter0_data_381_V_read407_phi_reg_21464 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_382_V_read408_phi_reg_21476() {
    ap_phi_reg_pp0_iter0_data_382_V_read408_phi_reg_21476 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_383_V_read409_phi_reg_21488() {
    ap_phi_reg_pp0_iter0_data_383_V_read409_phi_reg_21488 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_384_V_read410_phi_reg_21500() {
    ap_phi_reg_pp0_iter0_data_384_V_read410_phi_reg_21500 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_385_V_read411_phi_reg_21512() {
    ap_phi_reg_pp0_iter0_data_385_V_read411_phi_reg_21512 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_386_V_read412_phi_reg_21524() {
    ap_phi_reg_pp0_iter0_data_386_V_read412_phi_reg_21524 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_387_V_read413_phi_reg_21536() {
    ap_phi_reg_pp0_iter0_data_387_V_read413_phi_reg_21536 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_388_V_read414_phi_reg_21548() {
    ap_phi_reg_pp0_iter0_data_388_V_read414_phi_reg_21548 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_389_V_read415_phi_reg_21560() {
    ap_phi_reg_pp0_iter0_data_389_V_read415_phi_reg_21560 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_38_V_read64_phi_reg_17348() {
    ap_phi_reg_pp0_iter0_data_38_V_read64_phi_reg_17348 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_390_V_read416_phi_reg_21572() {
    ap_phi_reg_pp0_iter0_data_390_V_read416_phi_reg_21572 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_391_V_read417_phi_reg_21584() {
    ap_phi_reg_pp0_iter0_data_391_V_read417_phi_reg_21584 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_392_V_read418_phi_reg_21596() {
    ap_phi_reg_pp0_iter0_data_392_V_read418_phi_reg_21596 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_393_V_read419_phi_reg_21608() {
    ap_phi_reg_pp0_iter0_data_393_V_read419_phi_reg_21608 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_394_V_read420_phi_reg_21620() {
    ap_phi_reg_pp0_iter0_data_394_V_read420_phi_reg_21620 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_395_V_read421_phi_reg_21632() {
    ap_phi_reg_pp0_iter0_data_395_V_read421_phi_reg_21632 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_396_V_read422_phi_reg_21644() {
    ap_phi_reg_pp0_iter0_data_396_V_read422_phi_reg_21644 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_397_V_read423_phi_reg_21656() {
    ap_phi_reg_pp0_iter0_data_397_V_read423_phi_reg_21656 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_398_V_read424_phi_reg_21668() {
    ap_phi_reg_pp0_iter0_data_398_V_read424_phi_reg_21668 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_399_V_read425_phi_reg_21680() {
    ap_phi_reg_pp0_iter0_data_399_V_read425_phi_reg_21680 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_39_V_read65_phi_reg_17360() {
    ap_phi_reg_pp0_iter0_data_39_V_read65_phi_reg_17360 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_3_V_read29_phi_reg_16928() {
    ap_phi_reg_pp0_iter0_data_3_V_read29_phi_reg_16928 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_40_V_read66_phi_reg_17372() {
    ap_phi_reg_pp0_iter0_data_40_V_read66_phi_reg_17372 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_41_V_read67_phi_reg_17384() {
    ap_phi_reg_pp0_iter0_data_41_V_read67_phi_reg_17384 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_42_V_read68_phi_reg_17396() {
    ap_phi_reg_pp0_iter0_data_42_V_read68_phi_reg_17396 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_43_V_read69_phi_reg_17408() {
    ap_phi_reg_pp0_iter0_data_43_V_read69_phi_reg_17408 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_44_V_read70_phi_reg_17420() {
    ap_phi_reg_pp0_iter0_data_44_V_read70_phi_reg_17420 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_45_V_read71_phi_reg_17432() {
    ap_phi_reg_pp0_iter0_data_45_V_read71_phi_reg_17432 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_46_V_read72_phi_reg_17444() {
    ap_phi_reg_pp0_iter0_data_46_V_read72_phi_reg_17444 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_47_V_read73_phi_reg_17456() {
    ap_phi_reg_pp0_iter0_data_47_V_read73_phi_reg_17456 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_48_V_read74_phi_reg_17468() {
    ap_phi_reg_pp0_iter0_data_48_V_read74_phi_reg_17468 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_49_V_read75_phi_reg_17480() {
    ap_phi_reg_pp0_iter0_data_49_V_read75_phi_reg_17480 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_4_V_read30_phi_reg_16940() {
    ap_phi_reg_pp0_iter0_data_4_V_read30_phi_reg_16940 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_50_V_read76_phi_reg_17492() {
    ap_phi_reg_pp0_iter0_data_50_V_read76_phi_reg_17492 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_51_V_read77_phi_reg_17504() {
    ap_phi_reg_pp0_iter0_data_51_V_read77_phi_reg_17504 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_52_V_read78_phi_reg_17516() {
    ap_phi_reg_pp0_iter0_data_52_V_read78_phi_reg_17516 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_53_V_read79_phi_reg_17528() {
    ap_phi_reg_pp0_iter0_data_53_V_read79_phi_reg_17528 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_54_V_read80_phi_reg_17540() {
    ap_phi_reg_pp0_iter0_data_54_V_read80_phi_reg_17540 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_55_V_read81_phi_reg_17552() {
    ap_phi_reg_pp0_iter0_data_55_V_read81_phi_reg_17552 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_56_V_read82_phi_reg_17564() {
    ap_phi_reg_pp0_iter0_data_56_V_read82_phi_reg_17564 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_57_V_read83_phi_reg_17576() {
    ap_phi_reg_pp0_iter0_data_57_V_read83_phi_reg_17576 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_58_V_read84_phi_reg_17588() {
    ap_phi_reg_pp0_iter0_data_58_V_read84_phi_reg_17588 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_59_V_read85_phi_reg_17600() {
    ap_phi_reg_pp0_iter0_data_59_V_read85_phi_reg_17600 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_5_V_read31_phi_reg_16952() {
    ap_phi_reg_pp0_iter0_data_5_V_read31_phi_reg_16952 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_60_V_read86_phi_reg_17612() {
    ap_phi_reg_pp0_iter0_data_60_V_read86_phi_reg_17612 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_61_V_read87_phi_reg_17624() {
    ap_phi_reg_pp0_iter0_data_61_V_read87_phi_reg_17624 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_62_V_read88_phi_reg_17636() {
    ap_phi_reg_pp0_iter0_data_62_V_read88_phi_reg_17636 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_63_V_read89_phi_reg_17648() {
    ap_phi_reg_pp0_iter0_data_63_V_read89_phi_reg_17648 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_64_V_read90_phi_reg_17660() {
    ap_phi_reg_pp0_iter0_data_64_V_read90_phi_reg_17660 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_65_V_read91_phi_reg_17672() {
    ap_phi_reg_pp0_iter0_data_65_V_read91_phi_reg_17672 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_66_V_read92_phi_reg_17684() {
    ap_phi_reg_pp0_iter0_data_66_V_read92_phi_reg_17684 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_67_V_read93_phi_reg_17696() {
    ap_phi_reg_pp0_iter0_data_67_V_read93_phi_reg_17696 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_68_V_read94_phi_reg_17708() {
    ap_phi_reg_pp0_iter0_data_68_V_read94_phi_reg_17708 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_69_V_read95_phi_reg_17720() {
    ap_phi_reg_pp0_iter0_data_69_V_read95_phi_reg_17720 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_6_V_read32_phi_reg_16964() {
    ap_phi_reg_pp0_iter0_data_6_V_read32_phi_reg_16964 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_70_V_read96_phi_reg_17732() {
    ap_phi_reg_pp0_iter0_data_70_V_read96_phi_reg_17732 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_71_V_read97_phi_reg_17744() {
    ap_phi_reg_pp0_iter0_data_71_V_read97_phi_reg_17744 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_72_V_read98_phi_reg_17756() {
    ap_phi_reg_pp0_iter0_data_72_V_read98_phi_reg_17756 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_73_V_read99_phi_reg_17768() {
    ap_phi_reg_pp0_iter0_data_73_V_read99_phi_reg_17768 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_74_V_read100_phi_reg_17780() {
    ap_phi_reg_pp0_iter0_data_74_V_read100_phi_reg_17780 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_75_V_read101_phi_reg_17792() {
    ap_phi_reg_pp0_iter0_data_75_V_read101_phi_reg_17792 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_76_V_read102_phi_reg_17804() {
    ap_phi_reg_pp0_iter0_data_76_V_read102_phi_reg_17804 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_77_V_read103_phi_reg_17816() {
    ap_phi_reg_pp0_iter0_data_77_V_read103_phi_reg_17816 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_78_V_read104_phi_reg_17828() {
    ap_phi_reg_pp0_iter0_data_78_V_read104_phi_reg_17828 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_79_V_read105_phi_reg_17840() {
    ap_phi_reg_pp0_iter0_data_79_V_read105_phi_reg_17840 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_7_V_read33_phi_reg_16976() {
    ap_phi_reg_pp0_iter0_data_7_V_read33_phi_reg_16976 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_80_V_read106_phi_reg_17852() {
    ap_phi_reg_pp0_iter0_data_80_V_read106_phi_reg_17852 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_81_V_read107_phi_reg_17864() {
    ap_phi_reg_pp0_iter0_data_81_V_read107_phi_reg_17864 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_82_V_read108_phi_reg_17876() {
    ap_phi_reg_pp0_iter0_data_82_V_read108_phi_reg_17876 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_83_V_read109_phi_reg_17888() {
    ap_phi_reg_pp0_iter0_data_83_V_read109_phi_reg_17888 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_84_V_read110_phi_reg_17900() {
    ap_phi_reg_pp0_iter0_data_84_V_read110_phi_reg_17900 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_85_V_read111_phi_reg_17912() {
    ap_phi_reg_pp0_iter0_data_85_V_read111_phi_reg_17912 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_86_V_read112_phi_reg_17924() {
    ap_phi_reg_pp0_iter0_data_86_V_read112_phi_reg_17924 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_87_V_read113_phi_reg_17936() {
    ap_phi_reg_pp0_iter0_data_87_V_read113_phi_reg_17936 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_88_V_read114_phi_reg_17948() {
    ap_phi_reg_pp0_iter0_data_88_V_read114_phi_reg_17948 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_89_V_read115_phi_reg_17960() {
    ap_phi_reg_pp0_iter0_data_89_V_read115_phi_reg_17960 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_8_V_read34_phi_reg_16988() {
    ap_phi_reg_pp0_iter0_data_8_V_read34_phi_reg_16988 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_90_V_read116_phi_reg_17972() {
    ap_phi_reg_pp0_iter0_data_90_V_read116_phi_reg_17972 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_91_V_read117_phi_reg_17984() {
    ap_phi_reg_pp0_iter0_data_91_V_read117_phi_reg_17984 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_92_V_read118_phi_reg_17996() {
    ap_phi_reg_pp0_iter0_data_92_V_read118_phi_reg_17996 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_93_V_read119_phi_reg_18008() {
    ap_phi_reg_pp0_iter0_data_93_V_read119_phi_reg_18008 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_94_V_read120_phi_reg_18020() {
    ap_phi_reg_pp0_iter0_data_94_V_read120_phi_reg_18020 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_95_V_read121_phi_reg_18032() {
    ap_phi_reg_pp0_iter0_data_95_V_read121_phi_reg_18032 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_96_V_read122_phi_reg_18044() {
    ap_phi_reg_pp0_iter0_data_96_V_read122_phi_reg_18044 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_97_V_read123_phi_reg_18056() {
    ap_phi_reg_pp0_iter0_data_97_V_read123_phi_reg_18056 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_98_V_read124_phi_reg_18068() {
    ap_phi_reg_pp0_iter0_data_98_V_read124_phi_reg_18068 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_99_V_read125_phi_reg_18080() {
    ap_phi_reg_pp0_iter0_data_99_V_read125_phi_reg_18080 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_9_V_read35_phi_reg_17000() {
    ap_phi_reg_pp0_iter0_data_9_V_read35_phi_reg_17000 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_ready() {
    if ((esl_seteq<1,1,1>(ap_phi_mux_w_index25_phi_fu_11281_p6.read(), ap_const_lv1_1) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0_11001.read()))) {
        ap_ready = ap_const_logic_1;
    } else {
        ap_ready = ap_const_logic_0;
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_reset_idle_pp0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_idle_pp0_0to5.read()))) {
        ap_reset_idle_pp0 = ap_const_logic_1;
    } else {
        ap_reset_idle_pp0 = ap_const_logic_0;
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_0() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter5_reg.read()))) {
        ap_return_0 = acc_0_V_fu_101500_p2.read();
    } else {
        ap_return_0 = ap_return_0_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_1() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter5_reg.read()))) {
        ap_return_1 = acc_1_V_fu_101510_p2.read();
    } else {
        ap_return_1 = ap_return_1_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_2() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter5_reg.read()))) {
        ap_return_2 = acc_2_V_fu_101520_p2.read();
    } else {
        ap_return_2 = ap_return_2_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_3() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter5_reg.read()))) {
        ap_return_3 = acc_3_V_fu_101530_p2.read();
    } else {
        ap_return_3 = ap_return_3_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_4() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter5_reg.read()))) {
        ap_return_4 = acc_4_V_fu_101540_p2.read();
    } else {
        ap_return_4 = ap_return_4_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_5() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter5_reg.read()))) {
        ap_return_5 = acc_5_V_fu_101550_p2.read();
    } else {
        ap_return_5 = ap_return_5_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter5_reg.read()))) {
        ap_return_6 = acc_6_V_fu_101560_p2.read();
    } else {
        ap_return_6 = ap_return_6_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_7() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter5_reg.read()))) {
        ap_return_7 = acc_7_V_fu_101570_p2.read();
    } else {
        ap_return_7 = ap_return_7_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_8() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter5_reg.read()))) {
        ap_return_8 = acc_8_V_fu_101580_p2.read();
    } else {
        ap_return_8 = ap_return_8_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_9() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0_11001.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter6.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter5_reg.read()))) {
        ap_return_9 = acc_9_V_fu_101590_p2.read();
    } else {
        ap_return_9 = ap_return_9_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1000_fu_62385_p0() {
    mul_ln1118_1000_fu_62385_p0 =  (sc_lv<3>) (sext_ln1116_200_fu_47163_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1000_fu_62385_p1() {
    mul_ln1118_1000_fu_62385_p1 = tmp_1000_reg_109631.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1000_fu_62385_p2() {
    mul_ln1118_1000_fu_62385_p2 = (!mul_ln1118_1000_fu_62385_p0.read().is_01() || !mul_ln1118_1000_fu_62385_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1000_fu_62385_p0.read()) * sc_bigint<5>(mul_ln1118_1000_fu_62385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1001_fu_62406_p0() {
    mul_ln1118_1001_fu_62406_p0 =  (sc_lv<3>) (sext_ln1116_201_fu_47187_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1001_fu_62406_p1() {
    mul_ln1118_1001_fu_62406_p1 = tmp_1001_reg_109636.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1001_fu_62406_p2() {
    mul_ln1118_1001_fu_62406_p2 = (!mul_ln1118_1001_fu_62406_p0.read().is_01() || !mul_ln1118_1001_fu_62406_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1001_fu_62406_p0.read()) * sc_bigint<5>(mul_ln1118_1001_fu_62406_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1002_fu_62427_p0() {
    mul_ln1118_1002_fu_62427_p0 =  (sc_lv<3>) (sext_ln1116_202_fu_47211_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1002_fu_62427_p1() {
    mul_ln1118_1002_fu_62427_p1 = tmp_1002_reg_109641.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1002_fu_62427_p2() {
    mul_ln1118_1002_fu_62427_p2 = (!mul_ln1118_1002_fu_62427_p0.read().is_01() || !mul_ln1118_1002_fu_62427_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1002_fu_62427_p0.read()) * sc_bigint<5>(mul_ln1118_1002_fu_62427_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1003_fu_62436_p0() {
    mul_ln1118_1003_fu_62436_p0 =  (sc_lv<3>) (sext_ln1116_203_fu_47223_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1003_fu_62436_p1() {
    mul_ln1118_1003_fu_62436_p1 = tmp_1003_reg_109646.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1003_fu_62436_p2() {
    mul_ln1118_1003_fu_62436_p2 = (!mul_ln1118_1003_fu_62436_p0.read().is_01() || !mul_ln1118_1003_fu_62436_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1003_fu_62436_p0.read()) * sc_bigint<5>(mul_ln1118_1003_fu_62436_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1004_fu_62457_p0() {
    mul_ln1118_1004_fu_62457_p0 =  (sc_lv<3>) (sext_ln1116_204_fu_47247_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1004_fu_62457_p1() {
    mul_ln1118_1004_fu_62457_p1 = tmp_1004_reg_109651.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1004_fu_62457_p2() {
    mul_ln1118_1004_fu_62457_p2 = (!mul_ln1118_1004_fu_62457_p0.read().is_01() || !mul_ln1118_1004_fu_62457_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1004_fu_62457_p0.read()) * sc_bigint<5>(mul_ln1118_1004_fu_62457_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1005_fu_62478_p0() {
    mul_ln1118_1005_fu_62478_p0 =  (sc_lv<3>) (sext_ln1116_205_fu_47271_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1005_fu_62478_p1() {
    mul_ln1118_1005_fu_62478_p1 = tmp_1005_reg_109656.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1005_fu_62478_p2() {
    mul_ln1118_1005_fu_62478_p2 = (!mul_ln1118_1005_fu_62478_p0.read().is_01() || !mul_ln1118_1005_fu_62478_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1005_fu_62478_p0.read()) * sc_bigint<5>(mul_ln1118_1005_fu_62478_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1006_fu_62499_p0() {
    mul_ln1118_1006_fu_62499_p0 =  (sc_lv<3>) (sext_ln1116_206_fu_47295_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1006_fu_62499_p1() {
    mul_ln1118_1006_fu_62499_p1 = tmp_1006_reg_109661.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1006_fu_62499_p2() {
    mul_ln1118_1006_fu_62499_p2 = (!mul_ln1118_1006_fu_62499_p0.read().is_01() || !mul_ln1118_1006_fu_62499_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1006_fu_62499_p0.read()) * sc_bigint<5>(mul_ln1118_1006_fu_62499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1007_fu_62520_p0() {
    mul_ln1118_1007_fu_62520_p0 =  (sc_lv<3>) (sext_ln1116_207_fu_47319_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1007_fu_62520_p1() {
    mul_ln1118_1007_fu_62520_p1 = tmp_1007_reg_109666.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1007_fu_62520_p2() {
    mul_ln1118_1007_fu_62520_p2 = (!mul_ln1118_1007_fu_62520_p0.read().is_01() || !mul_ln1118_1007_fu_62520_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1007_fu_62520_p0.read()) * sc_bigint<5>(mul_ln1118_1007_fu_62520_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1008_fu_62541_p0() {
    mul_ln1118_1008_fu_62541_p0 =  (sc_lv<3>) (sext_ln1116_208_fu_47343_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1008_fu_62541_p1() {
    mul_ln1118_1008_fu_62541_p1 = tmp_1008_reg_109671.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1008_fu_62541_p2() {
    mul_ln1118_1008_fu_62541_p2 = (!mul_ln1118_1008_fu_62541_p0.read().is_01() || !mul_ln1118_1008_fu_62541_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1008_fu_62541_p0.read()) * sc_bigint<5>(mul_ln1118_1008_fu_62541_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1009_fu_62994_p0() {
    mul_ln1118_1009_fu_62994_p0 =  (sc_lv<3>) (sext_ln1116_fu_43407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1009_fu_62994_p1() {
    mul_ln1118_1009_fu_62994_p1 = tmp_1009_reg_109676.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1009_fu_62994_p2() {
    mul_ln1118_1009_fu_62994_p2 = (!mul_ln1118_1009_fu_62994_p0.read().is_01() || !mul_ln1118_1009_fu_62994_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1009_fu_62994_p0.read()) * sc_bigint<5>(mul_ln1118_1009_fu_62994_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_100_fu_45186_p0() {
    mul_ln1118_100_fu_45186_p0 =  (sc_lv<3>) (sext_ln1116_100_fu_45180_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_100_fu_45186_p1() {
    mul_ln1118_100_fu_45186_p1 = tmp_100_reg_104590.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_100_fu_45186_p2() {
    mul_ln1118_100_fu_45186_p2 = (!mul_ln1118_100_fu_45186_p0.read().is_01() || !mul_ln1118_100_fu_45186_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_100_fu_45186_p0.read()) * sc_bigint<5>(mul_ln1118_100_fu_45186_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1010_fu_63003_p0() {
    mul_ln1118_1010_fu_63003_p0 =  (sc_lv<3>) (sext_ln1116_10_fu_43419_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1010_fu_63003_p1() {
    mul_ln1118_1010_fu_63003_p1 = tmp_1010_reg_109681.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1010_fu_63003_p2() {
    mul_ln1118_1010_fu_63003_p2 = (!mul_ln1118_1010_fu_63003_p0.read().is_01() || !mul_ln1118_1010_fu_63003_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1010_fu_63003_p0.read()) * sc_bigint<5>(mul_ln1118_1010_fu_63003_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1011_fu_63024_p0() {
    mul_ln1118_1011_fu_63024_p0 =  (sc_lv<3>) (sext_ln1116_11_fu_43443_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1011_fu_63024_p1() {
    mul_ln1118_1011_fu_63024_p1 = tmp_1011_reg_109686.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1011_fu_63024_p2() {
    mul_ln1118_1011_fu_63024_p2 = (!mul_ln1118_1011_fu_63024_p0.read().is_01() || !mul_ln1118_1011_fu_63024_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1011_fu_63024_p0.read()) * sc_bigint<5>(mul_ln1118_1011_fu_63024_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1012_fu_63045_p0() {
    mul_ln1118_1012_fu_63045_p0 =  (sc_lv<3>) (sext_ln1116_12_fu_43467_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1012_fu_63045_p1() {
    mul_ln1118_1012_fu_63045_p1 = tmp_1012_reg_109691.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1012_fu_63045_p2() {
    mul_ln1118_1012_fu_63045_p2 = (!mul_ln1118_1012_fu_63045_p0.read().is_01() || !mul_ln1118_1012_fu_63045_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1012_fu_63045_p0.read()) * sc_bigint<5>(mul_ln1118_1012_fu_63045_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1013_fu_63054_p0() {
    mul_ln1118_1013_fu_63054_p0 =  (sc_lv<3>) (sext_ln1116_13_fu_43479_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1013_fu_63054_p1() {
    mul_ln1118_1013_fu_63054_p1 = tmp_1013_reg_109696.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1013_fu_63054_p2() {
    mul_ln1118_1013_fu_63054_p2 = (!mul_ln1118_1013_fu_63054_p0.read().is_01() || !mul_ln1118_1013_fu_63054_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1013_fu_63054_p0.read()) * sc_bigint<5>(mul_ln1118_1013_fu_63054_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1014_fu_63075_p0() {
    mul_ln1118_1014_fu_63075_p0 =  (sc_lv<3>) (sext_ln1116_14_fu_43503_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1014_fu_63075_p1() {
    mul_ln1118_1014_fu_63075_p1 = tmp_1014_reg_109701.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1014_fu_63075_p2() {
    mul_ln1118_1014_fu_63075_p2 = (!mul_ln1118_1014_fu_63075_p0.read().is_01() || !mul_ln1118_1014_fu_63075_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1014_fu_63075_p0.read()) * sc_bigint<5>(mul_ln1118_1014_fu_63075_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1015_fu_90529_p0() {
    mul_ln1118_1015_fu_90529_p0 =  (sc_lv<3>) (sext_ln1116_15_fu_82080_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1015_fu_90529_p1() {
    mul_ln1118_1015_fu_90529_p1 = tmp_1015_reg_109706_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1015_fu_90529_p2() {
    mul_ln1118_1015_fu_90529_p2 = (!mul_ln1118_1015_fu_90529_p0.read().is_01() || !mul_ln1118_1015_fu_90529_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1015_fu_90529_p0.read()) * sc_bigint<5>(mul_ln1118_1015_fu_90529_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1016_fu_63096_p0() {
    mul_ln1118_1016_fu_63096_p0 =  (sc_lv<3>) (sext_ln1116_16_fu_43527_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1016_fu_63096_p1() {
    mul_ln1118_1016_fu_63096_p1 = tmp_1016_reg_109711.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1016_fu_63096_p2() {
    mul_ln1118_1016_fu_63096_p2 = (!mul_ln1118_1016_fu_63096_p0.read().is_01() || !mul_ln1118_1016_fu_63096_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1016_fu_63096_p0.read()) * sc_bigint<5>(mul_ln1118_1016_fu_63096_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1017_fu_63117_p0() {
    mul_ln1118_1017_fu_63117_p0 =  (sc_lv<3>) (sext_ln1116_17_fu_43551_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1017_fu_63117_p1() {
    mul_ln1118_1017_fu_63117_p1 = tmp_1017_reg_109716.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1017_fu_63117_p2() {
    mul_ln1118_1017_fu_63117_p2 = (!mul_ln1118_1017_fu_63117_p0.read().is_01() || !mul_ln1118_1017_fu_63117_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1017_fu_63117_p0.read()) * sc_bigint<5>(mul_ln1118_1017_fu_63117_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1018_fu_90550_p0() {
    mul_ln1118_1018_fu_90550_p0 =  (sc_lv<3>) (sext_ln1116_18_fu_82104_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1018_fu_90550_p1() {
    mul_ln1118_1018_fu_90550_p1 = tmp_1018_reg_109721_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1018_fu_90550_p2() {
    mul_ln1118_1018_fu_90550_p2 = (!mul_ln1118_1018_fu_90550_p0.read().is_01() || !mul_ln1118_1018_fu_90550_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1018_fu_90550_p0.read()) * sc_bigint<5>(mul_ln1118_1018_fu_90550_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1019_fu_63138_p0() {
    mul_ln1118_1019_fu_63138_p0 =  (sc_lv<3>) (sext_ln1116_19_fu_43575_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1019_fu_63138_p1() {
    mul_ln1118_1019_fu_63138_p1 = tmp_1019_reg_109726.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1019_fu_63138_p2() {
    mul_ln1118_1019_fu_63138_p2 = (!mul_ln1118_1019_fu_63138_p0.read().is_01() || !mul_ln1118_1019_fu_63138_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1019_fu_63138_p0.read()) * sc_bigint<5>(mul_ln1118_1019_fu_63138_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_101_fu_45210_p0() {
    mul_ln1118_101_fu_45210_p0 =  (sc_lv<3>) (sext_ln1116_101_fu_45204_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_101_fu_45210_p1() {
    mul_ln1118_101_fu_45210_p1 = tmp_101_reg_104600.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_101_fu_45210_p2() {
    mul_ln1118_101_fu_45210_p2 = (!mul_ln1118_101_fu_45210_p0.read().is_01() || !mul_ln1118_101_fu_45210_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_101_fu_45210_p0.read()) * sc_bigint<5>(mul_ln1118_101_fu_45210_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1020_fu_63159_p0() {
    mul_ln1118_1020_fu_63159_p0 =  (sc_lv<3>) (sext_ln1116_20_fu_43599_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1020_fu_63159_p1() {
    mul_ln1118_1020_fu_63159_p1 = tmp_1020_reg_109731.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1020_fu_63159_p2() {
    mul_ln1118_1020_fu_63159_p2 = (!mul_ln1118_1020_fu_63159_p0.read().is_01() || !mul_ln1118_1020_fu_63159_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1020_fu_63159_p0.read()) * sc_bigint<5>(mul_ln1118_1020_fu_63159_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1021_fu_63180_p0() {
    mul_ln1118_1021_fu_63180_p0 =  (sc_lv<3>) (sext_ln1116_21_fu_43623_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1021_fu_63180_p1() {
    mul_ln1118_1021_fu_63180_p1 = tmp_1021_reg_109736.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1021_fu_63180_p2() {
    mul_ln1118_1021_fu_63180_p2 = (!mul_ln1118_1021_fu_63180_p0.read().is_01() || !mul_ln1118_1021_fu_63180_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1021_fu_63180_p0.read()) * sc_bigint<5>(mul_ln1118_1021_fu_63180_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1022_fu_63189_p0() {
    mul_ln1118_1022_fu_63189_p0 =  (sc_lv<3>) (sext_ln1116_22_fu_43635_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1022_fu_63189_p1() {
    mul_ln1118_1022_fu_63189_p1 = tmp_1022_reg_109741.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1022_fu_63189_p2() {
    mul_ln1118_1022_fu_63189_p2 = (!mul_ln1118_1022_fu_63189_p0.read().is_01() || !mul_ln1118_1022_fu_63189_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1022_fu_63189_p0.read()) * sc_bigint<5>(mul_ln1118_1022_fu_63189_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1023_fu_63210_p0() {
    mul_ln1118_1023_fu_63210_p0 =  (sc_lv<3>) (sext_ln1116_23_fu_43659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1023_fu_63210_p1() {
    mul_ln1118_1023_fu_63210_p1 = tmp_1023_reg_109746.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1023_fu_63210_p2() {
    mul_ln1118_1023_fu_63210_p2 = (!mul_ln1118_1023_fu_63210_p0.read().is_01() || !mul_ln1118_1023_fu_63210_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1023_fu_63210_p0.read()) * sc_bigint<5>(mul_ln1118_1023_fu_63210_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1024_fu_63231_p0() {
    mul_ln1118_1024_fu_63231_p0 =  (sc_lv<3>) (sext_ln1116_24_fu_43683_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1024_fu_63231_p1() {
    mul_ln1118_1024_fu_63231_p1 = tmp_1024_reg_109751.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1024_fu_63231_p2() {
    mul_ln1118_1024_fu_63231_p2 = (!mul_ln1118_1024_fu_63231_p0.read().is_01() || !mul_ln1118_1024_fu_63231_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1024_fu_63231_p0.read()) * sc_bigint<5>(mul_ln1118_1024_fu_63231_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1025_fu_63240_p0() {
    mul_ln1118_1025_fu_63240_p0 =  (sc_lv<3>) (sext_ln1116_25_fu_43695_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1025_fu_63240_p1() {
    mul_ln1118_1025_fu_63240_p1 = tmp_1025_reg_109756.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1025_fu_63240_p2() {
    mul_ln1118_1025_fu_63240_p2 = (!mul_ln1118_1025_fu_63240_p0.read().is_01() || !mul_ln1118_1025_fu_63240_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1025_fu_63240_p0.read()) * sc_bigint<5>(mul_ln1118_1025_fu_63240_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1026_fu_63261_p0() {
    mul_ln1118_1026_fu_63261_p0 =  (sc_lv<3>) (sext_ln1116_26_fu_43719_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1026_fu_63261_p1() {
    mul_ln1118_1026_fu_63261_p1 = tmp_1026_reg_109761.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1026_fu_63261_p2() {
    mul_ln1118_1026_fu_63261_p2 = (!mul_ln1118_1026_fu_63261_p0.read().is_01() || !mul_ln1118_1026_fu_63261_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1026_fu_63261_p0.read()) * sc_bigint<5>(mul_ln1118_1026_fu_63261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1027_fu_63282_p0() {
    mul_ln1118_1027_fu_63282_p0 =  (sc_lv<3>) (sext_ln1116_27_fu_43743_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1027_fu_63282_p1() {
    mul_ln1118_1027_fu_63282_p1 = tmp_1027_reg_109766.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1027_fu_63282_p2() {
    mul_ln1118_1027_fu_63282_p2 = (!mul_ln1118_1027_fu_63282_p0.read().is_01() || !mul_ln1118_1027_fu_63282_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1027_fu_63282_p0.read()) * sc_bigint<5>(mul_ln1118_1027_fu_63282_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1028_fu_63291_p0() {
    mul_ln1118_1028_fu_63291_p0 =  (sc_lv<3>) (sext_ln1116_28_fu_43755_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1028_fu_63291_p1() {
    mul_ln1118_1028_fu_63291_p1 = tmp_1028_reg_109771.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1028_fu_63291_p2() {
    mul_ln1118_1028_fu_63291_p2 = (!mul_ln1118_1028_fu_63291_p0.read().is_01() || !mul_ln1118_1028_fu_63291_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1028_fu_63291_p0.read()) * sc_bigint<5>(mul_ln1118_1028_fu_63291_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1029_fu_63312_p0() {
    mul_ln1118_1029_fu_63312_p0 =  (sc_lv<3>) (sext_ln1116_29_fu_43779_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1029_fu_63312_p1() {
    mul_ln1118_1029_fu_63312_p1 = tmp_1029_reg_109776.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1029_fu_63312_p2() {
    mul_ln1118_1029_fu_63312_p2 = (!mul_ln1118_1029_fu_63312_p0.read().is_01() || !mul_ln1118_1029_fu_63312_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1029_fu_63312_p0.read()) * sc_bigint<5>(mul_ln1118_1029_fu_63312_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_102_fu_45234_p0() {
    mul_ln1118_102_fu_45234_p0 =  (sc_lv<3>) (sext_ln1116_102_fu_45228_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_102_fu_45234_p1() {
    mul_ln1118_102_fu_45234_p1 = tmp_102_reg_104610.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_102_fu_45234_p2() {
    mul_ln1118_102_fu_45234_p2 = (!mul_ln1118_102_fu_45234_p0.read().is_01() || !mul_ln1118_102_fu_45234_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_102_fu_45234_p0.read()) * sc_bigint<5>(mul_ln1118_102_fu_45234_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1030_fu_63333_p0() {
    mul_ln1118_1030_fu_63333_p0 =  (sc_lv<3>) (sext_ln1116_30_fu_43803_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1030_fu_63333_p1() {
    mul_ln1118_1030_fu_63333_p1 = tmp_1030_reg_109781.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1030_fu_63333_p2() {
    mul_ln1118_1030_fu_63333_p2 = (!mul_ln1118_1030_fu_63333_p0.read().is_01() || !mul_ln1118_1030_fu_63333_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1030_fu_63333_p0.read()) * sc_bigint<5>(mul_ln1118_1030_fu_63333_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1031_fu_63354_p0() {
    mul_ln1118_1031_fu_63354_p0 =  (sc_lv<3>) (sext_ln1116_31_fu_43827_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1031_fu_63354_p1() {
    mul_ln1118_1031_fu_63354_p1 = tmp_1031_reg_109786.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1031_fu_63354_p2() {
    mul_ln1118_1031_fu_63354_p2 = (!mul_ln1118_1031_fu_63354_p0.read().is_01() || !mul_ln1118_1031_fu_63354_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1031_fu_63354_p0.read()) * sc_bigint<5>(mul_ln1118_1031_fu_63354_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1032_fu_63375_p0() {
    mul_ln1118_1032_fu_63375_p0 =  (sc_lv<3>) (sext_ln1116_32_fu_43851_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1032_fu_63375_p1() {
    mul_ln1118_1032_fu_63375_p1 = tmp_1032_reg_109791.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1032_fu_63375_p2() {
    mul_ln1118_1032_fu_63375_p2 = (!mul_ln1118_1032_fu_63375_p0.read().is_01() || !mul_ln1118_1032_fu_63375_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1032_fu_63375_p0.read()) * sc_bigint<5>(mul_ln1118_1032_fu_63375_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1033_fu_63396_p0() {
    mul_ln1118_1033_fu_63396_p0 =  (sc_lv<3>) (sext_ln1116_33_fu_43875_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1033_fu_63396_p1() {
    mul_ln1118_1033_fu_63396_p1 = tmp_1033_reg_109796.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1033_fu_63396_p2() {
    mul_ln1118_1033_fu_63396_p2 = (!mul_ln1118_1033_fu_63396_p0.read().is_01() || !mul_ln1118_1033_fu_63396_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1033_fu_63396_p0.read()) * sc_bigint<5>(mul_ln1118_1033_fu_63396_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1034_fu_63417_p0() {
    mul_ln1118_1034_fu_63417_p0 =  (sc_lv<3>) (sext_ln1116_34_fu_43899_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1034_fu_63417_p1() {
    mul_ln1118_1034_fu_63417_p1 = tmp_1034_reg_109801.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1034_fu_63417_p2() {
    mul_ln1118_1034_fu_63417_p2 = (!mul_ln1118_1034_fu_63417_p0.read().is_01() || !mul_ln1118_1034_fu_63417_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1034_fu_63417_p0.read()) * sc_bigint<5>(mul_ln1118_1034_fu_63417_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1035_fu_63426_p0() {
    mul_ln1118_1035_fu_63426_p0 =  (sc_lv<3>) (sext_ln1116_35_fu_43911_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1035_fu_63426_p1() {
    mul_ln1118_1035_fu_63426_p1 = tmp_1035_reg_109806.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1035_fu_63426_p2() {
    mul_ln1118_1035_fu_63426_p2 = (!mul_ln1118_1035_fu_63426_p0.read().is_01() || !mul_ln1118_1035_fu_63426_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1035_fu_63426_p0.read()) * sc_bigint<5>(mul_ln1118_1035_fu_63426_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1036_fu_63447_p0() {
    mul_ln1118_1036_fu_63447_p0 =  (sc_lv<3>) (sext_ln1116_36_fu_43935_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1036_fu_63447_p1() {
    mul_ln1118_1036_fu_63447_p1 = tmp_1036_reg_109811.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1036_fu_63447_p2() {
    mul_ln1118_1036_fu_63447_p2 = (!mul_ln1118_1036_fu_63447_p0.read().is_01() || !mul_ln1118_1036_fu_63447_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1036_fu_63447_p0.read()) * sc_bigint<5>(mul_ln1118_1036_fu_63447_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1037_fu_63468_p0() {
    mul_ln1118_1037_fu_63468_p0 =  (sc_lv<3>) (sext_ln1116_37_fu_43959_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1037_fu_63468_p1() {
    mul_ln1118_1037_fu_63468_p1 = tmp_1037_reg_109816.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1037_fu_63468_p2() {
    mul_ln1118_1037_fu_63468_p2 = (!mul_ln1118_1037_fu_63468_p0.read().is_01() || !mul_ln1118_1037_fu_63468_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1037_fu_63468_p0.read()) * sc_bigint<5>(mul_ln1118_1037_fu_63468_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1038_fu_63477_p0() {
    mul_ln1118_1038_fu_63477_p0 =  (sc_lv<3>) (sext_ln1116_38_fu_43971_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1038_fu_63477_p1() {
    mul_ln1118_1038_fu_63477_p1 = tmp_1038_reg_109821.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1038_fu_63477_p2() {
    mul_ln1118_1038_fu_63477_p2 = (!mul_ln1118_1038_fu_63477_p0.read().is_01() || !mul_ln1118_1038_fu_63477_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1038_fu_63477_p0.read()) * sc_bigint<5>(mul_ln1118_1038_fu_63477_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1039_fu_63498_p0() {
    mul_ln1118_1039_fu_63498_p0 =  (sc_lv<3>) (sext_ln1116_39_fu_43995_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1039_fu_63498_p1() {
    mul_ln1118_1039_fu_63498_p1 = tmp_1039_reg_109826.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1039_fu_63498_p2() {
    mul_ln1118_1039_fu_63498_p2 = (!mul_ln1118_1039_fu_63498_p0.read().is_01() || !mul_ln1118_1039_fu_63498_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1039_fu_63498_p0.read()) * sc_bigint<5>(mul_ln1118_1039_fu_63498_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_103_fu_45246_p0() {
    mul_ln1118_103_fu_45246_p0 =  (sc_lv<3>) (sext_ln1116_103_fu_45240_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_103_fu_45246_p1() {
    mul_ln1118_103_fu_45246_p1 = tmp_103_reg_104620.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_103_fu_45246_p2() {
    mul_ln1118_103_fu_45246_p2 = (!mul_ln1118_103_fu_45246_p0.read().is_01() || !mul_ln1118_103_fu_45246_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_103_fu_45246_p0.read()) * sc_bigint<5>(mul_ln1118_103_fu_45246_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1040_fu_90626_p0() {
    mul_ln1118_1040_fu_90626_p0 =  (sc_lv<3>) (sext_ln1116_40_reg_114696.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1040_fu_90626_p1() {
    mul_ln1118_1040_fu_90626_p1 = tmp_1040_reg_109831_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1040_fu_90626_p2() {
    mul_ln1118_1040_fu_90626_p2 = (!mul_ln1118_1040_fu_90626_p0.read().is_01() || !mul_ln1118_1040_fu_90626_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1040_fu_90626_p0.read()) * sc_bigint<5>(mul_ln1118_1040_fu_90626_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1041_fu_63519_p0() {
    mul_ln1118_1041_fu_63519_p0 =  (sc_lv<3>) (sext_ln1116_41_fu_44022_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1041_fu_63519_p1() {
    mul_ln1118_1041_fu_63519_p1 = tmp_1041_reg_109836.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1041_fu_63519_p2() {
    mul_ln1118_1041_fu_63519_p2 = (!mul_ln1118_1041_fu_63519_p0.read().is_01() || !mul_ln1118_1041_fu_63519_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1041_fu_63519_p0.read()) * sc_bigint<5>(mul_ln1118_1041_fu_63519_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1042_fu_63540_p0() {
    mul_ln1118_1042_fu_63540_p0 =  (sc_lv<3>) (sext_ln1116_42_fu_44046_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1042_fu_63540_p1() {
    mul_ln1118_1042_fu_63540_p1 = tmp_1042_reg_109841.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1042_fu_63540_p2() {
    mul_ln1118_1042_fu_63540_p2 = (!mul_ln1118_1042_fu_63540_p0.read().is_01() || !mul_ln1118_1042_fu_63540_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1042_fu_63540_p0.read()) * sc_bigint<5>(mul_ln1118_1042_fu_63540_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1043_fu_90646_p0() {
    mul_ln1118_1043_fu_90646_p0 =  (sc_lv<3>) (sext_ln1116_43_reg_114709.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1043_fu_90646_p1() {
    mul_ln1118_1043_fu_90646_p1 = tmp_1043_reg_109846_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1043_fu_90646_p2() {
    mul_ln1118_1043_fu_90646_p2 = (!mul_ln1118_1043_fu_90646_p0.read().is_01() || !mul_ln1118_1043_fu_90646_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1043_fu_90646_p0.read()) * sc_bigint<5>(mul_ln1118_1043_fu_90646_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1044_fu_63561_p0() {
    mul_ln1118_1044_fu_63561_p0 =  (sc_lv<3>) (sext_ln1116_44_fu_44073_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1044_fu_63561_p1() {
    mul_ln1118_1044_fu_63561_p1 = tmp_1044_reg_109851.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1044_fu_63561_p2() {
    mul_ln1118_1044_fu_63561_p2 = (!mul_ln1118_1044_fu_63561_p0.read().is_01() || !mul_ln1118_1044_fu_63561_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1044_fu_63561_p0.read()) * sc_bigint<5>(mul_ln1118_1044_fu_63561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1045_fu_63582_p0() {
    mul_ln1118_1045_fu_63582_p0 =  (sc_lv<3>) (sext_ln1116_45_fu_44097_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1045_fu_63582_p1() {
    mul_ln1118_1045_fu_63582_p1 = tmp_1045_reg_109856.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1045_fu_63582_p2() {
    mul_ln1118_1045_fu_63582_p2 = (!mul_ln1118_1045_fu_63582_p0.read().is_01() || !mul_ln1118_1045_fu_63582_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1045_fu_63582_p0.read()) * sc_bigint<5>(mul_ln1118_1045_fu_63582_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1046_fu_63603_p0() {
    mul_ln1118_1046_fu_63603_p0 =  (sc_lv<3>) (sext_ln1116_46_fu_44121_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1046_fu_63603_p1() {
    mul_ln1118_1046_fu_63603_p1 = tmp_1046_reg_109861.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1046_fu_63603_p2() {
    mul_ln1118_1046_fu_63603_p2 = (!mul_ln1118_1046_fu_63603_p0.read().is_01() || !mul_ln1118_1046_fu_63603_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1046_fu_63603_p0.read()) * sc_bigint<5>(mul_ln1118_1046_fu_63603_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1047_fu_63612_p0() {
    mul_ln1118_1047_fu_63612_p0 =  (sc_lv<3>) (sext_ln1116_47_fu_44133_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1047_fu_63612_p1() {
    mul_ln1118_1047_fu_63612_p1 = tmp_1047_reg_109866.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1047_fu_63612_p2() {
    mul_ln1118_1047_fu_63612_p2 = (!mul_ln1118_1047_fu_63612_p0.read().is_01() || !mul_ln1118_1047_fu_63612_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1047_fu_63612_p0.read()) * sc_bigint<5>(mul_ln1118_1047_fu_63612_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1048_fu_63633_p0() {
    mul_ln1118_1048_fu_63633_p0 =  (sc_lv<3>) (sext_ln1116_48_fu_44157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1048_fu_63633_p1() {
    mul_ln1118_1048_fu_63633_p1 = tmp_1048_reg_109871.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1048_fu_63633_p2() {
    mul_ln1118_1048_fu_63633_p2 = (!mul_ln1118_1048_fu_63633_p0.read().is_01() || !mul_ln1118_1048_fu_63633_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1048_fu_63633_p0.read()) * sc_bigint<5>(mul_ln1118_1048_fu_63633_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1049_fu_63654_p0() {
    mul_ln1118_1049_fu_63654_p0 =  (sc_lv<3>) (sext_ln1116_49_fu_44181_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1049_fu_63654_p1() {
    mul_ln1118_1049_fu_63654_p1 = tmp_1049_reg_109876.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1049_fu_63654_p2() {
    mul_ln1118_1049_fu_63654_p2 = (!mul_ln1118_1049_fu_63654_p0.read().is_01() || !mul_ln1118_1049_fu_63654_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1049_fu_63654_p0.read()) * sc_bigint<5>(mul_ln1118_1049_fu_63654_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_104_fu_45270_p0() {
    mul_ln1118_104_fu_45270_p0 =  (sc_lv<3>) (sext_ln1116_104_fu_45264_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_104_fu_45270_p1() {
    mul_ln1118_104_fu_45270_p1 = tmp_104_reg_104630.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_104_fu_45270_p2() {
    mul_ln1118_104_fu_45270_p2 = (!mul_ln1118_104_fu_45270_p0.read().is_01() || !mul_ln1118_104_fu_45270_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_104_fu_45270_p0.read()) * sc_bigint<5>(mul_ln1118_104_fu_45270_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1050_fu_63663_p0() {
    mul_ln1118_1050_fu_63663_p0 =  (sc_lv<3>) (sext_ln1116_50_fu_44193_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1050_fu_63663_p1() {
    mul_ln1118_1050_fu_63663_p1 = tmp_1050_reg_109881.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1050_fu_63663_p2() {
    mul_ln1118_1050_fu_63663_p2 = (!mul_ln1118_1050_fu_63663_p0.read().is_01() || !mul_ln1118_1050_fu_63663_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1050_fu_63663_p0.read()) * sc_bigint<5>(mul_ln1118_1050_fu_63663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1051_fu_63684_p0() {
    mul_ln1118_1051_fu_63684_p0 =  (sc_lv<3>) (sext_ln1116_51_fu_44217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1051_fu_63684_p1() {
    mul_ln1118_1051_fu_63684_p1 = tmp_1051_reg_109886.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1051_fu_63684_p2() {
    mul_ln1118_1051_fu_63684_p2 = (!mul_ln1118_1051_fu_63684_p0.read().is_01() || !mul_ln1118_1051_fu_63684_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1051_fu_63684_p0.read()) * sc_bigint<5>(mul_ln1118_1051_fu_63684_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1052_fu_90688_p0() {
    mul_ln1118_1052_fu_90688_p0 =  (sc_lv<3>) (sext_ln1116_52_reg_114732.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1052_fu_90688_p1() {
    mul_ln1118_1052_fu_90688_p1 = tmp_1052_reg_109891_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1052_fu_90688_p2() {
    mul_ln1118_1052_fu_90688_p2 = (!mul_ln1118_1052_fu_90688_p0.read().is_01() || !mul_ln1118_1052_fu_90688_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1052_fu_90688_p0.read()) * sc_bigint<5>(mul_ln1118_1052_fu_90688_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1053_fu_63705_p0() {
    mul_ln1118_1053_fu_63705_p0 =  (sc_lv<3>) (sext_ln1116_53_fu_44244_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1053_fu_63705_p1() {
    mul_ln1118_1053_fu_63705_p1 = tmp_1053_reg_109896.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1053_fu_63705_p2() {
    mul_ln1118_1053_fu_63705_p2 = (!mul_ln1118_1053_fu_63705_p0.read().is_01() || !mul_ln1118_1053_fu_63705_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1053_fu_63705_p0.read()) * sc_bigint<5>(mul_ln1118_1053_fu_63705_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1054_fu_63726_p0() {
    mul_ln1118_1054_fu_63726_p0 =  (sc_lv<3>) (sext_ln1116_54_fu_44268_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1054_fu_63726_p1() {
    mul_ln1118_1054_fu_63726_p1 = tmp_1054_reg_109901.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1054_fu_63726_p2() {
    mul_ln1118_1054_fu_63726_p2 = (!mul_ln1118_1054_fu_63726_p0.read().is_01() || !mul_ln1118_1054_fu_63726_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1054_fu_63726_p0.read()) * sc_bigint<5>(mul_ln1118_1054_fu_63726_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1055_fu_63747_p0() {
    mul_ln1118_1055_fu_63747_p0 =  (sc_lv<3>) (sext_ln1116_55_fu_44292_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1055_fu_63747_p1() {
    mul_ln1118_1055_fu_63747_p1 = tmp_1055_reg_109906.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1055_fu_63747_p2() {
    mul_ln1118_1055_fu_63747_p2 = (!mul_ln1118_1055_fu_63747_p0.read().is_01() || !mul_ln1118_1055_fu_63747_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1055_fu_63747_p0.read()) * sc_bigint<5>(mul_ln1118_1055_fu_63747_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1056_fu_63768_p0() {
    mul_ln1118_1056_fu_63768_p0 =  (sc_lv<3>) (sext_ln1116_56_fu_44316_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1056_fu_63768_p1() {
    mul_ln1118_1056_fu_63768_p1 = tmp_1056_reg_109911.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1056_fu_63768_p2() {
    mul_ln1118_1056_fu_63768_p2 = (!mul_ln1118_1056_fu_63768_p0.read().is_01() || !mul_ln1118_1056_fu_63768_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1056_fu_63768_p0.read()) * sc_bigint<5>(mul_ln1118_1056_fu_63768_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1057_fu_63789_p0() {
    mul_ln1118_1057_fu_63789_p0 =  (sc_lv<3>) (sext_ln1116_57_fu_44340_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1057_fu_63789_p1() {
    mul_ln1118_1057_fu_63789_p1 = tmp_1057_reg_109916.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1057_fu_63789_p2() {
    mul_ln1118_1057_fu_63789_p2 = (!mul_ln1118_1057_fu_63789_p0.read().is_01() || !mul_ln1118_1057_fu_63789_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1057_fu_63789_p0.read()) * sc_bigint<5>(mul_ln1118_1057_fu_63789_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1058_fu_63810_p0() {
    mul_ln1118_1058_fu_63810_p0 =  (sc_lv<3>) (sext_ln1116_58_fu_44364_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1058_fu_63810_p1() {
    mul_ln1118_1058_fu_63810_p1 = tmp_1058_reg_109921.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1058_fu_63810_p2() {
    mul_ln1118_1058_fu_63810_p2 = (!mul_ln1118_1058_fu_63810_p0.read().is_01() || !mul_ln1118_1058_fu_63810_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1058_fu_63810_p0.read()) * sc_bigint<5>(mul_ln1118_1058_fu_63810_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1059_fu_63831_p0() {
    mul_ln1118_1059_fu_63831_p0 =  (sc_lv<3>) (sext_ln1116_59_fu_44388_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1059_fu_63831_p1() {
    mul_ln1118_1059_fu_63831_p1 = tmp_1059_reg_109926.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1059_fu_63831_p2() {
    mul_ln1118_1059_fu_63831_p2 = (!mul_ln1118_1059_fu_63831_p0.read().is_01() || !mul_ln1118_1059_fu_63831_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1059_fu_63831_p0.read()) * sc_bigint<5>(mul_ln1118_1059_fu_63831_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_105_fu_45294_p0() {
    mul_ln1118_105_fu_45294_p0 =  (sc_lv<3>) (sext_ln1116_105_fu_45288_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_105_fu_45294_p1() {
    mul_ln1118_105_fu_45294_p1 = tmp_105_reg_104640.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_105_fu_45294_p2() {
    mul_ln1118_105_fu_45294_p2 = (!mul_ln1118_105_fu_45294_p0.read().is_01() || !mul_ln1118_105_fu_45294_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_105_fu_45294_p0.read()) * sc_bigint<5>(mul_ln1118_105_fu_45294_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1060_fu_63840_p0() {
    mul_ln1118_1060_fu_63840_p0 =  (sc_lv<3>) (sext_ln1116_60_fu_44400_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1060_fu_63840_p1() {
    mul_ln1118_1060_fu_63840_p1 = tmp_1060_reg_109931.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1060_fu_63840_p2() {
    mul_ln1118_1060_fu_63840_p2 = (!mul_ln1118_1060_fu_63840_p0.read().is_01() || !mul_ln1118_1060_fu_63840_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1060_fu_63840_p0.read()) * sc_bigint<5>(mul_ln1118_1060_fu_63840_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1061_fu_63861_p0() {
    mul_ln1118_1061_fu_63861_p0 =  (sc_lv<3>) (sext_ln1116_61_fu_44424_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1061_fu_63861_p1() {
    mul_ln1118_1061_fu_63861_p1 = tmp_1061_reg_109936.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1061_fu_63861_p2() {
    mul_ln1118_1061_fu_63861_p2 = (!mul_ln1118_1061_fu_63861_p0.read().is_01() || !mul_ln1118_1061_fu_63861_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1061_fu_63861_p0.read()) * sc_bigint<5>(mul_ln1118_1061_fu_63861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1062_fu_63882_p0() {
    mul_ln1118_1062_fu_63882_p0 =  (sc_lv<3>) (sext_ln1116_62_fu_44448_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1062_fu_63882_p1() {
    mul_ln1118_1062_fu_63882_p1 = tmp_1062_reg_109941.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1062_fu_63882_p2() {
    mul_ln1118_1062_fu_63882_p2 = (!mul_ln1118_1062_fu_63882_p0.read().is_01() || !mul_ln1118_1062_fu_63882_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1062_fu_63882_p0.read()) * sc_bigint<5>(mul_ln1118_1062_fu_63882_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1063_fu_63891_p0() {
    mul_ln1118_1063_fu_63891_p0 =  (sc_lv<3>) (sext_ln1116_63_fu_44460_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1063_fu_63891_p1() {
    mul_ln1118_1063_fu_63891_p1 = tmp_1063_reg_109946.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1063_fu_63891_p2() {
    mul_ln1118_1063_fu_63891_p2 = (!mul_ln1118_1063_fu_63891_p0.read().is_01() || !mul_ln1118_1063_fu_63891_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1063_fu_63891_p0.read()) * sc_bigint<5>(mul_ln1118_1063_fu_63891_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1064_fu_63912_p0() {
    mul_ln1118_1064_fu_63912_p0 =  (sc_lv<3>) (sext_ln1116_64_fu_44484_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1064_fu_63912_p1() {
    mul_ln1118_1064_fu_63912_p1 = tmp_1064_reg_109951.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1064_fu_63912_p2() {
    mul_ln1118_1064_fu_63912_p2 = (!mul_ln1118_1064_fu_63912_p0.read().is_01() || !mul_ln1118_1064_fu_63912_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1064_fu_63912_p0.read()) * sc_bigint<5>(mul_ln1118_1064_fu_63912_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1065_fu_90730_p0() {
    mul_ln1118_1065_fu_90730_p0 =  (sc_lv<3>) (sext_ln1116_65_reg_114755.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1065_fu_90730_p1() {
    mul_ln1118_1065_fu_90730_p1 = tmp_1065_reg_109956_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1065_fu_90730_p2() {
    mul_ln1118_1065_fu_90730_p2 = (!mul_ln1118_1065_fu_90730_p0.read().is_01() || !mul_ln1118_1065_fu_90730_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1065_fu_90730_p0.read()) * sc_bigint<5>(mul_ln1118_1065_fu_90730_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1066_fu_63933_p0() {
    mul_ln1118_1066_fu_63933_p0 =  (sc_lv<3>) (sext_ln1116_66_fu_44511_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1066_fu_63933_p1() {
    mul_ln1118_1066_fu_63933_p1 = tmp_1066_reg_109961.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1066_fu_63933_p2() {
    mul_ln1118_1066_fu_63933_p2 = (!mul_ln1118_1066_fu_63933_p0.read().is_01() || !mul_ln1118_1066_fu_63933_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1066_fu_63933_p0.read()) * sc_bigint<5>(mul_ln1118_1066_fu_63933_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1067_fu_63954_p0() {
    mul_ln1118_1067_fu_63954_p0 =  (sc_lv<3>) (sext_ln1116_67_fu_44535_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1067_fu_63954_p1() {
    mul_ln1118_1067_fu_63954_p1 = tmp_1067_reg_109966.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1067_fu_63954_p2() {
    mul_ln1118_1067_fu_63954_p2 = (!mul_ln1118_1067_fu_63954_p0.read().is_01() || !mul_ln1118_1067_fu_63954_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1067_fu_63954_p0.read()) * sc_bigint<5>(mul_ln1118_1067_fu_63954_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1068_fu_90750_p0() {
    mul_ln1118_1068_fu_90750_p0 =  (sc_lv<3>) (sext_ln1116_68_reg_114768.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1068_fu_90750_p1() {
    mul_ln1118_1068_fu_90750_p1 = tmp_1068_reg_109971_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1068_fu_90750_p2() {
    mul_ln1118_1068_fu_90750_p2 = (!mul_ln1118_1068_fu_90750_p0.read().is_01() || !mul_ln1118_1068_fu_90750_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1068_fu_90750_p0.read()) * sc_bigint<5>(mul_ln1118_1068_fu_90750_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1069_fu_63975_p0() {
    mul_ln1118_1069_fu_63975_p0 =  (sc_lv<3>) (sext_ln1116_69_fu_44562_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1069_fu_63975_p1() {
    mul_ln1118_1069_fu_63975_p1 = tmp_1069_reg_109976.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1069_fu_63975_p2() {
    mul_ln1118_1069_fu_63975_p2 = (!mul_ln1118_1069_fu_63975_p0.read().is_01() || !mul_ln1118_1069_fu_63975_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1069_fu_63975_p0.read()) * sc_bigint<5>(mul_ln1118_1069_fu_63975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_106_fu_45318_p0() {
    mul_ln1118_106_fu_45318_p0 =  (sc_lv<3>) (sext_ln1116_106_fu_45312_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_106_fu_45318_p1() {
    mul_ln1118_106_fu_45318_p1 = tmp_106_reg_104650.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_106_fu_45318_p2() {
    mul_ln1118_106_fu_45318_p2 = (!mul_ln1118_106_fu_45318_p0.read().is_01() || !mul_ln1118_106_fu_45318_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_106_fu_45318_p0.read()) * sc_bigint<5>(mul_ln1118_106_fu_45318_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1070_fu_63996_p0() {
    mul_ln1118_1070_fu_63996_p0 =  (sc_lv<3>) (sext_ln1116_70_fu_44586_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1070_fu_63996_p1() {
    mul_ln1118_1070_fu_63996_p1 = tmp_1070_reg_109981.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1070_fu_63996_p2() {
    mul_ln1118_1070_fu_63996_p2 = (!mul_ln1118_1070_fu_63996_p0.read().is_01() || !mul_ln1118_1070_fu_63996_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1070_fu_63996_p0.read()) * sc_bigint<5>(mul_ln1118_1070_fu_63996_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1071_fu_64017_p0() {
    mul_ln1118_1071_fu_64017_p0 =  (sc_lv<3>) (sext_ln1116_71_fu_44610_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1071_fu_64017_p1() {
    mul_ln1118_1071_fu_64017_p1 = tmp_1071_reg_109986.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1071_fu_64017_p2() {
    mul_ln1118_1071_fu_64017_p2 = (!mul_ln1118_1071_fu_64017_p0.read().is_01() || !mul_ln1118_1071_fu_64017_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1071_fu_64017_p0.read()) * sc_bigint<5>(mul_ln1118_1071_fu_64017_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1072_fu_64026_p0() {
    mul_ln1118_1072_fu_64026_p0 =  (sc_lv<3>) (sext_ln1116_72_fu_44622_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1072_fu_64026_p1() {
    mul_ln1118_1072_fu_64026_p1 = tmp_1072_reg_109991.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1072_fu_64026_p2() {
    mul_ln1118_1072_fu_64026_p2 = (!mul_ln1118_1072_fu_64026_p0.read().is_01() || !mul_ln1118_1072_fu_64026_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1072_fu_64026_p0.read()) * sc_bigint<5>(mul_ln1118_1072_fu_64026_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1073_fu_64047_p0() {
    mul_ln1118_1073_fu_64047_p0 =  (sc_lv<3>) (sext_ln1116_73_fu_44646_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1073_fu_64047_p1() {
    mul_ln1118_1073_fu_64047_p1 = tmp_1073_reg_109996.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1073_fu_64047_p2() {
    mul_ln1118_1073_fu_64047_p2 = (!mul_ln1118_1073_fu_64047_p0.read().is_01() || !mul_ln1118_1073_fu_64047_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1073_fu_64047_p0.read()) * sc_bigint<5>(mul_ln1118_1073_fu_64047_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1074_fu_64068_p0() {
    mul_ln1118_1074_fu_64068_p0 =  (sc_lv<3>) (sext_ln1116_74_fu_44670_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1074_fu_64068_p1() {
    mul_ln1118_1074_fu_64068_p1 = tmp_1074_reg_110001.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1074_fu_64068_p2() {
    mul_ln1118_1074_fu_64068_p2 = (!mul_ln1118_1074_fu_64068_p0.read().is_01() || !mul_ln1118_1074_fu_64068_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1074_fu_64068_p0.read()) * sc_bigint<5>(mul_ln1118_1074_fu_64068_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1075_fu_64077_p0() {
    mul_ln1118_1075_fu_64077_p0 =  (sc_lv<3>) (sext_ln1116_75_fu_44682_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1075_fu_64077_p1() {
    mul_ln1118_1075_fu_64077_p1 = tmp_1075_reg_110006.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1075_fu_64077_p2() {
    mul_ln1118_1075_fu_64077_p2 = (!mul_ln1118_1075_fu_64077_p0.read().is_01() || !mul_ln1118_1075_fu_64077_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1075_fu_64077_p0.read()) * sc_bigint<5>(mul_ln1118_1075_fu_64077_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1076_fu_64098_p0() {
    mul_ln1118_1076_fu_64098_p0 =  (sc_lv<3>) (sext_ln1116_76_fu_44706_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1076_fu_64098_p1() {
    mul_ln1118_1076_fu_64098_p1 = tmp_1076_reg_110011.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1076_fu_64098_p2() {
    mul_ln1118_1076_fu_64098_p2 = (!mul_ln1118_1076_fu_64098_p0.read().is_01() || !mul_ln1118_1076_fu_64098_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1076_fu_64098_p0.read()) * sc_bigint<5>(mul_ln1118_1076_fu_64098_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1077_fu_64119_p0() {
    mul_ln1118_1077_fu_64119_p0 =  (sc_lv<3>) (sext_ln1116_77_fu_44730_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1077_fu_64119_p1() {
    mul_ln1118_1077_fu_64119_p1 = tmp_1077_reg_110016.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1077_fu_64119_p2() {
    mul_ln1118_1077_fu_64119_p2 = (!mul_ln1118_1077_fu_64119_p0.read().is_01() || !mul_ln1118_1077_fu_64119_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1077_fu_64119_p0.read()) * sc_bigint<5>(mul_ln1118_1077_fu_64119_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1078_fu_64128_p0() {
    mul_ln1118_1078_fu_64128_p0 =  (sc_lv<3>) (sext_ln1116_78_fu_44742_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1078_fu_64128_p1() {
    mul_ln1118_1078_fu_64128_p1 = tmp_1078_reg_110021.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1078_fu_64128_p2() {
    mul_ln1118_1078_fu_64128_p2 = (!mul_ln1118_1078_fu_64128_p0.read().is_01() || !mul_ln1118_1078_fu_64128_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1078_fu_64128_p0.read()) * sc_bigint<5>(mul_ln1118_1078_fu_64128_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1079_fu_64149_p0() {
    mul_ln1118_1079_fu_64149_p0 =  (sc_lv<3>) (sext_ln1116_79_fu_44766_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1079_fu_64149_p1() {
    mul_ln1118_1079_fu_64149_p1 = tmp_1079_reg_110026.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1079_fu_64149_p2() {
    mul_ln1118_1079_fu_64149_p2 = (!mul_ln1118_1079_fu_64149_p0.read().is_01() || !mul_ln1118_1079_fu_64149_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1079_fu_64149_p0.read()) * sc_bigint<5>(mul_ln1118_1079_fu_64149_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_107_fu_45342_p0() {
    mul_ln1118_107_fu_45342_p0 =  (sc_lv<3>) (sext_ln1116_107_fu_45336_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_107_fu_45342_p1() {
    mul_ln1118_107_fu_45342_p1 = tmp_107_reg_104660.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_107_fu_45342_p2() {
    mul_ln1118_107_fu_45342_p2 = (!mul_ln1118_107_fu_45342_p0.read().is_01() || !mul_ln1118_107_fu_45342_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_107_fu_45342_p0.read()) * sc_bigint<5>(mul_ln1118_107_fu_45342_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1080_fu_64170_p0() {
    mul_ln1118_1080_fu_64170_p0 =  (sc_lv<3>) (sext_ln1116_80_fu_44790_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1080_fu_64170_p1() {
    mul_ln1118_1080_fu_64170_p1 = tmp_1080_reg_110031.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1080_fu_64170_p2() {
    mul_ln1118_1080_fu_64170_p2 = (!mul_ln1118_1080_fu_64170_p0.read().is_01() || !mul_ln1118_1080_fu_64170_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1080_fu_64170_p0.read()) * sc_bigint<5>(mul_ln1118_1080_fu_64170_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1081_fu_64191_p0() {
    mul_ln1118_1081_fu_64191_p0 =  (sc_lv<3>) (sext_ln1116_81_fu_44814_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1081_fu_64191_p1() {
    mul_ln1118_1081_fu_64191_p1 = tmp_1081_reg_110036.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1081_fu_64191_p2() {
    mul_ln1118_1081_fu_64191_p2 = (!mul_ln1118_1081_fu_64191_p0.read().is_01() || !mul_ln1118_1081_fu_64191_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1081_fu_64191_p0.read()) * sc_bigint<5>(mul_ln1118_1081_fu_64191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1082_fu_64212_p0() {
    mul_ln1118_1082_fu_64212_p0 =  (sc_lv<3>) (sext_ln1116_82_fu_44838_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1082_fu_64212_p1() {
    mul_ln1118_1082_fu_64212_p1 = tmp_1082_reg_110041.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1082_fu_64212_p2() {
    mul_ln1118_1082_fu_64212_p2 = (!mul_ln1118_1082_fu_64212_p0.read().is_01() || !mul_ln1118_1082_fu_64212_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1082_fu_64212_p0.read()) * sc_bigint<5>(mul_ln1118_1082_fu_64212_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1083_fu_64233_p0() {
    mul_ln1118_1083_fu_64233_p0 =  (sc_lv<3>) (sext_ln1116_83_fu_44862_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1083_fu_64233_p1() {
    mul_ln1118_1083_fu_64233_p1 = tmp_1083_reg_110046.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1083_fu_64233_p2() {
    mul_ln1118_1083_fu_64233_p2 = (!mul_ln1118_1083_fu_64233_p0.read().is_01() || !mul_ln1118_1083_fu_64233_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1083_fu_64233_p0.read()) * sc_bigint<5>(mul_ln1118_1083_fu_64233_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1084_fu_64254_p0() {
    mul_ln1118_1084_fu_64254_p0 =  (sc_lv<3>) (sext_ln1116_84_fu_44886_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1084_fu_64254_p1() {
    mul_ln1118_1084_fu_64254_p1 = tmp_1084_reg_110051.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1084_fu_64254_p2() {
    mul_ln1118_1084_fu_64254_p2 = (!mul_ln1118_1084_fu_64254_p0.read().is_01() || !mul_ln1118_1084_fu_64254_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1084_fu_64254_p0.read()) * sc_bigint<5>(mul_ln1118_1084_fu_64254_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1085_fu_64263_p0() {
    mul_ln1118_1085_fu_64263_p0 =  (sc_lv<3>) (sext_ln1116_85_fu_44898_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1085_fu_64263_p1() {
    mul_ln1118_1085_fu_64263_p1 = tmp_1085_reg_110056.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1085_fu_64263_p2() {
    mul_ln1118_1085_fu_64263_p2 = (!mul_ln1118_1085_fu_64263_p0.read().is_01() || !mul_ln1118_1085_fu_64263_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1085_fu_64263_p0.read()) * sc_bigint<5>(mul_ln1118_1085_fu_64263_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1086_fu_64284_p0() {
    mul_ln1118_1086_fu_64284_p0 =  (sc_lv<3>) (sext_ln1116_86_fu_44922_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1086_fu_64284_p1() {
    mul_ln1118_1086_fu_64284_p1 = tmp_1086_reg_110061.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1086_fu_64284_p2() {
    mul_ln1118_1086_fu_64284_p2 = (!mul_ln1118_1086_fu_64284_p0.read().is_01() || !mul_ln1118_1086_fu_64284_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1086_fu_64284_p0.read()) * sc_bigint<5>(mul_ln1118_1086_fu_64284_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1087_fu_64305_p0() {
    mul_ln1118_1087_fu_64305_p0 =  (sc_lv<3>) (sext_ln1116_87_fu_44946_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1087_fu_64305_p1() {
    mul_ln1118_1087_fu_64305_p1 = tmp_1087_reg_110066.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1087_fu_64305_p2() {
    mul_ln1118_1087_fu_64305_p2 = (!mul_ln1118_1087_fu_64305_p0.read().is_01() || !mul_ln1118_1087_fu_64305_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1087_fu_64305_p0.read()) * sc_bigint<5>(mul_ln1118_1087_fu_64305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1088_fu_64314_p0() {
    mul_ln1118_1088_fu_64314_p0 =  (sc_lv<3>) (sext_ln1116_88_fu_44958_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1088_fu_64314_p1() {
    mul_ln1118_1088_fu_64314_p1 = tmp_1088_reg_110071.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1088_fu_64314_p2() {
    mul_ln1118_1088_fu_64314_p2 = (!mul_ln1118_1088_fu_64314_p0.read().is_01() || !mul_ln1118_1088_fu_64314_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1088_fu_64314_p0.read()) * sc_bigint<5>(mul_ln1118_1088_fu_64314_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1089_fu_64335_p0() {
    mul_ln1118_1089_fu_64335_p0 =  (sc_lv<3>) (sext_ln1116_89_fu_44982_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1089_fu_64335_p1() {
    mul_ln1118_1089_fu_64335_p1 = tmp_1089_reg_110076.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1089_fu_64335_p2() {
    mul_ln1118_1089_fu_64335_p2 = (!mul_ln1118_1089_fu_64335_p0.read().is_01() || !mul_ln1118_1089_fu_64335_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1089_fu_64335_p0.read()) * sc_bigint<5>(mul_ln1118_1089_fu_64335_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_108_fu_45366_p0() {
    mul_ln1118_108_fu_45366_p0 =  (sc_lv<3>) (sext_ln1116_108_fu_45360_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_108_fu_45366_p1() {
    mul_ln1118_108_fu_45366_p1 = tmp_108_reg_104670.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_108_fu_45366_p2() {
    mul_ln1118_108_fu_45366_p2 = (!mul_ln1118_108_fu_45366_p0.read().is_01() || !mul_ln1118_108_fu_45366_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_108_fu_45366_p0.read()) * sc_bigint<5>(mul_ln1118_108_fu_45366_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1090_fu_90825_p0() {
    mul_ln1118_1090_fu_90825_p0 =  (sc_lv<3>) (sext_ln1116_90_reg_114806.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1090_fu_90825_p1() {
    mul_ln1118_1090_fu_90825_p1 = tmp_1090_reg_110081_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1090_fu_90825_p2() {
    mul_ln1118_1090_fu_90825_p2 = (!mul_ln1118_1090_fu_90825_p0.read().is_01() || !mul_ln1118_1090_fu_90825_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1090_fu_90825_p0.read()) * sc_bigint<5>(mul_ln1118_1090_fu_90825_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1091_fu_64356_p0() {
    mul_ln1118_1091_fu_64356_p0 =  (sc_lv<3>) (sext_ln1116_91_fu_45009_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1091_fu_64356_p1() {
    mul_ln1118_1091_fu_64356_p1 = tmp_1091_reg_110086.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1091_fu_64356_p2() {
    mul_ln1118_1091_fu_64356_p2 = (!mul_ln1118_1091_fu_64356_p0.read().is_01() || !mul_ln1118_1091_fu_64356_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1091_fu_64356_p0.read()) * sc_bigint<5>(mul_ln1118_1091_fu_64356_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1092_fu_64377_p0() {
    mul_ln1118_1092_fu_64377_p0 =  (sc_lv<3>) (sext_ln1116_92_fu_45033_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1092_fu_64377_p1() {
    mul_ln1118_1092_fu_64377_p1 = tmp_1092_reg_110091.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1092_fu_64377_p2() {
    mul_ln1118_1092_fu_64377_p2 = (!mul_ln1118_1092_fu_64377_p0.read().is_01() || !mul_ln1118_1092_fu_64377_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1092_fu_64377_p0.read()) * sc_bigint<5>(mul_ln1118_1092_fu_64377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1093_fu_90845_p0() {
    mul_ln1118_1093_fu_90845_p0 =  (sc_lv<3>) (sext_ln1116_93_reg_114819.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1093_fu_90845_p1() {
    mul_ln1118_1093_fu_90845_p1 = tmp_1093_reg_110096_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1093_fu_90845_p2() {
    mul_ln1118_1093_fu_90845_p2 = (!mul_ln1118_1093_fu_90845_p0.read().is_01() || !mul_ln1118_1093_fu_90845_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1093_fu_90845_p0.read()) * sc_bigint<5>(mul_ln1118_1093_fu_90845_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1094_fu_64398_p0() {
    mul_ln1118_1094_fu_64398_p0 =  (sc_lv<3>) (sext_ln1116_94_fu_45060_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1094_fu_64398_p1() {
    mul_ln1118_1094_fu_64398_p1 = tmp_1094_reg_110101.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1094_fu_64398_p2() {
    mul_ln1118_1094_fu_64398_p2 = (!mul_ln1118_1094_fu_64398_p0.read().is_01() || !mul_ln1118_1094_fu_64398_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1094_fu_64398_p0.read()) * sc_bigint<5>(mul_ln1118_1094_fu_64398_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1095_fu_64419_p0() {
    mul_ln1118_1095_fu_64419_p0 =  (sc_lv<3>) (sext_ln1116_95_fu_45084_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1095_fu_64419_p1() {
    mul_ln1118_1095_fu_64419_p1 = tmp_1095_reg_110106.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1095_fu_64419_p2() {
    mul_ln1118_1095_fu_64419_p2 = (!mul_ln1118_1095_fu_64419_p0.read().is_01() || !mul_ln1118_1095_fu_64419_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1095_fu_64419_p0.read()) * sc_bigint<5>(mul_ln1118_1095_fu_64419_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1096_fu_64440_p0() {
    mul_ln1118_1096_fu_64440_p0 =  (sc_lv<3>) (sext_ln1116_96_fu_45108_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1096_fu_64440_p1() {
    mul_ln1118_1096_fu_64440_p1 = tmp_1096_reg_110111.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1096_fu_64440_p2() {
    mul_ln1118_1096_fu_64440_p2 = (!mul_ln1118_1096_fu_64440_p0.read().is_01() || !mul_ln1118_1096_fu_64440_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1096_fu_64440_p0.read()) * sc_bigint<5>(mul_ln1118_1096_fu_64440_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1097_fu_64449_p0() {
    mul_ln1118_1097_fu_64449_p0 =  (sc_lv<3>) (sext_ln1116_97_fu_45120_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1097_fu_64449_p1() {
    mul_ln1118_1097_fu_64449_p1 = tmp_1097_reg_110116.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1097_fu_64449_p2() {
    mul_ln1118_1097_fu_64449_p2 = (!mul_ln1118_1097_fu_64449_p0.read().is_01() || !mul_ln1118_1097_fu_64449_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1097_fu_64449_p0.read()) * sc_bigint<5>(mul_ln1118_1097_fu_64449_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1098_fu_64470_p0() {
    mul_ln1118_1098_fu_64470_p0 =  (sc_lv<3>) (sext_ln1116_98_fu_45144_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1098_fu_64470_p1() {
    mul_ln1118_1098_fu_64470_p1 = tmp_1098_reg_110121.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1098_fu_64470_p2() {
    mul_ln1118_1098_fu_64470_p2 = (!mul_ln1118_1098_fu_64470_p0.read().is_01() || !mul_ln1118_1098_fu_64470_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1098_fu_64470_p0.read()) * sc_bigint<5>(mul_ln1118_1098_fu_64470_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1099_fu_64491_p0() {
    mul_ln1118_1099_fu_64491_p0 =  (sc_lv<3>) (sext_ln1116_99_fu_45168_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1099_fu_64491_p1() {
    mul_ln1118_1099_fu_64491_p1 = tmp_1099_reg_110126.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1099_fu_64491_p2() {
    mul_ln1118_1099_fu_64491_p2 = (!mul_ln1118_1099_fu_64491_p0.read().is_01() || !mul_ln1118_1099_fu_64491_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1099_fu_64491_p0.read()) * sc_bigint<5>(mul_ln1118_1099_fu_64491_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_109_fu_45390_p0() {
    mul_ln1118_109_fu_45390_p0 =  (sc_lv<3>) (sext_ln1116_109_fu_45384_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_109_fu_45390_p1() {
    mul_ln1118_109_fu_45390_p1 = tmp_109_reg_104680.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_109_fu_45390_p2() {
    mul_ln1118_109_fu_45390_p2 = (!mul_ln1118_109_fu_45390_p0.read().is_01() || !mul_ln1118_109_fu_45390_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_109_fu_45390_p0.read()) * sc_bigint<5>(mul_ln1118_109_fu_45390_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_10_fu_43425_p0() {
    mul_ln1118_10_fu_43425_p0 =  (sc_lv<3>) (sext_ln1116_10_fu_43419_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_10_fu_43425_p1() {
    mul_ln1118_10_fu_43425_p1 = tmp_11_reg_103690.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_10_fu_43425_p2() {
    mul_ln1118_10_fu_43425_p2 = (!mul_ln1118_10_fu_43425_p0.read().is_01() || !mul_ln1118_10_fu_43425_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_10_fu_43425_p0.read()) * sc_bigint<5>(mul_ln1118_10_fu_43425_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1100_fu_64500_p0() {
    mul_ln1118_1100_fu_64500_p0 =  (sc_lv<3>) (sext_ln1116_100_fu_45180_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1100_fu_64500_p1() {
    mul_ln1118_1100_fu_64500_p1 = tmp_1100_reg_110131.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1100_fu_64500_p2() {
    mul_ln1118_1100_fu_64500_p2 = (!mul_ln1118_1100_fu_64500_p0.read().is_01() || !mul_ln1118_1100_fu_64500_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1100_fu_64500_p0.read()) * sc_bigint<5>(mul_ln1118_1100_fu_64500_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1101_fu_64521_p0() {
    mul_ln1118_1101_fu_64521_p0 =  (sc_lv<3>) (sext_ln1116_101_fu_45204_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1101_fu_64521_p1() {
    mul_ln1118_1101_fu_64521_p1 = tmp_1101_reg_110136.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1101_fu_64521_p2() {
    mul_ln1118_1101_fu_64521_p2 = (!mul_ln1118_1101_fu_64521_p0.read().is_01() || !mul_ln1118_1101_fu_64521_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1101_fu_64521_p0.read()) * sc_bigint<5>(mul_ln1118_1101_fu_64521_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1102_fu_64542_p0() {
    mul_ln1118_1102_fu_64542_p0 =  (sc_lv<3>) (sext_ln1116_102_fu_45228_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1102_fu_64542_p1() {
    mul_ln1118_1102_fu_64542_p1 = tmp_1102_reg_110141.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1102_fu_64542_p2() {
    mul_ln1118_1102_fu_64542_p2 = (!mul_ln1118_1102_fu_64542_p0.read().is_01() || !mul_ln1118_1102_fu_64542_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1102_fu_64542_p0.read()) * sc_bigint<5>(mul_ln1118_1102_fu_64542_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1103_fu_64551_p0() {
    mul_ln1118_1103_fu_64551_p0 =  (sc_lv<3>) (sext_ln1116_103_fu_45240_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1103_fu_64551_p1() {
    mul_ln1118_1103_fu_64551_p1 = tmp_1103_reg_110146.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1103_fu_64551_p2() {
    mul_ln1118_1103_fu_64551_p2 = (!mul_ln1118_1103_fu_64551_p0.read().is_01() || !mul_ln1118_1103_fu_64551_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1103_fu_64551_p0.read()) * sc_bigint<5>(mul_ln1118_1103_fu_64551_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1104_fu_64572_p0() {
    mul_ln1118_1104_fu_64572_p0 =  (sc_lv<3>) (sext_ln1116_104_fu_45264_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1104_fu_64572_p1() {
    mul_ln1118_1104_fu_64572_p1 = tmp_1104_reg_110151.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1104_fu_64572_p2() {
    mul_ln1118_1104_fu_64572_p2 = (!mul_ln1118_1104_fu_64572_p0.read().is_01() || !mul_ln1118_1104_fu_64572_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1104_fu_64572_p0.read()) * sc_bigint<5>(mul_ln1118_1104_fu_64572_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1105_fu_64593_p0() {
    mul_ln1118_1105_fu_64593_p0 =  (sc_lv<3>) (sext_ln1116_105_fu_45288_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1105_fu_64593_p1() {
    mul_ln1118_1105_fu_64593_p1 = tmp_1105_reg_110156.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1105_fu_64593_p2() {
    mul_ln1118_1105_fu_64593_p2 = (!mul_ln1118_1105_fu_64593_p0.read().is_01() || !mul_ln1118_1105_fu_64593_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1105_fu_64593_p0.read()) * sc_bigint<5>(mul_ln1118_1105_fu_64593_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1106_fu_64614_p0() {
    mul_ln1118_1106_fu_64614_p0 =  (sc_lv<3>) (sext_ln1116_106_fu_45312_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1106_fu_64614_p1() {
    mul_ln1118_1106_fu_64614_p1 = tmp_1106_reg_110161.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1106_fu_64614_p2() {
    mul_ln1118_1106_fu_64614_p2 = (!mul_ln1118_1106_fu_64614_p0.read().is_01() || !mul_ln1118_1106_fu_64614_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1106_fu_64614_p0.read()) * sc_bigint<5>(mul_ln1118_1106_fu_64614_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1107_fu_64635_p0() {
    mul_ln1118_1107_fu_64635_p0 =  (sc_lv<3>) (sext_ln1116_107_fu_45336_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1107_fu_64635_p1() {
    mul_ln1118_1107_fu_64635_p1 = tmp_1107_reg_110166.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1107_fu_64635_p2() {
    mul_ln1118_1107_fu_64635_p2 = (!mul_ln1118_1107_fu_64635_p0.read().is_01() || !mul_ln1118_1107_fu_64635_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1107_fu_64635_p0.read()) * sc_bigint<5>(mul_ln1118_1107_fu_64635_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1108_fu_64656_p0() {
    mul_ln1118_1108_fu_64656_p0 =  (sc_lv<3>) (sext_ln1116_108_fu_45360_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1108_fu_64656_p1() {
    mul_ln1118_1108_fu_64656_p1 = tmp_1108_reg_110171.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1108_fu_64656_p2() {
    mul_ln1118_1108_fu_64656_p2 = (!mul_ln1118_1108_fu_64656_p0.read().is_01() || !mul_ln1118_1108_fu_64656_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1108_fu_64656_p0.read()) * sc_bigint<5>(mul_ln1118_1108_fu_64656_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1109_fu_64677_p0() {
    mul_ln1118_1109_fu_64677_p0 =  (sc_lv<3>) (sext_ln1116_109_fu_45384_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1109_fu_64677_p1() {
    mul_ln1118_1109_fu_64677_p1 = tmp_1109_reg_110176.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1109_fu_64677_p2() {
    mul_ln1118_1109_fu_64677_p2 = (!mul_ln1118_1109_fu_64677_p0.read().is_01() || !mul_ln1118_1109_fu_64677_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1109_fu_64677_p0.read()) * sc_bigint<5>(mul_ln1118_1109_fu_64677_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_110_fu_45402_p0() {
    mul_ln1118_110_fu_45402_p0 =  (sc_lv<3>) (sext_ln1116_110_fu_45396_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_110_fu_45402_p1() {
    mul_ln1118_110_fu_45402_p1 = tmp_110_reg_104690.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_110_fu_45402_p2() {
    mul_ln1118_110_fu_45402_p2 = (!mul_ln1118_110_fu_45402_p0.read().is_01() || !mul_ln1118_110_fu_45402_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_110_fu_45402_p0.read()) * sc_bigint<5>(mul_ln1118_110_fu_45402_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1110_fu_64686_p0() {
    mul_ln1118_1110_fu_64686_p0 =  (sc_lv<3>) (sext_ln1116_110_fu_45396_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1110_fu_64686_p1() {
    mul_ln1118_1110_fu_64686_p1 = tmp_1110_reg_110181.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1110_fu_64686_p2() {
    mul_ln1118_1110_fu_64686_p2 = (!mul_ln1118_1110_fu_64686_p0.read().is_01() || !mul_ln1118_1110_fu_64686_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1110_fu_64686_p0.read()) * sc_bigint<5>(mul_ln1118_1110_fu_64686_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1111_fu_64707_p0() {
    mul_ln1118_1111_fu_64707_p0 =  (sc_lv<3>) (sext_ln1116_111_fu_45420_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1111_fu_64707_p1() {
    mul_ln1118_1111_fu_64707_p1 = tmp_1111_reg_110186.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1111_fu_64707_p2() {
    mul_ln1118_1111_fu_64707_p2 = (!mul_ln1118_1111_fu_64707_p0.read().is_01() || !mul_ln1118_1111_fu_64707_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1111_fu_64707_p0.read()) * sc_bigint<5>(mul_ln1118_1111_fu_64707_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1112_fu_64728_p0() {
    mul_ln1118_1112_fu_64728_p0 =  (sc_lv<3>) (sext_ln1116_112_fu_45444_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1112_fu_64728_p1() {
    mul_ln1118_1112_fu_64728_p1 = tmp_1112_reg_110191.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1112_fu_64728_p2() {
    mul_ln1118_1112_fu_64728_p2 = (!mul_ln1118_1112_fu_64728_p0.read().is_01() || !mul_ln1118_1112_fu_64728_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1112_fu_64728_p0.read()) * sc_bigint<5>(mul_ln1118_1112_fu_64728_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1113_fu_64737_p0() {
    mul_ln1118_1113_fu_64737_p0 =  (sc_lv<3>) (sext_ln1116_113_fu_45456_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1113_fu_64737_p1() {
    mul_ln1118_1113_fu_64737_p1 = tmp_1113_reg_110196.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1113_fu_64737_p2() {
    mul_ln1118_1113_fu_64737_p2 = (!mul_ln1118_1113_fu_64737_p0.read().is_01() || !mul_ln1118_1113_fu_64737_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1113_fu_64737_p0.read()) * sc_bigint<5>(mul_ln1118_1113_fu_64737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1114_fu_64758_p0() {
    mul_ln1118_1114_fu_64758_p0 =  (sc_lv<3>) (sext_ln1116_114_fu_45480_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1114_fu_64758_p1() {
    mul_ln1118_1114_fu_64758_p1 = tmp_1114_reg_110201.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1114_fu_64758_p2() {
    mul_ln1118_1114_fu_64758_p2 = (!mul_ln1118_1114_fu_64758_p0.read().is_01() || !mul_ln1118_1114_fu_64758_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1114_fu_64758_p0.read()) * sc_bigint<5>(mul_ln1118_1114_fu_64758_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1115_fu_90920_p0() {
    mul_ln1118_1115_fu_90920_p0 =  (sc_lv<3>) (sext_ln1116_115_reg_114857.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1115_fu_90920_p1() {
    mul_ln1118_1115_fu_90920_p1 = tmp_1115_reg_110206_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1115_fu_90920_p2() {
    mul_ln1118_1115_fu_90920_p2 = (!mul_ln1118_1115_fu_90920_p0.read().is_01() || !mul_ln1118_1115_fu_90920_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1115_fu_90920_p0.read()) * sc_bigint<5>(mul_ln1118_1115_fu_90920_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1116_fu_64779_p0() {
    mul_ln1118_1116_fu_64779_p0 =  (sc_lv<3>) (sext_ln1116_116_fu_45507_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1116_fu_64779_p1() {
    mul_ln1118_1116_fu_64779_p1 = tmp_1116_reg_110211.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1116_fu_64779_p2() {
    mul_ln1118_1116_fu_64779_p2 = (!mul_ln1118_1116_fu_64779_p0.read().is_01() || !mul_ln1118_1116_fu_64779_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1116_fu_64779_p0.read()) * sc_bigint<5>(mul_ln1118_1116_fu_64779_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1117_fu_64800_p0() {
    mul_ln1118_1117_fu_64800_p0 =  (sc_lv<3>) (sext_ln1116_117_fu_45531_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1117_fu_64800_p1() {
    mul_ln1118_1117_fu_64800_p1 = tmp_1117_reg_110216.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1117_fu_64800_p2() {
    mul_ln1118_1117_fu_64800_p2 = (!mul_ln1118_1117_fu_64800_p0.read().is_01() || !mul_ln1118_1117_fu_64800_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1117_fu_64800_p0.read()) * sc_bigint<5>(mul_ln1118_1117_fu_64800_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1118_fu_90940_p0() {
    mul_ln1118_1118_fu_90940_p0 =  (sc_lv<3>) (sext_ln1116_118_reg_114870.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1118_fu_90940_p1() {
    mul_ln1118_1118_fu_90940_p1 = tmp_1118_reg_110221_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1118_fu_90940_p2() {
    mul_ln1118_1118_fu_90940_p2 = (!mul_ln1118_1118_fu_90940_p0.read().is_01() || !mul_ln1118_1118_fu_90940_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1118_fu_90940_p0.read()) * sc_bigint<5>(mul_ln1118_1118_fu_90940_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1119_fu_64821_p0() {
    mul_ln1118_1119_fu_64821_p0 =  (sc_lv<3>) (sext_ln1116_119_fu_45558_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1119_fu_64821_p1() {
    mul_ln1118_1119_fu_64821_p1 = tmp_1119_reg_110226.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1119_fu_64821_p2() {
    mul_ln1118_1119_fu_64821_p2 = (!mul_ln1118_1119_fu_64821_p0.read().is_01() || !mul_ln1118_1119_fu_64821_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1119_fu_64821_p0.read()) * sc_bigint<5>(mul_ln1118_1119_fu_64821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_111_fu_45426_p0() {
    mul_ln1118_111_fu_45426_p0 =  (sc_lv<3>) (sext_ln1116_111_fu_45420_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_111_fu_45426_p1() {
    mul_ln1118_111_fu_45426_p1 = tmp_111_reg_104700.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_111_fu_45426_p2() {
    mul_ln1118_111_fu_45426_p2 = (!mul_ln1118_111_fu_45426_p0.read().is_01() || !mul_ln1118_111_fu_45426_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_111_fu_45426_p0.read()) * sc_bigint<5>(mul_ln1118_111_fu_45426_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1120_fu_64842_p0() {
    mul_ln1118_1120_fu_64842_p0 =  (sc_lv<3>) (sext_ln1116_120_fu_45582_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1120_fu_64842_p1() {
    mul_ln1118_1120_fu_64842_p1 = tmp_1120_reg_110231.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1120_fu_64842_p2() {
    mul_ln1118_1120_fu_64842_p2 = (!mul_ln1118_1120_fu_64842_p0.read().is_01() || !mul_ln1118_1120_fu_64842_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1120_fu_64842_p0.read()) * sc_bigint<5>(mul_ln1118_1120_fu_64842_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1121_fu_64863_p0() {
    mul_ln1118_1121_fu_64863_p0 =  (sc_lv<3>) (sext_ln1116_121_fu_45606_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1121_fu_64863_p1() {
    mul_ln1118_1121_fu_64863_p1 = tmp_1121_reg_110236.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1121_fu_64863_p2() {
    mul_ln1118_1121_fu_64863_p2 = (!mul_ln1118_1121_fu_64863_p0.read().is_01() || !mul_ln1118_1121_fu_64863_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1121_fu_64863_p0.read()) * sc_bigint<5>(mul_ln1118_1121_fu_64863_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1122_fu_64872_p0() {
    mul_ln1118_1122_fu_64872_p0 =  (sc_lv<3>) (sext_ln1116_122_fu_45618_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1122_fu_64872_p1() {
    mul_ln1118_1122_fu_64872_p1 = tmp_1122_reg_110241.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1122_fu_64872_p2() {
    mul_ln1118_1122_fu_64872_p2 = (!mul_ln1118_1122_fu_64872_p0.read().is_01() || !mul_ln1118_1122_fu_64872_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1122_fu_64872_p0.read()) * sc_bigint<5>(mul_ln1118_1122_fu_64872_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1123_fu_64893_p0() {
    mul_ln1118_1123_fu_64893_p0 =  (sc_lv<3>) (sext_ln1116_123_fu_45642_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1123_fu_64893_p1() {
    mul_ln1118_1123_fu_64893_p1 = tmp_1123_reg_110246.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1123_fu_64893_p2() {
    mul_ln1118_1123_fu_64893_p2 = (!mul_ln1118_1123_fu_64893_p0.read().is_01() || !mul_ln1118_1123_fu_64893_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1123_fu_64893_p0.read()) * sc_bigint<5>(mul_ln1118_1123_fu_64893_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1124_fu_64914_p0() {
    mul_ln1118_1124_fu_64914_p0 =  (sc_lv<3>) (sext_ln1116_124_fu_45666_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1124_fu_64914_p1() {
    mul_ln1118_1124_fu_64914_p1 = tmp_1124_reg_110251.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1124_fu_64914_p2() {
    mul_ln1118_1124_fu_64914_p2 = (!mul_ln1118_1124_fu_64914_p0.read().is_01() || !mul_ln1118_1124_fu_64914_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1124_fu_64914_p0.read()) * sc_bigint<5>(mul_ln1118_1124_fu_64914_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1125_fu_64923_p0() {
    mul_ln1118_1125_fu_64923_p0 =  (sc_lv<3>) (sext_ln1116_125_fu_45678_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1125_fu_64923_p1() {
    mul_ln1118_1125_fu_64923_p1 = tmp_1125_reg_110256.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1125_fu_64923_p2() {
    mul_ln1118_1125_fu_64923_p2 = (!mul_ln1118_1125_fu_64923_p0.read().is_01() || !mul_ln1118_1125_fu_64923_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1125_fu_64923_p0.read()) * sc_bigint<5>(mul_ln1118_1125_fu_64923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1126_fu_64944_p0() {
    mul_ln1118_1126_fu_64944_p0 =  (sc_lv<3>) (sext_ln1116_126_fu_45702_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1126_fu_64944_p1() {
    mul_ln1118_1126_fu_64944_p1 = tmp_1126_reg_110261.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1126_fu_64944_p2() {
    mul_ln1118_1126_fu_64944_p2 = (!mul_ln1118_1126_fu_64944_p0.read().is_01() || !mul_ln1118_1126_fu_64944_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1126_fu_64944_p0.read()) * sc_bigint<5>(mul_ln1118_1126_fu_64944_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1127_fu_64965_p0() {
    mul_ln1118_1127_fu_64965_p0 =  (sc_lv<3>) (sext_ln1116_127_fu_45726_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1127_fu_64965_p1() {
    mul_ln1118_1127_fu_64965_p1 = tmp_1127_reg_110266.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1127_fu_64965_p2() {
    mul_ln1118_1127_fu_64965_p2 = (!mul_ln1118_1127_fu_64965_p0.read().is_01() || !mul_ln1118_1127_fu_64965_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1127_fu_64965_p0.read()) * sc_bigint<5>(mul_ln1118_1127_fu_64965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1128_fu_64974_p0() {
    mul_ln1118_1128_fu_64974_p0 =  (sc_lv<3>) (sext_ln1116_128_fu_45738_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1128_fu_64974_p1() {
    mul_ln1118_1128_fu_64974_p1 = tmp_1128_reg_110271.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1128_fu_64974_p2() {
    mul_ln1118_1128_fu_64974_p2 = (!mul_ln1118_1128_fu_64974_p0.read().is_01() || !mul_ln1118_1128_fu_64974_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1128_fu_64974_p0.read()) * sc_bigint<5>(mul_ln1118_1128_fu_64974_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1129_fu_64995_p0() {
    mul_ln1118_1129_fu_64995_p0 =  (sc_lv<3>) (sext_ln1116_129_fu_45762_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1129_fu_64995_p1() {
    mul_ln1118_1129_fu_64995_p1 = tmp_1129_reg_110276.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1129_fu_64995_p2() {
    mul_ln1118_1129_fu_64995_p2 = (!mul_ln1118_1129_fu_64995_p0.read().is_01() || !mul_ln1118_1129_fu_64995_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1129_fu_64995_p0.read()) * sc_bigint<5>(mul_ln1118_1129_fu_64995_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_112_fu_45450_p0() {
    mul_ln1118_112_fu_45450_p0 =  (sc_lv<3>) (sext_ln1116_112_fu_45444_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_112_fu_45450_p1() {
    mul_ln1118_112_fu_45450_p1 = tmp_112_reg_104710.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_112_fu_45450_p2() {
    mul_ln1118_112_fu_45450_p2 = (!mul_ln1118_112_fu_45450_p0.read().is_01() || !mul_ln1118_112_fu_45450_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_112_fu_45450_p0.read()) * sc_bigint<5>(mul_ln1118_112_fu_45450_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1130_fu_65016_p0() {
    mul_ln1118_1130_fu_65016_p0 =  (sc_lv<3>) (sext_ln1116_130_fu_45786_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1130_fu_65016_p1() {
    mul_ln1118_1130_fu_65016_p1 = tmp_1130_reg_110281.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1130_fu_65016_p2() {
    mul_ln1118_1130_fu_65016_p2 = (!mul_ln1118_1130_fu_65016_p0.read().is_01() || !mul_ln1118_1130_fu_65016_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1130_fu_65016_p0.read()) * sc_bigint<5>(mul_ln1118_1130_fu_65016_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1131_fu_65037_p0() {
    mul_ln1118_1131_fu_65037_p0 =  (sc_lv<3>) (sext_ln1116_131_fu_45810_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1131_fu_65037_p1() {
    mul_ln1118_1131_fu_65037_p1 = tmp_1131_reg_110286.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1131_fu_65037_p2() {
    mul_ln1118_1131_fu_65037_p2 = (!mul_ln1118_1131_fu_65037_p0.read().is_01() || !mul_ln1118_1131_fu_65037_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1131_fu_65037_p0.read()) * sc_bigint<5>(mul_ln1118_1131_fu_65037_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1132_fu_65058_p0() {
    mul_ln1118_1132_fu_65058_p0 =  (sc_lv<3>) (sext_ln1116_132_fu_45834_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1132_fu_65058_p1() {
    mul_ln1118_1132_fu_65058_p1 = tmp_1132_reg_110291.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1132_fu_65058_p2() {
    mul_ln1118_1132_fu_65058_p2 = (!mul_ln1118_1132_fu_65058_p0.read().is_01() || !mul_ln1118_1132_fu_65058_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1132_fu_65058_p0.read()) * sc_bigint<5>(mul_ln1118_1132_fu_65058_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1133_fu_65079_p0() {
    mul_ln1118_1133_fu_65079_p0 =  (sc_lv<3>) (sext_ln1116_133_fu_45858_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1133_fu_65079_p1() {
    mul_ln1118_1133_fu_65079_p1 = tmp_1133_reg_110296.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1133_fu_65079_p2() {
    mul_ln1118_1133_fu_65079_p2 = (!mul_ln1118_1133_fu_65079_p0.read().is_01() || !mul_ln1118_1133_fu_65079_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1133_fu_65079_p0.read()) * sc_bigint<5>(mul_ln1118_1133_fu_65079_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1134_fu_65100_p0() {
    mul_ln1118_1134_fu_65100_p0 =  (sc_lv<3>) (sext_ln1116_134_fu_45882_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1134_fu_65100_p1() {
    mul_ln1118_1134_fu_65100_p1 = tmp_1134_reg_110301.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1134_fu_65100_p2() {
    mul_ln1118_1134_fu_65100_p2 = (!mul_ln1118_1134_fu_65100_p0.read().is_01() || !mul_ln1118_1134_fu_65100_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1134_fu_65100_p0.read()) * sc_bigint<5>(mul_ln1118_1134_fu_65100_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1135_fu_65109_p0() {
    mul_ln1118_1135_fu_65109_p0 =  (sc_lv<3>) (sext_ln1116_135_fu_45894_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1135_fu_65109_p1() {
    mul_ln1118_1135_fu_65109_p1 = tmp_1135_reg_110306.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1135_fu_65109_p2() {
    mul_ln1118_1135_fu_65109_p2 = (!mul_ln1118_1135_fu_65109_p0.read().is_01() || !mul_ln1118_1135_fu_65109_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1135_fu_65109_p0.read()) * sc_bigint<5>(mul_ln1118_1135_fu_65109_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1136_fu_65130_p0() {
    mul_ln1118_1136_fu_65130_p0 =  (sc_lv<3>) (sext_ln1116_136_fu_45918_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1136_fu_65130_p1() {
    mul_ln1118_1136_fu_65130_p1 = tmp_1136_reg_110311.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1136_fu_65130_p2() {
    mul_ln1118_1136_fu_65130_p2 = (!mul_ln1118_1136_fu_65130_p0.read().is_01() || !mul_ln1118_1136_fu_65130_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1136_fu_65130_p0.read()) * sc_bigint<5>(mul_ln1118_1136_fu_65130_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1137_fu_65151_p0() {
    mul_ln1118_1137_fu_65151_p0 =  (sc_lv<3>) (sext_ln1116_137_fu_45942_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1137_fu_65151_p1() {
    mul_ln1118_1137_fu_65151_p1 = tmp_1137_reg_110316.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1137_fu_65151_p2() {
    mul_ln1118_1137_fu_65151_p2 = (!mul_ln1118_1137_fu_65151_p0.read().is_01() || !mul_ln1118_1137_fu_65151_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1137_fu_65151_p0.read()) * sc_bigint<5>(mul_ln1118_1137_fu_65151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1138_fu_65160_p0() {
    mul_ln1118_1138_fu_65160_p0 =  (sc_lv<3>) (sext_ln1116_138_fu_45954_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1138_fu_65160_p1() {
    mul_ln1118_1138_fu_65160_p1 = tmp_1138_reg_110321.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1138_fu_65160_p2() {
    mul_ln1118_1138_fu_65160_p2 = (!mul_ln1118_1138_fu_65160_p0.read().is_01() || !mul_ln1118_1138_fu_65160_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1138_fu_65160_p0.read()) * sc_bigint<5>(mul_ln1118_1138_fu_65160_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1139_fu_65181_p0() {
    mul_ln1118_1139_fu_65181_p0 =  (sc_lv<3>) (sext_ln1116_139_fu_45978_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1139_fu_65181_p1() {
    mul_ln1118_1139_fu_65181_p1 = tmp_1139_reg_110326.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1139_fu_65181_p2() {
    mul_ln1118_1139_fu_65181_p2 = (!mul_ln1118_1139_fu_65181_p0.read().is_01() || !mul_ln1118_1139_fu_65181_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1139_fu_65181_p0.read()) * sc_bigint<5>(mul_ln1118_1139_fu_65181_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_113_fu_45462_p0() {
    mul_ln1118_113_fu_45462_p0 =  (sc_lv<3>) (sext_ln1116_113_fu_45456_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_113_fu_45462_p1() {
    mul_ln1118_113_fu_45462_p1 = tmp_113_reg_104720.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_113_fu_45462_p2() {
    mul_ln1118_113_fu_45462_p2 = (!mul_ln1118_113_fu_45462_p0.read().is_01() || !mul_ln1118_113_fu_45462_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_113_fu_45462_p0.read()) * sc_bigint<5>(mul_ln1118_113_fu_45462_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1140_fu_91015_p0() {
    mul_ln1118_1140_fu_91015_p0 =  (sc_lv<3>) (sext_ln1116_140_reg_114908.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1140_fu_91015_p1() {
    mul_ln1118_1140_fu_91015_p1 = tmp_1140_reg_110331_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1140_fu_91015_p2() {
    mul_ln1118_1140_fu_91015_p2 = (!mul_ln1118_1140_fu_91015_p0.read().is_01() || !mul_ln1118_1140_fu_91015_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1140_fu_91015_p0.read()) * sc_bigint<5>(mul_ln1118_1140_fu_91015_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1141_fu_65202_p0() {
    mul_ln1118_1141_fu_65202_p0 =  (sc_lv<3>) (sext_ln1116_141_fu_46005_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1141_fu_65202_p1() {
    mul_ln1118_1141_fu_65202_p1 = tmp_1141_reg_110336.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1141_fu_65202_p2() {
    mul_ln1118_1141_fu_65202_p2 = (!mul_ln1118_1141_fu_65202_p0.read().is_01() || !mul_ln1118_1141_fu_65202_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1141_fu_65202_p0.read()) * sc_bigint<5>(mul_ln1118_1141_fu_65202_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1142_fu_65223_p0() {
    mul_ln1118_1142_fu_65223_p0 =  (sc_lv<3>) (sext_ln1116_142_fu_46029_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1142_fu_65223_p1() {
    mul_ln1118_1142_fu_65223_p1 = tmp_1142_reg_110341.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1142_fu_65223_p2() {
    mul_ln1118_1142_fu_65223_p2 = (!mul_ln1118_1142_fu_65223_p0.read().is_01() || !mul_ln1118_1142_fu_65223_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1142_fu_65223_p0.read()) * sc_bigint<5>(mul_ln1118_1142_fu_65223_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1143_fu_91035_p0() {
    mul_ln1118_1143_fu_91035_p0 =  (sc_lv<3>) (sext_ln1116_143_reg_114921.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1143_fu_91035_p1() {
    mul_ln1118_1143_fu_91035_p1 = tmp_1143_reg_110346_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1143_fu_91035_p2() {
    mul_ln1118_1143_fu_91035_p2 = (!mul_ln1118_1143_fu_91035_p0.read().is_01() || !mul_ln1118_1143_fu_91035_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1143_fu_91035_p0.read()) * sc_bigint<5>(mul_ln1118_1143_fu_91035_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1144_fu_65244_p0() {
    mul_ln1118_1144_fu_65244_p0 =  (sc_lv<3>) (sext_ln1116_144_fu_46056_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1144_fu_65244_p1() {
    mul_ln1118_1144_fu_65244_p1 = tmp_1144_reg_110351.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1144_fu_65244_p2() {
    mul_ln1118_1144_fu_65244_p2 = (!mul_ln1118_1144_fu_65244_p0.read().is_01() || !mul_ln1118_1144_fu_65244_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1144_fu_65244_p0.read()) * sc_bigint<5>(mul_ln1118_1144_fu_65244_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1145_fu_65265_p0() {
    mul_ln1118_1145_fu_65265_p0 =  (sc_lv<3>) (sext_ln1116_145_fu_46080_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1145_fu_65265_p1() {
    mul_ln1118_1145_fu_65265_p1 = tmp_1145_reg_110356.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1145_fu_65265_p2() {
    mul_ln1118_1145_fu_65265_p2 = (!mul_ln1118_1145_fu_65265_p0.read().is_01() || !mul_ln1118_1145_fu_65265_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1145_fu_65265_p0.read()) * sc_bigint<5>(mul_ln1118_1145_fu_65265_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1146_fu_65286_p0() {
    mul_ln1118_1146_fu_65286_p0 =  (sc_lv<3>) (sext_ln1116_146_fu_46104_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1146_fu_65286_p1() {
    mul_ln1118_1146_fu_65286_p1 = tmp_1146_reg_110361.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1146_fu_65286_p2() {
    mul_ln1118_1146_fu_65286_p2 = (!mul_ln1118_1146_fu_65286_p0.read().is_01() || !mul_ln1118_1146_fu_65286_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1146_fu_65286_p0.read()) * sc_bigint<5>(mul_ln1118_1146_fu_65286_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1147_fu_65295_p0() {
    mul_ln1118_1147_fu_65295_p0 =  (sc_lv<3>) (sext_ln1116_147_fu_46116_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1147_fu_65295_p1() {
    mul_ln1118_1147_fu_65295_p1 = tmp_1147_reg_110366.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1147_fu_65295_p2() {
    mul_ln1118_1147_fu_65295_p2 = (!mul_ln1118_1147_fu_65295_p0.read().is_01() || !mul_ln1118_1147_fu_65295_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1147_fu_65295_p0.read()) * sc_bigint<5>(mul_ln1118_1147_fu_65295_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1148_fu_65316_p0() {
    mul_ln1118_1148_fu_65316_p0 =  (sc_lv<3>) (sext_ln1116_148_fu_46140_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1148_fu_65316_p1() {
    mul_ln1118_1148_fu_65316_p1 = tmp_1148_reg_110371.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1148_fu_65316_p2() {
    mul_ln1118_1148_fu_65316_p2 = (!mul_ln1118_1148_fu_65316_p0.read().is_01() || !mul_ln1118_1148_fu_65316_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1148_fu_65316_p0.read()) * sc_bigint<5>(mul_ln1118_1148_fu_65316_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1149_fu_65337_p0() {
    mul_ln1118_1149_fu_65337_p0 =  (sc_lv<3>) (sext_ln1116_149_fu_46164_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1149_fu_65337_p1() {
    mul_ln1118_1149_fu_65337_p1 = tmp_1149_reg_110376.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1149_fu_65337_p2() {
    mul_ln1118_1149_fu_65337_p2 = (!mul_ln1118_1149_fu_65337_p0.read().is_01() || !mul_ln1118_1149_fu_65337_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1149_fu_65337_p0.read()) * sc_bigint<5>(mul_ln1118_1149_fu_65337_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_114_fu_45486_p0() {
    mul_ln1118_114_fu_45486_p0 =  (sc_lv<3>) (sext_ln1116_114_fu_45480_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_114_fu_45486_p1() {
    mul_ln1118_114_fu_45486_p1 = tmp_114_reg_104730.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_114_fu_45486_p2() {
    mul_ln1118_114_fu_45486_p2 = (!mul_ln1118_114_fu_45486_p0.read().is_01() || !mul_ln1118_114_fu_45486_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_114_fu_45486_p0.read()) * sc_bigint<5>(mul_ln1118_114_fu_45486_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1150_fu_65346_p0() {
    mul_ln1118_1150_fu_65346_p0 =  (sc_lv<3>) (sext_ln1116_150_fu_46176_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1150_fu_65346_p1() {
    mul_ln1118_1150_fu_65346_p1 = tmp_1150_reg_110381.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1150_fu_65346_p2() {
    mul_ln1118_1150_fu_65346_p2 = (!mul_ln1118_1150_fu_65346_p0.read().is_01() || !mul_ln1118_1150_fu_65346_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1150_fu_65346_p0.read()) * sc_bigint<5>(mul_ln1118_1150_fu_65346_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1151_fu_65367_p0() {
    mul_ln1118_1151_fu_65367_p0 =  (sc_lv<3>) (sext_ln1116_151_fu_46200_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1151_fu_65367_p1() {
    mul_ln1118_1151_fu_65367_p1 = tmp_1151_reg_110386.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1151_fu_65367_p2() {
    mul_ln1118_1151_fu_65367_p2 = (!mul_ln1118_1151_fu_65367_p0.read().is_01() || !mul_ln1118_1151_fu_65367_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1151_fu_65367_p0.read()) * sc_bigint<5>(mul_ln1118_1151_fu_65367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1152_fu_91077_p0() {
    mul_ln1118_1152_fu_91077_p0 =  (sc_lv<3>) (sext_ln1116_152_reg_114944.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1152_fu_91077_p1() {
    mul_ln1118_1152_fu_91077_p1 = tmp_1152_reg_110391_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1152_fu_91077_p2() {
    mul_ln1118_1152_fu_91077_p2 = (!mul_ln1118_1152_fu_91077_p0.read().is_01() || !mul_ln1118_1152_fu_91077_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1152_fu_91077_p0.read()) * sc_bigint<5>(mul_ln1118_1152_fu_91077_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1153_fu_65388_p0() {
    mul_ln1118_1153_fu_65388_p0 =  (sc_lv<3>) (sext_ln1116_153_fu_46227_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1153_fu_65388_p1() {
    mul_ln1118_1153_fu_65388_p1 = tmp_1153_reg_110396.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1153_fu_65388_p2() {
    mul_ln1118_1153_fu_65388_p2 = (!mul_ln1118_1153_fu_65388_p0.read().is_01() || !mul_ln1118_1153_fu_65388_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1153_fu_65388_p0.read()) * sc_bigint<5>(mul_ln1118_1153_fu_65388_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1154_fu_65409_p0() {
    mul_ln1118_1154_fu_65409_p0 =  (sc_lv<3>) (sext_ln1116_154_fu_46251_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1154_fu_65409_p1() {
    mul_ln1118_1154_fu_65409_p1 = tmp_1154_reg_110401.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1154_fu_65409_p2() {
    mul_ln1118_1154_fu_65409_p2 = (!mul_ln1118_1154_fu_65409_p0.read().is_01() || !mul_ln1118_1154_fu_65409_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1154_fu_65409_p0.read()) * sc_bigint<5>(mul_ln1118_1154_fu_65409_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1155_fu_65430_p0() {
    mul_ln1118_1155_fu_65430_p0 =  (sc_lv<3>) (sext_ln1116_155_fu_46275_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1155_fu_65430_p1() {
    mul_ln1118_1155_fu_65430_p1 = tmp_1155_reg_110406.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1155_fu_65430_p2() {
    mul_ln1118_1155_fu_65430_p2 = (!mul_ln1118_1155_fu_65430_p0.read().is_01() || !mul_ln1118_1155_fu_65430_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1155_fu_65430_p0.read()) * sc_bigint<5>(mul_ln1118_1155_fu_65430_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1156_fu_65451_p0() {
    mul_ln1118_1156_fu_65451_p0 =  (sc_lv<3>) (sext_ln1116_156_fu_46299_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1156_fu_65451_p1() {
    mul_ln1118_1156_fu_65451_p1 = tmp_1156_reg_110411.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1156_fu_65451_p2() {
    mul_ln1118_1156_fu_65451_p2 = (!mul_ln1118_1156_fu_65451_p0.read().is_01() || !mul_ln1118_1156_fu_65451_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1156_fu_65451_p0.read()) * sc_bigint<5>(mul_ln1118_1156_fu_65451_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1157_fu_65472_p0() {
    mul_ln1118_1157_fu_65472_p0 =  (sc_lv<3>) (sext_ln1116_157_fu_46323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1157_fu_65472_p1() {
    mul_ln1118_1157_fu_65472_p1 = tmp_1157_reg_110416.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1157_fu_65472_p2() {
    mul_ln1118_1157_fu_65472_p2 = (!mul_ln1118_1157_fu_65472_p0.read().is_01() || !mul_ln1118_1157_fu_65472_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1157_fu_65472_p0.read()) * sc_bigint<5>(mul_ln1118_1157_fu_65472_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1158_fu_65493_p0() {
    mul_ln1118_1158_fu_65493_p0 =  (sc_lv<3>) (sext_ln1116_158_fu_46347_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1158_fu_65493_p1() {
    mul_ln1118_1158_fu_65493_p1 = tmp_1158_reg_110421.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1158_fu_65493_p2() {
    mul_ln1118_1158_fu_65493_p2 = (!mul_ln1118_1158_fu_65493_p0.read().is_01() || !mul_ln1118_1158_fu_65493_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1158_fu_65493_p0.read()) * sc_bigint<5>(mul_ln1118_1158_fu_65493_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1159_fu_65514_p0() {
    mul_ln1118_1159_fu_65514_p0 =  (sc_lv<3>) (sext_ln1116_159_fu_46371_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1159_fu_65514_p1() {
    mul_ln1118_1159_fu_65514_p1 = tmp_1159_reg_110426.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1159_fu_65514_p2() {
    mul_ln1118_1159_fu_65514_p2 = (!mul_ln1118_1159_fu_65514_p0.read().is_01() || !mul_ln1118_1159_fu_65514_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1159_fu_65514_p0.read()) * sc_bigint<5>(mul_ln1118_1159_fu_65514_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_115_fu_82480_p0() {
    mul_ln1118_115_fu_82480_p0 =  (sc_lv<3>) (sext_ln1116_115_reg_114857.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_115_fu_82480_p1() {
    mul_ln1118_115_fu_82480_p1 = tmp_115_reg_104740_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_115_fu_82480_p2() {
    mul_ln1118_115_fu_82480_p2 = (!mul_ln1118_115_fu_82480_p0.read().is_01() || !mul_ln1118_115_fu_82480_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_115_fu_82480_p0.read()) * sc_bigint<5>(mul_ln1118_115_fu_82480_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1160_fu_65523_p0() {
    mul_ln1118_1160_fu_65523_p0 =  (sc_lv<3>) (sext_ln1116_160_fu_46383_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1160_fu_65523_p1() {
    mul_ln1118_1160_fu_65523_p1 = tmp_1160_reg_110431.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1160_fu_65523_p2() {
    mul_ln1118_1160_fu_65523_p2 = (!mul_ln1118_1160_fu_65523_p0.read().is_01() || !mul_ln1118_1160_fu_65523_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1160_fu_65523_p0.read()) * sc_bigint<5>(mul_ln1118_1160_fu_65523_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1161_fu_65544_p0() {
    mul_ln1118_1161_fu_65544_p0 =  (sc_lv<3>) (sext_ln1116_161_fu_46407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1161_fu_65544_p1() {
    mul_ln1118_1161_fu_65544_p1 = tmp_1161_reg_110436.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1161_fu_65544_p2() {
    mul_ln1118_1161_fu_65544_p2 = (!mul_ln1118_1161_fu_65544_p0.read().is_01() || !mul_ln1118_1161_fu_65544_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1161_fu_65544_p0.read()) * sc_bigint<5>(mul_ln1118_1161_fu_65544_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1162_fu_65565_p0() {
    mul_ln1118_1162_fu_65565_p0 =  (sc_lv<3>) (sext_ln1116_162_fu_46431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1162_fu_65565_p1() {
    mul_ln1118_1162_fu_65565_p1 = tmp_1162_reg_110441.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1162_fu_65565_p2() {
    mul_ln1118_1162_fu_65565_p2 = (!mul_ln1118_1162_fu_65565_p0.read().is_01() || !mul_ln1118_1162_fu_65565_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1162_fu_65565_p0.read()) * sc_bigint<5>(mul_ln1118_1162_fu_65565_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1163_fu_65574_p0() {
    mul_ln1118_1163_fu_65574_p0 =  (sc_lv<3>) (sext_ln1116_163_fu_46443_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1163_fu_65574_p1() {
    mul_ln1118_1163_fu_65574_p1 = tmp_1163_reg_110446.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1163_fu_65574_p2() {
    mul_ln1118_1163_fu_65574_p2 = (!mul_ln1118_1163_fu_65574_p0.read().is_01() || !mul_ln1118_1163_fu_65574_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1163_fu_65574_p0.read()) * sc_bigint<5>(mul_ln1118_1163_fu_65574_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1164_fu_65595_p0() {
    mul_ln1118_1164_fu_65595_p0 =  (sc_lv<3>) (sext_ln1116_164_fu_46467_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1164_fu_65595_p1() {
    mul_ln1118_1164_fu_65595_p1 = tmp_1164_reg_110451.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1164_fu_65595_p2() {
    mul_ln1118_1164_fu_65595_p2 = (!mul_ln1118_1164_fu_65595_p0.read().is_01() || !mul_ln1118_1164_fu_65595_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1164_fu_65595_p0.read()) * sc_bigint<5>(mul_ln1118_1164_fu_65595_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1165_fu_91119_p0() {
    mul_ln1118_1165_fu_91119_p0 =  (sc_lv<3>) (sext_ln1116_165_reg_114967.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1165_fu_91119_p1() {
    mul_ln1118_1165_fu_91119_p1 = tmp_1165_reg_110456_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1165_fu_91119_p2() {
    mul_ln1118_1165_fu_91119_p2 = (!mul_ln1118_1165_fu_91119_p0.read().is_01() || !mul_ln1118_1165_fu_91119_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1165_fu_91119_p0.read()) * sc_bigint<5>(mul_ln1118_1165_fu_91119_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1166_fu_65616_p0() {
    mul_ln1118_1166_fu_65616_p0 =  (sc_lv<3>) (sext_ln1116_166_fu_46494_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1166_fu_65616_p1() {
    mul_ln1118_1166_fu_65616_p1 = tmp_1166_reg_110461.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1166_fu_65616_p2() {
    mul_ln1118_1166_fu_65616_p2 = (!mul_ln1118_1166_fu_65616_p0.read().is_01() || !mul_ln1118_1166_fu_65616_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1166_fu_65616_p0.read()) * sc_bigint<5>(mul_ln1118_1166_fu_65616_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1167_fu_65637_p0() {
    mul_ln1118_1167_fu_65637_p0 =  (sc_lv<3>) (sext_ln1116_167_fu_46518_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1167_fu_65637_p1() {
    mul_ln1118_1167_fu_65637_p1 = tmp_1167_reg_110466.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1167_fu_65637_p2() {
    mul_ln1118_1167_fu_65637_p2 = (!mul_ln1118_1167_fu_65637_p0.read().is_01() || !mul_ln1118_1167_fu_65637_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1167_fu_65637_p0.read()) * sc_bigint<5>(mul_ln1118_1167_fu_65637_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1168_fu_91139_p0() {
    mul_ln1118_1168_fu_91139_p0 =  (sc_lv<3>) (sext_ln1116_168_reg_114980.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1168_fu_91139_p1() {
    mul_ln1118_1168_fu_91139_p1 = tmp_1168_reg_110471_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1168_fu_91139_p2() {
    mul_ln1118_1168_fu_91139_p2 = (!mul_ln1118_1168_fu_91139_p0.read().is_01() || !mul_ln1118_1168_fu_91139_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1168_fu_91139_p0.read()) * sc_bigint<5>(mul_ln1118_1168_fu_91139_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1169_fu_65658_p0() {
    mul_ln1118_1169_fu_65658_p0 =  (sc_lv<3>) (sext_ln1116_169_fu_46545_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1169_fu_65658_p1() {
    mul_ln1118_1169_fu_65658_p1 = tmp_1169_reg_110476.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1169_fu_65658_p2() {
    mul_ln1118_1169_fu_65658_p2 = (!mul_ln1118_1169_fu_65658_p0.read().is_01() || !mul_ln1118_1169_fu_65658_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1169_fu_65658_p0.read()) * sc_bigint<5>(mul_ln1118_1169_fu_65658_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_116_fu_45513_p0() {
    mul_ln1118_116_fu_45513_p0 =  (sc_lv<3>) (sext_ln1116_116_fu_45507_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_116_fu_45513_p1() {
    mul_ln1118_116_fu_45513_p1 = tmp_116_reg_104750.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_116_fu_45513_p2() {
    mul_ln1118_116_fu_45513_p2 = (!mul_ln1118_116_fu_45513_p0.read().is_01() || !mul_ln1118_116_fu_45513_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_116_fu_45513_p0.read()) * sc_bigint<5>(mul_ln1118_116_fu_45513_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1170_fu_65679_p0() {
    mul_ln1118_1170_fu_65679_p0 =  (sc_lv<3>) (sext_ln1116_170_fu_46569_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1170_fu_65679_p1() {
    mul_ln1118_1170_fu_65679_p1 = tmp_1170_reg_110481.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1170_fu_65679_p2() {
    mul_ln1118_1170_fu_65679_p2 = (!mul_ln1118_1170_fu_65679_p0.read().is_01() || !mul_ln1118_1170_fu_65679_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1170_fu_65679_p0.read()) * sc_bigint<5>(mul_ln1118_1170_fu_65679_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1171_fu_65700_p0() {
    mul_ln1118_1171_fu_65700_p0 =  (sc_lv<3>) (sext_ln1116_171_fu_46593_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1171_fu_65700_p1() {
    mul_ln1118_1171_fu_65700_p1 = tmp_1171_reg_110486.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1171_fu_65700_p2() {
    mul_ln1118_1171_fu_65700_p2 = (!mul_ln1118_1171_fu_65700_p0.read().is_01() || !mul_ln1118_1171_fu_65700_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1171_fu_65700_p0.read()) * sc_bigint<5>(mul_ln1118_1171_fu_65700_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1172_fu_65709_p0() {
    mul_ln1118_1172_fu_65709_p0 =  (sc_lv<3>) (sext_ln1116_172_fu_46605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1172_fu_65709_p1() {
    mul_ln1118_1172_fu_65709_p1 = tmp_1172_reg_110491.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1172_fu_65709_p2() {
    mul_ln1118_1172_fu_65709_p2 = (!mul_ln1118_1172_fu_65709_p0.read().is_01() || !mul_ln1118_1172_fu_65709_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1172_fu_65709_p0.read()) * sc_bigint<5>(mul_ln1118_1172_fu_65709_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1173_fu_65730_p0() {
    mul_ln1118_1173_fu_65730_p0 =  (sc_lv<3>) (sext_ln1116_173_fu_46629_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1173_fu_65730_p1() {
    mul_ln1118_1173_fu_65730_p1 = tmp_1173_reg_110496.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1173_fu_65730_p2() {
    mul_ln1118_1173_fu_65730_p2 = (!mul_ln1118_1173_fu_65730_p0.read().is_01() || !mul_ln1118_1173_fu_65730_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1173_fu_65730_p0.read()) * sc_bigint<5>(mul_ln1118_1173_fu_65730_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1174_fu_65751_p0() {
    mul_ln1118_1174_fu_65751_p0 =  (sc_lv<3>) (sext_ln1116_174_fu_46653_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1174_fu_65751_p1() {
    mul_ln1118_1174_fu_65751_p1 = tmp_1174_reg_110501.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1174_fu_65751_p2() {
    mul_ln1118_1174_fu_65751_p2 = (!mul_ln1118_1174_fu_65751_p0.read().is_01() || !mul_ln1118_1174_fu_65751_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1174_fu_65751_p0.read()) * sc_bigint<5>(mul_ln1118_1174_fu_65751_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1175_fu_65760_p0() {
    mul_ln1118_1175_fu_65760_p0 =  (sc_lv<3>) (sext_ln1116_175_fu_46665_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1175_fu_65760_p1() {
    mul_ln1118_1175_fu_65760_p1 = tmp_1175_reg_110506.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1175_fu_65760_p2() {
    mul_ln1118_1175_fu_65760_p2 = (!mul_ln1118_1175_fu_65760_p0.read().is_01() || !mul_ln1118_1175_fu_65760_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1175_fu_65760_p0.read()) * sc_bigint<5>(mul_ln1118_1175_fu_65760_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1176_fu_65781_p0() {
    mul_ln1118_1176_fu_65781_p0 =  (sc_lv<3>) (sext_ln1116_176_fu_46689_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1176_fu_65781_p1() {
    mul_ln1118_1176_fu_65781_p1 = tmp_1176_reg_110511.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1176_fu_65781_p2() {
    mul_ln1118_1176_fu_65781_p2 = (!mul_ln1118_1176_fu_65781_p0.read().is_01() || !mul_ln1118_1176_fu_65781_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1176_fu_65781_p0.read()) * sc_bigint<5>(mul_ln1118_1176_fu_65781_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1177_fu_65802_p0() {
    mul_ln1118_1177_fu_65802_p0 =  (sc_lv<3>) (sext_ln1116_177_fu_46713_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1177_fu_65802_p1() {
    mul_ln1118_1177_fu_65802_p1 = tmp_1177_reg_110516.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1177_fu_65802_p2() {
    mul_ln1118_1177_fu_65802_p2 = (!mul_ln1118_1177_fu_65802_p0.read().is_01() || !mul_ln1118_1177_fu_65802_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1177_fu_65802_p0.read()) * sc_bigint<5>(mul_ln1118_1177_fu_65802_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1178_fu_65811_p0() {
    mul_ln1118_1178_fu_65811_p0 =  (sc_lv<3>) (sext_ln1116_178_fu_46725_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1178_fu_65811_p1() {
    mul_ln1118_1178_fu_65811_p1 = tmp_1178_reg_110521.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1178_fu_65811_p2() {
    mul_ln1118_1178_fu_65811_p2 = (!mul_ln1118_1178_fu_65811_p0.read().is_01() || !mul_ln1118_1178_fu_65811_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1178_fu_65811_p0.read()) * sc_bigint<5>(mul_ln1118_1178_fu_65811_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1179_fu_65832_p0() {
    mul_ln1118_1179_fu_65832_p0 =  (sc_lv<3>) (sext_ln1116_179_fu_46749_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1179_fu_65832_p1() {
    mul_ln1118_1179_fu_65832_p1 = tmp_1179_reg_110526.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1179_fu_65832_p2() {
    mul_ln1118_1179_fu_65832_p2 = (!mul_ln1118_1179_fu_65832_p0.read().is_01() || !mul_ln1118_1179_fu_65832_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1179_fu_65832_p0.read()) * sc_bigint<5>(mul_ln1118_1179_fu_65832_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_117_fu_45537_p0() {
    mul_ln1118_117_fu_45537_p0 =  (sc_lv<3>) (sext_ln1116_117_fu_45531_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_117_fu_45537_p1() {
    mul_ln1118_117_fu_45537_p1 = tmp_117_reg_104760.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_117_fu_45537_p2() {
    mul_ln1118_117_fu_45537_p2 = (!mul_ln1118_117_fu_45537_p0.read().is_01() || !mul_ln1118_117_fu_45537_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_117_fu_45537_p0.read()) * sc_bigint<5>(mul_ln1118_117_fu_45537_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1180_fu_65853_p0() {
    mul_ln1118_1180_fu_65853_p0 =  (sc_lv<3>) (sext_ln1116_180_fu_46773_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1180_fu_65853_p1() {
    mul_ln1118_1180_fu_65853_p1 = tmp_1180_reg_110531.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1180_fu_65853_p2() {
    mul_ln1118_1180_fu_65853_p2 = (!mul_ln1118_1180_fu_65853_p0.read().is_01() || !mul_ln1118_1180_fu_65853_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1180_fu_65853_p0.read()) * sc_bigint<5>(mul_ln1118_1180_fu_65853_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1181_fu_65874_p0() {
    mul_ln1118_1181_fu_65874_p0 =  (sc_lv<3>) (sext_ln1116_181_fu_46797_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1181_fu_65874_p1() {
    mul_ln1118_1181_fu_65874_p1 = tmp_1181_reg_110536.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1181_fu_65874_p2() {
    mul_ln1118_1181_fu_65874_p2 = (!mul_ln1118_1181_fu_65874_p0.read().is_01() || !mul_ln1118_1181_fu_65874_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1181_fu_65874_p0.read()) * sc_bigint<5>(mul_ln1118_1181_fu_65874_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1182_fu_65895_p0() {
    mul_ln1118_1182_fu_65895_p0 =  (sc_lv<3>) (sext_ln1116_182_fu_46821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1182_fu_65895_p1() {
    mul_ln1118_1182_fu_65895_p1 = tmp_1182_reg_110541.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1182_fu_65895_p2() {
    mul_ln1118_1182_fu_65895_p2 = (!mul_ln1118_1182_fu_65895_p0.read().is_01() || !mul_ln1118_1182_fu_65895_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1182_fu_65895_p0.read()) * sc_bigint<5>(mul_ln1118_1182_fu_65895_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1183_fu_65916_p0() {
    mul_ln1118_1183_fu_65916_p0 =  (sc_lv<3>) (sext_ln1116_183_fu_46845_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1183_fu_65916_p1() {
    mul_ln1118_1183_fu_65916_p1 = tmp_1183_reg_110546.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1183_fu_65916_p2() {
    mul_ln1118_1183_fu_65916_p2 = (!mul_ln1118_1183_fu_65916_p0.read().is_01() || !mul_ln1118_1183_fu_65916_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1183_fu_65916_p0.read()) * sc_bigint<5>(mul_ln1118_1183_fu_65916_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1184_fu_65937_p0() {
    mul_ln1118_1184_fu_65937_p0 =  (sc_lv<3>) (sext_ln1116_184_fu_46869_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1184_fu_65937_p1() {
    mul_ln1118_1184_fu_65937_p1 = tmp_1184_reg_110551.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1184_fu_65937_p2() {
    mul_ln1118_1184_fu_65937_p2 = (!mul_ln1118_1184_fu_65937_p0.read().is_01() || !mul_ln1118_1184_fu_65937_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1184_fu_65937_p0.read()) * sc_bigint<5>(mul_ln1118_1184_fu_65937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1185_fu_65946_p0() {
    mul_ln1118_1185_fu_65946_p0 =  (sc_lv<3>) (sext_ln1116_185_fu_46881_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1185_fu_65946_p1() {
    mul_ln1118_1185_fu_65946_p1 = tmp_1185_reg_110556.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1185_fu_65946_p2() {
    mul_ln1118_1185_fu_65946_p2 = (!mul_ln1118_1185_fu_65946_p0.read().is_01() || !mul_ln1118_1185_fu_65946_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1185_fu_65946_p0.read()) * sc_bigint<5>(mul_ln1118_1185_fu_65946_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1186_fu_65967_p0() {
    mul_ln1118_1186_fu_65967_p0 =  (sc_lv<3>) (sext_ln1116_186_fu_46905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1186_fu_65967_p1() {
    mul_ln1118_1186_fu_65967_p1 = tmp_1186_reg_110561.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1186_fu_65967_p2() {
    mul_ln1118_1186_fu_65967_p2 = (!mul_ln1118_1186_fu_65967_p0.read().is_01() || !mul_ln1118_1186_fu_65967_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1186_fu_65967_p0.read()) * sc_bigint<5>(mul_ln1118_1186_fu_65967_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1187_fu_65988_p0() {
    mul_ln1118_1187_fu_65988_p0 =  (sc_lv<3>) (sext_ln1116_187_fu_46929_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1187_fu_65988_p1() {
    mul_ln1118_1187_fu_65988_p1 = tmp_1187_reg_110566.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1187_fu_65988_p2() {
    mul_ln1118_1187_fu_65988_p2 = (!mul_ln1118_1187_fu_65988_p0.read().is_01() || !mul_ln1118_1187_fu_65988_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1187_fu_65988_p0.read()) * sc_bigint<5>(mul_ln1118_1187_fu_65988_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1188_fu_65997_p0() {
    mul_ln1118_1188_fu_65997_p0 =  (sc_lv<3>) (sext_ln1116_188_fu_46941_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1188_fu_65997_p1() {
    mul_ln1118_1188_fu_65997_p1 = tmp_1188_reg_110571.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1188_fu_65997_p2() {
    mul_ln1118_1188_fu_65997_p2 = (!mul_ln1118_1188_fu_65997_p0.read().is_01() || !mul_ln1118_1188_fu_65997_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1188_fu_65997_p0.read()) * sc_bigint<5>(mul_ln1118_1188_fu_65997_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1189_fu_66018_p0() {
    mul_ln1118_1189_fu_66018_p0 =  (sc_lv<3>) (sext_ln1116_189_fu_46965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1189_fu_66018_p1() {
    mul_ln1118_1189_fu_66018_p1 = tmp_1189_reg_110576.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1189_fu_66018_p2() {
    mul_ln1118_1189_fu_66018_p2 = (!mul_ln1118_1189_fu_66018_p0.read().is_01() || !mul_ln1118_1189_fu_66018_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1189_fu_66018_p0.read()) * sc_bigint<5>(mul_ln1118_1189_fu_66018_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_118_fu_82500_p0() {
    mul_ln1118_118_fu_82500_p0 =  (sc_lv<3>) (sext_ln1116_118_reg_114870.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_118_fu_82500_p1() {
    mul_ln1118_118_fu_82500_p1 = tmp_118_reg_104770_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_118_fu_82500_p2() {
    mul_ln1118_118_fu_82500_p2 = (!mul_ln1118_118_fu_82500_p0.read().is_01() || !mul_ln1118_118_fu_82500_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_118_fu_82500_p0.read()) * sc_bigint<5>(mul_ln1118_118_fu_82500_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1190_fu_91214_p0() {
    mul_ln1118_1190_fu_91214_p0 =  (sc_lv<3>) (sext_ln1116_190_reg_115018.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1190_fu_91214_p1() {
    mul_ln1118_1190_fu_91214_p1 = tmp_1190_reg_110581_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1190_fu_91214_p2() {
    mul_ln1118_1190_fu_91214_p2 = (!mul_ln1118_1190_fu_91214_p0.read().is_01() || !mul_ln1118_1190_fu_91214_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1190_fu_91214_p0.read()) * sc_bigint<5>(mul_ln1118_1190_fu_91214_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1191_fu_66039_p0() {
    mul_ln1118_1191_fu_66039_p0 =  (sc_lv<3>) (sext_ln1116_191_fu_46992_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1191_fu_66039_p1() {
    mul_ln1118_1191_fu_66039_p1 = tmp_1191_reg_110586.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1191_fu_66039_p2() {
    mul_ln1118_1191_fu_66039_p2 = (!mul_ln1118_1191_fu_66039_p0.read().is_01() || !mul_ln1118_1191_fu_66039_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1191_fu_66039_p0.read()) * sc_bigint<5>(mul_ln1118_1191_fu_66039_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1192_fu_66060_p0() {
    mul_ln1118_1192_fu_66060_p0 =  (sc_lv<3>) (sext_ln1116_192_fu_47016_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1192_fu_66060_p1() {
    mul_ln1118_1192_fu_66060_p1 = tmp_1192_reg_110591.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1192_fu_66060_p2() {
    mul_ln1118_1192_fu_66060_p2 = (!mul_ln1118_1192_fu_66060_p0.read().is_01() || !mul_ln1118_1192_fu_66060_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1192_fu_66060_p0.read()) * sc_bigint<5>(mul_ln1118_1192_fu_66060_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1193_fu_91234_p0() {
    mul_ln1118_1193_fu_91234_p0 =  (sc_lv<3>) (sext_ln1116_193_reg_115031.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1193_fu_91234_p1() {
    mul_ln1118_1193_fu_91234_p1 = tmp_1193_reg_110596_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1193_fu_91234_p2() {
    mul_ln1118_1193_fu_91234_p2 = (!mul_ln1118_1193_fu_91234_p0.read().is_01() || !mul_ln1118_1193_fu_91234_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1193_fu_91234_p0.read()) * sc_bigint<5>(mul_ln1118_1193_fu_91234_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1194_fu_66081_p0() {
    mul_ln1118_1194_fu_66081_p0 =  (sc_lv<3>) (sext_ln1116_194_fu_47043_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1194_fu_66081_p1() {
    mul_ln1118_1194_fu_66081_p1 = tmp_1194_reg_110601.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1194_fu_66081_p2() {
    mul_ln1118_1194_fu_66081_p2 = (!mul_ln1118_1194_fu_66081_p0.read().is_01() || !mul_ln1118_1194_fu_66081_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1194_fu_66081_p0.read()) * sc_bigint<5>(mul_ln1118_1194_fu_66081_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1195_fu_66102_p0() {
    mul_ln1118_1195_fu_66102_p0 =  (sc_lv<3>) (sext_ln1116_195_fu_47067_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1195_fu_66102_p1() {
    mul_ln1118_1195_fu_66102_p1 = tmp_1195_reg_110606.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1195_fu_66102_p2() {
    mul_ln1118_1195_fu_66102_p2 = (!mul_ln1118_1195_fu_66102_p0.read().is_01() || !mul_ln1118_1195_fu_66102_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1195_fu_66102_p0.read()) * sc_bigint<5>(mul_ln1118_1195_fu_66102_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1196_fu_66123_p0() {
    mul_ln1118_1196_fu_66123_p0 =  (sc_lv<3>) (sext_ln1116_196_fu_47091_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1196_fu_66123_p1() {
    mul_ln1118_1196_fu_66123_p1 = tmp_1196_reg_110611.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1196_fu_66123_p2() {
    mul_ln1118_1196_fu_66123_p2 = (!mul_ln1118_1196_fu_66123_p0.read().is_01() || !mul_ln1118_1196_fu_66123_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1196_fu_66123_p0.read()) * sc_bigint<5>(mul_ln1118_1196_fu_66123_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1197_fu_66132_p0() {
    mul_ln1118_1197_fu_66132_p0 =  (sc_lv<3>) (sext_ln1116_197_fu_47103_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1197_fu_66132_p1() {
    mul_ln1118_1197_fu_66132_p1 = tmp_1197_reg_110616.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1197_fu_66132_p2() {
    mul_ln1118_1197_fu_66132_p2 = (!mul_ln1118_1197_fu_66132_p0.read().is_01() || !mul_ln1118_1197_fu_66132_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1197_fu_66132_p0.read()) * sc_bigint<5>(mul_ln1118_1197_fu_66132_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1198_fu_66153_p0() {
    mul_ln1118_1198_fu_66153_p0 =  (sc_lv<3>) (sext_ln1116_198_fu_47127_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1198_fu_66153_p1() {
    mul_ln1118_1198_fu_66153_p1 = tmp_1198_reg_110621.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1198_fu_66153_p2() {
    mul_ln1118_1198_fu_66153_p2 = (!mul_ln1118_1198_fu_66153_p0.read().is_01() || !mul_ln1118_1198_fu_66153_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1198_fu_66153_p0.read()) * sc_bigint<5>(mul_ln1118_1198_fu_66153_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1199_fu_66174_p0() {
    mul_ln1118_1199_fu_66174_p0 =  (sc_lv<3>) (sext_ln1116_199_fu_47151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1199_fu_66174_p1() {
    mul_ln1118_1199_fu_66174_p1 = tmp_1199_reg_110626.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1199_fu_66174_p2() {
    mul_ln1118_1199_fu_66174_p2 = (!mul_ln1118_1199_fu_66174_p0.read().is_01() || !mul_ln1118_1199_fu_66174_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1199_fu_66174_p0.read()) * sc_bigint<5>(mul_ln1118_1199_fu_66174_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_119_fu_45564_p0() {
    mul_ln1118_119_fu_45564_p0 =  (sc_lv<3>) (sext_ln1116_119_fu_45558_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_119_fu_45564_p1() {
    mul_ln1118_119_fu_45564_p1 = tmp_119_reg_104780.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_119_fu_45564_p2() {
    mul_ln1118_119_fu_45564_p2 = (!mul_ln1118_119_fu_45564_p0.read().is_01() || !mul_ln1118_119_fu_45564_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_119_fu_45564_p0.read()) * sc_bigint<5>(mul_ln1118_119_fu_45564_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_11_fu_43449_p0() {
    mul_ln1118_11_fu_43449_p0 =  (sc_lv<3>) (sext_ln1116_11_fu_43443_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_11_fu_43449_p1() {
    mul_ln1118_11_fu_43449_p1 = tmp_12_reg_103700.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_11_fu_43449_p2() {
    mul_ln1118_11_fu_43449_p2 = (!mul_ln1118_11_fu_43449_p0.read().is_01() || !mul_ln1118_11_fu_43449_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_11_fu_43449_p0.read()) * sc_bigint<5>(mul_ln1118_11_fu_43449_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1200_fu_66183_p0() {
    mul_ln1118_1200_fu_66183_p0 =  (sc_lv<3>) (sext_ln1116_200_fu_47163_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1200_fu_66183_p1() {
    mul_ln1118_1200_fu_66183_p1 = tmp_1200_reg_110631.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1200_fu_66183_p2() {
    mul_ln1118_1200_fu_66183_p2 = (!mul_ln1118_1200_fu_66183_p0.read().is_01() || !mul_ln1118_1200_fu_66183_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1200_fu_66183_p0.read()) * sc_bigint<5>(mul_ln1118_1200_fu_66183_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1201_fu_66204_p0() {
    mul_ln1118_1201_fu_66204_p0 =  (sc_lv<3>) (sext_ln1116_201_fu_47187_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1201_fu_66204_p1() {
    mul_ln1118_1201_fu_66204_p1 = tmp_1201_reg_110636.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1201_fu_66204_p2() {
    mul_ln1118_1201_fu_66204_p2 = (!mul_ln1118_1201_fu_66204_p0.read().is_01() || !mul_ln1118_1201_fu_66204_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1201_fu_66204_p0.read()) * sc_bigint<5>(mul_ln1118_1201_fu_66204_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1202_fu_66225_p0() {
    mul_ln1118_1202_fu_66225_p0 =  (sc_lv<3>) (sext_ln1116_202_fu_47211_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1202_fu_66225_p1() {
    mul_ln1118_1202_fu_66225_p1 = tmp_1202_reg_110641.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1202_fu_66225_p2() {
    mul_ln1118_1202_fu_66225_p2 = (!mul_ln1118_1202_fu_66225_p0.read().is_01() || !mul_ln1118_1202_fu_66225_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1202_fu_66225_p0.read()) * sc_bigint<5>(mul_ln1118_1202_fu_66225_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1203_fu_66234_p0() {
    mul_ln1118_1203_fu_66234_p0 =  (sc_lv<3>) (sext_ln1116_203_fu_47223_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1203_fu_66234_p1() {
    mul_ln1118_1203_fu_66234_p1 = tmp_1203_reg_110646.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1203_fu_66234_p2() {
    mul_ln1118_1203_fu_66234_p2 = (!mul_ln1118_1203_fu_66234_p0.read().is_01() || !mul_ln1118_1203_fu_66234_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1203_fu_66234_p0.read()) * sc_bigint<5>(mul_ln1118_1203_fu_66234_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1204_fu_66255_p0() {
    mul_ln1118_1204_fu_66255_p0 =  (sc_lv<3>) (sext_ln1116_204_fu_47247_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1204_fu_66255_p1() {
    mul_ln1118_1204_fu_66255_p1 = tmp_1204_reg_110651.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1204_fu_66255_p2() {
    mul_ln1118_1204_fu_66255_p2 = (!mul_ln1118_1204_fu_66255_p0.read().is_01() || !mul_ln1118_1204_fu_66255_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1204_fu_66255_p0.read()) * sc_bigint<5>(mul_ln1118_1204_fu_66255_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1205_fu_66276_p0() {
    mul_ln1118_1205_fu_66276_p0 =  (sc_lv<3>) (sext_ln1116_205_fu_47271_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1205_fu_66276_p1() {
    mul_ln1118_1205_fu_66276_p1 = tmp_1205_reg_110656.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1205_fu_66276_p2() {
    mul_ln1118_1205_fu_66276_p2 = (!mul_ln1118_1205_fu_66276_p0.read().is_01() || !mul_ln1118_1205_fu_66276_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1205_fu_66276_p0.read()) * sc_bigint<5>(mul_ln1118_1205_fu_66276_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1206_fu_66297_p0() {
    mul_ln1118_1206_fu_66297_p0 =  (sc_lv<3>) (sext_ln1116_206_fu_47295_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1206_fu_66297_p1() {
    mul_ln1118_1206_fu_66297_p1 = tmp_1206_reg_110661.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1206_fu_66297_p2() {
    mul_ln1118_1206_fu_66297_p2 = (!mul_ln1118_1206_fu_66297_p0.read().is_01() || !mul_ln1118_1206_fu_66297_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1206_fu_66297_p0.read()) * sc_bigint<5>(mul_ln1118_1206_fu_66297_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1207_fu_66318_p0() {
    mul_ln1118_1207_fu_66318_p0 =  (sc_lv<3>) (sext_ln1116_207_fu_47319_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1207_fu_66318_p1() {
    mul_ln1118_1207_fu_66318_p1 = tmp_1207_reg_110666.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1207_fu_66318_p2() {
    mul_ln1118_1207_fu_66318_p2 = (!mul_ln1118_1207_fu_66318_p0.read().is_01() || !mul_ln1118_1207_fu_66318_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1207_fu_66318_p0.read()) * sc_bigint<5>(mul_ln1118_1207_fu_66318_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1208_fu_66339_p0() {
    mul_ln1118_1208_fu_66339_p0 =  (sc_lv<3>) (sext_ln1116_208_fu_47343_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1208_fu_66339_p1() {
    mul_ln1118_1208_fu_66339_p1 = tmp_1208_reg_110671.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1208_fu_66339_p2() {
    mul_ln1118_1208_fu_66339_p2 = (!mul_ln1118_1208_fu_66339_p0.read().is_01() || !mul_ln1118_1208_fu_66339_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1208_fu_66339_p0.read()) * sc_bigint<5>(mul_ln1118_1208_fu_66339_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1209_fu_66792_p0() {
    mul_ln1118_1209_fu_66792_p0 =  (sc_lv<3>) (sext_ln1116_fu_43407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1209_fu_66792_p1() {
    mul_ln1118_1209_fu_66792_p1 = tmp_1209_reg_110676.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1209_fu_66792_p2() {
    mul_ln1118_1209_fu_66792_p2 = (!mul_ln1118_1209_fu_66792_p0.read().is_01() || !mul_ln1118_1209_fu_66792_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1209_fu_66792_p0.read()) * sc_bigint<5>(mul_ln1118_1209_fu_66792_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_120_fu_45588_p0() {
    mul_ln1118_120_fu_45588_p0 =  (sc_lv<3>) (sext_ln1116_120_fu_45582_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_120_fu_45588_p1() {
    mul_ln1118_120_fu_45588_p1 = tmp_120_reg_104790.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_120_fu_45588_p2() {
    mul_ln1118_120_fu_45588_p2 = (!mul_ln1118_120_fu_45588_p0.read().is_01() || !mul_ln1118_120_fu_45588_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_120_fu_45588_p0.read()) * sc_bigint<5>(mul_ln1118_120_fu_45588_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1210_fu_66801_p0() {
    mul_ln1118_1210_fu_66801_p0 =  (sc_lv<3>) (sext_ln1116_10_fu_43419_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1210_fu_66801_p1() {
    mul_ln1118_1210_fu_66801_p1 = tmp_1210_reg_110681.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1210_fu_66801_p2() {
    mul_ln1118_1210_fu_66801_p2 = (!mul_ln1118_1210_fu_66801_p0.read().is_01() || !mul_ln1118_1210_fu_66801_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1210_fu_66801_p0.read()) * sc_bigint<5>(mul_ln1118_1210_fu_66801_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1211_fu_66822_p0() {
    mul_ln1118_1211_fu_66822_p0 =  (sc_lv<3>) (sext_ln1116_11_fu_43443_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1211_fu_66822_p1() {
    mul_ln1118_1211_fu_66822_p1 = tmp_1211_reg_110686.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1211_fu_66822_p2() {
    mul_ln1118_1211_fu_66822_p2 = (!mul_ln1118_1211_fu_66822_p0.read().is_01() || !mul_ln1118_1211_fu_66822_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1211_fu_66822_p0.read()) * sc_bigint<5>(mul_ln1118_1211_fu_66822_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1212_fu_66843_p0() {
    mul_ln1118_1212_fu_66843_p0 =  (sc_lv<3>) (sext_ln1116_12_fu_43467_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1212_fu_66843_p1() {
    mul_ln1118_1212_fu_66843_p1 = tmp_1212_reg_110691.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1212_fu_66843_p2() {
    mul_ln1118_1212_fu_66843_p2 = (!mul_ln1118_1212_fu_66843_p0.read().is_01() || !mul_ln1118_1212_fu_66843_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1212_fu_66843_p0.read()) * sc_bigint<5>(mul_ln1118_1212_fu_66843_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1213_fu_66852_p0() {
    mul_ln1118_1213_fu_66852_p0 =  (sc_lv<3>) (sext_ln1116_13_fu_43479_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1213_fu_66852_p1() {
    mul_ln1118_1213_fu_66852_p1 = tmp_1213_reg_110696.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1213_fu_66852_p2() {
    mul_ln1118_1213_fu_66852_p2 = (!mul_ln1118_1213_fu_66852_p0.read().is_01() || !mul_ln1118_1213_fu_66852_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1213_fu_66852_p0.read()) * sc_bigint<5>(mul_ln1118_1213_fu_66852_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1214_fu_66873_p0() {
    mul_ln1118_1214_fu_66873_p0 =  (sc_lv<3>) (sext_ln1116_14_fu_43503_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1214_fu_66873_p1() {
    mul_ln1118_1214_fu_66873_p1 = tmp_1214_reg_110701.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1214_fu_66873_p2() {
    mul_ln1118_1214_fu_66873_p2 = (!mul_ln1118_1214_fu_66873_p0.read().is_01() || !mul_ln1118_1214_fu_66873_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1214_fu_66873_p0.read()) * sc_bigint<5>(mul_ln1118_1214_fu_66873_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1215_fu_92217_p0() {
    mul_ln1118_1215_fu_92217_p0 =  (sc_lv<3>) (sext_ln1116_15_fu_82080_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1215_fu_92217_p1() {
    mul_ln1118_1215_fu_92217_p1 = tmp_1215_reg_110706_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1215_fu_92217_p2() {
    mul_ln1118_1215_fu_92217_p2 = (!mul_ln1118_1215_fu_92217_p0.read().is_01() || !mul_ln1118_1215_fu_92217_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1215_fu_92217_p0.read()) * sc_bigint<5>(mul_ln1118_1215_fu_92217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1216_fu_66894_p0() {
    mul_ln1118_1216_fu_66894_p0 =  (sc_lv<3>) (sext_ln1116_16_fu_43527_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1216_fu_66894_p1() {
    mul_ln1118_1216_fu_66894_p1 = tmp_1216_reg_110711.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1216_fu_66894_p2() {
    mul_ln1118_1216_fu_66894_p2 = (!mul_ln1118_1216_fu_66894_p0.read().is_01() || !mul_ln1118_1216_fu_66894_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1216_fu_66894_p0.read()) * sc_bigint<5>(mul_ln1118_1216_fu_66894_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1217_fu_66915_p0() {
    mul_ln1118_1217_fu_66915_p0 =  (sc_lv<3>) (sext_ln1116_17_fu_43551_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1217_fu_66915_p1() {
    mul_ln1118_1217_fu_66915_p1 = tmp_1217_reg_110716.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1217_fu_66915_p2() {
    mul_ln1118_1217_fu_66915_p2 = (!mul_ln1118_1217_fu_66915_p0.read().is_01() || !mul_ln1118_1217_fu_66915_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1217_fu_66915_p0.read()) * sc_bigint<5>(mul_ln1118_1217_fu_66915_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1218_fu_92238_p0() {
    mul_ln1118_1218_fu_92238_p0 =  (sc_lv<3>) (sext_ln1116_18_fu_82104_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1218_fu_92238_p1() {
    mul_ln1118_1218_fu_92238_p1 = tmp_1218_reg_110721_pp0_iter2_reg.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1218_fu_92238_p2() {
    mul_ln1118_1218_fu_92238_p2 = (!mul_ln1118_1218_fu_92238_p0.read().is_01() || !mul_ln1118_1218_fu_92238_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1218_fu_92238_p0.read()) * sc_bigint<5>(mul_ln1118_1218_fu_92238_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1219_fu_66936_p0() {
    mul_ln1118_1219_fu_66936_p0 =  (sc_lv<3>) (sext_ln1116_19_fu_43575_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1219_fu_66936_p1() {
    mul_ln1118_1219_fu_66936_p1 = tmp_1219_reg_110726.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1219_fu_66936_p2() {
    mul_ln1118_1219_fu_66936_p2 = (!mul_ln1118_1219_fu_66936_p0.read().is_01() || !mul_ln1118_1219_fu_66936_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1219_fu_66936_p0.read()) * sc_bigint<5>(mul_ln1118_1219_fu_66936_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_121_fu_45612_p0() {
    mul_ln1118_121_fu_45612_p0 =  (sc_lv<3>) (sext_ln1116_121_fu_45606_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_121_fu_45612_p1() {
    mul_ln1118_121_fu_45612_p1 = tmp_121_reg_104800.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_121_fu_45612_p2() {
    mul_ln1118_121_fu_45612_p2 = (!mul_ln1118_121_fu_45612_p0.read().is_01() || !mul_ln1118_121_fu_45612_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_121_fu_45612_p0.read()) * sc_bigint<5>(mul_ln1118_121_fu_45612_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1220_fu_66957_p0() {
    mul_ln1118_1220_fu_66957_p0 =  (sc_lv<3>) (sext_ln1116_20_fu_43599_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1220_fu_66957_p1() {
    mul_ln1118_1220_fu_66957_p1 = tmp_1220_reg_110731.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1220_fu_66957_p2() {
    mul_ln1118_1220_fu_66957_p2 = (!mul_ln1118_1220_fu_66957_p0.read().is_01() || !mul_ln1118_1220_fu_66957_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1220_fu_66957_p0.read()) * sc_bigint<5>(mul_ln1118_1220_fu_66957_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1221_fu_66978_p0() {
    mul_ln1118_1221_fu_66978_p0 =  (sc_lv<3>) (sext_ln1116_21_fu_43623_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1221_fu_66978_p1() {
    mul_ln1118_1221_fu_66978_p1 = tmp_1221_reg_110736.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1221_fu_66978_p2() {
    mul_ln1118_1221_fu_66978_p2 = (!mul_ln1118_1221_fu_66978_p0.read().is_01() || !mul_ln1118_1221_fu_66978_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1221_fu_66978_p0.read()) * sc_bigint<5>(mul_ln1118_1221_fu_66978_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1222_fu_66987_p0() {
    mul_ln1118_1222_fu_66987_p0 =  (sc_lv<3>) (sext_ln1116_22_fu_43635_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1222_fu_66987_p1() {
    mul_ln1118_1222_fu_66987_p1 = tmp_1222_reg_110741.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1222_fu_66987_p2() {
    mul_ln1118_1222_fu_66987_p2 = (!mul_ln1118_1222_fu_66987_p0.read().is_01() || !mul_ln1118_1222_fu_66987_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1222_fu_66987_p0.read()) * sc_bigint<5>(mul_ln1118_1222_fu_66987_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1223_fu_67008_p0() {
    mul_ln1118_1223_fu_67008_p0 =  (sc_lv<3>) (sext_ln1116_23_fu_43659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1223_fu_67008_p1() {
    mul_ln1118_1223_fu_67008_p1 = tmp_1223_reg_110746.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1223_fu_67008_p2() {
    mul_ln1118_1223_fu_67008_p2 = (!mul_ln1118_1223_fu_67008_p0.read().is_01() || !mul_ln1118_1223_fu_67008_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1223_fu_67008_p0.read()) * sc_bigint<5>(mul_ln1118_1223_fu_67008_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1224_fu_67029_p0() {
    mul_ln1118_1224_fu_67029_p0 =  (sc_lv<3>) (sext_ln1116_24_fu_43683_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1224_fu_67029_p1() {
    mul_ln1118_1224_fu_67029_p1 = tmp_1224_reg_110751.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1224_fu_67029_p2() {
    mul_ln1118_1224_fu_67029_p2 = (!mul_ln1118_1224_fu_67029_p0.read().is_01() || !mul_ln1118_1224_fu_67029_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1224_fu_67029_p0.read()) * sc_bigint<5>(mul_ln1118_1224_fu_67029_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1225_fu_67038_p0() {
    mul_ln1118_1225_fu_67038_p0 =  (sc_lv<3>) (sext_ln1116_25_fu_43695_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1225_fu_67038_p1() {
    mul_ln1118_1225_fu_67038_p1 = tmp_1225_reg_110756.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1225_fu_67038_p2() {
    mul_ln1118_1225_fu_67038_p2 = (!mul_ln1118_1225_fu_67038_p0.read().is_01() || !mul_ln1118_1225_fu_67038_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1225_fu_67038_p0.read()) * sc_bigint<5>(mul_ln1118_1225_fu_67038_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1226_fu_67059_p0() {
    mul_ln1118_1226_fu_67059_p0 =  (sc_lv<3>) (sext_ln1116_26_fu_43719_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1226_fu_67059_p1() {
    mul_ln1118_1226_fu_67059_p1 = tmp_1226_reg_110761.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1226_fu_67059_p2() {
    mul_ln1118_1226_fu_67059_p2 = (!mul_ln1118_1226_fu_67059_p0.read().is_01() || !mul_ln1118_1226_fu_67059_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1226_fu_67059_p0.read()) * sc_bigint<5>(mul_ln1118_1226_fu_67059_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1227_fu_67080_p0() {
    mul_ln1118_1227_fu_67080_p0 =  (sc_lv<3>) (sext_ln1116_27_fu_43743_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1227_fu_67080_p1() {
    mul_ln1118_1227_fu_67080_p1 = tmp_1227_reg_110766.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1227_fu_67080_p2() {
    mul_ln1118_1227_fu_67080_p2 = (!mul_ln1118_1227_fu_67080_p0.read().is_01() || !mul_ln1118_1227_fu_67080_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1227_fu_67080_p0.read()) * sc_bigint<5>(mul_ln1118_1227_fu_67080_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1228_fu_67089_p0() {
    mul_ln1118_1228_fu_67089_p0 =  (sc_lv<3>) (sext_ln1116_28_fu_43755_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1228_fu_67089_p1() {
    mul_ln1118_1228_fu_67089_p1 = tmp_1228_reg_110771.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1228_fu_67089_p2() {
    mul_ln1118_1228_fu_67089_p2 = (!mul_ln1118_1228_fu_67089_p0.read().is_01() || !mul_ln1118_1228_fu_67089_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1228_fu_67089_p0.read()) * sc_bigint<5>(mul_ln1118_1228_fu_67089_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1229_fu_67110_p0() {
    mul_ln1118_1229_fu_67110_p0 =  (sc_lv<3>) (sext_ln1116_29_fu_43779_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1229_fu_67110_p1() {
    mul_ln1118_1229_fu_67110_p1 = tmp_1229_reg_110776.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1229_fu_67110_p2() {
    mul_ln1118_1229_fu_67110_p2 = (!mul_ln1118_1229_fu_67110_p0.read().is_01() || !mul_ln1118_1229_fu_67110_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1229_fu_67110_p0.read()) * sc_bigint<5>(mul_ln1118_1229_fu_67110_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_122_fu_45624_p0() {
    mul_ln1118_122_fu_45624_p0 =  (sc_lv<3>) (sext_ln1116_122_fu_45618_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_122_fu_45624_p1() {
    mul_ln1118_122_fu_45624_p1 = tmp_122_reg_104810.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_122_fu_45624_p2() {
    mul_ln1118_122_fu_45624_p2 = (!mul_ln1118_122_fu_45624_p0.read().is_01() || !mul_ln1118_122_fu_45624_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_122_fu_45624_p0.read()) * sc_bigint<5>(mul_ln1118_122_fu_45624_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1230_fu_67131_p0() {
    mul_ln1118_1230_fu_67131_p0 =  (sc_lv<3>) (sext_ln1116_30_fu_43803_p1.read());
}

}

