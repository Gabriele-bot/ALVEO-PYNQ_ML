#include "dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1231_fu_41225_p1() {
    mul_ln1118_1231_fu_41225_p1 = tmp_1231_fu_41211_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1231_fu_41225_p2() {
    mul_ln1118_1231_fu_41225_p2 = (!mul_ln1118_1231_fu_41225_p0.read().is_01() || !mul_ln1118_1231_fu_41225_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1231_fu_41225_p0.read()) * sc_bigint<5>(mul_ln1118_1231_fu_41225_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1232_fu_41255_p0() {
    mul_ln1118_1232_fu_41255_p0 =  (sc_lv<12>) (sext_ln1116_32_cast_fu_22367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1232_fu_41255_p1() {
    mul_ln1118_1232_fu_41255_p1 = tmp_1232_fu_41241_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1232_fu_41255_p2() {
    mul_ln1118_1232_fu_41255_p2 = (!mul_ln1118_1232_fu_41255_p0.read().is_01() || !mul_ln1118_1232_fu_41255_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1232_fu_41255_p0.read()) * sc_bigint<5>(mul_ln1118_1232_fu_41255_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1233_fu_41285_p0() {
    mul_ln1118_1233_fu_41285_p0 =  (sc_lv<12>) (sext_ln1116_33_cast_fu_22409_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1233_fu_41285_p1() {
    mul_ln1118_1233_fu_41285_p1 = tmp_1233_fu_41271_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1233_fu_41285_p2() {
    mul_ln1118_1233_fu_41285_p2 = (!mul_ln1118_1233_fu_41285_p0.read().is_01() || !mul_ln1118_1233_fu_41285_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1233_fu_41285_p0.read()) * sc_bigint<5>(mul_ln1118_1233_fu_41285_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1234_fu_76994_p0() {
    mul_ln1118_1234_fu_76994_p0 =  (sc_lv<12>) (sext_ln1116_34_cast_fu_52949_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1234_fu_76994_p1() {
    mul_ln1118_1234_fu_76994_p1 = tmp_1234_reg_102727.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1234_fu_76994_p2() {
    mul_ln1118_1234_fu_76994_p2 = (!mul_ln1118_1234_fu_76994_p0.read().is_01() || !mul_ln1118_1234_fu_76994_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1234_fu_76994_p0.read()) * sc_bigint<5>(mul_ln1118_1234_fu_76994_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1235_fu_77013_p0() {
    mul_ln1118_1235_fu_77013_p0 =  (sc_lv<12>) (sext_ln1116_35_cast_fu_52971_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1235_fu_77013_p1() {
    mul_ln1118_1235_fu_77013_p1 = tmp_1235_reg_102732.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1235_fu_77013_p2() {
    mul_ln1118_1235_fu_77013_p2 = (!mul_ln1118_1235_fu_77013_p0.read().is_01() || !mul_ln1118_1235_fu_77013_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1235_fu_77013_p0.read()) * sc_bigint<5>(mul_ln1118_1235_fu_77013_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1236_fu_77032_p0() {
    mul_ln1118_1236_fu_77032_p0 =  (sc_lv<12>) (sext_ln1116_36_cast_fu_52993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1236_fu_77032_p1() {
    mul_ln1118_1236_fu_77032_p1 = tmp_1236_reg_102737.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1236_fu_77032_p2() {
    mul_ln1118_1236_fu_77032_p2 = (!mul_ln1118_1236_fu_77032_p0.read().is_01() || !mul_ln1118_1236_fu_77032_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1236_fu_77032_p0.read()) * sc_bigint<5>(mul_ln1118_1236_fu_77032_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1237_fu_77051_p0() {
    mul_ln1118_1237_fu_77051_p0 =  (sc_lv<12>) (sext_ln1116_37_cast_fu_53015_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1237_fu_77051_p1() {
    mul_ln1118_1237_fu_77051_p1 = tmp_1237_reg_102742.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1237_fu_77051_p2() {
    mul_ln1118_1237_fu_77051_p2 = (!mul_ln1118_1237_fu_77051_p0.read().is_01() || !mul_ln1118_1237_fu_77051_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1237_fu_77051_p0.read()) * sc_bigint<5>(mul_ln1118_1237_fu_77051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1238_fu_77070_p0() {
    mul_ln1118_1238_fu_77070_p0 =  (sc_lv<12>) (sext_ln1116_38_cast_fu_53037_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1238_fu_77070_p1() {
    mul_ln1118_1238_fu_77070_p1 = tmp_1238_reg_102747.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1238_fu_77070_p2() {
    mul_ln1118_1238_fu_77070_p2 = (!mul_ln1118_1238_fu_77070_p0.read().is_01() || !mul_ln1118_1238_fu_77070_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1238_fu_77070_p0.read()) * sc_bigint<5>(mul_ln1118_1238_fu_77070_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1239_fu_77089_p0() {
    mul_ln1118_1239_fu_77089_p0 =  (sc_lv<12>) (sext_ln1116_39_cast_fu_53059_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1239_fu_77089_p1() {
    mul_ln1118_1239_fu_77089_p1 = tmp_1239_reg_102752.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1239_fu_77089_p2() {
    mul_ln1118_1239_fu_77089_p2 = (!mul_ln1118_1239_fu_77089_p0.read().is_01() || !mul_ln1118_1239_fu_77089_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1239_fu_77089_p0.read()) * sc_bigint<5>(mul_ln1118_1239_fu_77089_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_123_fu_54505_p0() {
    mul_ln1118_123_fu_54505_p0 =  (sc_lv<12>) (sext_ln1116_123_cast_fu_54499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_123_fu_54505_p1() {
    mul_ln1118_123_fu_54505_p1 = tmp_123_reg_96794.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_123_fu_54505_p2() {
    mul_ln1118_123_fu_54505_p2 = (!mul_ln1118_123_fu_54505_p0.read().is_01() || !mul_ln1118_123_fu_54505_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_123_fu_54505_p0.read()) * sc_bigint<5>(mul_ln1118_123_fu_54505_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1240_fu_77108_p0() {
    mul_ln1118_1240_fu_77108_p0 =  (sc_lv<12>) (sext_ln1116_40_cast_fu_53081_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1240_fu_77108_p1() {
    mul_ln1118_1240_fu_77108_p1 = tmp_1240_reg_102757.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1240_fu_77108_p2() {
    mul_ln1118_1240_fu_77108_p2 = (!mul_ln1118_1240_fu_77108_p0.read().is_01() || !mul_ln1118_1240_fu_77108_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1240_fu_77108_p0.read()) * sc_bigint<5>(mul_ln1118_1240_fu_77108_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1241_fu_77127_p0() {
    mul_ln1118_1241_fu_77127_p0 =  (sc_lv<12>) (sext_ln1116_41_cast_fu_53103_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1241_fu_77127_p1() {
    mul_ln1118_1241_fu_77127_p1 = tmp_1241_reg_102762.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1241_fu_77127_p2() {
    mul_ln1118_1241_fu_77127_p2 = (!mul_ln1118_1241_fu_77127_p0.read().is_01() || !mul_ln1118_1241_fu_77127_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1241_fu_77127_p0.read()) * sc_bigint<5>(mul_ln1118_1241_fu_77127_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1242_fu_77146_p0() {
    mul_ln1118_1242_fu_77146_p0 =  (sc_lv<12>) (sext_ln1116_42_cast_fu_53125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1242_fu_77146_p1() {
    mul_ln1118_1242_fu_77146_p1 = tmp_1242_reg_102767.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1242_fu_77146_p2() {
    mul_ln1118_1242_fu_77146_p2 = (!mul_ln1118_1242_fu_77146_p0.read().is_01() || !mul_ln1118_1242_fu_77146_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1242_fu_77146_p0.read()) * sc_bigint<5>(mul_ln1118_1242_fu_77146_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1243_fu_77165_p0() {
    mul_ln1118_1243_fu_77165_p0 =  (sc_lv<12>) (sext_ln1116_43_cast_fu_53147_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1243_fu_77165_p1() {
    mul_ln1118_1243_fu_77165_p1 = tmp_1243_reg_102772.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1243_fu_77165_p2() {
    mul_ln1118_1243_fu_77165_p2 = (!mul_ln1118_1243_fu_77165_p0.read().is_01() || !mul_ln1118_1243_fu_77165_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1243_fu_77165_p0.read()) * sc_bigint<5>(mul_ln1118_1243_fu_77165_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1244_fu_77184_p0() {
    mul_ln1118_1244_fu_77184_p0 =  (sc_lv<12>) (sext_ln1116_44_cast_fu_53169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1244_fu_77184_p1() {
    mul_ln1118_1244_fu_77184_p1 = tmp_1244_reg_102777.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1244_fu_77184_p2() {
    mul_ln1118_1244_fu_77184_p2 = (!mul_ln1118_1244_fu_77184_p0.read().is_01() || !mul_ln1118_1244_fu_77184_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1244_fu_77184_p0.read()) * sc_bigint<5>(mul_ln1118_1244_fu_77184_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1245_fu_77203_p0() {
    mul_ln1118_1245_fu_77203_p0 =  (sc_lv<12>) (sext_ln1116_45_cast_fu_53191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1245_fu_77203_p1() {
    mul_ln1118_1245_fu_77203_p1 = tmp_1245_reg_102782.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1245_fu_77203_p2() {
    mul_ln1118_1245_fu_77203_p2 = (!mul_ln1118_1245_fu_77203_p0.read().is_01() || !mul_ln1118_1245_fu_77203_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1245_fu_77203_p0.read()) * sc_bigint<5>(mul_ln1118_1245_fu_77203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1246_fu_77222_p0() {
    mul_ln1118_1246_fu_77222_p0 =  (sc_lv<12>) (sext_ln1116_46_cast_fu_53213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1246_fu_77222_p1() {
    mul_ln1118_1246_fu_77222_p1 = tmp_1246_reg_102787.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1246_fu_77222_p2() {
    mul_ln1118_1246_fu_77222_p2 = (!mul_ln1118_1246_fu_77222_p0.read().is_01() || !mul_ln1118_1246_fu_77222_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1246_fu_77222_p0.read()) * sc_bigint<5>(mul_ln1118_1246_fu_77222_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1247_fu_77241_p0() {
    mul_ln1118_1247_fu_77241_p0 =  (sc_lv<12>) (sext_ln1116_47_cast_fu_53235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1247_fu_77241_p1() {
    mul_ln1118_1247_fu_77241_p1 = tmp_1247_reg_102792.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1247_fu_77241_p2() {
    mul_ln1118_1247_fu_77241_p2 = (!mul_ln1118_1247_fu_77241_p0.read().is_01() || !mul_ln1118_1247_fu_77241_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1247_fu_77241_p0.read()) * sc_bigint<5>(mul_ln1118_1247_fu_77241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1248_fu_77260_p0() {
    mul_ln1118_1248_fu_77260_p0 =  (sc_lv<12>) (sext_ln1116_48_cast_fu_53257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1248_fu_77260_p1() {
    mul_ln1118_1248_fu_77260_p1 = tmp_1248_reg_102797.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1248_fu_77260_p2() {
    mul_ln1118_1248_fu_77260_p2 = (!mul_ln1118_1248_fu_77260_p0.read().is_01() || !mul_ln1118_1248_fu_77260_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1248_fu_77260_p0.read()) * sc_bigint<5>(mul_ln1118_1248_fu_77260_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1249_fu_77279_p0() {
    mul_ln1118_1249_fu_77279_p0 =  (sc_lv<12>) (sext_ln1116_49_cast_fu_53279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1249_fu_77279_p1() {
    mul_ln1118_1249_fu_77279_p1 = tmp_1249_reg_102802.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1249_fu_77279_p2() {
    mul_ln1118_1249_fu_77279_p2 = (!mul_ln1118_1249_fu_77279_p0.read().is_01() || !mul_ln1118_1249_fu_77279_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1249_fu_77279_p0.read()) * sc_bigint<5>(mul_ln1118_1249_fu_77279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_124_fu_54527_p0() {
    mul_ln1118_124_fu_54527_p0 =  (sc_lv<12>) (sext_ln1116_124_cast_fu_54521_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_124_fu_54527_p1() {
    mul_ln1118_124_fu_54527_p1 = tmp_124_reg_96804.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_124_fu_54527_p2() {
    mul_ln1118_124_fu_54527_p2 = (!mul_ln1118_124_fu_54527_p0.read().is_01() || !mul_ln1118_124_fu_54527_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_124_fu_54527_p0.read()) * sc_bigint<5>(mul_ln1118_124_fu_54527_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1250_fu_77298_p0() {
    mul_ln1118_1250_fu_77298_p0 =  (sc_lv<12>) (sext_ln1116_50_cast_fu_53301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1250_fu_77298_p1() {
    mul_ln1118_1250_fu_77298_p1 = tmp_1250_reg_102807.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1250_fu_77298_p2() {
    mul_ln1118_1250_fu_77298_p2 = (!mul_ln1118_1250_fu_77298_p0.read().is_01() || !mul_ln1118_1250_fu_77298_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1250_fu_77298_p0.read()) * sc_bigint<5>(mul_ln1118_1250_fu_77298_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1251_fu_77317_p0() {
    mul_ln1118_1251_fu_77317_p0 =  (sc_lv<12>) (sext_ln1116_51_cast_fu_53323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1251_fu_77317_p1() {
    mul_ln1118_1251_fu_77317_p1 = tmp_1251_reg_102812.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1251_fu_77317_p2() {
    mul_ln1118_1251_fu_77317_p2 = (!mul_ln1118_1251_fu_77317_p0.read().is_01() || !mul_ln1118_1251_fu_77317_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1251_fu_77317_p0.read()) * sc_bigint<5>(mul_ln1118_1251_fu_77317_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1252_fu_77336_p0() {
    mul_ln1118_1252_fu_77336_p0 =  (sc_lv<12>) (sext_ln1116_52_cast_reg_96150.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1252_fu_77336_p1() {
    mul_ln1118_1252_fu_77336_p1 = tmp_1252_reg_102817.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1252_fu_77336_p2() {
    mul_ln1118_1252_fu_77336_p2 = (!mul_ln1118_1252_fu_77336_p0.read().is_01() || !mul_ln1118_1252_fu_77336_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1252_fu_77336_p0.read()) * sc_bigint<5>(mul_ln1118_1252_fu_77336_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1253_fu_41505_p0() {
    mul_ln1118_1253_fu_41505_p0 =  (sc_lv<12>) (sext_ln1116_53_cast_fu_22797_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1253_fu_41505_p1() {
    mul_ln1118_1253_fu_41505_p1 = tmp_1253_fu_41491_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1253_fu_41505_p2() {
    mul_ln1118_1253_fu_41505_p2 = (!mul_ln1118_1253_fu_41505_p0.read().is_01() || !mul_ln1118_1253_fu_41505_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1253_fu_41505_p0.read()) * sc_bigint<5>(mul_ln1118_1253_fu_41505_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1254_fu_41535_p0() {
    mul_ln1118_1254_fu_41535_p0 =  (sc_lv<12>) (sext_ln1116_54_cast_fu_22839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1254_fu_41535_p1() {
    mul_ln1118_1254_fu_41535_p1 = tmp_1254_fu_41521_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1254_fu_41535_p2() {
    mul_ln1118_1254_fu_41535_p2 = (!mul_ln1118_1254_fu_41535_p0.read().is_01() || !mul_ln1118_1254_fu_41535_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1254_fu_41535_p0.read()) * sc_bigint<5>(mul_ln1118_1254_fu_41535_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1255_fu_41565_p0() {
    mul_ln1118_1255_fu_41565_p0 =  (sc_lv<12>) (sext_ln1116_55_cast_fu_22881_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1255_fu_41565_p1() {
    mul_ln1118_1255_fu_41565_p1 = tmp_1255_fu_41551_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1255_fu_41565_p2() {
    mul_ln1118_1255_fu_41565_p2 = (!mul_ln1118_1255_fu_41565_p0.read().is_01() || !mul_ln1118_1255_fu_41565_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1255_fu_41565_p0.read()) * sc_bigint<5>(mul_ln1118_1255_fu_41565_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1256_fu_41595_p0() {
    mul_ln1118_1256_fu_41595_p0 =  (sc_lv<12>) (sext_ln1116_56_cast_fu_22923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1256_fu_41595_p1() {
    mul_ln1118_1256_fu_41595_p1 = tmp_1256_fu_41581_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1256_fu_41595_p2() {
    mul_ln1118_1256_fu_41595_p2 = (!mul_ln1118_1256_fu_41595_p0.read().is_01() || !mul_ln1118_1256_fu_41595_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1256_fu_41595_p0.read()) * sc_bigint<5>(mul_ln1118_1256_fu_41595_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1257_fu_41625_p0() {
    mul_ln1118_1257_fu_41625_p0 =  (sc_lv<12>) (sext_ln1116_57_cast_fu_22965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1257_fu_41625_p1() {
    mul_ln1118_1257_fu_41625_p1 = tmp_1257_fu_41611_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1257_fu_41625_p2() {
    mul_ln1118_1257_fu_41625_p2 = (!mul_ln1118_1257_fu_41625_p0.read().is_01() || !mul_ln1118_1257_fu_41625_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1257_fu_41625_p0.read()) * sc_bigint<5>(mul_ln1118_1257_fu_41625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1258_fu_41655_p0() {
    mul_ln1118_1258_fu_41655_p0 =  (sc_lv<12>) (sext_ln1116_58_cast_fu_23007_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1258_fu_41655_p1() {
    mul_ln1118_1258_fu_41655_p1 = tmp_1258_fu_41641_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1258_fu_41655_p2() {
    mul_ln1118_1258_fu_41655_p2 = (!mul_ln1118_1258_fu_41655_p0.read().is_01() || !mul_ln1118_1258_fu_41655_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1258_fu_41655_p0.read()) * sc_bigint<5>(mul_ln1118_1258_fu_41655_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1259_fu_77354_p0() {
    mul_ln1118_1259_fu_77354_p0 =  (sc_lv<12>) (sext_ln1116_59_cast_fu_53363_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1259_fu_77354_p1() {
    mul_ln1118_1259_fu_77354_p1 = tmp_1259_reg_102852.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1259_fu_77354_p2() {
    mul_ln1118_1259_fu_77354_p2 = (!mul_ln1118_1259_fu_77354_p0.read().is_01() || !mul_ln1118_1259_fu_77354_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1259_fu_77354_p0.read()) * sc_bigint<5>(mul_ln1118_1259_fu_77354_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_125_fu_54549_p0() {
    mul_ln1118_125_fu_54549_p0 =  (sc_lv<12>) (sext_ln1116_125_cast_fu_54543_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_125_fu_54549_p1() {
    mul_ln1118_125_fu_54549_p1 = tmp_125_reg_96814.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_125_fu_54549_p2() {
    mul_ln1118_125_fu_54549_p2 = (!mul_ln1118_125_fu_54549_p0.read().is_01() || !mul_ln1118_125_fu_54549_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_125_fu_54549_p0.read()) * sc_bigint<5>(mul_ln1118_125_fu_54549_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1260_fu_77373_p0() {
    mul_ln1118_1260_fu_77373_p0 =  (sc_lv<12>) (sext_ln1116_60_cast_fu_53385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1260_fu_77373_p1() {
    mul_ln1118_1260_fu_77373_p1 = tmp_1260_reg_102857.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1260_fu_77373_p2() {
    mul_ln1118_1260_fu_77373_p2 = (!mul_ln1118_1260_fu_77373_p0.read().is_01() || !mul_ln1118_1260_fu_77373_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1260_fu_77373_p0.read()) * sc_bigint<5>(mul_ln1118_1260_fu_77373_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1261_fu_77392_p0() {
    mul_ln1118_1261_fu_77392_p0 =  (sc_lv<12>) (sext_ln1116_61_cast_fu_53407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1261_fu_77392_p1() {
    mul_ln1118_1261_fu_77392_p1 = tmp_1261_reg_102862.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1261_fu_77392_p2() {
    mul_ln1118_1261_fu_77392_p2 = (!mul_ln1118_1261_fu_77392_p0.read().is_01() || !mul_ln1118_1261_fu_77392_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1261_fu_77392_p0.read()) * sc_bigint<5>(mul_ln1118_1261_fu_77392_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1262_fu_77411_p0() {
    mul_ln1118_1262_fu_77411_p0 =  (sc_lv<12>) (sext_ln1116_62_cast_fu_53429_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1262_fu_77411_p1() {
    mul_ln1118_1262_fu_77411_p1 = tmp_1262_reg_102867.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1262_fu_77411_p2() {
    mul_ln1118_1262_fu_77411_p2 = (!mul_ln1118_1262_fu_77411_p0.read().is_01() || !mul_ln1118_1262_fu_77411_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1262_fu_77411_p0.read()) * sc_bigint<5>(mul_ln1118_1262_fu_77411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1263_fu_77430_p0() {
    mul_ln1118_1263_fu_77430_p0 =  (sc_lv<12>) (sext_ln1116_63_cast_fu_53451_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1263_fu_77430_p1() {
    mul_ln1118_1263_fu_77430_p1 = tmp_1263_reg_102872.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1263_fu_77430_p2() {
    mul_ln1118_1263_fu_77430_p2 = (!mul_ln1118_1263_fu_77430_p0.read().is_01() || !mul_ln1118_1263_fu_77430_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1263_fu_77430_p0.read()) * sc_bigint<5>(mul_ln1118_1263_fu_77430_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1264_fu_77449_p0() {
    mul_ln1118_1264_fu_77449_p0 =  (sc_lv<12>) (sext_ln1116_64_cast_fu_53473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1264_fu_77449_p1() {
    mul_ln1118_1264_fu_77449_p1 = tmp_1264_reg_102877.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1264_fu_77449_p2() {
    mul_ln1118_1264_fu_77449_p2 = (!mul_ln1118_1264_fu_77449_p0.read().is_01() || !mul_ln1118_1264_fu_77449_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1264_fu_77449_p0.read()) * sc_bigint<5>(mul_ln1118_1264_fu_77449_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1265_fu_77468_p0() {
    mul_ln1118_1265_fu_77468_p0 =  (sc_lv<12>) (sext_ln1116_65_cast_fu_53495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1265_fu_77468_p1() {
    mul_ln1118_1265_fu_77468_p1 = tmp_1265_reg_102882.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1265_fu_77468_p2() {
    mul_ln1118_1265_fu_77468_p2 = (!mul_ln1118_1265_fu_77468_p0.read().is_01() || !mul_ln1118_1265_fu_77468_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1265_fu_77468_p0.read()) * sc_bigint<5>(mul_ln1118_1265_fu_77468_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1266_fu_77487_p0() {
    mul_ln1118_1266_fu_77487_p0 =  (sc_lv<12>) (sext_ln1116_66_cast_fu_53517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1266_fu_77487_p1() {
    mul_ln1118_1266_fu_77487_p1 = tmp_1266_reg_102887.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1266_fu_77487_p2() {
    mul_ln1118_1266_fu_77487_p2 = (!mul_ln1118_1266_fu_77487_p0.read().is_01() || !mul_ln1118_1266_fu_77487_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1266_fu_77487_p0.read()) * sc_bigint<5>(mul_ln1118_1266_fu_77487_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1267_fu_77506_p0() {
    mul_ln1118_1267_fu_77506_p0 =  (sc_lv<12>) (sext_ln1116_67_cast_fu_53539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1267_fu_77506_p1() {
    mul_ln1118_1267_fu_77506_p1 = tmp_1267_reg_102892.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1267_fu_77506_p2() {
    mul_ln1118_1267_fu_77506_p2 = (!mul_ln1118_1267_fu_77506_p0.read().is_01() || !mul_ln1118_1267_fu_77506_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1267_fu_77506_p0.read()) * sc_bigint<5>(mul_ln1118_1267_fu_77506_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1268_fu_77525_p0() {
    mul_ln1118_1268_fu_77525_p0 =  (sc_lv<12>) (sext_ln1116_68_cast_fu_53561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1268_fu_77525_p1() {
    mul_ln1118_1268_fu_77525_p1 = tmp_1268_reg_102897.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1268_fu_77525_p2() {
    mul_ln1118_1268_fu_77525_p2 = (!mul_ln1118_1268_fu_77525_p0.read().is_01() || !mul_ln1118_1268_fu_77525_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1268_fu_77525_p0.read()) * sc_bigint<5>(mul_ln1118_1268_fu_77525_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1269_fu_77544_p0() {
    mul_ln1118_1269_fu_77544_p0 =  (sc_lv<12>) (sext_ln1116_69_cast_fu_53583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1269_fu_77544_p1() {
    mul_ln1118_1269_fu_77544_p1 = tmp_1269_reg_102902.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1269_fu_77544_p2() {
    mul_ln1118_1269_fu_77544_p2 = (!mul_ln1118_1269_fu_77544_p0.read().is_01() || !mul_ln1118_1269_fu_77544_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1269_fu_77544_p0.read()) * sc_bigint<5>(mul_ln1118_1269_fu_77544_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_126_fu_54571_p0() {
    mul_ln1118_126_fu_54571_p0 =  (sc_lv<12>) (sext_ln1116_126_cast_fu_54565_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_126_fu_54571_p1() {
    mul_ln1118_126_fu_54571_p1 = tmp_126_reg_96824.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_126_fu_54571_p2() {
    mul_ln1118_126_fu_54571_p2 = (!mul_ln1118_126_fu_54571_p0.read().is_01() || !mul_ln1118_126_fu_54571_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_126_fu_54571_p0.read()) * sc_bigint<5>(mul_ln1118_126_fu_54571_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1270_fu_77563_p0() {
    mul_ln1118_1270_fu_77563_p0 =  (sc_lv<12>) (sext_ln1116_70_cast_fu_53605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1270_fu_77563_p1() {
    mul_ln1118_1270_fu_77563_p1 = tmp_1270_reg_102907.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1270_fu_77563_p2() {
    mul_ln1118_1270_fu_77563_p2 = (!mul_ln1118_1270_fu_77563_p0.read().is_01() || !mul_ln1118_1270_fu_77563_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1270_fu_77563_p0.read()) * sc_bigint<5>(mul_ln1118_1270_fu_77563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1271_fu_77582_p0() {
    mul_ln1118_1271_fu_77582_p0 =  (sc_lv<12>) (sext_ln1116_71_cast_fu_53627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1271_fu_77582_p1() {
    mul_ln1118_1271_fu_77582_p1 = tmp_1271_reg_102912.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1271_fu_77582_p2() {
    mul_ln1118_1271_fu_77582_p2 = (!mul_ln1118_1271_fu_77582_p0.read().is_01() || !mul_ln1118_1271_fu_77582_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1271_fu_77582_p0.read()) * sc_bigint<5>(mul_ln1118_1271_fu_77582_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1272_fu_77601_p0() {
    mul_ln1118_1272_fu_77601_p0 =  (sc_lv<12>) (sext_ln1116_72_cast_fu_53649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1272_fu_77601_p1() {
    mul_ln1118_1272_fu_77601_p1 = tmp_1272_reg_102917.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1272_fu_77601_p2() {
    mul_ln1118_1272_fu_77601_p2 = (!mul_ln1118_1272_fu_77601_p0.read().is_01() || !mul_ln1118_1272_fu_77601_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1272_fu_77601_p0.read()) * sc_bigint<5>(mul_ln1118_1272_fu_77601_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1273_fu_77620_p0() {
    mul_ln1118_1273_fu_77620_p0 =  (sc_lv<12>) (sext_ln1116_73_cast_fu_53671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1273_fu_77620_p1() {
    mul_ln1118_1273_fu_77620_p1 = tmp_1273_reg_102922.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1273_fu_77620_p2() {
    mul_ln1118_1273_fu_77620_p2 = (!mul_ln1118_1273_fu_77620_p0.read().is_01() || !mul_ln1118_1273_fu_77620_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1273_fu_77620_p0.read()) * sc_bigint<5>(mul_ln1118_1273_fu_77620_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1274_fu_77639_p0() {
    mul_ln1118_1274_fu_77639_p0 =  (sc_lv<12>) (sext_ln1116_74_cast_fu_53693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1274_fu_77639_p1() {
    mul_ln1118_1274_fu_77639_p1 = tmp_1274_reg_102927.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1274_fu_77639_p2() {
    mul_ln1118_1274_fu_77639_p2 = (!mul_ln1118_1274_fu_77639_p0.read().is_01() || !mul_ln1118_1274_fu_77639_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1274_fu_77639_p0.read()) * sc_bigint<5>(mul_ln1118_1274_fu_77639_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1275_fu_77658_p0() {
    mul_ln1118_1275_fu_77658_p0 =  (sc_lv<12>) (sext_ln1116_75_cast_fu_53715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1275_fu_77658_p1() {
    mul_ln1118_1275_fu_77658_p1 = tmp_1275_reg_102932.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1275_fu_77658_p2() {
    mul_ln1118_1275_fu_77658_p2 = (!mul_ln1118_1275_fu_77658_p0.read().is_01() || !mul_ln1118_1275_fu_77658_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1275_fu_77658_p0.read()) * sc_bigint<5>(mul_ln1118_1275_fu_77658_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1276_fu_77677_p0() {
    mul_ln1118_1276_fu_77677_p0 =  (sc_lv<12>) (sext_ln1116_76_cast_fu_53737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1276_fu_77677_p1() {
    mul_ln1118_1276_fu_77677_p1 = tmp_1276_reg_102937.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1276_fu_77677_p2() {
    mul_ln1118_1276_fu_77677_p2 = (!mul_ln1118_1276_fu_77677_p0.read().is_01() || !mul_ln1118_1276_fu_77677_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1276_fu_77677_p0.read()) * sc_bigint<5>(mul_ln1118_1276_fu_77677_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1277_fu_77696_p0() {
    mul_ln1118_1277_fu_77696_p0 =  (sc_lv<12>) (sext_ln1116_77_cast_reg_96378.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1277_fu_77696_p1() {
    mul_ln1118_1277_fu_77696_p1 = tmp_1277_reg_102942.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1277_fu_77696_p2() {
    mul_ln1118_1277_fu_77696_p2 = (!mul_ln1118_1277_fu_77696_p0.read().is_01() || !mul_ln1118_1277_fu_77696_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1277_fu_77696_p0.read()) * sc_bigint<5>(mul_ln1118_1277_fu_77696_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1278_fu_41875_p0() {
    mul_ln1118_1278_fu_41875_p0 =  (sc_lv<12>) (sext_ln1116_78_cast_fu_23395_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1278_fu_41875_p1() {
    mul_ln1118_1278_fu_41875_p1 = tmp_1278_fu_41861_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1278_fu_41875_p2() {
    mul_ln1118_1278_fu_41875_p2 = (!mul_ln1118_1278_fu_41875_p0.read().is_01() || !mul_ln1118_1278_fu_41875_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1278_fu_41875_p0.read()) * sc_bigint<5>(mul_ln1118_1278_fu_41875_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1279_fu_41905_p0() {
    mul_ln1118_1279_fu_41905_p0 =  (sc_lv<12>) (sext_ln1116_79_cast_fu_23437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1279_fu_41905_p1() {
    mul_ln1118_1279_fu_41905_p1 = tmp_1279_fu_41891_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1279_fu_41905_p2() {
    mul_ln1118_1279_fu_41905_p2 = (!mul_ln1118_1279_fu_41905_p0.read().is_01() || !mul_ln1118_1279_fu_41905_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1279_fu_41905_p0.read()) * sc_bigint<5>(mul_ln1118_1279_fu_41905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_127_fu_54593_p0() {
    mul_ln1118_127_fu_54593_p0 =  (sc_lv<12>) (sext_ln1116_127_cast_fu_54587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_127_fu_54593_p1() {
    mul_ln1118_127_fu_54593_p1 = tmp_127_reg_96834.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_127_fu_54593_p2() {
    mul_ln1118_127_fu_54593_p2 = (!mul_ln1118_127_fu_54593_p0.read().is_01() || !mul_ln1118_127_fu_54593_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_127_fu_54593_p0.read()) * sc_bigint<5>(mul_ln1118_127_fu_54593_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1280_fu_41935_p0() {
    mul_ln1118_1280_fu_41935_p0 =  (sc_lv<12>) (sext_ln1116_80_cast_fu_23479_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1280_fu_41935_p1() {
    mul_ln1118_1280_fu_41935_p1 = tmp_1280_fu_41921_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1280_fu_41935_p2() {
    mul_ln1118_1280_fu_41935_p2 = (!mul_ln1118_1280_fu_41935_p0.read().is_01() || !mul_ln1118_1280_fu_41935_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1280_fu_41935_p0.read()) * sc_bigint<5>(mul_ln1118_1280_fu_41935_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1281_fu_41965_p0() {
    mul_ln1118_1281_fu_41965_p0 =  (sc_lv<12>) (sext_ln1116_81_cast_fu_23521_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1281_fu_41965_p1() {
    mul_ln1118_1281_fu_41965_p1 = tmp_1281_fu_41951_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1281_fu_41965_p2() {
    mul_ln1118_1281_fu_41965_p2 = (!mul_ln1118_1281_fu_41965_p0.read().is_01() || !mul_ln1118_1281_fu_41965_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1281_fu_41965_p0.read()) * sc_bigint<5>(mul_ln1118_1281_fu_41965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1282_fu_41995_p0() {
    mul_ln1118_1282_fu_41995_p0 =  (sc_lv<12>) (sext_ln1116_82_cast_fu_23563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1282_fu_41995_p1() {
    mul_ln1118_1282_fu_41995_p1 = tmp_1282_fu_41981_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1282_fu_41995_p2() {
    mul_ln1118_1282_fu_41995_p2 = (!mul_ln1118_1282_fu_41995_p0.read().is_01() || !mul_ln1118_1282_fu_41995_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1282_fu_41995_p0.read()) * sc_bigint<5>(mul_ln1118_1282_fu_41995_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1283_fu_42025_p0() {
    mul_ln1118_1283_fu_42025_p0 =  (sc_lv<12>) (sext_ln1116_83_cast_fu_23605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1283_fu_42025_p1() {
    mul_ln1118_1283_fu_42025_p1 = tmp_1283_fu_42011_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1283_fu_42025_p2() {
    mul_ln1118_1283_fu_42025_p2 = (!mul_ln1118_1283_fu_42025_p0.read().is_01() || !mul_ln1118_1283_fu_42025_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1283_fu_42025_p0.read()) * sc_bigint<5>(mul_ln1118_1283_fu_42025_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1284_fu_77714_p0() {
    mul_ln1118_1284_fu_77714_p0 =  (sc_lv<12>) (sext_ln1116_84_cast_fu_53777_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1284_fu_77714_p1() {
    mul_ln1118_1284_fu_77714_p1 = tmp_1284_reg_102977.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1284_fu_77714_p2() {
    mul_ln1118_1284_fu_77714_p2 = (!mul_ln1118_1284_fu_77714_p0.read().is_01() || !mul_ln1118_1284_fu_77714_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1284_fu_77714_p0.read()) * sc_bigint<5>(mul_ln1118_1284_fu_77714_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1285_fu_77733_p0() {
    mul_ln1118_1285_fu_77733_p0 =  (sc_lv<12>) (sext_ln1116_85_cast_fu_53799_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1285_fu_77733_p1() {
    mul_ln1118_1285_fu_77733_p1 = tmp_1285_reg_102982.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1285_fu_77733_p2() {
    mul_ln1118_1285_fu_77733_p2 = (!mul_ln1118_1285_fu_77733_p0.read().is_01() || !mul_ln1118_1285_fu_77733_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1285_fu_77733_p0.read()) * sc_bigint<5>(mul_ln1118_1285_fu_77733_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1286_fu_77752_p0() {
    mul_ln1118_1286_fu_77752_p0 =  (sc_lv<12>) (sext_ln1116_86_cast_fu_53821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1286_fu_77752_p1() {
    mul_ln1118_1286_fu_77752_p1 = tmp_1286_reg_102987.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1286_fu_77752_p2() {
    mul_ln1118_1286_fu_77752_p2 = (!mul_ln1118_1286_fu_77752_p0.read().is_01() || !mul_ln1118_1286_fu_77752_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1286_fu_77752_p0.read()) * sc_bigint<5>(mul_ln1118_1286_fu_77752_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1287_fu_77771_p0() {
    mul_ln1118_1287_fu_77771_p0 =  (sc_lv<12>) (sext_ln1116_87_cast_fu_53843_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1287_fu_77771_p1() {
    mul_ln1118_1287_fu_77771_p1 = tmp_1287_reg_102992.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1287_fu_77771_p2() {
    mul_ln1118_1287_fu_77771_p2 = (!mul_ln1118_1287_fu_77771_p0.read().is_01() || !mul_ln1118_1287_fu_77771_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1287_fu_77771_p0.read()) * sc_bigint<5>(mul_ln1118_1287_fu_77771_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1288_fu_77790_p0() {
    mul_ln1118_1288_fu_77790_p0 =  (sc_lv<12>) (sext_ln1116_88_cast_fu_53865_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1288_fu_77790_p1() {
    mul_ln1118_1288_fu_77790_p1 = tmp_1288_reg_102997.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1288_fu_77790_p2() {
    mul_ln1118_1288_fu_77790_p2 = (!mul_ln1118_1288_fu_77790_p0.read().is_01() || !mul_ln1118_1288_fu_77790_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1288_fu_77790_p0.read()) * sc_bigint<5>(mul_ln1118_1288_fu_77790_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1289_fu_77809_p0() {
    mul_ln1118_1289_fu_77809_p0 =  (sc_lv<12>) (sext_ln1116_89_cast_fu_53887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1289_fu_77809_p1() {
    mul_ln1118_1289_fu_77809_p1 = tmp_1289_reg_103002.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1289_fu_77809_p2() {
    mul_ln1118_1289_fu_77809_p2 = (!mul_ln1118_1289_fu_77809_p0.read().is_01() || !mul_ln1118_1289_fu_77809_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1289_fu_77809_p0.read()) * sc_bigint<5>(mul_ln1118_1289_fu_77809_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_128_fu_54615_p0() {
    mul_ln1118_128_fu_54615_p0 =  (sc_lv<12>) (sext_ln1116_128_cast_fu_54609_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_128_fu_54615_p1() {
    mul_ln1118_128_fu_54615_p1 = tmp_128_reg_96844.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_128_fu_54615_p2() {
    mul_ln1118_128_fu_54615_p2 = (!mul_ln1118_128_fu_54615_p0.read().is_01() || !mul_ln1118_128_fu_54615_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_128_fu_54615_p0.read()) * sc_bigint<5>(mul_ln1118_128_fu_54615_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1290_fu_77828_p0() {
    mul_ln1118_1290_fu_77828_p0 =  (sc_lv<12>) (sext_ln1116_90_cast_fu_53909_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1290_fu_77828_p1() {
    mul_ln1118_1290_fu_77828_p1 = tmp_1290_reg_103007.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1290_fu_77828_p2() {
    mul_ln1118_1290_fu_77828_p2 = (!mul_ln1118_1290_fu_77828_p0.read().is_01() || !mul_ln1118_1290_fu_77828_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1290_fu_77828_p0.read()) * sc_bigint<5>(mul_ln1118_1290_fu_77828_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1291_fu_77847_p0() {
    mul_ln1118_1291_fu_77847_p0 =  (sc_lv<12>) (sext_ln1116_91_cast_fu_53931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1291_fu_77847_p1() {
    mul_ln1118_1291_fu_77847_p1 = tmp_1291_reg_103012.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1291_fu_77847_p2() {
    mul_ln1118_1291_fu_77847_p2 = (!mul_ln1118_1291_fu_77847_p0.read().is_01() || !mul_ln1118_1291_fu_77847_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1291_fu_77847_p0.read()) * sc_bigint<5>(mul_ln1118_1291_fu_77847_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1292_fu_77866_p0() {
    mul_ln1118_1292_fu_77866_p0 =  (sc_lv<12>) (sext_ln1116_92_cast_fu_53953_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1292_fu_77866_p1() {
    mul_ln1118_1292_fu_77866_p1 = tmp_1292_reg_103017.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1292_fu_77866_p2() {
    mul_ln1118_1292_fu_77866_p2 = (!mul_ln1118_1292_fu_77866_p0.read().is_01() || !mul_ln1118_1292_fu_77866_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1292_fu_77866_p0.read()) * sc_bigint<5>(mul_ln1118_1292_fu_77866_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1293_fu_77885_p0() {
    mul_ln1118_1293_fu_77885_p0 =  (sc_lv<12>) (sext_ln1116_93_cast_fu_53975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1293_fu_77885_p1() {
    mul_ln1118_1293_fu_77885_p1 = tmp_1293_reg_103022.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1293_fu_77885_p2() {
    mul_ln1118_1293_fu_77885_p2 = (!mul_ln1118_1293_fu_77885_p0.read().is_01() || !mul_ln1118_1293_fu_77885_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1293_fu_77885_p0.read()) * sc_bigint<5>(mul_ln1118_1293_fu_77885_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1294_fu_77904_p0() {
    mul_ln1118_1294_fu_77904_p0 =  (sc_lv<12>) (sext_ln1116_94_cast_fu_53997_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1294_fu_77904_p1() {
    mul_ln1118_1294_fu_77904_p1 = tmp_1294_reg_103027.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1294_fu_77904_p2() {
    mul_ln1118_1294_fu_77904_p2 = (!mul_ln1118_1294_fu_77904_p0.read().is_01() || !mul_ln1118_1294_fu_77904_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1294_fu_77904_p0.read()) * sc_bigint<5>(mul_ln1118_1294_fu_77904_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1295_fu_77923_p0() {
    mul_ln1118_1295_fu_77923_p0 =  (sc_lv<12>) (sext_ln1116_95_cast_fu_54019_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1295_fu_77923_p1() {
    mul_ln1118_1295_fu_77923_p1 = tmp_1295_reg_103032.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1295_fu_77923_p2() {
    mul_ln1118_1295_fu_77923_p2 = (!mul_ln1118_1295_fu_77923_p0.read().is_01() || !mul_ln1118_1295_fu_77923_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1295_fu_77923_p0.read()) * sc_bigint<5>(mul_ln1118_1295_fu_77923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1296_fu_77942_p0() {
    mul_ln1118_1296_fu_77942_p0 =  (sc_lv<12>) (sext_ln1116_96_cast_fu_54041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1296_fu_77942_p1() {
    mul_ln1118_1296_fu_77942_p1 = tmp_1296_reg_103037.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1296_fu_77942_p2() {
    mul_ln1118_1296_fu_77942_p2 = (!mul_ln1118_1296_fu_77942_p0.read().is_01() || !mul_ln1118_1296_fu_77942_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1296_fu_77942_p0.read()) * sc_bigint<5>(mul_ln1118_1296_fu_77942_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1297_fu_77961_p0() {
    mul_ln1118_1297_fu_77961_p0 =  (sc_lv<12>) (sext_ln1116_97_cast_fu_54063_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1297_fu_77961_p1() {
    mul_ln1118_1297_fu_77961_p1 = tmp_1297_reg_103042.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1297_fu_77961_p2() {
    mul_ln1118_1297_fu_77961_p2 = (!mul_ln1118_1297_fu_77961_p0.read().is_01() || !mul_ln1118_1297_fu_77961_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1297_fu_77961_p0.read()) * sc_bigint<5>(mul_ln1118_1297_fu_77961_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1298_fu_77980_p0() {
    mul_ln1118_1298_fu_77980_p0 =  (sc_lv<12>) (sext_ln1116_98_cast_fu_54085_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1298_fu_77980_p1() {
    mul_ln1118_1298_fu_77980_p1 = tmp_1298_reg_103047.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1298_fu_77980_p2() {
    mul_ln1118_1298_fu_77980_p2 = (!mul_ln1118_1298_fu_77980_p0.read().is_01() || !mul_ln1118_1298_fu_77980_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1298_fu_77980_p0.read()) * sc_bigint<5>(mul_ln1118_1298_fu_77980_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1299_fu_77999_p0() {
    mul_ln1118_1299_fu_77999_p0 =  (sc_lv<12>) (sext_ln1116_99_cast_fu_54107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1299_fu_77999_p1() {
    mul_ln1118_1299_fu_77999_p1 = tmp_1299_reg_103052.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1299_fu_77999_p2() {
    mul_ln1118_1299_fu_77999_p2 = (!mul_ln1118_1299_fu_77999_p0.read().is_01() || !mul_ln1118_1299_fu_77999_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1299_fu_77999_p0.read()) * sc_bigint<5>(mul_ln1118_1299_fu_77999_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_129_fu_54637_p0() {
    mul_ln1118_129_fu_54637_p0 =  (sc_lv<12>) (sext_ln1116_129_cast_fu_54631_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_129_fu_54637_p1() {
    mul_ln1118_129_fu_54637_p1 = tmp_129_reg_96854.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_129_fu_54637_p2() {
    mul_ln1118_129_fu_54637_p2 = (!mul_ln1118_129_fu_54637_p0.read().is_01() || !mul_ln1118_129_fu_54637_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_129_fu_54637_p0.read()) * sc_bigint<5>(mul_ln1118_129_fu_54637_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_12_fu_52603_p0() {
    mul_ln1118_12_fu_52603_p0 =  (sc_lv<12>) (sext_ln1116_12_cast_fu_52597_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_12_fu_52603_p1() {
    mul_ln1118_12_fu_52603_p1 = tmp_13_reg_95780.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_12_fu_52603_p2() {
    mul_ln1118_12_fu_52603_p2 = (!mul_ln1118_12_fu_52603_p0.read().is_01() || !mul_ln1118_12_fu_52603_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_12_fu_52603_p0.read()) * sc_bigint<5>(mul_ln1118_12_fu_52603_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1300_fu_78018_p0() {
    mul_ln1118_1300_fu_78018_p0 =  (sc_lv<12>) (sext_ln1116_100_cast_fu_54129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1300_fu_78018_p1() {
    mul_ln1118_1300_fu_78018_p1 = tmp_1300_reg_103057.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1300_fu_78018_p2() {
    mul_ln1118_1300_fu_78018_p2 = (!mul_ln1118_1300_fu_78018_p0.read().is_01() || !mul_ln1118_1300_fu_78018_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1300_fu_78018_p0.read()) * sc_bigint<5>(mul_ln1118_1300_fu_78018_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1301_fu_78037_p0() {
    mul_ln1118_1301_fu_78037_p0 =  (sc_lv<12>) (sext_ln1116_101_cast_fu_54151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1301_fu_78037_p1() {
    mul_ln1118_1301_fu_78037_p1 = tmp_1301_reg_103062.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1301_fu_78037_p2() {
    mul_ln1118_1301_fu_78037_p2 = (!mul_ln1118_1301_fu_78037_p0.read().is_01() || !mul_ln1118_1301_fu_78037_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1301_fu_78037_p0.read()) * sc_bigint<5>(mul_ln1118_1301_fu_78037_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1302_fu_78056_p0() {
    mul_ln1118_1302_fu_78056_p0 =  (sc_lv<12>) (sext_ln1116_102_cast_reg_96606.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1302_fu_78056_p1() {
    mul_ln1118_1302_fu_78056_p1 = tmp_1302_reg_103067.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1302_fu_78056_p2() {
    mul_ln1118_1302_fu_78056_p2 = (!mul_ln1118_1302_fu_78056_p0.read().is_01() || !mul_ln1118_1302_fu_78056_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1302_fu_78056_p0.read()) * sc_bigint<5>(mul_ln1118_1302_fu_78056_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1303_fu_42245_p0() {
    mul_ln1118_1303_fu_42245_p0 =  (sc_lv<12>) (sext_ln1116_103_cast_fu_23993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1303_fu_42245_p1() {
    mul_ln1118_1303_fu_42245_p1 = tmp_1303_fu_42231_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1303_fu_42245_p2() {
    mul_ln1118_1303_fu_42245_p2 = (!mul_ln1118_1303_fu_42245_p0.read().is_01() || !mul_ln1118_1303_fu_42245_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1303_fu_42245_p0.read()) * sc_bigint<5>(mul_ln1118_1303_fu_42245_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1304_fu_42275_p0() {
    mul_ln1118_1304_fu_42275_p0 =  (sc_lv<12>) (sext_ln1116_104_cast_fu_24035_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1304_fu_42275_p1() {
    mul_ln1118_1304_fu_42275_p1 = tmp_1304_fu_42261_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1304_fu_42275_p2() {
    mul_ln1118_1304_fu_42275_p2 = (!mul_ln1118_1304_fu_42275_p0.read().is_01() || !mul_ln1118_1304_fu_42275_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1304_fu_42275_p0.read()) * sc_bigint<5>(mul_ln1118_1304_fu_42275_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1305_fu_42305_p0() {
    mul_ln1118_1305_fu_42305_p0 =  (sc_lv<12>) (sext_ln1116_105_cast_fu_24077_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1305_fu_42305_p1() {
    mul_ln1118_1305_fu_42305_p1 = tmp_1305_fu_42291_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1305_fu_42305_p2() {
    mul_ln1118_1305_fu_42305_p2 = (!mul_ln1118_1305_fu_42305_p0.read().is_01() || !mul_ln1118_1305_fu_42305_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1305_fu_42305_p0.read()) * sc_bigint<5>(mul_ln1118_1305_fu_42305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1306_fu_42335_p0() {
    mul_ln1118_1306_fu_42335_p0 =  (sc_lv<12>) (sext_ln1116_106_cast_fu_24119_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1306_fu_42335_p1() {
    mul_ln1118_1306_fu_42335_p1 = tmp_1306_fu_42321_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1306_fu_42335_p2() {
    mul_ln1118_1306_fu_42335_p2 = (!mul_ln1118_1306_fu_42335_p0.read().is_01() || !mul_ln1118_1306_fu_42335_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1306_fu_42335_p0.read()) * sc_bigint<5>(mul_ln1118_1306_fu_42335_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1307_fu_42365_p0() {
    mul_ln1118_1307_fu_42365_p0 =  (sc_lv<12>) (sext_ln1116_107_cast_fu_24161_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1307_fu_42365_p1() {
    mul_ln1118_1307_fu_42365_p1 = tmp_1307_fu_42351_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1307_fu_42365_p2() {
    mul_ln1118_1307_fu_42365_p2 = (!mul_ln1118_1307_fu_42365_p0.read().is_01() || !mul_ln1118_1307_fu_42365_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1307_fu_42365_p0.read()) * sc_bigint<5>(mul_ln1118_1307_fu_42365_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1308_fu_42395_p0() {
    mul_ln1118_1308_fu_42395_p0 =  (sc_lv<12>) (sext_ln1116_108_cast_fu_24203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1308_fu_42395_p1() {
    mul_ln1118_1308_fu_42395_p1 = tmp_1308_fu_42381_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1308_fu_42395_p2() {
    mul_ln1118_1308_fu_42395_p2 = (!mul_ln1118_1308_fu_42395_p0.read().is_01() || !mul_ln1118_1308_fu_42395_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1308_fu_42395_p0.read()) * sc_bigint<5>(mul_ln1118_1308_fu_42395_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1309_fu_78074_p0() {
    mul_ln1118_1309_fu_78074_p0 =  (sc_lv<12>) (sext_ln1116_109_cast_fu_54191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1309_fu_78074_p1() {
    mul_ln1118_1309_fu_78074_p1 = tmp_1309_reg_103102.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1309_fu_78074_p2() {
    mul_ln1118_1309_fu_78074_p2 = (!mul_ln1118_1309_fu_78074_p0.read().is_01() || !mul_ln1118_1309_fu_78074_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1309_fu_78074_p0.read()) * sc_bigint<5>(mul_ln1118_1309_fu_78074_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_130_fu_54659_p0() {
    mul_ln1118_130_fu_54659_p0 =  (sc_lv<12>) (sext_ln1116_130_cast_fu_54653_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_130_fu_54659_p1() {
    mul_ln1118_130_fu_54659_p1 = tmp_130_reg_96864.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_130_fu_54659_p2() {
    mul_ln1118_130_fu_54659_p2 = (!mul_ln1118_130_fu_54659_p0.read().is_01() || !mul_ln1118_130_fu_54659_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_130_fu_54659_p0.read()) * sc_bigint<5>(mul_ln1118_130_fu_54659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1310_fu_78093_p0() {
    mul_ln1118_1310_fu_78093_p0 =  (sc_lv<12>) (sext_ln1116_110_cast_fu_54213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1310_fu_78093_p1() {
    mul_ln1118_1310_fu_78093_p1 = tmp_1310_reg_103107.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1310_fu_78093_p2() {
    mul_ln1118_1310_fu_78093_p2 = (!mul_ln1118_1310_fu_78093_p0.read().is_01() || !mul_ln1118_1310_fu_78093_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1310_fu_78093_p0.read()) * sc_bigint<5>(mul_ln1118_1310_fu_78093_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1311_fu_78112_p0() {
    mul_ln1118_1311_fu_78112_p0 =  (sc_lv<12>) (sext_ln1116_111_cast_fu_54235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1311_fu_78112_p1() {
    mul_ln1118_1311_fu_78112_p1 = tmp_1311_reg_103112.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1311_fu_78112_p2() {
    mul_ln1118_1311_fu_78112_p2 = (!mul_ln1118_1311_fu_78112_p0.read().is_01() || !mul_ln1118_1311_fu_78112_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1311_fu_78112_p0.read()) * sc_bigint<5>(mul_ln1118_1311_fu_78112_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1312_fu_78131_p0() {
    mul_ln1118_1312_fu_78131_p0 =  (sc_lv<12>) (sext_ln1116_112_cast_fu_54257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1312_fu_78131_p1() {
    mul_ln1118_1312_fu_78131_p1 = tmp_1312_reg_103117.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1312_fu_78131_p2() {
    mul_ln1118_1312_fu_78131_p2 = (!mul_ln1118_1312_fu_78131_p0.read().is_01() || !mul_ln1118_1312_fu_78131_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1312_fu_78131_p0.read()) * sc_bigint<5>(mul_ln1118_1312_fu_78131_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1313_fu_78150_p0() {
    mul_ln1118_1313_fu_78150_p0 =  (sc_lv<12>) (sext_ln1116_113_cast_fu_54279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1313_fu_78150_p1() {
    mul_ln1118_1313_fu_78150_p1 = tmp_1313_reg_103122.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1313_fu_78150_p2() {
    mul_ln1118_1313_fu_78150_p2 = (!mul_ln1118_1313_fu_78150_p0.read().is_01() || !mul_ln1118_1313_fu_78150_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1313_fu_78150_p0.read()) * sc_bigint<5>(mul_ln1118_1313_fu_78150_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1314_fu_78169_p0() {
    mul_ln1118_1314_fu_78169_p0 =  (sc_lv<12>) (sext_ln1116_114_cast_fu_54301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1314_fu_78169_p1() {
    mul_ln1118_1314_fu_78169_p1 = tmp_1314_reg_103127.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1314_fu_78169_p2() {
    mul_ln1118_1314_fu_78169_p2 = (!mul_ln1118_1314_fu_78169_p0.read().is_01() || !mul_ln1118_1314_fu_78169_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1314_fu_78169_p0.read()) * sc_bigint<5>(mul_ln1118_1314_fu_78169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1315_fu_78188_p0() {
    mul_ln1118_1315_fu_78188_p0 =  (sc_lv<12>) (sext_ln1116_115_cast_fu_54323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1315_fu_78188_p1() {
    mul_ln1118_1315_fu_78188_p1 = tmp_1315_reg_103132.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1315_fu_78188_p2() {
    mul_ln1118_1315_fu_78188_p2 = (!mul_ln1118_1315_fu_78188_p0.read().is_01() || !mul_ln1118_1315_fu_78188_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1315_fu_78188_p0.read()) * sc_bigint<5>(mul_ln1118_1315_fu_78188_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1316_fu_78207_p0() {
    mul_ln1118_1316_fu_78207_p0 =  (sc_lv<12>) (sext_ln1116_116_cast_fu_54345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1316_fu_78207_p1() {
    mul_ln1118_1316_fu_78207_p1 = tmp_1316_reg_103137.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1316_fu_78207_p2() {
    mul_ln1118_1316_fu_78207_p2 = (!mul_ln1118_1316_fu_78207_p0.read().is_01() || !mul_ln1118_1316_fu_78207_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1316_fu_78207_p0.read()) * sc_bigint<5>(mul_ln1118_1316_fu_78207_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1317_fu_78226_p0() {
    mul_ln1118_1317_fu_78226_p0 =  (sc_lv<12>) (sext_ln1116_117_cast_fu_54367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1317_fu_78226_p1() {
    mul_ln1118_1317_fu_78226_p1 = tmp_1317_reg_103142.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1317_fu_78226_p2() {
    mul_ln1118_1317_fu_78226_p2 = (!mul_ln1118_1317_fu_78226_p0.read().is_01() || !mul_ln1118_1317_fu_78226_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1317_fu_78226_p0.read()) * sc_bigint<5>(mul_ln1118_1317_fu_78226_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1318_fu_78245_p0() {
    mul_ln1118_1318_fu_78245_p0 =  (sc_lv<12>) (sext_ln1116_118_cast_fu_54389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1318_fu_78245_p1() {
    mul_ln1118_1318_fu_78245_p1 = tmp_1318_reg_103147.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1318_fu_78245_p2() {
    mul_ln1118_1318_fu_78245_p2 = (!mul_ln1118_1318_fu_78245_p0.read().is_01() || !mul_ln1118_1318_fu_78245_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1318_fu_78245_p0.read()) * sc_bigint<5>(mul_ln1118_1318_fu_78245_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1319_fu_78264_p0() {
    mul_ln1118_1319_fu_78264_p0 =  (sc_lv<12>) (sext_ln1116_119_cast_fu_54411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1319_fu_78264_p1() {
    mul_ln1118_1319_fu_78264_p1 = tmp_1319_reg_103152.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1319_fu_78264_p2() {
    mul_ln1118_1319_fu_78264_p2 = (!mul_ln1118_1319_fu_78264_p0.read().is_01() || !mul_ln1118_1319_fu_78264_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1319_fu_78264_p0.read()) * sc_bigint<5>(mul_ln1118_1319_fu_78264_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_131_fu_54681_p0() {
    mul_ln1118_131_fu_54681_p0 =  (sc_lv<12>) (sext_ln1116_131_cast_fu_54675_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_131_fu_54681_p1() {
    mul_ln1118_131_fu_54681_p1 = tmp_131_reg_96874.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_131_fu_54681_p2() {
    mul_ln1118_131_fu_54681_p2 = (!mul_ln1118_131_fu_54681_p0.read().is_01() || !mul_ln1118_131_fu_54681_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_131_fu_54681_p0.read()) * sc_bigint<5>(mul_ln1118_131_fu_54681_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1320_fu_78283_p0() {
    mul_ln1118_1320_fu_78283_p0 =  (sc_lv<12>) (sext_ln1116_120_cast_fu_54433_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1320_fu_78283_p1() {
    mul_ln1118_1320_fu_78283_p1 = tmp_1320_reg_103157.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1320_fu_78283_p2() {
    mul_ln1118_1320_fu_78283_p2 = (!mul_ln1118_1320_fu_78283_p0.read().is_01() || !mul_ln1118_1320_fu_78283_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1320_fu_78283_p0.read()) * sc_bigint<5>(mul_ln1118_1320_fu_78283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1321_fu_78302_p0() {
    mul_ln1118_1321_fu_78302_p0 =  (sc_lv<12>) (sext_ln1116_121_cast_fu_54455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1321_fu_78302_p1() {
    mul_ln1118_1321_fu_78302_p1 = tmp_1321_reg_103162.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1321_fu_78302_p2() {
    mul_ln1118_1321_fu_78302_p2 = (!mul_ln1118_1321_fu_78302_p0.read().is_01() || !mul_ln1118_1321_fu_78302_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1321_fu_78302_p0.read()) * sc_bigint<5>(mul_ln1118_1321_fu_78302_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1322_fu_78321_p0() {
    mul_ln1118_1322_fu_78321_p0 =  (sc_lv<12>) (sext_ln1116_122_cast_fu_54477_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1322_fu_78321_p1() {
    mul_ln1118_1322_fu_78321_p1 = tmp_1322_reg_103167.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1322_fu_78321_p2() {
    mul_ln1118_1322_fu_78321_p2 = (!mul_ln1118_1322_fu_78321_p0.read().is_01() || !mul_ln1118_1322_fu_78321_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1322_fu_78321_p0.read()) * sc_bigint<5>(mul_ln1118_1322_fu_78321_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1323_fu_78340_p0() {
    mul_ln1118_1323_fu_78340_p0 =  (sc_lv<12>) (sext_ln1116_123_cast_fu_54499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1323_fu_78340_p1() {
    mul_ln1118_1323_fu_78340_p1 = tmp_1323_reg_103172.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1323_fu_78340_p2() {
    mul_ln1118_1323_fu_78340_p2 = (!mul_ln1118_1323_fu_78340_p0.read().is_01() || !mul_ln1118_1323_fu_78340_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1323_fu_78340_p0.read()) * sc_bigint<5>(mul_ln1118_1323_fu_78340_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1324_fu_78359_p0() {
    mul_ln1118_1324_fu_78359_p0 =  (sc_lv<12>) (sext_ln1116_124_cast_fu_54521_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1324_fu_78359_p1() {
    mul_ln1118_1324_fu_78359_p1 = tmp_1324_reg_103177.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1324_fu_78359_p2() {
    mul_ln1118_1324_fu_78359_p2 = (!mul_ln1118_1324_fu_78359_p0.read().is_01() || !mul_ln1118_1324_fu_78359_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1324_fu_78359_p0.read()) * sc_bigint<5>(mul_ln1118_1324_fu_78359_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1325_fu_78378_p0() {
    mul_ln1118_1325_fu_78378_p0 =  (sc_lv<12>) (sext_ln1116_125_cast_fu_54543_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1325_fu_78378_p1() {
    mul_ln1118_1325_fu_78378_p1 = tmp_1325_reg_103182.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1325_fu_78378_p2() {
    mul_ln1118_1325_fu_78378_p2 = (!mul_ln1118_1325_fu_78378_p0.read().is_01() || !mul_ln1118_1325_fu_78378_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1325_fu_78378_p0.read()) * sc_bigint<5>(mul_ln1118_1325_fu_78378_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1326_fu_78397_p0() {
    mul_ln1118_1326_fu_78397_p0 =  (sc_lv<12>) (sext_ln1116_126_cast_fu_54565_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1326_fu_78397_p1() {
    mul_ln1118_1326_fu_78397_p1 = tmp_1326_reg_103187.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1326_fu_78397_p2() {
    mul_ln1118_1326_fu_78397_p2 = (!mul_ln1118_1326_fu_78397_p0.read().is_01() || !mul_ln1118_1326_fu_78397_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1326_fu_78397_p0.read()) * sc_bigint<5>(mul_ln1118_1326_fu_78397_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1327_fu_78416_p0() {
    mul_ln1118_1327_fu_78416_p0 =  (sc_lv<12>) (sext_ln1116_127_cast_fu_54587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1327_fu_78416_p1() {
    mul_ln1118_1327_fu_78416_p1 = tmp_1327_reg_103192.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1327_fu_78416_p2() {
    mul_ln1118_1327_fu_78416_p2 = (!mul_ln1118_1327_fu_78416_p0.read().is_01() || !mul_ln1118_1327_fu_78416_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1327_fu_78416_p0.read()) * sc_bigint<5>(mul_ln1118_1327_fu_78416_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1328_fu_78435_p0() {
    mul_ln1118_1328_fu_78435_p0 =  (sc_lv<12>) (sext_ln1116_128_cast_fu_54609_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1328_fu_78435_p1() {
    mul_ln1118_1328_fu_78435_p1 = tmp_1328_reg_103197.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1328_fu_78435_p2() {
    mul_ln1118_1328_fu_78435_p2 = (!mul_ln1118_1328_fu_78435_p0.read().is_01() || !mul_ln1118_1328_fu_78435_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1328_fu_78435_p0.read()) * sc_bigint<5>(mul_ln1118_1328_fu_78435_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1329_fu_78454_p0() {
    mul_ln1118_1329_fu_78454_p0 =  (sc_lv<12>) (sext_ln1116_129_cast_fu_54631_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1329_fu_78454_p1() {
    mul_ln1118_1329_fu_78454_p1 = tmp_1329_reg_103202.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1329_fu_78454_p2() {
    mul_ln1118_1329_fu_78454_p2 = (!mul_ln1118_1329_fu_78454_p0.read().is_01() || !mul_ln1118_1329_fu_78454_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1329_fu_78454_p0.read()) * sc_bigint<5>(mul_ln1118_1329_fu_78454_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_132_fu_24667_p0() {
    mul_ln1118_132_fu_24667_p0 =  (sc_lv<12>) (sext_ln1116_132_cast_fu_24659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_132_fu_24667_p1() {
    mul_ln1118_132_fu_24667_p1 = tmp_132_fu_24649_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_132_fu_24667_p2() {
    mul_ln1118_132_fu_24667_p2 = (!mul_ln1118_132_fu_24667_p0.read().is_01() || !mul_ln1118_132_fu_24667_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_132_fu_24667_p0.read()) * sc_bigint<5>(mul_ln1118_132_fu_24667_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1330_fu_78473_p0() {
    mul_ln1118_1330_fu_78473_p0 =  (sc_lv<12>) (sext_ln1116_130_cast_fu_54653_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1330_fu_78473_p1() {
    mul_ln1118_1330_fu_78473_p1 = tmp_1330_reg_103207.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1330_fu_78473_p2() {
    mul_ln1118_1330_fu_78473_p2 = (!mul_ln1118_1330_fu_78473_p0.read().is_01() || !mul_ln1118_1330_fu_78473_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1330_fu_78473_p0.read()) * sc_bigint<5>(mul_ln1118_1330_fu_78473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1331_fu_78492_p0() {
    mul_ln1118_1331_fu_78492_p0 =  (sc_lv<12>) (sext_ln1116_131_cast_fu_54675_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1331_fu_78492_p1() {
    mul_ln1118_1331_fu_78492_p1 = tmp_1331_reg_103212.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1331_fu_78492_p2() {
    mul_ln1118_1331_fu_78492_p2 = (!mul_ln1118_1331_fu_78492_p0.read().is_01() || !mul_ln1118_1331_fu_78492_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1331_fu_78492_p0.read()) * sc_bigint<5>(mul_ln1118_1331_fu_78492_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1332_fu_42655_p0() {
    mul_ln1118_1332_fu_42655_p0 =  (sc_lv<12>) (sext_ln1116_132_cast_fu_24659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1332_fu_42655_p1() {
    mul_ln1118_1332_fu_42655_p1 = tmp_1332_fu_42641_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1332_fu_42655_p2() {
    mul_ln1118_1332_fu_42655_p2 = (!mul_ln1118_1332_fu_42655_p0.read().is_01() || !mul_ln1118_1332_fu_42655_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1332_fu_42655_p0.read()) * sc_bigint<5>(mul_ln1118_1332_fu_42655_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1333_fu_42685_p0() {
    mul_ln1118_1333_fu_42685_p0 =  (sc_lv<12>) (sext_ln1116_133_cast_fu_24701_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1333_fu_42685_p1() {
    mul_ln1118_1333_fu_42685_p1 = tmp_1333_fu_42671_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1333_fu_42685_p2() {
    mul_ln1118_1333_fu_42685_p2 = (!mul_ln1118_1333_fu_42685_p0.read().is_01() || !mul_ln1118_1333_fu_42685_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1333_fu_42685_p0.read()) * sc_bigint<5>(mul_ln1118_1333_fu_42685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1334_fu_78511_p0() {
    mul_ln1118_1334_fu_78511_p0 =  (sc_lv<12>) (sext_ln1116_134_cast_fu_54697_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1334_fu_78511_p1() {
    mul_ln1118_1334_fu_78511_p1 = tmp_1334_reg_103227.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1334_fu_78511_p2() {
    mul_ln1118_1334_fu_78511_p2 = (!mul_ln1118_1334_fu_78511_p0.read().is_01() || !mul_ln1118_1334_fu_78511_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1334_fu_78511_p0.read()) * sc_bigint<5>(mul_ln1118_1334_fu_78511_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1335_fu_78530_p0() {
    mul_ln1118_1335_fu_78530_p0 =  (sc_lv<12>) (sext_ln1116_135_cast_fu_54719_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1335_fu_78530_p1() {
    mul_ln1118_1335_fu_78530_p1 = tmp_1335_reg_103232.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1335_fu_78530_p2() {
    mul_ln1118_1335_fu_78530_p2 = (!mul_ln1118_1335_fu_78530_p0.read().is_01() || !mul_ln1118_1335_fu_78530_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1335_fu_78530_p0.read()) * sc_bigint<5>(mul_ln1118_1335_fu_78530_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1336_fu_78549_p0() {
    mul_ln1118_1336_fu_78549_p0 =  (sc_lv<12>) (sext_ln1116_136_cast_fu_54741_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1336_fu_78549_p1() {
    mul_ln1118_1336_fu_78549_p1 = tmp_1336_reg_103237.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1336_fu_78549_p2() {
    mul_ln1118_1336_fu_78549_p2 = (!mul_ln1118_1336_fu_78549_p0.read().is_01() || !mul_ln1118_1336_fu_78549_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1336_fu_78549_p0.read()) * sc_bigint<5>(mul_ln1118_1336_fu_78549_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1337_fu_78568_p0() {
    mul_ln1118_1337_fu_78568_p0 =  (sc_lv<12>) (sext_ln1116_137_cast_fu_54763_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1337_fu_78568_p1() {
    mul_ln1118_1337_fu_78568_p1 = tmp_1337_reg_103242.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1337_fu_78568_p2() {
    mul_ln1118_1337_fu_78568_p2 = (!mul_ln1118_1337_fu_78568_p0.read().is_01() || !mul_ln1118_1337_fu_78568_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1337_fu_78568_p0.read()) * sc_bigint<5>(mul_ln1118_1337_fu_78568_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1338_fu_78587_p0() {
    mul_ln1118_1338_fu_78587_p0 =  (sc_lv<12>) (sext_ln1116_138_cast_fu_54785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1338_fu_78587_p1() {
    mul_ln1118_1338_fu_78587_p1 = tmp_1338_reg_103247.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1338_fu_78587_p2() {
    mul_ln1118_1338_fu_78587_p2 = (!mul_ln1118_1338_fu_78587_p0.read().is_01() || !mul_ln1118_1338_fu_78587_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1338_fu_78587_p0.read()) * sc_bigint<5>(mul_ln1118_1338_fu_78587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1339_fu_78606_p0() {
    mul_ln1118_1339_fu_78606_p0 =  (sc_lv<12>) (sext_ln1116_139_cast_fu_54807_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1339_fu_78606_p1() {
    mul_ln1118_1339_fu_78606_p1 = tmp_1339_reg_103252.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1339_fu_78606_p2() {
    mul_ln1118_1339_fu_78606_p2 = (!mul_ln1118_1339_fu_78606_p0.read().is_01() || !mul_ln1118_1339_fu_78606_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1339_fu_78606_p0.read()) * sc_bigint<5>(mul_ln1118_1339_fu_78606_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_133_fu_24709_p0() {
    mul_ln1118_133_fu_24709_p0 =  (sc_lv<12>) (sext_ln1116_133_cast_fu_24701_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_133_fu_24709_p1() {
    mul_ln1118_133_fu_24709_p1 = tmp_133_fu_24691_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_133_fu_24709_p2() {
    mul_ln1118_133_fu_24709_p2 = (!mul_ln1118_133_fu_24709_p0.read().is_01() || !mul_ln1118_133_fu_24709_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_133_fu_24709_p0.read()) * sc_bigint<5>(mul_ln1118_133_fu_24709_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1340_fu_78625_p0() {
    mul_ln1118_1340_fu_78625_p0 =  (sc_lv<12>) (sext_ln1116_140_cast_fu_54829_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1340_fu_78625_p1() {
    mul_ln1118_1340_fu_78625_p1 = tmp_1340_reg_103257.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1340_fu_78625_p2() {
    mul_ln1118_1340_fu_78625_p2 = (!mul_ln1118_1340_fu_78625_p0.read().is_01() || !mul_ln1118_1340_fu_78625_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1340_fu_78625_p0.read()) * sc_bigint<5>(mul_ln1118_1340_fu_78625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1341_fu_78644_p0() {
    mul_ln1118_1341_fu_78644_p0 =  (sc_lv<12>) (sext_ln1116_141_cast_fu_54851_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1341_fu_78644_p1() {
    mul_ln1118_1341_fu_78644_p1 = tmp_1341_reg_103262.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1341_fu_78644_p2() {
    mul_ln1118_1341_fu_78644_p2 = (!mul_ln1118_1341_fu_78644_p0.read().is_01() || !mul_ln1118_1341_fu_78644_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1341_fu_78644_p0.read()) * sc_bigint<5>(mul_ln1118_1341_fu_78644_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1342_fu_78663_p0() {
    mul_ln1118_1342_fu_78663_p0 =  (sc_lv<12>) (sext_ln1116_142_cast_fu_54873_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1342_fu_78663_p1() {
    mul_ln1118_1342_fu_78663_p1 = tmp_1342_reg_103267.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1342_fu_78663_p2() {
    mul_ln1118_1342_fu_78663_p2 = (!mul_ln1118_1342_fu_78663_p0.read().is_01() || !mul_ln1118_1342_fu_78663_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1342_fu_78663_p0.read()) * sc_bigint<5>(mul_ln1118_1342_fu_78663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1343_fu_78682_p0() {
    mul_ln1118_1343_fu_78682_p0 =  (sc_lv<12>) (sext_ln1116_143_cast_fu_54895_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1343_fu_78682_p1() {
    mul_ln1118_1343_fu_78682_p1 = tmp_1343_reg_103272.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1343_fu_78682_p2() {
    mul_ln1118_1343_fu_78682_p2 = (!mul_ln1118_1343_fu_78682_p0.read().is_01() || !mul_ln1118_1343_fu_78682_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1343_fu_78682_p0.read()) * sc_bigint<5>(mul_ln1118_1343_fu_78682_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1344_fu_78701_p0() {
    mul_ln1118_1344_fu_78701_p0 =  (sc_lv<12>) (sext_ln1116_144_cast_fu_54917_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1344_fu_78701_p1() {
    mul_ln1118_1344_fu_78701_p1 = tmp_1344_reg_103277.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1344_fu_78701_p2() {
    mul_ln1118_1344_fu_78701_p2 = (!mul_ln1118_1344_fu_78701_p0.read().is_01() || !mul_ln1118_1344_fu_78701_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1344_fu_78701_p0.read()) * sc_bigint<5>(mul_ln1118_1344_fu_78701_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1345_fu_78720_p0() {
    mul_ln1118_1345_fu_78720_p0 =  (sc_lv<12>) (sext_ln1116_145_cast_fu_54939_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1345_fu_78720_p1() {
    mul_ln1118_1345_fu_78720_p1 = tmp_1345_reg_103282.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1345_fu_78720_p2() {
    mul_ln1118_1345_fu_78720_p2 = (!mul_ln1118_1345_fu_78720_p0.read().is_01() || !mul_ln1118_1345_fu_78720_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1345_fu_78720_p0.read()) * sc_bigint<5>(mul_ln1118_1345_fu_78720_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1346_fu_78739_p0() {
    mul_ln1118_1346_fu_78739_p0 =  (sc_lv<12>) (sext_ln1116_146_cast_fu_54961_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1346_fu_78739_p1() {
    mul_ln1118_1346_fu_78739_p1 = tmp_1346_reg_103287.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1346_fu_78739_p2() {
    mul_ln1118_1346_fu_78739_p2 = (!mul_ln1118_1346_fu_78739_p0.read().is_01() || !mul_ln1118_1346_fu_78739_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1346_fu_78739_p0.read()) * sc_bigint<5>(mul_ln1118_1346_fu_78739_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1347_fu_78758_p0() {
    mul_ln1118_1347_fu_78758_p0 =  (sc_lv<12>) (sext_ln1116_147_cast_fu_54983_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1347_fu_78758_p1() {
    mul_ln1118_1347_fu_78758_p1 = tmp_1347_reg_103292.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1347_fu_78758_p2() {
    mul_ln1118_1347_fu_78758_p2 = (!mul_ln1118_1347_fu_78758_p0.read().is_01() || !mul_ln1118_1347_fu_78758_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1347_fu_78758_p0.read()) * sc_bigint<5>(mul_ln1118_1347_fu_78758_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1348_fu_78777_p0() {
    mul_ln1118_1348_fu_78777_p0 =  (sc_lv<12>) (sext_ln1116_148_cast_fu_55005_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1348_fu_78777_p1() {
    mul_ln1118_1348_fu_78777_p1 = tmp_1348_reg_103297.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1348_fu_78777_p2() {
    mul_ln1118_1348_fu_78777_p2 = (!mul_ln1118_1348_fu_78777_p0.read().is_01() || !mul_ln1118_1348_fu_78777_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1348_fu_78777_p0.read()) * sc_bigint<5>(mul_ln1118_1348_fu_78777_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1349_fu_78796_p0() {
    mul_ln1118_1349_fu_78796_p0 =  (sc_lv<12>) (sext_ln1116_149_cast_fu_55027_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1349_fu_78796_p1() {
    mul_ln1118_1349_fu_78796_p1 = tmp_1349_reg_103302.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1349_fu_78796_p2() {
    mul_ln1118_1349_fu_78796_p2 = (!mul_ln1118_1349_fu_78796_p0.read().is_01() || !mul_ln1118_1349_fu_78796_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1349_fu_78796_p0.read()) * sc_bigint<5>(mul_ln1118_1349_fu_78796_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_134_fu_54703_p0() {
    mul_ln1118_134_fu_54703_p0 =  (sc_lv<12>) (sext_ln1116_134_cast_fu_54697_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_134_fu_54703_p1() {
    mul_ln1118_134_fu_54703_p1 = tmp_134_reg_96894.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_134_fu_54703_p2() {
    mul_ln1118_134_fu_54703_p2 = (!mul_ln1118_134_fu_54703_p0.read().is_01() || !mul_ln1118_134_fu_54703_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_134_fu_54703_p0.read()) * sc_bigint<5>(mul_ln1118_134_fu_54703_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1350_fu_78815_p0() {
    mul_ln1118_1350_fu_78815_p0 =  (sc_lv<12>) (sext_ln1116_150_cast_fu_55049_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1350_fu_78815_p1() {
    mul_ln1118_1350_fu_78815_p1 = tmp_1350_reg_103307.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1350_fu_78815_p2() {
    mul_ln1118_1350_fu_78815_p2 = (!mul_ln1118_1350_fu_78815_p0.read().is_01() || !mul_ln1118_1350_fu_78815_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1350_fu_78815_p0.read()) * sc_bigint<5>(mul_ln1118_1350_fu_78815_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1351_fu_78834_p0() {
    mul_ln1118_1351_fu_78834_p0 =  (sc_lv<12>) (sext_ln1116_151_cast_reg_97064.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1351_fu_78834_p1() {
    mul_ln1118_1351_fu_78834_p1 = tmp_1351_reg_103312.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1351_fu_78834_p2() {
    mul_ln1118_1351_fu_78834_p2 = (!mul_ln1118_1351_fu_78834_p0.read().is_01() || !mul_ln1118_1351_fu_78834_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1351_fu_78834_p0.read()) * sc_bigint<5>(mul_ln1118_1351_fu_78834_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1352_fu_78852_p0() {
    mul_ln1118_1352_fu_78852_p0 =  (sc_lv<12>) (sext_ln1116_152_cast_reg_97082.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1352_fu_78852_p1() {
    mul_ln1118_1352_fu_78852_p1 = tmp_1352_reg_103317.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1352_fu_78852_p2() {
    mul_ln1118_1352_fu_78852_p2 = (!mul_ln1118_1352_fu_78852_p0.read().is_01() || !mul_ln1118_1352_fu_78852_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1352_fu_78852_p0.read()) * sc_bigint<5>(mul_ln1118_1352_fu_78852_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1353_fu_42905_p0() {
    mul_ln1118_1353_fu_42905_p0 =  (sc_lv<12>) (sext_ln1116_153_cast_fu_25093_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1353_fu_42905_p1() {
    mul_ln1118_1353_fu_42905_p1 = tmp_1353_fu_42891_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1353_fu_42905_p2() {
    mul_ln1118_1353_fu_42905_p2 = (!mul_ln1118_1353_fu_42905_p0.read().is_01() || !mul_ln1118_1353_fu_42905_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1353_fu_42905_p0.read()) * sc_bigint<5>(mul_ln1118_1353_fu_42905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1354_fu_42935_p0() {
    mul_ln1118_1354_fu_42935_p0 =  (sc_lv<12>) (sext_ln1116_154_cast_fu_25135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1354_fu_42935_p1() {
    mul_ln1118_1354_fu_42935_p1 = tmp_1354_fu_42921_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1354_fu_42935_p2() {
    mul_ln1118_1354_fu_42935_p2 = (!mul_ln1118_1354_fu_42935_p0.read().is_01() || !mul_ln1118_1354_fu_42935_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1354_fu_42935_p0.read()) * sc_bigint<5>(mul_ln1118_1354_fu_42935_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1355_fu_42965_p0() {
    mul_ln1118_1355_fu_42965_p0 =  (sc_lv<12>) (sext_ln1116_155_cast_fu_25177_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1355_fu_42965_p1() {
    mul_ln1118_1355_fu_42965_p1 = tmp_1355_fu_42951_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1355_fu_42965_p2() {
    mul_ln1118_1355_fu_42965_p2 = (!mul_ln1118_1355_fu_42965_p0.read().is_01() || !mul_ln1118_1355_fu_42965_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1355_fu_42965_p0.read()) * sc_bigint<5>(mul_ln1118_1355_fu_42965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1356_fu_42995_p0() {
    mul_ln1118_1356_fu_42995_p0 =  (sc_lv<12>) (sext_ln1116_156_cast_fu_25219_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1356_fu_42995_p1() {
    mul_ln1118_1356_fu_42995_p1 = tmp_1356_fu_42981_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1356_fu_42995_p2() {
    mul_ln1118_1356_fu_42995_p2 = (!mul_ln1118_1356_fu_42995_p0.read().is_01() || !mul_ln1118_1356_fu_42995_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1356_fu_42995_p0.read()) * sc_bigint<5>(mul_ln1118_1356_fu_42995_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1357_fu_43025_p0() {
    mul_ln1118_1357_fu_43025_p0 =  (sc_lv<12>) (sext_ln1116_157_cast_fu_25261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1357_fu_43025_p1() {
    mul_ln1118_1357_fu_43025_p1 = tmp_1357_fu_43011_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1357_fu_43025_p2() {
    mul_ln1118_1357_fu_43025_p2 = (!mul_ln1118_1357_fu_43025_p0.read().is_01() || !mul_ln1118_1357_fu_43025_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1357_fu_43025_p0.read()) * sc_bigint<5>(mul_ln1118_1357_fu_43025_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1358_fu_43055_p0() {
    mul_ln1118_1358_fu_43055_p0 =  (sc_lv<12>) (sext_ln1116_158_cast_fu_25303_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1358_fu_43055_p1() {
    mul_ln1118_1358_fu_43055_p1 = tmp_1358_fu_43041_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1358_fu_43055_p2() {
    mul_ln1118_1358_fu_43055_p2 = (!mul_ln1118_1358_fu_43055_p0.read().is_01() || !mul_ln1118_1358_fu_43055_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1358_fu_43055_p0.read()) * sc_bigint<5>(mul_ln1118_1358_fu_43055_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1359_fu_78870_p0() {
    mul_ln1118_1359_fu_78870_p0 =  (sc_lv<12>) (sext_ln1116_159_cast_fu_55107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1359_fu_78870_p1() {
    mul_ln1118_1359_fu_78870_p1 = tmp_1359_reg_103352.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1359_fu_78870_p2() {
    mul_ln1118_1359_fu_78870_p2 = (!mul_ln1118_1359_fu_78870_p0.read().is_01() || !mul_ln1118_1359_fu_78870_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1359_fu_78870_p0.read()) * sc_bigint<5>(mul_ln1118_1359_fu_78870_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_135_fu_54725_p0() {
    mul_ln1118_135_fu_54725_p0 =  (sc_lv<12>) (sext_ln1116_135_cast_fu_54719_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_135_fu_54725_p1() {
    mul_ln1118_135_fu_54725_p1 = tmp_135_reg_96904.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_135_fu_54725_p2() {
    mul_ln1118_135_fu_54725_p2 = (!mul_ln1118_135_fu_54725_p0.read().is_01() || !mul_ln1118_135_fu_54725_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_135_fu_54725_p0.read()) * sc_bigint<5>(mul_ln1118_135_fu_54725_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1360_fu_78889_p0() {
    mul_ln1118_1360_fu_78889_p0 =  (sc_lv<12>) (sext_ln1116_160_cast_fu_55129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1360_fu_78889_p1() {
    mul_ln1118_1360_fu_78889_p1 = tmp_1360_reg_103357.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1360_fu_78889_p2() {
    mul_ln1118_1360_fu_78889_p2 = (!mul_ln1118_1360_fu_78889_p0.read().is_01() || !mul_ln1118_1360_fu_78889_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1360_fu_78889_p0.read()) * sc_bigint<5>(mul_ln1118_1360_fu_78889_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1361_fu_78908_p0() {
    mul_ln1118_1361_fu_78908_p0 =  (sc_lv<12>) (sext_ln1116_161_cast_fu_55151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1361_fu_78908_p1() {
    mul_ln1118_1361_fu_78908_p1 = tmp_1361_reg_103362.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1361_fu_78908_p2() {
    mul_ln1118_1361_fu_78908_p2 = (!mul_ln1118_1361_fu_78908_p0.read().is_01() || !mul_ln1118_1361_fu_78908_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1361_fu_78908_p0.read()) * sc_bigint<5>(mul_ln1118_1361_fu_78908_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1362_fu_78927_p0() {
    mul_ln1118_1362_fu_78927_p0 =  (sc_lv<12>) (sext_ln1116_162_cast_fu_55173_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1362_fu_78927_p1() {
    mul_ln1118_1362_fu_78927_p1 = tmp_1362_reg_103367.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1362_fu_78927_p2() {
    mul_ln1118_1362_fu_78927_p2 = (!mul_ln1118_1362_fu_78927_p0.read().is_01() || !mul_ln1118_1362_fu_78927_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1362_fu_78927_p0.read()) * sc_bigint<5>(mul_ln1118_1362_fu_78927_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1363_fu_78946_p0() {
    mul_ln1118_1363_fu_78946_p0 =  (sc_lv<12>) (sext_ln1116_163_cast_fu_55195_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1363_fu_78946_p1() {
    mul_ln1118_1363_fu_78946_p1 = tmp_1363_reg_103372.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1363_fu_78946_p2() {
    mul_ln1118_1363_fu_78946_p2 = (!mul_ln1118_1363_fu_78946_p0.read().is_01() || !mul_ln1118_1363_fu_78946_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1363_fu_78946_p0.read()) * sc_bigint<5>(mul_ln1118_1363_fu_78946_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1364_fu_78965_p0() {
    mul_ln1118_1364_fu_78965_p0 =  (sc_lv<12>) (sext_ln1116_164_cast_fu_55217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1364_fu_78965_p1() {
    mul_ln1118_1364_fu_78965_p1 = tmp_1364_reg_103377.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1364_fu_78965_p2() {
    mul_ln1118_1364_fu_78965_p2 = (!mul_ln1118_1364_fu_78965_p0.read().is_01() || !mul_ln1118_1364_fu_78965_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1364_fu_78965_p0.read()) * sc_bigint<5>(mul_ln1118_1364_fu_78965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1365_fu_78984_p0() {
    mul_ln1118_1365_fu_78984_p0 =  (sc_lv<12>) (sext_ln1116_165_cast_fu_55239_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1365_fu_78984_p1() {
    mul_ln1118_1365_fu_78984_p1 = tmp_1365_reg_103382.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1365_fu_78984_p2() {
    mul_ln1118_1365_fu_78984_p2 = (!mul_ln1118_1365_fu_78984_p0.read().is_01() || !mul_ln1118_1365_fu_78984_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1365_fu_78984_p0.read()) * sc_bigint<5>(mul_ln1118_1365_fu_78984_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1366_fu_79003_p0() {
    mul_ln1118_1366_fu_79003_p0 =  (sc_lv<12>) (sext_ln1116_166_cast_fu_55261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1366_fu_79003_p1() {
    mul_ln1118_1366_fu_79003_p1 = tmp_1366_reg_103387.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1366_fu_79003_p2() {
    mul_ln1118_1366_fu_79003_p2 = (!mul_ln1118_1366_fu_79003_p0.read().is_01() || !mul_ln1118_1366_fu_79003_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1366_fu_79003_p0.read()) * sc_bigint<5>(mul_ln1118_1366_fu_79003_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1367_fu_79022_p0() {
    mul_ln1118_1367_fu_79022_p0 =  (sc_lv<12>) (sext_ln1116_167_cast_fu_55283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1367_fu_79022_p1() {
    mul_ln1118_1367_fu_79022_p1 = tmp_1367_reg_103392.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1367_fu_79022_p2() {
    mul_ln1118_1367_fu_79022_p2 = (!mul_ln1118_1367_fu_79022_p0.read().is_01() || !mul_ln1118_1367_fu_79022_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1367_fu_79022_p0.read()) * sc_bigint<5>(mul_ln1118_1367_fu_79022_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1368_fu_79041_p0() {
    mul_ln1118_1368_fu_79041_p0 =  (sc_lv<12>) (sext_ln1116_168_cast_fu_55305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1368_fu_79041_p1() {
    mul_ln1118_1368_fu_79041_p1 = tmp_1368_reg_103397.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1368_fu_79041_p2() {
    mul_ln1118_1368_fu_79041_p2 = (!mul_ln1118_1368_fu_79041_p0.read().is_01() || !mul_ln1118_1368_fu_79041_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1368_fu_79041_p0.read()) * sc_bigint<5>(mul_ln1118_1368_fu_79041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1369_fu_79060_p0() {
    mul_ln1118_1369_fu_79060_p0 =  (sc_lv<12>) (sext_ln1116_169_cast_fu_55327_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1369_fu_79060_p1() {
    mul_ln1118_1369_fu_79060_p1 = tmp_1369_reg_103402.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1369_fu_79060_p2() {
    mul_ln1118_1369_fu_79060_p2 = (!mul_ln1118_1369_fu_79060_p0.read().is_01() || !mul_ln1118_1369_fu_79060_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1369_fu_79060_p0.read()) * sc_bigint<5>(mul_ln1118_1369_fu_79060_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_136_fu_54747_p0() {
    mul_ln1118_136_fu_54747_p0 =  (sc_lv<12>) (sext_ln1116_136_cast_fu_54741_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_136_fu_54747_p1() {
    mul_ln1118_136_fu_54747_p1 = tmp_136_reg_96914.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_136_fu_54747_p2() {
    mul_ln1118_136_fu_54747_p2 = (!mul_ln1118_136_fu_54747_p0.read().is_01() || !mul_ln1118_136_fu_54747_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_136_fu_54747_p0.read()) * sc_bigint<5>(mul_ln1118_136_fu_54747_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1370_fu_79079_p0() {
    mul_ln1118_1370_fu_79079_p0 =  (sc_lv<12>) (sext_ln1116_170_cast_fu_55349_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1370_fu_79079_p1() {
    mul_ln1118_1370_fu_79079_p1 = tmp_1370_reg_103407.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1370_fu_79079_p2() {
    mul_ln1118_1370_fu_79079_p2 = (!mul_ln1118_1370_fu_79079_p0.read().is_01() || !mul_ln1118_1370_fu_79079_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1370_fu_79079_p0.read()) * sc_bigint<5>(mul_ln1118_1370_fu_79079_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1371_fu_79098_p0() {
    mul_ln1118_1371_fu_79098_p0 =  (sc_lv<12>) (sext_ln1116_171_cast_fu_55371_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1371_fu_79098_p1() {
    mul_ln1118_1371_fu_79098_p1 = tmp_1371_reg_103412.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1371_fu_79098_p2() {
    mul_ln1118_1371_fu_79098_p2 = (!mul_ln1118_1371_fu_79098_p0.read().is_01() || !mul_ln1118_1371_fu_79098_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1371_fu_79098_p0.read()) * sc_bigint<5>(mul_ln1118_1371_fu_79098_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1372_fu_79117_p0() {
    mul_ln1118_1372_fu_79117_p0 =  (sc_lv<12>) (sext_ln1116_172_cast_fu_55393_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1372_fu_79117_p1() {
    mul_ln1118_1372_fu_79117_p1 = tmp_1372_reg_103417.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1372_fu_79117_p2() {
    mul_ln1118_1372_fu_79117_p2 = (!mul_ln1118_1372_fu_79117_p0.read().is_01() || !mul_ln1118_1372_fu_79117_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1372_fu_79117_p0.read()) * sc_bigint<5>(mul_ln1118_1372_fu_79117_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1373_fu_79136_p0() {
    mul_ln1118_1373_fu_79136_p0 =  (sc_lv<12>) (sext_ln1116_173_cast_fu_55415_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1373_fu_79136_p1() {
    mul_ln1118_1373_fu_79136_p1 = tmp_1373_reg_103422.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1373_fu_79136_p2() {
    mul_ln1118_1373_fu_79136_p2 = (!mul_ln1118_1373_fu_79136_p0.read().is_01() || !mul_ln1118_1373_fu_79136_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1373_fu_79136_p0.read()) * sc_bigint<5>(mul_ln1118_1373_fu_79136_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1374_fu_79155_p0() {
    mul_ln1118_1374_fu_79155_p0 =  (sc_lv<12>) (sext_ln1116_174_cast_fu_55437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1374_fu_79155_p1() {
    mul_ln1118_1374_fu_79155_p1 = tmp_1374_reg_103427.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1374_fu_79155_p2() {
    mul_ln1118_1374_fu_79155_p2 = (!mul_ln1118_1374_fu_79155_p0.read().is_01() || !mul_ln1118_1374_fu_79155_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1374_fu_79155_p0.read()) * sc_bigint<5>(mul_ln1118_1374_fu_79155_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1375_fu_79174_p0() {
    mul_ln1118_1375_fu_79174_p0 =  (sc_lv<12>) (sext_ln1116_175_cast_fu_55459_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1375_fu_79174_p1() {
    mul_ln1118_1375_fu_79174_p1 = tmp_1375_reg_103432.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1375_fu_79174_p2() {
    mul_ln1118_1375_fu_79174_p2 = (!mul_ln1118_1375_fu_79174_p0.read().is_01() || !mul_ln1118_1375_fu_79174_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1375_fu_79174_p0.read()) * sc_bigint<5>(mul_ln1118_1375_fu_79174_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1376_fu_79193_p0() {
    mul_ln1118_1376_fu_79193_p0 =  (sc_lv<12>) (sext_ln1116_176_cast_reg_97300.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1376_fu_79193_p1() {
    mul_ln1118_1376_fu_79193_p1 = tmp_1376_reg_103437.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1376_fu_79193_p2() {
    mul_ln1118_1376_fu_79193_p2 = (!mul_ln1118_1376_fu_79193_p0.read().is_01() || !mul_ln1118_1376_fu_79193_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1376_fu_79193_p0.read()) * sc_bigint<5>(mul_ln1118_1376_fu_79193_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1377_fu_79211_p0() {
    mul_ln1118_1377_fu_79211_p0 =  (sc_lv<12>) (sext_ln1116_177_cast_reg_97318.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1377_fu_79211_p1() {
    mul_ln1118_1377_fu_79211_p1 = tmp_1377_reg_103442.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1377_fu_79211_p2() {
    mul_ln1118_1377_fu_79211_p2 = (!mul_ln1118_1377_fu_79211_p0.read().is_01() || !mul_ln1118_1377_fu_79211_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1377_fu_79211_p0.read()) * sc_bigint<5>(mul_ln1118_1377_fu_79211_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1378_fu_43275_p0() {
    mul_ln1118_1378_fu_43275_p0 =  (sc_lv<12>) (sext_ln1116_178_cast_fu_25695_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1378_fu_43275_p1() {
    mul_ln1118_1378_fu_43275_p1 = tmp_1378_fu_43261_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1378_fu_43275_p2() {
    mul_ln1118_1378_fu_43275_p2 = (!mul_ln1118_1378_fu_43275_p0.read().is_01() || !mul_ln1118_1378_fu_43275_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1378_fu_43275_p0.read()) * sc_bigint<5>(mul_ln1118_1378_fu_43275_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1379_fu_43305_p0() {
    mul_ln1118_1379_fu_43305_p0 =  (sc_lv<12>) (sext_ln1116_179_cast_fu_25737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1379_fu_43305_p1() {
    mul_ln1118_1379_fu_43305_p1 = tmp_1379_fu_43291_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1379_fu_43305_p2() {
    mul_ln1118_1379_fu_43305_p2 = (!mul_ln1118_1379_fu_43305_p0.read().is_01() || !mul_ln1118_1379_fu_43305_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1379_fu_43305_p0.read()) * sc_bigint<5>(mul_ln1118_1379_fu_43305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_137_fu_54769_p0() {
    mul_ln1118_137_fu_54769_p0 =  (sc_lv<12>) (sext_ln1116_137_cast_fu_54763_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_137_fu_54769_p1() {
    mul_ln1118_137_fu_54769_p1 = tmp_137_reg_96924.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_137_fu_54769_p2() {
    mul_ln1118_137_fu_54769_p2 = (!mul_ln1118_137_fu_54769_p0.read().is_01() || !mul_ln1118_137_fu_54769_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_137_fu_54769_p0.read()) * sc_bigint<5>(mul_ln1118_137_fu_54769_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1380_fu_43335_p0() {
    mul_ln1118_1380_fu_43335_p0 =  (sc_lv<12>) (sext_ln1116_180_cast_fu_25779_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1380_fu_43335_p1() {
    mul_ln1118_1380_fu_43335_p1 = tmp_1380_fu_43321_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1380_fu_43335_p2() {
    mul_ln1118_1380_fu_43335_p2 = (!mul_ln1118_1380_fu_43335_p0.read().is_01() || !mul_ln1118_1380_fu_43335_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1380_fu_43335_p0.read()) * sc_bigint<5>(mul_ln1118_1380_fu_43335_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1381_fu_43365_p0() {
    mul_ln1118_1381_fu_43365_p0 =  (sc_lv<12>) (sext_ln1116_181_cast_fu_25821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1381_fu_43365_p1() {
    mul_ln1118_1381_fu_43365_p1 = tmp_1381_fu_43351_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1381_fu_43365_p2() {
    mul_ln1118_1381_fu_43365_p2 = (!mul_ln1118_1381_fu_43365_p0.read().is_01() || !mul_ln1118_1381_fu_43365_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1381_fu_43365_p0.read()) * sc_bigint<5>(mul_ln1118_1381_fu_43365_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1382_fu_43395_p0() {
    mul_ln1118_1382_fu_43395_p0 =  (sc_lv<12>) (sext_ln1116_182_cast_fu_25863_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1382_fu_43395_p1() {
    mul_ln1118_1382_fu_43395_p1 = tmp_1382_fu_43381_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1382_fu_43395_p2() {
    mul_ln1118_1382_fu_43395_p2 = (!mul_ln1118_1382_fu_43395_p0.read().is_01() || !mul_ln1118_1382_fu_43395_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1382_fu_43395_p0.read()) * sc_bigint<5>(mul_ln1118_1382_fu_43395_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1383_fu_43425_p0() {
    mul_ln1118_1383_fu_43425_p0 =  (sc_lv<12>) (sext_ln1116_183_cast_fu_25905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1383_fu_43425_p1() {
    mul_ln1118_1383_fu_43425_p1 = tmp_1383_fu_43411_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1383_fu_43425_p2() {
    mul_ln1118_1383_fu_43425_p2 = (!mul_ln1118_1383_fu_43425_p0.read().is_01() || !mul_ln1118_1383_fu_43425_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1383_fu_43425_p0.read()) * sc_bigint<5>(mul_ln1118_1383_fu_43425_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1384_fu_79229_p0() {
    mul_ln1118_1384_fu_79229_p0 =  (sc_lv<12>) (sext_ln1116_184_cast_fu_55517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1384_fu_79229_p1() {
    mul_ln1118_1384_fu_79229_p1 = tmp_1384_reg_103477.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1384_fu_79229_p2() {
    mul_ln1118_1384_fu_79229_p2 = (!mul_ln1118_1384_fu_79229_p0.read().is_01() || !mul_ln1118_1384_fu_79229_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1384_fu_79229_p0.read()) * sc_bigint<5>(mul_ln1118_1384_fu_79229_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1385_fu_79248_p0() {
    mul_ln1118_1385_fu_79248_p0 =  (sc_lv<12>) (sext_ln1116_185_cast_fu_55539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1385_fu_79248_p1() {
    mul_ln1118_1385_fu_79248_p1 = tmp_1385_reg_103482.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1385_fu_79248_p2() {
    mul_ln1118_1385_fu_79248_p2 = (!mul_ln1118_1385_fu_79248_p0.read().is_01() || !mul_ln1118_1385_fu_79248_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1385_fu_79248_p0.read()) * sc_bigint<5>(mul_ln1118_1385_fu_79248_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1386_fu_79267_p0() {
    mul_ln1118_1386_fu_79267_p0 =  (sc_lv<12>) (sext_ln1116_186_cast_fu_55561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1386_fu_79267_p1() {
    mul_ln1118_1386_fu_79267_p1 = tmp_1386_reg_103487.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1386_fu_79267_p2() {
    mul_ln1118_1386_fu_79267_p2 = (!mul_ln1118_1386_fu_79267_p0.read().is_01() || !mul_ln1118_1386_fu_79267_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1386_fu_79267_p0.read()) * sc_bigint<5>(mul_ln1118_1386_fu_79267_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1387_fu_79286_p0() {
    mul_ln1118_1387_fu_79286_p0 =  (sc_lv<12>) (sext_ln1116_187_cast_fu_55583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1387_fu_79286_p1() {
    mul_ln1118_1387_fu_79286_p1 = tmp_1387_reg_103492.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1387_fu_79286_p2() {
    mul_ln1118_1387_fu_79286_p2 = (!mul_ln1118_1387_fu_79286_p0.read().is_01() || !mul_ln1118_1387_fu_79286_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1387_fu_79286_p0.read()) * sc_bigint<5>(mul_ln1118_1387_fu_79286_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1388_fu_79305_p0() {
    mul_ln1118_1388_fu_79305_p0 =  (sc_lv<12>) (sext_ln1116_188_cast_fu_55605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1388_fu_79305_p1() {
    mul_ln1118_1388_fu_79305_p1 = tmp_1388_reg_103497.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1388_fu_79305_p2() {
    mul_ln1118_1388_fu_79305_p2 = (!mul_ln1118_1388_fu_79305_p0.read().is_01() || !mul_ln1118_1388_fu_79305_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1388_fu_79305_p0.read()) * sc_bigint<5>(mul_ln1118_1388_fu_79305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1389_fu_79324_p0() {
    mul_ln1118_1389_fu_79324_p0 =  (sc_lv<12>) (sext_ln1116_189_cast_fu_55627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1389_fu_79324_p1() {
    mul_ln1118_1389_fu_79324_p1 = tmp_1389_reg_103502.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1389_fu_79324_p2() {
    mul_ln1118_1389_fu_79324_p2 = (!mul_ln1118_1389_fu_79324_p0.read().is_01() || !mul_ln1118_1389_fu_79324_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1389_fu_79324_p0.read()) * sc_bigint<5>(mul_ln1118_1389_fu_79324_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_138_fu_54791_p0() {
    mul_ln1118_138_fu_54791_p0 =  (sc_lv<12>) (sext_ln1116_138_cast_fu_54785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_138_fu_54791_p1() {
    mul_ln1118_138_fu_54791_p1 = tmp_138_reg_96934.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_138_fu_54791_p2() {
    mul_ln1118_138_fu_54791_p2 = (!mul_ln1118_138_fu_54791_p0.read().is_01() || !mul_ln1118_138_fu_54791_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_138_fu_54791_p0.read()) * sc_bigint<5>(mul_ln1118_138_fu_54791_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1390_fu_79343_p0() {
    mul_ln1118_1390_fu_79343_p0 =  (sc_lv<12>) (sext_ln1116_190_cast_fu_55649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1390_fu_79343_p1() {
    mul_ln1118_1390_fu_79343_p1 = tmp_1390_reg_103507.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1390_fu_79343_p2() {
    mul_ln1118_1390_fu_79343_p2 = (!mul_ln1118_1390_fu_79343_p0.read().is_01() || !mul_ln1118_1390_fu_79343_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1390_fu_79343_p0.read()) * sc_bigint<5>(mul_ln1118_1390_fu_79343_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1391_fu_79362_p0() {
    mul_ln1118_1391_fu_79362_p0 =  (sc_lv<12>) (sext_ln1116_191_cast_fu_55671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1391_fu_79362_p1() {
    mul_ln1118_1391_fu_79362_p1 = tmp_1391_reg_103512.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1391_fu_79362_p2() {
    mul_ln1118_1391_fu_79362_p2 = (!mul_ln1118_1391_fu_79362_p0.read().is_01() || !mul_ln1118_1391_fu_79362_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1391_fu_79362_p0.read()) * sc_bigint<5>(mul_ln1118_1391_fu_79362_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1392_fu_79381_p0() {
    mul_ln1118_1392_fu_79381_p0 =  (sc_lv<12>) (sext_ln1116_192_cast_fu_55693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1392_fu_79381_p1() {
    mul_ln1118_1392_fu_79381_p1 = tmp_1392_reg_103517.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1392_fu_79381_p2() {
    mul_ln1118_1392_fu_79381_p2 = (!mul_ln1118_1392_fu_79381_p0.read().is_01() || !mul_ln1118_1392_fu_79381_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1392_fu_79381_p0.read()) * sc_bigint<5>(mul_ln1118_1392_fu_79381_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1393_fu_79400_p0() {
    mul_ln1118_1393_fu_79400_p0 =  (sc_lv<12>) (sext_ln1116_193_cast_fu_55715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1393_fu_79400_p1() {
    mul_ln1118_1393_fu_79400_p1 = tmp_1393_reg_103522.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1393_fu_79400_p2() {
    mul_ln1118_1393_fu_79400_p2 = (!mul_ln1118_1393_fu_79400_p0.read().is_01() || !mul_ln1118_1393_fu_79400_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1393_fu_79400_p0.read()) * sc_bigint<5>(mul_ln1118_1393_fu_79400_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1394_fu_79419_p0() {
    mul_ln1118_1394_fu_79419_p0 =  (sc_lv<12>) (sext_ln1116_194_cast_fu_55737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1394_fu_79419_p1() {
    mul_ln1118_1394_fu_79419_p1 = tmp_1394_reg_103527.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1394_fu_79419_p2() {
    mul_ln1118_1394_fu_79419_p2 = (!mul_ln1118_1394_fu_79419_p0.read().is_01() || !mul_ln1118_1394_fu_79419_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1394_fu_79419_p0.read()) * sc_bigint<5>(mul_ln1118_1394_fu_79419_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1395_fu_79438_p0() {
    mul_ln1118_1395_fu_79438_p0 =  (sc_lv<12>) (sext_ln1116_195_cast_fu_55759_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1395_fu_79438_p1() {
    mul_ln1118_1395_fu_79438_p1 = tmp_1395_reg_103532.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1395_fu_79438_p2() {
    mul_ln1118_1395_fu_79438_p2 = (!mul_ln1118_1395_fu_79438_p0.read().is_01() || !mul_ln1118_1395_fu_79438_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1395_fu_79438_p0.read()) * sc_bigint<5>(mul_ln1118_1395_fu_79438_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1396_fu_79457_p0() {
    mul_ln1118_1396_fu_79457_p0 =  (sc_lv<12>) (sext_ln1116_196_cast_fu_55781_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1396_fu_79457_p1() {
    mul_ln1118_1396_fu_79457_p1 = tmp_1396_reg_103537.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1396_fu_79457_p2() {
    mul_ln1118_1396_fu_79457_p2 = (!mul_ln1118_1396_fu_79457_p0.read().is_01() || !mul_ln1118_1396_fu_79457_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1396_fu_79457_p0.read()) * sc_bigint<5>(mul_ln1118_1396_fu_79457_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1397_fu_79476_p0() {
    mul_ln1118_1397_fu_79476_p0 =  (sc_lv<12>) (sext_ln1116_197_cast_fu_55803_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1397_fu_79476_p1() {
    mul_ln1118_1397_fu_79476_p1 = tmp_1397_reg_103542.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1397_fu_79476_p2() {
    mul_ln1118_1397_fu_79476_p2 = (!mul_ln1118_1397_fu_79476_p0.read().is_01() || !mul_ln1118_1397_fu_79476_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1397_fu_79476_p0.read()) * sc_bigint<5>(mul_ln1118_1397_fu_79476_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1398_fu_79495_p0() {
    mul_ln1118_1398_fu_79495_p0 =  (sc_lv<12>) (sext_ln1116_198_cast_fu_55825_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1398_fu_79495_p1() {
    mul_ln1118_1398_fu_79495_p1 = tmp_1398_reg_103547.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1398_fu_79495_p2() {
    mul_ln1118_1398_fu_79495_p2 = (!mul_ln1118_1398_fu_79495_p0.read().is_01() || !mul_ln1118_1398_fu_79495_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1398_fu_79495_p0.read()) * sc_bigint<5>(mul_ln1118_1398_fu_79495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1399_fu_79514_p0() {
    mul_ln1118_1399_fu_79514_p0 =  (sc_lv<12>) (sext_ln1116_199_cast_fu_55847_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1399_fu_79514_p1() {
    mul_ln1118_1399_fu_79514_p1 = tmp_1399_reg_103552.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1399_fu_79514_p2() {
    mul_ln1118_1399_fu_79514_p2 = (!mul_ln1118_1399_fu_79514_p0.read().is_01() || !mul_ln1118_1399_fu_79514_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1399_fu_79514_p0.read()) * sc_bigint<5>(mul_ln1118_1399_fu_79514_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_139_fu_54813_p0() {
    mul_ln1118_139_fu_54813_p0 =  (sc_lv<12>) (sext_ln1116_139_cast_fu_54807_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_139_fu_54813_p1() {
    mul_ln1118_139_fu_54813_p1 = tmp_139_reg_96944.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_139_fu_54813_p2() {
    mul_ln1118_139_fu_54813_p2 = (!mul_ln1118_139_fu_54813_p0.read().is_01() || !mul_ln1118_139_fu_54813_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_139_fu_54813_p0.read()) * sc_bigint<5>(mul_ln1118_139_fu_54813_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_13_fu_52625_p0() {
    mul_ln1118_13_fu_52625_p0 =  (sc_lv<12>) (sext_ln1116_13_cast_fu_52619_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_13_fu_52625_p1() {
    mul_ln1118_13_fu_52625_p1 = tmp_14_reg_95790.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_13_fu_52625_p2() {
    mul_ln1118_13_fu_52625_p2 = (!mul_ln1118_13_fu_52625_p0.read().is_01() || !mul_ln1118_13_fu_52625_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_13_fu_52625_p0.read()) * sc_bigint<5>(mul_ln1118_13_fu_52625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1400_fu_79533_p0() {
    mul_ln1118_1400_fu_79533_p0 =  (sc_lv<12>) (sext_ln1116_200_cast_fu_55869_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1400_fu_79533_p1() {
    mul_ln1118_1400_fu_79533_p1 = tmp_1400_reg_103557.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1400_fu_79533_p2() {
    mul_ln1118_1400_fu_79533_p2 = (!mul_ln1118_1400_fu_79533_p0.read().is_01() || !mul_ln1118_1400_fu_79533_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1400_fu_79533_p0.read()) * sc_bigint<5>(mul_ln1118_1400_fu_79533_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1401_fu_79552_p0() {
    mul_ln1118_1401_fu_79552_p0 =  (sc_lv<12>) (sext_ln1116_201_cast_reg_97536.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1401_fu_79552_p1() {
    mul_ln1118_1401_fu_79552_p1 = tmp_1401_reg_103562.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1401_fu_79552_p2() {
    mul_ln1118_1401_fu_79552_p2 = (!mul_ln1118_1401_fu_79552_p0.read().is_01() || !mul_ln1118_1401_fu_79552_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1401_fu_79552_p0.read()) * sc_bigint<5>(mul_ln1118_1401_fu_79552_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1402_fu_79570_p0() {
    mul_ln1118_1402_fu_79570_p0 =  (sc_lv<12>) (sext_ln1116_202_cast_reg_97554.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1402_fu_79570_p1() {
    mul_ln1118_1402_fu_79570_p1 = tmp_1402_reg_103567.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1402_fu_79570_p2() {
    mul_ln1118_1402_fu_79570_p2 = (!mul_ln1118_1402_fu_79570_p0.read().is_01() || !mul_ln1118_1402_fu_79570_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1402_fu_79570_p0.read()) * sc_bigint<5>(mul_ln1118_1402_fu_79570_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1403_fu_43645_p0() {
    mul_ln1118_1403_fu_43645_p0 =  (sc_lv<12>) (sext_ln1116_203_cast_fu_26297_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1403_fu_43645_p1() {
    mul_ln1118_1403_fu_43645_p1 = tmp_1403_fu_43631_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1403_fu_43645_p2() {
    mul_ln1118_1403_fu_43645_p2 = (!mul_ln1118_1403_fu_43645_p0.read().is_01() || !mul_ln1118_1403_fu_43645_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1403_fu_43645_p0.read()) * sc_bigint<5>(mul_ln1118_1403_fu_43645_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1404_fu_43675_p0() {
    mul_ln1118_1404_fu_43675_p0 =  (sc_lv<12>) (sext_ln1116_204_cast_fu_26339_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1404_fu_43675_p1() {
    mul_ln1118_1404_fu_43675_p1 = tmp_1404_fu_43661_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1404_fu_43675_p2() {
    mul_ln1118_1404_fu_43675_p2 = (!mul_ln1118_1404_fu_43675_p0.read().is_01() || !mul_ln1118_1404_fu_43675_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1404_fu_43675_p0.read()) * sc_bigint<5>(mul_ln1118_1404_fu_43675_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1405_fu_43705_p0() {
    mul_ln1118_1405_fu_43705_p0 =  (sc_lv<12>) (sext_ln1116_205_cast_fu_26381_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1405_fu_43705_p1() {
    mul_ln1118_1405_fu_43705_p1 = tmp_1405_fu_43691_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1405_fu_43705_p2() {
    mul_ln1118_1405_fu_43705_p2 = (!mul_ln1118_1405_fu_43705_p0.read().is_01() || !mul_ln1118_1405_fu_43705_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1405_fu_43705_p0.read()) * sc_bigint<5>(mul_ln1118_1405_fu_43705_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1406_fu_43735_p0() {
    mul_ln1118_1406_fu_43735_p0 =  (sc_lv<12>) (sext_ln1116_206_cast_fu_26423_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1406_fu_43735_p1() {
    mul_ln1118_1406_fu_43735_p1 = tmp_1406_fu_43721_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1406_fu_43735_p2() {
    mul_ln1118_1406_fu_43735_p2 = (!mul_ln1118_1406_fu_43735_p0.read().is_01() || !mul_ln1118_1406_fu_43735_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1406_fu_43735_p0.read()) * sc_bigint<5>(mul_ln1118_1406_fu_43735_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1407_fu_43765_p0() {
    mul_ln1118_1407_fu_43765_p0 =  (sc_lv<12>) (sext_ln1116_207_cast_fu_26465_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1407_fu_43765_p1() {
    mul_ln1118_1407_fu_43765_p1 = tmp_1407_fu_43751_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1407_fu_43765_p2() {
    mul_ln1118_1407_fu_43765_p2 = (!mul_ln1118_1407_fu_43765_p0.read().is_01() || !mul_ln1118_1407_fu_43765_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1407_fu_43765_p0.read()) * sc_bigint<5>(mul_ln1118_1407_fu_43765_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1408_fu_43795_p0() {
    mul_ln1118_1408_fu_43795_p0 =  (sc_lv<12>) (sext_ln1116_208_cast_fu_26507_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1408_fu_43795_p1() {
    mul_ln1118_1408_fu_43795_p1 = tmp_1408_fu_43781_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1408_fu_43795_p2() {
    mul_ln1118_1408_fu_43795_p2 = (!mul_ln1118_1408_fu_43795_p0.read().is_01() || !mul_ln1118_1408_fu_43795_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1408_fu_43795_p0.read()) * sc_bigint<5>(mul_ln1118_1408_fu_43795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1409_fu_80576_p0() {
    mul_ln1118_1409_fu_80576_p0 =  (sc_lv<12>) (sext_ln1116_cast_fu_52531_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1409_fu_80576_p1() {
    mul_ln1118_1409_fu_80576_p1 = tmp_1409_reg_103602.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1409_fu_80576_p2() {
    mul_ln1118_1409_fu_80576_p2 = (!mul_ln1118_1409_fu_80576_p0.read().is_01() || !mul_ln1118_1409_fu_80576_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1409_fu_80576_p0.read()) * sc_bigint<5>(mul_ln1118_1409_fu_80576_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_140_fu_54835_p0() {
    mul_ln1118_140_fu_54835_p0 =  (sc_lv<12>) (sext_ln1116_140_cast_fu_54829_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_140_fu_54835_p1() {
    mul_ln1118_140_fu_54835_p1 = tmp_140_reg_96954.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_140_fu_54835_p2() {
    mul_ln1118_140_fu_54835_p2 = (!mul_ln1118_140_fu_54835_p0.read().is_01() || !mul_ln1118_140_fu_54835_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_140_fu_54835_p0.read()) * sc_bigint<5>(mul_ln1118_140_fu_54835_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1410_fu_80595_p0() {
    mul_ln1118_1410_fu_80595_p0 =  (sc_lv<12>) (sext_ln1116_10_cast_fu_52553_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1410_fu_80595_p1() {
    mul_ln1118_1410_fu_80595_p1 = tmp_1410_reg_103607.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1410_fu_80595_p2() {
    mul_ln1118_1410_fu_80595_p2 = (!mul_ln1118_1410_fu_80595_p0.read().is_01() || !mul_ln1118_1410_fu_80595_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1410_fu_80595_p0.read()) * sc_bigint<5>(mul_ln1118_1410_fu_80595_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1411_fu_80614_p0() {
    mul_ln1118_1411_fu_80614_p0 =  (sc_lv<12>) (sext_ln1116_11_cast_fu_52575_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1411_fu_80614_p1() {
    mul_ln1118_1411_fu_80614_p1 = tmp_1411_reg_103612.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1411_fu_80614_p2() {
    mul_ln1118_1411_fu_80614_p2 = (!mul_ln1118_1411_fu_80614_p0.read().is_01() || !mul_ln1118_1411_fu_80614_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1411_fu_80614_p0.read()) * sc_bigint<5>(mul_ln1118_1411_fu_80614_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1412_fu_80633_p0() {
    mul_ln1118_1412_fu_80633_p0 =  (sc_lv<12>) (sext_ln1116_12_cast_fu_52597_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1412_fu_80633_p1() {
    mul_ln1118_1412_fu_80633_p1 = tmp_1412_reg_103617.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1412_fu_80633_p2() {
    mul_ln1118_1412_fu_80633_p2 = (!mul_ln1118_1412_fu_80633_p0.read().is_01() || !mul_ln1118_1412_fu_80633_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1412_fu_80633_p0.read()) * sc_bigint<5>(mul_ln1118_1412_fu_80633_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1413_fu_80652_p0() {
    mul_ln1118_1413_fu_80652_p0 =  (sc_lv<12>) (sext_ln1116_13_cast_fu_52619_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1413_fu_80652_p1() {
    mul_ln1118_1413_fu_80652_p1 = tmp_1413_reg_103622.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1413_fu_80652_p2() {
    mul_ln1118_1413_fu_80652_p2 = (!mul_ln1118_1413_fu_80652_p0.read().is_01() || !mul_ln1118_1413_fu_80652_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1413_fu_80652_p0.read()) * sc_bigint<5>(mul_ln1118_1413_fu_80652_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1414_fu_80671_p0() {
    mul_ln1118_1414_fu_80671_p0 =  (sc_lv<12>) (sext_ln1116_14_cast_fu_52641_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1414_fu_80671_p1() {
    mul_ln1118_1414_fu_80671_p1 = tmp_1414_reg_103627.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1414_fu_80671_p2() {
    mul_ln1118_1414_fu_80671_p2 = (!mul_ln1118_1414_fu_80671_p0.read().is_01() || !mul_ln1118_1414_fu_80671_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1414_fu_80671_p0.read()) * sc_bigint<5>(mul_ln1118_1414_fu_80671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1415_fu_80690_p0() {
    mul_ln1118_1415_fu_80690_p0 =  (sc_lv<12>) (sext_ln1116_15_cast_fu_52663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1415_fu_80690_p1() {
    mul_ln1118_1415_fu_80690_p1 = tmp_1415_reg_103632.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1415_fu_80690_p2() {
    mul_ln1118_1415_fu_80690_p2 = (!mul_ln1118_1415_fu_80690_p0.read().is_01() || !mul_ln1118_1415_fu_80690_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1415_fu_80690_p0.read()) * sc_bigint<5>(mul_ln1118_1415_fu_80690_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1416_fu_80709_p0() {
    mul_ln1118_1416_fu_80709_p0 =  (sc_lv<12>) (sext_ln1116_16_cast_fu_52685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1416_fu_80709_p1() {
    mul_ln1118_1416_fu_80709_p1 = tmp_1416_reg_103637.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1416_fu_80709_p2() {
    mul_ln1118_1416_fu_80709_p2 = (!mul_ln1118_1416_fu_80709_p0.read().is_01() || !mul_ln1118_1416_fu_80709_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1416_fu_80709_p0.read()) * sc_bigint<5>(mul_ln1118_1416_fu_80709_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1417_fu_80728_p0() {
    mul_ln1118_1417_fu_80728_p0 =  (sc_lv<12>) (sext_ln1116_17_cast_fu_52707_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1417_fu_80728_p1() {
    mul_ln1118_1417_fu_80728_p1 = tmp_1417_reg_103642.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1417_fu_80728_p2() {
    mul_ln1118_1417_fu_80728_p2 = (!mul_ln1118_1417_fu_80728_p0.read().is_01() || !mul_ln1118_1417_fu_80728_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1417_fu_80728_p0.read()) * sc_bigint<5>(mul_ln1118_1417_fu_80728_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1418_fu_80747_p0() {
    mul_ln1118_1418_fu_80747_p0 =  (sc_lv<12>) (sext_ln1116_18_cast_fu_52729_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1418_fu_80747_p1() {
    mul_ln1118_1418_fu_80747_p1 = tmp_1418_reg_103647.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1418_fu_80747_p2() {
    mul_ln1118_1418_fu_80747_p2 = (!mul_ln1118_1418_fu_80747_p0.read().is_01() || !mul_ln1118_1418_fu_80747_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1418_fu_80747_p0.read()) * sc_bigint<5>(mul_ln1118_1418_fu_80747_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1419_fu_80766_p0() {
    mul_ln1118_1419_fu_80766_p0 =  (sc_lv<12>) (sext_ln1116_19_cast_fu_52751_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1419_fu_80766_p1() {
    mul_ln1118_1419_fu_80766_p1 = tmp_1419_reg_103652.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1419_fu_80766_p2() {
    mul_ln1118_1419_fu_80766_p2 = (!mul_ln1118_1419_fu_80766_p0.read().is_01() || !mul_ln1118_1419_fu_80766_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1419_fu_80766_p0.read()) * sc_bigint<5>(mul_ln1118_1419_fu_80766_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_141_fu_54857_p0() {
    mul_ln1118_141_fu_54857_p0 =  (sc_lv<12>) (sext_ln1116_141_cast_fu_54851_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_141_fu_54857_p1() {
    mul_ln1118_141_fu_54857_p1 = tmp_141_reg_96964.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_141_fu_54857_p2() {
    mul_ln1118_141_fu_54857_p2 = (!mul_ln1118_141_fu_54857_p0.read().is_01() || !mul_ln1118_141_fu_54857_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_141_fu_54857_p0.read()) * sc_bigint<5>(mul_ln1118_141_fu_54857_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1420_fu_80785_p0() {
    mul_ln1118_1420_fu_80785_p0 =  (sc_lv<12>) (sext_ln1116_20_cast_fu_52773_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1420_fu_80785_p1() {
    mul_ln1118_1420_fu_80785_p1 = tmp_1420_reg_103657.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1420_fu_80785_p2() {
    mul_ln1118_1420_fu_80785_p2 = (!mul_ln1118_1420_fu_80785_p0.read().is_01() || !mul_ln1118_1420_fu_80785_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1420_fu_80785_p0.read()) * sc_bigint<5>(mul_ln1118_1420_fu_80785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1421_fu_80804_p0() {
    mul_ln1118_1421_fu_80804_p0 =  (sc_lv<12>) (sext_ln1116_21_cast_fu_52795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1421_fu_80804_p1() {
    mul_ln1118_1421_fu_80804_p1 = tmp_1421_reg_103662.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1421_fu_80804_p2() {
    mul_ln1118_1421_fu_80804_p2 = (!mul_ln1118_1421_fu_80804_p0.read().is_01() || !mul_ln1118_1421_fu_80804_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1421_fu_80804_p0.read()) * sc_bigint<5>(mul_ln1118_1421_fu_80804_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1422_fu_80823_p0() {
    mul_ln1118_1422_fu_80823_p0 =  (sc_lv<12>) (sext_ln1116_22_cast_fu_52817_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1422_fu_80823_p1() {
    mul_ln1118_1422_fu_80823_p1 = tmp_1422_reg_103667.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1422_fu_80823_p2() {
    mul_ln1118_1422_fu_80823_p2 = (!mul_ln1118_1422_fu_80823_p0.read().is_01() || !mul_ln1118_1422_fu_80823_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1422_fu_80823_p0.read()) * sc_bigint<5>(mul_ln1118_1422_fu_80823_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1423_fu_80842_p0() {
    mul_ln1118_1423_fu_80842_p0 =  (sc_lv<12>) (sext_ln1116_23_cast_fu_52839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1423_fu_80842_p1() {
    mul_ln1118_1423_fu_80842_p1 = tmp_1423_reg_103672.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1423_fu_80842_p2() {
    mul_ln1118_1423_fu_80842_p2 = (!mul_ln1118_1423_fu_80842_p0.read().is_01() || !mul_ln1118_1423_fu_80842_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1423_fu_80842_p0.read()) * sc_bigint<5>(mul_ln1118_1423_fu_80842_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1424_fu_80861_p0() {
    mul_ln1118_1424_fu_80861_p0 =  (sc_lv<12>) (sext_ln1116_24_cast_fu_52861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1424_fu_80861_p1() {
    mul_ln1118_1424_fu_80861_p1 = tmp_1424_reg_103677.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1424_fu_80861_p2() {
    mul_ln1118_1424_fu_80861_p2 = (!mul_ln1118_1424_fu_80861_p0.read().is_01() || !mul_ln1118_1424_fu_80861_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1424_fu_80861_p0.read()) * sc_bigint<5>(mul_ln1118_1424_fu_80861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1425_fu_80880_p0() {
    mul_ln1118_1425_fu_80880_p0 =  (sc_lv<12>) (sext_ln1116_25_cast_fu_52883_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1425_fu_80880_p1() {
    mul_ln1118_1425_fu_80880_p1 = tmp_1425_reg_103682.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1425_fu_80880_p2() {
    mul_ln1118_1425_fu_80880_p2 = (!mul_ln1118_1425_fu_80880_p0.read().is_01() || !mul_ln1118_1425_fu_80880_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1425_fu_80880_p0.read()) * sc_bigint<5>(mul_ln1118_1425_fu_80880_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1426_fu_80899_p0() {
    mul_ln1118_1426_fu_80899_p0 =  (sc_lv<12>) (sext_ln1116_26_cast_fu_52905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1426_fu_80899_p1() {
    mul_ln1118_1426_fu_80899_p1 = tmp_1426_reg_103687.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1426_fu_80899_p2() {
    mul_ln1118_1426_fu_80899_p2 = (!mul_ln1118_1426_fu_80899_p0.read().is_01() || !mul_ln1118_1426_fu_80899_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1426_fu_80899_p0.read()) * sc_bigint<5>(mul_ln1118_1426_fu_80899_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1427_fu_80918_p0() {
    mul_ln1118_1427_fu_80918_p0 =  (sc_lv<12>) (sext_ln1116_27_cast_fu_52927_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1427_fu_80918_p1() {
    mul_ln1118_1427_fu_80918_p1 = tmp_1427_reg_103692.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1427_fu_80918_p2() {
    mul_ln1118_1427_fu_80918_p2 = (!mul_ln1118_1427_fu_80918_p0.read().is_01() || !mul_ln1118_1427_fu_80918_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1427_fu_80918_p0.read()) * sc_bigint<5>(mul_ln1118_1427_fu_80918_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1428_fu_44015_p0() {
    mul_ln1118_1428_fu_44015_p0 =  (sc_lv<12>) (sext_ln1116_28_cast_fu_22199_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1428_fu_44015_p1() {
    mul_ln1118_1428_fu_44015_p1 = tmp_1428_fu_44001_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1428_fu_44015_p2() {
    mul_ln1118_1428_fu_44015_p2 = (!mul_ln1118_1428_fu_44015_p0.read().is_01() || !mul_ln1118_1428_fu_44015_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1428_fu_44015_p0.read()) * sc_bigint<5>(mul_ln1118_1428_fu_44015_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1429_fu_44045_p0() {
    mul_ln1118_1429_fu_44045_p0 =  (sc_lv<12>) (sext_ln1116_29_cast_fu_22241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1429_fu_44045_p1() {
    mul_ln1118_1429_fu_44045_p1 = tmp_1429_fu_44031_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1429_fu_44045_p2() {
    mul_ln1118_1429_fu_44045_p2 = (!mul_ln1118_1429_fu_44045_p0.read().is_01() || !mul_ln1118_1429_fu_44045_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1429_fu_44045_p0.read()) * sc_bigint<5>(mul_ln1118_1429_fu_44045_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_142_fu_54879_p0() {
    mul_ln1118_142_fu_54879_p0 =  (sc_lv<12>) (sext_ln1116_142_cast_fu_54873_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_142_fu_54879_p1() {
    mul_ln1118_142_fu_54879_p1 = tmp_142_reg_96974.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_142_fu_54879_p2() {
    mul_ln1118_142_fu_54879_p2 = (!mul_ln1118_142_fu_54879_p0.read().is_01() || !mul_ln1118_142_fu_54879_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_142_fu_54879_p0.read()) * sc_bigint<5>(mul_ln1118_142_fu_54879_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1430_fu_44075_p0() {
    mul_ln1118_1430_fu_44075_p0 =  (sc_lv<12>) (sext_ln1116_30_cast_fu_22283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1430_fu_44075_p1() {
    mul_ln1118_1430_fu_44075_p1 = tmp_1430_fu_44061_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1430_fu_44075_p2() {
    mul_ln1118_1430_fu_44075_p2 = (!mul_ln1118_1430_fu_44075_p0.read().is_01() || !mul_ln1118_1430_fu_44075_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1430_fu_44075_p0.read()) * sc_bigint<5>(mul_ln1118_1430_fu_44075_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1431_fu_44105_p0() {
    mul_ln1118_1431_fu_44105_p0 =  (sc_lv<12>) (sext_ln1116_31_cast_fu_22325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1431_fu_44105_p1() {
    mul_ln1118_1431_fu_44105_p1 = tmp_1431_fu_44091_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1431_fu_44105_p2() {
    mul_ln1118_1431_fu_44105_p2 = (!mul_ln1118_1431_fu_44105_p0.read().is_01() || !mul_ln1118_1431_fu_44105_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1431_fu_44105_p0.read()) * sc_bigint<5>(mul_ln1118_1431_fu_44105_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1432_fu_44135_p0() {
    mul_ln1118_1432_fu_44135_p0 =  (sc_lv<12>) (sext_ln1116_32_cast_fu_22367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1432_fu_44135_p1() {
    mul_ln1118_1432_fu_44135_p1 = tmp_1432_fu_44121_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1432_fu_44135_p2() {
    mul_ln1118_1432_fu_44135_p2 = (!mul_ln1118_1432_fu_44135_p0.read().is_01() || !mul_ln1118_1432_fu_44135_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1432_fu_44135_p0.read()) * sc_bigint<5>(mul_ln1118_1432_fu_44135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1433_fu_44165_p0() {
    mul_ln1118_1433_fu_44165_p0 =  (sc_lv<12>) (sext_ln1116_33_cast_fu_22409_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1433_fu_44165_p1() {
    mul_ln1118_1433_fu_44165_p1 = tmp_1433_fu_44151_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1433_fu_44165_p2() {
    mul_ln1118_1433_fu_44165_p2 = (!mul_ln1118_1433_fu_44165_p0.read().is_01() || !mul_ln1118_1433_fu_44165_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1433_fu_44165_p0.read()) * sc_bigint<5>(mul_ln1118_1433_fu_44165_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1434_fu_80937_p0() {
    mul_ln1118_1434_fu_80937_p0 =  (sc_lv<12>) (sext_ln1116_34_cast_fu_52949_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1434_fu_80937_p1() {
    mul_ln1118_1434_fu_80937_p1 = tmp_1434_reg_103727.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1434_fu_80937_p2() {
    mul_ln1118_1434_fu_80937_p2 = (!mul_ln1118_1434_fu_80937_p0.read().is_01() || !mul_ln1118_1434_fu_80937_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1434_fu_80937_p0.read()) * sc_bigint<5>(mul_ln1118_1434_fu_80937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1435_fu_80956_p0() {
    mul_ln1118_1435_fu_80956_p0 =  (sc_lv<12>) (sext_ln1116_35_cast_fu_52971_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1435_fu_80956_p1() {
    mul_ln1118_1435_fu_80956_p1 = tmp_1435_reg_103732.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1435_fu_80956_p2() {
    mul_ln1118_1435_fu_80956_p2 = (!mul_ln1118_1435_fu_80956_p0.read().is_01() || !mul_ln1118_1435_fu_80956_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1435_fu_80956_p0.read()) * sc_bigint<5>(mul_ln1118_1435_fu_80956_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1436_fu_80975_p0() {
    mul_ln1118_1436_fu_80975_p0 =  (sc_lv<12>) (sext_ln1116_36_cast_fu_52993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1436_fu_80975_p1() {
    mul_ln1118_1436_fu_80975_p1 = tmp_1436_reg_103737.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1436_fu_80975_p2() {
    mul_ln1118_1436_fu_80975_p2 = (!mul_ln1118_1436_fu_80975_p0.read().is_01() || !mul_ln1118_1436_fu_80975_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1436_fu_80975_p0.read()) * sc_bigint<5>(mul_ln1118_1436_fu_80975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1437_fu_80994_p0() {
    mul_ln1118_1437_fu_80994_p0 =  (sc_lv<12>) (sext_ln1116_37_cast_fu_53015_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1437_fu_80994_p1() {
    mul_ln1118_1437_fu_80994_p1 = tmp_1437_reg_103742.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1437_fu_80994_p2() {
    mul_ln1118_1437_fu_80994_p2 = (!mul_ln1118_1437_fu_80994_p0.read().is_01() || !mul_ln1118_1437_fu_80994_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1437_fu_80994_p0.read()) * sc_bigint<5>(mul_ln1118_1437_fu_80994_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1438_fu_81013_p0() {
    mul_ln1118_1438_fu_81013_p0 =  (sc_lv<12>) (sext_ln1116_38_cast_fu_53037_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1438_fu_81013_p1() {
    mul_ln1118_1438_fu_81013_p1 = tmp_1438_reg_103747.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1438_fu_81013_p2() {
    mul_ln1118_1438_fu_81013_p2 = (!mul_ln1118_1438_fu_81013_p0.read().is_01() || !mul_ln1118_1438_fu_81013_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1438_fu_81013_p0.read()) * sc_bigint<5>(mul_ln1118_1438_fu_81013_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1439_fu_81032_p0() {
    mul_ln1118_1439_fu_81032_p0 =  (sc_lv<12>) (sext_ln1116_39_cast_fu_53059_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1439_fu_81032_p1() {
    mul_ln1118_1439_fu_81032_p1 = tmp_1439_reg_103752.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1439_fu_81032_p2() {
    mul_ln1118_1439_fu_81032_p2 = (!mul_ln1118_1439_fu_81032_p0.read().is_01() || !mul_ln1118_1439_fu_81032_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1439_fu_81032_p0.read()) * sc_bigint<5>(mul_ln1118_1439_fu_81032_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_143_fu_54901_p0() {
    mul_ln1118_143_fu_54901_p0 =  (sc_lv<12>) (sext_ln1116_143_cast_fu_54895_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_143_fu_54901_p1() {
    mul_ln1118_143_fu_54901_p1 = tmp_143_reg_96984.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_143_fu_54901_p2() {
    mul_ln1118_143_fu_54901_p2 = (!mul_ln1118_143_fu_54901_p0.read().is_01() || !mul_ln1118_143_fu_54901_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_143_fu_54901_p0.read()) * sc_bigint<5>(mul_ln1118_143_fu_54901_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1440_fu_81051_p0() {
    mul_ln1118_1440_fu_81051_p0 =  (sc_lv<12>) (sext_ln1116_40_cast_fu_53081_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1440_fu_81051_p1() {
    mul_ln1118_1440_fu_81051_p1 = tmp_1440_reg_103757.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1440_fu_81051_p2() {
    mul_ln1118_1440_fu_81051_p2 = (!mul_ln1118_1440_fu_81051_p0.read().is_01() || !mul_ln1118_1440_fu_81051_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1440_fu_81051_p0.read()) * sc_bigint<5>(mul_ln1118_1440_fu_81051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1441_fu_81070_p0() {
    mul_ln1118_1441_fu_81070_p0 =  (sc_lv<12>) (sext_ln1116_41_cast_fu_53103_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1441_fu_81070_p1() {
    mul_ln1118_1441_fu_81070_p1 = tmp_1441_reg_103762.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1441_fu_81070_p2() {
    mul_ln1118_1441_fu_81070_p2 = (!mul_ln1118_1441_fu_81070_p0.read().is_01() || !mul_ln1118_1441_fu_81070_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1441_fu_81070_p0.read()) * sc_bigint<5>(mul_ln1118_1441_fu_81070_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1442_fu_81089_p0() {
    mul_ln1118_1442_fu_81089_p0 =  (sc_lv<12>) (sext_ln1116_42_cast_fu_53125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1442_fu_81089_p1() {
    mul_ln1118_1442_fu_81089_p1 = tmp_1442_reg_103767.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1442_fu_81089_p2() {
    mul_ln1118_1442_fu_81089_p2 = (!mul_ln1118_1442_fu_81089_p0.read().is_01() || !mul_ln1118_1442_fu_81089_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1442_fu_81089_p0.read()) * sc_bigint<5>(mul_ln1118_1442_fu_81089_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1443_fu_81108_p0() {
    mul_ln1118_1443_fu_81108_p0 =  (sc_lv<12>) (sext_ln1116_43_cast_fu_53147_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1443_fu_81108_p1() {
    mul_ln1118_1443_fu_81108_p1 = tmp_1443_reg_103772.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1443_fu_81108_p2() {
    mul_ln1118_1443_fu_81108_p2 = (!mul_ln1118_1443_fu_81108_p0.read().is_01() || !mul_ln1118_1443_fu_81108_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1443_fu_81108_p0.read()) * sc_bigint<5>(mul_ln1118_1443_fu_81108_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1444_fu_81127_p0() {
    mul_ln1118_1444_fu_81127_p0 =  (sc_lv<12>) (sext_ln1116_44_cast_fu_53169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1444_fu_81127_p1() {
    mul_ln1118_1444_fu_81127_p1 = tmp_1444_reg_103777.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1444_fu_81127_p2() {
    mul_ln1118_1444_fu_81127_p2 = (!mul_ln1118_1444_fu_81127_p0.read().is_01() || !mul_ln1118_1444_fu_81127_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1444_fu_81127_p0.read()) * sc_bigint<5>(mul_ln1118_1444_fu_81127_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1445_fu_81146_p0() {
    mul_ln1118_1445_fu_81146_p0 =  (sc_lv<12>) (sext_ln1116_45_cast_fu_53191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1445_fu_81146_p1() {
    mul_ln1118_1445_fu_81146_p1 = tmp_1445_reg_103782.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1445_fu_81146_p2() {
    mul_ln1118_1445_fu_81146_p2 = (!mul_ln1118_1445_fu_81146_p0.read().is_01() || !mul_ln1118_1445_fu_81146_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1445_fu_81146_p0.read()) * sc_bigint<5>(mul_ln1118_1445_fu_81146_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1446_fu_81165_p0() {
    mul_ln1118_1446_fu_81165_p0 =  (sc_lv<12>) (sext_ln1116_46_cast_fu_53213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1446_fu_81165_p1() {
    mul_ln1118_1446_fu_81165_p1 = tmp_1446_reg_103787.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1446_fu_81165_p2() {
    mul_ln1118_1446_fu_81165_p2 = (!mul_ln1118_1446_fu_81165_p0.read().is_01() || !mul_ln1118_1446_fu_81165_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1446_fu_81165_p0.read()) * sc_bigint<5>(mul_ln1118_1446_fu_81165_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1447_fu_81184_p0() {
    mul_ln1118_1447_fu_81184_p0 =  (sc_lv<12>) (sext_ln1116_47_cast_fu_53235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1447_fu_81184_p1() {
    mul_ln1118_1447_fu_81184_p1 = tmp_1447_reg_103792.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1447_fu_81184_p2() {
    mul_ln1118_1447_fu_81184_p2 = (!mul_ln1118_1447_fu_81184_p0.read().is_01() || !mul_ln1118_1447_fu_81184_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1447_fu_81184_p0.read()) * sc_bigint<5>(mul_ln1118_1447_fu_81184_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1448_fu_81203_p0() {
    mul_ln1118_1448_fu_81203_p0 =  (sc_lv<12>) (sext_ln1116_48_cast_fu_53257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1448_fu_81203_p1() {
    mul_ln1118_1448_fu_81203_p1 = tmp_1448_reg_103797.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1448_fu_81203_p2() {
    mul_ln1118_1448_fu_81203_p2 = (!mul_ln1118_1448_fu_81203_p0.read().is_01() || !mul_ln1118_1448_fu_81203_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1448_fu_81203_p0.read()) * sc_bigint<5>(mul_ln1118_1448_fu_81203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1449_fu_81222_p0() {
    mul_ln1118_1449_fu_81222_p0 =  (sc_lv<12>) (sext_ln1116_49_cast_fu_53279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1449_fu_81222_p1() {
    mul_ln1118_1449_fu_81222_p1 = tmp_1449_reg_103802.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1449_fu_81222_p2() {
    mul_ln1118_1449_fu_81222_p2 = (!mul_ln1118_1449_fu_81222_p0.read().is_01() || !mul_ln1118_1449_fu_81222_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1449_fu_81222_p0.read()) * sc_bigint<5>(mul_ln1118_1449_fu_81222_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_144_fu_54923_p0() {
    mul_ln1118_144_fu_54923_p0 =  (sc_lv<12>) (sext_ln1116_144_cast_fu_54917_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_144_fu_54923_p1() {
    mul_ln1118_144_fu_54923_p1 = tmp_144_reg_96994.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_144_fu_54923_p2() {
    mul_ln1118_144_fu_54923_p2 = (!mul_ln1118_144_fu_54923_p0.read().is_01() || !mul_ln1118_144_fu_54923_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_144_fu_54923_p0.read()) * sc_bigint<5>(mul_ln1118_144_fu_54923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1450_fu_81241_p0() {
    mul_ln1118_1450_fu_81241_p0 =  (sc_lv<12>) (sext_ln1116_50_cast_fu_53301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1450_fu_81241_p1() {
    mul_ln1118_1450_fu_81241_p1 = tmp_1450_reg_103807.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1450_fu_81241_p2() {
    mul_ln1118_1450_fu_81241_p2 = (!mul_ln1118_1450_fu_81241_p0.read().is_01() || !mul_ln1118_1450_fu_81241_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1450_fu_81241_p0.read()) * sc_bigint<5>(mul_ln1118_1450_fu_81241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1451_fu_81260_p0() {
    mul_ln1118_1451_fu_81260_p0 =  (sc_lv<12>) (sext_ln1116_51_cast_fu_53323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1451_fu_81260_p1() {
    mul_ln1118_1451_fu_81260_p1 = tmp_1451_reg_103812.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1451_fu_81260_p2() {
    mul_ln1118_1451_fu_81260_p2 = (!mul_ln1118_1451_fu_81260_p0.read().is_01() || !mul_ln1118_1451_fu_81260_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1451_fu_81260_p0.read()) * sc_bigint<5>(mul_ln1118_1451_fu_81260_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1452_fu_81279_p0() {
    mul_ln1118_1452_fu_81279_p0 =  (sc_lv<12>) (sext_ln1116_52_cast_reg_96150.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1452_fu_81279_p1() {
    mul_ln1118_1452_fu_81279_p1 = tmp_1452_reg_103817.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1452_fu_81279_p2() {
    mul_ln1118_1452_fu_81279_p2 = (!mul_ln1118_1452_fu_81279_p0.read().is_01() || !mul_ln1118_1452_fu_81279_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1452_fu_81279_p0.read()) * sc_bigint<5>(mul_ln1118_1452_fu_81279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1453_fu_44385_p0() {
    mul_ln1118_1453_fu_44385_p0 =  (sc_lv<12>) (sext_ln1116_53_cast_fu_22797_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1453_fu_44385_p1() {
    mul_ln1118_1453_fu_44385_p1 = tmp_1453_fu_44371_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1453_fu_44385_p2() {
    mul_ln1118_1453_fu_44385_p2 = (!mul_ln1118_1453_fu_44385_p0.read().is_01() || !mul_ln1118_1453_fu_44385_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1453_fu_44385_p0.read()) * sc_bigint<5>(mul_ln1118_1453_fu_44385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1454_fu_44415_p0() {
    mul_ln1118_1454_fu_44415_p0 =  (sc_lv<12>) (sext_ln1116_54_cast_fu_22839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1454_fu_44415_p1() {
    mul_ln1118_1454_fu_44415_p1 = tmp_1454_fu_44401_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1454_fu_44415_p2() {
    mul_ln1118_1454_fu_44415_p2 = (!mul_ln1118_1454_fu_44415_p0.read().is_01() || !mul_ln1118_1454_fu_44415_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1454_fu_44415_p0.read()) * sc_bigint<5>(mul_ln1118_1454_fu_44415_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1455_fu_44445_p0() {
    mul_ln1118_1455_fu_44445_p0 =  (sc_lv<12>) (sext_ln1116_55_cast_fu_22881_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1455_fu_44445_p1() {
    mul_ln1118_1455_fu_44445_p1 = tmp_1455_fu_44431_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1455_fu_44445_p2() {
    mul_ln1118_1455_fu_44445_p2 = (!mul_ln1118_1455_fu_44445_p0.read().is_01() || !mul_ln1118_1455_fu_44445_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1455_fu_44445_p0.read()) * sc_bigint<5>(mul_ln1118_1455_fu_44445_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1456_fu_44475_p0() {
    mul_ln1118_1456_fu_44475_p0 =  (sc_lv<12>) (sext_ln1116_56_cast_fu_22923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1456_fu_44475_p1() {
    mul_ln1118_1456_fu_44475_p1 = tmp_1456_fu_44461_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1456_fu_44475_p2() {
    mul_ln1118_1456_fu_44475_p2 = (!mul_ln1118_1456_fu_44475_p0.read().is_01() || !mul_ln1118_1456_fu_44475_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1456_fu_44475_p0.read()) * sc_bigint<5>(mul_ln1118_1456_fu_44475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1457_fu_44505_p0() {
    mul_ln1118_1457_fu_44505_p0 =  (sc_lv<12>) (sext_ln1116_57_cast_fu_22965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1457_fu_44505_p1() {
    mul_ln1118_1457_fu_44505_p1 = tmp_1457_fu_44491_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1457_fu_44505_p2() {
    mul_ln1118_1457_fu_44505_p2 = (!mul_ln1118_1457_fu_44505_p0.read().is_01() || !mul_ln1118_1457_fu_44505_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1457_fu_44505_p0.read()) * sc_bigint<5>(mul_ln1118_1457_fu_44505_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1458_fu_44535_p0() {
    mul_ln1118_1458_fu_44535_p0 =  (sc_lv<12>) (sext_ln1116_58_cast_fu_23007_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1458_fu_44535_p1() {
    mul_ln1118_1458_fu_44535_p1 = tmp_1458_fu_44521_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1458_fu_44535_p2() {
    mul_ln1118_1458_fu_44535_p2 = (!mul_ln1118_1458_fu_44535_p0.read().is_01() || !mul_ln1118_1458_fu_44535_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1458_fu_44535_p0.read()) * sc_bigint<5>(mul_ln1118_1458_fu_44535_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1459_fu_81297_p0() {
    mul_ln1118_1459_fu_81297_p0 =  (sc_lv<12>) (sext_ln1116_59_cast_fu_53363_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1459_fu_81297_p1() {
    mul_ln1118_1459_fu_81297_p1 = tmp_1459_reg_103852.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1459_fu_81297_p2() {
    mul_ln1118_1459_fu_81297_p2 = (!mul_ln1118_1459_fu_81297_p0.read().is_01() || !mul_ln1118_1459_fu_81297_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1459_fu_81297_p0.read()) * sc_bigint<5>(mul_ln1118_1459_fu_81297_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_145_fu_54945_p0() {
    mul_ln1118_145_fu_54945_p0 =  (sc_lv<12>) (sext_ln1116_145_cast_fu_54939_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_145_fu_54945_p1() {
    mul_ln1118_145_fu_54945_p1 = tmp_145_reg_97004.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_145_fu_54945_p2() {
    mul_ln1118_145_fu_54945_p2 = (!mul_ln1118_145_fu_54945_p0.read().is_01() || !mul_ln1118_145_fu_54945_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_145_fu_54945_p0.read()) * sc_bigint<5>(mul_ln1118_145_fu_54945_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1460_fu_81316_p0() {
    mul_ln1118_1460_fu_81316_p0 =  (sc_lv<12>) (sext_ln1116_60_cast_fu_53385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1460_fu_81316_p1() {
    mul_ln1118_1460_fu_81316_p1 = tmp_1460_reg_103857.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1460_fu_81316_p2() {
    mul_ln1118_1460_fu_81316_p2 = (!mul_ln1118_1460_fu_81316_p0.read().is_01() || !mul_ln1118_1460_fu_81316_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1460_fu_81316_p0.read()) * sc_bigint<5>(mul_ln1118_1460_fu_81316_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1461_fu_81335_p0() {
    mul_ln1118_1461_fu_81335_p0 =  (sc_lv<12>) (sext_ln1116_61_cast_fu_53407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1461_fu_81335_p1() {
    mul_ln1118_1461_fu_81335_p1 = tmp_1461_reg_103862.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1461_fu_81335_p2() {
    mul_ln1118_1461_fu_81335_p2 = (!mul_ln1118_1461_fu_81335_p0.read().is_01() || !mul_ln1118_1461_fu_81335_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1461_fu_81335_p0.read()) * sc_bigint<5>(mul_ln1118_1461_fu_81335_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1462_fu_81354_p0() {
    mul_ln1118_1462_fu_81354_p0 =  (sc_lv<12>) (sext_ln1116_62_cast_fu_53429_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1462_fu_81354_p1() {
    mul_ln1118_1462_fu_81354_p1 = tmp_1462_reg_103867.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1462_fu_81354_p2() {
    mul_ln1118_1462_fu_81354_p2 = (!mul_ln1118_1462_fu_81354_p0.read().is_01() || !mul_ln1118_1462_fu_81354_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1462_fu_81354_p0.read()) * sc_bigint<5>(mul_ln1118_1462_fu_81354_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1463_fu_81373_p0() {
    mul_ln1118_1463_fu_81373_p0 =  (sc_lv<12>) (sext_ln1116_63_cast_fu_53451_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1463_fu_81373_p1() {
    mul_ln1118_1463_fu_81373_p1 = tmp_1463_reg_103872.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1463_fu_81373_p2() {
    mul_ln1118_1463_fu_81373_p2 = (!mul_ln1118_1463_fu_81373_p0.read().is_01() || !mul_ln1118_1463_fu_81373_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1463_fu_81373_p0.read()) * sc_bigint<5>(mul_ln1118_1463_fu_81373_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1464_fu_81392_p0() {
    mul_ln1118_1464_fu_81392_p0 =  (sc_lv<12>) (sext_ln1116_64_cast_fu_53473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1464_fu_81392_p1() {
    mul_ln1118_1464_fu_81392_p1 = tmp_1464_reg_103877.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1464_fu_81392_p2() {
    mul_ln1118_1464_fu_81392_p2 = (!mul_ln1118_1464_fu_81392_p0.read().is_01() || !mul_ln1118_1464_fu_81392_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1464_fu_81392_p0.read()) * sc_bigint<5>(mul_ln1118_1464_fu_81392_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1465_fu_81411_p0() {
    mul_ln1118_1465_fu_81411_p0 =  (sc_lv<12>) (sext_ln1116_65_cast_fu_53495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1465_fu_81411_p1() {
    mul_ln1118_1465_fu_81411_p1 = tmp_1465_reg_103882.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1465_fu_81411_p2() {
    mul_ln1118_1465_fu_81411_p2 = (!mul_ln1118_1465_fu_81411_p0.read().is_01() || !mul_ln1118_1465_fu_81411_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1465_fu_81411_p0.read()) * sc_bigint<5>(mul_ln1118_1465_fu_81411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1466_fu_81430_p0() {
    mul_ln1118_1466_fu_81430_p0 =  (sc_lv<12>) (sext_ln1116_66_cast_fu_53517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1466_fu_81430_p1() {
    mul_ln1118_1466_fu_81430_p1 = tmp_1466_reg_103887.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1466_fu_81430_p2() {
    mul_ln1118_1466_fu_81430_p2 = (!mul_ln1118_1466_fu_81430_p0.read().is_01() || !mul_ln1118_1466_fu_81430_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1466_fu_81430_p0.read()) * sc_bigint<5>(mul_ln1118_1466_fu_81430_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1467_fu_81449_p0() {
    mul_ln1118_1467_fu_81449_p0 =  (sc_lv<12>) (sext_ln1116_67_cast_fu_53539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1467_fu_81449_p1() {
    mul_ln1118_1467_fu_81449_p1 = tmp_1467_reg_103892.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1467_fu_81449_p2() {
    mul_ln1118_1467_fu_81449_p2 = (!mul_ln1118_1467_fu_81449_p0.read().is_01() || !mul_ln1118_1467_fu_81449_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1467_fu_81449_p0.read()) * sc_bigint<5>(mul_ln1118_1467_fu_81449_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1468_fu_81468_p0() {
    mul_ln1118_1468_fu_81468_p0 =  (sc_lv<12>) (sext_ln1116_68_cast_fu_53561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1468_fu_81468_p1() {
    mul_ln1118_1468_fu_81468_p1 = tmp_1468_reg_103897.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1468_fu_81468_p2() {
    mul_ln1118_1468_fu_81468_p2 = (!mul_ln1118_1468_fu_81468_p0.read().is_01() || !mul_ln1118_1468_fu_81468_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1468_fu_81468_p0.read()) * sc_bigint<5>(mul_ln1118_1468_fu_81468_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1469_fu_81487_p0() {
    mul_ln1118_1469_fu_81487_p0 =  (sc_lv<12>) (sext_ln1116_69_cast_fu_53583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1469_fu_81487_p1() {
    mul_ln1118_1469_fu_81487_p1 = tmp_1469_reg_103902.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1469_fu_81487_p2() {
    mul_ln1118_1469_fu_81487_p2 = (!mul_ln1118_1469_fu_81487_p0.read().is_01() || !mul_ln1118_1469_fu_81487_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1469_fu_81487_p0.read()) * sc_bigint<5>(mul_ln1118_1469_fu_81487_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_146_fu_54967_p0() {
    mul_ln1118_146_fu_54967_p0 =  (sc_lv<12>) (sext_ln1116_146_cast_fu_54961_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_146_fu_54967_p1() {
    mul_ln1118_146_fu_54967_p1 = tmp_146_reg_97014.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_146_fu_54967_p2() {
    mul_ln1118_146_fu_54967_p2 = (!mul_ln1118_146_fu_54967_p0.read().is_01() || !mul_ln1118_146_fu_54967_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_146_fu_54967_p0.read()) * sc_bigint<5>(mul_ln1118_146_fu_54967_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1470_fu_81506_p0() {
    mul_ln1118_1470_fu_81506_p0 =  (sc_lv<12>) (sext_ln1116_70_cast_fu_53605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1470_fu_81506_p1() {
    mul_ln1118_1470_fu_81506_p1 = tmp_1470_reg_103907.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1470_fu_81506_p2() {
    mul_ln1118_1470_fu_81506_p2 = (!mul_ln1118_1470_fu_81506_p0.read().is_01() || !mul_ln1118_1470_fu_81506_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1470_fu_81506_p0.read()) * sc_bigint<5>(mul_ln1118_1470_fu_81506_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1471_fu_81525_p0() {
    mul_ln1118_1471_fu_81525_p0 =  (sc_lv<12>) (sext_ln1116_71_cast_fu_53627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1471_fu_81525_p1() {
    mul_ln1118_1471_fu_81525_p1 = tmp_1471_reg_103912.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1471_fu_81525_p2() {
    mul_ln1118_1471_fu_81525_p2 = (!mul_ln1118_1471_fu_81525_p0.read().is_01() || !mul_ln1118_1471_fu_81525_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1471_fu_81525_p0.read()) * sc_bigint<5>(mul_ln1118_1471_fu_81525_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1472_fu_81544_p0() {
    mul_ln1118_1472_fu_81544_p0 =  (sc_lv<12>) (sext_ln1116_72_cast_fu_53649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1472_fu_81544_p1() {
    mul_ln1118_1472_fu_81544_p1 = tmp_1472_reg_103917.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1472_fu_81544_p2() {
    mul_ln1118_1472_fu_81544_p2 = (!mul_ln1118_1472_fu_81544_p0.read().is_01() || !mul_ln1118_1472_fu_81544_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1472_fu_81544_p0.read()) * sc_bigint<5>(mul_ln1118_1472_fu_81544_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1473_fu_81563_p0() {
    mul_ln1118_1473_fu_81563_p0 =  (sc_lv<12>) (sext_ln1116_73_cast_fu_53671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1473_fu_81563_p1() {
    mul_ln1118_1473_fu_81563_p1 = tmp_1473_reg_103922.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1473_fu_81563_p2() {
    mul_ln1118_1473_fu_81563_p2 = (!mul_ln1118_1473_fu_81563_p0.read().is_01() || !mul_ln1118_1473_fu_81563_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1473_fu_81563_p0.read()) * sc_bigint<5>(mul_ln1118_1473_fu_81563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1474_fu_81582_p0() {
    mul_ln1118_1474_fu_81582_p0 =  (sc_lv<12>) (sext_ln1116_74_cast_fu_53693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1474_fu_81582_p1() {
    mul_ln1118_1474_fu_81582_p1 = tmp_1474_reg_103927.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1474_fu_81582_p2() {
    mul_ln1118_1474_fu_81582_p2 = (!mul_ln1118_1474_fu_81582_p0.read().is_01() || !mul_ln1118_1474_fu_81582_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1474_fu_81582_p0.read()) * sc_bigint<5>(mul_ln1118_1474_fu_81582_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1475_fu_81601_p0() {
    mul_ln1118_1475_fu_81601_p0 =  (sc_lv<12>) (sext_ln1116_75_cast_fu_53715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1475_fu_81601_p1() {
    mul_ln1118_1475_fu_81601_p1 = tmp_1475_reg_103932.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1475_fu_81601_p2() {
    mul_ln1118_1475_fu_81601_p2 = (!mul_ln1118_1475_fu_81601_p0.read().is_01() || !mul_ln1118_1475_fu_81601_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1475_fu_81601_p0.read()) * sc_bigint<5>(mul_ln1118_1475_fu_81601_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1476_fu_81620_p0() {
    mul_ln1118_1476_fu_81620_p0 =  (sc_lv<12>) (sext_ln1116_76_cast_fu_53737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1476_fu_81620_p1() {
    mul_ln1118_1476_fu_81620_p1 = tmp_1476_reg_103937.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1476_fu_81620_p2() {
    mul_ln1118_1476_fu_81620_p2 = (!mul_ln1118_1476_fu_81620_p0.read().is_01() || !mul_ln1118_1476_fu_81620_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1476_fu_81620_p0.read()) * sc_bigint<5>(mul_ln1118_1476_fu_81620_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1477_fu_81639_p0() {
    mul_ln1118_1477_fu_81639_p0 =  (sc_lv<12>) (sext_ln1116_77_cast_reg_96378.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1477_fu_81639_p1() {
    mul_ln1118_1477_fu_81639_p1 = tmp_1477_reg_103942.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1477_fu_81639_p2() {
    mul_ln1118_1477_fu_81639_p2 = (!mul_ln1118_1477_fu_81639_p0.read().is_01() || !mul_ln1118_1477_fu_81639_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1477_fu_81639_p0.read()) * sc_bigint<5>(mul_ln1118_1477_fu_81639_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1478_fu_44755_p0() {
    mul_ln1118_1478_fu_44755_p0 =  (sc_lv<12>) (sext_ln1116_78_cast_fu_23395_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1478_fu_44755_p1() {
    mul_ln1118_1478_fu_44755_p1 = tmp_1478_fu_44741_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1478_fu_44755_p2() {
    mul_ln1118_1478_fu_44755_p2 = (!mul_ln1118_1478_fu_44755_p0.read().is_01() || !mul_ln1118_1478_fu_44755_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1478_fu_44755_p0.read()) * sc_bigint<5>(mul_ln1118_1478_fu_44755_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1479_fu_44785_p0() {
    mul_ln1118_1479_fu_44785_p0 =  (sc_lv<12>) (sext_ln1116_79_cast_fu_23437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1479_fu_44785_p1() {
    mul_ln1118_1479_fu_44785_p1 = tmp_1479_fu_44771_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1479_fu_44785_p2() {
    mul_ln1118_1479_fu_44785_p2 = (!mul_ln1118_1479_fu_44785_p0.read().is_01() || !mul_ln1118_1479_fu_44785_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1479_fu_44785_p0.read()) * sc_bigint<5>(mul_ln1118_1479_fu_44785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_147_fu_54989_p0() {
    mul_ln1118_147_fu_54989_p0 =  (sc_lv<12>) (sext_ln1116_147_cast_fu_54983_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_147_fu_54989_p1() {
    mul_ln1118_147_fu_54989_p1 = tmp_147_reg_97024.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_147_fu_54989_p2() {
    mul_ln1118_147_fu_54989_p2 = (!mul_ln1118_147_fu_54989_p0.read().is_01() || !mul_ln1118_147_fu_54989_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_147_fu_54989_p0.read()) * sc_bigint<5>(mul_ln1118_147_fu_54989_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1480_fu_44815_p0() {
    mul_ln1118_1480_fu_44815_p0 =  (sc_lv<12>) (sext_ln1116_80_cast_fu_23479_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1480_fu_44815_p1() {
    mul_ln1118_1480_fu_44815_p1 = tmp_1480_fu_44801_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1480_fu_44815_p2() {
    mul_ln1118_1480_fu_44815_p2 = (!mul_ln1118_1480_fu_44815_p0.read().is_01() || !mul_ln1118_1480_fu_44815_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1480_fu_44815_p0.read()) * sc_bigint<5>(mul_ln1118_1480_fu_44815_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1481_fu_44845_p0() {
    mul_ln1118_1481_fu_44845_p0 =  (sc_lv<12>) (sext_ln1116_81_cast_fu_23521_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1481_fu_44845_p1() {
    mul_ln1118_1481_fu_44845_p1 = tmp_1481_fu_44831_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1481_fu_44845_p2() {
    mul_ln1118_1481_fu_44845_p2 = (!mul_ln1118_1481_fu_44845_p0.read().is_01() || !mul_ln1118_1481_fu_44845_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1481_fu_44845_p0.read()) * sc_bigint<5>(mul_ln1118_1481_fu_44845_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1482_fu_44875_p0() {
    mul_ln1118_1482_fu_44875_p0 =  (sc_lv<12>) (sext_ln1116_82_cast_fu_23563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1482_fu_44875_p1() {
    mul_ln1118_1482_fu_44875_p1 = tmp_1482_fu_44861_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1482_fu_44875_p2() {
    mul_ln1118_1482_fu_44875_p2 = (!mul_ln1118_1482_fu_44875_p0.read().is_01() || !mul_ln1118_1482_fu_44875_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1482_fu_44875_p0.read()) * sc_bigint<5>(mul_ln1118_1482_fu_44875_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1483_fu_44905_p0() {
    mul_ln1118_1483_fu_44905_p0 =  (sc_lv<12>) (sext_ln1116_83_cast_fu_23605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1483_fu_44905_p1() {
    mul_ln1118_1483_fu_44905_p1 = tmp_1483_fu_44891_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1483_fu_44905_p2() {
    mul_ln1118_1483_fu_44905_p2 = (!mul_ln1118_1483_fu_44905_p0.read().is_01() || !mul_ln1118_1483_fu_44905_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1483_fu_44905_p0.read()) * sc_bigint<5>(mul_ln1118_1483_fu_44905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1484_fu_81657_p0() {
    mul_ln1118_1484_fu_81657_p0 =  (sc_lv<12>) (sext_ln1116_84_cast_fu_53777_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1484_fu_81657_p1() {
    mul_ln1118_1484_fu_81657_p1 = tmp_1484_reg_103977.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1484_fu_81657_p2() {
    mul_ln1118_1484_fu_81657_p2 = (!mul_ln1118_1484_fu_81657_p0.read().is_01() || !mul_ln1118_1484_fu_81657_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1484_fu_81657_p0.read()) * sc_bigint<5>(mul_ln1118_1484_fu_81657_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1485_fu_81676_p0() {
    mul_ln1118_1485_fu_81676_p0 =  (sc_lv<12>) (sext_ln1116_85_cast_fu_53799_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1485_fu_81676_p1() {
    mul_ln1118_1485_fu_81676_p1 = tmp_1485_reg_103982.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1485_fu_81676_p2() {
    mul_ln1118_1485_fu_81676_p2 = (!mul_ln1118_1485_fu_81676_p0.read().is_01() || !mul_ln1118_1485_fu_81676_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1485_fu_81676_p0.read()) * sc_bigint<5>(mul_ln1118_1485_fu_81676_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1486_fu_81695_p0() {
    mul_ln1118_1486_fu_81695_p0 =  (sc_lv<12>) (sext_ln1116_86_cast_fu_53821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1486_fu_81695_p1() {
    mul_ln1118_1486_fu_81695_p1 = tmp_1486_reg_103987.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1486_fu_81695_p2() {
    mul_ln1118_1486_fu_81695_p2 = (!mul_ln1118_1486_fu_81695_p0.read().is_01() || !mul_ln1118_1486_fu_81695_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1486_fu_81695_p0.read()) * sc_bigint<5>(mul_ln1118_1486_fu_81695_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1487_fu_81714_p0() {
    mul_ln1118_1487_fu_81714_p0 =  (sc_lv<12>) (sext_ln1116_87_cast_fu_53843_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1487_fu_81714_p1() {
    mul_ln1118_1487_fu_81714_p1 = tmp_1487_reg_103992.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1487_fu_81714_p2() {
    mul_ln1118_1487_fu_81714_p2 = (!mul_ln1118_1487_fu_81714_p0.read().is_01() || !mul_ln1118_1487_fu_81714_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1487_fu_81714_p0.read()) * sc_bigint<5>(mul_ln1118_1487_fu_81714_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1488_fu_81733_p0() {
    mul_ln1118_1488_fu_81733_p0 =  (sc_lv<12>) (sext_ln1116_88_cast_fu_53865_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1488_fu_81733_p1() {
    mul_ln1118_1488_fu_81733_p1 = tmp_1488_reg_103997.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1488_fu_81733_p2() {
    mul_ln1118_1488_fu_81733_p2 = (!mul_ln1118_1488_fu_81733_p0.read().is_01() || !mul_ln1118_1488_fu_81733_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1488_fu_81733_p0.read()) * sc_bigint<5>(mul_ln1118_1488_fu_81733_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1489_fu_81752_p0() {
    mul_ln1118_1489_fu_81752_p0 =  (sc_lv<12>) (sext_ln1116_89_cast_fu_53887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1489_fu_81752_p1() {
    mul_ln1118_1489_fu_81752_p1 = tmp_1489_reg_104002.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1489_fu_81752_p2() {
    mul_ln1118_1489_fu_81752_p2 = (!mul_ln1118_1489_fu_81752_p0.read().is_01() || !mul_ln1118_1489_fu_81752_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1489_fu_81752_p0.read()) * sc_bigint<5>(mul_ln1118_1489_fu_81752_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_148_fu_55011_p0() {
    mul_ln1118_148_fu_55011_p0 =  (sc_lv<12>) (sext_ln1116_148_cast_fu_55005_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_148_fu_55011_p1() {
    mul_ln1118_148_fu_55011_p1 = tmp_148_reg_97034.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_148_fu_55011_p2() {
    mul_ln1118_148_fu_55011_p2 = (!mul_ln1118_148_fu_55011_p0.read().is_01() || !mul_ln1118_148_fu_55011_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_148_fu_55011_p0.read()) * sc_bigint<5>(mul_ln1118_148_fu_55011_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1490_fu_81771_p0() {
    mul_ln1118_1490_fu_81771_p0 =  (sc_lv<12>) (sext_ln1116_90_cast_fu_53909_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1490_fu_81771_p1() {
    mul_ln1118_1490_fu_81771_p1 = tmp_1490_reg_104007.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1490_fu_81771_p2() {
    mul_ln1118_1490_fu_81771_p2 = (!mul_ln1118_1490_fu_81771_p0.read().is_01() || !mul_ln1118_1490_fu_81771_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1490_fu_81771_p0.read()) * sc_bigint<5>(mul_ln1118_1490_fu_81771_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1491_fu_81790_p0() {
    mul_ln1118_1491_fu_81790_p0 =  (sc_lv<12>) (sext_ln1116_91_cast_fu_53931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1491_fu_81790_p1() {
    mul_ln1118_1491_fu_81790_p1 = tmp_1491_reg_104012.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1491_fu_81790_p2() {
    mul_ln1118_1491_fu_81790_p2 = (!mul_ln1118_1491_fu_81790_p0.read().is_01() || !mul_ln1118_1491_fu_81790_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1491_fu_81790_p0.read()) * sc_bigint<5>(mul_ln1118_1491_fu_81790_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1492_fu_81809_p0() {
    mul_ln1118_1492_fu_81809_p0 =  (sc_lv<12>) (sext_ln1116_92_cast_fu_53953_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1492_fu_81809_p1() {
    mul_ln1118_1492_fu_81809_p1 = tmp_1492_reg_104017.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1492_fu_81809_p2() {
    mul_ln1118_1492_fu_81809_p2 = (!mul_ln1118_1492_fu_81809_p0.read().is_01() || !mul_ln1118_1492_fu_81809_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1492_fu_81809_p0.read()) * sc_bigint<5>(mul_ln1118_1492_fu_81809_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1493_fu_81828_p0() {
    mul_ln1118_1493_fu_81828_p0 =  (sc_lv<12>) (sext_ln1116_93_cast_fu_53975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1493_fu_81828_p1() {
    mul_ln1118_1493_fu_81828_p1 = tmp_1493_reg_104022.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1493_fu_81828_p2() {
    mul_ln1118_1493_fu_81828_p2 = (!mul_ln1118_1493_fu_81828_p0.read().is_01() || !mul_ln1118_1493_fu_81828_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1493_fu_81828_p0.read()) * sc_bigint<5>(mul_ln1118_1493_fu_81828_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1494_fu_81847_p0() {
    mul_ln1118_1494_fu_81847_p0 =  (sc_lv<12>) (sext_ln1116_94_cast_fu_53997_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1494_fu_81847_p1() {
    mul_ln1118_1494_fu_81847_p1 = tmp_1494_reg_104027.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1494_fu_81847_p2() {
    mul_ln1118_1494_fu_81847_p2 = (!mul_ln1118_1494_fu_81847_p0.read().is_01() || !mul_ln1118_1494_fu_81847_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1494_fu_81847_p0.read()) * sc_bigint<5>(mul_ln1118_1494_fu_81847_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1495_fu_81866_p0() {
    mul_ln1118_1495_fu_81866_p0 =  (sc_lv<12>) (sext_ln1116_95_cast_fu_54019_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1495_fu_81866_p1() {
    mul_ln1118_1495_fu_81866_p1 = tmp_1495_reg_104032.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1495_fu_81866_p2() {
    mul_ln1118_1495_fu_81866_p2 = (!mul_ln1118_1495_fu_81866_p0.read().is_01() || !mul_ln1118_1495_fu_81866_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1495_fu_81866_p0.read()) * sc_bigint<5>(mul_ln1118_1495_fu_81866_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1496_fu_81885_p0() {
    mul_ln1118_1496_fu_81885_p0 =  (sc_lv<12>) (sext_ln1116_96_cast_fu_54041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1496_fu_81885_p1() {
    mul_ln1118_1496_fu_81885_p1 = tmp_1496_reg_104037.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1496_fu_81885_p2() {
    mul_ln1118_1496_fu_81885_p2 = (!mul_ln1118_1496_fu_81885_p0.read().is_01() || !mul_ln1118_1496_fu_81885_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1496_fu_81885_p0.read()) * sc_bigint<5>(mul_ln1118_1496_fu_81885_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1497_fu_81904_p0() {
    mul_ln1118_1497_fu_81904_p0 =  (sc_lv<12>) (sext_ln1116_97_cast_fu_54063_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1497_fu_81904_p1() {
    mul_ln1118_1497_fu_81904_p1 = tmp_1497_reg_104042.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1497_fu_81904_p2() {
    mul_ln1118_1497_fu_81904_p2 = (!mul_ln1118_1497_fu_81904_p0.read().is_01() || !mul_ln1118_1497_fu_81904_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1497_fu_81904_p0.read()) * sc_bigint<5>(mul_ln1118_1497_fu_81904_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1498_fu_81923_p0() {
    mul_ln1118_1498_fu_81923_p0 =  (sc_lv<12>) (sext_ln1116_98_cast_fu_54085_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1498_fu_81923_p1() {
    mul_ln1118_1498_fu_81923_p1 = tmp_1498_reg_104047.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1498_fu_81923_p2() {
    mul_ln1118_1498_fu_81923_p2 = (!mul_ln1118_1498_fu_81923_p0.read().is_01() || !mul_ln1118_1498_fu_81923_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1498_fu_81923_p0.read()) * sc_bigint<5>(mul_ln1118_1498_fu_81923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1499_fu_81942_p0() {
    mul_ln1118_1499_fu_81942_p0 =  (sc_lv<12>) (sext_ln1116_99_cast_fu_54107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1499_fu_81942_p1() {
    mul_ln1118_1499_fu_81942_p1 = tmp_1499_reg_104052.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1499_fu_81942_p2() {
    mul_ln1118_1499_fu_81942_p2 = (!mul_ln1118_1499_fu_81942_p0.read().is_01() || !mul_ln1118_1499_fu_81942_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1499_fu_81942_p0.read()) * sc_bigint<5>(mul_ln1118_1499_fu_81942_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_149_fu_55033_p0() {
    mul_ln1118_149_fu_55033_p0 =  (sc_lv<12>) (sext_ln1116_149_cast_fu_55027_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_149_fu_55033_p1() {
    mul_ln1118_149_fu_55033_p1 = tmp_149_reg_97044.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_149_fu_55033_p2() {
    mul_ln1118_149_fu_55033_p2 = (!mul_ln1118_149_fu_55033_p0.read().is_01() || !mul_ln1118_149_fu_55033_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_149_fu_55033_p0.read()) * sc_bigint<5>(mul_ln1118_149_fu_55033_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_14_fu_52647_p0() {
    mul_ln1118_14_fu_52647_p0 =  (sc_lv<12>) (sext_ln1116_14_cast_fu_52641_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_14_fu_52647_p1() {
    mul_ln1118_14_fu_52647_p1 = tmp_15_reg_95800.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_14_fu_52647_p2() {
    mul_ln1118_14_fu_52647_p2 = (!mul_ln1118_14_fu_52647_p0.read().is_01() || !mul_ln1118_14_fu_52647_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_14_fu_52647_p0.read()) * sc_bigint<5>(mul_ln1118_14_fu_52647_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1500_fu_81961_p0() {
    mul_ln1118_1500_fu_81961_p0 =  (sc_lv<12>) (sext_ln1116_100_cast_fu_54129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1500_fu_81961_p1() {
    mul_ln1118_1500_fu_81961_p1 = tmp_1500_reg_104057.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1500_fu_81961_p2() {
    mul_ln1118_1500_fu_81961_p2 = (!mul_ln1118_1500_fu_81961_p0.read().is_01() || !mul_ln1118_1500_fu_81961_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1500_fu_81961_p0.read()) * sc_bigint<5>(mul_ln1118_1500_fu_81961_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1501_fu_81980_p0() {
    mul_ln1118_1501_fu_81980_p0 =  (sc_lv<12>) (sext_ln1116_101_cast_fu_54151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1501_fu_81980_p1() {
    mul_ln1118_1501_fu_81980_p1 = tmp_1501_reg_104062.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1501_fu_81980_p2() {
    mul_ln1118_1501_fu_81980_p2 = (!mul_ln1118_1501_fu_81980_p0.read().is_01() || !mul_ln1118_1501_fu_81980_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1501_fu_81980_p0.read()) * sc_bigint<5>(mul_ln1118_1501_fu_81980_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1502_fu_81999_p0() {
    mul_ln1118_1502_fu_81999_p0 =  (sc_lv<12>) (sext_ln1116_102_cast_reg_96606.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1502_fu_81999_p1() {
    mul_ln1118_1502_fu_81999_p1 = tmp_1502_reg_104067.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1502_fu_81999_p2() {
    mul_ln1118_1502_fu_81999_p2 = (!mul_ln1118_1502_fu_81999_p0.read().is_01() || !mul_ln1118_1502_fu_81999_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1502_fu_81999_p0.read()) * sc_bigint<5>(mul_ln1118_1502_fu_81999_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1503_fu_45125_p0() {
    mul_ln1118_1503_fu_45125_p0 =  (sc_lv<12>) (sext_ln1116_103_cast_fu_23993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1503_fu_45125_p1() {
    mul_ln1118_1503_fu_45125_p1 = tmp_1503_fu_45111_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1503_fu_45125_p2() {
    mul_ln1118_1503_fu_45125_p2 = (!mul_ln1118_1503_fu_45125_p0.read().is_01() || !mul_ln1118_1503_fu_45125_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1503_fu_45125_p0.read()) * sc_bigint<5>(mul_ln1118_1503_fu_45125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1504_fu_45155_p0() {
    mul_ln1118_1504_fu_45155_p0 =  (sc_lv<12>) (sext_ln1116_104_cast_fu_24035_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1504_fu_45155_p1() {
    mul_ln1118_1504_fu_45155_p1 = tmp_1504_fu_45141_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1504_fu_45155_p2() {
    mul_ln1118_1504_fu_45155_p2 = (!mul_ln1118_1504_fu_45155_p0.read().is_01() || !mul_ln1118_1504_fu_45155_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1504_fu_45155_p0.read()) * sc_bigint<5>(mul_ln1118_1504_fu_45155_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1505_fu_45185_p0() {
    mul_ln1118_1505_fu_45185_p0 =  (sc_lv<12>) (sext_ln1116_105_cast_fu_24077_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1505_fu_45185_p1() {
    mul_ln1118_1505_fu_45185_p1 = tmp_1505_fu_45171_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1505_fu_45185_p2() {
    mul_ln1118_1505_fu_45185_p2 = (!mul_ln1118_1505_fu_45185_p0.read().is_01() || !mul_ln1118_1505_fu_45185_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1505_fu_45185_p0.read()) * sc_bigint<5>(mul_ln1118_1505_fu_45185_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1506_fu_45215_p0() {
    mul_ln1118_1506_fu_45215_p0 =  (sc_lv<12>) (sext_ln1116_106_cast_fu_24119_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1506_fu_45215_p1() {
    mul_ln1118_1506_fu_45215_p1 = tmp_1506_fu_45201_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1506_fu_45215_p2() {
    mul_ln1118_1506_fu_45215_p2 = (!mul_ln1118_1506_fu_45215_p0.read().is_01() || !mul_ln1118_1506_fu_45215_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1506_fu_45215_p0.read()) * sc_bigint<5>(mul_ln1118_1506_fu_45215_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1507_fu_45245_p0() {
    mul_ln1118_1507_fu_45245_p0 =  (sc_lv<12>) (sext_ln1116_107_cast_fu_24161_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1507_fu_45245_p1() {
    mul_ln1118_1507_fu_45245_p1 = tmp_1507_fu_45231_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1507_fu_45245_p2() {
    mul_ln1118_1507_fu_45245_p2 = (!mul_ln1118_1507_fu_45245_p0.read().is_01() || !mul_ln1118_1507_fu_45245_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1507_fu_45245_p0.read()) * sc_bigint<5>(mul_ln1118_1507_fu_45245_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1508_fu_45275_p0() {
    mul_ln1118_1508_fu_45275_p0 =  (sc_lv<12>) (sext_ln1116_108_cast_fu_24203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1508_fu_45275_p1() {
    mul_ln1118_1508_fu_45275_p1 = tmp_1508_fu_45261_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1508_fu_45275_p2() {
    mul_ln1118_1508_fu_45275_p2 = (!mul_ln1118_1508_fu_45275_p0.read().is_01() || !mul_ln1118_1508_fu_45275_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1508_fu_45275_p0.read()) * sc_bigint<5>(mul_ln1118_1508_fu_45275_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1509_fu_82017_p0() {
    mul_ln1118_1509_fu_82017_p0 =  (sc_lv<12>) (sext_ln1116_109_cast_fu_54191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1509_fu_82017_p1() {
    mul_ln1118_1509_fu_82017_p1 = tmp_1509_reg_104102.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1509_fu_82017_p2() {
    mul_ln1118_1509_fu_82017_p2 = (!mul_ln1118_1509_fu_82017_p0.read().is_01() || !mul_ln1118_1509_fu_82017_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1509_fu_82017_p0.read()) * sc_bigint<5>(mul_ln1118_1509_fu_82017_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_150_fu_55055_p0() {
    mul_ln1118_150_fu_55055_p0 =  (sc_lv<12>) (sext_ln1116_150_cast_fu_55049_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_150_fu_55055_p1() {
    mul_ln1118_150_fu_55055_p1 = tmp_150_reg_97054.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_150_fu_55055_p2() {
    mul_ln1118_150_fu_55055_p2 = (!mul_ln1118_150_fu_55055_p0.read().is_01() || !mul_ln1118_150_fu_55055_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_150_fu_55055_p0.read()) * sc_bigint<5>(mul_ln1118_150_fu_55055_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1510_fu_82036_p0() {
    mul_ln1118_1510_fu_82036_p0 =  (sc_lv<12>) (sext_ln1116_110_cast_fu_54213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1510_fu_82036_p1() {
    mul_ln1118_1510_fu_82036_p1 = tmp_1510_reg_104107.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1510_fu_82036_p2() {
    mul_ln1118_1510_fu_82036_p2 = (!mul_ln1118_1510_fu_82036_p0.read().is_01() || !mul_ln1118_1510_fu_82036_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1510_fu_82036_p0.read()) * sc_bigint<5>(mul_ln1118_1510_fu_82036_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1511_fu_82055_p0() {
    mul_ln1118_1511_fu_82055_p0 =  (sc_lv<12>) (sext_ln1116_111_cast_fu_54235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1511_fu_82055_p1() {
    mul_ln1118_1511_fu_82055_p1 = tmp_1511_reg_104112.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1511_fu_82055_p2() {
    mul_ln1118_1511_fu_82055_p2 = (!mul_ln1118_1511_fu_82055_p0.read().is_01() || !mul_ln1118_1511_fu_82055_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1511_fu_82055_p0.read()) * sc_bigint<5>(mul_ln1118_1511_fu_82055_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1512_fu_82074_p0() {
    mul_ln1118_1512_fu_82074_p0 =  (sc_lv<12>) (sext_ln1116_112_cast_fu_54257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1512_fu_82074_p1() {
    mul_ln1118_1512_fu_82074_p1 = tmp_1512_reg_104117.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1512_fu_82074_p2() {
    mul_ln1118_1512_fu_82074_p2 = (!mul_ln1118_1512_fu_82074_p0.read().is_01() || !mul_ln1118_1512_fu_82074_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1512_fu_82074_p0.read()) * sc_bigint<5>(mul_ln1118_1512_fu_82074_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1513_fu_82093_p0() {
    mul_ln1118_1513_fu_82093_p0 =  (sc_lv<12>) (sext_ln1116_113_cast_fu_54279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1513_fu_82093_p1() {
    mul_ln1118_1513_fu_82093_p1 = tmp_1513_reg_104122.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1513_fu_82093_p2() {
    mul_ln1118_1513_fu_82093_p2 = (!mul_ln1118_1513_fu_82093_p0.read().is_01() || !mul_ln1118_1513_fu_82093_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1513_fu_82093_p0.read()) * sc_bigint<5>(mul_ln1118_1513_fu_82093_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1514_fu_82112_p0() {
    mul_ln1118_1514_fu_82112_p0 =  (sc_lv<12>) (sext_ln1116_114_cast_fu_54301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1514_fu_82112_p1() {
    mul_ln1118_1514_fu_82112_p1 = tmp_1514_reg_104127.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1514_fu_82112_p2() {
    mul_ln1118_1514_fu_82112_p2 = (!mul_ln1118_1514_fu_82112_p0.read().is_01() || !mul_ln1118_1514_fu_82112_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1514_fu_82112_p0.read()) * sc_bigint<5>(mul_ln1118_1514_fu_82112_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1515_fu_82131_p0() {
    mul_ln1118_1515_fu_82131_p0 =  (sc_lv<12>) (sext_ln1116_115_cast_fu_54323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1515_fu_82131_p1() {
    mul_ln1118_1515_fu_82131_p1 = tmp_1515_reg_104132.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1515_fu_82131_p2() {
    mul_ln1118_1515_fu_82131_p2 = (!mul_ln1118_1515_fu_82131_p0.read().is_01() || !mul_ln1118_1515_fu_82131_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1515_fu_82131_p0.read()) * sc_bigint<5>(mul_ln1118_1515_fu_82131_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1516_fu_82150_p0() {
    mul_ln1118_1516_fu_82150_p0 =  (sc_lv<12>) (sext_ln1116_116_cast_fu_54345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1516_fu_82150_p1() {
    mul_ln1118_1516_fu_82150_p1 = tmp_1516_reg_104137.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1516_fu_82150_p2() {
    mul_ln1118_1516_fu_82150_p2 = (!mul_ln1118_1516_fu_82150_p0.read().is_01() || !mul_ln1118_1516_fu_82150_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1516_fu_82150_p0.read()) * sc_bigint<5>(mul_ln1118_1516_fu_82150_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1517_fu_82169_p0() {
    mul_ln1118_1517_fu_82169_p0 =  (sc_lv<12>) (sext_ln1116_117_cast_fu_54367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1517_fu_82169_p1() {
    mul_ln1118_1517_fu_82169_p1 = tmp_1517_reg_104142.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1517_fu_82169_p2() {
    mul_ln1118_1517_fu_82169_p2 = (!mul_ln1118_1517_fu_82169_p0.read().is_01() || !mul_ln1118_1517_fu_82169_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1517_fu_82169_p0.read()) * sc_bigint<5>(mul_ln1118_1517_fu_82169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1518_fu_82188_p0() {
    mul_ln1118_1518_fu_82188_p0 =  (sc_lv<12>) (sext_ln1116_118_cast_fu_54389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1518_fu_82188_p1() {
    mul_ln1118_1518_fu_82188_p1 = tmp_1518_reg_104147.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1518_fu_82188_p2() {
    mul_ln1118_1518_fu_82188_p2 = (!mul_ln1118_1518_fu_82188_p0.read().is_01() || !mul_ln1118_1518_fu_82188_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1518_fu_82188_p0.read()) * sc_bigint<5>(mul_ln1118_1518_fu_82188_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1519_fu_82207_p0() {
    mul_ln1118_1519_fu_82207_p0 =  (sc_lv<12>) (sext_ln1116_119_cast_fu_54411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1519_fu_82207_p1() {
    mul_ln1118_1519_fu_82207_p1 = tmp_1519_reg_104152.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1519_fu_82207_p2() {
    mul_ln1118_1519_fu_82207_p2 = (!mul_ln1118_1519_fu_82207_p0.read().is_01() || !mul_ln1118_1519_fu_82207_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1519_fu_82207_p0.read()) * sc_bigint<5>(mul_ln1118_1519_fu_82207_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_151_fu_55074_p0() {
    mul_ln1118_151_fu_55074_p0 =  (sc_lv<12>) (sext_ln1116_151_cast_reg_97064.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_151_fu_55074_p1() {
    mul_ln1118_151_fu_55074_p1 = tmp_151_reg_97059.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_151_fu_55074_p2() {
    mul_ln1118_151_fu_55074_p2 = (!mul_ln1118_151_fu_55074_p0.read().is_01() || !mul_ln1118_151_fu_55074_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_151_fu_55074_p0.read()) * sc_bigint<5>(mul_ln1118_151_fu_55074_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1520_fu_82226_p0() {
    mul_ln1118_1520_fu_82226_p0 =  (sc_lv<12>) (sext_ln1116_120_cast_fu_54433_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1520_fu_82226_p1() {
    mul_ln1118_1520_fu_82226_p1 = tmp_1520_reg_104157.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1520_fu_82226_p2() {
    mul_ln1118_1520_fu_82226_p2 = (!mul_ln1118_1520_fu_82226_p0.read().is_01() || !mul_ln1118_1520_fu_82226_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1520_fu_82226_p0.read()) * sc_bigint<5>(mul_ln1118_1520_fu_82226_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1521_fu_82245_p0() {
    mul_ln1118_1521_fu_82245_p0 =  (sc_lv<12>) (sext_ln1116_121_cast_fu_54455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1521_fu_82245_p1() {
    mul_ln1118_1521_fu_82245_p1 = tmp_1521_reg_104162.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1521_fu_82245_p2() {
    mul_ln1118_1521_fu_82245_p2 = (!mul_ln1118_1521_fu_82245_p0.read().is_01() || !mul_ln1118_1521_fu_82245_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1521_fu_82245_p0.read()) * sc_bigint<5>(mul_ln1118_1521_fu_82245_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1522_fu_82264_p0() {
    mul_ln1118_1522_fu_82264_p0 =  (sc_lv<12>) (sext_ln1116_122_cast_fu_54477_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1522_fu_82264_p1() {
    mul_ln1118_1522_fu_82264_p1 = tmp_1522_reg_104167.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1522_fu_82264_p2() {
    mul_ln1118_1522_fu_82264_p2 = (!mul_ln1118_1522_fu_82264_p0.read().is_01() || !mul_ln1118_1522_fu_82264_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1522_fu_82264_p0.read()) * sc_bigint<5>(mul_ln1118_1522_fu_82264_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1523_fu_82283_p0() {
    mul_ln1118_1523_fu_82283_p0 =  (sc_lv<12>) (sext_ln1116_123_cast_fu_54499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1523_fu_82283_p1() {
    mul_ln1118_1523_fu_82283_p1 = tmp_1523_reg_104172.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1523_fu_82283_p2() {
    mul_ln1118_1523_fu_82283_p2 = (!mul_ln1118_1523_fu_82283_p0.read().is_01() || !mul_ln1118_1523_fu_82283_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1523_fu_82283_p0.read()) * sc_bigint<5>(mul_ln1118_1523_fu_82283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1524_fu_82302_p0() {
    mul_ln1118_1524_fu_82302_p0 =  (sc_lv<12>) (sext_ln1116_124_cast_fu_54521_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1524_fu_82302_p1() {
    mul_ln1118_1524_fu_82302_p1 = tmp_1524_reg_104177.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1524_fu_82302_p2() {
    mul_ln1118_1524_fu_82302_p2 = (!mul_ln1118_1524_fu_82302_p0.read().is_01() || !mul_ln1118_1524_fu_82302_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1524_fu_82302_p0.read()) * sc_bigint<5>(mul_ln1118_1524_fu_82302_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1525_fu_82321_p0() {
    mul_ln1118_1525_fu_82321_p0 =  (sc_lv<12>) (sext_ln1116_125_cast_fu_54543_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1525_fu_82321_p1() {
    mul_ln1118_1525_fu_82321_p1 = tmp_1525_reg_104182.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1525_fu_82321_p2() {
    mul_ln1118_1525_fu_82321_p2 = (!mul_ln1118_1525_fu_82321_p0.read().is_01() || !mul_ln1118_1525_fu_82321_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1525_fu_82321_p0.read()) * sc_bigint<5>(mul_ln1118_1525_fu_82321_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1526_fu_82340_p0() {
    mul_ln1118_1526_fu_82340_p0 =  (sc_lv<12>) (sext_ln1116_126_cast_fu_54565_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1526_fu_82340_p1() {
    mul_ln1118_1526_fu_82340_p1 = tmp_1526_reg_104187.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1526_fu_82340_p2() {
    mul_ln1118_1526_fu_82340_p2 = (!mul_ln1118_1526_fu_82340_p0.read().is_01() || !mul_ln1118_1526_fu_82340_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1526_fu_82340_p0.read()) * sc_bigint<5>(mul_ln1118_1526_fu_82340_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1527_fu_82359_p0() {
    mul_ln1118_1527_fu_82359_p0 =  (sc_lv<12>) (sext_ln1116_127_cast_fu_54587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1527_fu_82359_p1() {
    mul_ln1118_1527_fu_82359_p1 = tmp_1527_reg_104192.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1527_fu_82359_p2() {
    mul_ln1118_1527_fu_82359_p2 = (!mul_ln1118_1527_fu_82359_p0.read().is_01() || !mul_ln1118_1527_fu_82359_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1527_fu_82359_p0.read()) * sc_bigint<5>(mul_ln1118_1527_fu_82359_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1528_fu_82378_p0() {
    mul_ln1118_1528_fu_82378_p0 =  (sc_lv<12>) (sext_ln1116_128_cast_fu_54609_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1528_fu_82378_p1() {
    mul_ln1118_1528_fu_82378_p1 = tmp_1528_reg_104197.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1528_fu_82378_p2() {
    mul_ln1118_1528_fu_82378_p2 = (!mul_ln1118_1528_fu_82378_p0.read().is_01() || !mul_ln1118_1528_fu_82378_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1528_fu_82378_p0.read()) * sc_bigint<5>(mul_ln1118_1528_fu_82378_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1529_fu_82397_p0() {
    mul_ln1118_1529_fu_82397_p0 =  (sc_lv<12>) (sext_ln1116_129_cast_fu_54631_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1529_fu_82397_p1() {
    mul_ln1118_1529_fu_82397_p1 = tmp_1529_reg_104202.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1529_fu_82397_p2() {
    mul_ln1118_1529_fu_82397_p2 = (!mul_ln1118_1529_fu_82397_p0.read().is_01() || !mul_ln1118_1529_fu_82397_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1529_fu_82397_p0.read()) * sc_bigint<5>(mul_ln1118_1529_fu_82397_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_152_fu_55092_p0() {
    mul_ln1118_152_fu_55092_p0 =  (sc_lv<12>) (sext_ln1116_152_cast_reg_97082.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_152_fu_55092_p1() {
    mul_ln1118_152_fu_55092_p1 = tmp_152_reg_97077.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_152_fu_55092_p2() {
    mul_ln1118_152_fu_55092_p2 = (!mul_ln1118_152_fu_55092_p0.read().is_01() || !mul_ln1118_152_fu_55092_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_152_fu_55092_p0.read()) * sc_bigint<5>(mul_ln1118_152_fu_55092_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1530_fu_82416_p0() {
    mul_ln1118_1530_fu_82416_p0 =  (sc_lv<12>) (sext_ln1116_130_cast_fu_54653_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1530_fu_82416_p1() {
    mul_ln1118_1530_fu_82416_p1 = tmp_1530_reg_104207.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1530_fu_82416_p2() {
    mul_ln1118_1530_fu_82416_p2 = (!mul_ln1118_1530_fu_82416_p0.read().is_01() || !mul_ln1118_1530_fu_82416_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1530_fu_82416_p0.read()) * sc_bigint<5>(mul_ln1118_1530_fu_82416_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1531_fu_82435_p0() {
    mul_ln1118_1531_fu_82435_p0 =  (sc_lv<12>) (sext_ln1116_131_cast_fu_54675_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1531_fu_82435_p1() {
    mul_ln1118_1531_fu_82435_p1 = tmp_1531_reg_104212.read();
}

}

