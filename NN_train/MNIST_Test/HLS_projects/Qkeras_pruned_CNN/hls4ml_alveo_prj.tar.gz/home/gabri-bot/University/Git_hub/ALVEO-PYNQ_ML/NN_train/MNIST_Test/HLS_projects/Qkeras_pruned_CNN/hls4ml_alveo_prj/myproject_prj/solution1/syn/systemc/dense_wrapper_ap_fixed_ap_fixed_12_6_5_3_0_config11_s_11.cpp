#include "dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_630_fu_41431_p2() {
    mul_ln1118_630_fu_41431_p2 = (!mul_ln1118_630_fu_41431_p0.read().is_01() || !mul_ln1118_630_fu_41431_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_630_fu_41431_p0.read()) * sc_bigint<5>(mul_ln1118_630_fu_41431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_631_fu_41463_p0() {
    mul_ln1118_631_fu_41463_p0 =  (sc_lv<3>) (sext_ln1116_31_fu_22669_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_631_fu_41463_p1() {
    mul_ln1118_631_fu_41463_p1 = tmp_631_fu_41449_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_631_fu_41463_p2() {
    mul_ln1118_631_fu_41463_p2 = (!mul_ln1118_631_fu_41463_p0.read().is_01() || !mul_ln1118_631_fu_41463_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_631_fu_41463_p0.read()) * sc_bigint<5>(mul_ln1118_631_fu_41463_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_632_fu_41495_p0() {
    mul_ln1118_632_fu_41495_p0 =  (sc_lv<3>) (sext_ln1116_32_fu_22713_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_632_fu_41495_p1() {
    mul_ln1118_632_fu_41495_p1 = tmp_632_fu_41481_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_632_fu_41495_p2() {
    mul_ln1118_632_fu_41495_p2 = (!mul_ln1118_632_fu_41495_p0.read().is_01() || !mul_ln1118_632_fu_41495_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_632_fu_41495_p0.read()) * sc_bigint<5>(mul_ln1118_632_fu_41495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_633_fu_41527_p0() {
    mul_ln1118_633_fu_41527_p0 =  (sc_lv<3>) (sext_ln1116_33_fu_22757_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_633_fu_41527_p1() {
    mul_ln1118_633_fu_41527_p1 = tmp_633_fu_41513_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_633_fu_41527_p2() {
    mul_ln1118_633_fu_41527_p2 = (!mul_ln1118_633_fu_41527_p0.read().is_01() || !mul_ln1118_633_fu_41527_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_633_fu_41527_p0.read()) * sc_bigint<5>(mul_ln1118_633_fu_41527_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_634_fu_87242_p0() {
    mul_ln1118_634_fu_87242_p0 =  (sc_lv<3>) (sext_ln1116_34_reg_106007.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_634_fu_87242_p1() {
    mul_ln1118_634_fu_87242_p1 = tmp_634_reg_108456.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_634_fu_87242_p2() {
    mul_ln1118_634_fu_87242_p2 = (!mul_ln1118_634_fu_87242_p0.read().is_01() || !mul_ln1118_634_fu_87242_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_634_fu_87242_p0.read()) * sc_bigint<5>(mul_ln1118_634_fu_87242_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_635_fu_41569_p0() {
    mul_ln1118_635_fu_41569_p0 =  (sc_lv<3>) (sext_ln1116_35_fu_22823_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_635_fu_41569_p1() {
    mul_ln1118_635_fu_41569_p1 = tmp_635_fu_41555_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_635_fu_41569_p2() {
    mul_ln1118_635_fu_41569_p2 = (!mul_ln1118_635_fu_41569_p0.read().is_01() || !mul_ln1118_635_fu_41569_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_635_fu_41569_p0.read()) * sc_bigint<5>(mul_ln1118_635_fu_41569_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_636_fu_41601_p0() {
    mul_ln1118_636_fu_41601_p0 =  (sc_lv<3>) (sext_ln1116_36_fu_22867_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_636_fu_41601_p1() {
    mul_ln1118_636_fu_41601_p1 = tmp_636_fu_41587_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_636_fu_41601_p2() {
    mul_ln1118_636_fu_41601_p2 = (!mul_ln1118_636_fu_41601_p0.read().is_01() || !mul_ln1118_636_fu_41601_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_636_fu_41601_p0.read()) * sc_bigint<5>(mul_ln1118_636_fu_41601_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_637_fu_87262_p0() {
    mul_ln1118_637_fu_87262_p0 =  (sc_lv<3>) (sext_ln1116_37_reg_106025.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_637_fu_87262_p1() {
    mul_ln1118_637_fu_87262_p1 = tmp_637_reg_108461.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_637_fu_87262_p2() {
    mul_ln1118_637_fu_87262_p2 = (!mul_ln1118_637_fu_87262_p0.read().is_01() || !mul_ln1118_637_fu_87262_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_637_fu_87262_p0.read()) * sc_bigint<5>(mul_ln1118_637_fu_87262_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_638_fu_41643_p0() {
    mul_ln1118_638_fu_41643_p0 =  (sc_lv<3>) (sext_ln1116_38_fu_22933_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_638_fu_41643_p1() {
    mul_ln1118_638_fu_41643_p1 = tmp_638_fu_41629_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_638_fu_41643_p2() {
    mul_ln1118_638_fu_41643_p2 = (!mul_ln1118_638_fu_41643_p0.read().is_01() || !mul_ln1118_638_fu_41643_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_638_fu_41643_p0.read()) * sc_bigint<5>(mul_ln1118_638_fu_41643_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_639_fu_41675_p0() {
    mul_ln1118_639_fu_41675_p0 =  (sc_lv<3>) (sext_ln1116_39_fu_22977_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_639_fu_41675_p1() {
    mul_ln1118_639_fu_41675_p1 = tmp_639_fu_41661_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_639_fu_41675_p2() {
    mul_ln1118_639_fu_41675_p2 = (!mul_ln1118_639_fu_41675_p0.read().is_01() || !mul_ln1118_639_fu_41675_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_639_fu_41675_p0.read()) * sc_bigint<5>(mul_ln1118_639_fu_41675_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_63_fu_23791_p0() {
    mul_ln1118_63_fu_23791_p0 =  (sc_lv<3>) (sext_ln1116_63_fu_23783_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_63_fu_23791_p1() {
    mul_ln1118_63_fu_23791_p1 = tmp_63_fu_23773_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_63_fu_23791_p2() {
    mul_ln1118_63_fu_23791_p2 = (!mul_ln1118_63_fu_23791_p0.read().is_01() || !mul_ln1118_63_fu_23791_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_63_fu_23791_p0.read()) * sc_bigint<5>(mul_ln1118_63_fu_23791_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_640_fu_87282_p0() {
    mul_ln1118_640_fu_87282_p0 =  (sc_lv<3>) (sext_ln1116_40_fu_80193_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_640_fu_87282_p1() {
    mul_ln1118_640_fu_87282_p1 = tmp_640_reg_108466.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_640_fu_87282_p2() {
    mul_ln1118_640_fu_87282_p2 = (!mul_ln1118_640_fu_87282_p0.read().is_01() || !mul_ln1118_640_fu_87282_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_640_fu_87282_p0.read()) * sc_bigint<5>(mul_ln1118_640_fu_87282_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_641_fu_87303_p0() {
    mul_ln1118_641_fu_87303_p0 =  (sc_lv<3>) (sext_ln1116_41_fu_80217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_641_fu_87303_p1() {
    mul_ln1118_641_fu_87303_p1 = tmp_641_reg_108471.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_641_fu_87303_p2() {
    mul_ln1118_641_fu_87303_p2 = (!mul_ln1118_641_fu_87303_p0.read().is_01() || !mul_ln1118_641_fu_87303_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_641_fu_87303_p0.read()) * sc_bigint<5>(mul_ln1118_641_fu_87303_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_642_fu_87324_p0() {
    mul_ln1118_642_fu_87324_p0 =  (sc_lv<3>) (sext_ln1116_42_fu_80241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_642_fu_87324_p1() {
    mul_ln1118_642_fu_87324_p1 = tmp_642_reg_108476.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_642_fu_87324_p2() {
    mul_ln1118_642_fu_87324_p2 = (!mul_ln1118_642_fu_87324_p0.read().is_01() || !mul_ln1118_642_fu_87324_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_642_fu_87324_p0.read()) * sc_bigint<5>(mul_ln1118_642_fu_87324_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_643_fu_87345_p0() {
    mul_ln1118_643_fu_87345_p0 =  (sc_lv<3>) (sext_ln1116_43_fu_80265_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_643_fu_87345_p1() {
    mul_ln1118_643_fu_87345_p1 = tmp_643_reg_108481.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_643_fu_87345_p2() {
    mul_ln1118_643_fu_87345_p2 = (!mul_ln1118_643_fu_87345_p0.read().is_01() || !mul_ln1118_643_fu_87345_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_643_fu_87345_p0.read()) * sc_bigint<5>(mul_ln1118_643_fu_87345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_644_fu_87366_p0() {
    mul_ln1118_644_fu_87366_p0 =  (sc_lv<3>) (sext_ln1116_44_fu_80289_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_644_fu_87366_p1() {
    mul_ln1118_644_fu_87366_p1 = tmp_644_reg_108486.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_644_fu_87366_p2() {
    mul_ln1118_644_fu_87366_p2 = (!mul_ln1118_644_fu_87366_p0.read().is_01() || !mul_ln1118_644_fu_87366_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_644_fu_87366_p0.read()) * sc_bigint<5>(mul_ln1118_644_fu_87366_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_645_fu_87387_p0() {
    mul_ln1118_645_fu_87387_p0 =  (sc_lv<3>) (sext_ln1116_45_fu_80313_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_645_fu_87387_p1() {
    mul_ln1118_645_fu_87387_p1 = tmp_645_reg_108491.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_645_fu_87387_p2() {
    mul_ln1118_645_fu_87387_p2 = (!mul_ln1118_645_fu_87387_p0.read().is_01() || !mul_ln1118_645_fu_87387_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_645_fu_87387_p0.read()) * sc_bigint<5>(mul_ln1118_645_fu_87387_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_646_fu_87408_p0() {
    mul_ln1118_646_fu_87408_p0 =  (sc_lv<3>) (sext_ln1116_46_reg_106103.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_646_fu_87408_p1() {
    mul_ln1118_646_fu_87408_p1 = tmp_646_reg_108496.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_646_fu_87408_p2() {
    mul_ln1118_646_fu_87408_p2 = (!mul_ln1118_646_fu_87408_p0.read().is_01() || !mul_ln1118_646_fu_87408_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_646_fu_87408_p0.read()) * sc_bigint<5>(mul_ln1118_646_fu_87408_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_647_fu_41777_p0() {
    mul_ln1118_647_fu_41777_p0 =  (sc_lv<3>) (sext_ln1116_47_fu_23151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_647_fu_41777_p1() {
    mul_ln1118_647_fu_41777_p1 = tmp_647_fu_41763_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_647_fu_41777_p2() {
    mul_ln1118_647_fu_41777_p2 = (!mul_ln1118_647_fu_41777_p0.read().is_01() || !mul_ln1118_647_fu_41777_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_647_fu_41777_p0.read()) * sc_bigint<5>(mul_ln1118_647_fu_41777_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_648_fu_41809_p0() {
    mul_ln1118_648_fu_41809_p0 =  (sc_lv<3>) (sext_ln1116_48_fu_23195_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_648_fu_41809_p1() {
    mul_ln1118_648_fu_41809_p1 = tmp_648_fu_41795_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_648_fu_41809_p2() {
    mul_ln1118_648_fu_41809_p2 = (!mul_ln1118_648_fu_41809_p0.read().is_01() || !mul_ln1118_648_fu_41809_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_648_fu_41809_p0.read()) * sc_bigint<5>(mul_ln1118_648_fu_41809_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_649_fu_87428_p0() {
    mul_ln1118_649_fu_87428_p0 =  (sc_lv<3>) (sext_ln1116_49_reg_106121.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_649_fu_87428_p1() {
    mul_ln1118_649_fu_87428_p1 = tmp_649_reg_108501.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_649_fu_87428_p2() {
    mul_ln1118_649_fu_87428_p2 = (!mul_ln1118_649_fu_87428_p0.read().is_01() || !mul_ln1118_649_fu_87428_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_649_fu_87428_p0.read()) * sc_bigint<5>(mul_ln1118_649_fu_87428_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_64_fu_23835_p0() {
    mul_ln1118_64_fu_23835_p0 =  (sc_lv<3>) (sext_ln1116_64_fu_23827_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_64_fu_23835_p1() {
    mul_ln1118_64_fu_23835_p1 = tmp_64_fu_23817_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_64_fu_23835_p2() {
    mul_ln1118_64_fu_23835_p2 = (!mul_ln1118_64_fu_23835_p0.read().is_01() || !mul_ln1118_64_fu_23835_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_64_fu_23835_p0.read()) * sc_bigint<5>(mul_ln1118_64_fu_23835_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_650_fu_41851_p0() {
    mul_ln1118_650_fu_41851_p0 =  (sc_lv<3>) (sext_ln1116_50_fu_23261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_650_fu_41851_p1() {
    mul_ln1118_650_fu_41851_p1 = tmp_650_fu_41837_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_650_fu_41851_p2() {
    mul_ln1118_650_fu_41851_p2 = (!mul_ln1118_650_fu_41851_p0.read().is_01() || !mul_ln1118_650_fu_41851_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_650_fu_41851_p0.read()) * sc_bigint<5>(mul_ln1118_650_fu_41851_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_651_fu_41883_p0() {
    mul_ln1118_651_fu_41883_p0 =  (sc_lv<3>) (sext_ln1116_51_fu_23305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_651_fu_41883_p1() {
    mul_ln1118_651_fu_41883_p1 = tmp_651_fu_41869_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_651_fu_41883_p2() {
    mul_ln1118_651_fu_41883_p2 = (!mul_ln1118_651_fu_41883_p0.read().is_01() || !mul_ln1118_651_fu_41883_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_651_fu_41883_p0.read()) * sc_bigint<5>(mul_ln1118_651_fu_41883_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_652_fu_87448_p0() {
    mul_ln1118_652_fu_87448_p0 =  (sc_lv<3>) (sext_ln1116_52_fu_80377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_652_fu_87448_p1() {
    mul_ln1118_652_fu_87448_p1 = tmp_652_reg_108506.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_652_fu_87448_p2() {
    mul_ln1118_652_fu_87448_p2 = (!mul_ln1118_652_fu_87448_p0.read().is_01() || !mul_ln1118_652_fu_87448_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_652_fu_87448_p0.read()) * sc_bigint<5>(mul_ln1118_652_fu_87448_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_653_fu_41925_p0() {
    mul_ln1118_653_fu_41925_p0 =  (sc_lv<3>) (sext_ln1116_53_fu_23367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_653_fu_41925_p1() {
    mul_ln1118_653_fu_41925_p1 = tmp_653_fu_41911_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_653_fu_41925_p2() {
    mul_ln1118_653_fu_41925_p2 = (!mul_ln1118_653_fu_41925_p0.read().is_01() || !mul_ln1118_653_fu_41925_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_653_fu_41925_p0.read()) * sc_bigint<5>(mul_ln1118_653_fu_41925_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_654_fu_41957_p0() {
    mul_ln1118_654_fu_41957_p0 =  (sc_lv<3>) (sext_ln1116_54_fu_23411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_654_fu_41957_p1() {
    mul_ln1118_654_fu_41957_p1 = tmp_654_fu_41943_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_654_fu_41957_p2() {
    mul_ln1118_654_fu_41957_p2 = (!mul_ln1118_654_fu_41957_p0.read().is_01() || !mul_ln1118_654_fu_41957_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_654_fu_41957_p0.read()) * sc_bigint<5>(mul_ln1118_654_fu_41957_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_655_fu_41989_p0() {
    mul_ln1118_655_fu_41989_p0 =  (sc_lv<3>) (sext_ln1116_55_fu_23455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_655_fu_41989_p1() {
    mul_ln1118_655_fu_41989_p1 = tmp_655_fu_41975_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_655_fu_41989_p2() {
    mul_ln1118_655_fu_41989_p2 = (!mul_ln1118_655_fu_41989_p0.read().is_01() || !mul_ln1118_655_fu_41989_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_655_fu_41989_p0.read()) * sc_bigint<5>(mul_ln1118_655_fu_41989_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_656_fu_42021_p0() {
    mul_ln1118_656_fu_42021_p0 =  (sc_lv<3>) (sext_ln1116_56_fu_23499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_656_fu_42021_p1() {
    mul_ln1118_656_fu_42021_p1 = tmp_656_fu_42007_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_656_fu_42021_p2() {
    mul_ln1118_656_fu_42021_p2 = (!mul_ln1118_656_fu_42021_p0.read().is_01() || !mul_ln1118_656_fu_42021_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_656_fu_42021_p0.read()) * sc_bigint<5>(mul_ln1118_656_fu_42021_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_657_fu_42053_p0() {
    mul_ln1118_657_fu_42053_p0 =  (sc_lv<3>) (sext_ln1116_57_fu_23543_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_657_fu_42053_p1() {
    mul_ln1118_657_fu_42053_p1 = tmp_657_fu_42039_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_657_fu_42053_p2() {
    mul_ln1118_657_fu_42053_p2 = (!mul_ln1118_657_fu_42053_p0.read().is_01() || !mul_ln1118_657_fu_42053_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_657_fu_42053_p0.read()) * sc_bigint<5>(mul_ln1118_657_fu_42053_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_658_fu_42085_p0() {
    mul_ln1118_658_fu_42085_p0 =  (sc_lv<3>) (sext_ln1116_58_fu_23587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_658_fu_42085_p1() {
    mul_ln1118_658_fu_42085_p1 = tmp_658_fu_42071_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_658_fu_42085_p2() {
    mul_ln1118_658_fu_42085_p2 = (!mul_ln1118_658_fu_42085_p0.read().is_01() || !mul_ln1118_658_fu_42085_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_658_fu_42085_p0.read()) * sc_bigint<5>(mul_ln1118_658_fu_42085_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_659_fu_42117_p0() {
    mul_ln1118_659_fu_42117_p0 =  (sc_lv<3>) (sext_ln1116_59_fu_23631_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_659_fu_42117_p1() {
    mul_ln1118_659_fu_42117_p1 = tmp_659_fu_42103_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_659_fu_42117_p2() {
    mul_ln1118_659_fu_42117_p2 = (!mul_ln1118_659_fu_42117_p0.read().is_01() || !mul_ln1118_659_fu_42117_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_659_fu_42117_p0.read()) * sc_bigint<5>(mul_ln1118_659_fu_42117_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_65_fu_80426_p0() {
    mul_ln1118_65_fu_80426_p0 =  (sc_lv<3>) (sext_ln1116_65_reg_106159.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_65_fu_80426_p1() {
    mul_ln1118_65_fu_80426_p1 = tmp_65_reg_106154.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_65_fu_80426_p2() {
    mul_ln1118_65_fu_80426_p2 = (!mul_ln1118_65_fu_80426_p0.read().is_01() || !mul_ln1118_65_fu_80426_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_65_fu_80426_p0.read()) * sc_bigint<5>(mul_ln1118_65_fu_80426_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_660_fu_42137_p0() {
    mul_ln1118_660_fu_42137_p0 =  (sc_lv<3>) (sext_ln1116_60_fu_23663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_660_fu_42137_p1() {
    mul_ln1118_660_fu_42137_p1 = tmp_660_fu_42123_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_660_fu_42137_p2() {
    mul_ln1118_660_fu_42137_p2 = (!mul_ln1118_660_fu_42137_p0.read().is_01() || !mul_ln1118_660_fu_42137_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_660_fu_42137_p0.read()) * sc_bigint<5>(mul_ln1118_660_fu_42137_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_661_fu_42169_p0() {
    mul_ln1118_661_fu_42169_p0 =  (sc_lv<3>) (sext_ln1116_61_fu_23707_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_661_fu_42169_p1() {
    mul_ln1118_661_fu_42169_p1 = tmp_661_fu_42155_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_661_fu_42169_p2() {
    mul_ln1118_661_fu_42169_p2 = (!mul_ln1118_661_fu_42169_p0.read().is_01() || !mul_ln1118_661_fu_42169_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_661_fu_42169_p0.read()) * sc_bigint<5>(mul_ln1118_661_fu_42169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_662_fu_42201_p0() {
    mul_ln1118_662_fu_42201_p0 =  (sc_lv<3>) (sext_ln1116_62_fu_23751_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_662_fu_42201_p1() {
    mul_ln1118_662_fu_42201_p1 = tmp_662_fu_42187_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_662_fu_42201_p2() {
    mul_ln1118_662_fu_42201_p2 = (!mul_ln1118_662_fu_42201_p0.read().is_01() || !mul_ln1118_662_fu_42201_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_662_fu_42201_p0.read()) * sc_bigint<5>(mul_ln1118_662_fu_42201_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_663_fu_42221_p0() {
    mul_ln1118_663_fu_42221_p0 =  (sc_lv<3>) (sext_ln1116_63_fu_23783_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_663_fu_42221_p1() {
    mul_ln1118_663_fu_42221_p1 = tmp_663_fu_42207_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_663_fu_42221_p2() {
    mul_ln1118_663_fu_42221_p2 = (!mul_ln1118_663_fu_42221_p0.read().is_01() || !mul_ln1118_663_fu_42221_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_663_fu_42221_p0.read()) * sc_bigint<5>(mul_ln1118_663_fu_42221_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_664_fu_42253_p0() {
    mul_ln1118_664_fu_42253_p0 =  (sc_lv<3>) (sext_ln1116_64_fu_23827_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_664_fu_42253_p1() {
    mul_ln1118_664_fu_42253_p1 = tmp_664_fu_42239_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_664_fu_42253_p2() {
    mul_ln1118_664_fu_42253_p2 = (!mul_ln1118_664_fu_42253_p0.read().is_01() || !mul_ln1118_664_fu_42253_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_664_fu_42253_p0.read()) * sc_bigint<5>(mul_ln1118_664_fu_42253_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_665_fu_87491_p0() {
    mul_ln1118_665_fu_87491_p0 =  (sc_lv<3>) (sext_ln1116_65_reg_106159.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_665_fu_87491_p1() {
    mul_ln1118_665_fu_87491_p1 = tmp_665_reg_108521.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_665_fu_87491_p2() {
    mul_ln1118_665_fu_87491_p2 = (!mul_ln1118_665_fu_87491_p0.read().is_01() || !mul_ln1118_665_fu_87491_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_665_fu_87491_p0.read()) * sc_bigint<5>(mul_ln1118_665_fu_87491_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_666_fu_42295_p0() {
    mul_ln1118_666_fu_42295_p0 =  (sc_lv<3>) (sext_ln1116_66_fu_23893_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_666_fu_42295_p1() {
    mul_ln1118_666_fu_42295_p1 = tmp_666_fu_42281_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_666_fu_42295_p2() {
    mul_ln1118_666_fu_42295_p2 = (!mul_ln1118_666_fu_42295_p0.read().is_01() || !mul_ln1118_666_fu_42295_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_666_fu_42295_p0.read()) * sc_bigint<5>(mul_ln1118_666_fu_42295_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_667_fu_42327_p0() {
    mul_ln1118_667_fu_42327_p0 =  (sc_lv<3>) (sext_ln1116_67_fu_23937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_667_fu_42327_p1() {
    mul_ln1118_667_fu_42327_p1 = tmp_667_fu_42313_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_667_fu_42327_p2() {
    mul_ln1118_667_fu_42327_p2 = (!mul_ln1118_667_fu_42327_p0.read().is_01() || !mul_ln1118_667_fu_42327_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_667_fu_42327_p0.read()) * sc_bigint<5>(mul_ln1118_667_fu_42327_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_668_fu_87511_p0() {
    mul_ln1118_668_fu_87511_p0 =  (sc_lv<3>) (sext_ln1116_68_reg_106177.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_668_fu_87511_p1() {
    mul_ln1118_668_fu_87511_p1 = tmp_668_reg_108526.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_668_fu_87511_p2() {
    mul_ln1118_668_fu_87511_p2 = (!mul_ln1118_668_fu_87511_p0.read().is_01() || !mul_ln1118_668_fu_87511_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_668_fu_87511_p0.read()) * sc_bigint<5>(mul_ln1118_668_fu_87511_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_669_fu_42369_p0() {
    mul_ln1118_669_fu_42369_p0 =  (sc_lv<3>) (sext_ln1116_69_fu_24003_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_669_fu_42369_p1() {
    mul_ln1118_669_fu_42369_p1 = tmp_669_fu_42355_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_669_fu_42369_p2() {
    mul_ln1118_669_fu_42369_p2 = (!mul_ln1118_669_fu_42369_p0.read().is_01() || !mul_ln1118_669_fu_42369_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_669_fu_42369_p0.read()) * sc_bigint<5>(mul_ln1118_669_fu_42369_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_66_fu_23901_p0() {
    mul_ln1118_66_fu_23901_p0 =  (sc_lv<3>) (sext_ln1116_66_fu_23893_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_66_fu_23901_p1() {
    mul_ln1118_66_fu_23901_p1 = tmp_66_fu_23883_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_66_fu_23901_p2() {
    mul_ln1118_66_fu_23901_p2 = (!mul_ln1118_66_fu_23901_p0.read().is_01() || !mul_ln1118_66_fu_23901_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_66_fu_23901_p0.read()) * sc_bigint<5>(mul_ln1118_66_fu_23901_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_670_fu_42401_p0() {
    mul_ln1118_670_fu_42401_p0 =  (sc_lv<3>) (sext_ln1116_70_fu_24047_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_670_fu_42401_p1() {
    mul_ln1118_670_fu_42401_p1 = tmp_670_fu_42387_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_670_fu_42401_p2() {
    mul_ln1118_670_fu_42401_p2 = (!mul_ln1118_670_fu_42401_p0.read().is_01() || !mul_ln1118_670_fu_42401_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_670_fu_42401_p0.read()) * sc_bigint<5>(mul_ln1118_670_fu_42401_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_671_fu_87531_p0() {
    mul_ln1118_671_fu_87531_p0 =  (sc_lv<3>) (sext_ln1116_71_reg_106195.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_671_fu_87531_p1() {
    mul_ln1118_671_fu_87531_p1 = tmp_671_reg_108531.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_671_fu_87531_p2() {
    mul_ln1118_671_fu_87531_p2 = (!mul_ln1118_671_fu_87531_p0.read().is_01() || !mul_ln1118_671_fu_87531_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_671_fu_87531_p0.read()) * sc_bigint<5>(mul_ln1118_671_fu_87531_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_672_fu_42443_p0() {
    mul_ln1118_672_fu_42443_p0 =  (sc_lv<3>) (sext_ln1116_72_fu_24113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_672_fu_42443_p1() {
    mul_ln1118_672_fu_42443_p1 = tmp_672_fu_42429_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_672_fu_42443_p2() {
    mul_ln1118_672_fu_42443_p2 = (!mul_ln1118_672_fu_42443_p0.read().is_01() || !mul_ln1118_672_fu_42443_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_672_fu_42443_p0.read()) * sc_bigint<5>(mul_ln1118_672_fu_42443_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_673_fu_42475_p0() {
    mul_ln1118_673_fu_42475_p0 =  (sc_lv<3>) (sext_ln1116_73_fu_24157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_673_fu_42475_p1() {
    mul_ln1118_673_fu_42475_p1 = tmp_673_fu_42461_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_673_fu_42475_p2() {
    mul_ln1118_673_fu_42475_p2 = (!mul_ln1118_673_fu_42475_p0.read().is_01() || !mul_ln1118_673_fu_42475_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_673_fu_42475_p0.read()) * sc_bigint<5>(mul_ln1118_673_fu_42475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_674_fu_87551_p0() {
    mul_ln1118_674_fu_87551_p0 =  (sc_lv<3>) (sext_ln1116_74_reg_106213.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_674_fu_87551_p1() {
    mul_ln1118_674_fu_87551_p1 = tmp_674_reg_108536.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_674_fu_87551_p2() {
    mul_ln1118_674_fu_87551_p2 = (!mul_ln1118_674_fu_87551_p0.read().is_01() || !mul_ln1118_674_fu_87551_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_674_fu_87551_p0.read()) * sc_bigint<5>(mul_ln1118_674_fu_87551_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_675_fu_42517_p0() {
    mul_ln1118_675_fu_42517_p0 =  (sc_lv<3>) (sext_ln1116_75_fu_24223_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_675_fu_42517_p1() {
    mul_ln1118_675_fu_42517_p1 = tmp_675_fu_42503_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_675_fu_42517_p2() {
    mul_ln1118_675_fu_42517_p2 = (!mul_ln1118_675_fu_42517_p0.read().is_01() || !mul_ln1118_675_fu_42517_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_675_fu_42517_p0.read()) * sc_bigint<5>(mul_ln1118_675_fu_42517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_676_fu_42549_p0() {
    mul_ln1118_676_fu_42549_p0 =  (sc_lv<3>) (sext_ln1116_76_fu_24267_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_676_fu_42549_p1() {
    mul_ln1118_676_fu_42549_p1 = tmp_676_fu_42535_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_676_fu_42549_p2() {
    mul_ln1118_676_fu_42549_p2 = (!mul_ln1118_676_fu_42549_p0.read().is_01() || !mul_ln1118_676_fu_42549_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_676_fu_42549_p0.read()) * sc_bigint<5>(mul_ln1118_676_fu_42549_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_677_fu_87571_p0() {
    mul_ln1118_677_fu_87571_p0 =  (sc_lv<3>) (sext_ln1116_77_reg_106231.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_677_fu_87571_p1() {
    mul_ln1118_677_fu_87571_p1 = tmp_677_reg_108541.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_677_fu_87571_p2() {
    mul_ln1118_677_fu_87571_p2 = (!mul_ln1118_677_fu_87571_p0.read().is_01() || !mul_ln1118_677_fu_87571_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_677_fu_87571_p0.read()) * sc_bigint<5>(mul_ln1118_677_fu_87571_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_678_fu_42591_p0() {
    mul_ln1118_678_fu_42591_p0 =  (sc_lv<3>) (sext_ln1116_78_fu_24333_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_678_fu_42591_p1() {
    mul_ln1118_678_fu_42591_p1 = tmp_678_fu_42577_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_678_fu_42591_p2() {
    mul_ln1118_678_fu_42591_p2 = (!mul_ln1118_678_fu_42591_p0.read().is_01() || !mul_ln1118_678_fu_42591_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_678_fu_42591_p0.read()) * sc_bigint<5>(mul_ln1118_678_fu_42591_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_679_fu_42623_p0() {
    mul_ln1118_679_fu_42623_p0 =  (sc_lv<3>) (sext_ln1116_79_fu_24377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_679_fu_42623_p1() {
    mul_ln1118_679_fu_42623_p1 = tmp_679_fu_42609_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_679_fu_42623_p2() {
    mul_ln1118_679_fu_42623_p2 = (!mul_ln1118_679_fu_42623_p0.read().is_01() || !mul_ln1118_679_fu_42623_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_679_fu_42623_p0.read()) * sc_bigint<5>(mul_ln1118_679_fu_42623_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_67_fu_23945_p0() {
    mul_ln1118_67_fu_23945_p0 =  (sc_lv<3>) (sext_ln1116_67_fu_23937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_67_fu_23945_p1() {
    mul_ln1118_67_fu_23945_p1 = tmp_67_fu_23927_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_67_fu_23945_p2() {
    mul_ln1118_67_fu_23945_p2 = (!mul_ln1118_67_fu_23945_p0.read().is_01() || !mul_ln1118_67_fu_23945_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_67_fu_23945_p0.read()) * sc_bigint<5>(mul_ln1118_67_fu_23945_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_680_fu_42655_p0() {
    mul_ln1118_680_fu_42655_p0 =  (sc_lv<3>) (sext_ln1116_80_fu_24421_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_680_fu_42655_p1() {
    mul_ln1118_680_fu_42655_p1 = tmp_680_fu_42641_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_680_fu_42655_p2() {
    mul_ln1118_680_fu_42655_p2 = (!mul_ln1118_680_fu_42655_p0.read().is_01() || !mul_ln1118_680_fu_42655_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_680_fu_42655_p0.read()) * sc_bigint<5>(mul_ln1118_680_fu_42655_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_681_fu_42687_p0() {
    mul_ln1118_681_fu_42687_p0 =  (sc_lv<3>) (sext_ln1116_81_fu_24465_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_681_fu_42687_p1() {
    mul_ln1118_681_fu_42687_p1 = tmp_681_fu_42673_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_681_fu_42687_p2() {
    mul_ln1118_681_fu_42687_p2 = (!mul_ln1118_681_fu_42687_p0.read().is_01() || !mul_ln1118_681_fu_42687_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_681_fu_42687_p0.read()) * sc_bigint<5>(mul_ln1118_681_fu_42687_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_682_fu_42719_p0() {
    mul_ln1118_682_fu_42719_p0 =  (sc_lv<3>) (sext_ln1116_82_fu_24509_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_682_fu_42719_p1() {
    mul_ln1118_682_fu_42719_p1 = tmp_682_fu_42705_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_682_fu_42719_p2() {
    mul_ln1118_682_fu_42719_p2 = (!mul_ln1118_682_fu_42719_p0.read().is_01() || !mul_ln1118_682_fu_42719_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_682_fu_42719_p0.read()) * sc_bigint<5>(mul_ln1118_682_fu_42719_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_683_fu_42751_p0() {
    mul_ln1118_683_fu_42751_p0 =  (sc_lv<3>) (sext_ln1116_83_fu_24553_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_683_fu_42751_p1() {
    mul_ln1118_683_fu_42751_p1 = tmp_683_fu_42737_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_683_fu_42751_p2() {
    mul_ln1118_683_fu_42751_p2 = (!mul_ln1118_683_fu_42751_p0.read().is_01() || !mul_ln1118_683_fu_42751_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_683_fu_42751_p0.read()) * sc_bigint<5>(mul_ln1118_683_fu_42751_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_684_fu_42783_p0() {
    mul_ln1118_684_fu_42783_p0 =  (sc_lv<3>) (sext_ln1116_84_fu_24597_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_684_fu_42783_p1() {
    mul_ln1118_684_fu_42783_p1 = tmp_684_fu_42769_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_684_fu_42783_p2() {
    mul_ln1118_684_fu_42783_p2 = (!mul_ln1118_684_fu_42783_p0.read().is_01() || !mul_ln1118_684_fu_42783_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_684_fu_42783_p0.read()) * sc_bigint<5>(mul_ln1118_684_fu_42783_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_685_fu_42803_p0() {
    mul_ln1118_685_fu_42803_p0 =  (sc_lv<3>) (sext_ln1116_85_fu_24629_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_685_fu_42803_p1() {
    mul_ln1118_685_fu_42803_p1 = tmp_685_fu_42789_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_685_fu_42803_p2() {
    mul_ln1118_685_fu_42803_p2 = (!mul_ln1118_685_fu_42803_p0.read().is_01() || !mul_ln1118_685_fu_42803_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_685_fu_42803_p0.read()) * sc_bigint<5>(mul_ln1118_685_fu_42803_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_686_fu_42835_p0() {
    mul_ln1118_686_fu_42835_p0 =  (sc_lv<3>) (sext_ln1116_86_fu_24673_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_686_fu_42835_p1() {
    mul_ln1118_686_fu_42835_p1 = tmp_686_fu_42821_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_686_fu_42835_p2() {
    mul_ln1118_686_fu_42835_p2 = (!mul_ln1118_686_fu_42835_p0.read().is_01() || !mul_ln1118_686_fu_42835_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_686_fu_42835_p0.read()) * sc_bigint<5>(mul_ln1118_686_fu_42835_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_687_fu_42867_p0() {
    mul_ln1118_687_fu_42867_p0 =  (sc_lv<3>) (sext_ln1116_87_fu_24717_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_687_fu_42867_p1() {
    mul_ln1118_687_fu_42867_p1 = tmp_687_fu_42853_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_687_fu_42867_p2() {
    mul_ln1118_687_fu_42867_p2 = (!mul_ln1118_687_fu_42867_p0.read().is_01() || !mul_ln1118_687_fu_42867_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_687_fu_42867_p0.read()) * sc_bigint<5>(mul_ln1118_687_fu_42867_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_688_fu_42887_p0() {
    mul_ln1118_688_fu_42887_p0 =  (sc_lv<3>) (sext_ln1116_88_fu_24749_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_688_fu_42887_p1() {
    mul_ln1118_688_fu_42887_p1 = tmp_688_fu_42873_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_688_fu_42887_p2() {
    mul_ln1118_688_fu_42887_p2 = (!mul_ln1118_688_fu_42887_p0.read().is_01() || !mul_ln1118_688_fu_42887_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_688_fu_42887_p0.read()) * sc_bigint<5>(mul_ln1118_688_fu_42887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_689_fu_42919_p0() {
    mul_ln1118_689_fu_42919_p0 =  (sc_lv<3>) (sext_ln1116_89_fu_24793_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_689_fu_42919_p1() {
    mul_ln1118_689_fu_42919_p1 = tmp_689_fu_42905_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_689_fu_42919_p2() {
    mul_ln1118_689_fu_42919_p2 = (!mul_ln1118_689_fu_42919_p0.read().is_01() || !mul_ln1118_689_fu_42919_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_689_fu_42919_p0.read()) * sc_bigint<5>(mul_ln1118_689_fu_42919_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_68_fu_80446_p0() {
    mul_ln1118_68_fu_80446_p0 =  (sc_lv<3>) (sext_ln1116_68_reg_106177.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_68_fu_80446_p1() {
    mul_ln1118_68_fu_80446_p1 = tmp_68_reg_106172.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_68_fu_80446_p2() {
    mul_ln1118_68_fu_80446_p2 = (!mul_ln1118_68_fu_80446_p0.read().is_01() || !mul_ln1118_68_fu_80446_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_68_fu_80446_p0.read()) * sc_bigint<5>(mul_ln1118_68_fu_80446_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_690_fu_87613_p0() {
    mul_ln1118_690_fu_87613_p0 =  (sc_lv<3>) (sext_ln1116_90_reg_106259.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_690_fu_87613_p1() {
    mul_ln1118_690_fu_87613_p1 = tmp_690_reg_108556.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_690_fu_87613_p2() {
    mul_ln1118_690_fu_87613_p2 = (!mul_ln1118_690_fu_87613_p0.read().is_01() || !mul_ln1118_690_fu_87613_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_690_fu_87613_p0.read()) * sc_bigint<5>(mul_ln1118_690_fu_87613_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_691_fu_42961_p0() {
    mul_ln1118_691_fu_42961_p0 =  (sc_lv<3>) (sext_ln1116_91_fu_24859_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_691_fu_42961_p1() {
    mul_ln1118_691_fu_42961_p1 = tmp_691_fu_42947_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_691_fu_42961_p2() {
    mul_ln1118_691_fu_42961_p2 = (!mul_ln1118_691_fu_42961_p0.read().is_01() || !mul_ln1118_691_fu_42961_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_691_fu_42961_p0.read()) * sc_bigint<5>(mul_ln1118_691_fu_42961_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_692_fu_42993_p0() {
    mul_ln1118_692_fu_42993_p0 =  (sc_lv<3>) (sext_ln1116_92_fu_24903_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_692_fu_42993_p1() {
    mul_ln1118_692_fu_42993_p1 = tmp_692_fu_42979_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_692_fu_42993_p2() {
    mul_ln1118_692_fu_42993_p2 = (!mul_ln1118_692_fu_42993_p0.read().is_01() || !mul_ln1118_692_fu_42993_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_692_fu_42993_p0.read()) * sc_bigint<5>(mul_ln1118_692_fu_42993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_693_fu_87633_p0() {
    mul_ln1118_693_fu_87633_p0 =  (sc_lv<3>) (sext_ln1116_93_reg_106277.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_693_fu_87633_p1() {
    mul_ln1118_693_fu_87633_p1 = tmp_693_reg_108561.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_693_fu_87633_p2() {
    mul_ln1118_693_fu_87633_p2 = (!mul_ln1118_693_fu_87633_p0.read().is_01() || !mul_ln1118_693_fu_87633_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_693_fu_87633_p0.read()) * sc_bigint<5>(mul_ln1118_693_fu_87633_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_694_fu_43035_p0() {
    mul_ln1118_694_fu_43035_p0 =  (sc_lv<3>) (sext_ln1116_94_fu_24969_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_694_fu_43035_p1() {
    mul_ln1118_694_fu_43035_p1 = tmp_694_fu_43021_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_694_fu_43035_p2() {
    mul_ln1118_694_fu_43035_p2 = (!mul_ln1118_694_fu_43035_p0.read().is_01() || !mul_ln1118_694_fu_43035_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_694_fu_43035_p0.read()) * sc_bigint<5>(mul_ln1118_694_fu_43035_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_695_fu_43067_p0() {
    mul_ln1118_695_fu_43067_p0 =  (sc_lv<3>) (sext_ln1116_95_fu_25013_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_695_fu_43067_p1() {
    mul_ln1118_695_fu_43067_p1 = tmp_695_fu_43053_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_695_fu_43067_p2() {
    mul_ln1118_695_fu_43067_p2 = (!mul_ln1118_695_fu_43067_p0.read().is_01() || !mul_ln1118_695_fu_43067_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_695_fu_43067_p0.read()) * sc_bigint<5>(mul_ln1118_695_fu_43067_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_696_fu_87653_p0() {
    mul_ln1118_696_fu_87653_p0 =  (sc_lv<3>) (sext_ln1116_96_reg_106295.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_696_fu_87653_p1() {
    mul_ln1118_696_fu_87653_p1 = tmp_696_reg_108566.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_696_fu_87653_p2() {
    mul_ln1118_696_fu_87653_p2 = (!mul_ln1118_696_fu_87653_p0.read().is_01() || !mul_ln1118_696_fu_87653_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_696_fu_87653_p0.read()) * sc_bigint<5>(mul_ln1118_696_fu_87653_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_697_fu_43109_p0() {
    mul_ln1118_697_fu_43109_p0 =  (sc_lv<3>) (sext_ln1116_97_fu_25079_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_697_fu_43109_p1() {
    mul_ln1118_697_fu_43109_p1 = tmp_697_fu_43095_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_697_fu_43109_p2() {
    mul_ln1118_697_fu_43109_p2 = (!mul_ln1118_697_fu_43109_p0.read().is_01() || !mul_ln1118_697_fu_43109_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_697_fu_43109_p0.read()) * sc_bigint<5>(mul_ln1118_697_fu_43109_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_698_fu_43141_p0() {
    mul_ln1118_698_fu_43141_p0 =  (sc_lv<3>) (sext_ln1116_98_fu_25123_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_698_fu_43141_p1() {
    mul_ln1118_698_fu_43141_p1 = tmp_698_fu_43127_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_698_fu_43141_p2() {
    mul_ln1118_698_fu_43141_p2 = (!mul_ln1118_698_fu_43141_p0.read().is_01() || !mul_ln1118_698_fu_43141_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_698_fu_43141_p0.read()) * sc_bigint<5>(mul_ln1118_698_fu_43141_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_699_fu_87673_p0() {
    mul_ln1118_699_fu_87673_p0 =  (sc_lv<3>) (sext_ln1116_99_reg_106313.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_699_fu_87673_p1() {
    mul_ln1118_699_fu_87673_p1 = tmp_699_reg_108571.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_699_fu_87673_p2() {
    mul_ln1118_699_fu_87673_p2 = (!mul_ln1118_699_fu_87673_p0.read().is_01() || !mul_ln1118_699_fu_87673_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_699_fu_87673_p0.read()) * sc_bigint<5>(mul_ln1118_699_fu_87673_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_69_fu_24011_p0() {
    mul_ln1118_69_fu_24011_p0 =  (sc_lv<3>) (sext_ln1116_69_fu_24003_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_69_fu_24011_p1() {
    mul_ln1118_69_fu_24011_p1 = tmp_69_fu_23993_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_69_fu_24011_p2() {
    mul_ln1118_69_fu_24011_p2 = (!mul_ln1118_69_fu_24011_p0.read().is_01() || !mul_ln1118_69_fu_24011_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_69_fu_24011_p0.read()) * sc_bigint<5>(mul_ln1118_69_fu_24011_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_700_fu_43183_p0() {
    mul_ln1118_700_fu_43183_p0 =  (sc_lv<3>) (sext_ln1116_100_fu_25189_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_700_fu_43183_p1() {
    mul_ln1118_700_fu_43183_p1 = tmp_700_fu_43169_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_700_fu_43183_p2() {
    mul_ln1118_700_fu_43183_p2 = (!mul_ln1118_700_fu_43183_p0.read().is_01() || !mul_ln1118_700_fu_43183_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_700_fu_43183_p0.read()) * sc_bigint<5>(mul_ln1118_700_fu_43183_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_701_fu_43215_p0() {
    mul_ln1118_701_fu_43215_p0 =  (sc_lv<3>) (sext_ln1116_101_fu_25233_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_701_fu_43215_p1() {
    mul_ln1118_701_fu_43215_p1 = tmp_701_fu_43201_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_701_fu_43215_p2() {
    mul_ln1118_701_fu_43215_p2 = (!mul_ln1118_701_fu_43215_p0.read().is_01() || !mul_ln1118_701_fu_43215_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_701_fu_43215_p0.read()) * sc_bigint<5>(mul_ln1118_701_fu_43215_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_702_fu_87693_p0() {
    mul_ln1118_702_fu_87693_p0 =  (sc_lv<3>) (sext_ln1116_102_reg_106331.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_702_fu_87693_p1() {
    mul_ln1118_702_fu_87693_p1 = tmp_702_reg_108576.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_702_fu_87693_p2() {
    mul_ln1118_702_fu_87693_p2 = (!mul_ln1118_702_fu_87693_p0.read().is_01() || !mul_ln1118_702_fu_87693_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_702_fu_87693_p0.read()) * sc_bigint<5>(mul_ln1118_702_fu_87693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_703_fu_43257_p0() {
    mul_ln1118_703_fu_43257_p0 =  (sc_lv<3>) (sext_ln1116_103_fu_25299_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_703_fu_43257_p1() {
    mul_ln1118_703_fu_43257_p1 = tmp_703_fu_43243_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_703_fu_43257_p2() {
    mul_ln1118_703_fu_43257_p2 = (!mul_ln1118_703_fu_43257_p0.read().is_01() || !mul_ln1118_703_fu_43257_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_703_fu_43257_p0.read()) * sc_bigint<5>(mul_ln1118_703_fu_43257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_704_fu_43289_p0() {
    mul_ln1118_704_fu_43289_p0 =  (sc_lv<3>) (sext_ln1116_104_fu_25343_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_704_fu_43289_p1() {
    mul_ln1118_704_fu_43289_p1 = tmp_704_fu_43275_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_704_fu_43289_p2() {
    mul_ln1118_704_fu_43289_p2 = (!mul_ln1118_704_fu_43289_p0.read().is_01() || !mul_ln1118_704_fu_43289_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_704_fu_43289_p0.read()) * sc_bigint<5>(mul_ln1118_704_fu_43289_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_705_fu_43321_p0() {
    mul_ln1118_705_fu_43321_p0 =  (sc_lv<3>) (sext_ln1116_105_fu_25387_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_705_fu_43321_p1() {
    mul_ln1118_705_fu_43321_p1 = tmp_705_fu_43307_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_705_fu_43321_p2() {
    mul_ln1118_705_fu_43321_p2 = (!mul_ln1118_705_fu_43321_p0.read().is_01() || !mul_ln1118_705_fu_43321_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_705_fu_43321_p0.read()) * sc_bigint<5>(mul_ln1118_705_fu_43321_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_706_fu_43353_p0() {
    mul_ln1118_706_fu_43353_p0 =  (sc_lv<3>) (sext_ln1116_106_fu_25431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_706_fu_43353_p1() {
    mul_ln1118_706_fu_43353_p1 = tmp_706_fu_43339_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_706_fu_43353_p2() {
    mul_ln1118_706_fu_43353_p2 = (!mul_ln1118_706_fu_43353_p0.read().is_01() || !mul_ln1118_706_fu_43353_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_706_fu_43353_p0.read()) * sc_bigint<5>(mul_ln1118_706_fu_43353_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_707_fu_43385_p0() {
    mul_ln1118_707_fu_43385_p0 =  (sc_lv<3>) (sext_ln1116_107_fu_25475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_707_fu_43385_p1() {
    mul_ln1118_707_fu_43385_p1 = tmp_707_fu_43371_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_707_fu_43385_p2() {
    mul_ln1118_707_fu_43385_p2 = (!mul_ln1118_707_fu_43385_p0.read().is_01() || !mul_ln1118_707_fu_43385_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_707_fu_43385_p0.read()) * sc_bigint<5>(mul_ln1118_707_fu_43385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_708_fu_43417_p0() {
    mul_ln1118_708_fu_43417_p0 =  (sc_lv<3>) (sext_ln1116_108_fu_25519_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_708_fu_43417_p1() {
    mul_ln1118_708_fu_43417_p1 = tmp_708_fu_43403_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_708_fu_43417_p2() {
    mul_ln1118_708_fu_43417_p2 = (!mul_ln1118_708_fu_43417_p0.read().is_01() || !mul_ln1118_708_fu_43417_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_708_fu_43417_p0.read()) * sc_bigint<5>(mul_ln1118_708_fu_43417_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_709_fu_43449_p0() {
    mul_ln1118_709_fu_43449_p0 =  (sc_lv<3>) (sext_ln1116_109_fu_25563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_709_fu_43449_p1() {
    mul_ln1118_709_fu_43449_p1 = tmp_709_fu_43435_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_709_fu_43449_p2() {
    mul_ln1118_709_fu_43449_p2 = (!mul_ln1118_709_fu_43449_p0.read().is_01() || !mul_ln1118_709_fu_43449_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_709_fu_43449_p0.read()) * sc_bigint<5>(mul_ln1118_709_fu_43449_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_70_fu_24055_p0() {
    mul_ln1118_70_fu_24055_p0 =  (sc_lv<3>) (sext_ln1116_70_fu_24047_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_70_fu_24055_p1() {
    mul_ln1118_70_fu_24055_p1 = tmp_70_fu_24037_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_70_fu_24055_p2() {
    mul_ln1118_70_fu_24055_p2 = (!mul_ln1118_70_fu_24055_p0.read().is_01() || !mul_ln1118_70_fu_24055_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_70_fu_24055_p0.read()) * sc_bigint<5>(mul_ln1118_70_fu_24055_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_710_fu_43469_p0() {
    mul_ln1118_710_fu_43469_p0 =  (sc_lv<3>) (sext_ln1116_110_fu_25595_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_710_fu_43469_p1() {
    mul_ln1118_710_fu_43469_p1 = tmp_710_fu_43455_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_710_fu_43469_p2() {
    mul_ln1118_710_fu_43469_p2 = (!mul_ln1118_710_fu_43469_p0.read().is_01() || !mul_ln1118_710_fu_43469_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_710_fu_43469_p0.read()) * sc_bigint<5>(mul_ln1118_710_fu_43469_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_711_fu_43501_p0() {
    mul_ln1118_711_fu_43501_p0 =  (sc_lv<3>) (sext_ln1116_111_fu_25639_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_711_fu_43501_p1() {
    mul_ln1118_711_fu_43501_p1 = tmp_711_fu_43487_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_711_fu_43501_p2() {
    mul_ln1118_711_fu_43501_p2 = (!mul_ln1118_711_fu_43501_p0.read().is_01() || !mul_ln1118_711_fu_43501_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_711_fu_43501_p0.read()) * sc_bigint<5>(mul_ln1118_711_fu_43501_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_712_fu_43533_p0() {
    mul_ln1118_712_fu_43533_p0 =  (sc_lv<3>) (sext_ln1116_112_fu_25683_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_712_fu_43533_p1() {
    mul_ln1118_712_fu_43533_p1 = tmp_712_fu_43519_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_712_fu_43533_p2() {
    mul_ln1118_712_fu_43533_p2 = (!mul_ln1118_712_fu_43533_p0.read().is_01() || !mul_ln1118_712_fu_43533_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_712_fu_43533_p0.read()) * sc_bigint<5>(mul_ln1118_712_fu_43533_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_713_fu_43553_p0() {
    mul_ln1118_713_fu_43553_p0 =  (sc_lv<3>) (sext_ln1116_113_fu_25715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_713_fu_43553_p1() {
    mul_ln1118_713_fu_43553_p1 = tmp_713_fu_43539_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_713_fu_43553_p2() {
    mul_ln1118_713_fu_43553_p2 = (!mul_ln1118_713_fu_43553_p0.read().is_01() || !mul_ln1118_713_fu_43553_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_713_fu_43553_p0.read()) * sc_bigint<5>(mul_ln1118_713_fu_43553_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_714_fu_43585_p0() {
    mul_ln1118_714_fu_43585_p0 =  (sc_lv<3>) (sext_ln1116_114_fu_25759_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_714_fu_43585_p1() {
    mul_ln1118_714_fu_43585_p1 = tmp_714_fu_43571_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_714_fu_43585_p2() {
    mul_ln1118_714_fu_43585_p2 = (!mul_ln1118_714_fu_43585_p0.read().is_01() || !mul_ln1118_714_fu_43585_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_714_fu_43585_p0.read()) * sc_bigint<5>(mul_ln1118_714_fu_43585_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_715_fu_87735_p0() {
    mul_ln1118_715_fu_87735_p0 =  (sc_lv<3>) (sext_ln1116_115_reg_106359.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_715_fu_87735_p1() {
    mul_ln1118_715_fu_87735_p1 = tmp_715_reg_108591.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_715_fu_87735_p2() {
    mul_ln1118_715_fu_87735_p2 = (!mul_ln1118_715_fu_87735_p0.read().is_01() || !mul_ln1118_715_fu_87735_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_715_fu_87735_p0.read()) * sc_bigint<5>(mul_ln1118_715_fu_87735_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_716_fu_43627_p0() {
    mul_ln1118_716_fu_43627_p0 =  (sc_lv<3>) (sext_ln1116_116_fu_25825_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_716_fu_43627_p1() {
    mul_ln1118_716_fu_43627_p1 = tmp_716_fu_43613_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_716_fu_43627_p2() {
    mul_ln1118_716_fu_43627_p2 = (!mul_ln1118_716_fu_43627_p0.read().is_01() || !mul_ln1118_716_fu_43627_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_716_fu_43627_p0.read()) * sc_bigint<5>(mul_ln1118_716_fu_43627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_717_fu_43659_p0() {
    mul_ln1118_717_fu_43659_p0 =  (sc_lv<3>) (sext_ln1116_117_fu_25869_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_717_fu_43659_p1() {
    mul_ln1118_717_fu_43659_p1 = tmp_717_fu_43645_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_717_fu_43659_p2() {
    mul_ln1118_717_fu_43659_p2 = (!mul_ln1118_717_fu_43659_p0.read().is_01() || !mul_ln1118_717_fu_43659_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_717_fu_43659_p0.read()) * sc_bigint<5>(mul_ln1118_717_fu_43659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_718_fu_87755_p0() {
    mul_ln1118_718_fu_87755_p0 =  (sc_lv<3>) (sext_ln1116_118_reg_106377.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_718_fu_87755_p1() {
    mul_ln1118_718_fu_87755_p1 = tmp_718_reg_108596.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_718_fu_87755_p2() {
    mul_ln1118_718_fu_87755_p2 = (!mul_ln1118_718_fu_87755_p0.read().is_01() || !mul_ln1118_718_fu_87755_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_718_fu_87755_p0.read()) * sc_bigint<5>(mul_ln1118_718_fu_87755_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_719_fu_43701_p0() {
    mul_ln1118_719_fu_43701_p0 =  (sc_lv<3>) (sext_ln1116_119_fu_25935_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_719_fu_43701_p1() {
    mul_ln1118_719_fu_43701_p1 = tmp_719_fu_43687_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_719_fu_43701_p2() {
    mul_ln1118_719_fu_43701_p2 = (!mul_ln1118_719_fu_43701_p0.read().is_01() || !mul_ln1118_719_fu_43701_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_719_fu_43701_p0.read()) * sc_bigint<5>(mul_ln1118_719_fu_43701_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_71_fu_80466_p0() {
    mul_ln1118_71_fu_80466_p0 =  (sc_lv<3>) (sext_ln1116_71_reg_106195.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_71_fu_80466_p1() {
    mul_ln1118_71_fu_80466_p1 = tmp_71_reg_106190.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_71_fu_80466_p2() {
    mul_ln1118_71_fu_80466_p2 = (!mul_ln1118_71_fu_80466_p0.read().is_01() || !mul_ln1118_71_fu_80466_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_71_fu_80466_p0.read()) * sc_bigint<5>(mul_ln1118_71_fu_80466_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_720_fu_43733_p0() {
    mul_ln1118_720_fu_43733_p0 =  (sc_lv<3>) (sext_ln1116_120_fu_25979_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_720_fu_43733_p1() {
    mul_ln1118_720_fu_43733_p1 = tmp_720_fu_43719_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_720_fu_43733_p2() {
    mul_ln1118_720_fu_43733_p2 = (!mul_ln1118_720_fu_43733_p0.read().is_01() || !mul_ln1118_720_fu_43733_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_720_fu_43733_p0.read()) * sc_bigint<5>(mul_ln1118_720_fu_43733_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_721_fu_87775_p0() {
    mul_ln1118_721_fu_87775_p0 =  (sc_lv<3>) (sext_ln1116_121_reg_106395.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_721_fu_87775_p1() {
    mul_ln1118_721_fu_87775_p1 = tmp_721_reg_108601.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_721_fu_87775_p2() {
    mul_ln1118_721_fu_87775_p2 = (!mul_ln1118_721_fu_87775_p0.read().is_01() || !mul_ln1118_721_fu_87775_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_721_fu_87775_p0.read()) * sc_bigint<5>(mul_ln1118_721_fu_87775_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_722_fu_43775_p0() {
    mul_ln1118_722_fu_43775_p0 =  (sc_lv<3>) (sext_ln1116_122_fu_26045_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_722_fu_43775_p1() {
    mul_ln1118_722_fu_43775_p1 = tmp_722_fu_43761_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_722_fu_43775_p2() {
    mul_ln1118_722_fu_43775_p2 = (!mul_ln1118_722_fu_43775_p0.read().is_01() || !mul_ln1118_722_fu_43775_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_722_fu_43775_p0.read()) * sc_bigint<5>(mul_ln1118_722_fu_43775_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_723_fu_43807_p0() {
    mul_ln1118_723_fu_43807_p0 =  (sc_lv<3>) (sext_ln1116_123_fu_26089_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_723_fu_43807_p1() {
    mul_ln1118_723_fu_43807_p1 = tmp_723_fu_43793_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_723_fu_43807_p2() {
    mul_ln1118_723_fu_43807_p2 = (!mul_ln1118_723_fu_43807_p0.read().is_01() || !mul_ln1118_723_fu_43807_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_723_fu_43807_p0.read()) * sc_bigint<5>(mul_ln1118_723_fu_43807_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_724_fu_87795_p0() {
    mul_ln1118_724_fu_87795_p0 =  (sc_lv<3>) (sext_ln1116_124_reg_106413.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_724_fu_87795_p1() {
    mul_ln1118_724_fu_87795_p1 = tmp_724_reg_108606.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_724_fu_87795_p2() {
    mul_ln1118_724_fu_87795_p2 = (!mul_ln1118_724_fu_87795_p0.read().is_01() || !mul_ln1118_724_fu_87795_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_724_fu_87795_p0.read()) * sc_bigint<5>(mul_ln1118_724_fu_87795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_725_fu_43849_p0() {
    mul_ln1118_725_fu_43849_p0 =  (sc_lv<3>) (sext_ln1116_125_fu_26155_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_725_fu_43849_p1() {
    mul_ln1118_725_fu_43849_p1 = tmp_725_fu_43835_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_725_fu_43849_p2() {
    mul_ln1118_725_fu_43849_p2 = (!mul_ln1118_725_fu_43849_p0.read().is_01() || !mul_ln1118_725_fu_43849_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_725_fu_43849_p0.read()) * sc_bigint<5>(mul_ln1118_725_fu_43849_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_726_fu_43881_p0() {
    mul_ln1118_726_fu_43881_p0 =  (sc_lv<3>) (sext_ln1116_126_fu_26199_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_726_fu_43881_p1() {
    mul_ln1118_726_fu_43881_p1 = tmp_726_fu_43867_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_726_fu_43881_p2() {
    mul_ln1118_726_fu_43881_p2 = (!mul_ln1118_726_fu_43881_p0.read().is_01() || !mul_ln1118_726_fu_43881_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_726_fu_43881_p0.read()) * sc_bigint<5>(mul_ln1118_726_fu_43881_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_727_fu_87815_p0() {
    mul_ln1118_727_fu_87815_p0 =  (sc_lv<3>) (sext_ln1116_127_reg_106431.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_727_fu_87815_p1() {
    mul_ln1118_727_fu_87815_p1 = tmp_727_reg_108611.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_727_fu_87815_p2() {
    mul_ln1118_727_fu_87815_p2 = (!mul_ln1118_727_fu_87815_p0.read().is_01() || !mul_ln1118_727_fu_87815_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_727_fu_87815_p0.read()) * sc_bigint<5>(mul_ln1118_727_fu_87815_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_728_fu_43923_p0() {
    mul_ln1118_728_fu_43923_p0 =  (sc_lv<3>) (sext_ln1116_128_fu_26265_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_728_fu_43923_p1() {
    mul_ln1118_728_fu_43923_p1 = tmp_728_fu_43909_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_728_fu_43923_p2() {
    mul_ln1118_728_fu_43923_p2 = (!mul_ln1118_728_fu_43923_p0.read().is_01() || !mul_ln1118_728_fu_43923_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_728_fu_43923_p0.read()) * sc_bigint<5>(mul_ln1118_728_fu_43923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_729_fu_43955_p0() {
    mul_ln1118_729_fu_43955_p0 =  (sc_lv<3>) (sext_ln1116_129_fu_26309_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_729_fu_43955_p1() {
    mul_ln1118_729_fu_43955_p1 = tmp_729_fu_43941_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_729_fu_43955_p2() {
    mul_ln1118_729_fu_43955_p2 = (!mul_ln1118_729_fu_43955_p0.read().is_01() || !mul_ln1118_729_fu_43955_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_729_fu_43955_p0.read()) * sc_bigint<5>(mul_ln1118_729_fu_43955_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_72_fu_24121_p0() {
    mul_ln1118_72_fu_24121_p0 =  (sc_lv<3>) (sext_ln1116_72_fu_24113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_72_fu_24121_p1() {
    mul_ln1118_72_fu_24121_p1 = tmp_72_fu_24103_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_72_fu_24121_p2() {
    mul_ln1118_72_fu_24121_p2 = (!mul_ln1118_72_fu_24121_p0.read().is_01() || !mul_ln1118_72_fu_24121_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_72_fu_24121_p0.read()) * sc_bigint<5>(mul_ln1118_72_fu_24121_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_730_fu_43987_p0() {
    mul_ln1118_730_fu_43987_p0 =  (sc_lv<3>) (sext_ln1116_130_fu_26353_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_730_fu_43987_p1() {
    mul_ln1118_730_fu_43987_p1 = tmp_730_fu_43973_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_730_fu_43987_p2() {
    mul_ln1118_730_fu_43987_p2 = (!mul_ln1118_730_fu_43987_p0.read().is_01() || !mul_ln1118_730_fu_43987_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_730_fu_43987_p0.read()) * sc_bigint<5>(mul_ln1118_730_fu_43987_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_731_fu_44019_p0() {
    mul_ln1118_731_fu_44019_p0 =  (sc_lv<3>) (sext_ln1116_131_fu_26397_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_731_fu_44019_p1() {
    mul_ln1118_731_fu_44019_p1 = tmp_731_fu_44005_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_731_fu_44019_p2() {
    mul_ln1118_731_fu_44019_p2 = (!mul_ln1118_731_fu_44019_p0.read().is_01() || !mul_ln1118_731_fu_44019_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_731_fu_44019_p0.read()) * sc_bigint<5>(mul_ln1118_731_fu_44019_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_732_fu_44051_p0() {
    mul_ln1118_732_fu_44051_p0 =  (sc_lv<3>) (sext_ln1116_132_fu_26441_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_732_fu_44051_p1() {
    mul_ln1118_732_fu_44051_p1 = tmp_732_fu_44037_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_732_fu_44051_p2() {
    mul_ln1118_732_fu_44051_p2 = (!mul_ln1118_732_fu_44051_p0.read().is_01() || !mul_ln1118_732_fu_44051_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_732_fu_44051_p0.read()) * sc_bigint<5>(mul_ln1118_732_fu_44051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_733_fu_44083_p0() {
    mul_ln1118_733_fu_44083_p0 =  (sc_lv<3>) (sext_ln1116_133_fu_26485_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_733_fu_44083_p1() {
    mul_ln1118_733_fu_44083_p1 = tmp_733_fu_44069_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_733_fu_44083_p2() {
    mul_ln1118_733_fu_44083_p2 = (!mul_ln1118_733_fu_44083_p0.read().is_01() || !mul_ln1118_733_fu_44083_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_733_fu_44083_p0.read()) * sc_bigint<5>(mul_ln1118_733_fu_44083_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_734_fu_87835_p0() {
    mul_ln1118_734_fu_87835_p0 =  (sc_lv<3>) (sext_ln1116_134_reg_106449.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_734_fu_87835_p1() {
    mul_ln1118_734_fu_87835_p1 = tmp_734_reg_108616.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_734_fu_87835_p2() {
    mul_ln1118_734_fu_87835_p2 = (!mul_ln1118_734_fu_87835_p0.read().is_01() || !mul_ln1118_734_fu_87835_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_734_fu_87835_p0.read()) * sc_bigint<5>(mul_ln1118_734_fu_87835_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_735_fu_44125_p0() {
    mul_ln1118_735_fu_44125_p0 =  (sc_lv<3>) (sext_ln1116_135_fu_26551_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_735_fu_44125_p1() {
    mul_ln1118_735_fu_44125_p1 = tmp_735_fu_44111_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_735_fu_44125_p2() {
    mul_ln1118_735_fu_44125_p2 = (!mul_ln1118_735_fu_44125_p0.read().is_01() || !mul_ln1118_735_fu_44125_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_735_fu_44125_p0.read()) * sc_bigint<5>(mul_ln1118_735_fu_44125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_736_fu_44157_p0() {
    mul_ln1118_736_fu_44157_p0 =  (sc_lv<3>) (sext_ln1116_136_fu_26595_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_736_fu_44157_p1() {
    mul_ln1118_736_fu_44157_p1 = tmp_736_fu_44143_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_736_fu_44157_p2() {
    mul_ln1118_736_fu_44157_p2 = (!mul_ln1118_736_fu_44157_p0.read().is_01() || !mul_ln1118_736_fu_44157_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_736_fu_44157_p0.read()) * sc_bigint<5>(mul_ln1118_736_fu_44157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_737_fu_87855_p0() {
    mul_ln1118_737_fu_87855_p0 =  (sc_lv<3>) (sext_ln1116_137_reg_106467.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_737_fu_87855_p1() {
    mul_ln1118_737_fu_87855_p1 = tmp_737_reg_108621.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_737_fu_87855_p2() {
    mul_ln1118_737_fu_87855_p2 = (!mul_ln1118_737_fu_87855_p0.read().is_01() || !mul_ln1118_737_fu_87855_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_737_fu_87855_p0.read()) * sc_bigint<5>(mul_ln1118_737_fu_87855_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_738_fu_44199_p0() {
    mul_ln1118_738_fu_44199_p0 =  (sc_lv<3>) (sext_ln1116_138_fu_26661_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_738_fu_44199_p1() {
    mul_ln1118_738_fu_44199_p1 = tmp_738_fu_44185_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_738_fu_44199_p2() {
    mul_ln1118_738_fu_44199_p2 = (!mul_ln1118_738_fu_44199_p0.read().is_01() || !mul_ln1118_738_fu_44199_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_738_fu_44199_p0.read()) * sc_bigint<5>(mul_ln1118_738_fu_44199_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_739_fu_44231_p0() {
    mul_ln1118_739_fu_44231_p0 =  (sc_lv<3>) (sext_ln1116_139_fu_26705_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_739_fu_44231_p1() {
    mul_ln1118_739_fu_44231_p1 = tmp_739_fu_44217_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_739_fu_44231_p2() {
    mul_ln1118_739_fu_44231_p2 = (!mul_ln1118_739_fu_44231_p0.read().is_01() || !mul_ln1118_739_fu_44231_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_739_fu_44231_p0.read()) * sc_bigint<5>(mul_ln1118_739_fu_44231_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_73_fu_24165_p0() {
    mul_ln1118_73_fu_24165_p0 =  (sc_lv<3>) (sext_ln1116_73_fu_24157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_73_fu_24165_p1() {
    mul_ln1118_73_fu_24165_p1 = tmp_73_fu_24147_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_73_fu_24165_p2() {
    mul_ln1118_73_fu_24165_p2 = (!mul_ln1118_73_fu_24165_p0.read().is_01() || !mul_ln1118_73_fu_24165_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_73_fu_24165_p0.read()) * sc_bigint<5>(mul_ln1118_73_fu_24165_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_740_fu_87875_p0() {
    mul_ln1118_740_fu_87875_p0 =  (sc_lv<3>) (sext_ln1116_140_fu_80807_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_740_fu_87875_p1() {
    mul_ln1118_740_fu_87875_p1 = tmp_740_reg_108626.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_740_fu_87875_p2() {
    mul_ln1118_740_fu_87875_p2 = (!mul_ln1118_740_fu_87875_p0.read().is_01() || !mul_ln1118_740_fu_87875_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_740_fu_87875_p0.read()) * sc_bigint<5>(mul_ln1118_740_fu_87875_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_741_fu_87896_p0() {
    mul_ln1118_741_fu_87896_p0 =  (sc_lv<3>) (sext_ln1116_141_fu_80831_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_741_fu_87896_p1() {
    mul_ln1118_741_fu_87896_p1 = tmp_741_reg_108631.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_741_fu_87896_p2() {
    mul_ln1118_741_fu_87896_p2 = (!mul_ln1118_741_fu_87896_p0.read().is_01() || !mul_ln1118_741_fu_87896_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_741_fu_87896_p0.read()) * sc_bigint<5>(mul_ln1118_741_fu_87896_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_742_fu_87917_p0() {
    mul_ln1118_742_fu_87917_p0 =  (sc_lv<3>) (sext_ln1116_142_fu_80855_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_742_fu_87917_p1() {
    mul_ln1118_742_fu_87917_p1 = tmp_742_reg_108636.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_742_fu_87917_p2() {
    mul_ln1118_742_fu_87917_p2 = (!mul_ln1118_742_fu_87917_p0.read().is_01() || !mul_ln1118_742_fu_87917_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_742_fu_87917_p0.read()) * sc_bigint<5>(mul_ln1118_742_fu_87917_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_743_fu_87938_p0() {
    mul_ln1118_743_fu_87938_p0 =  (sc_lv<3>) (sext_ln1116_143_fu_80879_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_743_fu_87938_p1() {
    mul_ln1118_743_fu_87938_p1 = tmp_743_reg_108641.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_743_fu_87938_p2() {
    mul_ln1118_743_fu_87938_p2 = (!mul_ln1118_743_fu_87938_p0.read().is_01() || !mul_ln1118_743_fu_87938_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_743_fu_87938_p0.read()) * sc_bigint<5>(mul_ln1118_743_fu_87938_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_744_fu_44303_p0() {
    mul_ln1118_744_fu_44303_p0 =  (sc_lv<3>) (sext_ln1116_144_fu_26821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_744_fu_44303_p1() {
    mul_ln1118_744_fu_44303_p1 = tmp_744_fu_44289_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_744_fu_44303_p2() {
    mul_ln1118_744_fu_44303_p2 = (!mul_ln1118_744_fu_44303_p0.read().is_01() || !mul_ln1118_744_fu_44303_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_744_fu_44303_p0.read()) * sc_bigint<5>(mul_ln1118_744_fu_44303_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_745_fu_44335_p0() {
    mul_ln1118_745_fu_44335_p0 =  (sc_lv<3>) (sext_ln1116_145_fu_26865_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_745_fu_44335_p1() {
    mul_ln1118_745_fu_44335_p1 = tmp_745_fu_44321_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_745_fu_44335_p2() {
    mul_ln1118_745_fu_44335_p2 = (!mul_ln1118_745_fu_44335_p0.read().is_01() || !mul_ln1118_745_fu_44335_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_745_fu_44335_p0.read()) * sc_bigint<5>(mul_ln1118_745_fu_44335_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_746_fu_87959_p0() {
    mul_ln1118_746_fu_87959_p0 =  (sc_lv<3>) (sext_ln1116_146_reg_106525.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_746_fu_87959_p1() {
    mul_ln1118_746_fu_87959_p1 = tmp_746_reg_108646.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_746_fu_87959_p2() {
    mul_ln1118_746_fu_87959_p2 = (!mul_ln1118_746_fu_87959_p0.read().is_01() || !mul_ln1118_746_fu_87959_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_746_fu_87959_p0.read()) * sc_bigint<5>(mul_ln1118_746_fu_87959_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_747_fu_44377_p0() {
    mul_ln1118_747_fu_44377_p0 =  (sc_lv<3>) (sext_ln1116_147_fu_26931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_747_fu_44377_p1() {
    mul_ln1118_747_fu_44377_p1 = tmp_747_fu_44363_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_747_fu_44377_p2() {
    mul_ln1118_747_fu_44377_p2 = (!mul_ln1118_747_fu_44377_p0.read().is_01() || !mul_ln1118_747_fu_44377_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_747_fu_44377_p0.read()) * sc_bigint<5>(mul_ln1118_747_fu_44377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_748_fu_44409_p0() {
    mul_ln1118_748_fu_44409_p0 =  (sc_lv<3>) (sext_ln1116_148_fu_26975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_748_fu_44409_p1() {
    mul_ln1118_748_fu_44409_p1 = tmp_748_fu_44395_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_748_fu_44409_p2() {
    mul_ln1118_748_fu_44409_p2 = (!mul_ln1118_748_fu_44409_p0.read().is_01() || !mul_ln1118_748_fu_44409_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_748_fu_44409_p0.read()) * sc_bigint<5>(mul_ln1118_748_fu_44409_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_749_fu_87979_p0() {
    mul_ln1118_749_fu_87979_p0 =  (sc_lv<3>) (sext_ln1116_149_reg_106543.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_749_fu_87979_p1() {
    mul_ln1118_749_fu_87979_p1 = tmp_749_reg_108651.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_749_fu_87979_p2() {
    mul_ln1118_749_fu_87979_p2 = (!mul_ln1118_749_fu_87979_p0.read().is_01() || !mul_ln1118_749_fu_87979_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_749_fu_87979_p0.read()) * sc_bigint<5>(mul_ln1118_749_fu_87979_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_74_fu_80486_p0() {
    mul_ln1118_74_fu_80486_p0 =  (sc_lv<3>) (sext_ln1116_74_reg_106213.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_74_fu_80486_p1() {
    mul_ln1118_74_fu_80486_p1 = tmp_74_reg_106208.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_74_fu_80486_p2() {
    mul_ln1118_74_fu_80486_p2 = (!mul_ln1118_74_fu_80486_p0.read().is_01() || !mul_ln1118_74_fu_80486_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_74_fu_80486_p0.read()) * sc_bigint<5>(mul_ln1118_74_fu_80486_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_750_fu_44451_p0() {
    mul_ln1118_750_fu_44451_p0 =  (sc_lv<3>) (sext_ln1116_150_fu_27041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_750_fu_44451_p1() {
    mul_ln1118_750_fu_44451_p1 = tmp_750_fu_44437_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_750_fu_44451_p2() {
    mul_ln1118_750_fu_44451_p2 = (!mul_ln1118_750_fu_44451_p0.read().is_01() || !mul_ln1118_750_fu_44451_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_750_fu_44451_p0.read()) * sc_bigint<5>(mul_ln1118_750_fu_44451_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_751_fu_44483_p0() {
    mul_ln1118_751_fu_44483_p0 =  (sc_lv<3>) (sext_ln1116_151_fu_27085_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_751_fu_44483_p1() {
    mul_ln1118_751_fu_44483_p1 = tmp_751_fu_44469_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_751_fu_44483_p2() {
    mul_ln1118_751_fu_44483_p2 = (!mul_ln1118_751_fu_44483_p0.read().is_01() || !mul_ln1118_751_fu_44483_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_751_fu_44483_p0.read()) * sc_bigint<5>(mul_ln1118_751_fu_44483_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_752_fu_87999_p0() {
    mul_ln1118_752_fu_87999_p0 =  (sc_lv<3>) (sext_ln1116_152_fu_80943_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_752_fu_87999_p1() {
    mul_ln1118_752_fu_87999_p1 = tmp_752_reg_108656.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_752_fu_87999_p2() {
    mul_ln1118_752_fu_87999_p2 = (!mul_ln1118_752_fu_87999_p0.read().is_01() || !mul_ln1118_752_fu_87999_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_752_fu_87999_p0.read()) * sc_bigint<5>(mul_ln1118_752_fu_87999_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_753_fu_44525_p0() {
    mul_ln1118_753_fu_44525_p0 =  (sc_lv<3>) (sext_ln1116_153_fu_27147_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_753_fu_44525_p1() {
    mul_ln1118_753_fu_44525_p1 = tmp_753_fu_44511_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_753_fu_44525_p2() {
    mul_ln1118_753_fu_44525_p2 = (!mul_ln1118_753_fu_44525_p0.read().is_01() || !mul_ln1118_753_fu_44525_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_753_fu_44525_p0.read()) * sc_bigint<5>(mul_ln1118_753_fu_44525_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_754_fu_44557_p0() {
    mul_ln1118_754_fu_44557_p0 =  (sc_lv<3>) (sext_ln1116_154_fu_27191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_754_fu_44557_p1() {
    mul_ln1118_754_fu_44557_p1 = tmp_754_fu_44543_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_754_fu_44557_p2() {
    mul_ln1118_754_fu_44557_p2 = (!mul_ln1118_754_fu_44557_p0.read().is_01() || !mul_ln1118_754_fu_44557_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_754_fu_44557_p0.read()) * sc_bigint<5>(mul_ln1118_754_fu_44557_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_755_fu_44589_p0() {
    mul_ln1118_755_fu_44589_p0 =  (sc_lv<3>) (sext_ln1116_155_fu_27235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_755_fu_44589_p1() {
    mul_ln1118_755_fu_44589_p1 = tmp_755_fu_44575_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_755_fu_44589_p2() {
    mul_ln1118_755_fu_44589_p2 = (!mul_ln1118_755_fu_44589_p0.read().is_01() || !mul_ln1118_755_fu_44589_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_755_fu_44589_p0.read()) * sc_bigint<5>(mul_ln1118_755_fu_44589_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_756_fu_44621_p0() {
    mul_ln1118_756_fu_44621_p0 =  (sc_lv<3>) (sext_ln1116_156_fu_27279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_756_fu_44621_p1() {
    mul_ln1118_756_fu_44621_p1 = tmp_756_fu_44607_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_756_fu_44621_p2() {
    mul_ln1118_756_fu_44621_p2 = (!mul_ln1118_756_fu_44621_p0.read().is_01() || !mul_ln1118_756_fu_44621_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_756_fu_44621_p0.read()) * sc_bigint<5>(mul_ln1118_756_fu_44621_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_757_fu_44653_p0() {
    mul_ln1118_757_fu_44653_p0 =  (sc_lv<3>) (sext_ln1116_157_fu_27323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_757_fu_44653_p1() {
    mul_ln1118_757_fu_44653_p1 = tmp_757_fu_44639_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_757_fu_44653_p2() {
    mul_ln1118_757_fu_44653_p2 = (!mul_ln1118_757_fu_44653_p0.read().is_01() || !mul_ln1118_757_fu_44653_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_757_fu_44653_p0.read()) * sc_bigint<5>(mul_ln1118_757_fu_44653_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_758_fu_44685_p0() {
    mul_ln1118_758_fu_44685_p0 =  (sc_lv<3>) (sext_ln1116_158_fu_27367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_758_fu_44685_p1() {
    mul_ln1118_758_fu_44685_p1 = tmp_758_fu_44671_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_758_fu_44685_p2() {
    mul_ln1118_758_fu_44685_p2 = (!mul_ln1118_758_fu_44685_p0.read().is_01() || !mul_ln1118_758_fu_44685_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_758_fu_44685_p0.read()) * sc_bigint<5>(mul_ln1118_758_fu_44685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_759_fu_44717_p0() {
    mul_ln1118_759_fu_44717_p0 =  (sc_lv<3>) (sext_ln1116_159_fu_27411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_759_fu_44717_p1() {
    mul_ln1118_759_fu_44717_p1 = tmp_759_fu_44703_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_759_fu_44717_p2() {
    mul_ln1118_759_fu_44717_p2 = (!mul_ln1118_759_fu_44717_p0.read().is_01() || !mul_ln1118_759_fu_44717_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_759_fu_44717_p0.read()) * sc_bigint<5>(mul_ln1118_759_fu_44717_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_75_fu_24231_p0() {
    mul_ln1118_75_fu_24231_p0 =  (sc_lv<3>) (sext_ln1116_75_fu_24223_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_75_fu_24231_p1() {
    mul_ln1118_75_fu_24231_p1 = tmp_75_fu_24213_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_75_fu_24231_p2() {
    mul_ln1118_75_fu_24231_p2 = (!mul_ln1118_75_fu_24231_p0.read().is_01() || !mul_ln1118_75_fu_24231_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_75_fu_24231_p0.read()) * sc_bigint<5>(mul_ln1118_75_fu_24231_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_760_fu_44737_p0() {
    mul_ln1118_760_fu_44737_p0 =  (sc_lv<3>) (sext_ln1116_160_fu_27443_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_760_fu_44737_p1() {
    mul_ln1118_760_fu_44737_p1 = tmp_760_fu_44723_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_760_fu_44737_p2() {
    mul_ln1118_760_fu_44737_p2 = (!mul_ln1118_760_fu_44737_p0.read().is_01() || !mul_ln1118_760_fu_44737_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_760_fu_44737_p0.read()) * sc_bigint<5>(mul_ln1118_760_fu_44737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_761_fu_44769_p0() {
    mul_ln1118_761_fu_44769_p0 =  (sc_lv<3>) (sext_ln1116_161_fu_27487_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_761_fu_44769_p1() {
    mul_ln1118_761_fu_44769_p1 = tmp_761_fu_44755_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_761_fu_44769_p2() {
    mul_ln1118_761_fu_44769_p2 = (!mul_ln1118_761_fu_44769_p0.read().is_01() || !mul_ln1118_761_fu_44769_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_761_fu_44769_p0.read()) * sc_bigint<5>(mul_ln1118_761_fu_44769_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_762_fu_44801_p0() {
    mul_ln1118_762_fu_44801_p0 =  (sc_lv<3>) (sext_ln1116_162_fu_27531_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_762_fu_44801_p1() {
    mul_ln1118_762_fu_44801_p1 = tmp_762_fu_44787_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_762_fu_44801_p2() {
    mul_ln1118_762_fu_44801_p2 = (!mul_ln1118_762_fu_44801_p0.read().is_01() || !mul_ln1118_762_fu_44801_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_762_fu_44801_p0.read()) * sc_bigint<5>(mul_ln1118_762_fu_44801_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_763_fu_44821_p0() {
    mul_ln1118_763_fu_44821_p0 =  (sc_lv<3>) (sext_ln1116_163_fu_27563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_763_fu_44821_p1() {
    mul_ln1118_763_fu_44821_p1 = tmp_763_fu_44807_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_763_fu_44821_p2() {
    mul_ln1118_763_fu_44821_p2 = (!mul_ln1118_763_fu_44821_p0.read().is_01() || !mul_ln1118_763_fu_44821_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_763_fu_44821_p0.read()) * sc_bigint<5>(mul_ln1118_763_fu_44821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_764_fu_44853_p0() {
    mul_ln1118_764_fu_44853_p0 =  (sc_lv<3>) (sext_ln1116_164_fu_27607_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_764_fu_44853_p1() {
    mul_ln1118_764_fu_44853_p1 = tmp_764_fu_44839_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_764_fu_44853_p2() {
    mul_ln1118_764_fu_44853_p2 = (!mul_ln1118_764_fu_44853_p0.read().is_01() || !mul_ln1118_764_fu_44853_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_764_fu_44853_p0.read()) * sc_bigint<5>(mul_ln1118_764_fu_44853_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_765_fu_88042_p0() {
    mul_ln1118_765_fu_88042_p0 =  (sc_lv<3>) (sext_ln1116_165_reg_106581.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_765_fu_88042_p1() {
    mul_ln1118_765_fu_88042_p1 = tmp_765_reg_108671.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_765_fu_88042_p2() {
    mul_ln1118_765_fu_88042_p2 = (!mul_ln1118_765_fu_88042_p0.read().is_01() || !mul_ln1118_765_fu_88042_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_765_fu_88042_p0.read()) * sc_bigint<5>(mul_ln1118_765_fu_88042_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_766_fu_44895_p0() {
    mul_ln1118_766_fu_44895_p0 =  (sc_lv<3>) (sext_ln1116_166_fu_27673_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_766_fu_44895_p1() {
    mul_ln1118_766_fu_44895_p1 = tmp_766_fu_44881_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_766_fu_44895_p2() {
    mul_ln1118_766_fu_44895_p2 = (!mul_ln1118_766_fu_44895_p0.read().is_01() || !mul_ln1118_766_fu_44895_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_766_fu_44895_p0.read()) * sc_bigint<5>(mul_ln1118_766_fu_44895_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_767_fu_44927_p0() {
    mul_ln1118_767_fu_44927_p0 =  (sc_lv<3>) (sext_ln1116_167_fu_27717_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_767_fu_44927_p1() {
    mul_ln1118_767_fu_44927_p1 = tmp_767_fu_44913_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_767_fu_44927_p2() {
    mul_ln1118_767_fu_44927_p2 = (!mul_ln1118_767_fu_44927_p0.read().is_01() || !mul_ln1118_767_fu_44927_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_767_fu_44927_p0.read()) * sc_bigint<5>(mul_ln1118_767_fu_44927_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_768_fu_88062_p0() {
    mul_ln1118_768_fu_88062_p0 =  (sc_lv<3>) (sext_ln1116_168_reg_106599.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_768_fu_88062_p1() {
    mul_ln1118_768_fu_88062_p1 = tmp_768_reg_108676.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_768_fu_88062_p2() {
    mul_ln1118_768_fu_88062_p2 = (!mul_ln1118_768_fu_88062_p0.read().is_01() || !mul_ln1118_768_fu_88062_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_768_fu_88062_p0.read()) * sc_bigint<5>(mul_ln1118_768_fu_88062_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_769_fu_44969_p0() {
    mul_ln1118_769_fu_44969_p0 =  (sc_lv<3>) (sext_ln1116_169_fu_27783_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_769_fu_44969_p1() {
    mul_ln1118_769_fu_44969_p1 = tmp_769_fu_44955_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_769_fu_44969_p2() {
    mul_ln1118_769_fu_44969_p2 = (!mul_ln1118_769_fu_44969_p0.read().is_01() || !mul_ln1118_769_fu_44969_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_769_fu_44969_p0.read()) * sc_bigint<5>(mul_ln1118_769_fu_44969_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_76_fu_24275_p0() {
    mul_ln1118_76_fu_24275_p0 =  (sc_lv<3>) (sext_ln1116_76_fu_24267_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_76_fu_24275_p1() {
    mul_ln1118_76_fu_24275_p1 = tmp_76_fu_24257_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_76_fu_24275_p2() {
    mul_ln1118_76_fu_24275_p2 = (!mul_ln1118_76_fu_24275_p0.read().is_01() || !mul_ln1118_76_fu_24275_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_76_fu_24275_p0.read()) * sc_bigint<5>(mul_ln1118_76_fu_24275_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_770_fu_45001_p0() {
    mul_ln1118_770_fu_45001_p0 =  (sc_lv<3>) (sext_ln1116_170_fu_27827_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_770_fu_45001_p1() {
    mul_ln1118_770_fu_45001_p1 = tmp_770_fu_44987_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_770_fu_45001_p2() {
    mul_ln1118_770_fu_45001_p2 = (!mul_ln1118_770_fu_45001_p0.read().is_01() || !mul_ln1118_770_fu_45001_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_770_fu_45001_p0.read()) * sc_bigint<5>(mul_ln1118_770_fu_45001_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_771_fu_88082_p0() {
    mul_ln1118_771_fu_88082_p0 =  (sc_lv<3>) (sext_ln1116_171_reg_106617.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_771_fu_88082_p1() {
    mul_ln1118_771_fu_88082_p1 = tmp_771_reg_108681.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_771_fu_88082_p2() {
    mul_ln1118_771_fu_88082_p2 = (!mul_ln1118_771_fu_88082_p0.read().is_01() || !mul_ln1118_771_fu_88082_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_771_fu_88082_p0.read()) * sc_bigint<5>(mul_ln1118_771_fu_88082_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_772_fu_45043_p0() {
    mul_ln1118_772_fu_45043_p0 =  (sc_lv<3>) (sext_ln1116_172_fu_27893_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_772_fu_45043_p1() {
    mul_ln1118_772_fu_45043_p1 = tmp_772_fu_45029_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_772_fu_45043_p2() {
    mul_ln1118_772_fu_45043_p2 = (!mul_ln1118_772_fu_45043_p0.read().is_01() || !mul_ln1118_772_fu_45043_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_772_fu_45043_p0.read()) * sc_bigint<5>(mul_ln1118_772_fu_45043_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_773_fu_45075_p0() {
    mul_ln1118_773_fu_45075_p0 =  (sc_lv<3>) (sext_ln1116_173_fu_27937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_773_fu_45075_p1() {
    mul_ln1118_773_fu_45075_p1 = tmp_773_fu_45061_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_773_fu_45075_p2() {
    mul_ln1118_773_fu_45075_p2 = (!mul_ln1118_773_fu_45075_p0.read().is_01() || !mul_ln1118_773_fu_45075_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_773_fu_45075_p0.read()) * sc_bigint<5>(mul_ln1118_773_fu_45075_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_774_fu_88102_p0() {
    mul_ln1118_774_fu_88102_p0 =  (sc_lv<3>) (sext_ln1116_174_reg_106635.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_774_fu_88102_p1() {
    mul_ln1118_774_fu_88102_p1 = tmp_774_reg_108686.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_774_fu_88102_p2() {
    mul_ln1118_774_fu_88102_p2 = (!mul_ln1118_774_fu_88102_p0.read().is_01() || !mul_ln1118_774_fu_88102_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_774_fu_88102_p0.read()) * sc_bigint<5>(mul_ln1118_774_fu_88102_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_775_fu_45117_p0() {
    mul_ln1118_775_fu_45117_p0 =  (sc_lv<3>) (sext_ln1116_175_fu_28003_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_775_fu_45117_p1() {
    mul_ln1118_775_fu_45117_p1 = tmp_775_fu_45103_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_775_fu_45117_p2() {
    mul_ln1118_775_fu_45117_p2 = (!mul_ln1118_775_fu_45117_p0.read().is_01() || !mul_ln1118_775_fu_45117_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_775_fu_45117_p0.read()) * sc_bigint<5>(mul_ln1118_775_fu_45117_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_776_fu_45149_p0() {
    mul_ln1118_776_fu_45149_p0 =  (sc_lv<3>) (sext_ln1116_176_fu_28047_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_776_fu_45149_p1() {
    mul_ln1118_776_fu_45149_p1 = tmp_776_fu_45135_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_776_fu_45149_p2() {
    mul_ln1118_776_fu_45149_p2 = (!mul_ln1118_776_fu_45149_p0.read().is_01() || !mul_ln1118_776_fu_45149_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_776_fu_45149_p0.read()) * sc_bigint<5>(mul_ln1118_776_fu_45149_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_777_fu_88122_p0() {
    mul_ln1118_777_fu_88122_p0 =  (sc_lv<3>) (sext_ln1116_177_reg_106653.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_777_fu_88122_p1() {
    mul_ln1118_777_fu_88122_p1 = tmp_777_reg_108691.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_777_fu_88122_p2() {
    mul_ln1118_777_fu_88122_p2 = (!mul_ln1118_777_fu_88122_p0.read().is_01() || !mul_ln1118_777_fu_88122_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_777_fu_88122_p0.read()) * sc_bigint<5>(mul_ln1118_777_fu_88122_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_778_fu_45191_p0() {
    mul_ln1118_778_fu_45191_p0 =  (sc_lv<3>) (sext_ln1116_178_fu_28113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_778_fu_45191_p1() {
    mul_ln1118_778_fu_45191_p1 = tmp_778_fu_45177_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_778_fu_45191_p2() {
    mul_ln1118_778_fu_45191_p2 = (!mul_ln1118_778_fu_45191_p0.read().is_01() || !mul_ln1118_778_fu_45191_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_778_fu_45191_p0.read()) * sc_bigint<5>(mul_ln1118_778_fu_45191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_779_fu_45223_p0() {
    mul_ln1118_779_fu_45223_p0 =  (sc_lv<3>) (sext_ln1116_179_fu_28157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_779_fu_45223_p1() {
    mul_ln1118_779_fu_45223_p1 = tmp_779_fu_45209_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_779_fu_45223_p2() {
    mul_ln1118_779_fu_45223_p2 = (!mul_ln1118_779_fu_45223_p0.read().is_01() || !mul_ln1118_779_fu_45223_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_779_fu_45223_p0.read()) * sc_bigint<5>(mul_ln1118_779_fu_45223_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_77_fu_80506_p0() {
    mul_ln1118_77_fu_80506_p0 =  (sc_lv<3>) (sext_ln1116_77_reg_106231.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_77_fu_80506_p1() {
    mul_ln1118_77_fu_80506_p1 = tmp_77_reg_106226.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_77_fu_80506_p2() {
    mul_ln1118_77_fu_80506_p2 = (!mul_ln1118_77_fu_80506_p0.read().is_01() || !mul_ln1118_77_fu_80506_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_77_fu_80506_p0.read()) * sc_bigint<5>(mul_ln1118_77_fu_80506_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_780_fu_45255_p0() {
    mul_ln1118_780_fu_45255_p0 =  (sc_lv<3>) (sext_ln1116_180_fu_28201_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_780_fu_45255_p1() {
    mul_ln1118_780_fu_45255_p1 = tmp_780_fu_45241_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_780_fu_45255_p2() {
    mul_ln1118_780_fu_45255_p2 = (!mul_ln1118_780_fu_45255_p0.read().is_01() || !mul_ln1118_780_fu_45255_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_780_fu_45255_p0.read()) * sc_bigint<5>(mul_ln1118_780_fu_45255_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_781_fu_45287_p0() {
    mul_ln1118_781_fu_45287_p0 =  (sc_lv<3>) (sext_ln1116_181_fu_28245_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_781_fu_45287_p1() {
    mul_ln1118_781_fu_45287_p1 = tmp_781_fu_45273_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_781_fu_45287_p2() {
    mul_ln1118_781_fu_45287_p2 = (!mul_ln1118_781_fu_45287_p0.read().is_01() || !mul_ln1118_781_fu_45287_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_781_fu_45287_p0.read()) * sc_bigint<5>(mul_ln1118_781_fu_45287_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_782_fu_45319_p0() {
    mul_ln1118_782_fu_45319_p0 =  (sc_lv<3>) (sext_ln1116_182_fu_28289_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_782_fu_45319_p1() {
    mul_ln1118_782_fu_45319_p1 = tmp_782_fu_45305_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_782_fu_45319_p2() {
    mul_ln1118_782_fu_45319_p2 = (!mul_ln1118_782_fu_45319_p0.read().is_01() || !mul_ln1118_782_fu_45319_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_782_fu_45319_p0.read()) * sc_bigint<5>(mul_ln1118_782_fu_45319_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_783_fu_45351_p0() {
    mul_ln1118_783_fu_45351_p0 =  (sc_lv<3>) (sext_ln1116_183_fu_28333_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_783_fu_45351_p1() {
    mul_ln1118_783_fu_45351_p1 = tmp_783_fu_45337_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_783_fu_45351_p2() {
    mul_ln1118_783_fu_45351_p2 = (!mul_ln1118_783_fu_45351_p0.read().is_01() || !mul_ln1118_783_fu_45351_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_783_fu_45351_p0.read()) * sc_bigint<5>(mul_ln1118_783_fu_45351_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_784_fu_45383_p0() {
    mul_ln1118_784_fu_45383_p0 =  (sc_lv<3>) (sext_ln1116_184_fu_28377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_784_fu_45383_p1() {
    mul_ln1118_784_fu_45383_p1 = tmp_784_fu_45369_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_784_fu_45383_p2() {
    mul_ln1118_784_fu_45383_p2 = (!mul_ln1118_784_fu_45383_p0.read().is_01() || !mul_ln1118_784_fu_45383_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_784_fu_45383_p0.read()) * sc_bigint<5>(mul_ln1118_784_fu_45383_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_785_fu_45403_p0() {
    mul_ln1118_785_fu_45403_p0 =  (sc_lv<3>) (sext_ln1116_185_fu_28409_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_785_fu_45403_p1() {
    mul_ln1118_785_fu_45403_p1 = tmp_785_fu_45389_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_785_fu_45403_p2() {
    mul_ln1118_785_fu_45403_p2 = (!mul_ln1118_785_fu_45403_p0.read().is_01() || !mul_ln1118_785_fu_45403_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_785_fu_45403_p0.read()) * sc_bigint<5>(mul_ln1118_785_fu_45403_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_786_fu_45435_p0() {
    mul_ln1118_786_fu_45435_p0 =  (sc_lv<3>) (sext_ln1116_186_fu_28453_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_786_fu_45435_p1() {
    mul_ln1118_786_fu_45435_p1 = tmp_786_fu_45421_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_786_fu_45435_p2() {
    mul_ln1118_786_fu_45435_p2 = (!mul_ln1118_786_fu_45435_p0.read().is_01() || !mul_ln1118_786_fu_45435_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_786_fu_45435_p0.read()) * sc_bigint<5>(mul_ln1118_786_fu_45435_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_787_fu_45467_p0() {
    mul_ln1118_787_fu_45467_p0 =  (sc_lv<3>) (sext_ln1116_187_fu_28497_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_787_fu_45467_p1() {
    mul_ln1118_787_fu_45467_p1 = tmp_787_fu_45453_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_787_fu_45467_p2() {
    mul_ln1118_787_fu_45467_p2 = (!mul_ln1118_787_fu_45467_p0.read().is_01() || !mul_ln1118_787_fu_45467_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_787_fu_45467_p0.read()) * sc_bigint<5>(mul_ln1118_787_fu_45467_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_788_fu_45487_p0() {
    mul_ln1118_788_fu_45487_p0 =  (sc_lv<3>) (sext_ln1116_188_fu_28529_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_788_fu_45487_p1() {
    mul_ln1118_788_fu_45487_p1 = tmp_788_fu_45473_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_788_fu_45487_p2() {
    mul_ln1118_788_fu_45487_p2 = (!mul_ln1118_788_fu_45487_p0.read().is_01() || !mul_ln1118_788_fu_45487_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_788_fu_45487_p0.read()) * sc_bigint<5>(mul_ln1118_788_fu_45487_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_789_fu_45519_p0() {
    mul_ln1118_789_fu_45519_p0 =  (sc_lv<3>) (sext_ln1116_189_fu_28573_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_789_fu_45519_p1() {
    mul_ln1118_789_fu_45519_p1 = tmp_789_fu_45505_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_789_fu_45519_p2() {
    mul_ln1118_789_fu_45519_p2 = (!mul_ln1118_789_fu_45519_p0.read().is_01() || !mul_ln1118_789_fu_45519_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_789_fu_45519_p0.read()) * sc_bigint<5>(mul_ln1118_789_fu_45519_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_78_fu_24341_p0() {
    mul_ln1118_78_fu_24341_p0 =  (sc_lv<3>) (sext_ln1116_78_fu_24333_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_78_fu_24341_p1() {
    mul_ln1118_78_fu_24341_p1 = tmp_78_fu_24323_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_78_fu_24341_p2() {
    mul_ln1118_78_fu_24341_p2 = (!mul_ln1118_78_fu_24341_p0.read().is_01() || !mul_ln1118_78_fu_24341_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_78_fu_24341_p0.read()) * sc_bigint<5>(mul_ln1118_78_fu_24341_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_790_fu_88164_p0() {
    mul_ln1118_790_fu_88164_p0 =  (sc_lv<3>) (sext_ln1116_190_reg_106681.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_790_fu_88164_p1() {
    mul_ln1118_790_fu_88164_p1 = tmp_790_reg_108706.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_790_fu_88164_p2() {
    mul_ln1118_790_fu_88164_p2 = (!mul_ln1118_790_fu_88164_p0.read().is_01() || !mul_ln1118_790_fu_88164_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_790_fu_88164_p0.read()) * sc_bigint<5>(mul_ln1118_790_fu_88164_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_791_fu_45561_p0() {
    mul_ln1118_791_fu_45561_p0 =  (sc_lv<3>) (sext_ln1116_191_fu_28639_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_791_fu_45561_p1() {
    mul_ln1118_791_fu_45561_p1 = tmp_791_fu_45547_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_791_fu_45561_p2() {
    mul_ln1118_791_fu_45561_p2 = (!mul_ln1118_791_fu_45561_p0.read().is_01() || !mul_ln1118_791_fu_45561_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_791_fu_45561_p0.read()) * sc_bigint<5>(mul_ln1118_791_fu_45561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_792_fu_45593_p0() {
    mul_ln1118_792_fu_45593_p0 =  (sc_lv<3>) (sext_ln1116_192_fu_28683_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_792_fu_45593_p1() {
    mul_ln1118_792_fu_45593_p1 = tmp_792_fu_45579_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_792_fu_45593_p2() {
    mul_ln1118_792_fu_45593_p2 = (!mul_ln1118_792_fu_45593_p0.read().is_01() || !mul_ln1118_792_fu_45593_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_792_fu_45593_p0.read()) * sc_bigint<5>(mul_ln1118_792_fu_45593_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_793_fu_88184_p0() {
    mul_ln1118_793_fu_88184_p0 =  (sc_lv<3>) (sext_ln1116_193_reg_106699.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_793_fu_88184_p1() {
    mul_ln1118_793_fu_88184_p1 = tmp_793_reg_108711.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_793_fu_88184_p2() {
    mul_ln1118_793_fu_88184_p2 = (!mul_ln1118_793_fu_88184_p0.read().is_01() || !mul_ln1118_793_fu_88184_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_793_fu_88184_p0.read()) * sc_bigint<5>(mul_ln1118_793_fu_88184_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_794_fu_45635_p0() {
    mul_ln1118_794_fu_45635_p0 =  (sc_lv<3>) (sext_ln1116_194_fu_28749_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_794_fu_45635_p1() {
    mul_ln1118_794_fu_45635_p1 = tmp_794_fu_45621_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_794_fu_45635_p2() {
    mul_ln1118_794_fu_45635_p2 = (!mul_ln1118_794_fu_45635_p0.read().is_01() || !mul_ln1118_794_fu_45635_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_794_fu_45635_p0.read()) * sc_bigint<5>(mul_ln1118_794_fu_45635_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_795_fu_45667_p0() {
    mul_ln1118_795_fu_45667_p0 =  (sc_lv<3>) (sext_ln1116_195_fu_28793_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_795_fu_45667_p1() {
    mul_ln1118_795_fu_45667_p1 = tmp_795_fu_45653_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_795_fu_45667_p2() {
    mul_ln1118_795_fu_45667_p2 = (!mul_ln1118_795_fu_45667_p0.read().is_01() || !mul_ln1118_795_fu_45667_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_795_fu_45667_p0.read()) * sc_bigint<5>(mul_ln1118_795_fu_45667_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_796_fu_88204_p0() {
    mul_ln1118_796_fu_88204_p0 =  (sc_lv<3>) (sext_ln1116_196_reg_106717.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_796_fu_88204_p1() {
    mul_ln1118_796_fu_88204_p1 = tmp_796_reg_108716.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_796_fu_88204_p2() {
    mul_ln1118_796_fu_88204_p2 = (!mul_ln1118_796_fu_88204_p0.read().is_01() || !mul_ln1118_796_fu_88204_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_796_fu_88204_p0.read()) * sc_bigint<5>(mul_ln1118_796_fu_88204_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_797_fu_45709_p0() {
    mul_ln1118_797_fu_45709_p0 =  (sc_lv<3>) (sext_ln1116_197_fu_28859_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_797_fu_45709_p1() {
    mul_ln1118_797_fu_45709_p1 = tmp_797_fu_45695_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_797_fu_45709_p2() {
    mul_ln1118_797_fu_45709_p2 = (!mul_ln1118_797_fu_45709_p0.read().is_01() || !mul_ln1118_797_fu_45709_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_797_fu_45709_p0.read()) * sc_bigint<5>(mul_ln1118_797_fu_45709_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_798_fu_45741_p0() {
    mul_ln1118_798_fu_45741_p0 =  (sc_lv<3>) (sext_ln1116_198_fu_28903_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_798_fu_45741_p1() {
    mul_ln1118_798_fu_45741_p1 = tmp_798_fu_45727_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_798_fu_45741_p2() {
    mul_ln1118_798_fu_45741_p2 = (!mul_ln1118_798_fu_45741_p0.read().is_01() || !mul_ln1118_798_fu_45741_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_798_fu_45741_p0.read()) * sc_bigint<5>(mul_ln1118_798_fu_45741_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_799_fu_88224_p0() {
    mul_ln1118_799_fu_88224_p0 =  (sc_lv<3>) (sext_ln1116_199_reg_106735.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_799_fu_88224_p1() {
    mul_ln1118_799_fu_88224_p1 = tmp_799_reg_108721.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_799_fu_88224_p2() {
    mul_ln1118_799_fu_88224_p2 = (!mul_ln1118_799_fu_88224_p0.read().is_01() || !mul_ln1118_799_fu_88224_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_799_fu_88224_p0.read()) * sc_bigint<5>(mul_ln1118_799_fu_88224_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_79_fu_24385_p0() {
    mul_ln1118_79_fu_24385_p0 =  (sc_lv<3>) (sext_ln1116_79_fu_24377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_79_fu_24385_p1() {
    mul_ln1118_79_fu_24385_p1 = tmp_79_fu_24367_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_79_fu_24385_p2() {
    mul_ln1118_79_fu_24385_p2 = (!mul_ln1118_79_fu_24385_p0.read().is_01() || !mul_ln1118_79_fu_24385_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_79_fu_24385_p0.read()) * sc_bigint<5>(mul_ln1118_79_fu_24385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_800_fu_45783_p0() {
    mul_ln1118_800_fu_45783_p0 =  (sc_lv<3>) (sext_ln1116_200_fu_28969_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_800_fu_45783_p1() {
    mul_ln1118_800_fu_45783_p1 = tmp_800_fu_45769_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_800_fu_45783_p2() {
    mul_ln1118_800_fu_45783_p2 = (!mul_ln1118_800_fu_45783_p0.read().is_01() || !mul_ln1118_800_fu_45783_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_800_fu_45783_p0.read()) * sc_bigint<5>(mul_ln1118_800_fu_45783_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_801_fu_45815_p0() {
    mul_ln1118_801_fu_45815_p0 =  (sc_lv<3>) (sext_ln1116_201_fu_29013_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_801_fu_45815_p1() {
    mul_ln1118_801_fu_45815_p1 = tmp_801_fu_45801_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_801_fu_45815_p2() {
    mul_ln1118_801_fu_45815_p2 = (!mul_ln1118_801_fu_45815_p0.read().is_01() || !mul_ln1118_801_fu_45815_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_801_fu_45815_p0.read()) * sc_bigint<5>(mul_ln1118_801_fu_45815_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_802_fu_88244_p0() {
    mul_ln1118_802_fu_88244_p0 =  (sc_lv<3>) (sext_ln1116_202_reg_106753.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_802_fu_88244_p1() {
    mul_ln1118_802_fu_88244_p1 = tmp_802_reg_108726.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_802_fu_88244_p2() {
    mul_ln1118_802_fu_88244_p2 = (!mul_ln1118_802_fu_88244_p0.read().is_01() || !mul_ln1118_802_fu_88244_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_802_fu_88244_p0.read()) * sc_bigint<5>(mul_ln1118_802_fu_88244_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_803_fu_45857_p0() {
    mul_ln1118_803_fu_45857_p0 =  (sc_lv<3>) (sext_ln1116_203_fu_29079_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_803_fu_45857_p1() {
    mul_ln1118_803_fu_45857_p1 = tmp_803_fu_45843_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_803_fu_45857_p2() {
    mul_ln1118_803_fu_45857_p2 = (!mul_ln1118_803_fu_45857_p0.read().is_01() || !mul_ln1118_803_fu_45857_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_803_fu_45857_p0.read()) * sc_bigint<5>(mul_ln1118_803_fu_45857_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_804_fu_45889_p0() {
    mul_ln1118_804_fu_45889_p0 =  (sc_lv<3>) (sext_ln1116_204_fu_29123_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_804_fu_45889_p1() {
    mul_ln1118_804_fu_45889_p1 = tmp_804_fu_45875_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_804_fu_45889_p2() {
    mul_ln1118_804_fu_45889_p2 = (!mul_ln1118_804_fu_45889_p0.read().is_01() || !mul_ln1118_804_fu_45889_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_804_fu_45889_p0.read()) * sc_bigint<5>(mul_ln1118_804_fu_45889_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_805_fu_45921_p0() {
    mul_ln1118_805_fu_45921_p0 =  (sc_lv<3>) (sext_ln1116_205_fu_29167_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_805_fu_45921_p1() {
    mul_ln1118_805_fu_45921_p1 = tmp_805_fu_45907_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_805_fu_45921_p2() {
    mul_ln1118_805_fu_45921_p2 = (!mul_ln1118_805_fu_45921_p0.read().is_01() || !mul_ln1118_805_fu_45921_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_805_fu_45921_p0.read()) * sc_bigint<5>(mul_ln1118_805_fu_45921_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_806_fu_45953_p0() {
    mul_ln1118_806_fu_45953_p0 =  (sc_lv<3>) (sext_ln1116_206_fu_29211_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_806_fu_45953_p1() {
    mul_ln1118_806_fu_45953_p1 = tmp_806_fu_45939_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_806_fu_45953_p2() {
    mul_ln1118_806_fu_45953_p2 = (!mul_ln1118_806_fu_45953_p0.read().is_01() || !mul_ln1118_806_fu_45953_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_806_fu_45953_p0.read()) * sc_bigint<5>(mul_ln1118_806_fu_45953_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_807_fu_45985_p0() {
    mul_ln1118_807_fu_45985_p0 =  (sc_lv<3>) (sext_ln1116_207_fu_29255_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_807_fu_45985_p1() {
    mul_ln1118_807_fu_45985_p1 = tmp_807_fu_45971_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_807_fu_45985_p2() {
    mul_ln1118_807_fu_45985_p2 = (!mul_ln1118_807_fu_45985_p0.read().is_01() || !mul_ln1118_807_fu_45985_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_807_fu_45985_p0.read()) * sc_bigint<5>(mul_ln1118_807_fu_45985_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_808_fu_46017_p0() {
    mul_ln1118_808_fu_46017_p0 =  (sc_lv<3>) (sext_ln1116_208_fu_29299_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_808_fu_46017_p1() {
    mul_ln1118_808_fu_46017_p1 = tmp_808_fu_46003_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_808_fu_46017_p2() {
    mul_ln1118_808_fu_46017_p2 = (!mul_ln1118_808_fu_46017_p0.read().is_01() || !mul_ln1118_808_fu_46017_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_808_fu_46017_p0.read()) * sc_bigint<5>(mul_ln1118_808_fu_46017_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_809_fu_46463_p0() {
    mul_ln1118_809_fu_46463_p0 =  (sc_lv<3>) (sext_ln1116_fu_21855_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_809_fu_46463_p1() {
    mul_ln1118_809_fu_46463_p1 = tmp_809_fu_46449_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_809_fu_46463_p2() {
    mul_ln1118_809_fu_46463_p2 = (!mul_ln1118_809_fu_46463_p0.read().is_01() || !mul_ln1118_809_fu_46463_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_809_fu_46463_p0.read()) * sc_bigint<5>(mul_ln1118_809_fu_46463_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_80_fu_24429_p0() {
    mul_ln1118_80_fu_24429_p0 =  (sc_lv<3>) (sext_ln1116_80_fu_24421_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_80_fu_24429_p1() {
    mul_ln1118_80_fu_24429_p1 = tmp_80_fu_24411_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_80_fu_24429_p2() {
    mul_ln1118_80_fu_24429_p2 = (!mul_ln1118_80_fu_24429_p0.read().is_01() || !mul_ln1118_80_fu_24429_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_80_fu_24429_p0.read()) * sc_bigint<5>(mul_ln1118_80_fu_24429_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_810_fu_46483_p0() {
    mul_ln1118_810_fu_46483_p0 =  (sc_lv<3>) (sext_ln1116_10_fu_21887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_810_fu_46483_p1() {
    mul_ln1118_810_fu_46483_p1 = tmp_810_fu_46469_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_810_fu_46483_p2() {
    mul_ln1118_810_fu_46483_p2 = (!mul_ln1118_810_fu_46483_p0.read().is_01() || !mul_ln1118_810_fu_46483_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_810_fu_46483_p0.read()) * sc_bigint<5>(mul_ln1118_810_fu_46483_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_811_fu_46515_p0() {
    mul_ln1118_811_fu_46515_p0 =  (sc_lv<3>) (sext_ln1116_11_fu_21931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_811_fu_46515_p1() {
    mul_ln1118_811_fu_46515_p1 = tmp_811_fu_46501_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_811_fu_46515_p2() {
    mul_ln1118_811_fu_46515_p2 = (!mul_ln1118_811_fu_46515_p0.read().is_01() || !mul_ln1118_811_fu_46515_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_811_fu_46515_p0.read()) * sc_bigint<5>(mul_ln1118_811_fu_46515_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_812_fu_46547_p0() {
    mul_ln1118_812_fu_46547_p0 =  (sc_lv<3>) (sext_ln1116_12_fu_21975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_812_fu_46547_p1() {
    mul_ln1118_812_fu_46547_p1 = tmp_812_fu_46533_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_812_fu_46547_p2() {
    mul_ln1118_812_fu_46547_p2 = (!mul_ln1118_812_fu_46547_p0.read().is_01() || !mul_ln1118_812_fu_46547_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_812_fu_46547_p0.read()) * sc_bigint<5>(mul_ln1118_812_fu_46547_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_813_fu_46567_p0() {
    mul_ln1118_813_fu_46567_p0 =  (sc_lv<3>) (sext_ln1116_13_fu_22007_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_813_fu_46567_p1() {
    mul_ln1118_813_fu_46567_p1 = tmp_813_fu_46553_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_813_fu_46567_p2() {
    mul_ln1118_813_fu_46567_p2 = (!mul_ln1118_813_fu_46567_p0.read().is_01() || !mul_ln1118_813_fu_46567_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_813_fu_46567_p0.read()) * sc_bigint<5>(mul_ln1118_813_fu_46567_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_814_fu_46599_p0() {
    mul_ln1118_814_fu_46599_p0 =  (sc_lv<3>) (sext_ln1116_14_fu_22051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_814_fu_46599_p1() {
    mul_ln1118_814_fu_46599_p1 = tmp_814_fu_46585_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_814_fu_46599_p2() {
    mul_ln1118_814_fu_46599_p2 = (!mul_ln1118_814_fu_46599_p0.read().is_01() || !mul_ln1118_814_fu_46599_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_814_fu_46599_p0.read()) * sc_bigint<5>(mul_ln1118_814_fu_46599_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_815_fu_89487_p0() {
    mul_ln1118_815_fu_89487_p0 =  (sc_lv<3>) (sext_ln1116_15_fu_80033_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_815_fu_89487_p1() {
    mul_ln1118_815_fu_89487_p1 = tmp_815_reg_109086.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_815_fu_89487_p2() {
    mul_ln1118_815_fu_89487_p2 = (!mul_ln1118_815_fu_89487_p0.read().is_01() || !mul_ln1118_815_fu_89487_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_815_fu_89487_p0.read()) * sc_bigint<5>(mul_ln1118_815_fu_89487_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_816_fu_46641_p0() {
    mul_ln1118_816_fu_46641_p0 =  (sc_lv<3>) (sext_ln1116_16_fu_22113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_816_fu_46641_p1() {
    mul_ln1118_816_fu_46641_p1 = tmp_816_fu_46627_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_816_fu_46641_p2() {
    mul_ln1118_816_fu_46641_p2 = (!mul_ln1118_816_fu_46641_p0.read().is_01() || !mul_ln1118_816_fu_46641_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_816_fu_46641_p0.read()) * sc_bigint<5>(mul_ln1118_816_fu_46641_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_817_fu_46673_p0() {
    mul_ln1118_817_fu_46673_p0 =  (sc_lv<3>) (sext_ln1116_17_fu_22157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_817_fu_46673_p1() {
    mul_ln1118_817_fu_46673_p1 = tmp_817_fu_46659_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_817_fu_46673_p2() {
    mul_ln1118_817_fu_46673_p2 = (!mul_ln1118_817_fu_46673_p0.read().is_01() || !mul_ln1118_817_fu_46673_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_817_fu_46673_p0.read()) * sc_bigint<5>(mul_ln1118_817_fu_46673_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_818_fu_89508_p0() {
    mul_ln1118_818_fu_89508_p0 =  (sc_lv<3>) (sext_ln1116_18_fu_80057_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_818_fu_89508_p1() {
    mul_ln1118_818_fu_89508_p1 = tmp_818_reg_109091.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_818_fu_89508_p2() {
    mul_ln1118_818_fu_89508_p2 = (!mul_ln1118_818_fu_89508_p0.read().is_01() || !mul_ln1118_818_fu_89508_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_818_fu_89508_p0.read()) * sc_bigint<5>(mul_ln1118_818_fu_89508_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_819_fu_46715_p0() {
    mul_ln1118_819_fu_46715_p0 =  (sc_lv<3>) (sext_ln1116_19_fu_22219_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_819_fu_46715_p1() {
    mul_ln1118_819_fu_46715_p1 = tmp_819_fu_46701_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_819_fu_46715_p2() {
    mul_ln1118_819_fu_46715_p2 = (!mul_ln1118_819_fu_46715_p0.read().is_01() || !mul_ln1118_819_fu_46715_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_819_fu_46715_p0.read()) * sc_bigint<5>(mul_ln1118_819_fu_46715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_81_fu_24473_p0() {
    mul_ln1118_81_fu_24473_p0 =  (sc_lv<3>) (sext_ln1116_81_fu_24465_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_81_fu_24473_p1() {
    mul_ln1118_81_fu_24473_p1 = tmp_81_fu_24455_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_81_fu_24473_p2() {
    mul_ln1118_81_fu_24473_p2 = (!mul_ln1118_81_fu_24473_p0.read().is_01() || !mul_ln1118_81_fu_24473_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_81_fu_24473_p0.read()) * sc_bigint<5>(mul_ln1118_81_fu_24473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_820_fu_46747_p0() {
    mul_ln1118_820_fu_46747_p0 =  (sc_lv<3>) (sext_ln1116_20_fu_22263_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_820_fu_46747_p1() {
    mul_ln1118_820_fu_46747_p1 = tmp_820_fu_46733_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_820_fu_46747_p2() {
    mul_ln1118_820_fu_46747_p2 = (!mul_ln1118_820_fu_46747_p0.read().is_01() || !mul_ln1118_820_fu_46747_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_820_fu_46747_p0.read()) * sc_bigint<5>(mul_ln1118_820_fu_46747_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_821_fu_89529_p0() {
    mul_ln1118_821_fu_89529_p0 =  (sc_lv<3>) (sext_ln1116_21_fu_80081_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_821_fu_89529_p1() {
    mul_ln1118_821_fu_89529_p1 = tmp_821_reg_109096.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_821_fu_89529_p2() {
    mul_ln1118_821_fu_89529_p2 = (!mul_ln1118_821_fu_89529_p0.read().is_01() || !mul_ln1118_821_fu_89529_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_821_fu_89529_p0.read()) * sc_bigint<5>(mul_ln1118_821_fu_89529_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_822_fu_46789_p0() {
    mul_ln1118_822_fu_46789_p0 =  (sc_lv<3>) (sext_ln1116_22_fu_22325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_822_fu_46789_p1() {
    mul_ln1118_822_fu_46789_p1 = tmp_822_fu_46775_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_822_fu_46789_p2() {
    mul_ln1118_822_fu_46789_p2 = (!mul_ln1118_822_fu_46789_p0.read().is_01() || !mul_ln1118_822_fu_46789_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_822_fu_46789_p0.read()) * sc_bigint<5>(mul_ln1118_822_fu_46789_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_823_fu_46821_p0() {
    mul_ln1118_823_fu_46821_p0 =  (sc_lv<3>) (sext_ln1116_23_fu_22369_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_823_fu_46821_p1() {
    mul_ln1118_823_fu_46821_p1 = tmp_823_fu_46807_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_823_fu_46821_p2() {
    mul_ln1118_823_fu_46821_p2 = (!mul_ln1118_823_fu_46821_p0.read().is_01() || !mul_ln1118_823_fu_46821_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_823_fu_46821_p0.read()) * sc_bigint<5>(mul_ln1118_823_fu_46821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_824_fu_89550_p0() {
    mul_ln1118_824_fu_89550_p0 =  (sc_lv<3>) (sext_ln1116_24_fu_80105_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_824_fu_89550_p1() {
    mul_ln1118_824_fu_89550_p1 = tmp_824_reg_109101.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_824_fu_89550_p2() {
    mul_ln1118_824_fu_89550_p2 = (!mul_ln1118_824_fu_89550_p0.read().is_01() || !mul_ln1118_824_fu_89550_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_824_fu_89550_p0.read()) * sc_bigint<5>(mul_ln1118_824_fu_89550_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_825_fu_46863_p0() {
    mul_ln1118_825_fu_46863_p0 =  (sc_lv<3>) (sext_ln1116_25_fu_22431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_825_fu_46863_p1() {
    mul_ln1118_825_fu_46863_p1 = tmp_825_fu_46849_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_825_fu_46863_p2() {
    mul_ln1118_825_fu_46863_p2 = (!mul_ln1118_825_fu_46863_p0.read().is_01() || !mul_ln1118_825_fu_46863_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_825_fu_46863_p0.read()) * sc_bigint<5>(mul_ln1118_825_fu_46863_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_826_fu_46895_p0() {
    mul_ln1118_826_fu_46895_p0 =  (sc_lv<3>) (sext_ln1116_26_fu_22475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_826_fu_46895_p1() {
    mul_ln1118_826_fu_46895_p1 = tmp_826_fu_46881_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_826_fu_46895_p2() {
    mul_ln1118_826_fu_46895_p2 = (!mul_ln1118_826_fu_46895_p0.read().is_01() || !mul_ln1118_826_fu_46895_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_826_fu_46895_p0.read()) * sc_bigint<5>(mul_ln1118_826_fu_46895_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_827_fu_89571_p0() {
    mul_ln1118_827_fu_89571_p0 =  (sc_lv<3>) (sext_ln1116_27_fu_80129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_827_fu_89571_p1() {
    mul_ln1118_827_fu_89571_p1 = tmp_827_reg_109106.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_827_fu_89571_p2() {
    mul_ln1118_827_fu_89571_p2 = (!mul_ln1118_827_fu_89571_p0.read().is_01() || !mul_ln1118_827_fu_89571_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_827_fu_89571_p0.read()) * sc_bigint<5>(mul_ln1118_827_fu_89571_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_828_fu_46937_p0() {
    mul_ln1118_828_fu_46937_p0 =  (sc_lv<3>) (sext_ln1116_28_fu_22537_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_828_fu_46937_p1() {
    mul_ln1118_828_fu_46937_p1 = tmp_828_fu_46923_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_828_fu_46937_p2() {
    mul_ln1118_828_fu_46937_p2 = (!mul_ln1118_828_fu_46937_p0.read().is_01() || !mul_ln1118_828_fu_46937_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_828_fu_46937_p0.read()) * sc_bigint<5>(mul_ln1118_828_fu_46937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_829_fu_46969_p0() {
    mul_ln1118_829_fu_46969_p0 =  (sc_lv<3>) (sext_ln1116_29_fu_22581_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_829_fu_46969_p1() {
    mul_ln1118_829_fu_46969_p1 = tmp_829_fu_46955_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_829_fu_46969_p2() {
    mul_ln1118_829_fu_46969_p2 = (!mul_ln1118_829_fu_46969_p0.read().is_01() || !mul_ln1118_829_fu_46969_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_829_fu_46969_p0.read()) * sc_bigint<5>(mul_ln1118_829_fu_46969_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_82_fu_24517_p0() {
    mul_ln1118_82_fu_24517_p0 =  (sc_lv<3>) (sext_ln1116_82_fu_24509_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_82_fu_24517_p1() {
    mul_ln1118_82_fu_24517_p1 = tmp_82_fu_24499_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_82_fu_24517_p2() {
    mul_ln1118_82_fu_24517_p2 = (!mul_ln1118_82_fu_24517_p0.read().is_01() || !mul_ln1118_82_fu_24517_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_82_fu_24517_p0.read()) * sc_bigint<5>(mul_ln1118_82_fu_24517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_830_fu_47001_p0() {
    mul_ln1118_830_fu_47001_p0 =  (sc_lv<3>) (sext_ln1116_30_fu_22625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_830_fu_47001_p1() {
    mul_ln1118_830_fu_47001_p1 = tmp_830_fu_46987_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_830_fu_47001_p2() {
    mul_ln1118_830_fu_47001_p2 = (!mul_ln1118_830_fu_47001_p0.read().is_01() || !mul_ln1118_830_fu_47001_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_830_fu_47001_p0.read()) * sc_bigint<5>(mul_ln1118_830_fu_47001_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_831_fu_47033_p0() {
    mul_ln1118_831_fu_47033_p0 =  (sc_lv<3>) (sext_ln1116_31_fu_22669_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_831_fu_47033_p1() {
    mul_ln1118_831_fu_47033_p1 = tmp_831_fu_47019_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_831_fu_47033_p2() {
    mul_ln1118_831_fu_47033_p2 = (!mul_ln1118_831_fu_47033_p0.read().is_01() || !mul_ln1118_831_fu_47033_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_831_fu_47033_p0.read()) * sc_bigint<5>(mul_ln1118_831_fu_47033_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_832_fu_47065_p0() {
    mul_ln1118_832_fu_47065_p0 =  (sc_lv<3>) (sext_ln1116_32_fu_22713_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_832_fu_47065_p1() {
    mul_ln1118_832_fu_47065_p1 = tmp_832_fu_47051_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_832_fu_47065_p2() {
    mul_ln1118_832_fu_47065_p2 = (!mul_ln1118_832_fu_47065_p0.read().is_01() || !mul_ln1118_832_fu_47065_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_832_fu_47065_p0.read()) * sc_bigint<5>(mul_ln1118_832_fu_47065_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_833_fu_47097_p0() {
    mul_ln1118_833_fu_47097_p0 =  (sc_lv<3>) (sext_ln1116_33_fu_22757_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_833_fu_47097_p1() {
    mul_ln1118_833_fu_47097_p1 = tmp_833_fu_47083_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_833_fu_47097_p2() {
    mul_ln1118_833_fu_47097_p2 = (!mul_ln1118_833_fu_47097_p0.read().is_01() || !mul_ln1118_833_fu_47097_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_833_fu_47097_p0.read()) * sc_bigint<5>(mul_ln1118_833_fu_47097_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_834_fu_89592_p0() {
    mul_ln1118_834_fu_89592_p0 =  (sc_lv<3>) (sext_ln1116_34_reg_106007.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_834_fu_89592_p1() {
    mul_ln1118_834_fu_89592_p1 = tmp_834_reg_109111.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_834_fu_89592_p2() {
    mul_ln1118_834_fu_89592_p2 = (!mul_ln1118_834_fu_89592_p0.read().is_01() || !mul_ln1118_834_fu_89592_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_834_fu_89592_p0.read()) * sc_bigint<5>(mul_ln1118_834_fu_89592_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_835_fu_47139_p0() {
    mul_ln1118_835_fu_47139_p0 =  (sc_lv<3>) (sext_ln1116_35_fu_22823_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_835_fu_47139_p1() {
    mul_ln1118_835_fu_47139_p1 = tmp_835_fu_47125_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_835_fu_47139_p2() {
    mul_ln1118_835_fu_47139_p2 = (!mul_ln1118_835_fu_47139_p0.read().is_01() || !mul_ln1118_835_fu_47139_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_835_fu_47139_p0.read()) * sc_bigint<5>(mul_ln1118_835_fu_47139_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_836_fu_47171_p0() {
    mul_ln1118_836_fu_47171_p0 =  (sc_lv<3>) (sext_ln1116_36_fu_22867_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_836_fu_47171_p1() {
    mul_ln1118_836_fu_47171_p1 = tmp_836_fu_47157_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_836_fu_47171_p2() {
    mul_ln1118_836_fu_47171_p2 = (!mul_ln1118_836_fu_47171_p0.read().is_01() || !mul_ln1118_836_fu_47171_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_836_fu_47171_p0.read()) * sc_bigint<5>(mul_ln1118_836_fu_47171_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_837_fu_89612_p0() {
    mul_ln1118_837_fu_89612_p0 =  (sc_lv<3>) (sext_ln1116_37_reg_106025.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_837_fu_89612_p1() {
    mul_ln1118_837_fu_89612_p1 = tmp_837_reg_109116.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_837_fu_89612_p2() {
    mul_ln1118_837_fu_89612_p2 = (!mul_ln1118_837_fu_89612_p0.read().is_01() || !mul_ln1118_837_fu_89612_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_837_fu_89612_p0.read()) * sc_bigint<5>(mul_ln1118_837_fu_89612_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_838_fu_47213_p0() {
    mul_ln1118_838_fu_47213_p0 =  (sc_lv<3>) (sext_ln1116_38_fu_22933_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_838_fu_47213_p1() {
    mul_ln1118_838_fu_47213_p1 = tmp_838_fu_47199_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_838_fu_47213_p2() {
    mul_ln1118_838_fu_47213_p2 = (!mul_ln1118_838_fu_47213_p0.read().is_01() || !mul_ln1118_838_fu_47213_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_838_fu_47213_p0.read()) * sc_bigint<5>(mul_ln1118_838_fu_47213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_839_fu_47245_p0() {
    mul_ln1118_839_fu_47245_p0 =  (sc_lv<3>) (sext_ln1116_39_fu_22977_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_839_fu_47245_p1() {
    mul_ln1118_839_fu_47245_p1 = tmp_839_fu_47231_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_839_fu_47245_p2() {
    mul_ln1118_839_fu_47245_p2 = (!mul_ln1118_839_fu_47245_p0.read().is_01() || !mul_ln1118_839_fu_47245_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_839_fu_47245_p0.read()) * sc_bigint<5>(mul_ln1118_839_fu_47245_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_83_fu_24561_p0() {
    mul_ln1118_83_fu_24561_p0 =  (sc_lv<3>) (sext_ln1116_83_fu_24553_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_83_fu_24561_p1() {
    mul_ln1118_83_fu_24561_p1 = tmp_83_fu_24543_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_83_fu_24561_p2() {
    mul_ln1118_83_fu_24561_p2 = (!mul_ln1118_83_fu_24561_p0.read().is_01() || !mul_ln1118_83_fu_24561_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_83_fu_24561_p0.read()) * sc_bigint<5>(mul_ln1118_83_fu_24561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_840_fu_89632_p0() {
    mul_ln1118_840_fu_89632_p0 =  (sc_lv<3>) (sext_ln1116_40_fu_80193_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_840_fu_89632_p1() {
    mul_ln1118_840_fu_89632_p1 = tmp_840_reg_109121.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_840_fu_89632_p2() {
    mul_ln1118_840_fu_89632_p2 = (!mul_ln1118_840_fu_89632_p0.read().is_01() || !mul_ln1118_840_fu_89632_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_840_fu_89632_p0.read()) * sc_bigint<5>(mul_ln1118_840_fu_89632_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_841_fu_89653_p0() {
    mul_ln1118_841_fu_89653_p0 =  (sc_lv<3>) (sext_ln1116_41_fu_80217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_841_fu_89653_p1() {
    mul_ln1118_841_fu_89653_p1 = tmp_841_reg_109126.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_841_fu_89653_p2() {
    mul_ln1118_841_fu_89653_p2 = (!mul_ln1118_841_fu_89653_p0.read().is_01() || !mul_ln1118_841_fu_89653_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_841_fu_89653_p0.read()) * sc_bigint<5>(mul_ln1118_841_fu_89653_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_842_fu_89674_p0() {
    mul_ln1118_842_fu_89674_p0 =  (sc_lv<3>) (sext_ln1116_42_fu_80241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_842_fu_89674_p1() {
    mul_ln1118_842_fu_89674_p1 = tmp_842_reg_109131.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_842_fu_89674_p2() {
    mul_ln1118_842_fu_89674_p2 = (!mul_ln1118_842_fu_89674_p0.read().is_01() || !mul_ln1118_842_fu_89674_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_842_fu_89674_p0.read()) * sc_bigint<5>(mul_ln1118_842_fu_89674_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_843_fu_89695_p0() {
    mul_ln1118_843_fu_89695_p0 =  (sc_lv<3>) (sext_ln1116_43_fu_80265_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_843_fu_89695_p1() {
    mul_ln1118_843_fu_89695_p1 = tmp_843_reg_109136.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_843_fu_89695_p2() {
    mul_ln1118_843_fu_89695_p2 = (!mul_ln1118_843_fu_89695_p0.read().is_01() || !mul_ln1118_843_fu_89695_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_843_fu_89695_p0.read()) * sc_bigint<5>(mul_ln1118_843_fu_89695_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_844_fu_89716_p0() {
    mul_ln1118_844_fu_89716_p0 =  (sc_lv<3>) (sext_ln1116_44_fu_80289_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_844_fu_89716_p1() {
    mul_ln1118_844_fu_89716_p1 = tmp_844_reg_109141.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_844_fu_89716_p2() {
    mul_ln1118_844_fu_89716_p2 = (!mul_ln1118_844_fu_89716_p0.read().is_01() || !mul_ln1118_844_fu_89716_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_844_fu_89716_p0.read()) * sc_bigint<5>(mul_ln1118_844_fu_89716_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_845_fu_89737_p0() {
    mul_ln1118_845_fu_89737_p0 =  (sc_lv<3>) (sext_ln1116_45_fu_80313_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_845_fu_89737_p1() {
    mul_ln1118_845_fu_89737_p1 = tmp_845_reg_109146.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_845_fu_89737_p2() {
    mul_ln1118_845_fu_89737_p2 = (!mul_ln1118_845_fu_89737_p0.read().is_01() || !mul_ln1118_845_fu_89737_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_845_fu_89737_p0.read()) * sc_bigint<5>(mul_ln1118_845_fu_89737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_846_fu_89758_p0() {
    mul_ln1118_846_fu_89758_p0 =  (sc_lv<3>) (sext_ln1116_46_reg_106103.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_846_fu_89758_p1() {
    mul_ln1118_846_fu_89758_p1 = tmp_846_reg_109151.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_846_fu_89758_p2() {
    mul_ln1118_846_fu_89758_p2 = (!mul_ln1118_846_fu_89758_p0.read().is_01() || !mul_ln1118_846_fu_89758_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_846_fu_89758_p0.read()) * sc_bigint<5>(mul_ln1118_846_fu_89758_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_847_fu_47347_p0() {
    mul_ln1118_847_fu_47347_p0 =  (sc_lv<3>) (sext_ln1116_47_fu_23151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_847_fu_47347_p1() {
    mul_ln1118_847_fu_47347_p1 = tmp_847_fu_47333_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_847_fu_47347_p2() {
    mul_ln1118_847_fu_47347_p2 = (!mul_ln1118_847_fu_47347_p0.read().is_01() || !mul_ln1118_847_fu_47347_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_847_fu_47347_p0.read()) * sc_bigint<5>(mul_ln1118_847_fu_47347_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_848_fu_47379_p0() {
    mul_ln1118_848_fu_47379_p0 =  (sc_lv<3>) (sext_ln1116_48_fu_23195_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_848_fu_47379_p1() {
    mul_ln1118_848_fu_47379_p1 = tmp_848_fu_47365_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_848_fu_47379_p2() {
    mul_ln1118_848_fu_47379_p2 = (!mul_ln1118_848_fu_47379_p0.read().is_01() || !mul_ln1118_848_fu_47379_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_848_fu_47379_p0.read()) * sc_bigint<5>(mul_ln1118_848_fu_47379_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_849_fu_89778_p0() {
    mul_ln1118_849_fu_89778_p0 =  (sc_lv<3>) (sext_ln1116_49_reg_106121.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_849_fu_89778_p1() {
    mul_ln1118_849_fu_89778_p1 = tmp_849_reg_109156.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_849_fu_89778_p2() {
    mul_ln1118_849_fu_89778_p2 = (!mul_ln1118_849_fu_89778_p0.read().is_01() || !mul_ln1118_849_fu_89778_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_849_fu_89778_p0.read()) * sc_bigint<5>(mul_ln1118_849_fu_89778_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_84_fu_24605_p0() {
    mul_ln1118_84_fu_24605_p0 =  (sc_lv<3>) (sext_ln1116_84_fu_24597_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_84_fu_24605_p1() {
    mul_ln1118_84_fu_24605_p1 = tmp_84_fu_24587_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_84_fu_24605_p2() {
    mul_ln1118_84_fu_24605_p2 = (!mul_ln1118_84_fu_24605_p0.read().is_01() || !mul_ln1118_84_fu_24605_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_84_fu_24605_p0.read()) * sc_bigint<5>(mul_ln1118_84_fu_24605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_850_fu_47421_p0() {
    mul_ln1118_850_fu_47421_p0 =  (sc_lv<3>) (sext_ln1116_50_fu_23261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_850_fu_47421_p1() {
    mul_ln1118_850_fu_47421_p1 = tmp_850_fu_47407_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_850_fu_47421_p2() {
    mul_ln1118_850_fu_47421_p2 = (!mul_ln1118_850_fu_47421_p0.read().is_01() || !mul_ln1118_850_fu_47421_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_850_fu_47421_p0.read()) * sc_bigint<5>(mul_ln1118_850_fu_47421_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_851_fu_47453_p0() {
    mul_ln1118_851_fu_47453_p0 =  (sc_lv<3>) (sext_ln1116_51_fu_23305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_851_fu_47453_p1() {
    mul_ln1118_851_fu_47453_p1 = tmp_851_fu_47439_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_851_fu_47453_p2() {
    mul_ln1118_851_fu_47453_p2 = (!mul_ln1118_851_fu_47453_p0.read().is_01() || !mul_ln1118_851_fu_47453_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_851_fu_47453_p0.read()) * sc_bigint<5>(mul_ln1118_851_fu_47453_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_852_fu_89798_p0() {
    mul_ln1118_852_fu_89798_p0 =  (sc_lv<3>) (sext_ln1116_52_fu_80377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_852_fu_89798_p1() {
    mul_ln1118_852_fu_89798_p1 = tmp_852_reg_109161.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_852_fu_89798_p2() {
    mul_ln1118_852_fu_89798_p2 = (!mul_ln1118_852_fu_89798_p0.read().is_01() || !mul_ln1118_852_fu_89798_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_852_fu_89798_p0.read()) * sc_bigint<5>(mul_ln1118_852_fu_89798_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_853_fu_47495_p0() {
    mul_ln1118_853_fu_47495_p0 =  (sc_lv<3>) (sext_ln1116_53_fu_23367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_853_fu_47495_p1() {
    mul_ln1118_853_fu_47495_p1 = tmp_853_fu_47481_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_853_fu_47495_p2() {
    mul_ln1118_853_fu_47495_p2 = (!mul_ln1118_853_fu_47495_p0.read().is_01() || !mul_ln1118_853_fu_47495_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_853_fu_47495_p0.read()) * sc_bigint<5>(mul_ln1118_853_fu_47495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_854_fu_47527_p0() {
    mul_ln1118_854_fu_47527_p0 =  (sc_lv<3>) (sext_ln1116_54_fu_23411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_854_fu_47527_p1() {
    mul_ln1118_854_fu_47527_p1 = tmp_854_fu_47513_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_854_fu_47527_p2() {
    mul_ln1118_854_fu_47527_p2 = (!mul_ln1118_854_fu_47527_p0.read().is_01() || !mul_ln1118_854_fu_47527_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_854_fu_47527_p0.read()) * sc_bigint<5>(mul_ln1118_854_fu_47527_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_855_fu_47559_p0() {
    mul_ln1118_855_fu_47559_p0 =  (sc_lv<3>) (sext_ln1116_55_fu_23455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_855_fu_47559_p1() {
    mul_ln1118_855_fu_47559_p1 = tmp_855_fu_47545_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_855_fu_47559_p2() {
    mul_ln1118_855_fu_47559_p2 = (!mul_ln1118_855_fu_47559_p0.read().is_01() || !mul_ln1118_855_fu_47559_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_855_fu_47559_p0.read()) * sc_bigint<5>(mul_ln1118_855_fu_47559_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_856_fu_47591_p0() {
    mul_ln1118_856_fu_47591_p0 =  (sc_lv<3>) (sext_ln1116_56_fu_23499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_856_fu_47591_p1() {
    mul_ln1118_856_fu_47591_p1 = tmp_856_fu_47577_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_856_fu_47591_p2() {
    mul_ln1118_856_fu_47591_p2 = (!mul_ln1118_856_fu_47591_p0.read().is_01() || !mul_ln1118_856_fu_47591_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_856_fu_47591_p0.read()) * sc_bigint<5>(mul_ln1118_856_fu_47591_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_857_fu_47623_p0() {
    mul_ln1118_857_fu_47623_p0 =  (sc_lv<3>) (sext_ln1116_57_fu_23543_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_857_fu_47623_p1() {
    mul_ln1118_857_fu_47623_p1 = tmp_857_fu_47609_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_857_fu_47623_p2() {
    mul_ln1118_857_fu_47623_p2 = (!mul_ln1118_857_fu_47623_p0.read().is_01() || !mul_ln1118_857_fu_47623_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_857_fu_47623_p0.read()) * sc_bigint<5>(mul_ln1118_857_fu_47623_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_858_fu_47655_p0() {
    mul_ln1118_858_fu_47655_p0 =  (sc_lv<3>) (sext_ln1116_58_fu_23587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_858_fu_47655_p1() {
    mul_ln1118_858_fu_47655_p1 = tmp_858_fu_47641_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_858_fu_47655_p2() {
    mul_ln1118_858_fu_47655_p2 = (!mul_ln1118_858_fu_47655_p0.read().is_01() || !mul_ln1118_858_fu_47655_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_858_fu_47655_p0.read()) * sc_bigint<5>(mul_ln1118_858_fu_47655_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_859_fu_47687_p0() {
    mul_ln1118_859_fu_47687_p0 =  (sc_lv<3>) (sext_ln1116_59_fu_23631_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_859_fu_47687_p1() {
    mul_ln1118_859_fu_47687_p1 = tmp_859_fu_47673_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_859_fu_47687_p2() {
    mul_ln1118_859_fu_47687_p2 = (!mul_ln1118_859_fu_47687_p0.read().is_01() || !mul_ln1118_859_fu_47687_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_859_fu_47687_p0.read()) * sc_bigint<5>(mul_ln1118_859_fu_47687_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_85_fu_24637_p0() {
    mul_ln1118_85_fu_24637_p0 =  (sc_lv<3>) (sext_ln1116_85_fu_24629_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_85_fu_24637_p1() {
    mul_ln1118_85_fu_24637_p1 = tmp_85_fu_24619_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_85_fu_24637_p2() {
    mul_ln1118_85_fu_24637_p2 = (!mul_ln1118_85_fu_24637_p0.read().is_01() || !mul_ln1118_85_fu_24637_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_85_fu_24637_p0.read()) * sc_bigint<5>(mul_ln1118_85_fu_24637_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_860_fu_47707_p0() {
    mul_ln1118_860_fu_47707_p0 =  (sc_lv<3>) (sext_ln1116_60_fu_23663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_860_fu_47707_p1() {
    mul_ln1118_860_fu_47707_p1 = tmp_860_fu_47693_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_860_fu_47707_p2() {
    mul_ln1118_860_fu_47707_p2 = (!mul_ln1118_860_fu_47707_p0.read().is_01() || !mul_ln1118_860_fu_47707_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_860_fu_47707_p0.read()) * sc_bigint<5>(mul_ln1118_860_fu_47707_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_861_fu_47739_p0() {
    mul_ln1118_861_fu_47739_p0 =  (sc_lv<3>) (sext_ln1116_61_fu_23707_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_861_fu_47739_p1() {
    mul_ln1118_861_fu_47739_p1 = tmp_861_fu_47725_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_861_fu_47739_p2() {
    mul_ln1118_861_fu_47739_p2 = (!mul_ln1118_861_fu_47739_p0.read().is_01() || !mul_ln1118_861_fu_47739_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_861_fu_47739_p0.read()) * sc_bigint<5>(mul_ln1118_861_fu_47739_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_862_fu_47771_p0() {
    mul_ln1118_862_fu_47771_p0 =  (sc_lv<3>) (sext_ln1116_62_fu_23751_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_862_fu_47771_p1() {
    mul_ln1118_862_fu_47771_p1 = tmp_862_fu_47757_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_862_fu_47771_p2() {
    mul_ln1118_862_fu_47771_p2 = (!mul_ln1118_862_fu_47771_p0.read().is_01() || !mul_ln1118_862_fu_47771_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_862_fu_47771_p0.read()) * sc_bigint<5>(mul_ln1118_862_fu_47771_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_863_fu_47791_p0() {
    mul_ln1118_863_fu_47791_p0 =  (sc_lv<3>) (sext_ln1116_63_fu_23783_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_863_fu_47791_p1() {
    mul_ln1118_863_fu_47791_p1 = tmp_863_fu_47777_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_863_fu_47791_p2() {
    mul_ln1118_863_fu_47791_p2 = (!mul_ln1118_863_fu_47791_p0.read().is_01() || !mul_ln1118_863_fu_47791_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_863_fu_47791_p0.read()) * sc_bigint<5>(mul_ln1118_863_fu_47791_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_864_fu_47823_p0() {
    mul_ln1118_864_fu_47823_p0 =  (sc_lv<3>) (sext_ln1116_64_fu_23827_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_864_fu_47823_p1() {
    mul_ln1118_864_fu_47823_p1 = tmp_864_fu_47809_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_864_fu_47823_p2() {
    mul_ln1118_864_fu_47823_p2 = (!mul_ln1118_864_fu_47823_p0.read().is_01() || !mul_ln1118_864_fu_47823_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_864_fu_47823_p0.read()) * sc_bigint<5>(mul_ln1118_864_fu_47823_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_865_fu_89841_p0() {
    mul_ln1118_865_fu_89841_p0 =  (sc_lv<3>) (sext_ln1116_65_reg_106159.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_865_fu_89841_p1() {
    mul_ln1118_865_fu_89841_p1 = tmp_865_reg_109176.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_865_fu_89841_p2() {
    mul_ln1118_865_fu_89841_p2 = (!mul_ln1118_865_fu_89841_p0.read().is_01() || !mul_ln1118_865_fu_89841_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_865_fu_89841_p0.read()) * sc_bigint<5>(mul_ln1118_865_fu_89841_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_866_fu_47865_p0() {
    mul_ln1118_866_fu_47865_p0 =  (sc_lv<3>) (sext_ln1116_66_fu_23893_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_866_fu_47865_p1() {
    mul_ln1118_866_fu_47865_p1 = tmp_866_fu_47851_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_866_fu_47865_p2() {
    mul_ln1118_866_fu_47865_p2 = (!mul_ln1118_866_fu_47865_p0.read().is_01() || !mul_ln1118_866_fu_47865_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_866_fu_47865_p0.read()) * sc_bigint<5>(mul_ln1118_866_fu_47865_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_867_fu_47897_p0() {
    mul_ln1118_867_fu_47897_p0 =  (sc_lv<3>) (sext_ln1116_67_fu_23937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_867_fu_47897_p1() {
    mul_ln1118_867_fu_47897_p1 = tmp_867_fu_47883_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_867_fu_47897_p2() {
    mul_ln1118_867_fu_47897_p2 = (!mul_ln1118_867_fu_47897_p0.read().is_01() || !mul_ln1118_867_fu_47897_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_867_fu_47897_p0.read()) * sc_bigint<5>(mul_ln1118_867_fu_47897_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_868_fu_89861_p0() {
    mul_ln1118_868_fu_89861_p0 =  (sc_lv<3>) (sext_ln1116_68_reg_106177.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_868_fu_89861_p1() {
    mul_ln1118_868_fu_89861_p1 = tmp_868_reg_109181.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_868_fu_89861_p2() {
    mul_ln1118_868_fu_89861_p2 = (!mul_ln1118_868_fu_89861_p0.read().is_01() || !mul_ln1118_868_fu_89861_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_868_fu_89861_p0.read()) * sc_bigint<5>(mul_ln1118_868_fu_89861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_869_fu_47939_p0() {
    mul_ln1118_869_fu_47939_p0 =  (sc_lv<3>) (sext_ln1116_69_fu_24003_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_869_fu_47939_p1() {
    mul_ln1118_869_fu_47939_p1 = tmp_869_fu_47925_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_869_fu_47939_p2() {
    mul_ln1118_869_fu_47939_p2 = (!mul_ln1118_869_fu_47939_p0.read().is_01() || !mul_ln1118_869_fu_47939_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_869_fu_47939_p0.read()) * sc_bigint<5>(mul_ln1118_869_fu_47939_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_86_fu_24681_p0() {
    mul_ln1118_86_fu_24681_p0 =  (sc_lv<3>) (sext_ln1116_86_fu_24673_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_86_fu_24681_p1() {
    mul_ln1118_86_fu_24681_p1 = tmp_86_fu_24663_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_86_fu_24681_p2() {
    mul_ln1118_86_fu_24681_p2 = (!mul_ln1118_86_fu_24681_p0.read().is_01() || !mul_ln1118_86_fu_24681_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_86_fu_24681_p0.read()) * sc_bigint<5>(mul_ln1118_86_fu_24681_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_870_fu_47971_p0() {
    mul_ln1118_870_fu_47971_p0 =  (sc_lv<3>) (sext_ln1116_70_fu_24047_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_870_fu_47971_p1() {
    mul_ln1118_870_fu_47971_p1 = tmp_870_fu_47957_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_870_fu_47971_p2() {
    mul_ln1118_870_fu_47971_p2 = (!mul_ln1118_870_fu_47971_p0.read().is_01() || !mul_ln1118_870_fu_47971_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_870_fu_47971_p0.read()) * sc_bigint<5>(mul_ln1118_870_fu_47971_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_871_fu_89881_p0() {
    mul_ln1118_871_fu_89881_p0 =  (sc_lv<3>) (sext_ln1116_71_reg_106195.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_871_fu_89881_p1() {
    mul_ln1118_871_fu_89881_p1 = tmp_871_reg_109186.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_871_fu_89881_p2() {
    mul_ln1118_871_fu_89881_p2 = (!mul_ln1118_871_fu_89881_p0.read().is_01() || !mul_ln1118_871_fu_89881_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_871_fu_89881_p0.read()) * sc_bigint<5>(mul_ln1118_871_fu_89881_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_872_fu_48013_p0() {
    mul_ln1118_872_fu_48013_p0 =  (sc_lv<3>) (sext_ln1116_72_fu_24113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_872_fu_48013_p1() {
    mul_ln1118_872_fu_48013_p1 = tmp_872_fu_47999_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_872_fu_48013_p2() {
    mul_ln1118_872_fu_48013_p2 = (!mul_ln1118_872_fu_48013_p0.read().is_01() || !mul_ln1118_872_fu_48013_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_872_fu_48013_p0.read()) * sc_bigint<5>(mul_ln1118_872_fu_48013_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_873_fu_48045_p0() {
    mul_ln1118_873_fu_48045_p0 =  (sc_lv<3>) (sext_ln1116_73_fu_24157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_873_fu_48045_p1() {
    mul_ln1118_873_fu_48045_p1 = tmp_873_fu_48031_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_873_fu_48045_p2() {
    mul_ln1118_873_fu_48045_p2 = (!mul_ln1118_873_fu_48045_p0.read().is_01() || !mul_ln1118_873_fu_48045_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_873_fu_48045_p0.read()) * sc_bigint<5>(mul_ln1118_873_fu_48045_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_874_fu_89901_p0() {
    mul_ln1118_874_fu_89901_p0 =  (sc_lv<3>) (sext_ln1116_74_reg_106213.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_874_fu_89901_p1() {
    mul_ln1118_874_fu_89901_p1 = tmp_874_reg_109191.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_874_fu_89901_p2() {
    mul_ln1118_874_fu_89901_p2 = (!mul_ln1118_874_fu_89901_p0.read().is_01() || !mul_ln1118_874_fu_89901_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_874_fu_89901_p0.read()) * sc_bigint<5>(mul_ln1118_874_fu_89901_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_875_fu_48087_p0() {
    mul_ln1118_875_fu_48087_p0 =  (sc_lv<3>) (sext_ln1116_75_fu_24223_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_875_fu_48087_p1() {
    mul_ln1118_875_fu_48087_p1 = tmp_875_fu_48073_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_875_fu_48087_p2() {
    mul_ln1118_875_fu_48087_p2 = (!mul_ln1118_875_fu_48087_p0.read().is_01() || !mul_ln1118_875_fu_48087_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_875_fu_48087_p0.read()) * sc_bigint<5>(mul_ln1118_875_fu_48087_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_876_fu_48119_p0() {
    mul_ln1118_876_fu_48119_p0 =  (sc_lv<3>) (sext_ln1116_76_fu_24267_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_876_fu_48119_p1() {
    mul_ln1118_876_fu_48119_p1 = tmp_876_fu_48105_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_876_fu_48119_p2() {
    mul_ln1118_876_fu_48119_p2 = (!mul_ln1118_876_fu_48119_p0.read().is_01() || !mul_ln1118_876_fu_48119_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_876_fu_48119_p0.read()) * sc_bigint<5>(mul_ln1118_876_fu_48119_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_877_fu_89921_p0() {
    mul_ln1118_877_fu_89921_p0 =  (sc_lv<3>) (sext_ln1116_77_reg_106231.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_877_fu_89921_p1() {
    mul_ln1118_877_fu_89921_p1 = tmp_877_reg_109196.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_877_fu_89921_p2() {
    mul_ln1118_877_fu_89921_p2 = (!mul_ln1118_877_fu_89921_p0.read().is_01() || !mul_ln1118_877_fu_89921_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_877_fu_89921_p0.read()) * sc_bigint<5>(mul_ln1118_877_fu_89921_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_878_fu_48161_p0() {
    mul_ln1118_878_fu_48161_p0 =  (sc_lv<3>) (sext_ln1116_78_fu_24333_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_878_fu_48161_p1() {
    mul_ln1118_878_fu_48161_p1 = tmp_878_fu_48147_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_878_fu_48161_p2() {
    mul_ln1118_878_fu_48161_p2 = (!mul_ln1118_878_fu_48161_p0.read().is_01() || !mul_ln1118_878_fu_48161_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_878_fu_48161_p0.read()) * sc_bigint<5>(mul_ln1118_878_fu_48161_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_879_fu_48193_p0() {
    mul_ln1118_879_fu_48193_p0 =  (sc_lv<3>) (sext_ln1116_79_fu_24377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_879_fu_48193_p1() {
    mul_ln1118_879_fu_48193_p1 = tmp_879_fu_48179_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_879_fu_48193_p2() {
    mul_ln1118_879_fu_48193_p2 = (!mul_ln1118_879_fu_48193_p0.read().is_01() || !mul_ln1118_879_fu_48193_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_879_fu_48193_p0.read()) * sc_bigint<5>(mul_ln1118_879_fu_48193_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_87_fu_24725_p0() {
    mul_ln1118_87_fu_24725_p0 =  (sc_lv<3>) (sext_ln1116_87_fu_24717_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_87_fu_24725_p1() {
    mul_ln1118_87_fu_24725_p1 = tmp_87_fu_24707_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_87_fu_24725_p2() {
    mul_ln1118_87_fu_24725_p2 = (!mul_ln1118_87_fu_24725_p0.read().is_01() || !mul_ln1118_87_fu_24725_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_87_fu_24725_p0.read()) * sc_bigint<5>(mul_ln1118_87_fu_24725_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_880_fu_48225_p0() {
    mul_ln1118_880_fu_48225_p0 =  (sc_lv<3>) (sext_ln1116_80_fu_24421_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_880_fu_48225_p1() {
    mul_ln1118_880_fu_48225_p1 = tmp_880_fu_48211_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_880_fu_48225_p2() {
    mul_ln1118_880_fu_48225_p2 = (!mul_ln1118_880_fu_48225_p0.read().is_01() || !mul_ln1118_880_fu_48225_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_880_fu_48225_p0.read()) * sc_bigint<5>(mul_ln1118_880_fu_48225_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_881_fu_48257_p0() {
    mul_ln1118_881_fu_48257_p0 =  (sc_lv<3>) (sext_ln1116_81_fu_24465_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_881_fu_48257_p1() {
    mul_ln1118_881_fu_48257_p1 = tmp_881_fu_48243_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_881_fu_48257_p2() {
    mul_ln1118_881_fu_48257_p2 = (!mul_ln1118_881_fu_48257_p0.read().is_01() || !mul_ln1118_881_fu_48257_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_881_fu_48257_p0.read()) * sc_bigint<5>(mul_ln1118_881_fu_48257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_882_fu_48289_p0() {
    mul_ln1118_882_fu_48289_p0 =  (sc_lv<3>) (sext_ln1116_82_fu_24509_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_882_fu_48289_p1() {
    mul_ln1118_882_fu_48289_p1 = tmp_882_fu_48275_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_882_fu_48289_p2() {
    mul_ln1118_882_fu_48289_p2 = (!mul_ln1118_882_fu_48289_p0.read().is_01() || !mul_ln1118_882_fu_48289_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_882_fu_48289_p0.read()) * sc_bigint<5>(mul_ln1118_882_fu_48289_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_883_fu_48321_p0() {
    mul_ln1118_883_fu_48321_p0 =  (sc_lv<3>) (sext_ln1116_83_fu_24553_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_883_fu_48321_p1() {
    mul_ln1118_883_fu_48321_p1 = tmp_883_fu_48307_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_883_fu_48321_p2() {
    mul_ln1118_883_fu_48321_p2 = (!mul_ln1118_883_fu_48321_p0.read().is_01() || !mul_ln1118_883_fu_48321_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_883_fu_48321_p0.read()) * sc_bigint<5>(mul_ln1118_883_fu_48321_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_884_fu_48353_p0() {
    mul_ln1118_884_fu_48353_p0 =  (sc_lv<3>) (sext_ln1116_84_fu_24597_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_884_fu_48353_p1() {
    mul_ln1118_884_fu_48353_p1 = tmp_884_fu_48339_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_884_fu_48353_p2() {
    mul_ln1118_884_fu_48353_p2 = (!mul_ln1118_884_fu_48353_p0.read().is_01() || !mul_ln1118_884_fu_48353_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_884_fu_48353_p0.read()) * sc_bigint<5>(mul_ln1118_884_fu_48353_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_885_fu_48373_p0() {
    mul_ln1118_885_fu_48373_p0 =  (sc_lv<3>) (sext_ln1116_85_fu_24629_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_885_fu_48373_p1() {
    mul_ln1118_885_fu_48373_p1 = tmp_885_fu_48359_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_885_fu_48373_p2() {
    mul_ln1118_885_fu_48373_p2 = (!mul_ln1118_885_fu_48373_p0.read().is_01() || !mul_ln1118_885_fu_48373_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_885_fu_48373_p0.read()) * sc_bigint<5>(mul_ln1118_885_fu_48373_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_886_fu_48405_p0() {
    mul_ln1118_886_fu_48405_p0 =  (sc_lv<3>) (sext_ln1116_86_fu_24673_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_886_fu_48405_p1() {
    mul_ln1118_886_fu_48405_p1 = tmp_886_fu_48391_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_886_fu_48405_p2() {
    mul_ln1118_886_fu_48405_p2 = (!mul_ln1118_886_fu_48405_p0.read().is_01() || !mul_ln1118_886_fu_48405_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_886_fu_48405_p0.read()) * sc_bigint<5>(mul_ln1118_886_fu_48405_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_887_fu_48437_p0() {
    mul_ln1118_887_fu_48437_p0 =  (sc_lv<3>) (sext_ln1116_87_fu_24717_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_887_fu_48437_p1() {
    mul_ln1118_887_fu_48437_p1 = tmp_887_fu_48423_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_887_fu_48437_p2() {
    mul_ln1118_887_fu_48437_p2 = (!mul_ln1118_887_fu_48437_p0.read().is_01() || !mul_ln1118_887_fu_48437_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_887_fu_48437_p0.read()) * sc_bigint<5>(mul_ln1118_887_fu_48437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_888_fu_48457_p0() {
    mul_ln1118_888_fu_48457_p0 =  (sc_lv<3>) (sext_ln1116_88_fu_24749_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_888_fu_48457_p1() {
    mul_ln1118_888_fu_48457_p1 = tmp_888_fu_48443_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_888_fu_48457_p2() {
    mul_ln1118_888_fu_48457_p2 = (!mul_ln1118_888_fu_48457_p0.read().is_01() || !mul_ln1118_888_fu_48457_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_888_fu_48457_p0.read()) * sc_bigint<5>(mul_ln1118_888_fu_48457_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_889_fu_48489_p0() {
    mul_ln1118_889_fu_48489_p0 =  (sc_lv<3>) (sext_ln1116_89_fu_24793_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_889_fu_48489_p1() {
    mul_ln1118_889_fu_48489_p1 = tmp_889_fu_48475_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_889_fu_48489_p2() {
    mul_ln1118_889_fu_48489_p2 = (!mul_ln1118_889_fu_48489_p0.read().is_01() || !mul_ln1118_889_fu_48489_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_889_fu_48489_p0.read()) * sc_bigint<5>(mul_ln1118_889_fu_48489_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_88_fu_24757_p0() {
    mul_ln1118_88_fu_24757_p0 =  (sc_lv<3>) (sext_ln1116_88_fu_24749_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_88_fu_24757_p1() {
    mul_ln1118_88_fu_24757_p1 = tmp_88_fu_24739_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_88_fu_24757_p2() {
    mul_ln1118_88_fu_24757_p2 = (!mul_ln1118_88_fu_24757_p0.read().is_01() || !mul_ln1118_88_fu_24757_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_88_fu_24757_p0.read()) * sc_bigint<5>(mul_ln1118_88_fu_24757_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_890_fu_89963_p0() {
    mul_ln1118_890_fu_89963_p0 =  (sc_lv<3>) (sext_ln1116_90_reg_106259.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_890_fu_89963_p1() {
    mul_ln1118_890_fu_89963_p1 = tmp_890_reg_109211.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_890_fu_89963_p2() {
    mul_ln1118_890_fu_89963_p2 = (!mul_ln1118_890_fu_89963_p0.read().is_01() || !mul_ln1118_890_fu_89963_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_890_fu_89963_p0.read()) * sc_bigint<5>(mul_ln1118_890_fu_89963_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_891_fu_48531_p0() {
    mul_ln1118_891_fu_48531_p0 =  (sc_lv<3>) (sext_ln1116_91_fu_24859_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_891_fu_48531_p1() {
    mul_ln1118_891_fu_48531_p1 = tmp_891_fu_48517_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_891_fu_48531_p2() {
    mul_ln1118_891_fu_48531_p2 = (!mul_ln1118_891_fu_48531_p0.read().is_01() || !mul_ln1118_891_fu_48531_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_891_fu_48531_p0.read()) * sc_bigint<5>(mul_ln1118_891_fu_48531_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_892_fu_48563_p0() {
    mul_ln1118_892_fu_48563_p0 =  (sc_lv<3>) (sext_ln1116_92_fu_24903_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_892_fu_48563_p1() {
    mul_ln1118_892_fu_48563_p1 = tmp_892_fu_48549_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_892_fu_48563_p2() {
    mul_ln1118_892_fu_48563_p2 = (!mul_ln1118_892_fu_48563_p0.read().is_01() || !mul_ln1118_892_fu_48563_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_892_fu_48563_p0.read()) * sc_bigint<5>(mul_ln1118_892_fu_48563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_893_fu_89983_p0() {
    mul_ln1118_893_fu_89983_p0 =  (sc_lv<3>) (sext_ln1116_93_reg_106277.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_893_fu_89983_p1() {
    mul_ln1118_893_fu_89983_p1 = tmp_893_reg_109216.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_893_fu_89983_p2() {
    mul_ln1118_893_fu_89983_p2 = (!mul_ln1118_893_fu_89983_p0.read().is_01() || !mul_ln1118_893_fu_89983_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_893_fu_89983_p0.read()) * sc_bigint<5>(mul_ln1118_893_fu_89983_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_894_fu_48605_p0() {
    mul_ln1118_894_fu_48605_p0 =  (sc_lv<3>) (sext_ln1116_94_fu_24969_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_894_fu_48605_p1() {
    mul_ln1118_894_fu_48605_p1 = tmp_894_fu_48591_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_894_fu_48605_p2() {
    mul_ln1118_894_fu_48605_p2 = (!mul_ln1118_894_fu_48605_p0.read().is_01() || !mul_ln1118_894_fu_48605_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_894_fu_48605_p0.read()) * sc_bigint<5>(mul_ln1118_894_fu_48605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_895_fu_48637_p0() {
    mul_ln1118_895_fu_48637_p0 =  (sc_lv<3>) (sext_ln1116_95_fu_25013_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_895_fu_48637_p1() {
    mul_ln1118_895_fu_48637_p1 = tmp_895_fu_48623_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_895_fu_48637_p2() {
    mul_ln1118_895_fu_48637_p2 = (!mul_ln1118_895_fu_48637_p0.read().is_01() || !mul_ln1118_895_fu_48637_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_895_fu_48637_p0.read()) * sc_bigint<5>(mul_ln1118_895_fu_48637_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_896_fu_90003_p0() {
    mul_ln1118_896_fu_90003_p0 =  (sc_lv<3>) (sext_ln1116_96_reg_106295.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_896_fu_90003_p1() {
    mul_ln1118_896_fu_90003_p1 = tmp_896_reg_109221.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_896_fu_90003_p2() {
    mul_ln1118_896_fu_90003_p2 = (!mul_ln1118_896_fu_90003_p0.read().is_01() || !mul_ln1118_896_fu_90003_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_896_fu_90003_p0.read()) * sc_bigint<5>(mul_ln1118_896_fu_90003_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_897_fu_48679_p0() {
    mul_ln1118_897_fu_48679_p0 =  (sc_lv<3>) (sext_ln1116_97_fu_25079_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_897_fu_48679_p1() {
    mul_ln1118_897_fu_48679_p1 = tmp_897_fu_48665_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_897_fu_48679_p2() {
    mul_ln1118_897_fu_48679_p2 = (!mul_ln1118_897_fu_48679_p0.read().is_01() || !mul_ln1118_897_fu_48679_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_897_fu_48679_p0.read()) * sc_bigint<5>(mul_ln1118_897_fu_48679_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_898_fu_48711_p0() {
    mul_ln1118_898_fu_48711_p0 =  (sc_lv<3>) (sext_ln1116_98_fu_25123_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_898_fu_48711_p1() {
    mul_ln1118_898_fu_48711_p1 = tmp_898_fu_48697_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_898_fu_48711_p2() {
    mul_ln1118_898_fu_48711_p2 = (!mul_ln1118_898_fu_48711_p0.read().is_01() || !mul_ln1118_898_fu_48711_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_898_fu_48711_p0.read()) * sc_bigint<5>(mul_ln1118_898_fu_48711_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_899_fu_90023_p0() {
    mul_ln1118_899_fu_90023_p0 =  (sc_lv<3>) (sext_ln1116_99_reg_106313.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_899_fu_90023_p1() {
    mul_ln1118_899_fu_90023_p1 = tmp_899_reg_109226.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_899_fu_90023_p2() {
    mul_ln1118_899_fu_90023_p2 = (!mul_ln1118_899_fu_90023_p0.read().is_01() || !mul_ln1118_899_fu_90023_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_899_fu_90023_p0.read()) * sc_bigint<5>(mul_ln1118_899_fu_90023_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_89_fu_24801_p0() {
    mul_ln1118_89_fu_24801_p0 =  (sc_lv<3>) (sext_ln1116_89_fu_24793_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_89_fu_24801_p1() {
    mul_ln1118_89_fu_24801_p1 = tmp_89_fu_24783_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_89_fu_24801_p2() {
    mul_ln1118_89_fu_24801_p2 = (!mul_ln1118_89_fu_24801_p0.read().is_01() || !mul_ln1118_89_fu_24801_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_89_fu_24801_p0.read()) * sc_bigint<5>(mul_ln1118_89_fu_24801_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_900_fu_48753_p0() {
    mul_ln1118_900_fu_48753_p0 =  (sc_lv<3>) (sext_ln1116_100_fu_25189_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_900_fu_48753_p1() {
    mul_ln1118_900_fu_48753_p1 = tmp_900_fu_48739_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_900_fu_48753_p2() {
    mul_ln1118_900_fu_48753_p2 = (!mul_ln1118_900_fu_48753_p0.read().is_01() || !mul_ln1118_900_fu_48753_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_900_fu_48753_p0.read()) * sc_bigint<5>(mul_ln1118_900_fu_48753_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_901_fu_48785_p0() {
    mul_ln1118_901_fu_48785_p0 =  (sc_lv<3>) (sext_ln1116_101_fu_25233_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_901_fu_48785_p1() {
    mul_ln1118_901_fu_48785_p1 = tmp_901_fu_48771_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_901_fu_48785_p2() {
    mul_ln1118_901_fu_48785_p2 = (!mul_ln1118_901_fu_48785_p0.read().is_01() || !mul_ln1118_901_fu_48785_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_901_fu_48785_p0.read()) * sc_bigint<5>(mul_ln1118_901_fu_48785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_902_fu_90043_p0() {
    mul_ln1118_902_fu_90043_p0 =  (sc_lv<3>) (sext_ln1116_102_reg_106331.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_902_fu_90043_p1() {
    mul_ln1118_902_fu_90043_p1 = tmp_902_reg_109231.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_902_fu_90043_p2() {
    mul_ln1118_902_fu_90043_p2 = (!mul_ln1118_902_fu_90043_p0.read().is_01() || !mul_ln1118_902_fu_90043_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_902_fu_90043_p0.read()) * sc_bigint<5>(mul_ln1118_902_fu_90043_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_903_fu_48827_p0() {
    mul_ln1118_903_fu_48827_p0 =  (sc_lv<3>) (sext_ln1116_103_fu_25299_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_903_fu_48827_p1() {
    mul_ln1118_903_fu_48827_p1 = tmp_903_fu_48813_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_903_fu_48827_p2() {
    mul_ln1118_903_fu_48827_p2 = (!mul_ln1118_903_fu_48827_p0.read().is_01() || !mul_ln1118_903_fu_48827_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_903_fu_48827_p0.read()) * sc_bigint<5>(mul_ln1118_903_fu_48827_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_904_fu_48859_p0() {
    mul_ln1118_904_fu_48859_p0 =  (sc_lv<3>) (sext_ln1116_104_fu_25343_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_904_fu_48859_p1() {
    mul_ln1118_904_fu_48859_p1 = tmp_904_fu_48845_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_904_fu_48859_p2() {
    mul_ln1118_904_fu_48859_p2 = (!mul_ln1118_904_fu_48859_p0.read().is_01() || !mul_ln1118_904_fu_48859_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_904_fu_48859_p0.read()) * sc_bigint<5>(mul_ln1118_904_fu_48859_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_905_fu_48891_p0() {
    mul_ln1118_905_fu_48891_p0 =  (sc_lv<3>) (sext_ln1116_105_fu_25387_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_905_fu_48891_p1() {
    mul_ln1118_905_fu_48891_p1 = tmp_905_fu_48877_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_905_fu_48891_p2() {
    mul_ln1118_905_fu_48891_p2 = (!mul_ln1118_905_fu_48891_p0.read().is_01() || !mul_ln1118_905_fu_48891_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_905_fu_48891_p0.read()) * sc_bigint<5>(mul_ln1118_905_fu_48891_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_906_fu_48923_p0() {
    mul_ln1118_906_fu_48923_p0 =  (sc_lv<3>) (sext_ln1116_106_fu_25431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_906_fu_48923_p1() {
    mul_ln1118_906_fu_48923_p1 = tmp_906_fu_48909_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_906_fu_48923_p2() {
    mul_ln1118_906_fu_48923_p2 = (!mul_ln1118_906_fu_48923_p0.read().is_01() || !mul_ln1118_906_fu_48923_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_906_fu_48923_p0.read()) * sc_bigint<5>(mul_ln1118_906_fu_48923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_907_fu_48955_p0() {
    mul_ln1118_907_fu_48955_p0 =  (sc_lv<3>) (sext_ln1116_107_fu_25475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_907_fu_48955_p1() {
    mul_ln1118_907_fu_48955_p1 = tmp_907_fu_48941_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_907_fu_48955_p2() {
    mul_ln1118_907_fu_48955_p2 = (!mul_ln1118_907_fu_48955_p0.read().is_01() || !mul_ln1118_907_fu_48955_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_907_fu_48955_p0.read()) * sc_bigint<5>(mul_ln1118_907_fu_48955_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_908_fu_48987_p0() {
    mul_ln1118_908_fu_48987_p0 =  (sc_lv<3>) (sext_ln1116_108_fu_25519_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_908_fu_48987_p1() {
    mul_ln1118_908_fu_48987_p1 = tmp_908_fu_48973_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_908_fu_48987_p2() {
    mul_ln1118_908_fu_48987_p2 = (!mul_ln1118_908_fu_48987_p0.read().is_01() || !mul_ln1118_908_fu_48987_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_908_fu_48987_p0.read()) * sc_bigint<5>(mul_ln1118_908_fu_48987_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_909_fu_49019_p0() {
    mul_ln1118_909_fu_49019_p0 =  (sc_lv<3>) (sext_ln1116_109_fu_25563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_909_fu_49019_p1() {
    mul_ln1118_909_fu_49019_p1 = tmp_909_fu_49005_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_909_fu_49019_p2() {
    mul_ln1118_909_fu_49019_p2 = (!mul_ln1118_909_fu_49019_p0.read().is_01() || !mul_ln1118_909_fu_49019_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_909_fu_49019_p0.read()) * sc_bigint<5>(mul_ln1118_909_fu_49019_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_90_fu_80548_p0() {
    mul_ln1118_90_fu_80548_p0 =  (sc_lv<3>) (sext_ln1116_90_reg_106259.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_90_fu_80548_p1() {
    mul_ln1118_90_fu_80548_p1 = tmp_90_reg_106254.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_90_fu_80548_p2() {
    mul_ln1118_90_fu_80548_p2 = (!mul_ln1118_90_fu_80548_p0.read().is_01() || !mul_ln1118_90_fu_80548_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_90_fu_80548_p0.read()) * sc_bigint<5>(mul_ln1118_90_fu_80548_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_910_fu_49039_p0() {
    mul_ln1118_910_fu_49039_p0 =  (sc_lv<3>) (sext_ln1116_110_fu_25595_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_910_fu_49039_p1() {
    mul_ln1118_910_fu_49039_p1 = tmp_910_fu_49025_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_910_fu_49039_p2() {
    mul_ln1118_910_fu_49039_p2 = (!mul_ln1118_910_fu_49039_p0.read().is_01() || !mul_ln1118_910_fu_49039_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_910_fu_49039_p0.read()) * sc_bigint<5>(mul_ln1118_910_fu_49039_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_911_fu_49071_p0() {
    mul_ln1118_911_fu_49071_p0 =  (sc_lv<3>) (sext_ln1116_111_fu_25639_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_911_fu_49071_p1() {
    mul_ln1118_911_fu_49071_p1 = tmp_911_fu_49057_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_911_fu_49071_p2() {
    mul_ln1118_911_fu_49071_p2 = (!mul_ln1118_911_fu_49071_p0.read().is_01() || !mul_ln1118_911_fu_49071_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_911_fu_49071_p0.read()) * sc_bigint<5>(mul_ln1118_911_fu_49071_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_912_fu_49103_p0() {
    mul_ln1118_912_fu_49103_p0 =  (sc_lv<3>) (sext_ln1116_112_fu_25683_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_912_fu_49103_p1() {
    mul_ln1118_912_fu_49103_p1 = tmp_912_fu_49089_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_912_fu_49103_p2() {
    mul_ln1118_912_fu_49103_p2 = (!mul_ln1118_912_fu_49103_p0.read().is_01() || !mul_ln1118_912_fu_49103_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_912_fu_49103_p0.read()) * sc_bigint<5>(mul_ln1118_912_fu_49103_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_913_fu_49123_p0() {
    mul_ln1118_913_fu_49123_p0 =  (sc_lv<3>) (sext_ln1116_113_fu_25715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_913_fu_49123_p1() {
    mul_ln1118_913_fu_49123_p1 = tmp_913_fu_49109_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_913_fu_49123_p2() {
    mul_ln1118_913_fu_49123_p2 = (!mul_ln1118_913_fu_49123_p0.read().is_01() || !mul_ln1118_913_fu_49123_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_913_fu_49123_p0.read()) * sc_bigint<5>(mul_ln1118_913_fu_49123_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_914_fu_49155_p0() {
    mul_ln1118_914_fu_49155_p0 =  (sc_lv<3>) (sext_ln1116_114_fu_25759_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_914_fu_49155_p1() {
    mul_ln1118_914_fu_49155_p1 = tmp_914_fu_49141_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_914_fu_49155_p2() {
    mul_ln1118_914_fu_49155_p2 = (!mul_ln1118_914_fu_49155_p0.read().is_01() || !mul_ln1118_914_fu_49155_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_914_fu_49155_p0.read()) * sc_bigint<5>(mul_ln1118_914_fu_49155_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_915_fu_90085_p0() {
    mul_ln1118_915_fu_90085_p0 =  (sc_lv<3>) (sext_ln1116_115_reg_106359.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_915_fu_90085_p1() {
    mul_ln1118_915_fu_90085_p1 = tmp_915_reg_109246.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_915_fu_90085_p2() {
    mul_ln1118_915_fu_90085_p2 = (!mul_ln1118_915_fu_90085_p0.read().is_01() || !mul_ln1118_915_fu_90085_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_915_fu_90085_p0.read()) * sc_bigint<5>(mul_ln1118_915_fu_90085_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_916_fu_49197_p0() {
    mul_ln1118_916_fu_49197_p0 =  (sc_lv<3>) (sext_ln1116_116_fu_25825_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_916_fu_49197_p1() {
    mul_ln1118_916_fu_49197_p1 = tmp_916_fu_49183_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_916_fu_49197_p2() {
    mul_ln1118_916_fu_49197_p2 = (!mul_ln1118_916_fu_49197_p0.read().is_01() || !mul_ln1118_916_fu_49197_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_916_fu_49197_p0.read()) * sc_bigint<5>(mul_ln1118_916_fu_49197_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_917_fu_49229_p0() {
    mul_ln1118_917_fu_49229_p0 =  (sc_lv<3>) (sext_ln1116_117_fu_25869_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_917_fu_49229_p1() {
    mul_ln1118_917_fu_49229_p1 = tmp_917_fu_49215_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_917_fu_49229_p2() {
    mul_ln1118_917_fu_49229_p2 = (!mul_ln1118_917_fu_49229_p0.read().is_01() || !mul_ln1118_917_fu_49229_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_917_fu_49229_p0.read()) * sc_bigint<5>(mul_ln1118_917_fu_49229_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_918_fu_90105_p0() {
    mul_ln1118_918_fu_90105_p0 =  (sc_lv<3>) (sext_ln1116_118_reg_106377.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_918_fu_90105_p1() {
    mul_ln1118_918_fu_90105_p1 = tmp_918_reg_109251.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_918_fu_90105_p2() {
    mul_ln1118_918_fu_90105_p2 = (!mul_ln1118_918_fu_90105_p0.read().is_01() || !mul_ln1118_918_fu_90105_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_918_fu_90105_p0.read()) * sc_bigint<5>(mul_ln1118_918_fu_90105_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_919_fu_49271_p0() {
    mul_ln1118_919_fu_49271_p0 =  (sc_lv<3>) (sext_ln1116_119_fu_25935_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_919_fu_49271_p1() {
    mul_ln1118_919_fu_49271_p1 = tmp_919_fu_49257_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_919_fu_49271_p2() {
    mul_ln1118_919_fu_49271_p2 = (!mul_ln1118_919_fu_49271_p0.read().is_01() || !mul_ln1118_919_fu_49271_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_919_fu_49271_p0.read()) * sc_bigint<5>(mul_ln1118_919_fu_49271_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_91_fu_24867_p0() {
    mul_ln1118_91_fu_24867_p0 =  (sc_lv<3>) (sext_ln1116_91_fu_24859_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_91_fu_24867_p1() {
    mul_ln1118_91_fu_24867_p1 = tmp_91_fu_24849_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_91_fu_24867_p2() {
    mul_ln1118_91_fu_24867_p2 = (!mul_ln1118_91_fu_24867_p0.read().is_01() || !mul_ln1118_91_fu_24867_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_91_fu_24867_p0.read()) * sc_bigint<5>(mul_ln1118_91_fu_24867_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_920_fu_49303_p0() {
    mul_ln1118_920_fu_49303_p0 =  (sc_lv<3>) (sext_ln1116_120_fu_25979_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_920_fu_49303_p1() {
    mul_ln1118_920_fu_49303_p1 = tmp_920_fu_49289_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_920_fu_49303_p2() {
    mul_ln1118_920_fu_49303_p2 = (!mul_ln1118_920_fu_49303_p0.read().is_01() || !mul_ln1118_920_fu_49303_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_920_fu_49303_p0.read()) * sc_bigint<5>(mul_ln1118_920_fu_49303_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_921_fu_90125_p0() {
    mul_ln1118_921_fu_90125_p0 =  (sc_lv<3>) (sext_ln1116_121_reg_106395.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_921_fu_90125_p1() {
    mul_ln1118_921_fu_90125_p1 = tmp_921_reg_109256.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_921_fu_90125_p2() {
    mul_ln1118_921_fu_90125_p2 = (!mul_ln1118_921_fu_90125_p0.read().is_01() || !mul_ln1118_921_fu_90125_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_921_fu_90125_p0.read()) * sc_bigint<5>(mul_ln1118_921_fu_90125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_922_fu_49345_p0() {
    mul_ln1118_922_fu_49345_p0 =  (sc_lv<3>) (sext_ln1116_122_fu_26045_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_922_fu_49345_p1() {
    mul_ln1118_922_fu_49345_p1 = tmp_922_fu_49331_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_922_fu_49345_p2() {
    mul_ln1118_922_fu_49345_p2 = (!mul_ln1118_922_fu_49345_p0.read().is_01() || !mul_ln1118_922_fu_49345_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_922_fu_49345_p0.read()) * sc_bigint<5>(mul_ln1118_922_fu_49345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_923_fu_49377_p0() {
    mul_ln1118_923_fu_49377_p0 =  (sc_lv<3>) (sext_ln1116_123_fu_26089_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_923_fu_49377_p1() {
    mul_ln1118_923_fu_49377_p1 = tmp_923_fu_49363_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_923_fu_49377_p2() {
    mul_ln1118_923_fu_49377_p2 = (!mul_ln1118_923_fu_49377_p0.read().is_01() || !mul_ln1118_923_fu_49377_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_923_fu_49377_p0.read()) * sc_bigint<5>(mul_ln1118_923_fu_49377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_924_fu_90145_p0() {
    mul_ln1118_924_fu_90145_p0 =  (sc_lv<3>) (sext_ln1116_124_reg_106413.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_924_fu_90145_p1() {
    mul_ln1118_924_fu_90145_p1 = tmp_924_reg_109261.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_924_fu_90145_p2() {
    mul_ln1118_924_fu_90145_p2 = (!mul_ln1118_924_fu_90145_p0.read().is_01() || !mul_ln1118_924_fu_90145_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_924_fu_90145_p0.read()) * sc_bigint<5>(mul_ln1118_924_fu_90145_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_925_fu_49419_p0() {
    mul_ln1118_925_fu_49419_p0 =  (sc_lv<3>) (sext_ln1116_125_fu_26155_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_925_fu_49419_p1() {
    mul_ln1118_925_fu_49419_p1 = tmp_925_fu_49405_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_925_fu_49419_p2() {
    mul_ln1118_925_fu_49419_p2 = (!mul_ln1118_925_fu_49419_p0.read().is_01() || !mul_ln1118_925_fu_49419_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_925_fu_49419_p0.read()) * sc_bigint<5>(mul_ln1118_925_fu_49419_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_926_fu_49451_p0() {
    mul_ln1118_926_fu_49451_p0 =  (sc_lv<3>) (sext_ln1116_126_fu_26199_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_926_fu_49451_p1() {
    mul_ln1118_926_fu_49451_p1 = tmp_926_fu_49437_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_926_fu_49451_p2() {
    mul_ln1118_926_fu_49451_p2 = (!mul_ln1118_926_fu_49451_p0.read().is_01() || !mul_ln1118_926_fu_49451_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_926_fu_49451_p0.read()) * sc_bigint<5>(mul_ln1118_926_fu_49451_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_927_fu_90165_p0() {
    mul_ln1118_927_fu_90165_p0 =  (sc_lv<3>) (sext_ln1116_127_reg_106431.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_927_fu_90165_p1() {
    mul_ln1118_927_fu_90165_p1 = tmp_927_reg_109266.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_927_fu_90165_p2() {
    mul_ln1118_927_fu_90165_p2 = (!mul_ln1118_927_fu_90165_p0.read().is_01() || !mul_ln1118_927_fu_90165_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_927_fu_90165_p0.read()) * sc_bigint<5>(mul_ln1118_927_fu_90165_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_928_fu_49493_p0() {
    mul_ln1118_928_fu_49493_p0 =  (sc_lv<3>) (sext_ln1116_128_fu_26265_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_928_fu_49493_p1() {
    mul_ln1118_928_fu_49493_p1 = tmp_928_fu_49479_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_928_fu_49493_p2() {
    mul_ln1118_928_fu_49493_p2 = (!mul_ln1118_928_fu_49493_p0.read().is_01() || !mul_ln1118_928_fu_49493_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_928_fu_49493_p0.read()) * sc_bigint<5>(mul_ln1118_928_fu_49493_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_929_fu_49525_p0() {
    mul_ln1118_929_fu_49525_p0 =  (sc_lv<3>) (sext_ln1116_129_fu_26309_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_929_fu_49525_p1() {
    mul_ln1118_929_fu_49525_p1 = tmp_929_fu_49511_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_929_fu_49525_p2() {
    mul_ln1118_929_fu_49525_p2 = (!mul_ln1118_929_fu_49525_p0.read().is_01() || !mul_ln1118_929_fu_49525_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_929_fu_49525_p0.read()) * sc_bigint<5>(mul_ln1118_929_fu_49525_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_92_fu_24911_p0() {
    mul_ln1118_92_fu_24911_p0 =  (sc_lv<3>) (sext_ln1116_92_fu_24903_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_92_fu_24911_p1() {
    mul_ln1118_92_fu_24911_p1 = tmp_92_fu_24893_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_92_fu_24911_p2() {
    mul_ln1118_92_fu_24911_p2 = (!mul_ln1118_92_fu_24911_p0.read().is_01() || !mul_ln1118_92_fu_24911_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_92_fu_24911_p0.read()) * sc_bigint<5>(mul_ln1118_92_fu_24911_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_930_fu_49557_p0() {
    mul_ln1118_930_fu_49557_p0 =  (sc_lv<3>) (sext_ln1116_130_fu_26353_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_930_fu_49557_p1() {
    mul_ln1118_930_fu_49557_p1 = tmp_930_fu_49543_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_930_fu_49557_p2() {
    mul_ln1118_930_fu_49557_p2 = (!mul_ln1118_930_fu_49557_p0.read().is_01() || !mul_ln1118_930_fu_49557_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_930_fu_49557_p0.read()) * sc_bigint<5>(mul_ln1118_930_fu_49557_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_931_fu_49589_p0() {
    mul_ln1118_931_fu_49589_p0 =  (sc_lv<3>) (sext_ln1116_131_fu_26397_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_931_fu_49589_p1() {
    mul_ln1118_931_fu_49589_p1 = tmp_931_fu_49575_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_931_fu_49589_p2() {
    mul_ln1118_931_fu_49589_p2 = (!mul_ln1118_931_fu_49589_p0.read().is_01() || !mul_ln1118_931_fu_49589_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_931_fu_49589_p0.read()) * sc_bigint<5>(mul_ln1118_931_fu_49589_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_932_fu_49621_p0() {
    mul_ln1118_932_fu_49621_p0 =  (sc_lv<3>) (sext_ln1116_132_fu_26441_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_932_fu_49621_p1() {
    mul_ln1118_932_fu_49621_p1 = tmp_932_fu_49607_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_932_fu_49621_p2() {
    mul_ln1118_932_fu_49621_p2 = (!mul_ln1118_932_fu_49621_p0.read().is_01() || !mul_ln1118_932_fu_49621_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_932_fu_49621_p0.read()) * sc_bigint<5>(mul_ln1118_932_fu_49621_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_933_fu_49653_p0() {
    mul_ln1118_933_fu_49653_p0 =  (sc_lv<3>) (sext_ln1116_133_fu_26485_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_933_fu_49653_p1() {
    mul_ln1118_933_fu_49653_p1 = tmp_933_fu_49639_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_933_fu_49653_p2() {
    mul_ln1118_933_fu_49653_p2 = (!mul_ln1118_933_fu_49653_p0.read().is_01() || !mul_ln1118_933_fu_49653_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_933_fu_49653_p0.read()) * sc_bigint<5>(mul_ln1118_933_fu_49653_p1.read());
}

}

