#include "dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_328_fu_58720_p1() {
    mul_ln1118_328_fu_58720_p1 = tmp_328_reg_98197.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_328_fu_58720_p2() {
    mul_ln1118_328_fu_58720_p2 = (!mul_ln1118_328_fu_58720_p0.read().is_01() || !mul_ln1118_328_fu_58720_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_328_fu_58720_p0.read()) * sc_bigint<5>(mul_ln1118_328_fu_58720_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_329_fu_58739_p0() {
    mul_ln1118_329_fu_58739_p0 =  (sc_lv<12>) (sext_ln1116_129_cast_fu_54631_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_329_fu_58739_p1() {
    mul_ln1118_329_fu_58739_p1 = tmp_329_reg_98202.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_329_fu_58739_p2() {
    mul_ln1118_329_fu_58739_p2 = (!mul_ln1118_329_fu_58739_p0.read().is_01() || !mul_ln1118_329_fu_58739_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_329_fu_58739_p0.read()) * sc_bigint<5>(mul_ln1118_329_fu_58739_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_32_fu_22375_p0() {
    mul_ln1118_32_fu_22375_p0 =  (sc_lv<12>) (sext_ln1116_32_cast_fu_22367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_32_fu_22375_p1() {
    mul_ln1118_32_fu_22375_p1 = tmp_32_fu_22357_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_32_fu_22375_p2() {
    mul_ln1118_32_fu_22375_p2 = (!mul_ln1118_32_fu_22375_p0.read().is_01() || !mul_ln1118_32_fu_22375_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_32_fu_22375_p0.read()) * sc_bigint<5>(mul_ln1118_32_fu_22375_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_330_fu_58758_p0() {
    mul_ln1118_330_fu_58758_p0 =  (sc_lv<12>) (sext_ln1116_130_cast_fu_54653_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_330_fu_58758_p1() {
    mul_ln1118_330_fu_58758_p1 = tmp_330_reg_98207.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_330_fu_58758_p2() {
    mul_ln1118_330_fu_58758_p2 = (!mul_ln1118_330_fu_58758_p0.read().is_01() || !mul_ln1118_330_fu_58758_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_330_fu_58758_p0.read()) * sc_bigint<5>(mul_ln1118_330_fu_58758_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_331_fu_58777_p0() {
    mul_ln1118_331_fu_58777_p0 =  (sc_lv<12>) (sext_ln1116_131_cast_fu_54675_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_331_fu_58777_p1() {
    mul_ln1118_331_fu_58777_p1 = tmp_331_reg_98212.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_331_fu_58777_p2() {
    mul_ln1118_331_fu_58777_p2 = (!mul_ln1118_331_fu_58777_p0.read().is_01() || !mul_ln1118_331_fu_58777_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_331_fu_58777_p0.read()) * sc_bigint<5>(mul_ln1118_331_fu_58777_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_332_fu_28255_p0() {
    mul_ln1118_332_fu_28255_p0 =  (sc_lv<12>) (sext_ln1116_132_cast_fu_24659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_332_fu_28255_p1() {
    mul_ln1118_332_fu_28255_p1 = tmp_332_fu_28241_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_332_fu_28255_p2() {
    mul_ln1118_332_fu_28255_p2 = (!mul_ln1118_332_fu_28255_p0.read().is_01() || !mul_ln1118_332_fu_28255_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_332_fu_28255_p0.read()) * sc_bigint<5>(mul_ln1118_332_fu_28255_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_333_fu_28285_p0() {
    mul_ln1118_333_fu_28285_p0 =  (sc_lv<12>) (sext_ln1116_133_cast_fu_24701_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_333_fu_28285_p1() {
    mul_ln1118_333_fu_28285_p1 = tmp_333_fu_28271_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_333_fu_28285_p2() {
    mul_ln1118_333_fu_28285_p2 = (!mul_ln1118_333_fu_28285_p0.read().is_01() || !mul_ln1118_333_fu_28285_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_333_fu_28285_p0.read()) * sc_bigint<5>(mul_ln1118_333_fu_28285_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_334_fu_58796_p0() {
    mul_ln1118_334_fu_58796_p0 =  (sc_lv<12>) (sext_ln1116_134_cast_fu_54697_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_334_fu_58796_p1() {
    mul_ln1118_334_fu_58796_p1 = tmp_334_reg_98227.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_334_fu_58796_p2() {
    mul_ln1118_334_fu_58796_p2 = (!mul_ln1118_334_fu_58796_p0.read().is_01() || !mul_ln1118_334_fu_58796_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_334_fu_58796_p0.read()) * sc_bigint<5>(mul_ln1118_334_fu_58796_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_335_fu_58815_p0() {
    mul_ln1118_335_fu_58815_p0 =  (sc_lv<12>) (sext_ln1116_135_cast_fu_54719_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_335_fu_58815_p1() {
    mul_ln1118_335_fu_58815_p1 = tmp_335_reg_98232.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_335_fu_58815_p2() {
    mul_ln1118_335_fu_58815_p2 = (!mul_ln1118_335_fu_58815_p0.read().is_01() || !mul_ln1118_335_fu_58815_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_335_fu_58815_p0.read()) * sc_bigint<5>(mul_ln1118_335_fu_58815_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_336_fu_58834_p0() {
    mul_ln1118_336_fu_58834_p0 =  (sc_lv<12>) (sext_ln1116_136_cast_fu_54741_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_336_fu_58834_p1() {
    mul_ln1118_336_fu_58834_p1 = tmp_336_reg_98237.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_336_fu_58834_p2() {
    mul_ln1118_336_fu_58834_p2 = (!mul_ln1118_336_fu_58834_p0.read().is_01() || !mul_ln1118_336_fu_58834_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_336_fu_58834_p0.read()) * sc_bigint<5>(mul_ln1118_336_fu_58834_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_337_fu_58853_p0() {
    mul_ln1118_337_fu_58853_p0 =  (sc_lv<12>) (sext_ln1116_137_cast_fu_54763_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_337_fu_58853_p1() {
    mul_ln1118_337_fu_58853_p1 = tmp_337_reg_98242.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_337_fu_58853_p2() {
    mul_ln1118_337_fu_58853_p2 = (!mul_ln1118_337_fu_58853_p0.read().is_01() || !mul_ln1118_337_fu_58853_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_337_fu_58853_p0.read()) * sc_bigint<5>(mul_ln1118_337_fu_58853_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_338_fu_58872_p0() {
    mul_ln1118_338_fu_58872_p0 =  (sc_lv<12>) (sext_ln1116_138_cast_fu_54785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_338_fu_58872_p1() {
    mul_ln1118_338_fu_58872_p1 = tmp_338_reg_98247.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_338_fu_58872_p2() {
    mul_ln1118_338_fu_58872_p2 = (!mul_ln1118_338_fu_58872_p0.read().is_01() || !mul_ln1118_338_fu_58872_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_338_fu_58872_p0.read()) * sc_bigint<5>(mul_ln1118_338_fu_58872_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_339_fu_58891_p0() {
    mul_ln1118_339_fu_58891_p0 =  (sc_lv<12>) (sext_ln1116_139_cast_fu_54807_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_339_fu_58891_p1() {
    mul_ln1118_339_fu_58891_p1 = tmp_339_reg_98252.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_339_fu_58891_p2() {
    mul_ln1118_339_fu_58891_p2 = (!mul_ln1118_339_fu_58891_p0.read().is_01() || !mul_ln1118_339_fu_58891_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_339_fu_58891_p0.read()) * sc_bigint<5>(mul_ln1118_339_fu_58891_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_33_fu_22417_p0() {
    mul_ln1118_33_fu_22417_p0 =  (sc_lv<12>) (sext_ln1116_33_cast_fu_22409_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_33_fu_22417_p1() {
    mul_ln1118_33_fu_22417_p1 = tmp_33_fu_22399_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_33_fu_22417_p2() {
    mul_ln1118_33_fu_22417_p2 = (!mul_ln1118_33_fu_22417_p0.read().is_01() || !mul_ln1118_33_fu_22417_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_33_fu_22417_p0.read()) * sc_bigint<5>(mul_ln1118_33_fu_22417_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_340_fu_58910_p0() {
    mul_ln1118_340_fu_58910_p0 =  (sc_lv<12>) (sext_ln1116_140_cast_fu_54829_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_340_fu_58910_p1() {
    mul_ln1118_340_fu_58910_p1 = tmp_340_reg_98257.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_340_fu_58910_p2() {
    mul_ln1118_340_fu_58910_p2 = (!mul_ln1118_340_fu_58910_p0.read().is_01() || !mul_ln1118_340_fu_58910_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_340_fu_58910_p0.read()) * sc_bigint<5>(mul_ln1118_340_fu_58910_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_341_fu_58929_p0() {
    mul_ln1118_341_fu_58929_p0 =  (sc_lv<12>) (sext_ln1116_141_cast_fu_54851_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_341_fu_58929_p1() {
    mul_ln1118_341_fu_58929_p1 = tmp_341_reg_98262.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_341_fu_58929_p2() {
    mul_ln1118_341_fu_58929_p2 = (!mul_ln1118_341_fu_58929_p0.read().is_01() || !mul_ln1118_341_fu_58929_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_341_fu_58929_p0.read()) * sc_bigint<5>(mul_ln1118_341_fu_58929_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_342_fu_58948_p0() {
    mul_ln1118_342_fu_58948_p0 =  (sc_lv<12>) (sext_ln1116_142_cast_fu_54873_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_342_fu_58948_p1() {
    mul_ln1118_342_fu_58948_p1 = tmp_342_reg_98267.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_342_fu_58948_p2() {
    mul_ln1118_342_fu_58948_p2 = (!mul_ln1118_342_fu_58948_p0.read().is_01() || !mul_ln1118_342_fu_58948_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_342_fu_58948_p0.read()) * sc_bigint<5>(mul_ln1118_342_fu_58948_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_343_fu_58967_p0() {
    mul_ln1118_343_fu_58967_p0 =  (sc_lv<12>) (sext_ln1116_143_cast_fu_54895_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_343_fu_58967_p1() {
    mul_ln1118_343_fu_58967_p1 = tmp_343_reg_98272.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_343_fu_58967_p2() {
    mul_ln1118_343_fu_58967_p2 = (!mul_ln1118_343_fu_58967_p0.read().is_01() || !mul_ln1118_343_fu_58967_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_343_fu_58967_p0.read()) * sc_bigint<5>(mul_ln1118_343_fu_58967_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_344_fu_58986_p0() {
    mul_ln1118_344_fu_58986_p0 =  (sc_lv<12>) (sext_ln1116_144_cast_fu_54917_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_344_fu_58986_p1() {
    mul_ln1118_344_fu_58986_p1 = tmp_344_reg_98277.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_344_fu_58986_p2() {
    mul_ln1118_344_fu_58986_p2 = (!mul_ln1118_344_fu_58986_p0.read().is_01() || !mul_ln1118_344_fu_58986_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_344_fu_58986_p0.read()) * sc_bigint<5>(mul_ln1118_344_fu_58986_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_345_fu_59005_p0() {
    mul_ln1118_345_fu_59005_p0 =  (sc_lv<12>) (sext_ln1116_145_cast_fu_54939_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_345_fu_59005_p1() {
    mul_ln1118_345_fu_59005_p1 = tmp_345_reg_98282.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_345_fu_59005_p2() {
    mul_ln1118_345_fu_59005_p2 = (!mul_ln1118_345_fu_59005_p0.read().is_01() || !mul_ln1118_345_fu_59005_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_345_fu_59005_p0.read()) * sc_bigint<5>(mul_ln1118_345_fu_59005_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_346_fu_59024_p0() {
    mul_ln1118_346_fu_59024_p0 =  (sc_lv<12>) (sext_ln1116_146_cast_fu_54961_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_346_fu_59024_p1() {
    mul_ln1118_346_fu_59024_p1 = tmp_346_reg_98287.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_346_fu_59024_p2() {
    mul_ln1118_346_fu_59024_p2 = (!mul_ln1118_346_fu_59024_p0.read().is_01() || !mul_ln1118_346_fu_59024_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_346_fu_59024_p0.read()) * sc_bigint<5>(mul_ln1118_346_fu_59024_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_347_fu_59043_p0() {
    mul_ln1118_347_fu_59043_p0 =  (sc_lv<12>) (sext_ln1116_147_cast_fu_54983_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_347_fu_59043_p1() {
    mul_ln1118_347_fu_59043_p1 = tmp_347_reg_98292.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_347_fu_59043_p2() {
    mul_ln1118_347_fu_59043_p2 = (!mul_ln1118_347_fu_59043_p0.read().is_01() || !mul_ln1118_347_fu_59043_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_347_fu_59043_p0.read()) * sc_bigint<5>(mul_ln1118_347_fu_59043_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_348_fu_59062_p0() {
    mul_ln1118_348_fu_59062_p0 =  (sc_lv<12>) (sext_ln1116_148_cast_fu_55005_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_348_fu_59062_p1() {
    mul_ln1118_348_fu_59062_p1 = tmp_348_reg_98297.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_348_fu_59062_p2() {
    mul_ln1118_348_fu_59062_p2 = (!mul_ln1118_348_fu_59062_p0.read().is_01() || !mul_ln1118_348_fu_59062_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_348_fu_59062_p0.read()) * sc_bigint<5>(mul_ln1118_348_fu_59062_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_349_fu_59081_p0() {
    mul_ln1118_349_fu_59081_p0 =  (sc_lv<12>) (sext_ln1116_149_cast_fu_55027_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_349_fu_59081_p1() {
    mul_ln1118_349_fu_59081_p1 = tmp_349_reg_98302.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_349_fu_59081_p2() {
    mul_ln1118_349_fu_59081_p2 = (!mul_ln1118_349_fu_59081_p0.read().is_01() || !mul_ln1118_349_fu_59081_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_349_fu_59081_p0.read()) * sc_bigint<5>(mul_ln1118_349_fu_59081_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_34_fu_52955_p0() {
    mul_ln1118_34_fu_52955_p0 =  (sc_lv<12>) (sext_ln1116_34_cast_fu_52949_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_34_fu_52955_p1() {
    mul_ln1118_34_fu_52955_p1 = tmp_34_reg_95970.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_34_fu_52955_p2() {
    mul_ln1118_34_fu_52955_p2 = (!mul_ln1118_34_fu_52955_p0.read().is_01() || !mul_ln1118_34_fu_52955_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_34_fu_52955_p0.read()) * sc_bigint<5>(mul_ln1118_34_fu_52955_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_350_fu_59100_p0() {
    mul_ln1118_350_fu_59100_p0 =  (sc_lv<12>) (sext_ln1116_150_cast_fu_55049_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_350_fu_59100_p1() {
    mul_ln1118_350_fu_59100_p1 = tmp_350_reg_98307.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_350_fu_59100_p2() {
    mul_ln1118_350_fu_59100_p2 = (!mul_ln1118_350_fu_59100_p0.read().is_01() || !mul_ln1118_350_fu_59100_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_350_fu_59100_p0.read()) * sc_bigint<5>(mul_ln1118_350_fu_59100_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_351_fu_59119_p0() {
    mul_ln1118_351_fu_59119_p0 =  (sc_lv<12>) (sext_ln1116_151_cast_reg_97064.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_351_fu_59119_p1() {
    mul_ln1118_351_fu_59119_p1 = tmp_351_reg_98312.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_351_fu_59119_p2() {
    mul_ln1118_351_fu_59119_p2 = (!mul_ln1118_351_fu_59119_p0.read().is_01() || !mul_ln1118_351_fu_59119_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_351_fu_59119_p0.read()) * sc_bigint<5>(mul_ln1118_351_fu_59119_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_352_fu_59137_p0() {
    mul_ln1118_352_fu_59137_p0 =  (sc_lv<12>) (sext_ln1116_152_cast_reg_97082.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_352_fu_59137_p1() {
    mul_ln1118_352_fu_59137_p1 = tmp_352_reg_98317.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_352_fu_59137_p2() {
    mul_ln1118_352_fu_59137_p2 = (!mul_ln1118_352_fu_59137_p0.read().is_01() || !mul_ln1118_352_fu_59137_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_352_fu_59137_p0.read()) * sc_bigint<5>(mul_ln1118_352_fu_59137_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_353_fu_28505_p0() {
    mul_ln1118_353_fu_28505_p0 =  (sc_lv<12>) (sext_ln1116_153_cast_fu_25093_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_353_fu_28505_p1() {
    mul_ln1118_353_fu_28505_p1 = tmp_353_fu_28491_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_353_fu_28505_p2() {
    mul_ln1118_353_fu_28505_p2 = (!mul_ln1118_353_fu_28505_p0.read().is_01() || !mul_ln1118_353_fu_28505_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_353_fu_28505_p0.read()) * sc_bigint<5>(mul_ln1118_353_fu_28505_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_354_fu_28535_p0() {
    mul_ln1118_354_fu_28535_p0 =  (sc_lv<12>) (sext_ln1116_154_cast_fu_25135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_354_fu_28535_p1() {
    mul_ln1118_354_fu_28535_p1 = tmp_354_fu_28521_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_354_fu_28535_p2() {
    mul_ln1118_354_fu_28535_p2 = (!mul_ln1118_354_fu_28535_p0.read().is_01() || !mul_ln1118_354_fu_28535_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_354_fu_28535_p0.read()) * sc_bigint<5>(mul_ln1118_354_fu_28535_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_355_fu_28565_p0() {
    mul_ln1118_355_fu_28565_p0 =  (sc_lv<12>) (sext_ln1116_155_cast_fu_25177_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_355_fu_28565_p1() {
    mul_ln1118_355_fu_28565_p1 = tmp_355_fu_28551_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_355_fu_28565_p2() {
    mul_ln1118_355_fu_28565_p2 = (!mul_ln1118_355_fu_28565_p0.read().is_01() || !mul_ln1118_355_fu_28565_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_355_fu_28565_p0.read()) * sc_bigint<5>(mul_ln1118_355_fu_28565_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_356_fu_28595_p0() {
    mul_ln1118_356_fu_28595_p0 =  (sc_lv<12>) (sext_ln1116_156_cast_fu_25219_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_356_fu_28595_p1() {
    mul_ln1118_356_fu_28595_p1 = tmp_356_fu_28581_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_356_fu_28595_p2() {
    mul_ln1118_356_fu_28595_p2 = (!mul_ln1118_356_fu_28595_p0.read().is_01() || !mul_ln1118_356_fu_28595_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_356_fu_28595_p0.read()) * sc_bigint<5>(mul_ln1118_356_fu_28595_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_357_fu_28625_p0() {
    mul_ln1118_357_fu_28625_p0 =  (sc_lv<12>) (sext_ln1116_157_cast_fu_25261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_357_fu_28625_p1() {
    mul_ln1118_357_fu_28625_p1 = tmp_357_fu_28611_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_357_fu_28625_p2() {
    mul_ln1118_357_fu_28625_p2 = (!mul_ln1118_357_fu_28625_p0.read().is_01() || !mul_ln1118_357_fu_28625_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_357_fu_28625_p0.read()) * sc_bigint<5>(mul_ln1118_357_fu_28625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_358_fu_28655_p0() {
    mul_ln1118_358_fu_28655_p0 =  (sc_lv<12>) (sext_ln1116_158_cast_fu_25303_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_358_fu_28655_p1() {
    mul_ln1118_358_fu_28655_p1 = tmp_358_fu_28641_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_358_fu_28655_p2() {
    mul_ln1118_358_fu_28655_p2 = (!mul_ln1118_358_fu_28655_p0.read().is_01() || !mul_ln1118_358_fu_28655_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_358_fu_28655_p0.read()) * sc_bigint<5>(mul_ln1118_358_fu_28655_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_359_fu_59155_p0() {
    mul_ln1118_359_fu_59155_p0 =  (sc_lv<12>) (sext_ln1116_159_cast_fu_55107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_359_fu_59155_p1() {
    mul_ln1118_359_fu_59155_p1 = tmp_359_reg_98352.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_359_fu_59155_p2() {
    mul_ln1118_359_fu_59155_p2 = (!mul_ln1118_359_fu_59155_p0.read().is_01() || !mul_ln1118_359_fu_59155_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_359_fu_59155_p0.read()) * sc_bigint<5>(mul_ln1118_359_fu_59155_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_35_fu_52977_p0() {
    mul_ln1118_35_fu_52977_p0 =  (sc_lv<12>) (sext_ln1116_35_cast_fu_52971_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_35_fu_52977_p1() {
    mul_ln1118_35_fu_52977_p1 = tmp_35_reg_95980.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_35_fu_52977_p2() {
    mul_ln1118_35_fu_52977_p2 = (!mul_ln1118_35_fu_52977_p0.read().is_01() || !mul_ln1118_35_fu_52977_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_35_fu_52977_p0.read()) * sc_bigint<5>(mul_ln1118_35_fu_52977_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_360_fu_59174_p0() {
    mul_ln1118_360_fu_59174_p0 =  (sc_lv<12>) (sext_ln1116_160_cast_fu_55129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_360_fu_59174_p1() {
    mul_ln1118_360_fu_59174_p1 = tmp_360_reg_98357.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_360_fu_59174_p2() {
    mul_ln1118_360_fu_59174_p2 = (!mul_ln1118_360_fu_59174_p0.read().is_01() || !mul_ln1118_360_fu_59174_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_360_fu_59174_p0.read()) * sc_bigint<5>(mul_ln1118_360_fu_59174_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_361_fu_59193_p0() {
    mul_ln1118_361_fu_59193_p0 =  (sc_lv<12>) (sext_ln1116_161_cast_fu_55151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_361_fu_59193_p1() {
    mul_ln1118_361_fu_59193_p1 = tmp_361_reg_98362.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_361_fu_59193_p2() {
    mul_ln1118_361_fu_59193_p2 = (!mul_ln1118_361_fu_59193_p0.read().is_01() || !mul_ln1118_361_fu_59193_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_361_fu_59193_p0.read()) * sc_bigint<5>(mul_ln1118_361_fu_59193_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_362_fu_59212_p0() {
    mul_ln1118_362_fu_59212_p0 =  (sc_lv<12>) (sext_ln1116_162_cast_fu_55173_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_362_fu_59212_p1() {
    mul_ln1118_362_fu_59212_p1 = tmp_362_reg_98367.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_362_fu_59212_p2() {
    mul_ln1118_362_fu_59212_p2 = (!mul_ln1118_362_fu_59212_p0.read().is_01() || !mul_ln1118_362_fu_59212_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_362_fu_59212_p0.read()) * sc_bigint<5>(mul_ln1118_362_fu_59212_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_363_fu_59231_p0() {
    mul_ln1118_363_fu_59231_p0 =  (sc_lv<12>) (sext_ln1116_163_cast_fu_55195_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_363_fu_59231_p1() {
    mul_ln1118_363_fu_59231_p1 = tmp_363_reg_98372.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_363_fu_59231_p2() {
    mul_ln1118_363_fu_59231_p2 = (!mul_ln1118_363_fu_59231_p0.read().is_01() || !mul_ln1118_363_fu_59231_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_363_fu_59231_p0.read()) * sc_bigint<5>(mul_ln1118_363_fu_59231_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_364_fu_59250_p0() {
    mul_ln1118_364_fu_59250_p0 =  (sc_lv<12>) (sext_ln1116_164_cast_fu_55217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_364_fu_59250_p1() {
    mul_ln1118_364_fu_59250_p1 = tmp_364_reg_98377.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_364_fu_59250_p2() {
    mul_ln1118_364_fu_59250_p2 = (!mul_ln1118_364_fu_59250_p0.read().is_01() || !mul_ln1118_364_fu_59250_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_364_fu_59250_p0.read()) * sc_bigint<5>(mul_ln1118_364_fu_59250_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_365_fu_59269_p0() {
    mul_ln1118_365_fu_59269_p0 =  (sc_lv<12>) (sext_ln1116_165_cast_fu_55239_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_365_fu_59269_p1() {
    mul_ln1118_365_fu_59269_p1 = tmp_365_reg_98382.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_365_fu_59269_p2() {
    mul_ln1118_365_fu_59269_p2 = (!mul_ln1118_365_fu_59269_p0.read().is_01() || !mul_ln1118_365_fu_59269_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_365_fu_59269_p0.read()) * sc_bigint<5>(mul_ln1118_365_fu_59269_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_366_fu_59288_p0() {
    mul_ln1118_366_fu_59288_p0 =  (sc_lv<12>) (sext_ln1116_166_cast_fu_55261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_366_fu_59288_p1() {
    mul_ln1118_366_fu_59288_p1 = tmp_366_reg_98387.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_366_fu_59288_p2() {
    mul_ln1118_366_fu_59288_p2 = (!mul_ln1118_366_fu_59288_p0.read().is_01() || !mul_ln1118_366_fu_59288_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_366_fu_59288_p0.read()) * sc_bigint<5>(mul_ln1118_366_fu_59288_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_367_fu_59307_p0() {
    mul_ln1118_367_fu_59307_p0 =  (sc_lv<12>) (sext_ln1116_167_cast_fu_55283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_367_fu_59307_p1() {
    mul_ln1118_367_fu_59307_p1 = tmp_367_reg_98392.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_367_fu_59307_p2() {
    mul_ln1118_367_fu_59307_p2 = (!mul_ln1118_367_fu_59307_p0.read().is_01() || !mul_ln1118_367_fu_59307_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_367_fu_59307_p0.read()) * sc_bigint<5>(mul_ln1118_367_fu_59307_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_368_fu_59326_p0() {
    mul_ln1118_368_fu_59326_p0 =  (sc_lv<12>) (sext_ln1116_168_cast_fu_55305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_368_fu_59326_p1() {
    mul_ln1118_368_fu_59326_p1 = tmp_368_reg_98397.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_368_fu_59326_p2() {
    mul_ln1118_368_fu_59326_p2 = (!mul_ln1118_368_fu_59326_p0.read().is_01() || !mul_ln1118_368_fu_59326_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_368_fu_59326_p0.read()) * sc_bigint<5>(mul_ln1118_368_fu_59326_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_369_fu_59345_p0() {
    mul_ln1118_369_fu_59345_p0 =  (sc_lv<12>) (sext_ln1116_169_cast_fu_55327_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_369_fu_59345_p1() {
    mul_ln1118_369_fu_59345_p1 = tmp_369_reg_98402.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_369_fu_59345_p2() {
    mul_ln1118_369_fu_59345_p2 = (!mul_ln1118_369_fu_59345_p0.read().is_01() || !mul_ln1118_369_fu_59345_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_369_fu_59345_p0.read()) * sc_bigint<5>(mul_ln1118_369_fu_59345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_36_fu_52999_p0() {
    mul_ln1118_36_fu_52999_p0 =  (sc_lv<12>) (sext_ln1116_36_cast_fu_52993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_36_fu_52999_p1() {
    mul_ln1118_36_fu_52999_p1 = tmp_36_reg_95990.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_36_fu_52999_p2() {
    mul_ln1118_36_fu_52999_p2 = (!mul_ln1118_36_fu_52999_p0.read().is_01() || !mul_ln1118_36_fu_52999_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_36_fu_52999_p0.read()) * sc_bigint<5>(mul_ln1118_36_fu_52999_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_370_fu_59364_p0() {
    mul_ln1118_370_fu_59364_p0 =  (sc_lv<12>) (sext_ln1116_170_cast_fu_55349_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_370_fu_59364_p1() {
    mul_ln1118_370_fu_59364_p1 = tmp_370_reg_98407.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_370_fu_59364_p2() {
    mul_ln1118_370_fu_59364_p2 = (!mul_ln1118_370_fu_59364_p0.read().is_01() || !mul_ln1118_370_fu_59364_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_370_fu_59364_p0.read()) * sc_bigint<5>(mul_ln1118_370_fu_59364_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_371_fu_59383_p0() {
    mul_ln1118_371_fu_59383_p0 =  (sc_lv<12>) (sext_ln1116_171_cast_fu_55371_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_371_fu_59383_p1() {
    mul_ln1118_371_fu_59383_p1 = tmp_371_reg_98412.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_371_fu_59383_p2() {
    mul_ln1118_371_fu_59383_p2 = (!mul_ln1118_371_fu_59383_p0.read().is_01() || !mul_ln1118_371_fu_59383_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_371_fu_59383_p0.read()) * sc_bigint<5>(mul_ln1118_371_fu_59383_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_372_fu_59402_p0() {
    mul_ln1118_372_fu_59402_p0 =  (sc_lv<12>) (sext_ln1116_172_cast_fu_55393_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_372_fu_59402_p1() {
    mul_ln1118_372_fu_59402_p1 = tmp_372_reg_98417.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_372_fu_59402_p2() {
    mul_ln1118_372_fu_59402_p2 = (!mul_ln1118_372_fu_59402_p0.read().is_01() || !mul_ln1118_372_fu_59402_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_372_fu_59402_p0.read()) * sc_bigint<5>(mul_ln1118_372_fu_59402_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_373_fu_59421_p0() {
    mul_ln1118_373_fu_59421_p0 =  (sc_lv<12>) (sext_ln1116_173_cast_fu_55415_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_373_fu_59421_p1() {
    mul_ln1118_373_fu_59421_p1 = tmp_373_reg_98422.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_373_fu_59421_p2() {
    mul_ln1118_373_fu_59421_p2 = (!mul_ln1118_373_fu_59421_p0.read().is_01() || !mul_ln1118_373_fu_59421_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_373_fu_59421_p0.read()) * sc_bigint<5>(mul_ln1118_373_fu_59421_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_374_fu_59440_p0() {
    mul_ln1118_374_fu_59440_p0 =  (sc_lv<12>) (sext_ln1116_174_cast_fu_55437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_374_fu_59440_p1() {
    mul_ln1118_374_fu_59440_p1 = tmp_374_reg_98427.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_374_fu_59440_p2() {
    mul_ln1118_374_fu_59440_p2 = (!mul_ln1118_374_fu_59440_p0.read().is_01() || !mul_ln1118_374_fu_59440_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_374_fu_59440_p0.read()) * sc_bigint<5>(mul_ln1118_374_fu_59440_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_375_fu_59459_p0() {
    mul_ln1118_375_fu_59459_p0 =  (sc_lv<12>) (sext_ln1116_175_cast_fu_55459_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_375_fu_59459_p1() {
    mul_ln1118_375_fu_59459_p1 = tmp_375_reg_98432.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_375_fu_59459_p2() {
    mul_ln1118_375_fu_59459_p2 = (!mul_ln1118_375_fu_59459_p0.read().is_01() || !mul_ln1118_375_fu_59459_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_375_fu_59459_p0.read()) * sc_bigint<5>(mul_ln1118_375_fu_59459_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_376_fu_59478_p0() {
    mul_ln1118_376_fu_59478_p0 =  (sc_lv<12>) (sext_ln1116_176_cast_reg_97300.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_376_fu_59478_p1() {
    mul_ln1118_376_fu_59478_p1 = tmp_376_reg_98437.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_376_fu_59478_p2() {
    mul_ln1118_376_fu_59478_p2 = (!mul_ln1118_376_fu_59478_p0.read().is_01() || !mul_ln1118_376_fu_59478_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_376_fu_59478_p0.read()) * sc_bigint<5>(mul_ln1118_376_fu_59478_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_377_fu_59496_p0() {
    mul_ln1118_377_fu_59496_p0 =  (sc_lv<12>) (sext_ln1116_177_cast_reg_97318.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_377_fu_59496_p1() {
    mul_ln1118_377_fu_59496_p1 = tmp_377_reg_98442.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_377_fu_59496_p2() {
    mul_ln1118_377_fu_59496_p2 = (!mul_ln1118_377_fu_59496_p0.read().is_01() || !mul_ln1118_377_fu_59496_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_377_fu_59496_p0.read()) * sc_bigint<5>(mul_ln1118_377_fu_59496_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_378_fu_28875_p0() {
    mul_ln1118_378_fu_28875_p0 =  (sc_lv<12>) (sext_ln1116_178_cast_fu_25695_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_378_fu_28875_p1() {
    mul_ln1118_378_fu_28875_p1 = tmp_378_fu_28861_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_378_fu_28875_p2() {
    mul_ln1118_378_fu_28875_p2 = (!mul_ln1118_378_fu_28875_p0.read().is_01() || !mul_ln1118_378_fu_28875_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_378_fu_28875_p0.read()) * sc_bigint<5>(mul_ln1118_378_fu_28875_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_379_fu_28905_p0() {
    mul_ln1118_379_fu_28905_p0 =  (sc_lv<12>) (sext_ln1116_179_cast_fu_25737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_379_fu_28905_p1() {
    mul_ln1118_379_fu_28905_p1 = tmp_379_fu_28891_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_379_fu_28905_p2() {
    mul_ln1118_379_fu_28905_p2 = (!mul_ln1118_379_fu_28905_p0.read().is_01() || !mul_ln1118_379_fu_28905_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_379_fu_28905_p0.read()) * sc_bigint<5>(mul_ln1118_379_fu_28905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_37_fu_53021_p0() {
    mul_ln1118_37_fu_53021_p0 =  (sc_lv<12>) (sext_ln1116_37_cast_fu_53015_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_37_fu_53021_p1() {
    mul_ln1118_37_fu_53021_p1 = tmp_37_reg_96000.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_37_fu_53021_p2() {
    mul_ln1118_37_fu_53021_p2 = (!mul_ln1118_37_fu_53021_p0.read().is_01() || !mul_ln1118_37_fu_53021_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_37_fu_53021_p0.read()) * sc_bigint<5>(mul_ln1118_37_fu_53021_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_380_fu_28935_p0() {
    mul_ln1118_380_fu_28935_p0 =  (sc_lv<12>) (sext_ln1116_180_cast_fu_25779_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_380_fu_28935_p1() {
    mul_ln1118_380_fu_28935_p1 = tmp_380_fu_28921_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_380_fu_28935_p2() {
    mul_ln1118_380_fu_28935_p2 = (!mul_ln1118_380_fu_28935_p0.read().is_01() || !mul_ln1118_380_fu_28935_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_380_fu_28935_p0.read()) * sc_bigint<5>(mul_ln1118_380_fu_28935_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_381_fu_28965_p0() {
    mul_ln1118_381_fu_28965_p0 =  (sc_lv<12>) (sext_ln1116_181_cast_fu_25821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_381_fu_28965_p1() {
    mul_ln1118_381_fu_28965_p1 = tmp_381_fu_28951_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_381_fu_28965_p2() {
    mul_ln1118_381_fu_28965_p2 = (!mul_ln1118_381_fu_28965_p0.read().is_01() || !mul_ln1118_381_fu_28965_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_381_fu_28965_p0.read()) * sc_bigint<5>(mul_ln1118_381_fu_28965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_382_fu_28995_p0() {
    mul_ln1118_382_fu_28995_p0 =  (sc_lv<12>) (sext_ln1116_182_cast_fu_25863_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_382_fu_28995_p1() {
    mul_ln1118_382_fu_28995_p1 = tmp_382_fu_28981_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_382_fu_28995_p2() {
    mul_ln1118_382_fu_28995_p2 = (!mul_ln1118_382_fu_28995_p0.read().is_01() || !mul_ln1118_382_fu_28995_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_382_fu_28995_p0.read()) * sc_bigint<5>(mul_ln1118_382_fu_28995_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_383_fu_29025_p0() {
    mul_ln1118_383_fu_29025_p0 =  (sc_lv<12>) (sext_ln1116_183_cast_fu_25905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_383_fu_29025_p1() {
    mul_ln1118_383_fu_29025_p1 = tmp_383_fu_29011_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_383_fu_29025_p2() {
    mul_ln1118_383_fu_29025_p2 = (!mul_ln1118_383_fu_29025_p0.read().is_01() || !mul_ln1118_383_fu_29025_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_383_fu_29025_p0.read()) * sc_bigint<5>(mul_ln1118_383_fu_29025_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_384_fu_59514_p0() {
    mul_ln1118_384_fu_59514_p0 =  (sc_lv<12>) (sext_ln1116_184_cast_fu_55517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_384_fu_59514_p1() {
    mul_ln1118_384_fu_59514_p1 = tmp_384_reg_98477.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_384_fu_59514_p2() {
    mul_ln1118_384_fu_59514_p2 = (!mul_ln1118_384_fu_59514_p0.read().is_01() || !mul_ln1118_384_fu_59514_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_384_fu_59514_p0.read()) * sc_bigint<5>(mul_ln1118_384_fu_59514_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_385_fu_59533_p0() {
    mul_ln1118_385_fu_59533_p0 =  (sc_lv<12>) (sext_ln1116_185_cast_fu_55539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_385_fu_59533_p1() {
    mul_ln1118_385_fu_59533_p1 = tmp_385_reg_98482.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_385_fu_59533_p2() {
    mul_ln1118_385_fu_59533_p2 = (!mul_ln1118_385_fu_59533_p0.read().is_01() || !mul_ln1118_385_fu_59533_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_385_fu_59533_p0.read()) * sc_bigint<5>(mul_ln1118_385_fu_59533_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_386_fu_59552_p0() {
    mul_ln1118_386_fu_59552_p0 =  (sc_lv<12>) (sext_ln1116_186_cast_fu_55561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_386_fu_59552_p1() {
    mul_ln1118_386_fu_59552_p1 = tmp_386_reg_98487.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_386_fu_59552_p2() {
    mul_ln1118_386_fu_59552_p2 = (!mul_ln1118_386_fu_59552_p0.read().is_01() || !mul_ln1118_386_fu_59552_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_386_fu_59552_p0.read()) * sc_bigint<5>(mul_ln1118_386_fu_59552_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_387_fu_59571_p0() {
    mul_ln1118_387_fu_59571_p0 =  (sc_lv<12>) (sext_ln1116_187_cast_fu_55583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_387_fu_59571_p1() {
    mul_ln1118_387_fu_59571_p1 = tmp_387_reg_98492.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_387_fu_59571_p2() {
    mul_ln1118_387_fu_59571_p2 = (!mul_ln1118_387_fu_59571_p0.read().is_01() || !mul_ln1118_387_fu_59571_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_387_fu_59571_p0.read()) * sc_bigint<5>(mul_ln1118_387_fu_59571_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_388_fu_59590_p0() {
    mul_ln1118_388_fu_59590_p0 =  (sc_lv<12>) (sext_ln1116_188_cast_fu_55605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_388_fu_59590_p1() {
    mul_ln1118_388_fu_59590_p1 = tmp_388_reg_98497.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_388_fu_59590_p2() {
    mul_ln1118_388_fu_59590_p2 = (!mul_ln1118_388_fu_59590_p0.read().is_01() || !mul_ln1118_388_fu_59590_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_388_fu_59590_p0.read()) * sc_bigint<5>(mul_ln1118_388_fu_59590_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_389_fu_59609_p0() {
    mul_ln1118_389_fu_59609_p0 =  (sc_lv<12>) (sext_ln1116_189_cast_fu_55627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_389_fu_59609_p1() {
    mul_ln1118_389_fu_59609_p1 = tmp_389_reg_98502.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_389_fu_59609_p2() {
    mul_ln1118_389_fu_59609_p2 = (!mul_ln1118_389_fu_59609_p0.read().is_01() || !mul_ln1118_389_fu_59609_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_389_fu_59609_p0.read()) * sc_bigint<5>(mul_ln1118_389_fu_59609_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_38_fu_53043_p0() {
    mul_ln1118_38_fu_53043_p0 =  (sc_lv<12>) (sext_ln1116_38_cast_fu_53037_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_38_fu_53043_p1() {
    mul_ln1118_38_fu_53043_p1 = tmp_38_reg_96010.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_38_fu_53043_p2() {
    mul_ln1118_38_fu_53043_p2 = (!mul_ln1118_38_fu_53043_p0.read().is_01() || !mul_ln1118_38_fu_53043_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_38_fu_53043_p0.read()) * sc_bigint<5>(mul_ln1118_38_fu_53043_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_390_fu_59628_p0() {
    mul_ln1118_390_fu_59628_p0 =  (sc_lv<12>) (sext_ln1116_190_cast_fu_55649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_390_fu_59628_p1() {
    mul_ln1118_390_fu_59628_p1 = tmp_390_reg_98507.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_390_fu_59628_p2() {
    mul_ln1118_390_fu_59628_p2 = (!mul_ln1118_390_fu_59628_p0.read().is_01() || !mul_ln1118_390_fu_59628_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_390_fu_59628_p0.read()) * sc_bigint<5>(mul_ln1118_390_fu_59628_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_391_fu_59647_p0() {
    mul_ln1118_391_fu_59647_p0 =  (sc_lv<12>) (sext_ln1116_191_cast_fu_55671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_391_fu_59647_p1() {
    mul_ln1118_391_fu_59647_p1 = tmp_391_reg_98512.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_391_fu_59647_p2() {
    mul_ln1118_391_fu_59647_p2 = (!mul_ln1118_391_fu_59647_p0.read().is_01() || !mul_ln1118_391_fu_59647_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_391_fu_59647_p0.read()) * sc_bigint<5>(mul_ln1118_391_fu_59647_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_392_fu_59666_p0() {
    mul_ln1118_392_fu_59666_p0 =  (sc_lv<12>) (sext_ln1116_192_cast_fu_55693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_392_fu_59666_p1() {
    mul_ln1118_392_fu_59666_p1 = tmp_392_reg_98517.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_392_fu_59666_p2() {
    mul_ln1118_392_fu_59666_p2 = (!mul_ln1118_392_fu_59666_p0.read().is_01() || !mul_ln1118_392_fu_59666_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_392_fu_59666_p0.read()) * sc_bigint<5>(mul_ln1118_392_fu_59666_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_393_fu_59685_p0() {
    mul_ln1118_393_fu_59685_p0 =  (sc_lv<12>) (sext_ln1116_193_cast_fu_55715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_393_fu_59685_p1() {
    mul_ln1118_393_fu_59685_p1 = tmp_393_reg_98522.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_393_fu_59685_p2() {
    mul_ln1118_393_fu_59685_p2 = (!mul_ln1118_393_fu_59685_p0.read().is_01() || !mul_ln1118_393_fu_59685_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_393_fu_59685_p0.read()) * sc_bigint<5>(mul_ln1118_393_fu_59685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_394_fu_59704_p0() {
    mul_ln1118_394_fu_59704_p0 =  (sc_lv<12>) (sext_ln1116_194_cast_fu_55737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_394_fu_59704_p1() {
    mul_ln1118_394_fu_59704_p1 = tmp_394_reg_98527.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_394_fu_59704_p2() {
    mul_ln1118_394_fu_59704_p2 = (!mul_ln1118_394_fu_59704_p0.read().is_01() || !mul_ln1118_394_fu_59704_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_394_fu_59704_p0.read()) * sc_bigint<5>(mul_ln1118_394_fu_59704_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_395_fu_59723_p0() {
    mul_ln1118_395_fu_59723_p0 =  (sc_lv<12>) (sext_ln1116_195_cast_fu_55759_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_395_fu_59723_p1() {
    mul_ln1118_395_fu_59723_p1 = tmp_395_reg_98532.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_395_fu_59723_p2() {
    mul_ln1118_395_fu_59723_p2 = (!mul_ln1118_395_fu_59723_p0.read().is_01() || !mul_ln1118_395_fu_59723_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_395_fu_59723_p0.read()) * sc_bigint<5>(mul_ln1118_395_fu_59723_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_396_fu_59742_p0() {
    mul_ln1118_396_fu_59742_p0 =  (sc_lv<12>) (sext_ln1116_196_cast_fu_55781_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_396_fu_59742_p1() {
    mul_ln1118_396_fu_59742_p1 = tmp_396_reg_98537.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_396_fu_59742_p2() {
    mul_ln1118_396_fu_59742_p2 = (!mul_ln1118_396_fu_59742_p0.read().is_01() || !mul_ln1118_396_fu_59742_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_396_fu_59742_p0.read()) * sc_bigint<5>(mul_ln1118_396_fu_59742_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_397_fu_59761_p0() {
    mul_ln1118_397_fu_59761_p0 =  (sc_lv<12>) (sext_ln1116_197_cast_fu_55803_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_397_fu_59761_p1() {
    mul_ln1118_397_fu_59761_p1 = tmp_397_reg_98542.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_397_fu_59761_p2() {
    mul_ln1118_397_fu_59761_p2 = (!mul_ln1118_397_fu_59761_p0.read().is_01() || !mul_ln1118_397_fu_59761_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_397_fu_59761_p0.read()) * sc_bigint<5>(mul_ln1118_397_fu_59761_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_398_fu_59780_p0() {
    mul_ln1118_398_fu_59780_p0 =  (sc_lv<12>) (sext_ln1116_198_cast_fu_55825_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_398_fu_59780_p1() {
    mul_ln1118_398_fu_59780_p1 = tmp_398_reg_98547.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_398_fu_59780_p2() {
    mul_ln1118_398_fu_59780_p2 = (!mul_ln1118_398_fu_59780_p0.read().is_01() || !mul_ln1118_398_fu_59780_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_398_fu_59780_p0.read()) * sc_bigint<5>(mul_ln1118_398_fu_59780_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_399_fu_59799_p0() {
    mul_ln1118_399_fu_59799_p0 =  (sc_lv<12>) (sext_ln1116_199_cast_fu_55847_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_399_fu_59799_p1() {
    mul_ln1118_399_fu_59799_p1 = tmp_399_reg_98552.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_399_fu_59799_p2() {
    mul_ln1118_399_fu_59799_p2 = (!mul_ln1118_399_fu_59799_p0.read().is_01() || !mul_ln1118_399_fu_59799_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_399_fu_59799_p0.read()) * sc_bigint<5>(mul_ln1118_399_fu_59799_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_39_fu_53065_p0() {
    mul_ln1118_39_fu_53065_p0 =  (sc_lv<12>) (sext_ln1116_39_cast_fu_53059_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_39_fu_53065_p1() {
    mul_ln1118_39_fu_53065_p1 = tmp_39_reg_96020.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_39_fu_53065_p2() {
    mul_ln1118_39_fu_53065_p2 = (!mul_ln1118_39_fu_53065_p0.read().is_01() || !mul_ln1118_39_fu_53065_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_39_fu_53065_p0.read()) * sc_bigint<5>(mul_ln1118_39_fu_53065_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_400_fu_59818_p0() {
    mul_ln1118_400_fu_59818_p0 =  (sc_lv<12>) (sext_ln1116_200_cast_fu_55869_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_400_fu_59818_p1() {
    mul_ln1118_400_fu_59818_p1 = tmp_400_reg_98557.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_400_fu_59818_p2() {
    mul_ln1118_400_fu_59818_p2 = (!mul_ln1118_400_fu_59818_p0.read().is_01() || !mul_ln1118_400_fu_59818_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_400_fu_59818_p0.read()) * sc_bigint<5>(mul_ln1118_400_fu_59818_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_401_fu_59837_p0() {
    mul_ln1118_401_fu_59837_p0 =  (sc_lv<12>) (sext_ln1116_201_cast_reg_97536.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_401_fu_59837_p1() {
    mul_ln1118_401_fu_59837_p1 = tmp_401_reg_98562.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_401_fu_59837_p2() {
    mul_ln1118_401_fu_59837_p2 = (!mul_ln1118_401_fu_59837_p0.read().is_01() || !mul_ln1118_401_fu_59837_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_401_fu_59837_p0.read()) * sc_bigint<5>(mul_ln1118_401_fu_59837_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_402_fu_59855_p0() {
    mul_ln1118_402_fu_59855_p0 =  (sc_lv<12>) (sext_ln1116_202_cast_reg_97554.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_402_fu_59855_p1() {
    mul_ln1118_402_fu_59855_p1 = tmp_402_reg_98567.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_402_fu_59855_p2() {
    mul_ln1118_402_fu_59855_p2 = (!mul_ln1118_402_fu_59855_p0.read().is_01() || !mul_ln1118_402_fu_59855_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_402_fu_59855_p0.read()) * sc_bigint<5>(mul_ln1118_402_fu_59855_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_403_fu_29245_p0() {
    mul_ln1118_403_fu_29245_p0 =  (sc_lv<12>) (sext_ln1116_203_cast_fu_26297_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_403_fu_29245_p1() {
    mul_ln1118_403_fu_29245_p1 = tmp_403_fu_29231_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_403_fu_29245_p2() {
    mul_ln1118_403_fu_29245_p2 = (!mul_ln1118_403_fu_29245_p0.read().is_01() || !mul_ln1118_403_fu_29245_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_403_fu_29245_p0.read()) * sc_bigint<5>(mul_ln1118_403_fu_29245_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_404_fu_29275_p0() {
    mul_ln1118_404_fu_29275_p0 =  (sc_lv<12>) (sext_ln1116_204_cast_fu_26339_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_404_fu_29275_p1() {
    mul_ln1118_404_fu_29275_p1 = tmp_404_fu_29261_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_404_fu_29275_p2() {
    mul_ln1118_404_fu_29275_p2 = (!mul_ln1118_404_fu_29275_p0.read().is_01() || !mul_ln1118_404_fu_29275_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_404_fu_29275_p0.read()) * sc_bigint<5>(mul_ln1118_404_fu_29275_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_405_fu_29305_p0() {
    mul_ln1118_405_fu_29305_p0 =  (sc_lv<12>) (sext_ln1116_205_cast_fu_26381_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_405_fu_29305_p1() {
    mul_ln1118_405_fu_29305_p1 = tmp_405_fu_29291_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_405_fu_29305_p2() {
    mul_ln1118_405_fu_29305_p2 = (!mul_ln1118_405_fu_29305_p0.read().is_01() || !mul_ln1118_405_fu_29305_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_405_fu_29305_p0.read()) * sc_bigint<5>(mul_ln1118_405_fu_29305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_406_fu_29335_p0() {
    mul_ln1118_406_fu_29335_p0 =  (sc_lv<12>) (sext_ln1116_206_cast_fu_26423_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_406_fu_29335_p1() {
    mul_ln1118_406_fu_29335_p1 = tmp_406_fu_29321_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_406_fu_29335_p2() {
    mul_ln1118_406_fu_29335_p2 = (!mul_ln1118_406_fu_29335_p0.read().is_01() || !mul_ln1118_406_fu_29335_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_406_fu_29335_p0.read()) * sc_bigint<5>(mul_ln1118_406_fu_29335_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_407_fu_29365_p0() {
    mul_ln1118_407_fu_29365_p0 =  (sc_lv<12>) (sext_ln1116_207_cast_fu_26465_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_407_fu_29365_p1() {
    mul_ln1118_407_fu_29365_p1 = tmp_407_fu_29351_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_407_fu_29365_p2() {
    mul_ln1118_407_fu_29365_p2 = (!mul_ln1118_407_fu_29365_p0.read().is_01() || !mul_ln1118_407_fu_29365_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_407_fu_29365_p0.read()) * sc_bigint<5>(mul_ln1118_407_fu_29365_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_408_fu_29395_p0() {
    mul_ln1118_408_fu_29395_p0 =  (sc_lv<12>) (sext_ln1116_208_cast_fu_26507_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_408_fu_29395_p1() {
    mul_ln1118_408_fu_29395_p1 = tmp_408_fu_29381_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_408_fu_29395_p2() {
    mul_ln1118_408_fu_29395_p2 = (!mul_ln1118_408_fu_29395_p0.read().is_01() || !mul_ln1118_408_fu_29395_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_408_fu_29395_p0.read()) * sc_bigint<5>(mul_ln1118_408_fu_29395_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_409_fu_60861_p0() {
    mul_ln1118_409_fu_60861_p0 =  (sc_lv<12>) (sext_ln1116_cast_fu_52531_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_409_fu_60861_p1() {
    mul_ln1118_409_fu_60861_p1 = tmp_409_reg_98602.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_409_fu_60861_p2() {
    mul_ln1118_409_fu_60861_p2 = (!mul_ln1118_409_fu_60861_p0.read().is_01() || !mul_ln1118_409_fu_60861_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_409_fu_60861_p0.read()) * sc_bigint<5>(mul_ln1118_409_fu_60861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_40_fu_53087_p0() {
    mul_ln1118_40_fu_53087_p0 =  (sc_lv<12>) (sext_ln1116_40_cast_fu_53081_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_40_fu_53087_p1() {
    mul_ln1118_40_fu_53087_p1 = tmp_40_reg_96030.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_40_fu_53087_p2() {
    mul_ln1118_40_fu_53087_p2 = (!mul_ln1118_40_fu_53087_p0.read().is_01() || !mul_ln1118_40_fu_53087_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_40_fu_53087_p0.read()) * sc_bigint<5>(mul_ln1118_40_fu_53087_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_410_fu_60880_p0() {
    mul_ln1118_410_fu_60880_p0 =  (sc_lv<12>) (sext_ln1116_10_cast_fu_52553_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_410_fu_60880_p1() {
    mul_ln1118_410_fu_60880_p1 = tmp_410_reg_98607.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_410_fu_60880_p2() {
    mul_ln1118_410_fu_60880_p2 = (!mul_ln1118_410_fu_60880_p0.read().is_01() || !mul_ln1118_410_fu_60880_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_410_fu_60880_p0.read()) * sc_bigint<5>(mul_ln1118_410_fu_60880_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_411_fu_60899_p0() {
    mul_ln1118_411_fu_60899_p0 =  (sc_lv<12>) (sext_ln1116_11_cast_fu_52575_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_411_fu_60899_p1() {
    mul_ln1118_411_fu_60899_p1 = tmp_411_reg_98612.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_411_fu_60899_p2() {
    mul_ln1118_411_fu_60899_p2 = (!mul_ln1118_411_fu_60899_p0.read().is_01() || !mul_ln1118_411_fu_60899_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_411_fu_60899_p0.read()) * sc_bigint<5>(mul_ln1118_411_fu_60899_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_412_fu_60918_p0() {
    mul_ln1118_412_fu_60918_p0 =  (sc_lv<12>) (sext_ln1116_12_cast_fu_52597_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_412_fu_60918_p1() {
    mul_ln1118_412_fu_60918_p1 = tmp_412_reg_98617.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_412_fu_60918_p2() {
    mul_ln1118_412_fu_60918_p2 = (!mul_ln1118_412_fu_60918_p0.read().is_01() || !mul_ln1118_412_fu_60918_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_412_fu_60918_p0.read()) * sc_bigint<5>(mul_ln1118_412_fu_60918_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_413_fu_60937_p0() {
    mul_ln1118_413_fu_60937_p0 =  (sc_lv<12>) (sext_ln1116_13_cast_fu_52619_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_413_fu_60937_p1() {
    mul_ln1118_413_fu_60937_p1 = tmp_413_reg_98622.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_413_fu_60937_p2() {
    mul_ln1118_413_fu_60937_p2 = (!mul_ln1118_413_fu_60937_p0.read().is_01() || !mul_ln1118_413_fu_60937_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_413_fu_60937_p0.read()) * sc_bigint<5>(mul_ln1118_413_fu_60937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_414_fu_60956_p0() {
    mul_ln1118_414_fu_60956_p0 =  (sc_lv<12>) (sext_ln1116_14_cast_fu_52641_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_414_fu_60956_p1() {
    mul_ln1118_414_fu_60956_p1 = tmp_414_reg_98627.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_414_fu_60956_p2() {
    mul_ln1118_414_fu_60956_p2 = (!mul_ln1118_414_fu_60956_p0.read().is_01() || !mul_ln1118_414_fu_60956_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_414_fu_60956_p0.read()) * sc_bigint<5>(mul_ln1118_414_fu_60956_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_415_fu_60975_p0() {
    mul_ln1118_415_fu_60975_p0 =  (sc_lv<12>) (sext_ln1116_15_cast_fu_52663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_415_fu_60975_p1() {
    mul_ln1118_415_fu_60975_p1 = tmp_415_reg_98632.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_415_fu_60975_p2() {
    mul_ln1118_415_fu_60975_p2 = (!mul_ln1118_415_fu_60975_p0.read().is_01() || !mul_ln1118_415_fu_60975_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_415_fu_60975_p0.read()) * sc_bigint<5>(mul_ln1118_415_fu_60975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_416_fu_60994_p0() {
    mul_ln1118_416_fu_60994_p0 =  (sc_lv<12>) (sext_ln1116_16_cast_fu_52685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_416_fu_60994_p1() {
    mul_ln1118_416_fu_60994_p1 = tmp_416_reg_98637.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_416_fu_60994_p2() {
    mul_ln1118_416_fu_60994_p2 = (!mul_ln1118_416_fu_60994_p0.read().is_01() || !mul_ln1118_416_fu_60994_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_416_fu_60994_p0.read()) * sc_bigint<5>(mul_ln1118_416_fu_60994_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_417_fu_61013_p0() {
    mul_ln1118_417_fu_61013_p0 =  (sc_lv<12>) (sext_ln1116_17_cast_fu_52707_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_417_fu_61013_p1() {
    mul_ln1118_417_fu_61013_p1 = tmp_417_reg_98642.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_417_fu_61013_p2() {
    mul_ln1118_417_fu_61013_p2 = (!mul_ln1118_417_fu_61013_p0.read().is_01() || !mul_ln1118_417_fu_61013_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_417_fu_61013_p0.read()) * sc_bigint<5>(mul_ln1118_417_fu_61013_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_418_fu_61032_p0() {
    mul_ln1118_418_fu_61032_p0 =  (sc_lv<12>) (sext_ln1116_18_cast_fu_52729_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_418_fu_61032_p1() {
    mul_ln1118_418_fu_61032_p1 = tmp_418_reg_98647.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_418_fu_61032_p2() {
    mul_ln1118_418_fu_61032_p2 = (!mul_ln1118_418_fu_61032_p0.read().is_01() || !mul_ln1118_418_fu_61032_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_418_fu_61032_p0.read()) * sc_bigint<5>(mul_ln1118_418_fu_61032_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_419_fu_61051_p0() {
    mul_ln1118_419_fu_61051_p0 =  (sc_lv<12>) (sext_ln1116_19_cast_fu_52751_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_419_fu_61051_p1() {
    mul_ln1118_419_fu_61051_p1 = tmp_419_reg_98652.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_419_fu_61051_p2() {
    mul_ln1118_419_fu_61051_p2 = (!mul_ln1118_419_fu_61051_p0.read().is_01() || !mul_ln1118_419_fu_61051_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_419_fu_61051_p0.read()) * sc_bigint<5>(mul_ln1118_419_fu_61051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_41_fu_53109_p0() {
    mul_ln1118_41_fu_53109_p0 =  (sc_lv<12>) (sext_ln1116_41_cast_fu_53103_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_41_fu_53109_p1() {
    mul_ln1118_41_fu_53109_p1 = tmp_41_reg_96040.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_41_fu_53109_p2() {
    mul_ln1118_41_fu_53109_p2 = (!mul_ln1118_41_fu_53109_p0.read().is_01() || !mul_ln1118_41_fu_53109_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_41_fu_53109_p0.read()) * sc_bigint<5>(mul_ln1118_41_fu_53109_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_420_fu_61070_p0() {
    mul_ln1118_420_fu_61070_p0 =  (sc_lv<12>) (sext_ln1116_20_cast_fu_52773_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_420_fu_61070_p1() {
    mul_ln1118_420_fu_61070_p1 = tmp_420_reg_98657.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_420_fu_61070_p2() {
    mul_ln1118_420_fu_61070_p2 = (!mul_ln1118_420_fu_61070_p0.read().is_01() || !mul_ln1118_420_fu_61070_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_420_fu_61070_p0.read()) * sc_bigint<5>(mul_ln1118_420_fu_61070_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_421_fu_61089_p0() {
    mul_ln1118_421_fu_61089_p0 =  (sc_lv<12>) (sext_ln1116_21_cast_fu_52795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_421_fu_61089_p1() {
    mul_ln1118_421_fu_61089_p1 = tmp_421_reg_98662.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_421_fu_61089_p2() {
    mul_ln1118_421_fu_61089_p2 = (!mul_ln1118_421_fu_61089_p0.read().is_01() || !mul_ln1118_421_fu_61089_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_421_fu_61089_p0.read()) * sc_bigint<5>(mul_ln1118_421_fu_61089_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_422_fu_61108_p0() {
    mul_ln1118_422_fu_61108_p0 =  (sc_lv<12>) (sext_ln1116_22_cast_fu_52817_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_422_fu_61108_p1() {
    mul_ln1118_422_fu_61108_p1 = tmp_422_reg_98667.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_422_fu_61108_p2() {
    mul_ln1118_422_fu_61108_p2 = (!mul_ln1118_422_fu_61108_p0.read().is_01() || !mul_ln1118_422_fu_61108_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_422_fu_61108_p0.read()) * sc_bigint<5>(mul_ln1118_422_fu_61108_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_423_fu_61127_p0() {
    mul_ln1118_423_fu_61127_p0 =  (sc_lv<12>) (sext_ln1116_23_cast_fu_52839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_423_fu_61127_p1() {
    mul_ln1118_423_fu_61127_p1 = tmp_423_reg_98672.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_423_fu_61127_p2() {
    mul_ln1118_423_fu_61127_p2 = (!mul_ln1118_423_fu_61127_p0.read().is_01() || !mul_ln1118_423_fu_61127_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_423_fu_61127_p0.read()) * sc_bigint<5>(mul_ln1118_423_fu_61127_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_424_fu_61146_p0() {
    mul_ln1118_424_fu_61146_p0 =  (sc_lv<12>) (sext_ln1116_24_cast_fu_52861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_424_fu_61146_p1() {
    mul_ln1118_424_fu_61146_p1 = tmp_424_reg_98677.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_424_fu_61146_p2() {
    mul_ln1118_424_fu_61146_p2 = (!mul_ln1118_424_fu_61146_p0.read().is_01() || !mul_ln1118_424_fu_61146_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_424_fu_61146_p0.read()) * sc_bigint<5>(mul_ln1118_424_fu_61146_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_425_fu_61165_p0() {
    mul_ln1118_425_fu_61165_p0 =  (sc_lv<12>) (sext_ln1116_25_cast_fu_52883_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_425_fu_61165_p1() {
    mul_ln1118_425_fu_61165_p1 = tmp_425_reg_98682.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_425_fu_61165_p2() {
    mul_ln1118_425_fu_61165_p2 = (!mul_ln1118_425_fu_61165_p0.read().is_01() || !mul_ln1118_425_fu_61165_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_425_fu_61165_p0.read()) * sc_bigint<5>(mul_ln1118_425_fu_61165_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_426_fu_61184_p0() {
    mul_ln1118_426_fu_61184_p0 =  (sc_lv<12>) (sext_ln1116_26_cast_fu_52905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_426_fu_61184_p1() {
    mul_ln1118_426_fu_61184_p1 = tmp_426_reg_98687.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_426_fu_61184_p2() {
    mul_ln1118_426_fu_61184_p2 = (!mul_ln1118_426_fu_61184_p0.read().is_01() || !mul_ln1118_426_fu_61184_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_426_fu_61184_p0.read()) * sc_bigint<5>(mul_ln1118_426_fu_61184_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_427_fu_61203_p0() {
    mul_ln1118_427_fu_61203_p0 =  (sc_lv<12>) (sext_ln1116_27_cast_fu_52927_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_427_fu_61203_p1() {
    mul_ln1118_427_fu_61203_p1 = tmp_427_reg_98692.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_427_fu_61203_p2() {
    mul_ln1118_427_fu_61203_p2 = (!mul_ln1118_427_fu_61203_p0.read().is_01() || !mul_ln1118_427_fu_61203_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_427_fu_61203_p0.read()) * sc_bigint<5>(mul_ln1118_427_fu_61203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_428_fu_29615_p0() {
    mul_ln1118_428_fu_29615_p0 =  (sc_lv<12>) (sext_ln1116_28_cast_fu_22199_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_428_fu_29615_p1() {
    mul_ln1118_428_fu_29615_p1 = tmp_428_fu_29601_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_428_fu_29615_p2() {
    mul_ln1118_428_fu_29615_p2 = (!mul_ln1118_428_fu_29615_p0.read().is_01() || !mul_ln1118_428_fu_29615_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_428_fu_29615_p0.read()) * sc_bigint<5>(mul_ln1118_428_fu_29615_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_429_fu_29645_p0() {
    mul_ln1118_429_fu_29645_p0 =  (sc_lv<12>) (sext_ln1116_29_cast_fu_22241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_429_fu_29645_p1() {
    mul_ln1118_429_fu_29645_p1 = tmp_429_fu_29631_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_429_fu_29645_p2() {
    mul_ln1118_429_fu_29645_p2 = (!mul_ln1118_429_fu_29645_p0.read().is_01() || !mul_ln1118_429_fu_29645_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_429_fu_29645_p0.read()) * sc_bigint<5>(mul_ln1118_429_fu_29645_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_42_fu_53131_p0() {
    mul_ln1118_42_fu_53131_p0 =  (sc_lv<12>) (sext_ln1116_42_cast_fu_53125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_42_fu_53131_p1() {
    mul_ln1118_42_fu_53131_p1 = tmp_42_reg_96050.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_42_fu_53131_p2() {
    mul_ln1118_42_fu_53131_p2 = (!mul_ln1118_42_fu_53131_p0.read().is_01() || !mul_ln1118_42_fu_53131_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_42_fu_53131_p0.read()) * sc_bigint<5>(mul_ln1118_42_fu_53131_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_430_fu_29675_p0() {
    mul_ln1118_430_fu_29675_p0 =  (sc_lv<12>) (sext_ln1116_30_cast_fu_22283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_430_fu_29675_p1() {
    mul_ln1118_430_fu_29675_p1 = tmp_430_fu_29661_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_430_fu_29675_p2() {
    mul_ln1118_430_fu_29675_p2 = (!mul_ln1118_430_fu_29675_p0.read().is_01() || !mul_ln1118_430_fu_29675_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_430_fu_29675_p0.read()) * sc_bigint<5>(mul_ln1118_430_fu_29675_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_431_fu_29705_p0() {
    mul_ln1118_431_fu_29705_p0 =  (sc_lv<12>) (sext_ln1116_31_cast_fu_22325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_431_fu_29705_p1() {
    mul_ln1118_431_fu_29705_p1 = tmp_431_fu_29691_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_431_fu_29705_p2() {
    mul_ln1118_431_fu_29705_p2 = (!mul_ln1118_431_fu_29705_p0.read().is_01() || !mul_ln1118_431_fu_29705_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_431_fu_29705_p0.read()) * sc_bigint<5>(mul_ln1118_431_fu_29705_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_432_fu_29735_p0() {
    mul_ln1118_432_fu_29735_p0 =  (sc_lv<12>) (sext_ln1116_32_cast_fu_22367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_432_fu_29735_p1() {
    mul_ln1118_432_fu_29735_p1 = tmp_432_fu_29721_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_432_fu_29735_p2() {
    mul_ln1118_432_fu_29735_p2 = (!mul_ln1118_432_fu_29735_p0.read().is_01() || !mul_ln1118_432_fu_29735_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_432_fu_29735_p0.read()) * sc_bigint<5>(mul_ln1118_432_fu_29735_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_433_fu_29765_p0() {
    mul_ln1118_433_fu_29765_p0 =  (sc_lv<12>) (sext_ln1116_33_cast_fu_22409_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_433_fu_29765_p1() {
    mul_ln1118_433_fu_29765_p1 = tmp_433_fu_29751_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_433_fu_29765_p2() {
    mul_ln1118_433_fu_29765_p2 = (!mul_ln1118_433_fu_29765_p0.read().is_01() || !mul_ln1118_433_fu_29765_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_433_fu_29765_p0.read()) * sc_bigint<5>(mul_ln1118_433_fu_29765_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_434_fu_61222_p0() {
    mul_ln1118_434_fu_61222_p0 =  (sc_lv<12>) (sext_ln1116_34_cast_fu_52949_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_434_fu_61222_p1() {
    mul_ln1118_434_fu_61222_p1 = tmp_434_reg_98727.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_434_fu_61222_p2() {
    mul_ln1118_434_fu_61222_p2 = (!mul_ln1118_434_fu_61222_p0.read().is_01() || !mul_ln1118_434_fu_61222_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_434_fu_61222_p0.read()) * sc_bigint<5>(mul_ln1118_434_fu_61222_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_435_fu_61241_p0() {
    mul_ln1118_435_fu_61241_p0 =  (sc_lv<12>) (sext_ln1116_35_cast_fu_52971_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_435_fu_61241_p1() {
    mul_ln1118_435_fu_61241_p1 = tmp_435_reg_98732.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_435_fu_61241_p2() {
    mul_ln1118_435_fu_61241_p2 = (!mul_ln1118_435_fu_61241_p0.read().is_01() || !mul_ln1118_435_fu_61241_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_435_fu_61241_p0.read()) * sc_bigint<5>(mul_ln1118_435_fu_61241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_436_fu_61260_p0() {
    mul_ln1118_436_fu_61260_p0 =  (sc_lv<12>) (sext_ln1116_36_cast_fu_52993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_436_fu_61260_p1() {
    mul_ln1118_436_fu_61260_p1 = tmp_436_reg_98737.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_436_fu_61260_p2() {
    mul_ln1118_436_fu_61260_p2 = (!mul_ln1118_436_fu_61260_p0.read().is_01() || !mul_ln1118_436_fu_61260_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_436_fu_61260_p0.read()) * sc_bigint<5>(mul_ln1118_436_fu_61260_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_437_fu_61279_p0() {
    mul_ln1118_437_fu_61279_p0 =  (sc_lv<12>) (sext_ln1116_37_cast_fu_53015_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_437_fu_61279_p1() {
    mul_ln1118_437_fu_61279_p1 = tmp_437_reg_98742.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_437_fu_61279_p2() {
    mul_ln1118_437_fu_61279_p2 = (!mul_ln1118_437_fu_61279_p0.read().is_01() || !mul_ln1118_437_fu_61279_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_437_fu_61279_p0.read()) * sc_bigint<5>(mul_ln1118_437_fu_61279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_438_fu_61298_p0() {
    mul_ln1118_438_fu_61298_p0 =  (sc_lv<12>) (sext_ln1116_38_cast_fu_53037_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_438_fu_61298_p1() {
    mul_ln1118_438_fu_61298_p1 = tmp_438_reg_98747.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_438_fu_61298_p2() {
    mul_ln1118_438_fu_61298_p2 = (!mul_ln1118_438_fu_61298_p0.read().is_01() || !mul_ln1118_438_fu_61298_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_438_fu_61298_p0.read()) * sc_bigint<5>(mul_ln1118_438_fu_61298_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_439_fu_61317_p0() {
    mul_ln1118_439_fu_61317_p0 =  (sc_lv<12>) (sext_ln1116_39_cast_fu_53059_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_439_fu_61317_p1() {
    mul_ln1118_439_fu_61317_p1 = tmp_439_reg_98752.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_439_fu_61317_p2() {
    mul_ln1118_439_fu_61317_p2 = (!mul_ln1118_439_fu_61317_p0.read().is_01() || !mul_ln1118_439_fu_61317_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_439_fu_61317_p0.read()) * sc_bigint<5>(mul_ln1118_439_fu_61317_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_43_fu_53153_p0() {
    mul_ln1118_43_fu_53153_p0 =  (sc_lv<12>) (sext_ln1116_43_cast_fu_53147_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_43_fu_53153_p1() {
    mul_ln1118_43_fu_53153_p1 = tmp_43_reg_96060.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_43_fu_53153_p2() {
    mul_ln1118_43_fu_53153_p2 = (!mul_ln1118_43_fu_53153_p0.read().is_01() || !mul_ln1118_43_fu_53153_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_43_fu_53153_p0.read()) * sc_bigint<5>(mul_ln1118_43_fu_53153_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_440_fu_61336_p0() {
    mul_ln1118_440_fu_61336_p0 =  (sc_lv<12>) (sext_ln1116_40_cast_fu_53081_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_440_fu_61336_p1() {
    mul_ln1118_440_fu_61336_p1 = tmp_440_reg_98757.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_440_fu_61336_p2() {
    mul_ln1118_440_fu_61336_p2 = (!mul_ln1118_440_fu_61336_p0.read().is_01() || !mul_ln1118_440_fu_61336_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_440_fu_61336_p0.read()) * sc_bigint<5>(mul_ln1118_440_fu_61336_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_441_fu_61355_p0() {
    mul_ln1118_441_fu_61355_p0 =  (sc_lv<12>) (sext_ln1116_41_cast_fu_53103_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_441_fu_61355_p1() {
    mul_ln1118_441_fu_61355_p1 = tmp_441_reg_98762.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_441_fu_61355_p2() {
    mul_ln1118_441_fu_61355_p2 = (!mul_ln1118_441_fu_61355_p0.read().is_01() || !mul_ln1118_441_fu_61355_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_441_fu_61355_p0.read()) * sc_bigint<5>(mul_ln1118_441_fu_61355_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_442_fu_61374_p0() {
    mul_ln1118_442_fu_61374_p0 =  (sc_lv<12>) (sext_ln1116_42_cast_fu_53125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_442_fu_61374_p1() {
    mul_ln1118_442_fu_61374_p1 = tmp_442_reg_98767.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_442_fu_61374_p2() {
    mul_ln1118_442_fu_61374_p2 = (!mul_ln1118_442_fu_61374_p0.read().is_01() || !mul_ln1118_442_fu_61374_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_442_fu_61374_p0.read()) * sc_bigint<5>(mul_ln1118_442_fu_61374_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_443_fu_61393_p0() {
    mul_ln1118_443_fu_61393_p0 =  (sc_lv<12>) (sext_ln1116_43_cast_fu_53147_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_443_fu_61393_p1() {
    mul_ln1118_443_fu_61393_p1 = tmp_443_reg_98772.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_443_fu_61393_p2() {
    mul_ln1118_443_fu_61393_p2 = (!mul_ln1118_443_fu_61393_p0.read().is_01() || !mul_ln1118_443_fu_61393_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_443_fu_61393_p0.read()) * sc_bigint<5>(mul_ln1118_443_fu_61393_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_444_fu_61412_p0() {
    mul_ln1118_444_fu_61412_p0 =  (sc_lv<12>) (sext_ln1116_44_cast_fu_53169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_444_fu_61412_p1() {
    mul_ln1118_444_fu_61412_p1 = tmp_444_reg_98777.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_444_fu_61412_p2() {
    mul_ln1118_444_fu_61412_p2 = (!mul_ln1118_444_fu_61412_p0.read().is_01() || !mul_ln1118_444_fu_61412_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_444_fu_61412_p0.read()) * sc_bigint<5>(mul_ln1118_444_fu_61412_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_445_fu_61431_p0() {
    mul_ln1118_445_fu_61431_p0 =  (sc_lv<12>) (sext_ln1116_45_cast_fu_53191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_445_fu_61431_p1() {
    mul_ln1118_445_fu_61431_p1 = tmp_445_reg_98782.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_445_fu_61431_p2() {
    mul_ln1118_445_fu_61431_p2 = (!mul_ln1118_445_fu_61431_p0.read().is_01() || !mul_ln1118_445_fu_61431_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_445_fu_61431_p0.read()) * sc_bigint<5>(mul_ln1118_445_fu_61431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_446_fu_61450_p0() {
    mul_ln1118_446_fu_61450_p0 =  (sc_lv<12>) (sext_ln1116_46_cast_fu_53213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_446_fu_61450_p1() {
    mul_ln1118_446_fu_61450_p1 = tmp_446_reg_98787.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_446_fu_61450_p2() {
    mul_ln1118_446_fu_61450_p2 = (!mul_ln1118_446_fu_61450_p0.read().is_01() || !mul_ln1118_446_fu_61450_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_446_fu_61450_p0.read()) * sc_bigint<5>(mul_ln1118_446_fu_61450_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_447_fu_61469_p0() {
    mul_ln1118_447_fu_61469_p0 =  (sc_lv<12>) (sext_ln1116_47_cast_fu_53235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_447_fu_61469_p1() {
    mul_ln1118_447_fu_61469_p1 = tmp_447_reg_98792.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_447_fu_61469_p2() {
    mul_ln1118_447_fu_61469_p2 = (!mul_ln1118_447_fu_61469_p0.read().is_01() || !mul_ln1118_447_fu_61469_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_447_fu_61469_p0.read()) * sc_bigint<5>(mul_ln1118_447_fu_61469_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_448_fu_61488_p0() {
    mul_ln1118_448_fu_61488_p0 =  (sc_lv<12>) (sext_ln1116_48_cast_fu_53257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_448_fu_61488_p1() {
    mul_ln1118_448_fu_61488_p1 = tmp_448_reg_98797.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_448_fu_61488_p2() {
    mul_ln1118_448_fu_61488_p2 = (!mul_ln1118_448_fu_61488_p0.read().is_01() || !mul_ln1118_448_fu_61488_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_448_fu_61488_p0.read()) * sc_bigint<5>(mul_ln1118_448_fu_61488_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_449_fu_61507_p0() {
    mul_ln1118_449_fu_61507_p0 =  (sc_lv<12>) (sext_ln1116_49_cast_fu_53279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_449_fu_61507_p1() {
    mul_ln1118_449_fu_61507_p1 = tmp_449_reg_98802.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_449_fu_61507_p2() {
    mul_ln1118_449_fu_61507_p2 = (!mul_ln1118_449_fu_61507_p0.read().is_01() || !mul_ln1118_449_fu_61507_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_449_fu_61507_p0.read()) * sc_bigint<5>(mul_ln1118_449_fu_61507_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_44_fu_53175_p0() {
    mul_ln1118_44_fu_53175_p0 =  (sc_lv<12>) (sext_ln1116_44_cast_fu_53169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_44_fu_53175_p1() {
    mul_ln1118_44_fu_53175_p1 = tmp_44_reg_96070.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_44_fu_53175_p2() {
    mul_ln1118_44_fu_53175_p2 = (!mul_ln1118_44_fu_53175_p0.read().is_01() || !mul_ln1118_44_fu_53175_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_44_fu_53175_p0.read()) * sc_bigint<5>(mul_ln1118_44_fu_53175_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_450_fu_61526_p0() {
    mul_ln1118_450_fu_61526_p0 =  (sc_lv<12>) (sext_ln1116_50_cast_fu_53301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_450_fu_61526_p1() {
    mul_ln1118_450_fu_61526_p1 = tmp_450_reg_98807.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_450_fu_61526_p2() {
    mul_ln1118_450_fu_61526_p2 = (!mul_ln1118_450_fu_61526_p0.read().is_01() || !mul_ln1118_450_fu_61526_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_450_fu_61526_p0.read()) * sc_bigint<5>(mul_ln1118_450_fu_61526_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_451_fu_61545_p0() {
    mul_ln1118_451_fu_61545_p0 =  (sc_lv<12>) (sext_ln1116_51_cast_fu_53323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_451_fu_61545_p1() {
    mul_ln1118_451_fu_61545_p1 = tmp_451_reg_98812.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_451_fu_61545_p2() {
    mul_ln1118_451_fu_61545_p2 = (!mul_ln1118_451_fu_61545_p0.read().is_01() || !mul_ln1118_451_fu_61545_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_451_fu_61545_p0.read()) * sc_bigint<5>(mul_ln1118_451_fu_61545_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_452_fu_61564_p0() {
    mul_ln1118_452_fu_61564_p0 =  (sc_lv<12>) (sext_ln1116_52_cast_reg_96150.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_452_fu_61564_p1() {
    mul_ln1118_452_fu_61564_p1 = tmp_452_reg_98817.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_452_fu_61564_p2() {
    mul_ln1118_452_fu_61564_p2 = (!mul_ln1118_452_fu_61564_p0.read().is_01() || !mul_ln1118_452_fu_61564_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_452_fu_61564_p0.read()) * sc_bigint<5>(mul_ln1118_452_fu_61564_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_453_fu_29985_p0() {
    mul_ln1118_453_fu_29985_p0 =  (sc_lv<12>) (sext_ln1116_53_cast_fu_22797_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_453_fu_29985_p1() {
    mul_ln1118_453_fu_29985_p1 = tmp_453_fu_29971_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_453_fu_29985_p2() {
    mul_ln1118_453_fu_29985_p2 = (!mul_ln1118_453_fu_29985_p0.read().is_01() || !mul_ln1118_453_fu_29985_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_453_fu_29985_p0.read()) * sc_bigint<5>(mul_ln1118_453_fu_29985_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_454_fu_30015_p0() {
    mul_ln1118_454_fu_30015_p0 =  (sc_lv<12>) (sext_ln1116_54_cast_fu_22839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_454_fu_30015_p1() {
    mul_ln1118_454_fu_30015_p1 = tmp_454_fu_30001_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_454_fu_30015_p2() {
    mul_ln1118_454_fu_30015_p2 = (!mul_ln1118_454_fu_30015_p0.read().is_01() || !mul_ln1118_454_fu_30015_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_454_fu_30015_p0.read()) * sc_bigint<5>(mul_ln1118_454_fu_30015_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_455_fu_30045_p0() {
    mul_ln1118_455_fu_30045_p0 =  (sc_lv<12>) (sext_ln1116_55_cast_fu_22881_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_455_fu_30045_p1() {
    mul_ln1118_455_fu_30045_p1 = tmp_455_fu_30031_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_455_fu_30045_p2() {
    mul_ln1118_455_fu_30045_p2 = (!mul_ln1118_455_fu_30045_p0.read().is_01() || !mul_ln1118_455_fu_30045_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_455_fu_30045_p0.read()) * sc_bigint<5>(mul_ln1118_455_fu_30045_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_456_fu_30075_p0() {
    mul_ln1118_456_fu_30075_p0 =  (sc_lv<12>) (sext_ln1116_56_cast_fu_22923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_456_fu_30075_p1() {
    mul_ln1118_456_fu_30075_p1 = tmp_456_fu_30061_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_456_fu_30075_p2() {
    mul_ln1118_456_fu_30075_p2 = (!mul_ln1118_456_fu_30075_p0.read().is_01() || !mul_ln1118_456_fu_30075_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_456_fu_30075_p0.read()) * sc_bigint<5>(mul_ln1118_456_fu_30075_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_457_fu_30105_p0() {
    mul_ln1118_457_fu_30105_p0 =  (sc_lv<12>) (sext_ln1116_57_cast_fu_22965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_457_fu_30105_p1() {
    mul_ln1118_457_fu_30105_p1 = tmp_457_fu_30091_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_457_fu_30105_p2() {
    mul_ln1118_457_fu_30105_p2 = (!mul_ln1118_457_fu_30105_p0.read().is_01() || !mul_ln1118_457_fu_30105_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_457_fu_30105_p0.read()) * sc_bigint<5>(mul_ln1118_457_fu_30105_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_458_fu_30135_p0() {
    mul_ln1118_458_fu_30135_p0 =  (sc_lv<12>) (sext_ln1116_58_cast_fu_23007_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_458_fu_30135_p1() {
    mul_ln1118_458_fu_30135_p1 = tmp_458_fu_30121_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_458_fu_30135_p2() {
    mul_ln1118_458_fu_30135_p2 = (!mul_ln1118_458_fu_30135_p0.read().is_01() || !mul_ln1118_458_fu_30135_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_458_fu_30135_p0.read()) * sc_bigint<5>(mul_ln1118_458_fu_30135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_459_fu_61582_p0() {
    mul_ln1118_459_fu_61582_p0 =  (sc_lv<12>) (sext_ln1116_59_cast_fu_53363_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_459_fu_61582_p1() {
    mul_ln1118_459_fu_61582_p1 = tmp_459_reg_98852.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_459_fu_61582_p2() {
    mul_ln1118_459_fu_61582_p2 = (!mul_ln1118_459_fu_61582_p0.read().is_01() || !mul_ln1118_459_fu_61582_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_459_fu_61582_p0.read()) * sc_bigint<5>(mul_ln1118_459_fu_61582_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_45_fu_53197_p0() {
    mul_ln1118_45_fu_53197_p0 =  (sc_lv<12>) (sext_ln1116_45_cast_fu_53191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_45_fu_53197_p1() {
    mul_ln1118_45_fu_53197_p1 = tmp_45_reg_96080.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_45_fu_53197_p2() {
    mul_ln1118_45_fu_53197_p2 = (!mul_ln1118_45_fu_53197_p0.read().is_01() || !mul_ln1118_45_fu_53197_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_45_fu_53197_p0.read()) * sc_bigint<5>(mul_ln1118_45_fu_53197_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_460_fu_61601_p0() {
    mul_ln1118_460_fu_61601_p0 =  (sc_lv<12>) (sext_ln1116_60_cast_fu_53385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_460_fu_61601_p1() {
    mul_ln1118_460_fu_61601_p1 = tmp_460_reg_98857.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_460_fu_61601_p2() {
    mul_ln1118_460_fu_61601_p2 = (!mul_ln1118_460_fu_61601_p0.read().is_01() || !mul_ln1118_460_fu_61601_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_460_fu_61601_p0.read()) * sc_bigint<5>(mul_ln1118_460_fu_61601_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_461_fu_61620_p0() {
    mul_ln1118_461_fu_61620_p0 =  (sc_lv<12>) (sext_ln1116_61_cast_fu_53407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_461_fu_61620_p1() {
    mul_ln1118_461_fu_61620_p1 = tmp_461_reg_98862.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_461_fu_61620_p2() {
    mul_ln1118_461_fu_61620_p2 = (!mul_ln1118_461_fu_61620_p0.read().is_01() || !mul_ln1118_461_fu_61620_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_461_fu_61620_p0.read()) * sc_bigint<5>(mul_ln1118_461_fu_61620_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_462_fu_61639_p0() {
    mul_ln1118_462_fu_61639_p0 =  (sc_lv<12>) (sext_ln1116_62_cast_fu_53429_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_462_fu_61639_p1() {
    mul_ln1118_462_fu_61639_p1 = tmp_462_reg_98867.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_462_fu_61639_p2() {
    mul_ln1118_462_fu_61639_p2 = (!mul_ln1118_462_fu_61639_p0.read().is_01() || !mul_ln1118_462_fu_61639_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_462_fu_61639_p0.read()) * sc_bigint<5>(mul_ln1118_462_fu_61639_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_463_fu_61658_p0() {
    mul_ln1118_463_fu_61658_p0 =  (sc_lv<12>) (sext_ln1116_63_cast_fu_53451_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_463_fu_61658_p1() {
    mul_ln1118_463_fu_61658_p1 = tmp_463_reg_98872.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_463_fu_61658_p2() {
    mul_ln1118_463_fu_61658_p2 = (!mul_ln1118_463_fu_61658_p0.read().is_01() || !mul_ln1118_463_fu_61658_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_463_fu_61658_p0.read()) * sc_bigint<5>(mul_ln1118_463_fu_61658_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_464_fu_61677_p0() {
    mul_ln1118_464_fu_61677_p0 =  (sc_lv<12>) (sext_ln1116_64_cast_fu_53473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_464_fu_61677_p1() {
    mul_ln1118_464_fu_61677_p1 = tmp_464_reg_98877.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_464_fu_61677_p2() {
    mul_ln1118_464_fu_61677_p2 = (!mul_ln1118_464_fu_61677_p0.read().is_01() || !mul_ln1118_464_fu_61677_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_464_fu_61677_p0.read()) * sc_bigint<5>(mul_ln1118_464_fu_61677_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_465_fu_61696_p0() {
    mul_ln1118_465_fu_61696_p0 =  (sc_lv<12>) (sext_ln1116_65_cast_fu_53495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_465_fu_61696_p1() {
    mul_ln1118_465_fu_61696_p1 = tmp_465_reg_98882.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_465_fu_61696_p2() {
    mul_ln1118_465_fu_61696_p2 = (!mul_ln1118_465_fu_61696_p0.read().is_01() || !mul_ln1118_465_fu_61696_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_465_fu_61696_p0.read()) * sc_bigint<5>(mul_ln1118_465_fu_61696_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_466_fu_61715_p0() {
    mul_ln1118_466_fu_61715_p0 =  (sc_lv<12>) (sext_ln1116_66_cast_fu_53517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_466_fu_61715_p1() {
    mul_ln1118_466_fu_61715_p1 = tmp_466_reg_98887.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_466_fu_61715_p2() {
    mul_ln1118_466_fu_61715_p2 = (!mul_ln1118_466_fu_61715_p0.read().is_01() || !mul_ln1118_466_fu_61715_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_466_fu_61715_p0.read()) * sc_bigint<5>(mul_ln1118_466_fu_61715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_467_fu_61734_p0() {
    mul_ln1118_467_fu_61734_p0 =  (sc_lv<12>) (sext_ln1116_67_cast_fu_53539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_467_fu_61734_p1() {
    mul_ln1118_467_fu_61734_p1 = tmp_467_reg_98892.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_467_fu_61734_p2() {
    mul_ln1118_467_fu_61734_p2 = (!mul_ln1118_467_fu_61734_p0.read().is_01() || !mul_ln1118_467_fu_61734_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_467_fu_61734_p0.read()) * sc_bigint<5>(mul_ln1118_467_fu_61734_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_468_fu_61753_p0() {
    mul_ln1118_468_fu_61753_p0 =  (sc_lv<12>) (sext_ln1116_68_cast_fu_53561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_468_fu_61753_p1() {
    mul_ln1118_468_fu_61753_p1 = tmp_468_reg_98897.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_468_fu_61753_p2() {
    mul_ln1118_468_fu_61753_p2 = (!mul_ln1118_468_fu_61753_p0.read().is_01() || !mul_ln1118_468_fu_61753_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_468_fu_61753_p0.read()) * sc_bigint<5>(mul_ln1118_468_fu_61753_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_469_fu_61772_p0() {
    mul_ln1118_469_fu_61772_p0 =  (sc_lv<12>) (sext_ln1116_69_cast_fu_53583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_469_fu_61772_p1() {
    mul_ln1118_469_fu_61772_p1 = tmp_469_reg_98902.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_469_fu_61772_p2() {
    mul_ln1118_469_fu_61772_p2 = (!mul_ln1118_469_fu_61772_p0.read().is_01() || !mul_ln1118_469_fu_61772_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_469_fu_61772_p0.read()) * sc_bigint<5>(mul_ln1118_469_fu_61772_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_46_fu_53219_p0() {
    mul_ln1118_46_fu_53219_p0 =  (sc_lv<12>) (sext_ln1116_46_cast_fu_53213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_46_fu_53219_p1() {
    mul_ln1118_46_fu_53219_p1 = tmp_46_reg_96090.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_46_fu_53219_p2() {
    mul_ln1118_46_fu_53219_p2 = (!mul_ln1118_46_fu_53219_p0.read().is_01() || !mul_ln1118_46_fu_53219_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_46_fu_53219_p0.read()) * sc_bigint<5>(mul_ln1118_46_fu_53219_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_470_fu_61791_p0() {
    mul_ln1118_470_fu_61791_p0 =  (sc_lv<12>) (sext_ln1116_70_cast_fu_53605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_470_fu_61791_p1() {
    mul_ln1118_470_fu_61791_p1 = tmp_470_reg_98907.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_470_fu_61791_p2() {
    mul_ln1118_470_fu_61791_p2 = (!mul_ln1118_470_fu_61791_p0.read().is_01() || !mul_ln1118_470_fu_61791_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_470_fu_61791_p0.read()) * sc_bigint<5>(mul_ln1118_470_fu_61791_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_471_fu_61810_p0() {
    mul_ln1118_471_fu_61810_p0 =  (sc_lv<12>) (sext_ln1116_71_cast_fu_53627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_471_fu_61810_p1() {
    mul_ln1118_471_fu_61810_p1 = tmp_471_reg_98912.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_471_fu_61810_p2() {
    mul_ln1118_471_fu_61810_p2 = (!mul_ln1118_471_fu_61810_p0.read().is_01() || !mul_ln1118_471_fu_61810_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_471_fu_61810_p0.read()) * sc_bigint<5>(mul_ln1118_471_fu_61810_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_472_fu_61829_p0() {
    mul_ln1118_472_fu_61829_p0 =  (sc_lv<12>) (sext_ln1116_72_cast_fu_53649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_472_fu_61829_p1() {
    mul_ln1118_472_fu_61829_p1 = tmp_472_reg_98917.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_472_fu_61829_p2() {
    mul_ln1118_472_fu_61829_p2 = (!mul_ln1118_472_fu_61829_p0.read().is_01() || !mul_ln1118_472_fu_61829_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_472_fu_61829_p0.read()) * sc_bigint<5>(mul_ln1118_472_fu_61829_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_473_fu_61848_p0() {
    mul_ln1118_473_fu_61848_p0 =  (sc_lv<12>) (sext_ln1116_73_cast_fu_53671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_473_fu_61848_p1() {
    mul_ln1118_473_fu_61848_p1 = tmp_473_reg_98922.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_473_fu_61848_p2() {
    mul_ln1118_473_fu_61848_p2 = (!mul_ln1118_473_fu_61848_p0.read().is_01() || !mul_ln1118_473_fu_61848_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_473_fu_61848_p0.read()) * sc_bigint<5>(mul_ln1118_473_fu_61848_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_474_fu_61867_p0() {
    mul_ln1118_474_fu_61867_p0 =  (sc_lv<12>) (sext_ln1116_74_cast_fu_53693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_474_fu_61867_p1() {
    mul_ln1118_474_fu_61867_p1 = tmp_474_reg_98927.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_474_fu_61867_p2() {
    mul_ln1118_474_fu_61867_p2 = (!mul_ln1118_474_fu_61867_p0.read().is_01() || !mul_ln1118_474_fu_61867_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_474_fu_61867_p0.read()) * sc_bigint<5>(mul_ln1118_474_fu_61867_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_475_fu_61886_p0() {
    mul_ln1118_475_fu_61886_p0 =  (sc_lv<12>) (sext_ln1116_75_cast_fu_53715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_475_fu_61886_p1() {
    mul_ln1118_475_fu_61886_p1 = tmp_475_reg_98932.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_475_fu_61886_p2() {
    mul_ln1118_475_fu_61886_p2 = (!mul_ln1118_475_fu_61886_p0.read().is_01() || !mul_ln1118_475_fu_61886_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_475_fu_61886_p0.read()) * sc_bigint<5>(mul_ln1118_475_fu_61886_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_476_fu_61905_p0() {
    mul_ln1118_476_fu_61905_p0 =  (sc_lv<12>) (sext_ln1116_76_cast_fu_53737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_476_fu_61905_p1() {
    mul_ln1118_476_fu_61905_p1 = tmp_476_reg_98937.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_476_fu_61905_p2() {
    mul_ln1118_476_fu_61905_p2 = (!mul_ln1118_476_fu_61905_p0.read().is_01() || !mul_ln1118_476_fu_61905_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_476_fu_61905_p0.read()) * sc_bigint<5>(mul_ln1118_476_fu_61905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_477_fu_61924_p0() {
    mul_ln1118_477_fu_61924_p0 =  (sc_lv<12>) (sext_ln1116_77_cast_reg_96378.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_477_fu_61924_p1() {
    mul_ln1118_477_fu_61924_p1 = tmp_477_reg_98942.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_477_fu_61924_p2() {
    mul_ln1118_477_fu_61924_p2 = (!mul_ln1118_477_fu_61924_p0.read().is_01() || !mul_ln1118_477_fu_61924_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_477_fu_61924_p0.read()) * sc_bigint<5>(mul_ln1118_477_fu_61924_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_478_fu_30355_p0() {
    mul_ln1118_478_fu_30355_p0 =  (sc_lv<12>) (sext_ln1116_78_cast_fu_23395_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_478_fu_30355_p1() {
    mul_ln1118_478_fu_30355_p1 = tmp_478_fu_30341_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_478_fu_30355_p2() {
    mul_ln1118_478_fu_30355_p2 = (!mul_ln1118_478_fu_30355_p0.read().is_01() || !mul_ln1118_478_fu_30355_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_478_fu_30355_p0.read()) * sc_bigint<5>(mul_ln1118_478_fu_30355_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_479_fu_30385_p0() {
    mul_ln1118_479_fu_30385_p0 =  (sc_lv<12>) (sext_ln1116_79_cast_fu_23437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_479_fu_30385_p1() {
    mul_ln1118_479_fu_30385_p1 = tmp_479_fu_30371_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_479_fu_30385_p2() {
    mul_ln1118_479_fu_30385_p2 = (!mul_ln1118_479_fu_30385_p0.read().is_01() || !mul_ln1118_479_fu_30385_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_479_fu_30385_p0.read()) * sc_bigint<5>(mul_ln1118_479_fu_30385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_47_fu_53241_p0() {
    mul_ln1118_47_fu_53241_p0 =  (sc_lv<12>) (sext_ln1116_47_cast_fu_53235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_47_fu_53241_p1() {
    mul_ln1118_47_fu_53241_p1 = tmp_47_reg_96100.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_47_fu_53241_p2() {
    mul_ln1118_47_fu_53241_p2 = (!mul_ln1118_47_fu_53241_p0.read().is_01() || !mul_ln1118_47_fu_53241_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_47_fu_53241_p0.read()) * sc_bigint<5>(mul_ln1118_47_fu_53241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_480_fu_30415_p0() {
    mul_ln1118_480_fu_30415_p0 =  (sc_lv<12>) (sext_ln1116_80_cast_fu_23479_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_480_fu_30415_p1() {
    mul_ln1118_480_fu_30415_p1 = tmp_480_fu_30401_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_480_fu_30415_p2() {
    mul_ln1118_480_fu_30415_p2 = (!mul_ln1118_480_fu_30415_p0.read().is_01() || !mul_ln1118_480_fu_30415_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_480_fu_30415_p0.read()) * sc_bigint<5>(mul_ln1118_480_fu_30415_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_481_fu_30445_p0() {
    mul_ln1118_481_fu_30445_p0 =  (sc_lv<12>) (sext_ln1116_81_cast_fu_23521_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_481_fu_30445_p1() {
    mul_ln1118_481_fu_30445_p1 = tmp_481_fu_30431_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_481_fu_30445_p2() {
    mul_ln1118_481_fu_30445_p2 = (!mul_ln1118_481_fu_30445_p0.read().is_01() || !mul_ln1118_481_fu_30445_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_481_fu_30445_p0.read()) * sc_bigint<5>(mul_ln1118_481_fu_30445_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_482_fu_30475_p0() {
    mul_ln1118_482_fu_30475_p0 =  (sc_lv<12>) (sext_ln1116_82_cast_fu_23563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_482_fu_30475_p1() {
    mul_ln1118_482_fu_30475_p1 = tmp_482_fu_30461_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_482_fu_30475_p2() {
    mul_ln1118_482_fu_30475_p2 = (!mul_ln1118_482_fu_30475_p0.read().is_01() || !mul_ln1118_482_fu_30475_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_482_fu_30475_p0.read()) * sc_bigint<5>(mul_ln1118_482_fu_30475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_483_fu_30505_p0() {
    mul_ln1118_483_fu_30505_p0 =  (sc_lv<12>) (sext_ln1116_83_cast_fu_23605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_483_fu_30505_p1() {
    mul_ln1118_483_fu_30505_p1 = tmp_483_fu_30491_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_483_fu_30505_p2() {
    mul_ln1118_483_fu_30505_p2 = (!mul_ln1118_483_fu_30505_p0.read().is_01() || !mul_ln1118_483_fu_30505_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_483_fu_30505_p0.read()) * sc_bigint<5>(mul_ln1118_483_fu_30505_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_484_fu_61942_p0() {
    mul_ln1118_484_fu_61942_p0 =  (sc_lv<12>) (sext_ln1116_84_cast_fu_53777_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_484_fu_61942_p1() {
    mul_ln1118_484_fu_61942_p1 = tmp_484_reg_98977.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_484_fu_61942_p2() {
    mul_ln1118_484_fu_61942_p2 = (!mul_ln1118_484_fu_61942_p0.read().is_01() || !mul_ln1118_484_fu_61942_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_484_fu_61942_p0.read()) * sc_bigint<5>(mul_ln1118_484_fu_61942_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_485_fu_61961_p0() {
    mul_ln1118_485_fu_61961_p0 =  (sc_lv<12>) (sext_ln1116_85_cast_fu_53799_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_485_fu_61961_p1() {
    mul_ln1118_485_fu_61961_p1 = tmp_485_reg_98982.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_485_fu_61961_p2() {
    mul_ln1118_485_fu_61961_p2 = (!mul_ln1118_485_fu_61961_p0.read().is_01() || !mul_ln1118_485_fu_61961_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_485_fu_61961_p0.read()) * sc_bigint<5>(mul_ln1118_485_fu_61961_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_486_fu_61980_p0() {
    mul_ln1118_486_fu_61980_p0 =  (sc_lv<12>) (sext_ln1116_86_cast_fu_53821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_486_fu_61980_p1() {
    mul_ln1118_486_fu_61980_p1 = tmp_486_reg_98987.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_486_fu_61980_p2() {
    mul_ln1118_486_fu_61980_p2 = (!mul_ln1118_486_fu_61980_p0.read().is_01() || !mul_ln1118_486_fu_61980_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_486_fu_61980_p0.read()) * sc_bigint<5>(mul_ln1118_486_fu_61980_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_487_fu_61999_p0() {
    mul_ln1118_487_fu_61999_p0 =  (sc_lv<12>) (sext_ln1116_87_cast_fu_53843_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_487_fu_61999_p1() {
    mul_ln1118_487_fu_61999_p1 = tmp_487_reg_98992.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_487_fu_61999_p2() {
    mul_ln1118_487_fu_61999_p2 = (!mul_ln1118_487_fu_61999_p0.read().is_01() || !mul_ln1118_487_fu_61999_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_487_fu_61999_p0.read()) * sc_bigint<5>(mul_ln1118_487_fu_61999_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_488_fu_62018_p0() {
    mul_ln1118_488_fu_62018_p0 =  (sc_lv<12>) (sext_ln1116_88_cast_fu_53865_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_488_fu_62018_p1() {
    mul_ln1118_488_fu_62018_p1 = tmp_488_reg_98997.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_488_fu_62018_p2() {
    mul_ln1118_488_fu_62018_p2 = (!mul_ln1118_488_fu_62018_p0.read().is_01() || !mul_ln1118_488_fu_62018_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_488_fu_62018_p0.read()) * sc_bigint<5>(mul_ln1118_488_fu_62018_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_489_fu_62037_p0() {
    mul_ln1118_489_fu_62037_p0 =  (sc_lv<12>) (sext_ln1116_89_cast_fu_53887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_489_fu_62037_p1() {
    mul_ln1118_489_fu_62037_p1 = tmp_489_reg_99002.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_489_fu_62037_p2() {
    mul_ln1118_489_fu_62037_p2 = (!mul_ln1118_489_fu_62037_p0.read().is_01() || !mul_ln1118_489_fu_62037_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_489_fu_62037_p0.read()) * sc_bigint<5>(mul_ln1118_489_fu_62037_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_48_fu_53263_p0() {
    mul_ln1118_48_fu_53263_p0 =  (sc_lv<12>) (sext_ln1116_48_cast_fu_53257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_48_fu_53263_p1() {
    mul_ln1118_48_fu_53263_p1 = tmp_48_reg_96110.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_48_fu_53263_p2() {
    mul_ln1118_48_fu_53263_p2 = (!mul_ln1118_48_fu_53263_p0.read().is_01() || !mul_ln1118_48_fu_53263_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_48_fu_53263_p0.read()) * sc_bigint<5>(mul_ln1118_48_fu_53263_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_490_fu_62056_p0() {
    mul_ln1118_490_fu_62056_p0 =  (sc_lv<12>) (sext_ln1116_90_cast_fu_53909_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_490_fu_62056_p1() {
    mul_ln1118_490_fu_62056_p1 = tmp_490_reg_99007.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_490_fu_62056_p2() {
    mul_ln1118_490_fu_62056_p2 = (!mul_ln1118_490_fu_62056_p0.read().is_01() || !mul_ln1118_490_fu_62056_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_490_fu_62056_p0.read()) * sc_bigint<5>(mul_ln1118_490_fu_62056_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_491_fu_62075_p0() {
    mul_ln1118_491_fu_62075_p0 =  (sc_lv<12>) (sext_ln1116_91_cast_fu_53931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_491_fu_62075_p1() {
    mul_ln1118_491_fu_62075_p1 = tmp_491_reg_99012.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_491_fu_62075_p2() {
    mul_ln1118_491_fu_62075_p2 = (!mul_ln1118_491_fu_62075_p0.read().is_01() || !mul_ln1118_491_fu_62075_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_491_fu_62075_p0.read()) * sc_bigint<5>(mul_ln1118_491_fu_62075_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_492_fu_62094_p0() {
    mul_ln1118_492_fu_62094_p0 =  (sc_lv<12>) (sext_ln1116_92_cast_fu_53953_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_492_fu_62094_p1() {
    mul_ln1118_492_fu_62094_p1 = tmp_492_reg_99017.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_492_fu_62094_p2() {
    mul_ln1118_492_fu_62094_p2 = (!mul_ln1118_492_fu_62094_p0.read().is_01() || !mul_ln1118_492_fu_62094_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_492_fu_62094_p0.read()) * sc_bigint<5>(mul_ln1118_492_fu_62094_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_493_fu_62113_p0() {
    mul_ln1118_493_fu_62113_p0 =  (sc_lv<12>) (sext_ln1116_93_cast_fu_53975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_493_fu_62113_p1() {
    mul_ln1118_493_fu_62113_p1 = tmp_493_reg_99022.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_493_fu_62113_p2() {
    mul_ln1118_493_fu_62113_p2 = (!mul_ln1118_493_fu_62113_p0.read().is_01() || !mul_ln1118_493_fu_62113_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_493_fu_62113_p0.read()) * sc_bigint<5>(mul_ln1118_493_fu_62113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_494_fu_62132_p0() {
    mul_ln1118_494_fu_62132_p0 =  (sc_lv<12>) (sext_ln1116_94_cast_fu_53997_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_494_fu_62132_p1() {
    mul_ln1118_494_fu_62132_p1 = tmp_494_reg_99027.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_494_fu_62132_p2() {
    mul_ln1118_494_fu_62132_p2 = (!mul_ln1118_494_fu_62132_p0.read().is_01() || !mul_ln1118_494_fu_62132_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_494_fu_62132_p0.read()) * sc_bigint<5>(mul_ln1118_494_fu_62132_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_495_fu_62151_p0() {
    mul_ln1118_495_fu_62151_p0 =  (sc_lv<12>) (sext_ln1116_95_cast_fu_54019_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_495_fu_62151_p1() {
    mul_ln1118_495_fu_62151_p1 = tmp_495_reg_99032.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_495_fu_62151_p2() {
    mul_ln1118_495_fu_62151_p2 = (!mul_ln1118_495_fu_62151_p0.read().is_01() || !mul_ln1118_495_fu_62151_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_495_fu_62151_p0.read()) * sc_bigint<5>(mul_ln1118_495_fu_62151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_496_fu_62170_p0() {
    mul_ln1118_496_fu_62170_p0 =  (sc_lv<12>) (sext_ln1116_96_cast_fu_54041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_496_fu_62170_p1() {
    mul_ln1118_496_fu_62170_p1 = tmp_496_reg_99037.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_496_fu_62170_p2() {
    mul_ln1118_496_fu_62170_p2 = (!mul_ln1118_496_fu_62170_p0.read().is_01() || !mul_ln1118_496_fu_62170_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_496_fu_62170_p0.read()) * sc_bigint<5>(mul_ln1118_496_fu_62170_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_497_fu_62189_p0() {
    mul_ln1118_497_fu_62189_p0 =  (sc_lv<12>) (sext_ln1116_97_cast_fu_54063_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_497_fu_62189_p1() {
    mul_ln1118_497_fu_62189_p1 = tmp_497_reg_99042.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_497_fu_62189_p2() {
    mul_ln1118_497_fu_62189_p2 = (!mul_ln1118_497_fu_62189_p0.read().is_01() || !mul_ln1118_497_fu_62189_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_497_fu_62189_p0.read()) * sc_bigint<5>(mul_ln1118_497_fu_62189_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_498_fu_62208_p0() {
    mul_ln1118_498_fu_62208_p0 =  (sc_lv<12>) (sext_ln1116_98_cast_fu_54085_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_498_fu_62208_p1() {
    mul_ln1118_498_fu_62208_p1 = tmp_498_reg_99047.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_498_fu_62208_p2() {
    mul_ln1118_498_fu_62208_p2 = (!mul_ln1118_498_fu_62208_p0.read().is_01() || !mul_ln1118_498_fu_62208_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_498_fu_62208_p0.read()) * sc_bigint<5>(mul_ln1118_498_fu_62208_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_499_fu_62227_p0() {
    mul_ln1118_499_fu_62227_p0 =  (sc_lv<12>) (sext_ln1116_99_cast_fu_54107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_499_fu_62227_p1() {
    mul_ln1118_499_fu_62227_p1 = tmp_499_reg_99052.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_499_fu_62227_p2() {
    mul_ln1118_499_fu_62227_p2 = (!mul_ln1118_499_fu_62227_p0.read().is_01() || !mul_ln1118_499_fu_62227_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_499_fu_62227_p0.read()) * sc_bigint<5>(mul_ln1118_499_fu_62227_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_49_fu_53285_p0() {
    mul_ln1118_49_fu_53285_p0 =  (sc_lv<12>) (sext_ln1116_49_cast_fu_53279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_49_fu_53285_p1() {
    mul_ln1118_49_fu_53285_p1 = tmp_49_reg_96120.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_49_fu_53285_p2() {
    mul_ln1118_49_fu_53285_p2 = (!mul_ln1118_49_fu_53285_p0.read().is_01() || !mul_ln1118_49_fu_53285_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_49_fu_53285_p0.read()) * sc_bigint<5>(mul_ln1118_49_fu_53285_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_500_fu_62246_p0() {
    mul_ln1118_500_fu_62246_p0 =  (sc_lv<12>) (sext_ln1116_100_cast_fu_54129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_500_fu_62246_p1() {
    mul_ln1118_500_fu_62246_p1 = tmp_500_reg_99057.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_500_fu_62246_p2() {
    mul_ln1118_500_fu_62246_p2 = (!mul_ln1118_500_fu_62246_p0.read().is_01() || !mul_ln1118_500_fu_62246_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_500_fu_62246_p0.read()) * sc_bigint<5>(mul_ln1118_500_fu_62246_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_501_fu_62265_p0() {
    mul_ln1118_501_fu_62265_p0 =  (sc_lv<12>) (sext_ln1116_101_cast_fu_54151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_501_fu_62265_p1() {
    mul_ln1118_501_fu_62265_p1 = tmp_501_reg_99062.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_501_fu_62265_p2() {
    mul_ln1118_501_fu_62265_p2 = (!mul_ln1118_501_fu_62265_p0.read().is_01() || !mul_ln1118_501_fu_62265_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_501_fu_62265_p0.read()) * sc_bigint<5>(mul_ln1118_501_fu_62265_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_502_fu_62284_p0() {
    mul_ln1118_502_fu_62284_p0 =  (sc_lv<12>) (sext_ln1116_102_cast_reg_96606.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_502_fu_62284_p1() {
    mul_ln1118_502_fu_62284_p1 = tmp_502_reg_99067.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_502_fu_62284_p2() {
    mul_ln1118_502_fu_62284_p2 = (!mul_ln1118_502_fu_62284_p0.read().is_01() || !mul_ln1118_502_fu_62284_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_502_fu_62284_p0.read()) * sc_bigint<5>(mul_ln1118_502_fu_62284_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_503_fu_30725_p0() {
    mul_ln1118_503_fu_30725_p0 =  (sc_lv<12>) (sext_ln1116_103_cast_fu_23993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_503_fu_30725_p1() {
    mul_ln1118_503_fu_30725_p1 = tmp_503_fu_30711_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_503_fu_30725_p2() {
    mul_ln1118_503_fu_30725_p2 = (!mul_ln1118_503_fu_30725_p0.read().is_01() || !mul_ln1118_503_fu_30725_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_503_fu_30725_p0.read()) * sc_bigint<5>(mul_ln1118_503_fu_30725_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_504_fu_30755_p0() {
    mul_ln1118_504_fu_30755_p0 =  (sc_lv<12>) (sext_ln1116_104_cast_fu_24035_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_504_fu_30755_p1() {
    mul_ln1118_504_fu_30755_p1 = tmp_504_fu_30741_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_504_fu_30755_p2() {
    mul_ln1118_504_fu_30755_p2 = (!mul_ln1118_504_fu_30755_p0.read().is_01() || !mul_ln1118_504_fu_30755_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_504_fu_30755_p0.read()) * sc_bigint<5>(mul_ln1118_504_fu_30755_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_505_fu_30785_p0() {
    mul_ln1118_505_fu_30785_p0 =  (sc_lv<12>) (sext_ln1116_105_cast_fu_24077_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_505_fu_30785_p1() {
    mul_ln1118_505_fu_30785_p1 = tmp_505_fu_30771_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_505_fu_30785_p2() {
    mul_ln1118_505_fu_30785_p2 = (!mul_ln1118_505_fu_30785_p0.read().is_01() || !mul_ln1118_505_fu_30785_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_505_fu_30785_p0.read()) * sc_bigint<5>(mul_ln1118_505_fu_30785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_506_fu_30815_p0() {
    mul_ln1118_506_fu_30815_p0 =  (sc_lv<12>) (sext_ln1116_106_cast_fu_24119_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_506_fu_30815_p1() {
    mul_ln1118_506_fu_30815_p1 = tmp_506_fu_30801_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_506_fu_30815_p2() {
    mul_ln1118_506_fu_30815_p2 = (!mul_ln1118_506_fu_30815_p0.read().is_01() || !mul_ln1118_506_fu_30815_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_506_fu_30815_p0.read()) * sc_bigint<5>(mul_ln1118_506_fu_30815_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_507_fu_30845_p0() {
    mul_ln1118_507_fu_30845_p0 =  (sc_lv<12>) (sext_ln1116_107_cast_fu_24161_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_507_fu_30845_p1() {
    mul_ln1118_507_fu_30845_p1 = tmp_507_fu_30831_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_507_fu_30845_p2() {
    mul_ln1118_507_fu_30845_p2 = (!mul_ln1118_507_fu_30845_p0.read().is_01() || !mul_ln1118_507_fu_30845_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_507_fu_30845_p0.read()) * sc_bigint<5>(mul_ln1118_507_fu_30845_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_508_fu_30875_p0() {
    mul_ln1118_508_fu_30875_p0 =  (sc_lv<12>) (sext_ln1116_108_cast_fu_24203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_508_fu_30875_p1() {
    mul_ln1118_508_fu_30875_p1 = tmp_508_fu_30861_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_508_fu_30875_p2() {
    mul_ln1118_508_fu_30875_p2 = (!mul_ln1118_508_fu_30875_p0.read().is_01() || !mul_ln1118_508_fu_30875_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_508_fu_30875_p0.read()) * sc_bigint<5>(mul_ln1118_508_fu_30875_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_509_fu_62302_p0() {
    mul_ln1118_509_fu_62302_p0 =  (sc_lv<12>) (sext_ln1116_109_cast_fu_54191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_509_fu_62302_p1() {
    mul_ln1118_509_fu_62302_p1 = tmp_509_reg_99102.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_509_fu_62302_p2() {
    mul_ln1118_509_fu_62302_p2 = (!mul_ln1118_509_fu_62302_p0.read().is_01() || !mul_ln1118_509_fu_62302_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_509_fu_62302_p0.read()) * sc_bigint<5>(mul_ln1118_509_fu_62302_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_50_fu_53307_p0() {
    mul_ln1118_50_fu_53307_p0 =  (sc_lv<12>) (sext_ln1116_50_cast_fu_53301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_50_fu_53307_p1() {
    mul_ln1118_50_fu_53307_p1 = tmp_50_reg_96130.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_50_fu_53307_p2() {
    mul_ln1118_50_fu_53307_p2 = (!mul_ln1118_50_fu_53307_p0.read().is_01() || !mul_ln1118_50_fu_53307_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_50_fu_53307_p0.read()) * sc_bigint<5>(mul_ln1118_50_fu_53307_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_510_fu_62321_p0() {
    mul_ln1118_510_fu_62321_p0 =  (sc_lv<12>) (sext_ln1116_110_cast_fu_54213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_510_fu_62321_p1() {
    mul_ln1118_510_fu_62321_p1 = tmp_510_reg_99107.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_510_fu_62321_p2() {
    mul_ln1118_510_fu_62321_p2 = (!mul_ln1118_510_fu_62321_p0.read().is_01() || !mul_ln1118_510_fu_62321_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_510_fu_62321_p0.read()) * sc_bigint<5>(mul_ln1118_510_fu_62321_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_511_fu_62340_p0() {
    mul_ln1118_511_fu_62340_p0 =  (sc_lv<12>) (sext_ln1116_111_cast_fu_54235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_511_fu_62340_p1() {
    mul_ln1118_511_fu_62340_p1 = tmp_511_reg_99112.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_511_fu_62340_p2() {
    mul_ln1118_511_fu_62340_p2 = (!mul_ln1118_511_fu_62340_p0.read().is_01() || !mul_ln1118_511_fu_62340_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_511_fu_62340_p0.read()) * sc_bigint<5>(mul_ln1118_511_fu_62340_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_512_fu_62359_p0() {
    mul_ln1118_512_fu_62359_p0 =  (sc_lv<12>) (sext_ln1116_112_cast_fu_54257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_512_fu_62359_p1() {
    mul_ln1118_512_fu_62359_p1 = tmp_512_reg_99117.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_512_fu_62359_p2() {
    mul_ln1118_512_fu_62359_p2 = (!mul_ln1118_512_fu_62359_p0.read().is_01() || !mul_ln1118_512_fu_62359_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_512_fu_62359_p0.read()) * sc_bigint<5>(mul_ln1118_512_fu_62359_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_513_fu_62378_p0() {
    mul_ln1118_513_fu_62378_p0 =  (sc_lv<12>) (sext_ln1116_113_cast_fu_54279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_513_fu_62378_p1() {
    mul_ln1118_513_fu_62378_p1 = tmp_513_reg_99122.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_513_fu_62378_p2() {
    mul_ln1118_513_fu_62378_p2 = (!mul_ln1118_513_fu_62378_p0.read().is_01() || !mul_ln1118_513_fu_62378_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_513_fu_62378_p0.read()) * sc_bigint<5>(mul_ln1118_513_fu_62378_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_514_fu_62397_p0() {
    mul_ln1118_514_fu_62397_p0 =  (sc_lv<12>) (sext_ln1116_114_cast_fu_54301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_514_fu_62397_p1() {
    mul_ln1118_514_fu_62397_p1 = tmp_514_reg_99127.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_514_fu_62397_p2() {
    mul_ln1118_514_fu_62397_p2 = (!mul_ln1118_514_fu_62397_p0.read().is_01() || !mul_ln1118_514_fu_62397_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_514_fu_62397_p0.read()) * sc_bigint<5>(mul_ln1118_514_fu_62397_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_515_fu_62416_p0() {
    mul_ln1118_515_fu_62416_p0 =  (sc_lv<12>) (sext_ln1116_115_cast_fu_54323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_515_fu_62416_p1() {
    mul_ln1118_515_fu_62416_p1 = tmp_515_reg_99132.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_515_fu_62416_p2() {
    mul_ln1118_515_fu_62416_p2 = (!mul_ln1118_515_fu_62416_p0.read().is_01() || !mul_ln1118_515_fu_62416_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_515_fu_62416_p0.read()) * sc_bigint<5>(mul_ln1118_515_fu_62416_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_516_fu_62435_p0() {
    mul_ln1118_516_fu_62435_p0 =  (sc_lv<12>) (sext_ln1116_116_cast_fu_54345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_516_fu_62435_p1() {
    mul_ln1118_516_fu_62435_p1 = tmp_516_reg_99137.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_516_fu_62435_p2() {
    mul_ln1118_516_fu_62435_p2 = (!mul_ln1118_516_fu_62435_p0.read().is_01() || !mul_ln1118_516_fu_62435_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_516_fu_62435_p0.read()) * sc_bigint<5>(mul_ln1118_516_fu_62435_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_517_fu_62454_p0() {
    mul_ln1118_517_fu_62454_p0 =  (sc_lv<12>) (sext_ln1116_117_cast_fu_54367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_517_fu_62454_p1() {
    mul_ln1118_517_fu_62454_p1 = tmp_517_reg_99142.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_517_fu_62454_p2() {
    mul_ln1118_517_fu_62454_p2 = (!mul_ln1118_517_fu_62454_p0.read().is_01() || !mul_ln1118_517_fu_62454_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_517_fu_62454_p0.read()) * sc_bigint<5>(mul_ln1118_517_fu_62454_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_518_fu_62473_p0() {
    mul_ln1118_518_fu_62473_p0 =  (sc_lv<12>) (sext_ln1116_118_cast_fu_54389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_518_fu_62473_p1() {
    mul_ln1118_518_fu_62473_p1 = tmp_518_reg_99147.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_518_fu_62473_p2() {
    mul_ln1118_518_fu_62473_p2 = (!mul_ln1118_518_fu_62473_p0.read().is_01() || !mul_ln1118_518_fu_62473_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_518_fu_62473_p0.read()) * sc_bigint<5>(mul_ln1118_518_fu_62473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_519_fu_62492_p0() {
    mul_ln1118_519_fu_62492_p0 =  (sc_lv<12>) (sext_ln1116_119_cast_fu_54411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_519_fu_62492_p1() {
    mul_ln1118_519_fu_62492_p1 = tmp_519_reg_99152.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_519_fu_62492_p2() {
    mul_ln1118_519_fu_62492_p2 = (!mul_ln1118_519_fu_62492_p0.read().is_01() || !mul_ln1118_519_fu_62492_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_519_fu_62492_p0.read()) * sc_bigint<5>(mul_ln1118_519_fu_62492_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_51_fu_53329_p0() {
    mul_ln1118_51_fu_53329_p0 =  (sc_lv<12>) (sext_ln1116_51_cast_fu_53323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_51_fu_53329_p1() {
    mul_ln1118_51_fu_53329_p1 = tmp_51_reg_96140.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_51_fu_53329_p2() {
    mul_ln1118_51_fu_53329_p2 = (!mul_ln1118_51_fu_53329_p0.read().is_01() || !mul_ln1118_51_fu_53329_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_51_fu_53329_p0.read()) * sc_bigint<5>(mul_ln1118_51_fu_53329_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_520_fu_62511_p0() {
    mul_ln1118_520_fu_62511_p0 =  (sc_lv<12>) (sext_ln1116_120_cast_fu_54433_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_520_fu_62511_p1() {
    mul_ln1118_520_fu_62511_p1 = tmp_520_reg_99157.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_520_fu_62511_p2() {
    mul_ln1118_520_fu_62511_p2 = (!mul_ln1118_520_fu_62511_p0.read().is_01() || !mul_ln1118_520_fu_62511_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_520_fu_62511_p0.read()) * sc_bigint<5>(mul_ln1118_520_fu_62511_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_521_fu_62530_p0() {
    mul_ln1118_521_fu_62530_p0 =  (sc_lv<12>) (sext_ln1116_121_cast_fu_54455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_521_fu_62530_p1() {
    mul_ln1118_521_fu_62530_p1 = tmp_521_reg_99162.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_521_fu_62530_p2() {
    mul_ln1118_521_fu_62530_p2 = (!mul_ln1118_521_fu_62530_p0.read().is_01() || !mul_ln1118_521_fu_62530_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_521_fu_62530_p0.read()) * sc_bigint<5>(mul_ln1118_521_fu_62530_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_522_fu_62549_p0() {
    mul_ln1118_522_fu_62549_p0 =  (sc_lv<12>) (sext_ln1116_122_cast_fu_54477_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_522_fu_62549_p1() {
    mul_ln1118_522_fu_62549_p1 = tmp_522_reg_99167.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_522_fu_62549_p2() {
    mul_ln1118_522_fu_62549_p2 = (!mul_ln1118_522_fu_62549_p0.read().is_01() || !mul_ln1118_522_fu_62549_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_522_fu_62549_p0.read()) * sc_bigint<5>(mul_ln1118_522_fu_62549_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_523_fu_62568_p0() {
    mul_ln1118_523_fu_62568_p0 =  (sc_lv<12>) (sext_ln1116_123_cast_fu_54499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_523_fu_62568_p1() {
    mul_ln1118_523_fu_62568_p1 = tmp_523_reg_99172.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_523_fu_62568_p2() {
    mul_ln1118_523_fu_62568_p2 = (!mul_ln1118_523_fu_62568_p0.read().is_01() || !mul_ln1118_523_fu_62568_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_523_fu_62568_p0.read()) * sc_bigint<5>(mul_ln1118_523_fu_62568_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_524_fu_62587_p0() {
    mul_ln1118_524_fu_62587_p0 =  (sc_lv<12>) (sext_ln1116_124_cast_fu_54521_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_524_fu_62587_p1() {
    mul_ln1118_524_fu_62587_p1 = tmp_524_reg_99177.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_524_fu_62587_p2() {
    mul_ln1118_524_fu_62587_p2 = (!mul_ln1118_524_fu_62587_p0.read().is_01() || !mul_ln1118_524_fu_62587_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_524_fu_62587_p0.read()) * sc_bigint<5>(mul_ln1118_524_fu_62587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_525_fu_62606_p0() {
    mul_ln1118_525_fu_62606_p0 =  (sc_lv<12>) (sext_ln1116_125_cast_fu_54543_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_525_fu_62606_p1() {
    mul_ln1118_525_fu_62606_p1 = tmp_525_reg_99182.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_525_fu_62606_p2() {
    mul_ln1118_525_fu_62606_p2 = (!mul_ln1118_525_fu_62606_p0.read().is_01() || !mul_ln1118_525_fu_62606_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_525_fu_62606_p0.read()) * sc_bigint<5>(mul_ln1118_525_fu_62606_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_526_fu_62625_p0() {
    mul_ln1118_526_fu_62625_p0 =  (sc_lv<12>) (sext_ln1116_126_cast_fu_54565_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_526_fu_62625_p1() {
    mul_ln1118_526_fu_62625_p1 = tmp_526_reg_99187.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_526_fu_62625_p2() {
    mul_ln1118_526_fu_62625_p2 = (!mul_ln1118_526_fu_62625_p0.read().is_01() || !mul_ln1118_526_fu_62625_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_526_fu_62625_p0.read()) * sc_bigint<5>(mul_ln1118_526_fu_62625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_527_fu_62644_p0() {
    mul_ln1118_527_fu_62644_p0 =  (sc_lv<12>) (sext_ln1116_127_cast_fu_54587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_527_fu_62644_p1() {
    mul_ln1118_527_fu_62644_p1 = tmp_527_reg_99192.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_527_fu_62644_p2() {
    mul_ln1118_527_fu_62644_p2 = (!mul_ln1118_527_fu_62644_p0.read().is_01() || !mul_ln1118_527_fu_62644_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_527_fu_62644_p0.read()) * sc_bigint<5>(mul_ln1118_527_fu_62644_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_528_fu_62663_p0() {
    mul_ln1118_528_fu_62663_p0 =  (sc_lv<12>) (sext_ln1116_128_cast_fu_54609_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_528_fu_62663_p1() {
    mul_ln1118_528_fu_62663_p1 = tmp_528_reg_99197.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_528_fu_62663_p2() {
    mul_ln1118_528_fu_62663_p2 = (!mul_ln1118_528_fu_62663_p0.read().is_01() || !mul_ln1118_528_fu_62663_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_528_fu_62663_p0.read()) * sc_bigint<5>(mul_ln1118_528_fu_62663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_529_fu_62682_p0() {
    mul_ln1118_529_fu_62682_p0 =  (sc_lv<12>) (sext_ln1116_129_cast_fu_54631_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_529_fu_62682_p1() {
    mul_ln1118_529_fu_62682_p1 = tmp_529_reg_99202.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_529_fu_62682_p2() {
    mul_ln1118_529_fu_62682_p2 = (!mul_ln1118_529_fu_62682_p0.read().is_01() || !mul_ln1118_529_fu_62682_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_529_fu_62682_p0.read()) * sc_bigint<5>(mul_ln1118_529_fu_62682_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_52_fu_53348_p0() {
    mul_ln1118_52_fu_53348_p0 =  (sc_lv<12>) (sext_ln1116_52_cast_reg_96150.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_52_fu_53348_p1() {
    mul_ln1118_52_fu_53348_p1 = tmp_52_reg_96145.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_52_fu_53348_p2() {
    mul_ln1118_52_fu_53348_p2 = (!mul_ln1118_52_fu_53348_p0.read().is_01() || !mul_ln1118_52_fu_53348_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_52_fu_53348_p0.read()) * sc_bigint<5>(mul_ln1118_52_fu_53348_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_530_fu_62701_p0() {
    mul_ln1118_530_fu_62701_p0 =  (sc_lv<12>) (sext_ln1116_130_cast_fu_54653_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_530_fu_62701_p1() {
    mul_ln1118_530_fu_62701_p1 = tmp_530_reg_99207.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_530_fu_62701_p2() {
    mul_ln1118_530_fu_62701_p2 = (!mul_ln1118_530_fu_62701_p0.read().is_01() || !mul_ln1118_530_fu_62701_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_530_fu_62701_p0.read()) * sc_bigint<5>(mul_ln1118_530_fu_62701_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_531_fu_62720_p0() {
    mul_ln1118_531_fu_62720_p0 =  (sc_lv<12>) (sext_ln1116_131_cast_fu_54675_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_531_fu_62720_p1() {
    mul_ln1118_531_fu_62720_p1 = tmp_531_reg_99212.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_531_fu_62720_p2() {
    mul_ln1118_531_fu_62720_p2 = (!mul_ln1118_531_fu_62720_p0.read().is_01() || !mul_ln1118_531_fu_62720_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_531_fu_62720_p0.read()) * sc_bigint<5>(mul_ln1118_531_fu_62720_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_532_fu_31135_p0() {
    mul_ln1118_532_fu_31135_p0 =  (sc_lv<12>) (sext_ln1116_132_cast_fu_24659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_532_fu_31135_p1() {
    mul_ln1118_532_fu_31135_p1 = tmp_532_fu_31121_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_532_fu_31135_p2() {
    mul_ln1118_532_fu_31135_p2 = (!mul_ln1118_532_fu_31135_p0.read().is_01() || !mul_ln1118_532_fu_31135_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_532_fu_31135_p0.read()) * sc_bigint<5>(mul_ln1118_532_fu_31135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_533_fu_31165_p0() {
    mul_ln1118_533_fu_31165_p0 =  (sc_lv<12>) (sext_ln1116_133_cast_fu_24701_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_533_fu_31165_p1() {
    mul_ln1118_533_fu_31165_p1 = tmp_533_fu_31151_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_533_fu_31165_p2() {
    mul_ln1118_533_fu_31165_p2 = (!mul_ln1118_533_fu_31165_p0.read().is_01() || !mul_ln1118_533_fu_31165_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_533_fu_31165_p0.read()) * sc_bigint<5>(mul_ln1118_533_fu_31165_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_534_fu_62739_p0() {
    mul_ln1118_534_fu_62739_p0 =  (sc_lv<12>) (sext_ln1116_134_cast_fu_54697_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_534_fu_62739_p1() {
    mul_ln1118_534_fu_62739_p1 = tmp_534_reg_99227.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_534_fu_62739_p2() {
    mul_ln1118_534_fu_62739_p2 = (!mul_ln1118_534_fu_62739_p0.read().is_01() || !mul_ln1118_534_fu_62739_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_534_fu_62739_p0.read()) * sc_bigint<5>(mul_ln1118_534_fu_62739_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_535_fu_62758_p0() {
    mul_ln1118_535_fu_62758_p0 =  (sc_lv<12>) (sext_ln1116_135_cast_fu_54719_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_535_fu_62758_p1() {
    mul_ln1118_535_fu_62758_p1 = tmp_535_reg_99232.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_535_fu_62758_p2() {
    mul_ln1118_535_fu_62758_p2 = (!mul_ln1118_535_fu_62758_p0.read().is_01() || !mul_ln1118_535_fu_62758_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_535_fu_62758_p0.read()) * sc_bigint<5>(mul_ln1118_535_fu_62758_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_536_fu_62777_p0() {
    mul_ln1118_536_fu_62777_p0 =  (sc_lv<12>) (sext_ln1116_136_cast_fu_54741_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_536_fu_62777_p1() {
    mul_ln1118_536_fu_62777_p1 = tmp_536_reg_99237.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_536_fu_62777_p2() {
    mul_ln1118_536_fu_62777_p2 = (!mul_ln1118_536_fu_62777_p0.read().is_01() || !mul_ln1118_536_fu_62777_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_536_fu_62777_p0.read()) * sc_bigint<5>(mul_ln1118_536_fu_62777_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_537_fu_62796_p0() {
    mul_ln1118_537_fu_62796_p0 =  (sc_lv<12>) (sext_ln1116_137_cast_fu_54763_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_537_fu_62796_p1() {
    mul_ln1118_537_fu_62796_p1 = tmp_537_reg_99242.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_537_fu_62796_p2() {
    mul_ln1118_537_fu_62796_p2 = (!mul_ln1118_537_fu_62796_p0.read().is_01() || !mul_ln1118_537_fu_62796_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_537_fu_62796_p0.read()) * sc_bigint<5>(mul_ln1118_537_fu_62796_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_538_fu_62815_p0() {
    mul_ln1118_538_fu_62815_p0 =  (sc_lv<12>) (sext_ln1116_138_cast_fu_54785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_538_fu_62815_p1() {
    mul_ln1118_538_fu_62815_p1 = tmp_538_reg_99247.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_538_fu_62815_p2() {
    mul_ln1118_538_fu_62815_p2 = (!mul_ln1118_538_fu_62815_p0.read().is_01() || !mul_ln1118_538_fu_62815_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_538_fu_62815_p0.read()) * sc_bigint<5>(mul_ln1118_538_fu_62815_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_539_fu_62834_p0() {
    mul_ln1118_539_fu_62834_p0 =  (sc_lv<12>) (sext_ln1116_139_cast_fu_54807_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_539_fu_62834_p1() {
    mul_ln1118_539_fu_62834_p1 = tmp_539_reg_99252.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_539_fu_62834_p2() {
    mul_ln1118_539_fu_62834_p2 = (!mul_ln1118_539_fu_62834_p0.read().is_01() || !mul_ln1118_539_fu_62834_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_539_fu_62834_p0.read()) * sc_bigint<5>(mul_ln1118_539_fu_62834_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_53_fu_22805_p0() {
    mul_ln1118_53_fu_22805_p0 =  (sc_lv<12>) (sext_ln1116_53_cast_fu_22797_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_53_fu_22805_p1() {
    mul_ln1118_53_fu_22805_p1 = tmp_53_fu_22787_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_53_fu_22805_p2() {
    mul_ln1118_53_fu_22805_p2 = (!mul_ln1118_53_fu_22805_p0.read().is_01() || !mul_ln1118_53_fu_22805_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_53_fu_22805_p0.read()) * sc_bigint<5>(mul_ln1118_53_fu_22805_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_540_fu_62853_p0() {
    mul_ln1118_540_fu_62853_p0 =  (sc_lv<12>) (sext_ln1116_140_cast_fu_54829_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_540_fu_62853_p1() {
    mul_ln1118_540_fu_62853_p1 = tmp_540_reg_99257.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_540_fu_62853_p2() {
    mul_ln1118_540_fu_62853_p2 = (!mul_ln1118_540_fu_62853_p0.read().is_01() || !mul_ln1118_540_fu_62853_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_540_fu_62853_p0.read()) * sc_bigint<5>(mul_ln1118_540_fu_62853_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_541_fu_62872_p0() {
    mul_ln1118_541_fu_62872_p0 =  (sc_lv<12>) (sext_ln1116_141_cast_fu_54851_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_541_fu_62872_p1() {
    mul_ln1118_541_fu_62872_p1 = tmp_541_reg_99262.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_541_fu_62872_p2() {
    mul_ln1118_541_fu_62872_p2 = (!mul_ln1118_541_fu_62872_p0.read().is_01() || !mul_ln1118_541_fu_62872_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_541_fu_62872_p0.read()) * sc_bigint<5>(mul_ln1118_541_fu_62872_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_542_fu_62891_p0() {
    mul_ln1118_542_fu_62891_p0 =  (sc_lv<12>) (sext_ln1116_142_cast_fu_54873_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_542_fu_62891_p1() {
    mul_ln1118_542_fu_62891_p1 = tmp_542_reg_99267.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_542_fu_62891_p2() {
    mul_ln1118_542_fu_62891_p2 = (!mul_ln1118_542_fu_62891_p0.read().is_01() || !mul_ln1118_542_fu_62891_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_542_fu_62891_p0.read()) * sc_bigint<5>(mul_ln1118_542_fu_62891_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_543_fu_62910_p0() {
    mul_ln1118_543_fu_62910_p0 =  (sc_lv<12>) (sext_ln1116_143_cast_fu_54895_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_543_fu_62910_p1() {
    mul_ln1118_543_fu_62910_p1 = tmp_543_reg_99272.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_543_fu_62910_p2() {
    mul_ln1118_543_fu_62910_p2 = (!mul_ln1118_543_fu_62910_p0.read().is_01() || !mul_ln1118_543_fu_62910_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_543_fu_62910_p0.read()) * sc_bigint<5>(mul_ln1118_543_fu_62910_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_544_fu_62929_p0() {
    mul_ln1118_544_fu_62929_p0 =  (sc_lv<12>) (sext_ln1116_144_cast_fu_54917_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_544_fu_62929_p1() {
    mul_ln1118_544_fu_62929_p1 = tmp_544_reg_99277.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_544_fu_62929_p2() {
    mul_ln1118_544_fu_62929_p2 = (!mul_ln1118_544_fu_62929_p0.read().is_01() || !mul_ln1118_544_fu_62929_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_544_fu_62929_p0.read()) * sc_bigint<5>(mul_ln1118_544_fu_62929_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_545_fu_62948_p0() {
    mul_ln1118_545_fu_62948_p0 =  (sc_lv<12>) (sext_ln1116_145_cast_fu_54939_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_545_fu_62948_p1() {
    mul_ln1118_545_fu_62948_p1 = tmp_545_reg_99282.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_545_fu_62948_p2() {
    mul_ln1118_545_fu_62948_p2 = (!mul_ln1118_545_fu_62948_p0.read().is_01() || !mul_ln1118_545_fu_62948_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_545_fu_62948_p0.read()) * sc_bigint<5>(mul_ln1118_545_fu_62948_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_546_fu_62967_p0() {
    mul_ln1118_546_fu_62967_p0 =  (sc_lv<12>) (sext_ln1116_146_cast_fu_54961_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_546_fu_62967_p1() {
    mul_ln1118_546_fu_62967_p1 = tmp_546_reg_99287.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_546_fu_62967_p2() {
    mul_ln1118_546_fu_62967_p2 = (!mul_ln1118_546_fu_62967_p0.read().is_01() || !mul_ln1118_546_fu_62967_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_546_fu_62967_p0.read()) * sc_bigint<5>(mul_ln1118_546_fu_62967_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_547_fu_62986_p0() {
    mul_ln1118_547_fu_62986_p0 =  (sc_lv<12>) (sext_ln1116_147_cast_fu_54983_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_547_fu_62986_p1() {
    mul_ln1118_547_fu_62986_p1 = tmp_547_reg_99292.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_547_fu_62986_p2() {
    mul_ln1118_547_fu_62986_p2 = (!mul_ln1118_547_fu_62986_p0.read().is_01() || !mul_ln1118_547_fu_62986_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_547_fu_62986_p0.read()) * sc_bigint<5>(mul_ln1118_547_fu_62986_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_548_fu_63005_p0() {
    mul_ln1118_548_fu_63005_p0 =  (sc_lv<12>) (sext_ln1116_148_cast_fu_55005_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_548_fu_63005_p1() {
    mul_ln1118_548_fu_63005_p1 = tmp_548_reg_99297.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_548_fu_63005_p2() {
    mul_ln1118_548_fu_63005_p2 = (!mul_ln1118_548_fu_63005_p0.read().is_01() || !mul_ln1118_548_fu_63005_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_548_fu_63005_p0.read()) * sc_bigint<5>(mul_ln1118_548_fu_63005_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_549_fu_63024_p0() {
    mul_ln1118_549_fu_63024_p0 =  (sc_lv<12>) (sext_ln1116_149_cast_fu_55027_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_549_fu_63024_p1() {
    mul_ln1118_549_fu_63024_p1 = tmp_549_reg_99302.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_549_fu_63024_p2() {
    mul_ln1118_549_fu_63024_p2 = (!mul_ln1118_549_fu_63024_p0.read().is_01() || !mul_ln1118_549_fu_63024_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_549_fu_63024_p0.read()) * sc_bigint<5>(mul_ln1118_549_fu_63024_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_54_fu_22847_p0() {
    mul_ln1118_54_fu_22847_p0 =  (sc_lv<12>) (sext_ln1116_54_cast_fu_22839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_54_fu_22847_p1() {
    mul_ln1118_54_fu_22847_p1 = tmp_54_fu_22829_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_54_fu_22847_p2() {
    mul_ln1118_54_fu_22847_p2 = (!mul_ln1118_54_fu_22847_p0.read().is_01() || !mul_ln1118_54_fu_22847_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_54_fu_22847_p0.read()) * sc_bigint<5>(mul_ln1118_54_fu_22847_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_550_fu_63043_p0() {
    mul_ln1118_550_fu_63043_p0 =  (sc_lv<12>) (sext_ln1116_150_cast_fu_55049_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_550_fu_63043_p1() {
    mul_ln1118_550_fu_63043_p1 = tmp_550_reg_99307.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_550_fu_63043_p2() {
    mul_ln1118_550_fu_63043_p2 = (!mul_ln1118_550_fu_63043_p0.read().is_01() || !mul_ln1118_550_fu_63043_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_550_fu_63043_p0.read()) * sc_bigint<5>(mul_ln1118_550_fu_63043_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_551_fu_63062_p0() {
    mul_ln1118_551_fu_63062_p0 =  (sc_lv<12>) (sext_ln1116_151_cast_reg_97064.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_551_fu_63062_p1() {
    mul_ln1118_551_fu_63062_p1 = tmp_551_reg_99312.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_551_fu_63062_p2() {
    mul_ln1118_551_fu_63062_p2 = (!mul_ln1118_551_fu_63062_p0.read().is_01() || !mul_ln1118_551_fu_63062_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_551_fu_63062_p0.read()) * sc_bigint<5>(mul_ln1118_551_fu_63062_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_552_fu_63080_p0() {
    mul_ln1118_552_fu_63080_p0 =  (sc_lv<12>) (sext_ln1116_152_cast_reg_97082.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_552_fu_63080_p1() {
    mul_ln1118_552_fu_63080_p1 = tmp_552_reg_99317.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_552_fu_63080_p2() {
    mul_ln1118_552_fu_63080_p2 = (!mul_ln1118_552_fu_63080_p0.read().is_01() || !mul_ln1118_552_fu_63080_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_552_fu_63080_p0.read()) * sc_bigint<5>(mul_ln1118_552_fu_63080_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_553_fu_31385_p0() {
    mul_ln1118_553_fu_31385_p0 =  (sc_lv<12>) (sext_ln1116_153_cast_fu_25093_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_553_fu_31385_p1() {
    mul_ln1118_553_fu_31385_p1 = tmp_553_fu_31371_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_553_fu_31385_p2() {
    mul_ln1118_553_fu_31385_p2 = (!mul_ln1118_553_fu_31385_p0.read().is_01() || !mul_ln1118_553_fu_31385_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_553_fu_31385_p0.read()) * sc_bigint<5>(mul_ln1118_553_fu_31385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_554_fu_31415_p0() {
    mul_ln1118_554_fu_31415_p0 =  (sc_lv<12>) (sext_ln1116_154_cast_fu_25135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_554_fu_31415_p1() {
    mul_ln1118_554_fu_31415_p1 = tmp_554_fu_31401_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_554_fu_31415_p2() {
    mul_ln1118_554_fu_31415_p2 = (!mul_ln1118_554_fu_31415_p0.read().is_01() || !mul_ln1118_554_fu_31415_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_554_fu_31415_p0.read()) * sc_bigint<5>(mul_ln1118_554_fu_31415_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_555_fu_31445_p0() {
    mul_ln1118_555_fu_31445_p0 =  (sc_lv<12>) (sext_ln1116_155_cast_fu_25177_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_555_fu_31445_p1() {
    mul_ln1118_555_fu_31445_p1 = tmp_555_fu_31431_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_555_fu_31445_p2() {
    mul_ln1118_555_fu_31445_p2 = (!mul_ln1118_555_fu_31445_p0.read().is_01() || !mul_ln1118_555_fu_31445_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_555_fu_31445_p0.read()) * sc_bigint<5>(mul_ln1118_555_fu_31445_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_556_fu_31475_p0() {
    mul_ln1118_556_fu_31475_p0 =  (sc_lv<12>) (sext_ln1116_156_cast_fu_25219_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_556_fu_31475_p1() {
    mul_ln1118_556_fu_31475_p1 = tmp_556_fu_31461_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_556_fu_31475_p2() {
    mul_ln1118_556_fu_31475_p2 = (!mul_ln1118_556_fu_31475_p0.read().is_01() || !mul_ln1118_556_fu_31475_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_556_fu_31475_p0.read()) * sc_bigint<5>(mul_ln1118_556_fu_31475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_557_fu_31505_p0() {
    mul_ln1118_557_fu_31505_p0 =  (sc_lv<12>) (sext_ln1116_157_cast_fu_25261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_557_fu_31505_p1() {
    mul_ln1118_557_fu_31505_p1 = tmp_557_fu_31491_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_557_fu_31505_p2() {
    mul_ln1118_557_fu_31505_p2 = (!mul_ln1118_557_fu_31505_p0.read().is_01() || !mul_ln1118_557_fu_31505_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_557_fu_31505_p0.read()) * sc_bigint<5>(mul_ln1118_557_fu_31505_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_558_fu_31535_p0() {
    mul_ln1118_558_fu_31535_p0 =  (sc_lv<12>) (sext_ln1116_158_cast_fu_25303_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_558_fu_31535_p1() {
    mul_ln1118_558_fu_31535_p1 = tmp_558_fu_31521_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_558_fu_31535_p2() {
    mul_ln1118_558_fu_31535_p2 = (!mul_ln1118_558_fu_31535_p0.read().is_01() || !mul_ln1118_558_fu_31535_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_558_fu_31535_p0.read()) * sc_bigint<5>(mul_ln1118_558_fu_31535_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_559_fu_63098_p0() {
    mul_ln1118_559_fu_63098_p0 =  (sc_lv<12>) (sext_ln1116_159_cast_fu_55107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_559_fu_63098_p1() {
    mul_ln1118_559_fu_63098_p1 = tmp_559_reg_99352.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_559_fu_63098_p2() {
    mul_ln1118_559_fu_63098_p2 = (!mul_ln1118_559_fu_63098_p0.read().is_01() || !mul_ln1118_559_fu_63098_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_559_fu_63098_p0.read()) * sc_bigint<5>(mul_ln1118_559_fu_63098_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_55_fu_22889_p0() {
    mul_ln1118_55_fu_22889_p0 =  (sc_lv<12>) (sext_ln1116_55_cast_fu_22881_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_55_fu_22889_p1() {
    mul_ln1118_55_fu_22889_p1 = tmp_55_fu_22871_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_55_fu_22889_p2() {
    mul_ln1118_55_fu_22889_p2 = (!mul_ln1118_55_fu_22889_p0.read().is_01() || !mul_ln1118_55_fu_22889_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_55_fu_22889_p0.read()) * sc_bigint<5>(mul_ln1118_55_fu_22889_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_560_fu_63117_p0() {
    mul_ln1118_560_fu_63117_p0 =  (sc_lv<12>) (sext_ln1116_160_cast_fu_55129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_560_fu_63117_p1() {
    mul_ln1118_560_fu_63117_p1 = tmp_560_reg_99357.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_560_fu_63117_p2() {
    mul_ln1118_560_fu_63117_p2 = (!mul_ln1118_560_fu_63117_p0.read().is_01() || !mul_ln1118_560_fu_63117_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_560_fu_63117_p0.read()) * sc_bigint<5>(mul_ln1118_560_fu_63117_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_561_fu_63136_p0() {
    mul_ln1118_561_fu_63136_p0 =  (sc_lv<12>) (sext_ln1116_161_cast_fu_55151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_561_fu_63136_p1() {
    mul_ln1118_561_fu_63136_p1 = tmp_561_reg_99362.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_561_fu_63136_p2() {
    mul_ln1118_561_fu_63136_p2 = (!mul_ln1118_561_fu_63136_p0.read().is_01() || !mul_ln1118_561_fu_63136_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_561_fu_63136_p0.read()) * sc_bigint<5>(mul_ln1118_561_fu_63136_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_562_fu_63155_p0() {
    mul_ln1118_562_fu_63155_p0 =  (sc_lv<12>) (sext_ln1116_162_cast_fu_55173_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_562_fu_63155_p1() {
    mul_ln1118_562_fu_63155_p1 = tmp_562_reg_99367.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_562_fu_63155_p2() {
    mul_ln1118_562_fu_63155_p2 = (!mul_ln1118_562_fu_63155_p0.read().is_01() || !mul_ln1118_562_fu_63155_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_562_fu_63155_p0.read()) * sc_bigint<5>(mul_ln1118_562_fu_63155_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_563_fu_63174_p0() {
    mul_ln1118_563_fu_63174_p0 =  (sc_lv<12>) (sext_ln1116_163_cast_fu_55195_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_563_fu_63174_p1() {
    mul_ln1118_563_fu_63174_p1 = tmp_563_reg_99372.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_563_fu_63174_p2() {
    mul_ln1118_563_fu_63174_p2 = (!mul_ln1118_563_fu_63174_p0.read().is_01() || !mul_ln1118_563_fu_63174_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_563_fu_63174_p0.read()) * sc_bigint<5>(mul_ln1118_563_fu_63174_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_564_fu_63193_p0() {
    mul_ln1118_564_fu_63193_p0 =  (sc_lv<12>) (sext_ln1116_164_cast_fu_55217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_564_fu_63193_p1() {
    mul_ln1118_564_fu_63193_p1 = tmp_564_reg_99377.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_564_fu_63193_p2() {
    mul_ln1118_564_fu_63193_p2 = (!mul_ln1118_564_fu_63193_p0.read().is_01() || !mul_ln1118_564_fu_63193_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_564_fu_63193_p0.read()) * sc_bigint<5>(mul_ln1118_564_fu_63193_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_565_fu_63212_p0() {
    mul_ln1118_565_fu_63212_p0 =  (sc_lv<12>) (sext_ln1116_165_cast_fu_55239_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_565_fu_63212_p1() {
    mul_ln1118_565_fu_63212_p1 = tmp_565_reg_99382.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_565_fu_63212_p2() {
    mul_ln1118_565_fu_63212_p2 = (!mul_ln1118_565_fu_63212_p0.read().is_01() || !mul_ln1118_565_fu_63212_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_565_fu_63212_p0.read()) * sc_bigint<5>(mul_ln1118_565_fu_63212_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_566_fu_63231_p0() {
    mul_ln1118_566_fu_63231_p0 =  (sc_lv<12>) (sext_ln1116_166_cast_fu_55261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_566_fu_63231_p1() {
    mul_ln1118_566_fu_63231_p1 = tmp_566_reg_99387.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_566_fu_63231_p2() {
    mul_ln1118_566_fu_63231_p2 = (!mul_ln1118_566_fu_63231_p0.read().is_01() || !mul_ln1118_566_fu_63231_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_566_fu_63231_p0.read()) * sc_bigint<5>(mul_ln1118_566_fu_63231_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_567_fu_63250_p0() {
    mul_ln1118_567_fu_63250_p0 =  (sc_lv<12>) (sext_ln1116_167_cast_fu_55283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_567_fu_63250_p1() {
    mul_ln1118_567_fu_63250_p1 = tmp_567_reg_99392.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_567_fu_63250_p2() {
    mul_ln1118_567_fu_63250_p2 = (!mul_ln1118_567_fu_63250_p0.read().is_01() || !mul_ln1118_567_fu_63250_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_567_fu_63250_p0.read()) * sc_bigint<5>(mul_ln1118_567_fu_63250_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_568_fu_63269_p0() {
    mul_ln1118_568_fu_63269_p0 =  (sc_lv<12>) (sext_ln1116_168_cast_fu_55305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_568_fu_63269_p1() {
    mul_ln1118_568_fu_63269_p1 = tmp_568_reg_99397.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_568_fu_63269_p2() {
    mul_ln1118_568_fu_63269_p2 = (!mul_ln1118_568_fu_63269_p0.read().is_01() || !mul_ln1118_568_fu_63269_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_568_fu_63269_p0.read()) * sc_bigint<5>(mul_ln1118_568_fu_63269_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_569_fu_63288_p0() {
    mul_ln1118_569_fu_63288_p0 =  (sc_lv<12>) (sext_ln1116_169_cast_fu_55327_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_569_fu_63288_p1() {
    mul_ln1118_569_fu_63288_p1 = tmp_569_reg_99402.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_569_fu_63288_p2() {
    mul_ln1118_569_fu_63288_p2 = (!mul_ln1118_569_fu_63288_p0.read().is_01() || !mul_ln1118_569_fu_63288_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_569_fu_63288_p0.read()) * sc_bigint<5>(mul_ln1118_569_fu_63288_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_56_fu_22931_p0() {
    mul_ln1118_56_fu_22931_p0 =  (sc_lv<12>) (sext_ln1116_56_cast_fu_22923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_56_fu_22931_p1() {
    mul_ln1118_56_fu_22931_p1 = tmp_56_fu_22913_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_56_fu_22931_p2() {
    mul_ln1118_56_fu_22931_p2 = (!mul_ln1118_56_fu_22931_p0.read().is_01() || !mul_ln1118_56_fu_22931_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_56_fu_22931_p0.read()) * sc_bigint<5>(mul_ln1118_56_fu_22931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_570_fu_63307_p0() {
    mul_ln1118_570_fu_63307_p0 =  (sc_lv<12>) (sext_ln1116_170_cast_fu_55349_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_570_fu_63307_p1() {
    mul_ln1118_570_fu_63307_p1 = tmp_570_reg_99407.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_570_fu_63307_p2() {
    mul_ln1118_570_fu_63307_p2 = (!mul_ln1118_570_fu_63307_p0.read().is_01() || !mul_ln1118_570_fu_63307_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_570_fu_63307_p0.read()) * sc_bigint<5>(mul_ln1118_570_fu_63307_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_571_fu_63326_p0() {
    mul_ln1118_571_fu_63326_p0 =  (sc_lv<12>) (sext_ln1116_171_cast_fu_55371_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_571_fu_63326_p1() {
    mul_ln1118_571_fu_63326_p1 = tmp_571_reg_99412.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_571_fu_63326_p2() {
    mul_ln1118_571_fu_63326_p2 = (!mul_ln1118_571_fu_63326_p0.read().is_01() || !mul_ln1118_571_fu_63326_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_571_fu_63326_p0.read()) * sc_bigint<5>(mul_ln1118_571_fu_63326_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_572_fu_63345_p0() {
    mul_ln1118_572_fu_63345_p0 =  (sc_lv<12>) (sext_ln1116_172_cast_fu_55393_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_572_fu_63345_p1() {
    mul_ln1118_572_fu_63345_p1 = tmp_572_reg_99417.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_572_fu_63345_p2() {
    mul_ln1118_572_fu_63345_p2 = (!mul_ln1118_572_fu_63345_p0.read().is_01() || !mul_ln1118_572_fu_63345_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_572_fu_63345_p0.read()) * sc_bigint<5>(mul_ln1118_572_fu_63345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_573_fu_63364_p0() {
    mul_ln1118_573_fu_63364_p0 =  (sc_lv<12>) (sext_ln1116_173_cast_fu_55415_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_573_fu_63364_p1() {
    mul_ln1118_573_fu_63364_p1 = tmp_573_reg_99422.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_573_fu_63364_p2() {
    mul_ln1118_573_fu_63364_p2 = (!mul_ln1118_573_fu_63364_p0.read().is_01() || !mul_ln1118_573_fu_63364_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_573_fu_63364_p0.read()) * sc_bigint<5>(mul_ln1118_573_fu_63364_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_574_fu_63383_p0() {
    mul_ln1118_574_fu_63383_p0 =  (sc_lv<12>) (sext_ln1116_174_cast_fu_55437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_574_fu_63383_p1() {
    mul_ln1118_574_fu_63383_p1 = tmp_574_reg_99427.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_574_fu_63383_p2() {
    mul_ln1118_574_fu_63383_p2 = (!mul_ln1118_574_fu_63383_p0.read().is_01() || !mul_ln1118_574_fu_63383_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_574_fu_63383_p0.read()) * sc_bigint<5>(mul_ln1118_574_fu_63383_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_575_fu_63402_p0() {
    mul_ln1118_575_fu_63402_p0 =  (sc_lv<12>) (sext_ln1116_175_cast_fu_55459_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_575_fu_63402_p1() {
    mul_ln1118_575_fu_63402_p1 = tmp_575_reg_99432.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_575_fu_63402_p2() {
    mul_ln1118_575_fu_63402_p2 = (!mul_ln1118_575_fu_63402_p0.read().is_01() || !mul_ln1118_575_fu_63402_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_575_fu_63402_p0.read()) * sc_bigint<5>(mul_ln1118_575_fu_63402_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_576_fu_63421_p0() {
    mul_ln1118_576_fu_63421_p0 =  (sc_lv<12>) (sext_ln1116_176_cast_reg_97300.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_576_fu_63421_p1() {
    mul_ln1118_576_fu_63421_p1 = tmp_576_reg_99437.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_576_fu_63421_p2() {
    mul_ln1118_576_fu_63421_p2 = (!mul_ln1118_576_fu_63421_p0.read().is_01() || !mul_ln1118_576_fu_63421_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_576_fu_63421_p0.read()) * sc_bigint<5>(mul_ln1118_576_fu_63421_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_577_fu_63439_p0() {
    mul_ln1118_577_fu_63439_p0 =  (sc_lv<12>) (sext_ln1116_177_cast_reg_97318.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_577_fu_63439_p1() {
    mul_ln1118_577_fu_63439_p1 = tmp_577_reg_99442.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_577_fu_63439_p2() {
    mul_ln1118_577_fu_63439_p2 = (!mul_ln1118_577_fu_63439_p0.read().is_01() || !mul_ln1118_577_fu_63439_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_577_fu_63439_p0.read()) * sc_bigint<5>(mul_ln1118_577_fu_63439_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_578_fu_31755_p0() {
    mul_ln1118_578_fu_31755_p0 =  (sc_lv<12>) (sext_ln1116_178_cast_fu_25695_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_578_fu_31755_p1() {
    mul_ln1118_578_fu_31755_p1 = tmp_578_fu_31741_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_578_fu_31755_p2() {
    mul_ln1118_578_fu_31755_p2 = (!mul_ln1118_578_fu_31755_p0.read().is_01() || !mul_ln1118_578_fu_31755_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_578_fu_31755_p0.read()) * sc_bigint<5>(mul_ln1118_578_fu_31755_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_579_fu_31785_p0() {
    mul_ln1118_579_fu_31785_p0 =  (sc_lv<12>) (sext_ln1116_179_cast_fu_25737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_579_fu_31785_p1() {
    mul_ln1118_579_fu_31785_p1 = tmp_579_fu_31771_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_579_fu_31785_p2() {
    mul_ln1118_579_fu_31785_p2 = (!mul_ln1118_579_fu_31785_p0.read().is_01() || !mul_ln1118_579_fu_31785_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_579_fu_31785_p0.read()) * sc_bigint<5>(mul_ln1118_579_fu_31785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_57_fu_22973_p0() {
    mul_ln1118_57_fu_22973_p0 =  (sc_lv<12>) (sext_ln1116_57_cast_fu_22965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_57_fu_22973_p1() {
    mul_ln1118_57_fu_22973_p1 = tmp_57_fu_22955_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_57_fu_22973_p2() {
    mul_ln1118_57_fu_22973_p2 = (!mul_ln1118_57_fu_22973_p0.read().is_01() || !mul_ln1118_57_fu_22973_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_57_fu_22973_p0.read()) * sc_bigint<5>(mul_ln1118_57_fu_22973_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_580_fu_31815_p0() {
    mul_ln1118_580_fu_31815_p0 =  (sc_lv<12>) (sext_ln1116_180_cast_fu_25779_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_580_fu_31815_p1() {
    mul_ln1118_580_fu_31815_p1 = tmp_580_fu_31801_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_580_fu_31815_p2() {
    mul_ln1118_580_fu_31815_p2 = (!mul_ln1118_580_fu_31815_p0.read().is_01() || !mul_ln1118_580_fu_31815_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_580_fu_31815_p0.read()) * sc_bigint<5>(mul_ln1118_580_fu_31815_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_581_fu_31845_p0() {
    mul_ln1118_581_fu_31845_p0 =  (sc_lv<12>) (sext_ln1116_181_cast_fu_25821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_581_fu_31845_p1() {
    mul_ln1118_581_fu_31845_p1 = tmp_581_fu_31831_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_581_fu_31845_p2() {
    mul_ln1118_581_fu_31845_p2 = (!mul_ln1118_581_fu_31845_p0.read().is_01() || !mul_ln1118_581_fu_31845_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_581_fu_31845_p0.read()) * sc_bigint<5>(mul_ln1118_581_fu_31845_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_582_fu_31875_p0() {
    mul_ln1118_582_fu_31875_p0 =  (sc_lv<12>) (sext_ln1116_182_cast_fu_25863_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_582_fu_31875_p1() {
    mul_ln1118_582_fu_31875_p1 = tmp_582_fu_31861_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_582_fu_31875_p2() {
    mul_ln1118_582_fu_31875_p2 = (!mul_ln1118_582_fu_31875_p0.read().is_01() || !mul_ln1118_582_fu_31875_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_582_fu_31875_p0.read()) * sc_bigint<5>(mul_ln1118_582_fu_31875_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_583_fu_31905_p0() {
    mul_ln1118_583_fu_31905_p0 =  (sc_lv<12>) (sext_ln1116_183_cast_fu_25905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_583_fu_31905_p1() {
    mul_ln1118_583_fu_31905_p1 = tmp_583_fu_31891_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_583_fu_31905_p2() {
    mul_ln1118_583_fu_31905_p2 = (!mul_ln1118_583_fu_31905_p0.read().is_01() || !mul_ln1118_583_fu_31905_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_583_fu_31905_p0.read()) * sc_bigint<5>(mul_ln1118_583_fu_31905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_584_fu_63457_p0() {
    mul_ln1118_584_fu_63457_p0 =  (sc_lv<12>) (sext_ln1116_184_cast_fu_55517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_584_fu_63457_p1() {
    mul_ln1118_584_fu_63457_p1 = tmp_584_reg_99477.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_584_fu_63457_p2() {
    mul_ln1118_584_fu_63457_p2 = (!mul_ln1118_584_fu_63457_p0.read().is_01() || !mul_ln1118_584_fu_63457_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_584_fu_63457_p0.read()) * sc_bigint<5>(mul_ln1118_584_fu_63457_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_585_fu_63476_p0() {
    mul_ln1118_585_fu_63476_p0 =  (sc_lv<12>) (sext_ln1116_185_cast_fu_55539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_585_fu_63476_p1() {
    mul_ln1118_585_fu_63476_p1 = tmp_585_reg_99482.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_585_fu_63476_p2() {
    mul_ln1118_585_fu_63476_p2 = (!mul_ln1118_585_fu_63476_p0.read().is_01() || !mul_ln1118_585_fu_63476_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_585_fu_63476_p0.read()) * sc_bigint<5>(mul_ln1118_585_fu_63476_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_586_fu_63495_p0() {
    mul_ln1118_586_fu_63495_p0 =  (sc_lv<12>) (sext_ln1116_186_cast_fu_55561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_586_fu_63495_p1() {
    mul_ln1118_586_fu_63495_p1 = tmp_586_reg_99487.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_586_fu_63495_p2() {
    mul_ln1118_586_fu_63495_p2 = (!mul_ln1118_586_fu_63495_p0.read().is_01() || !mul_ln1118_586_fu_63495_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_586_fu_63495_p0.read()) * sc_bigint<5>(mul_ln1118_586_fu_63495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_587_fu_63514_p0() {
    mul_ln1118_587_fu_63514_p0 =  (sc_lv<12>) (sext_ln1116_187_cast_fu_55583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_587_fu_63514_p1() {
    mul_ln1118_587_fu_63514_p1 = tmp_587_reg_99492.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_587_fu_63514_p2() {
    mul_ln1118_587_fu_63514_p2 = (!mul_ln1118_587_fu_63514_p0.read().is_01() || !mul_ln1118_587_fu_63514_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_587_fu_63514_p0.read()) * sc_bigint<5>(mul_ln1118_587_fu_63514_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_588_fu_63533_p0() {
    mul_ln1118_588_fu_63533_p0 =  (sc_lv<12>) (sext_ln1116_188_cast_fu_55605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_588_fu_63533_p1() {
    mul_ln1118_588_fu_63533_p1 = tmp_588_reg_99497.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_588_fu_63533_p2() {
    mul_ln1118_588_fu_63533_p2 = (!mul_ln1118_588_fu_63533_p0.read().is_01() || !mul_ln1118_588_fu_63533_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_588_fu_63533_p0.read()) * sc_bigint<5>(mul_ln1118_588_fu_63533_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_589_fu_63552_p0() {
    mul_ln1118_589_fu_63552_p0 =  (sc_lv<12>) (sext_ln1116_189_cast_fu_55627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_589_fu_63552_p1() {
    mul_ln1118_589_fu_63552_p1 = tmp_589_reg_99502.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_589_fu_63552_p2() {
    mul_ln1118_589_fu_63552_p2 = (!mul_ln1118_589_fu_63552_p0.read().is_01() || !mul_ln1118_589_fu_63552_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_589_fu_63552_p0.read()) * sc_bigint<5>(mul_ln1118_589_fu_63552_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_58_fu_23015_p0() {
    mul_ln1118_58_fu_23015_p0 =  (sc_lv<12>) (sext_ln1116_58_cast_fu_23007_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_58_fu_23015_p1() {
    mul_ln1118_58_fu_23015_p1 = tmp_58_fu_22997_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_58_fu_23015_p2() {
    mul_ln1118_58_fu_23015_p2 = (!mul_ln1118_58_fu_23015_p0.read().is_01() || !mul_ln1118_58_fu_23015_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_58_fu_23015_p0.read()) * sc_bigint<5>(mul_ln1118_58_fu_23015_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_590_fu_63571_p0() {
    mul_ln1118_590_fu_63571_p0 =  (sc_lv<12>) (sext_ln1116_190_cast_fu_55649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_590_fu_63571_p1() {
    mul_ln1118_590_fu_63571_p1 = tmp_590_reg_99507.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_590_fu_63571_p2() {
    mul_ln1118_590_fu_63571_p2 = (!mul_ln1118_590_fu_63571_p0.read().is_01() || !mul_ln1118_590_fu_63571_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_590_fu_63571_p0.read()) * sc_bigint<5>(mul_ln1118_590_fu_63571_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_591_fu_63590_p0() {
    mul_ln1118_591_fu_63590_p0 =  (sc_lv<12>) (sext_ln1116_191_cast_fu_55671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_591_fu_63590_p1() {
    mul_ln1118_591_fu_63590_p1 = tmp_591_reg_99512.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_591_fu_63590_p2() {
    mul_ln1118_591_fu_63590_p2 = (!mul_ln1118_591_fu_63590_p0.read().is_01() || !mul_ln1118_591_fu_63590_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_591_fu_63590_p0.read()) * sc_bigint<5>(mul_ln1118_591_fu_63590_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_592_fu_63609_p0() {
    mul_ln1118_592_fu_63609_p0 =  (sc_lv<12>) (sext_ln1116_192_cast_fu_55693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_592_fu_63609_p1() {
    mul_ln1118_592_fu_63609_p1 = tmp_592_reg_99517.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_592_fu_63609_p2() {
    mul_ln1118_592_fu_63609_p2 = (!mul_ln1118_592_fu_63609_p0.read().is_01() || !mul_ln1118_592_fu_63609_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_592_fu_63609_p0.read()) * sc_bigint<5>(mul_ln1118_592_fu_63609_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_593_fu_63628_p0() {
    mul_ln1118_593_fu_63628_p0 =  (sc_lv<12>) (sext_ln1116_193_cast_fu_55715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_593_fu_63628_p1() {
    mul_ln1118_593_fu_63628_p1 = tmp_593_reg_99522.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_593_fu_63628_p2() {
    mul_ln1118_593_fu_63628_p2 = (!mul_ln1118_593_fu_63628_p0.read().is_01() || !mul_ln1118_593_fu_63628_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_593_fu_63628_p0.read()) * sc_bigint<5>(mul_ln1118_593_fu_63628_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_594_fu_63647_p0() {
    mul_ln1118_594_fu_63647_p0 =  (sc_lv<12>) (sext_ln1116_194_cast_fu_55737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_594_fu_63647_p1() {
    mul_ln1118_594_fu_63647_p1 = tmp_594_reg_99527.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_594_fu_63647_p2() {
    mul_ln1118_594_fu_63647_p2 = (!mul_ln1118_594_fu_63647_p0.read().is_01() || !mul_ln1118_594_fu_63647_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_594_fu_63647_p0.read()) * sc_bigint<5>(mul_ln1118_594_fu_63647_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_595_fu_63666_p0() {
    mul_ln1118_595_fu_63666_p0 =  (sc_lv<12>) (sext_ln1116_195_cast_fu_55759_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_595_fu_63666_p1() {
    mul_ln1118_595_fu_63666_p1 = tmp_595_reg_99532.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_595_fu_63666_p2() {
    mul_ln1118_595_fu_63666_p2 = (!mul_ln1118_595_fu_63666_p0.read().is_01() || !mul_ln1118_595_fu_63666_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_595_fu_63666_p0.read()) * sc_bigint<5>(mul_ln1118_595_fu_63666_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_596_fu_63685_p0() {
    mul_ln1118_596_fu_63685_p0 =  (sc_lv<12>) (sext_ln1116_196_cast_fu_55781_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_596_fu_63685_p1() {
    mul_ln1118_596_fu_63685_p1 = tmp_596_reg_99537.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_596_fu_63685_p2() {
    mul_ln1118_596_fu_63685_p2 = (!mul_ln1118_596_fu_63685_p0.read().is_01() || !mul_ln1118_596_fu_63685_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_596_fu_63685_p0.read()) * sc_bigint<5>(mul_ln1118_596_fu_63685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_597_fu_63704_p0() {
    mul_ln1118_597_fu_63704_p0 =  (sc_lv<12>) (sext_ln1116_197_cast_fu_55803_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_597_fu_63704_p1() {
    mul_ln1118_597_fu_63704_p1 = tmp_597_reg_99542.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_597_fu_63704_p2() {
    mul_ln1118_597_fu_63704_p2 = (!mul_ln1118_597_fu_63704_p0.read().is_01() || !mul_ln1118_597_fu_63704_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_597_fu_63704_p0.read()) * sc_bigint<5>(mul_ln1118_597_fu_63704_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_598_fu_63723_p0() {
    mul_ln1118_598_fu_63723_p0 =  (sc_lv<12>) (sext_ln1116_198_cast_fu_55825_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_598_fu_63723_p1() {
    mul_ln1118_598_fu_63723_p1 = tmp_598_reg_99547.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_598_fu_63723_p2() {
    mul_ln1118_598_fu_63723_p2 = (!mul_ln1118_598_fu_63723_p0.read().is_01() || !mul_ln1118_598_fu_63723_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_598_fu_63723_p0.read()) * sc_bigint<5>(mul_ln1118_598_fu_63723_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_599_fu_63742_p0() {
    mul_ln1118_599_fu_63742_p0 =  (sc_lv<12>) (sext_ln1116_199_cast_fu_55847_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_599_fu_63742_p1() {
    mul_ln1118_599_fu_63742_p1 = tmp_599_reg_99552.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_599_fu_63742_p2() {
    mul_ln1118_599_fu_63742_p2 = (!mul_ln1118_599_fu_63742_p0.read().is_01() || !mul_ln1118_599_fu_63742_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_599_fu_63742_p0.read()) * sc_bigint<5>(mul_ln1118_599_fu_63742_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_59_fu_53369_p0() {
    mul_ln1118_59_fu_53369_p0 =  (sc_lv<12>) (sext_ln1116_59_cast_fu_53363_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_59_fu_53369_p1() {
    mul_ln1118_59_fu_53369_p1 = tmp_59_reg_96198.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_59_fu_53369_p2() {
    mul_ln1118_59_fu_53369_p2 = (!mul_ln1118_59_fu_53369_p0.read().is_01() || !mul_ln1118_59_fu_53369_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_59_fu_53369_p0.read()) * sc_bigint<5>(mul_ln1118_59_fu_53369_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_600_fu_63761_p0() {
    mul_ln1118_600_fu_63761_p0 =  (sc_lv<12>) (sext_ln1116_200_cast_fu_55869_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_600_fu_63761_p1() {
    mul_ln1118_600_fu_63761_p1 = tmp_600_reg_99557.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_600_fu_63761_p2() {
    mul_ln1118_600_fu_63761_p2 = (!mul_ln1118_600_fu_63761_p0.read().is_01() || !mul_ln1118_600_fu_63761_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_600_fu_63761_p0.read()) * sc_bigint<5>(mul_ln1118_600_fu_63761_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_601_fu_63780_p0() {
    mul_ln1118_601_fu_63780_p0 =  (sc_lv<12>) (sext_ln1116_201_cast_reg_97536.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_601_fu_63780_p1() {
    mul_ln1118_601_fu_63780_p1 = tmp_601_reg_99562.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_601_fu_63780_p2() {
    mul_ln1118_601_fu_63780_p2 = (!mul_ln1118_601_fu_63780_p0.read().is_01() || !mul_ln1118_601_fu_63780_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_601_fu_63780_p0.read()) * sc_bigint<5>(mul_ln1118_601_fu_63780_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_602_fu_63798_p0() {
    mul_ln1118_602_fu_63798_p0 =  (sc_lv<12>) (sext_ln1116_202_cast_reg_97554.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_602_fu_63798_p1() {
    mul_ln1118_602_fu_63798_p1 = tmp_602_reg_99567.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_602_fu_63798_p2() {
    mul_ln1118_602_fu_63798_p2 = (!mul_ln1118_602_fu_63798_p0.read().is_01() || !mul_ln1118_602_fu_63798_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_602_fu_63798_p0.read()) * sc_bigint<5>(mul_ln1118_602_fu_63798_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_603_fu_32125_p0() {
    mul_ln1118_603_fu_32125_p0 =  (sc_lv<12>) (sext_ln1116_203_cast_fu_26297_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_603_fu_32125_p1() {
    mul_ln1118_603_fu_32125_p1 = tmp_603_fu_32111_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_603_fu_32125_p2() {
    mul_ln1118_603_fu_32125_p2 = (!mul_ln1118_603_fu_32125_p0.read().is_01() || !mul_ln1118_603_fu_32125_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_603_fu_32125_p0.read()) * sc_bigint<5>(mul_ln1118_603_fu_32125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_604_fu_32155_p0() {
    mul_ln1118_604_fu_32155_p0 =  (sc_lv<12>) (sext_ln1116_204_cast_fu_26339_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_604_fu_32155_p1() {
    mul_ln1118_604_fu_32155_p1 = tmp_604_fu_32141_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_604_fu_32155_p2() {
    mul_ln1118_604_fu_32155_p2 = (!mul_ln1118_604_fu_32155_p0.read().is_01() || !mul_ln1118_604_fu_32155_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_604_fu_32155_p0.read()) * sc_bigint<5>(mul_ln1118_604_fu_32155_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_605_fu_32185_p0() {
    mul_ln1118_605_fu_32185_p0 =  (sc_lv<12>) (sext_ln1116_205_cast_fu_26381_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_605_fu_32185_p1() {
    mul_ln1118_605_fu_32185_p1 = tmp_605_fu_32171_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_605_fu_32185_p2() {
    mul_ln1118_605_fu_32185_p2 = (!mul_ln1118_605_fu_32185_p0.read().is_01() || !mul_ln1118_605_fu_32185_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_605_fu_32185_p0.read()) * sc_bigint<5>(mul_ln1118_605_fu_32185_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_606_fu_32215_p0() {
    mul_ln1118_606_fu_32215_p0 =  (sc_lv<12>) (sext_ln1116_206_cast_fu_26423_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_606_fu_32215_p1() {
    mul_ln1118_606_fu_32215_p1 = tmp_606_fu_32201_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_606_fu_32215_p2() {
    mul_ln1118_606_fu_32215_p2 = (!mul_ln1118_606_fu_32215_p0.read().is_01() || !mul_ln1118_606_fu_32215_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_606_fu_32215_p0.read()) * sc_bigint<5>(mul_ln1118_606_fu_32215_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_607_fu_32245_p0() {
    mul_ln1118_607_fu_32245_p0 =  (sc_lv<12>) (sext_ln1116_207_cast_fu_26465_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_607_fu_32245_p1() {
    mul_ln1118_607_fu_32245_p1 = tmp_607_fu_32231_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_607_fu_32245_p2() {
    mul_ln1118_607_fu_32245_p2 = (!mul_ln1118_607_fu_32245_p0.read().is_01() || !mul_ln1118_607_fu_32245_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_607_fu_32245_p0.read()) * sc_bigint<5>(mul_ln1118_607_fu_32245_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_608_fu_32275_p0() {
    mul_ln1118_608_fu_32275_p0 =  (sc_lv<12>) (sext_ln1116_208_cast_fu_26507_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_608_fu_32275_p1() {
    mul_ln1118_608_fu_32275_p1 = tmp_608_fu_32261_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_608_fu_32275_p2() {
    mul_ln1118_608_fu_32275_p2 = (!mul_ln1118_608_fu_32275_p0.read().is_01() || !mul_ln1118_608_fu_32275_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_608_fu_32275_p0.read()) * sc_bigint<5>(mul_ln1118_608_fu_32275_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_609_fu_64804_p0() {
    mul_ln1118_609_fu_64804_p0 =  (sc_lv<12>) (sext_ln1116_cast_fu_52531_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_609_fu_64804_p1() {
    mul_ln1118_609_fu_64804_p1 = tmp_609_reg_99602.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_609_fu_64804_p2() {
    mul_ln1118_609_fu_64804_p2 = (!mul_ln1118_609_fu_64804_p0.read().is_01() || !mul_ln1118_609_fu_64804_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_609_fu_64804_p0.read()) * sc_bigint<5>(mul_ln1118_609_fu_64804_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_60_fu_53391_p0() {
    mul_ln1118_60_fu_53391_p0 =  (sc_lv<12>) (sext_ln1116_60_cast_fu_53385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_60_fu_53391_p1() {
    mul_ln1118_60_fu_53391_p1 = tmp_60_reg_96208.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_60_fu_53391_p2() {
    mul_ln1118_60_fu_53391_p2 = (!mul_ln1118_60_fu_53391_p0.read().is_01() || !mul_ln1118_60_fu_53391_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_60_fu_53391_p0.read()) * sc_bigint<5>(mul_ln1118_60_fu_53391_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_610_fu_64823_p0() {
    mul_ln1118_610_fu_64823_p0 =  (sc_lv<12>) (sext_ln1116_10_cast_fu_52553_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_610_fu_64823_p1() {
    mul_ln1118_610_fu_64823_p1 = tmp_610_reg_99607.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_610_fu_64823_p2() {
    mul_ln1118_610_fu_64823_p2 = (!mul_ln1118_610_fu_64823_p0.read().is_01() || !mul_ln1118_610_fu_64823_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_610_fu_64823_p0.read()) * sc_bigint<5>(mul_ln1118_610_fu_64823_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_611_fu_64842_p0() {
    mul_ln1118_611_fu_64842_p0 =  (sc_lv<12>) (sext_ln1116_11_cast_fu_52575_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_611_fu_64842_p1() {
    mul_ln1118_611_fu_64842_p1 = tmp_611_reg_99612.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_611_fu_64842_p2() {
    mul_ln1118_611_fu_64842_p2 = (!mul_ln1118_611_fu_64842_p0.read().is_01() || !mul_ln1118_611_fu_64842_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_611_fu_64842_p0.read()) * sc_bigint<5>(mul_ln1118_611_fu_64842_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_612_fu_64861_p0() {
    mul_ln1118_612_fu_64861_p0 =  (sc_lv<12>) (sext_ln1116_12_cast_fu_52597_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_612_fu_64861_p1() {
    mul_ln1118_612_fu_64861_p1 = tmp_612_reg_99617.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_612_fu_64861_p2() {
    mul_ln1118_612_fu_64861_p2 = (!mul_ln1118_612_fu_64861_p0.read().is_01() || !mul_ln1118_612_fu_64861_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_612_fu_64861_p0.read()) * sc_bigint<5>(mul_ln1118_612_fu_64861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_613_fu_64880_p0() {
    mul_ln1118_613_fu_64880_p0 =  (sc_lv<12>) (sext_ln1116_13_cast_fu_52619_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_613_fu_64880_p1() {
    mul_ln1118_613_fu_64880_p1 = tmp_613_reg_99622.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_613_fu_64880_p2() {
    mul_ln1118_613_fu_64880_p2 = (!mul_ln1118_613_fu_64880_p0.read().is_01() || !mul_ln1118_613_fu_64880_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_613_fu_64880_p0.read()) * sc_bigint<5>(mul_ln1118_613_fu_64880_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_614_fu_64899_p0() {
    mul_ln1118_614_fu_64899_p0 =  (sc_lv<12>) (sext_ln1116_14_cast_fu_52641_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_614_fu_64899_p1() {
    mul_ln1118_614_fu_64899_p1 = tmp_614_reg_99627.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_614_fu_64899_p2() {
    mul_ln1118_614_fu_64899_p2 = (!mul_ln1118_614_fu_64899_p0.read().is_01() || !mul_ln1118_614_fu_64899_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_614_fu_64899_p0.read()) * sc_bigint<5>(mul_ln1118_614_fu_64899_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_615_fu_64918_p0() {
    mul_ln1118_615_fu_64918_p0 =  (sc_lv<12>) (sext_ln1116_15_cast_fu_52663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_615_fu_64918_p1() {
    mul_ln1118_615_fu_64918_p1 = tmp_615_reg_99632.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_615_fu_64918_p2() {
    mul_ln1118_615_fu_64918_p2 = (!mul_ln1118_615_fu_64918_p0.read().is_01() || !mul_ln1118_615_fu_64918_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_615_fu_64918_p0.read()) * sc_bigint<5>(mul_ln1118_615_fu_64918_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_616_fu_64937_p0() {
    mul_ln1118_616_fu_64937_p0 =  (sc_lv<12>) (sext_ln1116_16_cast_fu_52685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_616_fu_64937_p1() {
    mul_ln1118_616_fu_64937_p1 = tmp_616_reg_99637.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_616_fu_64937_p2() {
    mul_ln1118_616_fu_64937_p2 = (!mul_ln1118_616_fu_64937_p0.read().is_01() || !mul_ln1118_616_fu_64937_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_616_fu_64937_p0.read()) * sc_bigint<5>(mul_ln1118_616_fu_64937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_617_fu_64956_p0() {
    mul_ln1118_617_fu_64956_p0 =  (sc_lv<12>) (sext_ln1116_17_cast_fu_52707_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_617_fu_64956_p1() {
    mul_ln1118_617_fu_64956_p1 = tmp_617_reg_99642.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_617_fu_64956_p2() {
    mul_ln1118_617_fu_64956_p2 = (!mul_ln1118_617_fu_64956_p0.read().is_01() || !mul_ln1118_617_fu_64956_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_617_fu_64956_p0.read()) * sc_bigint<5>(mul_ln1118_617_fu_64956_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_618_fu_64975_p0() {
    mul_ln1118_618_fu_64975_p0 =  (sc_lv<12>) (sext_ln1116_18_cast_fu_52729_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_618_fu_64975_p1() {
    mul_ln1118_618_fu_64975_p1 = tmp_618_reg_99647.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_618_fu_64975_p2() {
    mul_ln1118_618_fu_64975_p2 = (!mul_ln1118_618_fu_64975_p0.read().is_01() || !mul_ln1118_618_fu_64975_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_618_fu_64975_p0.read()) * sc_bigint<5>(mul_ln1118_618_fu_64975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_619_fu_64994_p0() {
    mul_ln1118_619_fu_64994_p0 =  (sc_lv<12>) (sext_ln1116_19_cast_fu_52751_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_619_fu_64994_p1() {
    mul_ln1118_619_fu_64994_p1 = tmp_619_reg_99652.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_619_fu_64994_p2() {
    mul_ln1118_619_fu_64994_p2 = (!mul_ln1118_619_fu_64994_p0.read().is_01() || !mul_ln1118_619_fu_64994_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_619_fu_64994_p0.read()) * sc_bigint<5>(mul_ln1118_619_fu_64994_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_61_fu_53413_p0() {
    mul_ln1118_61_fu_53413_p0 =  (sc_lv<12>) (sext_ln1116_61_cast_fu_53407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_61_fu_53413_p1() {
    mul_ln1118_61_fu_53413_p1 = tmp_61_reg_96218.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_61_fu_53413_p2() {
    mul_ln1118_61_fu_53413_p2 = (!mul_ln1118_61_fu_53413_p0.read().is_01() || !mul_ln1118_61_fu_53413_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_61_fu_53413_p0.read()) * sc_bigint<5>(mul_ln1118_61_fu_53413_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_620_fu_65013_p0() {
    mul_ln1118_620_fu_65013_p0 =  (sc_lv<12>) (sext_ln1116_20_cast_fu_52773_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_620_fu_65013_p1() {
    mul_ln1118_620_fu_65013_p1 = tmp_620_reg_99657.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_620_fu_65013_p2() {
    mul_ln1118_620_fu_65013_p2 = (!mul_ln1118_620_fu_65013_p0.read().is_01() || !mul_ln1118_620_fu_65013_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_620_fu_65013_p0.read()) * sc_bigint<5>(mul_ln1118_620_fu_65013_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_621_fu_65032_p0() {
    mul_ln1118_621_fu_65032_p0 =  (sc_lv<12>) (sext_ln1116_21_cast_fu_52795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_621_fu_65032_p1() {
    mul_ln1118_621_fu_65032_p1 = tmp_621_reg_99662.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_621_fu_65032_p2() {
    mul_ln1118_621_fu_65032_p2 = (!mul_ln1118_621_fu_65032_p0.read().is_01() || !mul_ln1118_621_fu_65032_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_621_fu_65032_p0.read()) * sc_bigint<5>(mul_ln1118_621_fu_65032_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_622_fu_65051_p0() {
    mul_ln1118_622_fu_65051_p0 =  (sc_lv<12>) (sext_ln1116_22_cast_fu_52817_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_622_fu_65051_p1() {
    mul_ln1118_622_fu_65051_p1 = tmp_622_reg_99667.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_622_fu_65051_p2() {
    mul_ln1118_622_fu_65051_p2 = (!mul_ln1118_622_fu_65051_p0.read().is_01() || !mul_ln1118_622_fu_65051_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_622_fu_65051_p0.read()) * sc_bigint<5>(mul_ln1118_622_fu_65051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_623_fu_65070_p0() {
    mul_ln1118_623_fu_65070_p0 =  (sc_lv<12>) (sext_ln1116_23_cast_fu_52839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_623_fu_65070_p1() {
    mul_ln1118_623_fu_65070_p1 = tmp_623_reg_99672.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_623_fu_65070_p2() {
    mul_ln1118_623_fu_65070_p2 = (!mul_ln1118_623_fu_65070_p0.read().is_01() || !mul_ln1118_623_fu_65070_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_623_fu_65070_p0.read()) * sc_bigint<5>(mul_ln1118_623_fu_65070_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_624_fu_65089_p0() {
    mul_ln1118_624_fu_65089_p0 =  (sc_lv<12>) (sext_ln1116_24_cast_fu_52861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_624_fu_65089_p1() {
    mul_ln1118_624_fu_65089_p1 = tmp_624_reg_99677.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_624_fu_65089_p2() {
    mul_ln1118_624_fu_65089_p2 = (!mul_ln1118_624_fu_65089_p0.read().is_01() || !mul_ln1118_624_fu_65089_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_624_fu_65089_p0.read()) * sc_bigint<5>(mul_ln1118_624_fu_65089_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_625_fu_65108_p0() {
    mul_ln1118_625_fu_65108_p0 =  (sc_lv<12>) (sext_ln1116_25_cast_fu_52883_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_625_fu_65108_p1() {
    mul_ln1118_625_fu_65108_p1 = tmp_625_reg_99682.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_625_fu_65108_p2() {
    mul_ln1118_625_fu_65108_p2 = (!mul_ln1118_625_fu_65108_p0.read().is_01() || !mul_ln1118_625_fu_65108_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_625_fu_65108_p0.read()) * sc_bigint<5>(mul_ln1118_625_fu_65108_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_626_fu_65127_p0() {
    mul_ln1118_626_fu_65127_p0 =  (sc_lv<12>) (sext_ln1116_26_cast_fu_52905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_626_fu_65127_p1() {
    mul_ln1118_626_fu_65127_p1 = tmp_626_reg_99687.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_626_fu_65127_p2() {
    mul_ln1118_626_fu_65127_p2 = (!mul_ln1118_626_fu_65127_p0.read().is_01() || !mul_ln1118_626_fu_65127_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_626_fu_65127_p0.read()) * sc_bigint<5>(mul_ln1118_626_fu_65127_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_627_fu_65146_p0() {
    mul_ln1118_627_fu_65146_p0 =  (sc_lv<12>) (sext_ln1116_27_cast_fu_52927_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_627_fu_65146_p1() {
    mul_ln1118_627_fu_65146_p1 = tmp_627_reg_99692.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_627_fu_65146_p2() {
    mul_ln1118_627_fu_65146_p2 = (!mul_ln1118_627_fu_65146_p0.read().is_01() || !mul_ln1118_627_fu_65146_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_627_fu_65146_p0.read()) * sc_bigint<5>(mul_ln1118_627_fu_65146_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_628_fu_32495_p0() {
    mul_ln1118_628_fu_32495_p0 =  (sc_lv<12>) (sext_ln1116_28_cast_fu_22199_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_628_fu_32495_p1() {
    mul_ln1118_628_fu_32495_p1 = tmp_628_fu_32481_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_628_fu_32495_p2() {
    mul_ln1118_628_fu_32495_p2 = (!mul_ln1118_628_fu_32495_p0.read().is_01() || !mul_ln1118_628_fu_32495_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_628_fu_32495_p0.read()) * sc_bigint<5>(mul_ln1118_628_fu_32495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_629_fu_32525_p0() {
    mul_ln1118_629_fu_32525_p0 =  (sc_lv<12>) (sext_ln1116_29_cast_fu_22241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_629_fu_32525_p1() {
    mul_ln1118_629_fu_32525_p1 = tmp_629_fu_32511_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_629_fu_32525_p2() {
    mul_ln1118_629_fu_32525_p2 = (!mul_ln1118_629_fu_32525_p0.read().is_01() || !mul_ln1118_629_fu_32525_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_629_fu_32525_p0.read()) * sc_bigint<5>(mul_ln1118_629_fu_32525_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_62_fu_53435_p0() {
    mul_ln1118_62_fu_53435_p0 =  (sc_lv<12>) (sext_ln1116_62_cast_fu_53429_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_62_fu_53435_p1() {
    mul_ln1118_62_fu_53435_p1 = tmp_62_reg_96228.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_62_fu_53435_p2() {
    mul_ln1118_62_fu_53435_p2 = (!mul_ln1118_62_fu_53435_p0.read().is_01() || !mul_ln1118_62_fu_53435_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_62_fu_53435_p0.read()) * sc_bigint<5>(mul_ln1118_62_fu_53435_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_630_fu_32555_p0() {
    mul_ln1118_630_fu_32555_p0 =  (sc_lv<12>) (sext_ln1116_30_cast_fu_22283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_630_fu_32555_p1() {
    mul_ln1118_630_fu_32555_p1 = tmp_630_fu_32541_p4.read();
}

}

