#include "dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_630_fu_32555_p2() {
    mul_ln1118_630_fu_32555_p2 = (!mul_ln1118_630_fu_32555_p0.read().is_01() || !mul_ln1118_630_fu_32555_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_630_fu_32555_p0.read()) * sc_bigint<5>(mul_ln1118_630_fu_32555_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_631_fu_32585_p0() {
    mul_ln1118_631_fu_32585_p0 =  (sc_lv<12>) (sext_ln1116_31_cast_fu_22325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_631_fu_32585_p1() {
    mul_ln1118_631_fu_32585_p1 = tmp_631_fu_32571_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_631_fu_32585_p2() {
    mul_ln1118_631_fu_32585_p2 = (!mul_ln1118_631_fu_32585_p0.read().is_01() || !mul_ln1118_631_fu_32585_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_631_fu_32585_p0.read()) * sc_bigint<5>(mul_ln1118_631_fu_32585_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_632_fu_32615_p0() {
    mul_ln1118_632_fu_32615_p0 =  (sc_lv<12>) (sext_ln1116_32_cast_fu_22367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_632_fu_32615_p1() {
    mul_ln1118_632_fu_32615_p1 = tmp_632_fu_32601_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_632_fu_32615_p2() {
    mul_ln1118_632_fu_32615_p2 = (!mul_ln1118_632_fu_32615_p0.read().is_01() || !mul_ln1118_632_fu_32615_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_632_fu_32615_p0.read()) * sc_bigint<5>(mul_ln1118_632_fu_32615_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_633_fu_32645_p0() {
    mul_ln1118_633_fu_32645_p0 =  (sc_lv<12>) (sext_ln1116_33_cast_fu_22409_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_633_fu_32645_p1() {
    mul_ln1118_633_fu_32645_p1 = tmp_633_fu_32631_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_633_fu_32645_p2() {
    mul_ln1118_633_fu_32645_p2 = (!mul_ln1118_633_fu_32645_p0.read().is_01() || !mul_ln1118_633_fu_32645_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_633_fu_32645_p0.read()) * sc_bigint<5>(mul_ln1118_633_fu_32645_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_634_fu_65165_p0() {
    mul_ln1118_634_fu_65165_p0 =  (sc_lv<12>) (sext_ln1116_34_cast_fu_52949_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_634_fu_65165_p1() {
    mul_ln1118_634_fu_65165_p1 = tmp_634_reg_99727.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_634_fu_65165_p2() {
    mul_ln1118_634_fu_65165_p2 = (!mul_ln1118_634_fu_65165_p0.read().is_01() || !mul_ln1118_634_fu_65165_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_634_fu_65165_p0.read()) * sc_bigint<5>(mul_ln1118_634_fu_65165_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_635_fu_65184_p0() {
    mul_ln1118_635_fu_65184_p0 =  (sc_lv<12>) (sext_ln1116_35_cast_fu_52971_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_635_fu_65184_p1() {
    mul_ln1118_635_fu_65184_p1 = tmp_635_reg_99732.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_635_fu_65184_p2() {
    mul_ln1118_635_fu_65184_p2 = (!mul_ln1118_635_fu_65184_p0.read().is_01() || !mul_ln1118_635_fu_65184_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_635_fu_65184_p0.read()) * sc_bigint<5>(mul_ln1118_635_fu_65184_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_636_fu_65203_p0() {
    mul_ln1118_636_fu_65203_p0 =  (sc_lv<12>) (sext_ln1116_36_cast_fu_52993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_636_fu_65203_p1() {
    mul_ln1118_636_fu_65203_p1 = tmp_636_reg_99737.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_636_fu_65203_p2() {
    mul_ln1118_636_fu_65203_p2 = (!mul_ln1118_636_fu_65203_p0.read().is_01() || !mul_ln1118_636_fu_65203_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_636_fu_65203_p0.read()) * sc_bigint<5>(mul_ln1118_636_fu_65203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_637_fu_65222_p0() {
    mul_ln1118_637_fu_65222_p0 =  (sc_lv<12>) (sext_ln1116_37_cast_fu_53015_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_637_fu_65222_p1() {
    mul_ln1118_637_fu_65222_p1 = tmp_637_reg_99742.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_637_fu_65222_p2() {
    mul_ln1118_637_fu_65222_p2 = (!mul_ln1118_637_fu_65222_p0.read().is_01() || !mul_ln1118_637_fu_65222_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_637_fu_65222_p0.read()) * sc_bigint<5>(mul_ln1118_637_fu_65222_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_638_fu_65241_p0() {
    mul_ln1118_638_fu_65241_p0 =  (sc_lv<12>) (sext_ln1116_38_cast_fu_53037_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_638_fu_65241_p1() {
    mul_ln1118_638_fu_65241_p1 = tmp_638_reg_99747.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_638_fu_65241_p2() {
    mul_ln1118_638_fu_65241_p2 = (!mul_ln1118_638_fu_65241_p0.read().is_01() || !mul_ln1118_638_fu_65241_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_638_fu_65241_p0.read()) * sc_bigint<5>(mul_ln1118_638_fu_65241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_639_fu_65260_p0() {
    mul_ln1118_639_fu_65260_p0 =  (sc_lv<12>) (sext_ln1116_39_cast_fu_53059_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_639_fu_65260_p1() {
    mul_ln1118_639_fu_65260_p1 = tmp_639_reg_99752.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_639_fu_65260_p2() {
    mul_ln1118_639_fu_65260_p2 = (!mul_ln1118_639_fu_65260_p0.read().is_01() || !mul_ln1118_639_fu_65260_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_639_fu_65260_p0.read()) * sc_bigint<5>(mul_ln1118_639_fu_65260_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_63_fu_53457_p0() {
    mul_ln1118_63_fu_53457_p0 =  (sc_lv<12>) (sext_ln1116_63_cast_fu_53451_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_63_fu_53457_p1() {
    mul_ln1118_63_fu_53457_p1 = tmp_63_reg_96238.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_63_fu_53457_p2() {
    mul_ln1118_63_fu_53457_p2 = (!mul_ln1118_63_fu_53457_p0.read().is_01() || !mul_ln1118_63_fu_53457_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_63_fu_53457_p0.read()) * sc_bigint<5>(mul_ln1118_63_fu_53457_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_640_fu_65279_p0() {
    mul_ln1118_640_fu_65279_p0 =  (sc_lv<12>) (sext_ln1116_40_cast_fu_53081_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_640_fu_65279_p1() {
    mul_ln1118_640_fu_65279_p1 = tmp_640_reg_99757.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_640_fu_65279_p2() {
    mul_ln1118_640_fu_65279_p2 = (!mul_ln1118_640_fu_65279_p0.read().is_01() || !mul_ln1118_640_fu_65279_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_640_fu_65279_p0.read()) * sc_bigint<5>(mul_ln1118_640_fu_65279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_641_fu_65298_p0() {
    mul_ln1118_641_fu_65298_p0 =  (sc_lv<12>) (sext_ln1116_41_cast_fu_53103_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_641_fu_65298_p1() {
    mul_ln1118_641_fu_65298_p1 = tmp_641_reg_99762.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_641_fu_65298_p2() {
    mul_ln1118_641_fu_65298_p2 = (!mul_ln1118_641_fu_65298_p0.read().is_01() || !mul_ln1118_641_fu_65298_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_641_fu_65298_p0.read()) * sc_bigint<5>(mul_ln1118_641_fu_65298_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_642_fu_65317_p0() {
    mul_ln1118_642_fu_65317_p0 =  (sc_lv<12>) (sext_ln1116_42_cast_fu_53125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_642_fu_65317_p1() {
    mul_ln1118_642_fu_65317_p1 = tmp_642_reg_99767.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_642_fu_65317_p2() {
    mul_ln1118_642_fu_65317_p2 = (!mul_ln1118_642_fu_65317_p0.read().is_01() || !mul_ln1118_642_fu_65317_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_642_fu_65317_p0.read()) * sc_bigint<5>(mul_ln1118_642_fu_65317_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_643_fu_65336_p0() {
    mul_ln1118_643_fu_65336_p0 =  (sc_lv<12>) (sext_ln1116_43_cast_fu_53147_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_643_fu_65336_p1() {
    mul_ln1118_643_fu_65336_p1 = tmp_643_reg_99772.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_643_fu_65336_p2() {
    mul_ln1118_643_fu_65336_p2 = (!mul_ln1118_643_fu_65336_p0.read().is_01() || !mul_ln1118_643_fu_65336_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_643_fu_65336_p0.read()) * sc_bigint<5>(mul_ln1118_643_fu_65336_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_644_fu_65355_p0() {
    mul_ln1118_644_fu_65355_p0 =  (sc_lv<12>) (sext_ln1116_44_cast_fu_53169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_644_fu_65355_p1() {
    mul_ln1118_644_fu_65355_p1 = tmp_644_reg_99777.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_644_fu_65355_p2() {
    mul_ln1118_644_fu_65355_p2 = (!mul_ln1118_644_fu_65355_p0.read().is_01() || !mul_ln1118_644_fu_65355_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_644_fu_65355_p0.read()) * sc_bigint<5>(mul_ln1118_644_fu_65355_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_645_fu_65374_p0() {
    mul_ln1118_645_fu_65374_p0 =  (sc_lv<12>) (sext_ln1116_45_cast_fu_53191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_645_fu_65374_p1() {
    mul_ln1118_645_fu_65374_p1 = tmp_645_reg_99782.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_645_fu_65374_p2() {
    mul_ln1118_645_fu_65374_p2 = (!mul_ln1118_645_fu_65374_p0.read().is_01() || !mul_ln1118_645_fu_65374_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_645_fu_65374_p0.read()) * sc_bigint<5>(mul_ln1118_645_fu_65374_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_646_fu_65393_p0() {
    mul_ln1118_646_fu_65393_p0 =  (sc_lv<12>) (sext_ln1116_46_cast_fu_53213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_646_fu_65393_p1() {
    mul_ln1118_646_fu_65393_p1 = tmp_646_reg_99787.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_646_fu_65393_p2() {
    mul_ln1118_646_fu_65393_p2 = (!mul_ln1118_646_fu_65393_p0.read().is_01() || !mul_ln1118_646_fu_65393_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_646_fu_65393_p0.read()) * sc_bigint<5>(mul_ln1118_646_fu_65393_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_647_fu_65412_p0() {
    mul_ln1118_647_fu_65412_p0 =  (sc_lv<12>) (sext_ln1116_47_cast_fu_53235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_647_fu_65412_p1() {
    mul_ln1118_647_fu_65412_p1 = tmp_647_reg_99792.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_647_fu_65412_p2() {
    mul_ln1118_647_fu_65412_p2 = (!mul_ln1118_647_fu_65412_p0.read().is_01() || !mul_ln1118_647_fu_65412_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_647_fu_65412_p0.read()) * sc_bigint<5>(mul_ln1118_647_fu_65412_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_648_fu_65431_p0() {
    mul_ln1118_648_fu_65431_p0 =  (sc_lv<12>) (sext_ln1116_48_cast_fu_53257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_648_fu_65431_p1() {
    mul_ln1118_648_fu_65431_p1 = tmp_648_reg_99797.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_648_fu_65431_p2() {
    mul_ln1118_648_fu_65431_p2 = (!mul_ln1118_648_fu_65431_p0.read().is_01() || !mul_ln1118_648_fu_65431_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_648_fu_65431_p0.read()) * sc_bigint<5>(mul_ln1118_648_fu_65431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_649_fu_65450_p0() {
    mul_ln1118_649_fu_65450_p0 =  (sc_lv<12>) (sext_ln1116_49_cast_fu_53279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_649_fu_65450_p1() {
    mul_ln1118_649_fu_65450_p1 = tmp_649_reg_99802.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_649_fu_65450_p2() {
    mul_ln1118_649_fu_65450_p2 = (!mul_ln1118_649_fu_65450_p0.read().is_01() || !mul_ln1118_649_fu_65450_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_649_fu_65450_p0.read()) * sc_bigint<5>(mul_ln1118_649_fu_65450_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_64_fu_53479_p0() {
    mul_ln1118_64_fu_53479_p0 =  (sc_lv<12>) (sext_ln1116_64_cast_fu_53473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_64_fu_53479_p1() {
    mul_ln1118_64_fu_53479_p1 = tmp_64_reg_96248.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_64_fu_53479_p2() {
    mul_ln1118_64_fu_53479_p2 = (!mul_ln1118_64_fu_53479_p0.read().is_01() || !mul_ln1118_64_fu_53479_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_64_fu_53479_p0.read()) * sc_bigint<5>(mul_ln1118_64_fu_53479_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_650_fu_65469_p0() {
    mul_ln1118_650_fu_65469_p0 =  (sc_lv<12>) (sext_ln1116_50_cast_fu_53301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_650_fu_65469_p1() {
    mul_ln1118_650_fu_65469_p1 = tmp_650_reg_99807.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_650_fu_65469_p2() {
    mul_ln1118_650_fu_65469_p2 = (!mul_ln1118_650_fu_65469_p0.read().is_01() || !mul_ln1118_650_fu_65469_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_650_fu_65469_p0.read()) * sc_bigint<5>(mul_ln1118_650_fu_65469_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_651_fu_65488_p0() {
    mul_ln1118_651_fu_65488_p0 =  (sc_lv<12>) (sext_ln1116_51_cast_fu_53323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_651_fu_65488_p1() {
    mul_ln1118_651_fu_65488_p1 = tmp_651_reg_99812.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_651_fu_65488_p2() {
    mul_ln1118_651_fu_65488_p2 = (!mul_ln1118_651_fu_65488_p0.read().is_01() || !mul_ln1118_651_fu_65488_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_651_fu_65488_p0.read()) * sc_bigint<5>(mul_ln1118_651_fu_65488_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_652_fu_65507_p0() {
    mul_ln1118_652_fu_65507_p0 =  (sc_lv<12>) (sext_ln1116_52_cast_reg_96150.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_652_fu_65507_p1() {
    mul_ln1118_652_fu_65507_p1 = tmp_652_reg_99817.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_652_fu_65507_p2() {
    mul_ln1118_652_fu_65507_p2 = (!mul_ln1118_652_fu_65507_p0.read().is_01() || !mul_ln1118_652_fu_65507_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_652_fu_65507_p0.read()) * sc_bigint<5>(mul_ln1118_652_fu_65507_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_653_fu_32865_p0() {
    mul_ln1118_653_fu_32865_p0 =  (sc_lv<12>) (sext_ln1116_53_cast_fu_22797_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_653_fu_32865_p1() {
    mul_ln1118_653_fu_32865_p1 = tmp_653_fu_32851_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_653_fu_32865_p2() {
    mul_ln1118_653_fu_32865_p2 = (!mul_ln1118_653_fu_32865_p0.read().is_01() || !mul_ln1118_653_fu_32865_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_653_fu_32865_p0.read()) * sc_bigint<5>(mul_ln1118_653_fu_32865_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_654_fu_32895_p0() {
    mul_ln1118_654_fu_32895_p0 =  (sc_lv<12>) (sext_ln1116_54_cast_fu_22839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_654_fu_32895_p1() {
    mul_ln1118_654_fu_32895_p1 = tmp_654_fu_32881_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_654_fu_32895_p2() {
    mul_ln1118_654_fu_32895_p2 = (!mul_ln1118_654_fu_32895_p0.read().is_01() || !mul_ln1118_654_fu_32895_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_654_fu_32895_p0.read()) * sc_bigint<5>(mul_ln1118_654_fu_32895_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_655_fu_32925_p0() {
    mul_ln1118_655_fu_32925_p0 =  (sc_lv<12>) (sext_ln1116_55_cast_fu_22881_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_655_fu_32925_p1() {
    mul_ln1118_655_fu_32925_p1 = tmp_655_fu_32911_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_655_fu_32925_p2() {
    mul_ln1118_655_fu_32925_p2 = (!mul_ln1118_655_fu_32925_p0.read().is_01() || !mul_ln1118_655_fu_32925_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_655_fu_32925_p0.read()) * sc_bigint<5>(mul_ln1118_655_fu_32925_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_656_fu_32955_p0() {
    mul_ln1118_656_fu_32955_p0 =  (sc_lv<12>) (sext_ln1116_56_cast_fu_22923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_656_fu_32955_p1() {
    mul_ln1118_656_fu_32955_p1 = tmp_656_fu_32941_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_656_fu_32955_p2() {
    mul_ln1118_656_fu_32955_p2 = (!mul_ln1118_656_fu_32955_p0.read().is_01() || !mul_ln1118_656_fu_32955_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_656_fu_32955_p0.read()) * sc_bigint<5>(mul_ln1118_656_fu_32955_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_657_fu_32985_p0() {
    mul_ln1118_657_fu_32985_p0 =  (sc_lv<12>) (sext_ln1116_57_cast_fu_22965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_657_fu_32985_p1() {
    mul_ln1118_657_fu_32985_p1 = tmp_657_fu_32971_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_657_fu_32985_p2() {
    mul_ln1118_657_fu_32985_p2 = (!mul_ln1118_657_fu_32985_p0.read().is_01() || !mul_ln1118_657_fu_32985_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_657_fu_32985_p0.read()) * sc_bigint<5>(mul_ln1118_657_fu_32985_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_658_fu_33015_p0() {
    mul_ln1118_658_fu_33015_p0 =  (sc_lv<12>) (sext_ln1116_58_cast_fu_23007_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_658_fu_33015_p1() {
    mul_ln1118_658_fu_33015_p1 = tmp_658_fu_33001_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_658_fu_33015_p2() {
    mul_ln1118_658_fu_33015_p2 = (!mul_ln1118_658_fu_33015_p0.read().is_01() || !mul_ln1118_658_fu_33015_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_658_fu_33015_p0.read()) * sc_bigint<5>(mul_ln1118_658_fu_33015_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_659_fu_65525_p0() {
    mul_ln1118_659_fu_65525_p0 =  (sc_lv<12>) (sext_ln1116_59_cast_fu_53363_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_659_fu_65525_p1() {
    mul_ln1118_659_fu_65525_p1 = tmp_659_reg_99852.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_659_fu_65525_p2() {
    mul_ln1118_659_fu_65525_p2 = (!mul_ln1118_659_fu_65525_p0.read().is_01() || !mul_ln1118_659_fu_65525_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_659_fu_65525_p0.read()) * sc_bigint<5>(mul_ln1118_659_fu_65525_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_65_fu_53501_p0() {
    mul_ln1118_65_fu_53501_p0 =  (sc_lv<12>) (sext_ln1116_65_cast_fu_53495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_65_fu_53501_p1() {
    mul_ln1118_65_fu_53501_p1 = tmp_65_reg_96258.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_65_fu_53501_p2() {
    mul_ln1118_65_fu_53501_p2 = (!mul_ln1118_65_fu_53501_p0.read().is_01() || !mul_ln1118_65_fu_53501_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_65_fu_53501_p0.read()) * sc_bigint<5>(mul_ln1118_65_fu_53501_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_660_fu_65544_p0() {
    mul_ln1118_660_fu_65544_p0 =  (sc_lv<12>) (sext_ln1116_60_cast_fu_53385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_660_fu_65544_p1() {
    mul_ln1118_660_fu_65544_p1 = tmp_660_reg_99857.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_660_fu_65544_p2() {
    mul_ln1118_660_fu_65544_p2 = (!mul_ln1118_660_fu_65544_p0.read().is_01() || !mul_ln1118_660_fu_65544_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_660_fu_65544_p0.read()) * sc_bigint<5>(mul_ln1118_660_fu_65544_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_661_fu_65563_p0() {
    mul_ln1118_661_fu_65563_p0 =  (sc_lv<12>) (sext_ln1116_61_cast_fu_53407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_661_fu_65563_p1() {
    mul_ln1118_661_fu_65563_p1 = tmp_661_reg_99862.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_661_fu_65563_p2() {
    mul_ln1118_661_fu_65563_p2 = (!mul_ln1118_661_fu_65563_p0.read().is_01() || !mul_ln1118_661_fu_65563_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_661_fu_65563_p0.read()) * sc_bigint<5>(mul_ln1118_661_fu_65563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_662_fu_65582_p0() {
    mul_ln1118_662_fu_65582_p0 =  (sc_lv<12>) (sext_ln1116_62_cast_fu_53429_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_662_fu_65582_p1() {
    mul_ln1118_662_fu_65582_p1 = tmp_662_reg_99867.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_662_fu_65582_p2() {
    mul_ln1118_662_fu_65582_p2 = (!mul_ln1118_662_fu_65582_p0.read().is_01() || !mul_ln1118_662_fu_65582_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_662_fu_65582_p0.read()) * sc_bigint<5>(mul_ln1118_662_fu_65582_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_663_fu_65601_p0() {
    mul_ln1118_663_fu_65601_p0 =  (sc_lv<12>) (sext_ln1116_63_cast_fu_53451_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_663_fu_65601_p1() {
    mul_ln1118_663_fu_65601_p1 = tmp_663_reg_99872.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_663_fu_65601_p2() {
    mul_ln1118_663_fu_65601_p2 = (!mul_ln1118_663_fu_65601_p0.read().is_01() || !mul_ln1118_663_fu_65601_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_663_fu_65601_p0.read()) * sc_bigint<5>(mul_ln1118_663_fu_65601_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_664_fu_65620_p0() {
    mul_ln1118_664_fu_65620_p0 =  (sc_lv<12>) (sext_ln1116_64_cast_fu_53473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_664_fu_65620_p1() {
    mul_ln1118_664_fu_65620_p1 = tmp_664_reg_99877.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_664_fu_65620_p2() {
    mul_ln1118_664_fu_65620_p2 = (!mul_ln1118_664_fu_65620_p0.read().is_01() || !mul_ln1118_664_fu_65620_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_664_fu_65620_p0.read()) * sc_bigint<5>(mul_ln1118_664_fu_65620_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_665_fu_65639_p0() {
    mul_ln1118_665_fu_65639_p0 =  (sc_lv<12>) (sext_ln1116_65_cast_fu_53495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_665_fu_65639_p1() {
    mul_ln1118_665_fu_65639_p1 = tmp_665_reg_99882.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_665_fu_65639_p2() {
    mul_ln1118_665_fu_65639_p2 = (!mul_ln1118_665_fu_65639_p0.read().is_01() || !mul_ln1118_665_fu_65639_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_665_fu_65639_p0.read()) * sc_bigint<5>(mul_ln1118_665_fu_65639_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_666_fu_65658_p0() {
    mul_ln1118_666_fu_65658_p0 =  (sc_lv<12>) (sext_ln1116_66_cast_fu_53517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_666_fu_65658_p1() {
    mul_ln1118_666_fu_65658_p1 = tmp_666_reg_99887.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_666_fu_65658_p2() {
    mul_ln1118_666_fu_65658_p2 = (!mul_ln1118_666_fu_65658_p0.read().is_01() || !mul_ln1118_666_fu_65658_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_666_fu_65658_p0.read()) * sc_bigint<5>(mul_ln1118_666_fu_65658_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_667_fu_65677_p0() {
    mul_ln1118_667_fu_65677_p0 =  (sc_lv<12>) (sext_ln1116_67_cast_fu_53539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_667_fu_65677_p1() {
    mul_ln1118_667_fu_65677_p1 = tmp_667_reg_99892.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_667_fu_65677_p2() {
    mul_ln1118_667_fu_65677_p2 = (!mul_ln1118_667_fu_65677_p0.read().is_01() || !mul_ln1118_667_fu_65677_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_667_fu_65677_p0.read()) * sc_bigint<5>(mul_ln1118_667_fu_65677_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_668_fu_65696_p0() {
    mul_ln1118_668_fu_65696_p0 =  (sc_lv<12>) (sext_ln1116_68_cast_fu_53561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_668_fu_65696_p1() {
    mul_ln1118_668_fu_65696_p1 = tmp_668_reg_99897.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_668_fu_65696_p2() {
    mul_ln1118_668_fu_65696_p2 = (!mul_ln1118_668_fu_65696_p0.read().is_01() || !mul_ln1118_668_fu_65696_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_668_fu_65696_p0.read()) * sc_bigint<5>(mul_ln1118_668_fu_65696_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_669_fu_65715_p0() {
    mul_ln1118_669_fu_65715_p0 =  (sc_lv<12>) (sext_ln1116_69_cast_fu_53583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_669_fu_65715_p1() {
    mul_ln1118_669_fu_65715_p1 = tmp_669_reg_99902.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_669_fu_65715_p2() {
    mul_ln1118_669_fu_65715_p2 = (!mul_ln1118_669_fu_65715_p0.read().is_01() || !mul_ln1118_669_fu_65715_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_669_fu_65715_p0.read()) * sc_bigint<5>(mul_ln1118_669_fu_65715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_66_fu_53523_p0() {
    mul_ln1118_66_fu_53523_p0 =  (sc_lv<12>) (sext_ln1116_66_cast_fu_53517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_66_fu_53523_p1() {
    mul_ln1118_66_fu_53523_p1 = tmp_66_reg_96268.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_66_fu_53523_p2() {
    mul_ln1118_66_fu_53523_p2 = (!mul_ln1118_66_fu_53523_p0.read().is_01() || !mul_ln1118_66_fu_53523_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_66_fu_53523_p0.read()) * sc_bigint<5>(mul_ln1118_66_fu_53523_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_670_fu_65734_p0() {
    mul_ln1118_670_fu_65734_p0 =  (sc_lv<12>) (sext_ln1116_70_cast_fu_53605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_670_fu_65734_p1() {
    mul_ln1118_670_fu_65734_p1 = tmp_670_reg_99907.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_670_fu_65734_p2() {
    mul_ln1118_670_fu_65734_p2 = (!mul_ln1118_670_fu_65734_p0.read().is_01() || !mul_ln1118_670_fu_65734_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_670_fu_65734_p0.read()) * sc_bigint<5>(mul_ln1118_670_fu_65734_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_671_fu_65753_p0() {
    mul_ln1118_671_fu_65753_p0 =  (sc_lv<12>) (sext_ln1116_71_cast_fu_53627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_671_fu_65753_p1() {
    mul_ln1118_671_fu_65753_p1 = tmp_671_reg_99912.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_671_fu_65753_p2() {
    mul_ln1118_671_fu_65753_p2 = (!mul_ln1118_671_fu_65753_p0.read().is_01() || !mul_ln1118_671_fu_65753_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_671_fu_65753_p0.read()) * sc_bigint<5>(mul_ln1118_671_fu_65753_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_672_fu_65772_p0() {
    mul_ln1118_672_fu_65772_p0 =  (sc_lv<12>) (sext_ln1116_72_cast_fu_53649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_672_fu_65772_p1() {
    mul_ln1118_672_fu_65772_p1 = tmp_672_reg_99917.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_672_fu_65772_p2() {
    mul_ln1118_672_fu_65772_p2 = (!mul_ln1118_672_fu_65772_p0.read().is_01() || !mul_ln1118_672_fu_65772_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_672_fu_65772_p0.read()) * sc_bigint<5>(mul_ln1118_672_fu_65772_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_673_fu_65791_p0() {
    mul_ln1118_673_fu_65791_p0 =  (sc_lv<12>) (sext_ln1116_73_cast_fu_53671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_673_fu_65791_p1() {
    mul_ln1118_673_fu_65791_p1 = tmp_673_reg_99922.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_673_fu_65791_p2() {
    mul_ln1118_673_fu_65791_p2 = (!mul_ln1118_673_fu_65791_p0.read().is_01() || !mul_ln1118_673_fu_65791_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_673_fu_65791_p0.read()) * sc_bigint<5>(mul_ln1118_673_fu_65791_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_674_fu_65810_p0() {
    mul_ln1118_674_fu_65810_p0 =  (sc_lv<12>) (sext_ln1116_74_cast_fu_53693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_674_fu_65810_p1() {
    mul_ln1118_674_fu_65810_p1 = tmp_674_reg_99927.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_674_fu_65810_p2() {
    mul_ln1118_674_fu_65810_p2 = (!mul_ln1118_674_fu_65810_p0.read().is_01() || !mul_ln1118_674_fu_65810_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_674_fu_65810_p0.read()) * sc_bigint<5>(mul_ln1118_674_fu_65810_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_675_fu_65829_p0() {
    mul_ln1118_675_fu_65829_p0 =  (sc_lv<12>) (sext_ln1116_75_cast_fu_53715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_675_fu_65829_p1() {
    mul_ln1118_675_fu_65829_p1 = tmp_675_reg_99932.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_675_fu_65829_p2() {
    mul_ln1118_675_fu_65829_p2 = (!mul_ln1118_675_fu_65829_p0.read().is_01() || !mul_ln1118_675_fu_65829_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_675_fu_65829_p0.read()) * sc_bigint<5>(mul_ln1118_675_fu_65829_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_676_fu_65848_p0() {
    mul_ln1118_676_fu_65848_p0 =  (sc_lv<12>) (sext_ln1116_76_cast_fu_53737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_676_fu_65848_p1() {
    mul_ln1118_676_fu_65848_p1 = tmp_676_reg_99937.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_676_fu_65848_p2() {
    mul_ln1118_676_fu_65848_p2 = (!mul_ln1118_676_fu_65848_p0.read().is_01() || !mul_ln1118_676_fu_65848_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_676_fu_65848_p0.read()) * sc_bigint<5>(mul_ln1118_676_fu_65848_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_677_fu_65867_p0() {
    mul_ln1118_677_fu_65867_p0 =  (sc_lv<12>) (sext_ln1116_77_cast_reg_96378.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_677_fu_65867_p1() {
    mul_ln1118_677_fu_65867_p1 = tmp_677_reg_99942.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_677_fu_65867_p2() {
    mul_ln1118_677_fu_65867_p2 = (!mul_ln1118_677_fu_65867_p0.read().is_01() || !mul_ln1118_677_fu_65867_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_677_fu_65867_p0.read()) * sc_bigint<5>(mul_ln1118_677_fu_65867_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_678_fu_33235_p0() {
    mul_ln1118_678_fu_33235_p0 =  (sc_lv<12>) (sext_ln1116_78_cast_fu_23395_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_678_fu_33235_p1() {
    mul_ln1118_678_fu_33235_p1 = tmp_678_fu_33221_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_678_fu_33235_p2() {
    mul_ln1118_678_fu_33235_p2 = (!mul_ln1118_678_fu_33235_p0.read().is_01() || !mul_ln1118_678_fu_33235_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_678_fu_33235_p0.read()) * sc_bigint<5>(mul_ln1118_678_fu_33235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_679_fu_33265_p0() {
    mul_ln1118_679_fu_33265_p0 =  (sc_lv<12>) (sext_ln1116_79_cast_fu_23437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_679_fu_33265_p1() {
    mul_ln1118_679_fu_33265_p1 = tmp_679_fu_33251_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_679_fu_33265_p2() {
    mul_ln1118_679_fu_33265_p2 = (!mul_ln1118_679_fu_33265_p0.read().is_01() || !mul_ln1118_679_fu_33265_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_679_fu_33265_p0.read()) * sc_bigint<5>(mul_ln1118_679_fu_33265_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_67_fu_53545_p0() {
    mul_ln1118_67_fu_53545_p0 =  (sc_lv<12>) (sext_ln1116_67_cast_fu_53539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_67_fu_53545_p1() {
    mul_ln1118_67_fu_53545_p1 = tmp_67_reg_96278.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_67_fu_53545_p2() {
    mul_ln1118_67_fu_53545_p2 = (!mul_ln1118_67_fu_53545_p0.read().is_01() || !mul_ln1118_67_fu_53545_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_67_fu_53545_p0.read()) * sc_bigint<5>(mul_ln1118_67_fu_53545_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_680_fu_33295_p0() {
    mul_ln1118_680_fu_33295_p0 =  (sc_lv<12>) (sext_ln1116_80_cast_fu_23479_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_680_fu_33295_p1() {
    mul_ln1118_680_fu_33295_p1 = tmp_680_fu_33281_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_680_fu_33295_p2() {
    mul_ln1118_680_fu_33295_p2 = (!mul_ln1118_680_fu_33295_p0.read().is_01() || !mul_ln1118_680_fu_33295_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_680_fu_33295_p0.read()) * sc_bigint<5>(mul_ln1118_680_fu_33295_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_681_fu_33325_p0() {
    mul_ln1118_681_fu_33325_p0 =  (sc_lv<12>) (sext_ln1116_81_cast_fu_23521_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_681_fu_33325_p1() {
    mul_ln1118_681_fu_33325_p1 = tmp_681_fu_33311_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_681_fu_33325_p2() {
    mul_ln1118_681_fu_33325_p2 = (!mul_ln1118_681_fu_33325_p0.read().is_01() || !mul_ln1118_681_fu_33325_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_681_fu_33325_p0.read()) * sc_bigint<5>(mul_ln1118_681_fu_33325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_682_fu_33355_p0() {
    mul_ln1118_682_fu_33355_p0 =  (sc_lv<12>) (sext_ln1116_82_cast_fu_23563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_682_fu_33355_p1() {
    mul_ln1118_682_fu_33355_p1 = tmp_682_fu_33341_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_682_fu_33355_p2() {
    mul_ln1118_682_fu_33355_p2 = (!mul_ln1118_682_fu_33355_p0.read().is_01() || !mul_ln1118_682_fu_33355_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_682_fu_33355_p0.read()) * sc_bigint<5>(mul_ln1118_682_fu_33355_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_683_fu_33385_p0() {
    mul_ln1118_683_fu_33385_p0 =  (sc_lv<12>) (sext_ln1116_83_cast_fu_23605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_683_fu_33385_p1() {
    mul_ln1118_683_fu_33385_p1 = tmp_683_fu_33371_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_683_fu_33385_p2() {
    mul_ln1118_683_fu_33385_p2 = (!mul_ln1118_683_fu_33385_p0.read().is_01() || !mul_ln1118_683_fu_33385_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_683_fu_33385_p0.read()) * sc_bigint<5>(mul_ln1118_683_fu_33385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_684_fu_65885_p0() {
    mul_ln1118_684_fu_65885_p0 =  (sc_lv<12>) (sext_ln1116_84_cast_fu_53777_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_684_fu_65885_p1() {
    mul_ln1118_684_fu_65885_p1 = tmp_684_reg_99977.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_684_fu_65885_p2() {
    mul_ln1118_684_fu_65885_p2 = (!mul_ln1118_684_fu_65885_p0.read().is_01() || !mul_ln1118_684_fu_65885_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_684_fu_65885_p0.read()) * sc_bigint<5>(mul_ln1118_684_fu_65885_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_685_fu_65904_p0() {
    mul_ln1118_685_fu_65904_p0 =  (sc_lv<12>) (sext_ln1116_85_cast_fu_53799_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_685_fu_65904_p1() {
    mul_ln1118_685_fu_65904_p1 = tmp_685_reg_99982.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_685_fu_65904_p2() {
    mul_ln1118_685_fu_65904_p2 = (!mul_ln1118_685_fu_65904_p0.read().is_01() || !mul_ln1118_685_fu_65904_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_685_fu_65904_p0.read()) * sc_bigint<5>(mul_ln1118_685_fu_65904_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_686_fu_65923_p0() {
    mul_ln1118_686_fu_65923_p0 =  (sc_lv<12>) (sext_ln1116_86_cast_fu_53821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_686_fu_65923_p1() {
    mul_ln1118_686_fu_65923_p1 = tmp_686_reg_99987.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_686_fu_65923_p2() {
    mul_ln1118_686_fu_65923_p2 = (!mul_ln1118_686_fu_65923_p0.read().is_01() || !mul_ln1118_686_fu_65923_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_686_fu_65923_p0.read()) * sc_bigint<5>(mul_ln1118_686_fu_65923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_687_fu_65942_p0() {
    mul_ln1118_687_fu_65942_p0 =  (sc_lv<12>) (sext_ln1116_87_cast_fu_53843_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_687_fu_65942_p1() {
    mul_ln1118_687_fu_65942_p1 = tmp_687_reg_99992.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_687_fu_65942_p2() {
    mul_ln1118_687_fu_65942_p2 = (!mul_ln1118_687_fu_65942_p0.read().is_01() || !mul_ln1118_687_fu_65942_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_687_fu_65942_p0.read()) * sc_bigint<5>(mul_ln1118_687_fu_65942_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_688_fu_65961_p0() {
    mul_ln1118_688_fu_65961_p0 =  (sc_lv<12>) (sext_ln1116_88_cast_fu_53865_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_688_fu_65961_p1() {
    mul_ln1118_688_fu_65961_p1 = tmp_688_reg_99997.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_688_fu_65961_p2() {
    mul_ln1118_688_fu_65961_p2 = (!mul_ln1118_688_fu_65961_p0.read().is_01() || !mul_ln1118_688_fu_65961_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_688_fu_65961_p0.read()) * sc_bigint<5>(mul_ln1118_688_fu_65961_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_689_fu_65980_p0() {
    mul_ln1118_689_fu_65980_p0 =  (sc_lv<12>) (sext_ln1116_89_cast_fu_53887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_689_fu_65980_p1() {
    mul_ln1118_689_fu_65980_p1 = tmp_689_reg_100002.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_689_fu_65980_p2() {
    mul_ln1118_689_fu_65980_p2 = (!mul_ln1118_689_fu_65980_p0.read().is_01() || !mul_ln1118_689_fu_65980_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_689_fu_65980_p0.read()) * sc_bigint<5>(mul_ln1118_689_fu_65980_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_68_fu_53567_p0() {
    mul_ln1118_68_fu_53567_p0 =  (sc_lv<12>) (sext_ln1116_68_cast_fu_53561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_68_fu_53567_p1() {
    mul_ln1118_68_fu_53567_p1 = tmp_68_reg_96288.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_68_fu_53567_p2() {
    mul_ln1118_68_fu_53567_p2 = (!mul_ln1118_68_fu_53567_p0.read().is_01() || !mul_ln1118_68_fu_53567_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_68_fu_53567_p0.read()) * sc_bigint<5>(mul_ln1118_68_fu_53567_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_690_fu_65999_p0() {
    mul_ln1118_690_fu_65999_p0 =  (sc_lv<12>) (sext_ln1116_90_cast_fu_53909_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_690_fu_65999_p1() {
    mul_ln1118_690_fu_65999_p1 = tmp_690_reg_100007.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_690_fu_65999_p2() {
    mul_ln1118_690_fu_65999_p2 = (!mul_ln1118_690_fu_65999_p0.read().is_01() || !mul_ln1118_690_fu_65999_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_690_fu_65999_p0.read()) * sc_bigint<5>(mul_ln1118_690_fu_65999_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_691_fu_66018_p0() {
    mul_ln1118_691_fu_66018_p0 =  (sc_lv<12>) (sext_ln1116_91_cast_fu_53931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_691_fu_66018_p1() {
    mul_ln1118_691_fu_66018_p1 = tmp_691_reg_100012.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_691_fu_66018_p2() {
    mul_ln1118_691_fu_66018_p2 = (!mul_ln1118_691_fu_66018_p0.read().is_01() || !mul_ln1118_691_fu_66018_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_691_fu_66018_p0.read()) * sc_bigint<5>(mul_ln1118_691_fu_66018_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_692_fu_66037_p0() {
    mul_ln1118_692_fu_66037_p0 =  (sc_lv<12>) (sext_ln1116_92_cast_fu_53953_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_692_fu_66037_p1() {
    mul_ln1118_692_fu_66037_p1 = tmp_692_reg_100017.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_692_fu_66037_p2() {
    mul_ln1118_692_fu_66037_p2 = (!mul_ln1118_692_fu_66037_p0.read().is_01() || !mul_ln1118_692_fu_66037_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_692_fu_66037_p0.read()) * sc_bigint<5>(mul_ln1118_692_fu_66037_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_693_fu_66056_p0() {
    mul_ln1118_693_fu_66056_p0 =  (sc_lv<12>) (sext_ln1116_93_cast_fu_53975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_693_fu_66056_p1() {
    mul_ln1118_693_fu_66056_p1 = tmp_693_reg_100022.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_693_fu_66056_p2() {
    mul_ln1118_693_fu_66056_p2 = (!mul_ln1118_693_fu_66056_p0.read().is_01() || !mul_ln1118_693_fu_66056_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_693_fu_66056_p0.read()) * sc_bigint<5>(mul_ln1118_693_fu_66056_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_694_fu_66075_p0() {
    mul_ln1118_694_fu_66075_p0 =  (sc_lv<12>) (sext_ln1116_94_cast_fu_53997_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_694_fu_66075_p1() {
    mul_ln1118_694_fu_66075_p1 = tmp_694_reg_100027.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_694_fu_66075_p2() {
    mul_ln1118_694_fu_66075_p2 = (!mul_ln1118_694_fu_66075_p0.read().is_01() || !mul_ln1118_694_fu_66075_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_694_fu_66075_p0.read()) * sc_bigint<5>(mul_ln1118_694_fu_66075_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_695_fu_66094_p0() {
    mul_ln1118_695_fu_66094_p0 =  (sc_lv<12>) (sext_ln1116_95_cast_fu_54019_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_695_fu_66094_p1() {
    mul_ln1118_695_fu_66094_p1 = tmp_695_reg_100032.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_695_fu_66094_p2() {
    mul_ln1118_695_fu_66094_p2 = (!mul_ln1118_695_fu_66094_p0.read().is_01() || !mul_ln1118_695_fu_66094_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_695_fu_66094_p0.read()) * sc_bigint<5>(mul_ln1118_695_fu_66094_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_696_fu_66113_p0() {
    mul_ln1118_696_fu_66113_p0 =  (sc_lv<12>) (sext_ln1116_96_cast_fu_54041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_696_fu_66113_p1() {
    mul_ln1118_696_fu_66113_p1 = tmp_696_reg_100037.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_696_fu_66113_p2() {
    mul_ln1118_696_fu_66113_p2 = (!mul_ln1118_696_fu_66113_p0.read().is_01() || !mul_ln1118_696_fu_66113_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_696_fu_66113_p0.read()) * sc_bigint<5>(mul_ln1118_696_fu_66113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_697_fu_66132_p0() {
    mul_ln1118_697_fu_66132_p0 =  (sc_lv<12>) (sext_ln1116_97_cast_fu_54063_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_697_fu_66132_p1() {
    mul_ln1118_697_fu_66132_p1 = tmp_697_reg_100042.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_697_fu_66132_p2() {
    mul_ln1118_697_fu_66132_p2 = (!mul_ln1118_697_fu_66132_p0.read().is_01() || !mul_ln1118_697_fu_66132_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_697_fu_66132_p0.read()) * sc_bigint<5>(mul_ln1118_697_fu_66132_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_698_fu_66151_p0() {
    mul_ln1118_698_fu_66151_p0 =  (sc_lv<12>) (sext_ln1116_98_cast_fu_54085_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_698_fu_66151_p1() {
    mul_ln1118_698_fu_66151_p1 = tmp_698_reg_100047.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_698_fu_66151_p2() {
    mul_ln1118_698_fu_66151_p2 = (!mul_ln1118_698_fu_66151_p0.read().is_01() || !mul_ln1118_698_fu_66151_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_698_fu_66151_p0.read()) * sc_bigint<5>(mul_ln1118_698_fu_66151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_699_fu_66170_p0() {
    mul_ln1118_699_fu_66170_p0 =  (sc_lv<12>) (sext_ln1116_99_cast_fu_54107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_699_fu_66170_p1() {
    mul_ln1118_699_fu_66170_p1 = tmp_699_reg_100052.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_699_fu_66170_p2() {
    mul_ln1118_699_fu_66170_p2 = (!mul_ln1118_699_fu_66170_p0.read().is_01() || !mul_ln1118_699_fu_66170_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_699_fu_66170_p0.read()) * sc_bigint<5>(mul_ln1118_699_fu_66170_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_69_fu_53589_p0() {
    mul_ln1118_69_fu_53589_p0 =  (sc_lv<12>) (sext_ln1116_69_cast_fu_53583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_69_fu_53589_p1() {
    mul_ln1118_69_fu_53589_p1 = tmp_69_reg_96298.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_69_fu_53589_p2() {
    mul_ln1118_69_fu_53589_p2 = (!mul_ln1118_69_fu_53589_p0.read().is_01() || !mul_ln1118_69_fu_53589_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_69_fu_53589_p0.read()) * sc_bigint<5>(mul_ln1118_69_fu_53589_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_700_fu_66189_p0() {
    mul_ln1118_700_fu_66189_p0 =  (sc_lv<12>) (sext_ln1116_100_cast_fu_54129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_700_fu_66189_p1() {
    mul_ln1118_700_fu_66189_p1 = tmp_700_reg_100057.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_700_fu_66189_p2() {
    mul_ln1118_700_fu_66189_p2 = (!mul_ln1118_700_fu_66189_p0.read().is_01() || !mul_ln1118_700_fu_66189_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_700_fu_66189_p0.read()) * sc_bigint<5>(mul_ln1118_700_fu_66189_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_701_fu_66208_p0() {
    mul_ln1118_701_fu_66208_p0 =  (sc_lv<12>) (sext_ln1116_101_cast_fu_54151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_701_fu_66208_p1() {
    mul_ln1118_701_fu_66208_p1 = tmp_701_reg_100062.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_701_fu_66208_p2() {
    mul_ln1118_701_fu_66208_p2 = (!mul_ln1118_701_fu_66208_p0.read().is_01() || !mul_ln1118_701_fu_66208_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_701_fu_66208_p0.read()) * sc_bigint<5>(mul_ln1118_701_fu_66208_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_702_fu_66227_p0() {
    mul_ln1118_702_fu_66227_p0 =  (sc_lv<12>) (sext_ln1116_102_cast_reg_96606.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_702_fu_66227_p1() {
    mul_ln1118_702_fu_66227_p1 = tmp_702_reg_100067.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_702_fu_66227_p2() {
    mul_ln1118_702_fu_66227_p2 = (!mul_ln1118_702_fu_66227_p0.read().is_01() || !mul_ln1118_702_fu_66227_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_702_fu_66227_p0.read()) * sc_bigint<5>(mul_ln1118_702_fu_66227_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_703_fu_33605_p0() {
    mul_ln1118_703_fu_33605_p0 =  (sc_lv<12>) (sext_ln1116_103_cast_fu_23993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_703_fu_33605_p1() {
    mul_ln1118_703_fu_33605_p1 = tmp_703_fu_33591_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_703_fu_33605_p2() {
    mul_ln1118_703_fu_33605_p2 = (!mul_ln1118_703_fu_33605_p0.read().is_01() || !mul_ln1118_703_fu_33605_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_703_fu_33605_p0.read()) * sc_bigint<5>(mul_ln1118_703_fu_33605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_704_fu_33635_p0() {
    mul_ln1118_704_fu_33635_p0 =  (sc_lv<12>) (sext_ln1116_104_cast_fu_24035_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_704_fu_33635_p1() {
    mul_ln1118_704_fu_33635_p1 = tmp_704_fu_33621_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_704_fu_33635_p2() {
    mul_ln1118_704_fu_33635_p2 = (!mul_ln1118_704_fu_33635_p0.read().is_01() || !mul_ln1118_704_fu_33635_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_704_fu_33635_p0.read()) * sc_bigint<5>(mul_ln1118_704_fu_33635_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_705_fu_33665_p0() {
    mul_ln1118_705_fu_33665_p0 =  (sc_lv<12>) (sext_ln1116_105_cast_fu_24077_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_705_fu_33665_p1() {
    mul_ln1118_705_fu_33665_p1 = tmp_705_fu_33651_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_705_fu_33665_p2() {
    mul_ln1118_705_fu_33665_p2 = (!mul_ln1118_705_fu_33665_p0.read().is_01() || !mul_ln1118_705_fu_33665_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_705_fu_33665_p0.read()) * sc_bigint<5>(mul_ln1118_705_fu_33665_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_706_fu_33695_p0() {
    mul_ln1118_706_fu_33695_p0 =  (sc_lv<12>) (sext_ln1116_106_cast_fu_24119_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_706_fu_33695_p1() {
    mul_ln1118_706_fu_33695_p1 = tmp_706_fu_33681_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_706_fu_33695_p2() {
    mul_ln1118_706_fu_33695_p2 = (!mul_ln1118_706_fu_33695_p0.read().is_01() || !mul_ln1118_706_fu_33695_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_706_fu_33695_p0.read()) * sc_bigint<5>(mul_ln1118_706_fu_33695_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_707_fu_33725_p0() {
    mul_ln1118_707_fu_33725_p0 =  (sc_lv<12>) (sext_ln1116_107_cast_fu_24161_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_707_fu_33725_p1() {
    mul_ln1118_707_fu_33725_p1 = tmp_707_fu_33711_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_707_fu_33725_p2() {
    mul_ln1118_707_fu_33725_p2 = (!mul_ln1118_707_fu_33725_p0.read().is_01() || !mul_ln1118_707_fu_33725_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_707_fu_33725_p0.read()) * sc_bigint<5>(mul_ln1118_707_fu_33725_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_708_fu_33755_p0() {
    mul_ln1118_708_fu_33755_p0 =  (sc_lv<12>) (sext_ln1116_108_cast_fu_24203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_708_fu_33755_p1() {
    mul_ln1118_708_fu_33755_p1 = tmp_708_fu_33741_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_708_fu_33755_p2() {
    mul_ln1118_708_fu_33755_p2 = (!mul_ln1118_708_fu_33755_p0.read().is_01() || !mul_ln1118_708_fu_33755_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_708_fu_33755_p0.read()) * sc_bigint<5>(mul_ln1118_708_fu_33755_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_709_fu_66245_p0() {
    mul_ln1118_709_fu_66245_p0 =  (sc_lv<12>) (sext_ln1116_109_cast_fu_54191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_709_fu_66245_p1() {
    mul_ln1118_709_fu_66245_p1 = tmp_709_reg_100102.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_709_fu_66245_p2() {
    mul_ln1118_709_fu_66245_p2 = (!mul_ln1118_709_fu_66245_p0.read().is_01() || !mul_ln1118_709_fu_66245_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_709_fu_66245_p0.read()) * sc_bigint<5>(mul_ln1118_709_fu_66245_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_70_fu_53611_p0() {
    mul_ln1118_70_fu_53611_p0 =  (sc_lv<12>) (sext_ln1116_70_cast_fu_53605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_70_fu_53611_p1() {
    mul_ln1118_70_fu_53611_p1 = tmp_70_reg_96308.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_70_fu_53611_p2() {
    mul_ln1118_70_fu_53611_p2 = (!mul_ln1118_70_fu_53611_p0.read().is_01() || !mul_ln1118_70_fu_53611_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_70_fu_53611_p0.read()) * sc_bigint<5>(mul_ln1118_70_fu_53611_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_710_fu_66264_p0() {
    mul_ln1118_710_fu_66264_p0 =  (sc_lv<12>) (sext_ln1116_110_cast_fu_54213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_710_fu_66264_p1() {
    mul_ln1118_710_fu_66264_p1 = tmp_710_reg_100107.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_710_fu_66264_p2() {
    mul_ln1118_710_fu_66264_p2 = (!mul_ln1118_710_fu_66264_p0.read().is_01() || !mul_ln1118_710_fu_66264_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_710_fu_66264_p0.read()) * sc_bigint<5>(mul_ln1118_710_fu_66264_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_711_fu_66283_p0() {
    mul_ln1118_711_fu_66283_p0 =  (sc_lv<12>) (sext_ln1116_111_cast_fu_54235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_711_fu_66283_p1() {
    mul_ln1118_711_fu_66283_p1 = tmp_711_reg_100112.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_711_fu_66283_p2() {
    mul_ln1118_711_fu_66283_p2 = (!mul_ln1118_711_fu_66283_p0.read().is_01() || !mul_ln1118_711_fu_66283_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_711_fu_66283_p0.read()) * sc_bigint<5>(mul_ln1118_711_fu_66283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_712_fu_66302_p0() {
    mul_ln1118_712_fu_66302_p0 =  (sc_lv<12>) (sext_ln1116_112_cast_fu_54257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_712_fu_66302_p1() {
    mul_ln1118_712_fu_66302_p1 = tmp_712_reg_100117.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_712_fu_66302_p2() {
    mul_ln1118_712_fu_66302_p2 = (!mul_ln1118_712_fu_66302_p0.read().is_01() || !mul_ln1118_712_fu_66302_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_712_fu_66302_p0.read()) * sc_bigint<5>(mul_ln1118_712_fu_66302_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_713_fu_66321_p0() {
    mul_ln1118_713_fu_66321_p0 =  (sc_lv<12>) (sext_ln1116_113_cast_fu_54279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_713_fu_66321_p1() {
    mul_ln1118_713_fu_66321_p1 = tmp_713_reg_100122.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_713_fu_66321_p2() {
    mul_ln1118_713_fu_66321_p2 = (!mul_ln1118_713_fu_66321_p0.read().is_01() || !mul_ln1118_713_fu_66321_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_713_fu_66321_p0.read()) * sc_bigint<5>(mul_ln1118_713_fu_66321_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_714_fu_66340_p0() {
    mul_ln1118_714_fu_66340_p0 =  (sc_lv<12>) (sext_ln1116_114_cast_fu_54301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_714_fu_66340_p1() {
    mul_ln1118_714_fu_66340_p1 = tmp_714_reg_100127.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_714_fu_66340_p2() {
    mul_ln1118_714_fu_66340_p2 = (!mul_ln1118_714_fu_66340_p0.read().is_01() || !mul_ln1118_714_fu_66340_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_714_fu_66340_p0.read()) * sc_bigint<5>(mul_ln1118_714_fu_66340_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_715_fu_66359_p0() {
    mul_ln1118_715_fu_66359_p0 =  (sc_lv<12>) (sext_ln1116_115_cast_fu_54323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_715_fu_66359_p1() {
    mul_ln1118_715_fu_66359_p1 = tmp_715_reg_100132.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_715_fu_66359_p2() {
    mul_ln1118_715_fu_66359_p2 = (!mul_ln1118_715_fu_66359_p0.read().is_01() || !mul_ln1118_715_fu_66359_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_715_fu_66359_p0.read()) * sc_bigint<5>(mul_ln1118_715_fu_66359_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_716_fu_66378_p0() {
    mul_ln1118_716_fu_66378_p0 =  (sc_lv<12>) (sext_ln1116_116_cast_fu_54345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_716_fu_66378_p1() {
    mul_ln1118_716_fu_66378_p1 = tmp_716_reg_100137.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_716_fu_66378_p2() {
    mul_ln1118_716_fu_66378_p2 = (!mul_ln1118_716_fu_66378_p0.read().is_01() || !mul_ln1118_716_fu_66378_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_716_fu_66378_p0.read()) * sc_bigint<5>(mul_ln1118_716_fu_66378_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_717_fu_66397_p0() {
    mul_ln1118_717_fu_66397_p0 =  (sc_lv<12>) (sext_ln1116_117_cast_fu_54367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_717_fu_66397_p1() {
    mul_ln1118_717_fu_66397_p1 = tmp_717_reg_100142.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_717_fu_66397_p2() {
    mul_ln1118_717_fu_66397_p2 = (!mul_ln1118_717_fu_66397_p0.read().is_01() || !mul_ln1118_717_fu_66397_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_717_fu_66397_p0.read()) * sc_bigint<5>(mul_ln1118_717_fu_66397_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_718_fu_66416_p0() {
    mul_ln1118_718_fu_66416_p0 =  (sc_lv<12>) (sext_ln1116_118_cast_fu_54389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_718_fu_66416_p1() {
    mul_ln1118_718_fu_66416_p1 = tmp_718_reg_100147.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_718_fu_66416_p2() {
    mul_ln1118_718_fu_66416_p2 = (!mul_ln1118_718_fu_66416_p0.read().is_01() || !mul_ln1118_718_fu_66416_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_718_fu_66416_p0.read()) * sc_bigint<5>(mul_ln1118_718_fu_66416_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_719_fu_66435_p0() {
    mul_ln1118_719_fu_66435_p0 =  (sc_lv<12>) (sext_ln1116_119_cast_fu_54411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_719_fu_66435_p1() {
    mul_ln1118_719_fu_66435_p1 = tmp_719_reg_100152.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_719_fu_66435_p2() {
    mul_ln1118_719_fu_66435_p2 = (!mul_ln1118_719_fu_66435_p0.read().is_01() || !mul_ln1118_719_fu_66435_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_719_fu_66435_p0.read()) * sc_bigint<5>(mul_ln1118_719_fu_66435_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_71_fu_53633_p0() {
    mul_ln1118_71_fu_53633_p0 =  (sc_lv<12>) (sext_ln1116_71_cast_fu_53627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_71_fu_53633_p1() {
    mul_ln1118_71_fu_53633_p1 = tmp_71_reg_96318.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_71_fu_53633_p2() {
    mul_ln1118_71_fu_53633_p2 = (!mul_ln1118_71_fu_53633_p0.read().is_01() || !mul_ln1118_71_fu_53633_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_71_fu_53633_p0.read()) * sc_bigint<5>(mul_ln1118_71_fu_53633_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_720_fu_66454_p0() {
    mul_ln1118_720_fu_66454_p0 =  (sc_lv<12>) (sext_ln1116_120_cast_fu_54433_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_720_fu_66454_p1() {
    mul_ln1118_720_fu_66454_p1 = tmp_720_reg_100157.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_720_fu_66454_p2() {
    mul_ln1118_720_fu_66454_p2 = (!mul_ln1118_720_fu_66454_p0.read().is_01() || !mul_ln1118_720_fu_66454_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_720_fu_66454_p0.read()) * sc_bigint<5>(mul_ln1118_720_fu_66454_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_721_fu_66473_p0() {
    mul_ln1118_721_fu_66473_p0 =  (sc_lv<12>) (sext_ln1116_121_cast_fu_54455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_721_fu_66473_p1() {
    mul_ln1118_721_fu_66473_p1 = tmp_721_reg_100162.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_721_fu_66473_p2() {
    mul_ln1118_721_fu_66473_p2 = (!mul_ln1118_721_fu_66473_p0.read().is_01() || !mul_ln1118_721_fu_66473_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_721_fu_66473_p0.read()) * sc_bigint<5>(mul_ln1118_721_fu_66473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_722_fu_66492_p0() {
    mul_ln1118_722_fu_66492_p0 =  (sc_lv<12>) (sext_ln1116_122_cast_fu_54477_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_722_fu_66492_p1() {
    mul_ln1118_722_fu_66492_p1 = tmp_722_reg_100167.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_722_fu_66492_p2() {
    mul_ln1118_722_fu_66492_p2 = (!mul_ln1118_722_fu_66492_p0.read().is_01() || !mul_ln1118_722_fu_66492_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_722_fu_66492_p0.read()) * sc_bigint<5>(mul_ln1118_722_fu_66492_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_723_fu_66511_p0() {
    mul_ln1118_723_fu_66511_p0 =  (sc_lv<12>) (sext_ln1116_123_cast_fu_54499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_723_fu_66511_p1() {
    mul_ln1118_723_fu_66511_p1 = tmp_723_reg_100172.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_723_fu_66511_p2() {
    mul_ln1118_723_fu_66511_p2 = (!mul_ln1118_723_fu_66511_p0.read().is_01() || !mul_ln1118_723_fu_66511_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_723_fu_66511_p0.read()) * sc_bigint<5>(mul_ln1118_723_fu_66511_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_724_fu_66530_p0() {
    mul_ln1118_724_fu_66530_p0 =  (sc_lv<12>) (sext_ln1116_124_cast_fu_54521_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_724_fu_66530_p1() {
    mul_ln1118_724_fu_66530_p1 = tmp_724_reg_100177.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_724_fu_66530_p2() {
    mul_ln1118_724_fu_66530_p2 = (!mul_ln1118_724_fu_66530_p0.read().is_01() || !mul_ln1118_724_fu_66530_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_724_fu_66530_p0.read()) * sc_bigint<5>(mul_ln1118_724_fu_66530_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_725_fu_66549_p0() {
    mul_ln1118_725_fu_66549_p0 =  (sc_lv<12>) (sext_ln1116_125_cast_fu_54543_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_725_fu_66549_p1() {
    mul_ln1118_725_fu_66549_p1 = tmp_725_reg_100182.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_725_fu_66549_p2() {
    mul_ln1118_725_fu_66549_p2 = (!mul_ln1118_725_fu_66549_p0.read().is_01() || !mul_ln1118_725_fu_66549_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_725_fu_66549_p0.read()) * sc_bigint<5>(mul_ln1118_725_fu_66549_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_726_fu_66568_p0() {
    mul_ln1118_726_fu_66568_p0 =  (sc_lv<12>) (sext_ln1116_126_cast_fu_54565_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_726_fu_66568_p1() {
    mul_ln1118_726_fu_66568_p1 = tmp_726_reg_100187.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_726_fu_66568_p2() {
    mul_ln1118_726_fu_66568_p2 = (!mul_ln1118_726_fu_66568_p0.read().is_01() || !mul_ln1118_726_fu_66568_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_726_fu_66568_p0.read()) * sc_bigint<5>(mul_ln1118_726_fu_66568_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_727_fu_66587_p0() {
    mul_ln1118_727_fu_66587_p0 =  (sc_lv<12>) (sext_ln1116_127_cast_fu_54587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_727_fu_66587_p1() {
    mul_ln1118_727_fu_66587_p1 = tmp_727_reg_100192.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_727_fu_66587_p2() {
    mul_ln1118_727_fu_66587_p2 = (!mul_ln1118_727_fu_66587_p0.read().is_01() || !mul_ln1118_727_fu_66587_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_727_fu_66587_p0.read()) * sc_bigint<5>(mul_ln1118_727_fu_66587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_728_fu_66606_p0() {
    mul_ln1118_728_fu_66606_p0 =  (sc_lv<12>) (sext_ln1116_128_cast_fu_54609_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_728_fu_66606_p1() {
    mul_ln1118_728_fu_66606_p1 = tmp_728_reg_100197.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_728_fu_66606_p2() {
    mul_ln1118_728_fu_66606_p2 = (!mul_ln1118_728_fu_66606_p0.read().is_01() || !mul_ln1118_728_fu_66606_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_728_fu_66606_p0.read()) * sc_bigint<5>(mul_ln1118_728_fu_66606_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_729_fu_66625_p0() {
    mul_ln1118_729_fu_66625_p0 =  (sc_lv<12>) (sext_ln1116_129_cast_fu_54631_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_729_fu_66625_p1() {
    mul_ln1118_729_fu_66625_p1 = tmp_729_reg_100202.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_729_fu_66625_p2() {
    mul_ln1118_729_fu_66625_p2 = (!mul_ln1118_729_fu_66625_p0.read().is_01() || !mul_ln1118_729_fu_66625_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_729_fu_66625_p0.read()) * sc_bigint<5>(mul_ln1118_729_fu_66625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_72_fu_53655_p0() {
    mul_ln1118_72_fu_53655_p0 =  (sc_lv<12>) (sext_ln1116_72_cast_fu_53649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_72_fu_53655_p1() {
    mul_ln1118_72_fu_53655_p1 = tmp_72_reg_96328.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_72_fu_53655_p2() {
    mul_ln1118_72_fu_53655_p2 = (!mul_ln1118_72_fu_53655_p0.read().is_01() || !mul_ln1118_72_fu_53655_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_72_fu_53655_p0.read()) * sc_bigint<5>(mul_ln1118_72_fu_53655_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_730_fu_66644_p0() {
    mul_ln1118_730_fu_66644_p0 =  (sc_lv<12>) (sext_ln1116_130_cast_fu_54653_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_730_fu_66644_p1() {
    mul_ln1118_730_fu_66644_p1 = tmp_730_reg_100207.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_730_fu_66644_p2() {
    mul_ln1118_730_fu_66644_p2 = (!mul_ln1118_730_fu_66644_p0.read().is_01() || !mul_ln1118_730_fu_66644_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_730_fu_66644_p0.read()) * sc_bigint<5>(mul_ln1118_730_fu_66644_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_731_fu_66663_p0() {
    mul_ln1118_731_fu_66663_p0 =  (sc_lv<12>) (sext_ln1116_131_cast_fu_54675_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_731_fu_66663_p1() {
    mul_ln1118_731_fu_66663_p1 = tmp_731_reg_100212.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_731_fu_66663_p2() {
    mul_ln1118_731_fu_66663_p2 = (!mul_ln1118_731_fu_66663_p0.read().is_01() || !mul_ln1118_731_fu_66663_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_731_fu_66663_p0.read()) * sc_bigint<5>(mul_ln1118_731_fu_66663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_732_fu_34015_p0() {
    mul_ln1118_732_fu_34015_p0 =  (sc_lv<12>) (sext_ln1116_132_cast_fu_24659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_732_fu_34015_p1() {
    mul_ln1118_732_fu_34015_p1 = tmp_732_fu_34001_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_732_fu_34015_p2() {
    mul_ln1118_732_fu_34015_p2 = (!mul_ln1118_732_fu_34015_p0.read().is_01() || !mul_ln1118_732_fu_34015_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_732_fu_34015_p0.read()) * sc_bigint<5>(mul_ln1118_732_fu_34015_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_733_fu_34045_p0() {
    mul_ln1118_733_fu_34045_p0 =  (sc_lv<12>) (sext_ln1116_133_cast_fu_24701_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_733_fu_34045_p1() {
    mul_ln1118_733_fu_34045_p1 = tmp_733_fu_34031_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_733_fu_34045_p2() {
    mul_ln1118_733_fu_34045_p2 = (!mul_ln1118_733_fu_34045_p0.read().is_01() || !mul_ln1118_733_fu_34045_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_733_fu_34045_p0.read()) * sc_bigint<5>(mul_ln1118_733_fu_34045_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_734_fu_66682_p0() {
    mul_ln1118_734_fu_66682_p0 =  (sc_lv<12>) (sext_ln1116_134_cast_fu_54697_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_734_fu_66682_p1() {
    mul_ln1118_734_fu_66682_p1 = tmp_734_reg_100227.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_734_fu_66682_p2() {
    mul_ln1118_734_fu_66682_p2 = (!mul_ln1118_734_fu_66682_p0.read().is_01() || !mul_ln1118_734_fu_66682_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_734_fu_66682_p0.read()) * sc_bigint<5>(mul_ln1118_734_fu_66682_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_735_fu_66701_p0() {
    mul_ln1118_735_fu_66701_p0 =  (sc_lv<12>) (sext_ln1116_135_cast_fu_54719_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_735_fu_66701_p1() {
    mul_ln1118_735_fu_66701_p1 = tmp_735_reg_100232.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_735_fu_66701_p2() {
    mul_ln1118_735_fu_66701_p2 = (!mul_ln1118_735_fu_66701_p0.read().is_01() || !mul_ln1118_735_fu_66701_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_735_fu_66701_p0.read()) * sc_bigint<5>(mul_ln1118_735_fu_66701_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_736_fu_66720_p0() {
    mul_ln1118_736_fu_66720_p0 =  (sc_lv<12>) (sext_ln1116_136_cast_fu_54741_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_736_fu_66720_p1() {
    mul_ln1118_736_fu_66720_p1 = tmp_736_reg_100237.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_736_fu_66720_p2() {
    mul_ln1118_736_fu_66720_p2 = (!mul_ln1118_736_fu_66720_p0.read().is_01() || !mul_ln1118_736_fu_66720_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_736_fu_66720_p0.read()) * sc_bigint<5>(mul_ln1118_736_fu_66720_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_737_fu_66739_p0() {
    mul_ln1118_737_fu_66739_p0 =  (sc_lv<12>) (sext_ln1116_137_cast_fu_54763_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_737_fu_66739_p1() {
    mul_ln1118_737_fu_66739_p1 = tmp_737_reg_100242.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_737_fu_66739_p2() {
    mul_ln1118_737_fu_66739_p2 = (!mul_ln1118_737_fu_66739_p0.read().is_01() || !mul_ln1118_737_fu_66739_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_737_fu_66739_p0.read()) * sc_bigint<5>(mul_ln1118_737_fu_66739_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_738_fu_66758_p0() {
    mul_ln1118_738_fu_66758_p0 =  (sc_lv<12>) (sext_ln1116_138_cast_fu_54785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_738_fu_66758_p1() {
    mul_ln1118_738_fu_66758_p1 = tmp_738_reg_100247.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_738_fu_66758_p2() {
    mul_ln1118_738_fu_66758_p2 = (!mul_ln1118_738_fu_66758_p0.read().is_01() || !mul_ln1118_738_fu_66758_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_738_fu_66758_p0.read()) * sc_bigint<5>(mul_ln1118_738_fu_66758_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_739_fu_66777_p0() {
    mul_ln1118_739_fu_66777_p0 =  (sc_lv<12>) (sext_ln1116_139_cast_fu_54807_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_739_fu_66777_p1() {
    mul_ln1118_739_fu_66777_p1 = tmp_739_reg_100252.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_739_fu_66777_p2() {
    mul_ln1118_739_fu_66777_p2 = (!mul_ln1118_739_fu_66777_p0.read().is_01() || !mul_ln1118_739_fu_66777_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_739_fu_66777_p0.read()) * sc_bigint<5>(mul_ln1118_739_fu_66777_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_73_fu_53677_p0() {
    mul_ln1118_73_fu_53677_p0 =  (sc_lv<12>) (sext_ln1116_73_cast_fu_53671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_73_fu_53677_p1() {
    mul_ln1118_73_fu_53677_p1 = tmp_73_reg_96338.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_73_fu_53677_p2() {
    mul_ln1118_73_fu_53677_p2 = (!mul_ln1118_73_fu_53677_p0.read().is_01() || !mul_ln1118_73_fu_53677_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_73_fu_53677_p0.read()) * sc_bigint<5>(mul_ln1118_73_fu_53677_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_740_fu_66796_p0() {
    mul_ln1118_740_fu_66796_p0 =  (sc_lv<12>) (sext_ln1116_140_cast_fu_54829_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_740_fu_66796_p1() {
    mul_ln1118_740_fu_66796_p1 = tmp_740_reg_100257.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_740_fu_66796_p2() {
    mul_ln1118_740_fu_66796_p2 = (!mul_ln1118_740_fu_66796_p0.read().is_01() || !mul_ln1118_740_fu_66796_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_740_fu_66796_p0.read()) * sc_bigint<5>(mul_ln1118_740_fu_66796_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_741_fu_66815_p0() {
    mul_ln1118_741_fu_66815_p0 =  (sc_lv<12>) (sext_ln1116_141_cast_fu_54851_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_741_fu_66815_p1() {
    mul_ln1118_741_fu_66815_p1 = tmp_741_reg_100262.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_741_fu_66815_p2() {
    mul_ln1118_741_fu_66815_p2 = (!mul_ln1118_741_fu_66815_p0.read().is_01() || !mul_ln1118_741_fu_66815_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_741_fu_66815_p0.read()) * sc_bigint<5>(mul_ln1118_741_fu_66815_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_742_fu_66834_p0() {
    mul_ln1118_742_fu_66834_p0 =  (sc_lv<12>) (sext_ln1116_142_cast_fu_54873_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_742_fu_66834_p1() {
    mul_ln1118_742_fu_66834_p1 = tmp_742_reg_100267.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_742_fu_66834_p2() {
    mul_ln1118_742_fu_66834_p2 = (!mul_ln1118_742_fu_66834_p0.read().is_01() || !mul_ln1118_742_fu_66834_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_742_fu_66834_p0.read()) * sc_bigint<5>(mul_ln1118_742_fu_66834_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_743_fu_66853_p0() {
    mul_ln1118_743_fu_66853_p0 =  (sc_lv<12>) (sext_ln1116_143_cast_fu_54895_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_743_fu_66853_p1() {
    mul_ln1118_743_fu_66853_p1 = tmp_743_reg_100272.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_743_fu_66853_p2() {
    mul_ln1118_743_fu_66853_p2 = (!mul_ln1118_743_fu_66853_p0.read().is_01() || !mul_ln1118_743_fu_66853_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_743_fu_66853_p0.read()) * sc_bigint<5>(mul_ln1118_743_fu_66853_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_744_fu_66872_p0() {
    mul_ln1118_744_fu_66872_p0 =  (sc_lv<12>) (sext_ln1116_144_cast_fu_54917_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_744_fu_66872_p1() {
    mul_ln1118_744_fu_66872_p1 = tmp_744_reg_100277.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_744_fu_66872_p2() {
    mul_ln1118_744_fu_66872_p2 = (!mul_ln1118_744_fu_66872_p0.read().is_01() || !mul_ln1118_744_fu_66872_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_744_fu_66872_p0.read()) * sc_bigint<5>(mul_ln1118_744_fu_66872_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_745_fu_66891_p0() {
    mul_ln1118_745_fu_66891_p0 =  (sc_lv<12>) (sext_ln1116_145_cast_fu_54939_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_745_fu_66891_p1() {
    mul_ln1118_745_fu_66891_p1 = tmp_745_reg_100282.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_745_fu_66891_p2() {
    mul_ln1118_745_fu_66891_p2 = (!mul_ln1118_745_fu_66891_p0.read().is_01() || !mul_ln1118_745_fu_66891_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_745_fu_66891_p0.read()) * sc_bigint<5>(mul_ln1118_745_fu_66891_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_746_fu_66910_p0() {
    mul_ln1118_746_fu_66910_p0 =  (sc_lv<12>) (sext_ln1116_146_cast_fu_54961_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_746_fu_66910_p1() {
    mul_ln1118_746_fu_66910_p1 = tmp_746_reg_100287.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_746_fu_66910_p2() {
    mul_ln1118_746_fu_66910_p2 = (!mul_ln1118_746_fu_66910_p0.read().is_01() || !mul_ln1118_746_fu_66910_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_746_fu_66910_p0.read()) * sc_bigint<5>(mul_ln1118_746_fu_66910_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_747_fu_66929_p0() {
    mul_ln1118_747_fu_66929_p0 =  (sc_lv<12>) (sext_ln1116_147_cast_fu_54983_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_747_fu_66929_p1() {
    mul_ln1118_747_fu_66929_p1 = tmp_747_reg_100292.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_747_fu_66929_p2() {
    mul_ln1118_747_fu_66929_p2 = (!mul_ln1118_747_fu_66929_p0.read().is_01() || !mul_ln1118_747_fu_66929_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_747_fu_66929_p0.read()) * sc_bigint<5>(mul_ln1118_747_fu_66929_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_748_fu_66948_p0() {
    mul_ln1118_748_fu_66948_p0 =  (sc_lv<12>) (sext_ln1116_148_cast_fu_55005_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_748_fu_66948_p1() {
    mul_ln1118_748_fu_66948_p1 = tmp_748_reg_100297.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_748_fu_66948_p2() {
    mul_ln1118_748_fu_66948_p2 = (!mul_ln1118_748_fu_66948_p0.read().is_01() || !mul_ln1118_748_fu_66948_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_748_fu_66948_p0.read()) * sc_bigint<5>(mul_ln1118_748_fu_66948_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_749_fu_66967_p0() {
    mul_ln1118_749_fu_66967_p0 =  (sc_lv<12>) (sext_ln1116_149_cast_fu_55027_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_749_fu_66967_p1() {
    mul_ln1118_749_fu_66967_p1 = tmp_749_reg_100302.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_749_fu_66967_p2() {
    mul_ln1118_749_fu_66967_p2 = (!mul_ln1118_749_fu_66967_p0.read().is_01() || !mul_ln1118_749_fu_66967_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_749_fu_66967_p0.read()) * sc_bigint<5>(mul_ln1118_749_fu_66967_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_74_fu_53699_p0() {
    mul_ln1118_74_fu_53699_p0 =  (sc_lv<12>) (sext_ln1116_74_cast_fu_53693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_74_fu_53699_p1() {
    mul_ln1118_74_fu_53699_p1 = tmp_74_reg_96348.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_74_fu_53699_p2() {
    mul_ln1118_74_fu_53699_p2 = (!mul_ln1118_74_fu_53699_p0.read().is_01() || !mul_ln1118_74_fu_53699_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_74_fu_53699_p0.read()) * sc_bigint<5>(mul_ln1118_74_fu_53699_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_750_fu_66986_p0() {
    mul_ln1118_750_fu_66986_p0 =  (sc_lv<12>) (sext_ln1116_150_cast_fu_55049_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_750_fu_66986_p1() {
    mul_ln1118_750_fu_66986_p1 = tmp_750_reg_100307.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_750_fu_66986_p2() {
    mul_ln1118_750_fu_66986_p2 = (!mul_ln1118_750_fu_66986_p0.read().is_01() || !mul_ln1118_750_fu_66986_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_750_fu_66986_p0.read()) * sc_bigint<5>(mul_ln1118_750_fu_66986_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_751_fu_67005_p0() {
    mul_ln1118_751_fu_67005_p0 =  (sc_lv<12>) (sext_ln1116_151_cast_reg_97064.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_751_fu_67005_p1() {
    mul_ln1118_751_fu_67005_p1 = tmp_751_reg_100312.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_751_fu_67005_p2() {
    mul_ln1118_751_fu_67005_p2 = (!mul_ln1118_751_fu_67005_p0.read().is_01() || !mul_ln1118_751_fu_67005_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_751_fu_67005_p0.read()) * sc_bigint<5>(mul_ln1118_751_fu_67005_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_752_fu_67023_p0() {
    mul_ln1118_752_fu_67023_p0 =  (sc_lv<12>) (sext_ln1116_152_cast_reg_97082.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_752_fu_67023_p1() {
    mul_ln1118_752_fu_67023_p1 = tmp_752_reg_100317.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_752_fu_67023_p2() {
    mul_ln1118_752_fu_67023_p2 = (!mul_ln1118_752_fu_67023_p0.read().is_01() || !mul_ln1118_752_fu_67023_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_752_fu_67023_p0.read()) * sc_bigint<5>(mul_ln1118_752_fu_67023_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_753_fu_34265_p0() {
    mul_ln1118_753_fu_34265_p0 =  (sc_lv<12>) (sext_ln1116_153_cast_fu_25093_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_753_fu_34265_p1() {
    mul_ln1118_753_fu_34265_p1 = tmp_753_fu_34251_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_753_fu_34265_p2() {
    mul_ln1118_753_fu_34265_p2 = (!mul_ln1118_753_fu_34265_p0.read().is_01() || !mul_ln1118_753_fu_34265_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_753_fu_34265_p0.read()) * sc_bigint<5>(mul_ln1118_753_fu_34265_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_754_fu_34295_p0() {
    mul_ln1118_754_fu_34295_p0 =  (sc_lv<12>) (sext_ln1116_154_cast_fu_25135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_754_fu_34295_p1() {
    mul_ln1118_754_fu_34295_p1 = tmp_754_fu_34281_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_754_fu_34295_p2() {
    mul_ln1118_754_fu_34295_p2 = (!mul_ln1118_754_fu_34295_p0.read().is_01() || !mul_ln1118_754_fu_34295_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_754_fu_34295_p0.read()) * sc_bigint<5>(mul_ln1118_754_fu_34295_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_755_fu_34325_p0() {
    mul_ln1118_755_fu_34325_p0 =  (sc_lv<12>) (sext_ln1116_155_cast_fu_25177_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_755_fu_34325_p1() {
    mul_ln1118_755_fu_34325_p1 = tmp_755_fu_34311_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_755_fu_34325_p2() {
    mul_ln1118_755_fu_34325_p2 = (!mul_ln1118_755_fu_34325_p0.read().is_01() || !mul_ln1118_755_fu_34325_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_755_fu_34325_p0.read()) * sc_bigint<5>(mul_ln1118_755_fu_34325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_756_fu_34355_p0() {
    mul_ln1118_756_fu_34355_p0 =  (sc_lv<12>) (sext_ln1116_156_cast_fu_25219_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_756_fu_34355_p1() {
    mul_ln1118_756_fu_34355_p1 = tmp_756_fu_34341_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_756_fu_34355_p2() {
    mul_ln1118_756_fu_34355_p2 = (!mul_ln1118_756_fu_34355_p0.read().is_01() || !mul_ln1118_756_fu_34355_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_756_fu_34355_p0.read()) * sc_bigint<5>(mul_ln1118_756_fu_34355_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_757_fu_34385_p0() {
    mul_ln1118_757_fu_34385_p0 =  (sc_lv<12>) (sext_ln1116_157_cast_fu_25261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_757_fu_34385_p1() {
    mul_ln1118_757_fu_34385_p1 = tmp_757_fu_34371_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_757_fu_34385_p2() {
    mul_ln1118_757_fu_34385_p2 = (!mul_ln1118_757_fu_34385_p0.read().is_01() || !mul_ln1118_757_fu_34385_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_757_fu_34385_p0.read()) * sc_bigint<5>(mul_ln1118_757_fu_34385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_758_fu_34415_p0() {
    mul_ln1118_758_fu_34415_p0 =  (sc_lv<12>) (sext_ln1116_158_cast_fu_25303_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_758_fu_34415_p1() {
    mul_ln1118_758_fu_34415_p1 = tmp_758_fu_34401_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_758_fu_34415_p2() {
    mul_ln1118_758_fu_34415_p2 = (!mul_ln1118_758_fu_34415_p0.read().is_01() || !mul_ln1118_758_fu_34415_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_758_fu_34415_p0.read()) * sc_bigint<5>(mul_ln1118_758_fu_34415_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_759_fu_67041_p0() {
    mul_ln1118_759_fu_67041_p0 =  (sc_lv<12>) (sext_ln1116_159_cast_fu_55107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_759_fu_67041_p1() {
    mul_ln1118_759_fu_67041_p1 = tmp_759_reg_100352.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_759_fu_67041_p2() {
    mul_ln1118_759_fu_67041_p2 = (!mul_ln1118_759_fu_67041_p0.read().is_01() || !mul_ln1118_759_fu_67041_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_759_fu_67041_p0.read()) * sc_bigint<5>(mul_ln1118_759_fu_67041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_75_fu_53721_p0() {
    mul_ln1118_75_fu_53721_p0 =  (sc_lv<12>) (sext_ln1116_75_cast_fu_53715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_75_fu_53721_p1() {
    mul_ln1118_75_fu_53721_p1 = tmp_75_reg_96358.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_75_fu_53721_p2() {
    mul_ln1118_75_fu_53721_p2 = (!mul_ln1118_75_fu_53721_p0.read().is_01() || !mul_ln1118_75_fu_53721_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_75_fu_53721_p0.read()) * sc_bigint<5>(mul_ln1118_75_fu_53721_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_760_fu_67060_p0() {
    mul_ln1118_760_fu_67060_p0 =  (sc_lv<12>) (sext_ln1116_160_cast_fu_55129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_760_fu_67060_p1() {
    mul_ln1118_760_fu_67060_p1 = tmp_760_reg_100357.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_760_fu_67060_p2() {
    mul_ln1118_760_fu_67060_p2 = (!mul_ln1118_760_fu_67060_p0.read().is_01() || !mul_ln1118_760_fu_67060_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_760_fu_67060_p0.read()) * sc_bigint<5>(mul_ln1118_760_fu_67060_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_761_fu_67079_p0() {
    mul_ln1118_761_fu_67079_p0 =  (sc_lv<12>) (sext_ln1116_161_cast_fu_55151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_761_fu_67079_p1() {
    mul_ln1118_761_fu_67079_p1 = tmp_761_reg_100362.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_761_fu_67079_p2() {
    mul_ln1118_761_fu_67079_p2 = (!mul_ln1118_761_fu_67079_p0.read().is_01() || !mul_ln1118_761_fu_67079_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_761_fu_67079_p0.read()) * sc_bigint<5>(mul_ln1118_761_fu_67079_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_762_fu_67098_p0() {
    mul_ln1118_762_fu_67098_p0 =  (sc_lv<12>) (sext_ln1116_162_cast_fu_55173_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_762_fu_67098_p1() {
    mul_ln1118_762_fu_67098_p1 = tmp_762_reg_100367.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_762_fu_67098_p2() {
    mul_ln1118_762_fu_67098_p2 = (!mul_ln1118_762_fu_67098_p0.read().is_01() || !mul_ln1118_762_fu_67098_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_762_fu_67098_p0.read()) * sc_bigint<5>(mul_ln1118_762_fu_67098_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_763_fu_67117_p0() {
    mul_ln1118_763_fu_67117_p0 =  (sc_lv<12>) (sext_ln1116_163_cast_fu_55195_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_763_fu_67117_p1() {
    mul_ln1118_763_fu_67117_p1 = tmp_763_reg_100372.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_763_fu_67117_p2() {
    mul_ln1118_763_fu_67117_p2 = (!mul_ln1118_763_fu_67117_p0.read().is_01() || !mul_ln1118_763_fu_67117_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_763_fu_67117_p0.read()) * sc_bigint<5>(mul_ln1118_763_fu_67117_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_764_fu_67136_p0() {
    mul_ln1118_764_fu_67136_p0 =  (sc_lv<12>) (sext_ln1116_164_cast_fu_55217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_764_fu_67136_p1() {
    mul_ln1118_764_fu_67136_p1 = tmp_764_reg_100377.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_764_fu_67136_p2() {
    mul_ln1118_764_fu_67136_p2 = (!mul_ln1118_764_fu_67136_p0.read().is_01() || !mul_ln1118_764_fu_67136_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_764_fu_67136_p0.read()) * sc_bigint<5>(mul_ln1118_764_fu_67136_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_765_fu_67155_p0() {
    mul_ln1118_765_fu_67155_p0 =  (sc_lv<12>) (sext_ln1116_165_cast_fu_55239_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_765_fu_67155_p1() {
    mul_ln1118_765_fu_67155_p1 = tmp_765_reg_100382.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_765_fu_67155_p2() {
    mul_ln1118_765_fu_67155_p2 = (!mul_ln1118_765_fu_67155_p0.read().is_01() || !mul_ln1118_765_fu_67155_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_765_fu_67155_p0.read()) * sc_bigint<5>(mul_ln1118_765_fu_67155_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_766_fu_67174_p0() {
    mul_ln1118_766_fu_67174_p0 =  (sc_lv<12>) (sext_ln1116_166_cast_fu_55261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_766_fu_67174_p1() {
    mul_ln1118_766_fu_67174_p1 = tmp_766_reg_100387.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_766_fu_67174_p2() {
    mul_ln1118_766_fu_67174_p2 = (!mul_ln1118_766_fu_67174_p0.read().is_01() || !mul_ln1118_766_fu_67174_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_766_fu_67174_p0.read()) * sc_bigint<5>(mul_ln1118_766_fu_67174_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_767_fu_67193_p0() {
    mul_ln1118_767_fu_67193_p0 =  (sc_lv<12>) (sext_ln1116_167_cast_fu_55283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_767_fu_67193_p1() {
    mul_ln1118_767_fu_67193_p1 = tmp_767_reg_100392.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_767_fu_67193_p2() {
    mul_ln1118_767_fu_67193_p2 = (!mul_ln1118_767_fu_67193_p0.read().is_01() || !mul_ln1118_767_fu_67193_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_767_fu_67193_p0.read()) * sc_bigint<5>(mul_ln1118_767_fu_67193_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_768_fu_67212_p0() {
    mul_ln1118_768_fu_67212_p0 =  (sc_lv<12>) (sext_ln1116_168_cast_fu_55305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_768_fu_67212_p1() {
    mul_ln1118_768_fu_67212_p1 = tmp_768_reg_100397.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_768_fu_67212_p2() {
    mul_ln1118_768_fu_67212_p2 = (!mul_ln1118_768_fu_67212_p0.read().is_01() || !mul_ln1118_768_fu_67212_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_768_fu_67212_p0.read()) * sc_bigint<5>(mul_ln1118_768_fu_67212_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_769_fu_67231_p0() {
    mul_ln1118_769_fu_67231_p0 =  (sc_lv<12>) (sext_ln1116_169_cast_fu_55327_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_769_fu_67231_p1() {
    mul_ln1118_769_fu_67231_p1 = tmp_769_reg_100402.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_769_fu_67231_p2() {
    mul_ln1118_769_fu_67231_p2 = (!mul_ln1118_769_fu_67231_p0.read().is_01() || !mul_ln1118_769_fu_67231_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_769_fu_67231_p0.read()) * sc_bigint<5>(mul_ln1118_769_fu_67231_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_76_fu_53743_p0() {
    mul_ln1118_76_fu_53743_p0 =  (sc_lv<12>) (sext_ln1116_76_cast_fu_53737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_76_fu_53743_p1() {
    mul_ln1118_76_fu_53743_p1 = tmp_76_reg_96368.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_76_fu_53743_p2() {
    mul_ln1118_76_fu_53743_p2 = (!mul_ln1118_76_fu_53743_p0.read().is_01() || !mul_ln1118_76_fu_53743_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_76_fu_53743_p0.read()) * sc_bigint<5>(mul_ln1118_76_fu_53743_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_770_fu_67250_p0() {
    mul_ln1118_770_fu_67250_p0 =  (sc_lv<12>) (sext_ln1116_170_cast_fu_55349_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_770_fu_67250_p1() {
    mul_ln1118_770_fu_67250_p1 = tmp_770_reg_100407.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_770_fu_67250_p2() {
    mul_ln1118_770_fu_67250_p2 = (!mul_ln1118_770_fu_67250_p0.read().is_01() || !mul_ln1118_770_fu_67250_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_770_fu_67250_p0.read()) * sc_bigint<5>(mul_ln1118_770_fu_67250_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_771_fu_67269_p0() {
    mul_ln1118_771_fu_67269_p0 =  (sc_lv<12>) (sext_ln1116_171_cast_fu_55371_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_771_fu_67269_p1() {
    mul_ln1118_771_fu_67269_p1 = tmp_771_reg_100412.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_771_fu_67269_p2() {
    mul_ln1118_771_fu_67269_p2 = (!mul_ln1118_771_fu_67269_p0.read().is_01() || !mul_ln1118_771_fu_67269_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_771_fu_67269_p0.read()) * sc_bigint<5>(mul_ln1118_771_fu_67269_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_772_fu_67288_p0() {
    mul_ln1118_772_fu_67288_p0 =  (sc_lv<12>) (sext_ln1116_172_cast_fu_55393_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_772_fu_67288_p1() {
    mul_ln1118_772_fu_67288_p1 = tmp_772_reg_100417.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_772_fu_67288_p2() {
    mul_ln1118_772_fu_67288_p2 = (!mul_ln1118_772_fu_67288_p0.read().is_01() || !mul_ln1118_772_fu_67288_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_772_fu_67288_p0.read()) * sc_bigint<5>(mul_ln1118_772_fu_67288_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_773_fu_67307_p0() {
    mul_ln1118_773_fu_67307_p0 =  (sc_lv<12>) (sext_ln1116_173_cast_fu_55415_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_773_fu_67307_p1() {
    mul_ln1118_773_fu_67307_p1 = tmp_773_reg_100422.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_773_fu_67307_p2() {
    mul_ln1118_773_fu_67307_p2 = (!mul_ln1118_773_fu_67307_p0.read().is_01() || !mul_ln1118_773_fu_67307_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_773_fu_67307_p0.read()) * sc_bigint<5>(mul_ln1118_773_fu_67307_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_774_fu_67326_p0() {
    mul_ln1118_774_fu_67326_p0 =  (sc_lv<12>) (sext_ln1116_174_cast_fu_55437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_774_fu_67326_p1() {
    mul_ln1118_774_fu_67326_p1 = tmp_774_reg_100427.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_774_fu_67326_p2() {
    mul_ln1118_774_fu_67326_p2 = (!mul_ln1118_774_fu_67326_p0.read().is_01() || !mul_ln1118_774_fu_67326_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_774_fu_67326_p0.read()) * sc_bigint<5>(mul_ln1118_774_fu_67326_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_775_fu_67345_p0() {
    mul_ln1118_775_fu_67345_p0 =  (sc_lv<12>) (sext_ln1116_175_cast_fu_55459_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_775_fu_67345_p1() {
    mul_ln1118_775_fu_67345_p1 = tmp_775_reg_100432.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_775_fu_67345_p2() {
    mul_ln1118_775_fu_67345_p2 = (!mul_ln1118_775_fu_67345_p0.read().is_01() || !mul_ln1118_775_fu_67345_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_775_fu_67345_p0.read()) * sc_bigint<5>(mul_ln1118_775_fu_67345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_776_fu_67364_p0() {
    mul_ln1118_776_fu_67364_p0 =  (sc_lv<12>) (sext_ln1116_176_cast_reg_97300.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_776_fu_67364_p1() {
    mul_ln1118_776_fu_67364_p1 = tmp_776_reg_100437.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_776_fu_67364_p2() {
    mul_ln1118_776_fu_67364_p2 = (!mul_ln1118_776_fu_67364_p0.read().is_01() || !mul_ln1118_776_fu_67364_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_776_fu_67364_p0.read()) * sc_bigint<5>(mul_ln1118_776_fu_67364_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_777_fu_67382_p0() {
    mul_ln1118_777_fu_67382_p0 =  (sc_lv<12>) (sext_ln1116_177_cast_reg_97318.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_777_fu_67382_p1() {
    mul_ln1118_777_fu_67382_p1 = tmp_777_reg_100442.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_777_fu_67382_p2() {
    mul_ln1118_777_fu_67382_p2 = (!mul_ln1118_777_fu_67382_p0.read().is_01() || !mul_ln1118_777_fu_67382_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_777_fu_67382_p0.read()) * sc_bigint<5>(mul_ln1118_777_fu_67382_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_778_fu_34635_p0() {
    mul_ln1118_778_fu_34635_p0 =  (sc_lv<12>) (sext_ln1116_178_cast_fu_25695_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_778_fu_34635_p1() {
    mul_ln1118_778_fu_34635_p1 = tmp_778_fu_34621_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_778_fu_34635_p2() {
    mul_ln1118_778_fu_34635_p2 = (!mul_ln1118_778_fu_34635_p0.read().is_01() || !mul_ln1118_778_fu_34635_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_778_fu_34635_p0.read()) * sc_bigint<5>(mul_ln1118_778_fu_34635_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_779_fu_34665_p0() {
    mul_ln1118_779_fu_34665_p0 =  (sc_lv<12>) (sext_ln1116_179_cast_fu_25737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_779_fu_34665_p1() {
    mul_ln1118_779_fu_34665_p1 = tmp_779_fu_34651_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_779_fu_34665_p2() {
    mul_ln1118_779_fu_34665_p2 = (!mul_ln1118_779_fu_34665_p0.read().is_01() || !mul_ln1118_779_fu_34665_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_779_fu_34665_p0.read()) * sc_bigint<5>(mul_ln1118_779_fu_34665_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_77_fu_53762_p0() {
    mul_ln1118_77_fu_53762_p0 =  (sc_lv<12>) (sext_ln1116_77_cast_reg_96378.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_77_fu_53762_p1() {
    mul_ln1118_77_fu_53762_p1 = tmp_77_reg_96373.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_77_fu_53762_p2() {
    mul_ln1118_77_fu_53762_p2 = (!mul_ln1118_77_fu_53762_p0.read().is_01() || !mul_ln1118_77_fu_53762_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_77_fu_53762_p0.read()) * sc_bigint<5>(mul_ln1118_77_fu_53762_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_780_fu_34695_p0() {
    mul_ln1118_780_fu_34695_p0 =  (sc_lv<12>) (sext_ln1116_180_cast_fu_25779_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_780_fu_34695_p1() {
    mul_ln1118_780_fu_34695_p1 = tmp_780_fu_34681_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_780_fu_34695_p2() {
    mul_ln1118_780_fu_34695_p2 = (!mul_ln1118_780_fu_34695_p0.read().is_01() || !mul_ln1118_780_fu_34695_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_780_fu_34695_p0.read()) * sc_bigint<5>(mul_ln1118_780_fu_34695_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_781_fu_34725_p0() {
    mul_ln1118_781_fu_34725_p0 =  (sc_lv<12>) (sext_ln1116_181_cast_fu_25821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_781_fu_34725_p1() {
    mul_ln1118_781_fu_34725_p1 = tmp_781_fu_34711_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_781_fu_34725_p2() {
    mul_ln1118_781_fu_34725_p2 = (!mul_ln1118_781_fu_34725_p0.read().is_01() || !mul_ln1118_781_fu_34725_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_781_fu_34725_p0.read()) * sc_bigint<5>(mul_ln1118_781_fu_34725_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_782_fu_34755_p0() {
    mul_ln1118_782_fu_34755_p0 =  (sc_lv<12>) (sext_ln1116_182_cast_fu_25863_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_782_fu_34755_p1() {
    mul_ln1118_782_fu_34755_p1 = tmp_782_fu_34741_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_782_fu_34755_p2() {
    mul_ln1118_782_fu_34755_p2 = (!mul_ln1118_782_fu_34755_p0.read().is_01() || !mul_ln1118_782_fu_34755_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_782_fu_34755_p0.read()) * sc_bigint<5>(mul_ln1118_782_fu_34755_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_783_fu_34785_p0() {
    mul_ln1118_783_fu_34785_p0 =  (sc_lv<12>) (sext_ln1116_183_cast_fu_25905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_783_fu_34785_p1() {
    mul_ln1118_783_fu_34785_p1 = tmp_783_fu_34771_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_783_fu_34785_p2() {
    mul_ln1118_783_fu_34785_p2 = (!mul_ln1118_783_fu_34785_p0.read().is_01() || !mul_ln1118_783_fu_34785_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_783_fu_34785_p0.read()) * sc_bigint<5>(mul_ln1118_783_fu_34785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_784_fu_67400_p0() {
    mul_ln1118_784_fu_67400_p0 =  (sc_lv<12>) (sext_ln1116_184_cast_fu_55517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_784_fu_67400_p1() {
    mul_ln1118_784_fu_67400_p1 = tmp_784_reg_100477.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_784_fu_67400_p2() {
    mul_ln1118_784_fu_67400_p2 = (!mul_ln1118_784_fu_67400_p0.read().is_01() || !mul_ln1118_784_fu_67400_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_784_fu_67400_p0.read()) * sc_bigint<5>(mul_ln1118_784_fu_67400_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_785_fu_67419_p0() {
    mul_ln1118_785_fu_67419_p0 =  (sc_lv<12>) (sext_ln1116_185_cast_fu_55539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_785_fu_67419_p1() {
    mul_ln1118_785_fu_67419_p1 = tmp_785_reg_100482.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_785_fu_67419_p2() {
    mul_ln1118_785_fu_67419_p2 = (!mul_ln1118_785_fu_67419_p0.read().is_01() || !mul_ln1118_785_fu_67419_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_785_fu_67419_p0.read()) * sc_bigint<5>(mul_ln1118_785_fu_67419_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_786_fu_67438_p0() {
    mul_ln1118_786_fu_67438_p0 =  (sc_lv<12>) (sext_ln1116_186_cast_fu_55561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_786_fu_67438_p1() {
    mul_ln1118_786_fu_67438_p1 = tmp_786_reg_100487.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_786_fu_67438_p2() {
    mul_ln1118_786_fu_67438_p2 = (!mul_ln1118_786_fu_67438_p0.read().is_01() || !mul_ln1118_786_fu_67438_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_786_fu_67438_p0.read()) * sc_bigint<5>(mul_ln1118_786_fu_67438_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_787_fu_67457_p0() {
    mul_ln1118_787_fu_67457_p0 =  (sc_lv<12>) (sext_ln1116_187_cast_fu_55583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_787_fu_67457_p1() {
    mul_ln1118_787_fu_67457_p1 = tmp_787_reg_100492.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_787_fu_67457_p2() {
    mul_ln1118_787_fu_67457_p2 = (!mul_ln1118_787_fu_67457_p0.read().is_01() || !mul_ln1118_787_fu_67457_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_787_fu_67457_p0.read()) * sc_bigint<5>(mul_ln1118_787_fu_67457_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_788_fu_67476_p0() {
    mul_ln1118_788_fu_67476_p0 =  (sc_lv<12>) (sext_ln1116_188_cast_fu_55605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_788_fu_67476_p1() {
    mul_ln1118_788_fu_67476_p1 = tmp_788_reg_100497.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_788_fu_67476_p2() {
    mul_ln1118_788_fu_67476_p2 = (!mul_ln1118_788_fu_67476_p0.read().is_01() || !mul_ln1118_788_fu_67476_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_788_fu_67476_p0.read()) * sc_bigint<5>(mul_ln1118_788_fu_67476_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_789_fu_67495_p0() {
    mul_ln1118_789_fu_67495_p0 =  (sc_lv<12>) (sext_ln1116_189_cast_fu_55627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_789_fu_67495_p1() {
    mul_ln1118_789_fu_67495_p1 = tmp_789_reg_100502.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_789_fu_67495_p2() {
    mul_ln1118_789_fu_67495_p2 = (!mul_ln1118_789_fu_67495_p0.read().is_01() || !mul_ln1118_789_fu_67495_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_789_fu_67495_p0.read()) * sc_bigint<5>(mul_ln1118_789_fu_67495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_78_fu_23403_p0() {
    mul_ln1118_78_fu_23403_p0 =  (sc_lv<12>) (sext_ln1116_78_cast_fu_23395_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_78_fu_23403_p1() {
    mul_ln1118_78_fu_23403_p1 = tmp_78_fu_23385_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_78_fu_23403_p2() {
    mul_ln1118_78_fu_23403_p2 = (!mul_ln1118_78_fu_23403_p0.read().is_01() || !mul_ln1118_78_fu_23403_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_78_fu_23403_p0.read()) * sc_bigint<5>(mul_ln1118_78_fu_23403_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_790_fu_67514_p0() {
    mul_ln1118_790_fu_67514_p0 =  (sc_lv<12>) (sext_ln1116_190_cast_fu_55649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_790_fu_67514_p1() {
    mul_ln1118_790_fu_67514_p1 = tmp_790_reg_100507.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_790_fu_67514_p2() {
    mul_ln1118_790_fu_67514_p2 = (!mul_ln1118_790_fu_67514_p0.read().is_01() || !mul_ln1118_790_fu_67514_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_790_fu_67514_p0.read()) * sc_bigint<5>(mul_ln1118_790_fu_67514_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_791_fu_67533_p0() {
    mul_ln1118_791_fu_67533_p0 =  (sc_lv<12>) (sext_ln1116_191_cast_fu_55671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_791_fu_67533_p1() {
    mul_ln1118_791_fu_67533_p1 = tmp_791_reg_100512.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_791_fu_67533_p2() {
    mul_ln1118_791_fu_67533_p2 = (!mul_ln1118_791_fu_67533_p0.read().is_01() || !mul_ln1118_791_fu_67533_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_791_fu_67533_p0.read()) * sc_bigint<5>(mul_ln1118_791_fu_67533_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_792_fu_67552_p0() {
    mul_ln1118_792_fu_67552_p0 =  (sc_lv<12>) (sext_ln1116_192_cast_fu_55693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_792_fu_67552_p1() {
    mul_ln1118_792_fu_67552_p1 = tmp_792_reg_100517.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_792_fu_67552_p2() {
    mul_ln1118_792_fu_67552_p2 = (!mul_ln1118_792_fu_67552_p0.read().is_01() || !mul_ln1118_792_fu_67552_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_792_fu_67552_p0.read()) * sc_bigint<5>(mul_ln1118_792_fu_67552_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_793_fu_67571_p0() {
    mul_ln1118_793_fu_67571_p0 =  (sc_lv<12>) (sext_ln1116_193_cast_fu_55715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_793_fu_67571_p1() {
    mul_ln1118_793_fu_67571_p1 = tmp_793_reg_100522.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_793_fu_67571_p2() {
    mul_ln1118_793_fu_67571_p2 = (!mul_ln1118_793_fu_67571_p0.read().is_01() || !mul_ln1118_793_fu_67571_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_793_fu_67571_p0.read()) * sc_bigint<5>(mul_ln1118_793_fu_67571_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_794_fu_67590_p0() {
    mul_ln1118_794_fu_67590_p0 =  (sc_lv<12>) (sext_ln1116_194_cast_fu_55737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_794_fu_67590_p1() {
    mul_ln1118_794_fu_67590_p1 = tmp_794_reg_100527.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_794_fu_67590_p2() {
    mul_ln1118_794_fu_67590_p2 = (!mul_ln1118_794_fu_67590_p0.read().is_01() || !mul_ln1118_794_fu_67590_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_794_fu_67590_p0.read()) * sc_bigint<5>(mul_ln1118_794_fu_67590_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_795_fu_67609_p0() {
    mul_ln1118_795_fu_67609_p0 =  (sc_lv<12>) (sext_ln1116_195_cast_fu_55759_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_795_fu_67609_p1() {
    mul_ln1118_795_fu_67609_p1 = tmp_795_reg_100532.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_795_fu_67609_p2() {
    mul_ln1118_795_fu_67609_p2 = (!mul_ln1118_795_fu_67609_p0.read().is_01() || !mul_ln1118_795_fu_67609_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_795_fu_67609_p0.read()) * sc_bigint<5>(mul_ln1118_795_fu_67609_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_796_fu_67628_p0() {
    mul_ln1118_796_fu_67628_p0 =  (sc_lv<12>) (sext_ln1116_196_cast_fu_55781_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_796_fu_67628_p1() {
    mul_ln1118_796_fu_67628_p1 = tmp_796_reg_100537.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_796_fu_67628_p2() {
    mul_ln1118_796_fu_67628_p2 = (!mul_ln1118_796_fu_67628_p0.read().is_01() || !mul_ln1118_796_fu_67628_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_796_fu_67628_p0.read()) * sc_bigint<5>(mul_ln1118_796_fu_67628_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_797_fu_67647_p0() {
    mul_ln1118_797_fu_67647_p0 =  (sc_lv<12>) (sext_ln1116_197_cast_fu_55803_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_797_fu_67647_p1() {
    mul_ln1118_797_fu_67647_p1 = tmp_797_reg_100542.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_797_fu_67647_p2() {
    mul_ln1118_797_fu_67647_p2 = (!mul_ln1118_797_fu_67647_p0.read().is_01() || !mul_ln1118_797_fu_67647_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_797_fu_67647_p0.read()) * sc_bigint<5>(mul_ln1118_797_fu_67647_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_798_fu_67666_p0() {
    mul_ln1118_798_fu_67666_p0 =  (sc_lv<12>) (sext_ln1116_198_cast_fu_55825_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_798_fu_67666_p1() {
    mul_ln1118_798_fu_67666_p1 = tmp_798_reg_100547.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_798_fu_67666_p2() {
    mul_ln1118_798_fu_67666_p2 = (!mul_ln1118_798_fu_67666_p0.read().is_01() || !mul_ln1118_798_fu_67666_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_798_fu_67666_p0.read()) * sc_bigint<5>(mul_ln1118_798_fu_67666_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_799_fu_67685_p0() {
    mul_ln1118_799_fu_67685_p0 =  (sc_lv<12>) (sext_ln1116_199_cast_fu_55847_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_799_fu_67685_p1() {
    mul_ln1118_799_fu_67685_p1 = tmp_799_reg_100552.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_799_fu_67685_p2() {
    mul_ln1118_799_fu_67685_p2 = (!mul_ln1118_799_fu_67685_p0.read().is_01() || !mul_ln1118_799_fu_67685_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_799_fu_67685_p0.read()) * sc_bigint<5>(mul_ln1118_799_fu_67685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_79_fu_23445_p0() {
    mul_ln1118_79_fu_23445_p0 =  (sc_lv<12>) (sext_ln1116_79_cast_fu_23437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_79_fu_23445_p1() {
    mul_ln1118_79_fu_23445_p1 = tmp_79_fu_23427_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_79_fu_23445_p2() {
    mul_ln1118_79_fu_23445_p2 = (!mul_ln1118_79_fu_23445_p0.read().is_01() || !mul_ln1118_79_fu_23445_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_79_fu_23445_p0.read()) * sc_bigint<5>(mul_ln1118_79_fu_23445_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_800_fu_67704_p0() {
    mul_ln1118_800_fu_67704_p0 =  (sc_lv<12>) (sext_ln1116_200_cast_fu_55869_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_800_fu_67704_p1() {
    mul_ln1118_800_fu_67704_p1 = tmp_800_reg_100557.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_800_fu_67704_p2() {
    mul_ln1118_800_fu_67704_p2 = (!mul_ln1118_800_fu_67704_p0.read().is_01() || !mul_ln1118_800_fu_67704_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_800_fu_67704_p0.read()) * sc_bigint<5>(mul_ln1118_800_fu_67704_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_801_fu_67723_p0() {
    mul_ln1118_801_fu_67723_p0 =  (sc_lv<12>) (sext_ln1116_201_cast_reg_97536.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_801_fu_67723_p1() {
    mul_ln1118_801_fu_67723_p1 = tmp_801_reg_100562.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_801_fu_67723_p2() {
    mul_ln1118_801_fu_67723_p2 = (!mul_ln1118_801_fu_67723_p0.read().is_01() || !mul_ln1118_801_fu_67723_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_801_fu_67723_p0.read()) * sc_bigint<5>(mul_ln1118_801_fu_67723_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_802_fu_67741_p0() {
    mul_ln1118_802_fu_67741_p0 =  (sc_lv<12>) (sext_ln1116_202_cast_reg_97554.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_802_fu_67741_p1() {
    mul_ln1118_802_fu_67741_p1 = tmp_802_reg_100567.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_802_fu_67741_p2() {
    mul_ln1118_802_fu_67741_p2 = (!mul_ln1118_802_fu_67741_p0.read().is_01() || !mul_ln1118_802_fu_67741_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_802_fu_67741_p0.read()) * sc_bigint<5>(mul_ln1118_802_fu_67741_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_803_fu_35005_p0() {
    mul_ln1118_803_fu_35005_p0 =  (sc_lv<12>) (sext_ln1116_203_cast_fu_26297_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_803_fu_35005_p1() {
    mul_ln1118_803_fu_35005_p1 = tmp_803_fu_34991_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_803_fu_35005_p2() {
    mul_ln1118_803_fu_35005_p2 = (!mul_ln1118_803_fu_35005_p0.read().is_01() || !mul_ln1118_803_fu_35005_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_803_fu_35005_p0.read()) * sc_bigint<5>(mul_ln1118_803_fu_35005_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_804_fu_35035_p0() {
    mul_ln1118_804_fu_35035_p0 =  (sc_lv<12>) (sext_ln1116_204_cast_fu_26339_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_804_fu_35035_p1() {
    mul_ln1118_804_fu_35035_p1 = tmp_804_fu_35021_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_804_fu_35035_p2() {
    mul_ln1118_804_fu_35035_p2 = (!mul_ln1118_804_fu_35035_p0.read().is_01() || !mul_ln1118_804_fu_35035_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_804_fu_35035_p0.read()) * sc_bigint<5>(mul_ln1118_804_fu_35035_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_805_fu_35065_p0() {
    mul_ln1118_805_fu_35065_p0 =  (sc_lv<12>) (sext_ln1116_205_cast_fu_26381_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_805_fu_35065_p1() {
    mul_ln1118_805_fu_35065_p1 = tmp_805_fu_35051_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_805_fu_35065_p2() {
    mul_ln1118_805_fu_35065_p2 = (!mul_ln1118_805_fu_35065_p0.read().is_01() || !mul_ln1118_805_fu_35065_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_805_fu_35065_p0.read()) * sc_bigint<5>(mul_ln1118_805_fu_35065_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_806_fu_35095_p0() {
    mul_ln1118_806_fu_35095_p0 =  (sc_lv<12>) (sext_ln1116_206_cast_fu_26423_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_806_fu_35095_p1() {
    mul_ln1118_806_fu_35095_p1 = tmp_806_fu_35081_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_806_fu_35095_p2() {
    mul_ln1118_806_fu_35095_p2 = (!mul_ln1118_806_fu_35095_p0.read().is_01() || !mul_ln1118_806_fu_35095_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_806_fu_35095_p0.read()) * sc_bigint<5>(mul_ln1118_806_fu_35095_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_807_fu_35125_p0() {
    mul_ln1118_807_fu_35125_p0 =  (sc_lv<12>) (sext_ln1116_207_cast_fu_26465_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_807_fu_35125_p1() {
    mul_ln1118_807_fu_35125_p1 = tmp_807_fu_35111_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_807_fu_35125_p2() {
    mul_ln1118_807_fu_35125_p2 = (!mul_ln1118_807_fu_35125_p0.read().is_01() || !mul_ln1118_807_fu_35125_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_807_fu_35125_p0.read()) * sc_bigint<5>(mul_ln1118_807_fu_35125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_808_fu_35155_p0() {
    mul_ln1118_808_fu_35155_p0 =  (sc_lv<12>) (sext_ln1116_208_cast_fu_26507_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_808_fu_35155_p1() {
    mul_ln1118_808_fu_35155_p1 = tmp_808_fu_35141_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_808_fu_35155_p2() {
    mul_ln1118_808_fu_35155_p2 = (!mul_ln1118_808_fu_35155_p0.read().is_01() || !mul_ln1118_808_fu_35155_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_808_fu_35155_p0.read()) * sc_bigint<5>(mul_ln1118_808_fu_35155_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_809_fu_68747_p0() {
    mul_ln1118_809_fu_68747_p0 =  (sc_lv<12>) (sext_ln1116_cast_fu_52531_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_809_fu_68747_p1() {
    mul_ln1118_809_fu_68747_p1 = tmp_809_reg_100602.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_809_fu_68747_p2() {
    mul_ln1118_809_fu_68747_p2 = (!mul_ln1118_809_fu_68747_p0.read().is_01() || !mul_ln1118_809_fu_68747_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_809_fu_68747_p0.read()) * sc_bigint<5>(mul_ln1118_809_fu_68747_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_80_fu_23487_p0() {
    mul_ln1118_80_fu_23487_p0 =  (sc_lv<12>) (sext_ln1116_80_cast_fu_23479_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_80_fu_23487_p1() {
    mul_ln1118_80_fu_23487_p1 = tmp_80_fu_23469_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_80_fu_23487_p2() {
    mul_ln1118_80_fu_23487_p2 = (!mul_ln1118_80_fu_23487_p0.read().is_01() || !mul_ln1118_80_fu_23487_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_80_fu_23487_p0.read()) * sc_bigint<5>(mul_ln1118_80_fu_23487_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_810_fu_68766_p0() {
    mul_ln1118_810_fu_68766_p0 =  (sc_lv<12>) (sext_ln1116_10_cast_fu_52553_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_810_fu_68766_p1() {
    mul_ln1118_810_fu_68766_p1 = tmp_810_reg_100607.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_810_fu_68766_p2() {
    mul_ln1118_810_fu_68766_p2 = (!mul_ln1118_810_fu_68766_p0.read().is_01() || !mul_ln1118_810_fu_68766_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_810_fu_68766_p0.read()) * sc_bigint<5>(mul_ln1118_810_fu_68766_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_811_fu_68785_p0() {
    mul_ln1118_811_fu_68785_p0 =  (sc_lv<12>) (sext_ln1116_11_cast_fu_52575_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_811_fu_68785_p1() {
    mul_ln1118_811_fu_68785_p1 = tmp_811_reg_100612.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_811_fu_68785_p2() {
    mul_ln1118_811_fu_68785_p2 = (!mul_ln1118_811_fu_68785_p0.read().is_01() || !mul_ln1118_811_fu_68785_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_811_fu_68785_p0.read()) * sc_bigint<5>(mul_ln1118_811_fu_68785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_812_fu_68804_p0() {
    mul_ln1118_812_fu_68804_p0 =  (sc_lv<12>) (sext_ln1116_12_cast_fu_52597_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_812_fu_68804_p1() {
    mul_ln1118_812_fu_68804_p1 = tmp_812_reg_100617.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_812_fu_68804_p2() {
    mul_ln1118_812_fu_68804_p2 = (!mul_ln1118_812_fu_68804_p0.read().is_01() || !mul_ln1118_812_fu_68804_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_812_fu_68804_p0.read()) * sc_bigint<5>(mul_ln1118_812_fu_68804_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_813_fu_68823_p0() {
    mul_ln1118_813_fu_68823_p0 =  (sc_lv<12>) (sext_ln1116_13_cast_fu_52619_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_813_fu_68823_p1() {
    mul_ln1118_813_fu_68823_p1 = tmp_813_reg_100622.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_813_fu_68823_p2() {
    mul_ln1118_813_fu_68823_p2 = (!mul_ln1118_813_fu_68823_p0.read().is_01() || !mul_ln1118_813_fu_68823_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_813_fu_68823_p0.read()) * sc_bigint<5>(mul_ln1118_813_fu_68823_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_814_fu_68842_p0() {
    mul_ln1118_814_fu_68842_p0 =  (sc_lv<12>) (sext_ln1116_14_cast_fu_52641_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_814_fu_68842_p1() {
    mul_ln1118_814_fu_68842_p1 = tmp_814_reg_100627.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_814_fu_68842_p2() {
    mul_ln1118_814_fu_68842_p2 = (!mul_ln1118_814_fu_68842_p0.read().is_01() || !mul_ln1118_814_fu_68842_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_814_fu_68842_p0.read()) * sc_bigint<5>(mul_ln1118_814_fu_68842_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_815_fu_68861_p0() {
    mul_ln1118_815_fu_68861_p0 =  (sc_lv<12>) (sext_ln1116_15_cast_fu_52663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_815_fu_68861_p1() {
    mul_ln1118_815_fu_68861_p1 = tmp_815_reg_100632.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_815_fu_68861_p2() {
    mul_ln1118_815_fu_68861_p2 = (!mul_ln1118_815_fu_68861_p0.read().is_01() || !mul_ln1118_815_fu_68861_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_815_fu_68861_p0.read()) * sc_bigint<5>(mul_ln1118_815_fu_68861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_816_fu_68880_p0() {
    mul_ln1118_816_fu_68880_p0 =  (sc_lv<12>) (sext_ln1116_16_cast_fu_52685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_816_fu_68880_p1() {
    mul_ln1118_816_fu_68880_p1 = tmp_816_reg_100637.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_816_fu_68880_p2() {
    mul_ln1118_816_fu_68880_p2 = (!mul_ln1118_816_fu_68880_p0.read().is_01() || !mul_ln1118_816_fu_68880_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_816_fu_68880_p0.read()) * sc_bigint<5>(mul_ln1118_816_fu_68880_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_817_fu_68899_p0() {
    mul_ln1118_817_fu_68899_p0 =  (sc_lv<12>) (sext_ln1116_17_cast_fu_52707_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_817_fu_68899_p1() {
    mul_ln1118_817_fu_68899_p1 = tmp_817_reg_100642.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_817_fu_68899_p2() {
    mul_ln1118_817_fu_68899_p2 = (!mul_ln1118_817_fu_68899_p0.read().is_01() || !mul_ln1118_817_fu_68899_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_817_fu_68899_p0.read()) * sc_bigint<5>(mul_ln1118_817_fu_68899_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_818_fu_68918_p0() {
    mul_ln1118_818_fu_68918_p0 =  (sc_lv<12>) (sext_ln1116_18_cast_fu_52729_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_818_fu_68918_p1() {
    mul_ln1118_818_fu_68918_p1 = tmp_818_reg_100647.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_818_fu_68918_p2() {
    mul_ln1118_818_fu_68918_p2 = (!mul_ln1118_818_fu_68918_p0.read().is_01() || !mul_ln1118_818_fu_68918_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_818_fu_68918_p0.read()) * sc_bigint<5>(mul_ln1118_818_fu_68918_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_819_fu_68937_p0() {
    mul_ln1118_819_fu_68937_p0 =  (sc_lv<12>) (sext_ln1116_19_cast_fu_52751_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_819_fu_68937_p1() {
    mul_ln1118_819_fu_68937_p1 = tmp_819_reg_100652.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_819_fu_68937_p2() {
    mul_ln1118_819_fu_68937_p2 = (!mul_ln1118_819_fu_68937_p0.read().is_01() || !mul_ln1118_819_fu_68937_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_819_fu_68937_p0.read()) * sc_bigint<5>(mul_ln1118_819_fu_68937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_81_fu_23529_p0() {
    mul_ln1118_81_fu_23529_p0 =  (sc_lv<12>) (sext_ln1116_81_cast_fu_23521_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_81_fu_23529_p1() {
    mul_ln1118_81_fu_23529_p1 = tmp_81_fu_23511_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_81_fu_23529_p2() {
    mul_ln1118_81_fu_23529_p2 = (!mul_ln1118_81_fu_23529_p0.read().is_01() || !mul_ln1118_81_fu_23529_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_81_fu_23529_p0.read()) * sc_bigint<5>(mul_ln1118_81_fu_23529_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_820_fu_68956_p0() {
    mul_ln1118_820_fu_68956_p0 =  (sc_lv<12>) (sext_ln1116_20_cast_fu_52773_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_820_fu_68956_p1() {
    mul_ln1118_820_fu_68956_p1 = tmp_820_reg_100657.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_820_fu_68956_p2() {
    mul_ln1118_820_fu_68956_p2 = (!mul_ln1118_820_fu_68956_p0.read().is_01() || !mul_ln1118_820_fu_68956_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_820_fu_68956_p0.read()) * sc_bigint<5>(mul_ln1118_820_fu_68956_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_821_fu_68975_p0() {
    mul_ln1118_821_fu_68975_p0 =  (sc_lv<12>) (sext_ln1116_21_cast_fu_52795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_821_fu_68975_p1() {
    mul_ln1118_821_fu_68975_p1 = tmp_821_reg_100662.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_821_fu_68975_p2() {
    mul_ln1118_821_fu_68975_p2 = (!mul_ln1118_821_fu_68975_p0.read().is_01() || !mul_ln1118_821_fu_68975_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_821_fu_68975_p0.read()) * sc_bigint<5>(mul_ln1118_821_fu_68975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_822_fu_68994_p0() {
    mul_ln1118_822_fu_68994_p0 =  (sc_lv<12>) (sext_ln1116_22_cast_fu_52817_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_822_fu_68994_p1() {
    mul_ln1118_822_fu_68994_p1 = tmp_822_reg_100667.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_822_fu_68994_p2() {
    mul_ln1118_822_fu_68994_p2 = (!mul_ln1118_822_fu_68994_p0.read().is_01() || !mul_ln1118_822_fu_68994_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_822_fu_68994_p0.read()) * sc_bigint<5>(mul_ln1118_822_fu_68994_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_823_fu_69013_p0() {
    mul_ln1118_823_fu_69013_p0 =  (sc_lv<12>) (sext_ln1116_23_cast_fu_52839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_823_fu_69013_p1() {
    mul_ln1118_823_fu_69013_p1 = tmp_823_reg_100672.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_823_fu_69013_p2() {
    mul_ln1118_823_fu_69013_p2 = (!mul_ln1118_823_fu_69013_p0.read().is_01() || !mul_ln1118_823_fu_69013_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_823_fu_69013_p0.read()) * sc_bigint<5>(mul_ln1118_823_fu_69013_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_824_fu_69032_p0() {
    mul_ln1118_824_fu_69032_p0 =  (sc_lv<12>) (sext_ln1116_24_cast_fu_52861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_824_fu_69032_p1() {
    mul_ln1118_824_fu_69032_p1 = tmp_824_reg_100677.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_824_fu_69032_p2() {
    mul_ln1118_824_fu_69032_p2 = (!mul_ln1118_824_fu_69032_p0.read().is_01() || !mul_ln1118_824_fu_69032_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_824_fu_69032_p0.read()) * sc_bigint<5>(mul_ln1118_824_fu_69032_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_825_fu_69051_p0() {
    mul_ln1118_825_fu_69051_p0 =  (sc_lv<12>) (sext_ln1116_25_cast_fu_52883_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_825_fu_69051_p1() {
    mul_ln1118_825_fu_69051_p1 = tmp_825_reg_100682.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_825_fu_69051_p2() {
    mul_ln1118_825_fu_69051_p2 = (!mul_ln1118_825_fu_69051_p0.read().is_01() || !mul_ln1118_825_fu_69051_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_825_fu_69051_p0.read()) * sc_bigint<5>(mul_ln1118_825_fu_69051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_826_fu_69070_p0() {
    mul_ln1118_826_fu_69070_p0 =  (sc_lv<12>) (sext_ln1116_26_cast_fu_52905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_826_fu_69070_p1() {
    mul_ln1118_826_fu_69070_p1 = tmp_826_reg_100687.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_826_fu_69070_p2() {
    mul_ln1118_826_fu_69070_p2 = (!mul_ln1118_826_fu_69070_p0.read().is_01() || !mul_ln1118_826_fu_69070_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_826_fu_69070_p0.read()) * sc_bigint<5>(mul_ln1118_826_fu_69070_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_827_fu_69089_p0() {
    mul_ln1118_827_fu_69089_p0 =  (sc_lv<12>) (sext_ln1116_27_cast_fu_52927_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_827_fu_69089_p1() {
    mul_ln1118_827_fu_69089_p1 = tmp_827_reg_100692.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_827_fu_69089_p2() {
    mul_ln1118_827_fu_69089_p2 = (!mul_ln1118_827_fu_69089_p0.read().is_01() || !mul_ln1118_827_fu_69089_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_827_fu_69089_p0.read()) * sc_bigint<5>(mul_ln1118_827_fu_69089_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_828_fu_35375_p0() {
    mul_ln1118_828_fu_35375_p0 =  (sc_lv<12>) (sext_ln1116_28_cast_fu_22199_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_828_fu_35375_p1() {
    mul_ln1118_828_fu_35375_p1 = tmp_828_fu_35361_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_828_fu_35375_p2() {
    mul_ln1118_828_fu_35375_p2 = (!mul_ln1118_828_fu_35375_p0.read().is_01() || !mul_ln1118_828_fu_35375_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_828_fu_35375_p0.read()) * sc_bigint<5>(mul_ln1118_828_fu_35375_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_829_fu_35405_p0() {
    mul_ln1118_829_fu_35405_p0 =  (sc_lv<12>) (sext_ln1116_29_cast_fu_22241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_829_fu_35405_p1() {
    mul_ln1118_829_fu_35405_p1 = tmp_829_fu_35391_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_829_fu_35405_p2() {
    mul_ln1118_829_fu_35405_p2 = (!mul_ln1118_829_fu_35405_p0.read().is_01() || !mul_ln1118_829_fu_35405_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_829_fu_35405_p0.read()) * sc_bigint<5>(mul_ln1118_829_fu_35405_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_82_fu_23571_p0() {
    mul_ln1118_82_fu_23571_p0 =  (sc_lv<12>) (sext_ln1116_82_cast_fu_23563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_82_fu_23571_p1() {
    mul_ln1118_82_fu_23571_p1 = tmp_82_fu_23553_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_82_fu_23571_p2() {
    mul_ln1118_82_fu_23571_p2 = (!mul_ln1118_82_fu_23571_p0.read().is_01() || !mul_ln1118_82_fu_23571_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_82_fu_23571_p0.read()) * sc_bigint<5>(mul_ln1118_82_fu_23571_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_830_fu_35435_p0() {
    mul_ln1118_830_fu_35435_p0 =  (sc_lv<12>) (sext_ln1116_30_cast_fu_22283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_830_fu_35435_p1() {
    mul_ln1118_830_fu_35435_p1 = tmp_830_fu_35421_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_830_fu_35435_p2() {
    mul_ln1118_830_fu_35435_p2 = (!mul_ln1118_830_fu_35435_p0.read().is_01() || !mul_ln1118_830_fu_35435_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_830_fu_35435_p0.read()) * sc_bigint<5>(mul_ln1118_830_fu_35435_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_831_fu_35465_p0() {
    mul_ln1118_831_fu_35465_p0 =  (sc_lv<12>) (sext_ln1116_31_cast_fu_22325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_831_fu_35465_p1() {
    mul_ln1118_831_fu_35465_p1 = tmp_831_fu_35451_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_831_fu_35465_p2() {
    mul_ln1118_831_fu_35465_p2 = (!mul_ln1118_831_fu_35465_p0.read().is_01() || !mul_ln1118_831_fu_35465_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_831_fu_35465_p0.read()) * sc_bigint<5>(mul_ln1118_831_fu_35465_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_832_fu_35495_p0() {
    mul_ln1118_832_fu_35495_p0 =  (sc_lv<12>) (sext_ln1116_32_cast_fu_22367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_832_fu_35495_p1() {
    mul_ln1118_832_fu_35495_p1 = tmp_832_fu_35481_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_832_fu_35495_p2() {
    mul_ln1118_832_fu_35495_p2 = (!mul_ln1118_832_fu_35495_p0.read().is_01() || !mul_ln1118_832_fu_35495_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_832_fu_35495_p0.read()) * sc_bigint<5>(mul_ln1118_832_fu_35495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_833_fu_35525_p0() {
    mul_ln1118_833_fu_35525_p0 =  (sc_lv<12>) (sext_ln1116_33_cast_fu_22409_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_833_fu_35525_p1() {
    mul_ln1118_833_fu_35525_p1 = tmp_833_fu_35511_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_833_fu_35525_p2() {
    mul_ln1118_833_fu_35525_p2 = (!mul_ln1118_833_fu_35525_p0.read().is_01() || !mul_ln1118_833_fu_35525_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_833_fu_35525_p0.read()) * sc_bigint<5>(mul_ln1118_833_fu_35525_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_834_fu_69108_p0() {
    mul_ln1118_834_fu_69108_p0 =  (sc_lv<12>) (sext_ln1116_34_cast_fu_52949_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_834_fu_69108_p1() {
    mul_ln1118_834_fu_69108_p1 = tmp_834_reg_100727.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_834_fu_69108_p2() {
    mul_ln1118_834_fu_69108_p2 = (!mul_ln1118_834_fu_69108_p0.read().is_01() || !mul_ln1118_834_fu_69108_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_834_fu_69108_p0.read()) * sc_bigint<5>(mul_ln1118_834_fu_69108_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_835_fu_69127_p0() {
    mul_ln1118_835_fu_69127_p0 =  (sc_lv<12>) (sext_ln1116_35_cast_fu_52971_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_835_fu_69127_p1() {
    mul_ln1118_835_fu_69127_p1 = tmp_835_reg_100732.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_835_fu_69127_p2() {
    mul_ln1118_835_fu_69127_p2 = (!mul_ln1118_835_fu_69127_p0.read().is_01() || !mul_ln1118_835_fu_69127_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_835_fu_69127_p0.read()) * sc_bigint<5>(mul_ln1118_835_fu_69127_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_836_fu_69146_p0() {
    mul_ln1118_836_fu_69146_p0 =  (sc_lv<12>) (sext_ln1116_36_cast_fu_52993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_836_fu_69146_p1() {
    mul_ln1118_836_fu_69146_p1 = tmp_836_reg_100737.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_836_fu_69146_p2() {
    mul_ln1118_836_fu_69146_p2 = (!mul_ln1118_836_fu_69146_p0.read().is_01() || !mul_ln1118_836_fu_69146_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_836_fu_69146_p0.read()) * sc_bigint<5>(mul_ln1118_836_fu_69146_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_837_fu_69165_p0() {
    mul_ln1118_837_fu_69165_p0 =  (sc_lv<12>) (sext_ln1116_37_cast_fu_53015_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_837_fu_69165_p1() {
    mul_ln1118_837_fu_69165_p1 = tmp_837_reg_100742.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_837_fu_69165_p2() {
    mul_ln1118_837_fu_69165_p2 = (!mul_ln1118_837_fu_69165_p0.read().is_01() || !mul_ln1118_837_fu_69165_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_837_fu_69165_p0.read()) * sc_bigint<5>(mul_ln1118_837_fu_69165_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_838_fu_69184_p0() {
    mul_ln1118_838_fu_69184_p0 =  (sc_lv<12>) (sext_ln1116_38_cast_fu_53037_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_838_fu_69184_p1() {
    mul_ln1118_838_fu_69184_p1 = tmp_838_reg_100747.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_838_fu_69184_p2() {
    mul_ln1118_838_fu_69184_p2 = (!mul_ln1118_838_fu_69184_p0.read().is_01() || !mul_ln1118_838_fu_69184_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_838_fu_69184_p0.read()) * sc_bigint<5>(mul_ln1118_838_fu_69184_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_839_fu_69203_p0() {
    mul_ln1118_839_fu_69203_p0 =  (sc_lv<12>) (sext_ln1116_39_cast_fu_53059_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_839_fu_69203_p1() {
    mul_ln1118_839_fu_69203_p1 = tmp_839_reg_100752.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_839_fu_69203_p2() {
    mul_ln1118_839_fu_69203_p2 = (!mul_ln1118_839_fu_69203_p0.read().is_01() || !mul_ln1118_839_fu_69203_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_839_fu_69203_p0.read()) * sc_bigint<5>(mul_ln1118_839_fu_69203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_83_fu_23613_p0() {
    mul_ln1118_83_fu_23613_p0 =  (sc_lv<12>) (sext_ln1116_83_cast_fu_23605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_83_fu_23613_p1() {
    mul_ln1118_83_fu_23613_p1 = tmp_83_fu_23595_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_83_fu_23613_p2() {
    mul_ln1118_83_fu_23613_p2 = (!mul_ln1118_83_fu_23613_p0.read().is_01() || !mul_ln1118_83_fu_23613_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_83_fu_23613_p0.read()) * sc_bigint<5>(mul_ln1118_83_fu_23613_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_840_fu_69222_p0() {
    mul_ln1118_840_fu_69222_p0 =  (sc_lv<12>) (sext_ln1116_40_cast_fu_53081_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_840_fu_69222_p1() {
    mul_ln1118_840_fu_69222_p1 = tmp_840_reg_100757.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_840_fu_69222_p2() {
    mul_ln1118_840_fu_69222_p2 = (!mul_ln1118_840_fu_69222_p0.read().is_01() || !mul_ln1118_840_fu_69222_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_840_fu_69222_p0.read()) * sc_bigint<5>(mul_ln1118_840_fu_69222_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_841_fu_69241_p0() {
    mul_ln1118_841_fu_69241_p0 =  (sc_lv<12>) (sext_ln1116_41_cast_fu_53103_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_841_fu_69241_p1() {
    mul_ln1118_841_fu_69241_p1 = tmp_841_reg_100762.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_841_fu_69241_p2() {
    mul_ln1118_841_fu_69241_p2 = (!mul_ln1118_841_fu_69241_p0.read().is_01() || !mul_ln1118_841_fu_69241_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_841_fu_69241_p0.read()) * sc_bigint<5>(mul_ln1118_841_fu_69241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_842_fu_69260_p0() {
    mul_ln1118_842_fu_69260_p0 =  (sc_lv<12>) (sext_ln1116_42_cast_fu_53125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_842_fu_69260_p1() {
    mul_ln1118_842_fu_69260_p1 = tmp_842_reg_100767.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_842_fu_69260_p2() {
    mul_ln1118_842_fu_69260_p2 = (!mul_ln1118_842_fu_69260_p0.read().is_01() || !mul_ln1118_842_fu_69260_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_842_fu_69260_p0.read()) * sc_bigint<5>(mul_ln1118_842_fu_69260_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_843_fu_69279_p0() {
    mul_ln1118_843_fu_69279_p0 =  (sc_lv<12>) (sext_ln1116_43_cast_fu_53147_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_843_fu_69279_p1() {
    mul_ln1118_843_fu_69279_p1 = tmp_843_reg_100772.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_843_fu_69279_p2() {
    mul_ln1118_843_fu_69279_p2 = (!mul_ln1118_843_fu_69279_p0.read().is_01() || !mul_ln1118_843_fu_69279_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_843_fu_69279_p0.read()) * sc_bigint<5>(mul_ln1118_843_fu_69279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_844_fu_69298_p0() {
    mul_ln1118_844_fu_69298_p0 =  (sc_lv<12>) (sext_ln1116_44_cast_fu_53169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_844_fu_69298_p1() {
    mul_ln1118_844_fu_69298_p1 = tmp_844_reg_100777.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_844_fu_69298_p2() {
    mul_ln1118_844_fu_69298_p2 = (!mul_ln1118_844_fu_69298_p0.read().is_01() || !mul_ln1118_844_fu_69298_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_844_fu_69298_p0.read()) * sc_bigint<5>(mul_ln1118_844_fu_69298_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_845_fu_69317_p0() {
    mul_ln1118_845_fu_69317_p0 =  (sc_lv<12>) (sext_ln1116_45_cast_fu_53191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_845_fu_69317_p1() {
    mul_ln1118_845_fu_69317_p1 = tmp_845_reg_100782.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_845_fu_69317_p2() {
    mul_ln1118_845_fu_69317_p2 = (!mul_ln1118_845_fu_69317_p0.read().is_01() || !mul_ln1118_845_fu_69317_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_845_fu_69317_p0.read()) * sc_bigint<5>(mul_ln1118_845_fu_69317_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_846_fu_69336_p0() {
    mul_ln1118_846_fu_69336_p0 =  (sc_lv<12>) (sext_ln1116_46_cast_fu_53213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_846_fu_69336_p1() {
    mul_ln1118_846_fu_69336_p1 = tmp_846_reg_100787.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_846_fu_69336_p2() {
    mul_ln1118_846_fu_69336_p2 = (!mul_ln1118_846_fu_69336_p0.read().is_01() || !mul_ln1118_846_fu_69336_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_846_fu_69336_p0.read()) * sc_bigint<5>(mul_ln1118_846_fu_69336_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_847_fu_69355_p0() {
    mul_ln1118_847_fu_69355_p0 =  (sc_lv<12>) (sext_ln1116_47_cast_fu_53235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_847_fu_69355_p1() {
    mul_ln1118_847_fu_69355_p1 = tmp_847_reg_100792.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_847_fu_69355_p2() {
    mul_ln1118_847_fu_69355_p2 = (!mul_ln1118_847_fu_69355_p0.read().is_01() || !mul_ln1118_847_fu_69355_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_847_fu_69355_p0.read()) * sc_bigint<5>(mul_ln1118_847_fu_69355_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_848_fu_69374_p0() {
    mul_ln1118_848_fu_69374_p0 =  (sc_lv<12>) (sext_ln1116_48_cast_fu_53257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_848_fu_69374_p1() {
    mul_ln1118_848_fu_69374_p1 = tmp_848_reg_100797.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_848_fu_69374_p2() {
    mul_ln1118_848_fu_69374_p2 = (!mul_ln1118_848_fu_69374_p0.read().is_01() || !mul_ln1118_848_fu_69374_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_848_fu_69374_p0.read()) * sc_bigint<5>(mul_ln1118_848_fu_69374_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_849_fu_69393_p0() {
    mul_ln1118_849_fu_69393_p0 =  (sc_lv<12>) (sext_ln1116_49_cast_fu_53279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_849_fu_69393_p1() {
    mul_ln1118_849_fu_69393_p1 = tmp_849_reg_100802.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_849_fu_69393_p2() {
    mul_ln1118_849_fu_69393_p2 = (!mul_ln1118_849_fu_69393_p0.read().is_01() || !mul_ln1118_849_fu_69393_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_849_fu_69393_p0.read()) * sc_bigint<5>(mul_ln1118_849_fu_69393_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_84_fu_53783_p0() {
    mul_ln1118_84_fu_53783_p0 =  (sc_lv<12>) (sext_ln1116_84_cast_fu_53777_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_84_fu_53783_p1() {
    mul_ln1118_84_fu_53783_p1 = tmp_84_reg_96426.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_84_fu_53783_p2() {
    mul_ln1118_84_fu_53783_p2 = (!mul_ln1118_84_fu_53783_p0.read().is_01() || !mul_ln1118_84_fu_53783_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_84_fu_53783_p0.read()) * sc_bigint<5>(mul_ln1118_84_fu_53783_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_850_fu_69412_p0() {
    mul_ln1118_850_fu_69412_p0 =  (sc_lv<12>) (sext_ln1116_50_cast_fu_53301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_850_fu_69412_p1() {
    mul_ln1118_850_fu_69412_p1 = tmp_850_reg_100807.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_850_fu_69412_p2() {
    mul_ln1118_850_fu_69412_p2 = (!mul_ln1118_850_fu_69412_p0.read().is_01() || !mul_ln1118_850_fu_69412_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_850_fu_69412_p0.read()) * sc_bigint<5>(mul_ln1118_850_fu_69412_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_851_fu_69431_p0() {
    mul_ln1118_851_fu_69431_p0 =  (sc_lv<12>) (sext_ln1116_51_cast_fu_53323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_851_fu_69431_p1() {
    mul_ln1118_851_fu_69431_p1 = tmp_851_reg_100812.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_851_fu_69431_p2() {
    mul_ln1118_851_fu_69431_p2 = (!mul_ln1118_851_fu_69431_p0.read().is_01() || !mul_ln1118_851_fu_69431_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_851_fu_69431_p0.read()) * sc_bigint<5>(mul_ln1118_851_fu_69431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_852_fu_69450_p0() {
    mul_ln1118_852_fu_69450_p0 =  (sc_lv<12>) (sext_ln1116_52_cast_reg_96150.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_852_fu_69450_p1() {
    mul_ln1118_852_fu_69450_p1 = tmp_852_reg_100817.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_852_fu_69450_p2() {
    mul_ln1118_852_fu_69450_p2 = (!mul_ln1118_852_fu_69450_p0.read().is_01() || !mul_ln1118_852_fu_69450_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_852_fu_69450_p0.read()) * sc_bigint<5>(mul_ln1118_852_fu_69450_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_853_fu_35745_p0() {
    mul_ln1118_853_fu_35745_p0 =  (sc_lv<12>) (sext_ln1116_53_cast_fu_22797_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_853_fu_35745_p1() {
    mul_ln1118_853_fu_35745_p1 = tmp_853_fu_35731_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_853_fu_35745_p2() {
    mul_ln1118_853_fu_35745_p2 = (!mul_ln1118_853_fu_35745_p0.read().is_01() || !mul_ln1118_853_fu_35745_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_853_fu_35745_p0.read()) * sc_bigint<5>(mul_ln1118_853_fu_35745_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_854_fu_35775_p0() {
    mul_ln1118_854_fu_35775_p0 =  (sc_lv<12>) (sext_ln1116_54_cast_fu_22839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_854_fu_35775_p1() {
    mul_ln1118_854_fu_35775_p1 = tmp_854_fu_35761_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_854_fu_35775_p2() {
    mul_ln1118_854_fu_35775_p2 = (!mul_ln1118_854_fu_35775_p0.read().is_01() || !mul_ln1118_854_fu_35775_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_854_fu_35775_p0.read()) * sc_bigint<5>(mul_ln1118_854_fu_35775_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_855_fu_35805_p0() {
    mul_ln1118_855_fu_35805_p0 =  (sc_lv<12>) (sext_ln1116_55_cast_fu_22881_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_855_fu_35805_p1() {
    mul_ln1118_855_fu_35805_p1 = tmp_855_fu_35791_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_855_fu_35805_p2() {
    mul_ln1118_855_fu_35805_p2 = (!mul_ln1118_855_fu_35805_p0.read().is_01() || !mul_ln1118_855_fu_35805_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_855_fu_35805_p0.read()) * sc_bigint<5>(mul_ln1118_855_fu_35805_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_856_fu_35835_p0() {
    mul_ln1118_856_fu_35835_p0 =  (sc_lv<12>) (sext_ln1116_56_cast_fu_22923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_856_fu_35835_p1() {
    mul_ln1118_856_fu_35835_p1 = tmp_856_fu_35821_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_856_fu_35835_p2() {
    mul_ln1118_856_fu_35835_p2 = (!mul_ln1118_856_fu_35835_p0.read().is_01() || !mul_ln1118_856_fu_35835_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_856_fu_35835_p0.read()) * sc_bigint<5>(mul_ln1118_856_fu_35835_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_857_fu_35865_p0() {
    mul_ln1118_857_fu_35865_p0 =  (sc_lv<12>) (sext_ln1116_57_cast_fu_22965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_857_fu_35865_p1() {
    mul_ln1118_857_fu_35865_p1 = tmp_857_fu_35851_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_857_fu_35865_p2() {
    mul_ln1118_857_fu_35865_p2 = (!mul_ln1118_857_fu_35865_p0.read().is_01() || !mul_ln1118_857_fu_35865_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_857_fu_35865_p0.read()) * sc_bigint<5>(mul_ln1118_857_fu_35865_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_858_fu_35895_p0() {
    mul_ln1118_858_fu_35895_p0 =  (sc_lv<12>) (sext_ln1116_58_cast_fu_23007_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_858_fu_35895_p1() {
    mul_ln1118_858_fu_35895_p1 = tmp_858_fu_35881_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_858_fu_35895_p2() {
    mul_ln1118_858_fu_35895_p2 = (!mul_ln1118_858_fu_35895_p0.read().is_01() || !mul_ln1118_858_fu_35895_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_858_fu_35895_p0.read()) * sc_bigint<5>(mul_ln1118_858_fu_35895_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_859_fu_69468_p0() {
    mul_ln1118_859_fu_69468_p0 =  (sc_lv<12>) (sext_ln1116_59_cast_fu_53363_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_859_fu_69468_p1() {
    mul_ln1118_859_fu_69468_p1 = tmp_859_reg_100852.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_859_fu_69468_p2() {
    mul_ln1118_859_fu_69468_p2 = (!mul_ln1118_859_fu_69468_p0.read().is_01() || !mul_ln1118_859_fu_69468_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_859_fu_69468_p0.read()) * sc_bigint<5>(mul_ln1118_859_fu_69468_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_85_fu_53805_p0() {
    mul_ln1118_85_fu_53805_p0 =  (sc_lv<12>) (sext_ln1116_85_cast_fu_53799_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_85_fu_53805_p1() {
    mul_ln1118_85_fu_53805_p1 = tmp_85_reg_96436.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_85_fu_53805_p2() {
    mul_ln1118_85_fu_53805_p2 = (!mul_ln1118_85_fu_53805_p0.read().is_01() || !mul_ln1118_85_fu_53805_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_85_fu_53805_p0.read()) * sc_bigint<5>(mul_ln1118_85_fu_53805_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_860_fu_69487_p0() {
    mul_ln1118_860_fu_69487_p0 =  (sc_lv<12>) (sext_ln1116_60_cast_fu_53385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_860_fu_69487_p1() {
    mul_ln1118_860_fu_69487_p1 = tmp_860_reg_100857.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_860_fu_69487_p2() {
    mul_ln1118_860_fu_69487_p2 = (!mul_ln1118_860_fu_69487_p0.read().is_01() || !mul_ln1118_860_fu_69487_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_860_fu_69487_p0.read()) * sc_bigint<5>(mul_ln1118_860_fu_69487_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_861_fu_69506_p0() {
    mul_ln1118_861_fu_69506_p0 =  (sc_lv<12>) (sext_ln1116_61_cast_fu_53407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_861_fu_69506_p1() {
    mul_ln1118_861_fu_69506_p1 = tmp_861_reg_100862.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_861_fu_69506_p2() {
    mul_ln1118_861_fu_69506_p2 = (!mul_ln1118_861_fu_69506_p0.read().is_01() || !mul_ln1118_861_fu_69506_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_861_fu_69506_p0.read()) * sc_bigint<5>(mul_ln1118_861_fu_69506_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_862_fu_69525_p0() {
    mul_ln1118_862_fu_69525_p0 =  (sc_lv<12>) (sext_ln1116_62_cast_fu_53429_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_862_fu_69525_p1() {
    mul_ln1118_862_fu_69525_p1 = tmp_862_reg_100867.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_862_fu_69525_p2() {
    mul_ln1118_862_fu_69525_p2 = (!mul_ln1118_862_fu_69525_p0.read().is_01() || !mul_ln1118_862_fu_69525_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_862_fu_69525_p0.read()) * sc_bigint<5>(mul_ln1118_862_fu_69525_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_863_fu_69544_p0() {
    mul_ln1118_863_fu_69544_p0 =  (sc_lv<12>) (sext_ln1116_63_cast_fu_53451_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_863_fu_69544_p1() {
    mul_ln1118_863_fu_69544_p1 = tmp_863_reg_100872.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_863_fu_69544_p2() {
    mul_ln1118_863_fu_69544_p2 = (!mul_ln1118_863_fu_69544_p0.read().is_01() || !mul_ln1118_863_fu_69544_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_863_fu_69544_p0.read()) * sc_bigint<5>(mul_ln1118_863_fu_69544_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_864_fu_69563_p0() {
    mul_ln1118_864_fu_69563_p0 =  (sc_lv<12>) (sext_ln1116_64_cast_fu_53473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_864_fu_69563_p1() {
    mul_ln1118_864_fu_69563_p1 = tmp_864_reg_100877.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_864_fu_69563_p2() {
    mul_ln1118_864_fu_69563_p2 = (!mul_ln1118_864_fu_69563_p0.read().is_01() || !mul_ln1118_864_fu_69563_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_864_fu_69563_p0.read()) * sc_bigint<5>(mul_ln1118_864_fu_69563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_865_fu_69582_p0() {
    mul_ln1118_865_fu_69582_p0 =  (sc_lv<12>) (sext_ln1116_65_cast_fu_53495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_865_fu_69582_p1() {
    mul_ln1118_865_fu_69582_p1 = tmp_865_reg_100882.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_865_fu_69582_p2() {
    mul_ln1118_865_fu_69582_p2 = (!mul_ln1118_865_fu_69582_p0.read().is_01() || !mul_ln1118_865_fu_69582_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_865_fu_69582_p0.read()) * sc_bigint<5>(mul_ln1118_865_fu_69582_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_866_fu_69601_p0() {
    mul_ln1118_866_fu_69601_p0 =  (sc_lv<12>) (sext_ln1116_66_cast_fu_53517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_866_fu_69601_p1() {
    mul_ln1118_866_fu_69601_p1 = tmp_866_reg_100887.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_866_fu_69601_p2() {
    mul_ln1118_866_fu_69601_p2 = (!mul_ln1118_866_fu_69601_p0.read().is_01() || !mul_ln1118_866_fu_69601_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_866_fu_69601_p0.read()) * sc_bigint<5>(mul_ln1118_866_fu_69601_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_867_fu_69620_p0() {
    mul_ln1118_867_fu_69620_p0 =  (sc_lv<12>) (sext_ln1116_67_cast_fu_53539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_867_fu_69620_p1() {
    mul_ln1118_867_fu_69620_p1 = tmp_867_reg_100892.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_867_fu_69620_p2() {
    mul_ln1118_867_fu_69620_p2 = (!mul_ln1118_867_fu_69620_p0.read().is_01() || !mul_ln1118_867_fu_69620_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_867_fu_69620_p0.read()) * sc_bigint<5>(mul_ln1118_867_fu_69620_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_868_fu_69639_p0() {
    mul_ln1118_868_fu_69639_p0 =  (sc_lv<12>) (sext_ln1116_68_cast_fu_53561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_868_fu_69639_p1() {
    mul_ln1118_868_fu_69639_p1 = tmp_868_reg_100897.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_868_fu_69639_p2() {
    mul_ln1118_868_fu_69639_p2 = (!mul_ln1118_868_fu_69639_p0.read().is_01() || !mul_ln1118_868_fu_69639_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_868_fu_69639_p0.read()) * sc_bigint<5>(mul_ln1118_868_fu_69639_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_869_fu_69658_p0() {
    mul_ln1118_869_fu_69658_p0 =  (sc_lv<12>) (sext_ln1116_69_cast_fu_53583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_869_fu_69658_p1() {
    mul_ln1118_869_fu_69658_p1 = tmp_869_reg_100902.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_869_fu_69658_p2() {
    mul_ln1118_869_fu_69658_p2 = (!mul_ln1118_869_fu_69658_p0.read().is_01() || !mul_ln1118_869_fu_69658_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_869_fu_69658_p0.read()) * sc_bigint<5>(mul_ln1118_869_fu_69658_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_86_fu_53827_p0() {
    mul_ln1118_86_fu_53827_p0 =  (sc_lv<12>) (sext_ln1116_86_cast_fu_53821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_86_fu_53827_p1() {
    mul_ln1118_86_fu_53827_p1 = tmp_86_reg_96446.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_86_fu_53827_p2() {
    mul_ln1118_86_fu_53827_p2 = (!mul_ln1118_86_fu_53827_p0.read().is_01() || !mul_ln1118_86_fu_53827_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_86_fu_53827_p0.read()) * sc_bigint<5>(mul_ln1118_86_fu_53827_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_870_fu_69677_p0() {
    mul_ln1118_870_fu_69677_p0 =  (sc_lv<12>) (sext_ln1116_70_cast_fu_53605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_870_fu_69677_p1() {
    mul_ln1118_870_fu_69677_p1 = tmp_870_reg_100907.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_870_fu_69677_p2() {
    mul_ln1118_870_fu_69677_p2 = (!mul_ln1118_870_fu_69677_p0.read().is_01() || !mul_ln1118_870_fu_69677_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_870_fu_69677_p0.read()) * sc_bigint<5>(mul_ln1118_870_fu_69677_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_871_fu_69696_p0() {
    mul_ln1118_871_fu_69696_p0 =  (sc_lv<12>) (sext_ln1116_71_cast_fu_53627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_871_fu_69696_p1() {
    mul_ln1118_871_fu_69696_p1 = tmp_871_reg_100912.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_871_fu_69696_p2() {
    mul_ln1118_871_fu_69696_p2 = (!mul_ln1118_871_fu_69696_p0.read().is_01() || !mul_ln1118_871_fu_69696_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_871_fu_69696_p0.read()) * sc_bigint<5>(mul_ln1118_871_fu_69696_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_872_fu_69715_p0() {
    mul_ln1118_872_fu_69715_p0 =  (sc_lv<12>) (sext_ln1116_72_cast_fu_53649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_872_fu_69715_p1() {
    mul_ln1118_872_fu_69715_p1 = tmp_872_reg_100917.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_872_fu_69715_p2() {
    mul_ln1118_872_fu_69715_p2 = (!mul_ln1118_872_fu_69715_p0.read().is_01() || !mul_ln1118_872_fu_69715_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_872_fu_69715_p0.read()) * sc_bigint<5>(mul_ln1118_872_fu_69715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_873_fu_69734_p0() {
    mul_ln1118_873_fu_69734_p0 =  (sc_lv<12>) (sext_ln1116_73_cast_fu_53671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_873_fu_69734_p1() {
    mul_ln1118_873_fu_69734_p1 = tmp_873_reg_100922.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_873_fu_69734_p2() {
    mul_ln1118_873_fu_69734_p2 = (!mul_ln1118_873_fu_69734_p0.read().is_01() || !mul_ln1118_873_fu_69734_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_873_fu_69734_p0.read()) * sc_bigint<5>(mul_ln1118_873_fu_69734_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_874_fu_69753_p0() {
    mul_ln1118_874_fu_69753_p0 =  (sc_lv<12>) (sext_ln1116_74_cast_fu_53693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_874_fu_69753_p1() {
    mul_ln1118_874_fu_69753_p1 = tmp_874_reg_100927.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_874_fu_69753_p2() {
    mul_ln1118_874_fu_69753_p2 = (!mul_ln1118_874_fu_69753_p0.read().is_01() || !mul_ln1118_874_fu_69753_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_874_fu_69753_p0.read()) * sc_bigint<5>(mul_ln1118_874_fu_69753_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_875_fu_69772_p0() {
    mul_ln1118_875_fu_69772_p0 =  (sc_lv<12>) (sext_ln1116_75_cast_fu_53715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_875_fu_69772_p1() {
    mul_ln1118_875_fu_69772_p1 = tmp_875_reg_100932.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_875_fu_69772_p2() {
    mul_ln1118_875_fu_69772_p2 = (!mul_ln1118_875_fu_69772_p0.read().is_01() || !mul_ln1118_875_fu_69772_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_875_fu_69772_p0.read()) * sc_bigint<5>(mul_ln1118_875_fu_69772_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_876_fu_69791_p0() {
    mul_ln1118_876_fu_69791_p0 =  (sc_lv<12>) (sext_ln1116_76_cast_fu_53737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_876_fu_69791_p1() {
    mul_ln1118_876_fu_69791_p1 = tmp_876_reg_100937.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_876_fu_69791_p2() {
    mul_ln1118_876_fu_69791_p2 = (!mul_ln1118_876_fu_69791_p0.read().is_01() || !mul_ln1118_876_fu_69791_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_876_fu_69791_p0.read()) * sc_bigint<5>(mul_ln1118_876_fu_69791_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_877_fu_69810_p0() {
    mul_ln1118_877_fu_69810_p0 =  (sc_lv<12>) (sext_ln1116_77_cast_reg_96378.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_877_fu_69810_p1() {
    mul_ln1118_877_fu_69810_p1 = tmp_877_reg_100942.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_877_fu_69810_p2() {
    mul_ln1118_877_fu_69810_p2 = (!mul_ln1118_877_fu_69810_p0.read().is_01() || !mul_ln1118_877_fu_69810_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_877_fu_69810_p0.read()) * sc_bigint<5>(mul_ln1118_877_fu_69810_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_878_fu_36115_p0() {
    mul_ln1118_878_fu_36115_p0 =  (sc_lv<12>) (sext_ln1116_78_cast_fu_23395_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_878_fu_36115_p1() {
    mul_ln1118_878_fu_36115_p1 = tmp_878_fu_36101_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_878_fu_36115_p2() {
    mul_ln1118_878_fu_36115_p2 = (!mul_ln1118_878_fu_36115_p0.read().is_01() || !mul_ln1118_878_fu_36115_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_878_fu_36115_p0.read()) * sc_bigint<5>(mul_ln1118_878_fu_36115_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_879_fu_36145_p0() {
    mul_ln1118_879_fu_36145_p0 =  (sc_lv<12>) (sext_ln1116_79_cast_fu_23437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_879_fu_36145_p1() {
    mul_ln1118_879_fu_36145_p1 = tmp_879_fu_36131_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_879_fu_36145_p2() {
    mul_ln1118_879_fu_36145_p2 = (!mul_ln1118_879_fu_36145_p0.read().is_01() || !mul_ln1118_879_fu_36145_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_879_fu_36145_p0.read()) * sc_bigint<5>(mul_ln1118_879_fu_36145_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_87_fu_53849_p0() {
    mul_ln1118_87_fu_53849_p0 =  (sc_lv<12>) (sext_ln1116_87_cast_fu_53843_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_87_fu_53849_p1() {
    mul_ln1118_87_fu_53849_p1 = tmp_87_reg_96456.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_87_fu_53849_p2() {
    mul_ln1118_87_fu_53849_p2 = (!mul_ln1118_87_fu_53849_p0.read().is_01() || !mul_ln1118_87_fu_53849_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_87_fu_53849_p0.read()) * sc_bigint<5>(mul_ln1118_87_fu_53849_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_880_fu_36175_p0() {
    mul_ln1118_880_fu_36175_p0 =  (sc_lv<12>) (sext_ln1116_80_cast_fu_23479_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_880_fu_36175_p1() {
    mul_ln1118_880_fu_36175_p1 = tmp_880_fu_36161_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_880_fu_36175_p2() {
    mul_ln1118_880_fu_36175_p2 = (!mul_ln1118_880_fu_36175_p0.read().is_01() || !mul_ln1118_880_fu_36175_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_880_fu_36175_p0.read()) * sc_bigint<5>(mul_ln1118_880_fu_36175_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_881_fu_36205_p0() {
    mul_ln1118_881_fu_36205_p0 =  (sc_lv<12>) (sext_ln1116_81_cast_fu_23521_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_881_fu_36205_p1() {
    mul_ln1118_881_fu_36205_p1 = tmp_881_fu_36191_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_881_fu_36205_p2() {
    mul_ln1118_881_fu_36205_p2 = (!mul_ln1118_881_fu_36205_p0.read().is_01() || !mul_ln1118_881_fu_36205_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_881_fu_36205_p0.read()) * sc_bigint<5>(mul_ln1118_881_fu_36205_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_882_fu_36235_p0() {
    mul_ln1118_882_fu_36235_p0 =  (sc_lv<12>) (sext_ln1116_82_cast_fu_23563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_882_fu_36235_p1() {
    mul_ln1118_882_fu_36235_p1 = tmp_882_fu_36221_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_882_fu_36235_p2() {
    mul_ln1118_882_fu_36235_p2 = (!mul_ln1118_882_fu_36235_p0.read().is_01() || !mul_ln1118_882_fu_36235_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_882_fu_36235_p0.read()) * sc_bigint<5>(mul_ln1118_882_fu_36235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_883_fu_36265_p0() {
    mul_ln1118_883_fu_36265_p0 =  (sc_lv<12>) (sext_ln1116_83_cast_fu_23605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_883_fu_36265_p1() {
    mul_ln1118_883_fu_36265_p1 = tmp_883_fu_36251_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_883_fu_36265_p2() {
    mul_ln1118_883_fu_36265_p2 = (!mul_ln1118_883_fu_36265_p0.read().is_01() || !mul_ln1118_883_fu_36265_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_883_fu_36265_p0.read()) * sc_bigint<5>(mul_ln1118_883_fu_36265_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_884_fu_69828_p0() {
    mul_ln1118_884_fu_69828_p0 =  (sc_lv<12>) (sext_ln1116_84_cast_fu_53777_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_884_fu_69828_p1() {
    mul_ln1118_884_fu_69828_p1 = tmp_884_reg_100977.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_884_fu_69828_p2() {
    mul_ln1118_884_fu_69828_p2 = (!mul_ln1118_884_fu_69828_p0.read().is_01() || !mul_ln1118_884_fu_69828_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_884_fu_69828_p0.read()) * sc_bigint<5>(mul_ln1118_884_fu_69828_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_885_fu_69847_p0() {
    mul_ln1118_885_fu_69847_p0 =  (sc_lv<12>) (sext_ln1116_85_cast_fu_53799_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_885_fu_69847_p1() {
    mul_ln1118_885_fu_69847_p1 = tmp_885_reg_100982.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_885_fu_69847_p2() {
    mul_ln1118_885_fu_69847_p2 = (!mul_ln1118_885_fu_69847_p0.read().is_01() || !mul_ln1118_885_fu_69847_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_885_fu_69847_p0.read()) * sc_bigint<5>(mul_ln1118_885_fu_69847_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_886_fu_69866_p0() {
    mul_ln1118_886_fu_69866_p0 =  (sc_lv<12>) (sext_ln1116_86_cast_fu_53821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_886_fu_69866_p1() {
    mul_ln1118_886_fu_69866_p1 = tmp_886_reg_100987.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_886_fu_69866_p2() {
    mul_ln1118_886_fu_69866_p2 = (!mul_ln1118_886_fu_69866_p0.read().is_01() || !mul_ln1118_886_fu_69866_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_886_fu_69866_p0.read()) * sc_bigint<5>(mul_ln1118_886_fu_69866_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_887_fu_69885_p0() {
    mul_ln1118_887_fu_69885_p0 =  (sc_lv<12>) (sext_ln1116_87_cast_fu_53843_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_887_fu_69885_p1() {
    mul_ln1118_887_fu_69885_p1 = tmp_887_reg_100992.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_887_fu_69885_p2() {
    mul_ln1118_887_fu_69885_p2 = (!mul_ln1118_887_fu_69885_p0.read().is_01() || !mul_ln1118_887_fu_69885_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_887_fu_69885_p0.read()) * sc_bigint<5>(mul_ln1118_887_fu_69885_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_888_fu_69904_p0() {
    mul_ln1118_888_fu_69904_p0 =  (sc_lv<12>) (sext_ln1116_88_cast_fu_53865_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_888_fu_69904_p1() {
    mul_ln1118_888_fu_69904_p1 = tmp_888_reg_100997.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_888_fu_69904_p2() {
    mul_ln1118_888_fu_69904_p2 = (!mul_ln1118_888_fu_69904_p0.read().is_01() || !mul_ln1118_888_fu_69904_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_888_fu_69904_p0.read()) * sc_bigint<5>(mul_ln1118_888_fu_69904_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_889_fu_69923_p0() {
    mul_ln1118_889_fu_69923_p0 =  (sc_lv<12>) (sext_ln1116_89_cast_fu_53887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_889_fu_69923_p1() {
    mul_ln1118_889_fu_69923_p1 = tmp_889_reg_101002.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_889_fu_69923_p2() {
    mul_ln1118_889_fu_69923_p2 = (!mul_ln1118_889_fu_69923_p0.read().is_01() || !mul_ln1118_889_fu_69923_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_889_fu_69923_p0.read()) * sc_bigint<5>(mul_ln1118_889_fu_69923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_88_fu_53871_p0() {
    mul_ln1118_88_fu_53871_p0 =  (sc_lv<12>) (sext_ln1116_88_cast_fu_53865_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_88_fu_53871_p1() {
    mul_ln1118_88_fu_53871_p1 = tmp_88_reg_96466.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_88_fu_53871_p2() {
    mul_ln1118_88_fu_53871_p2 = (!mul_ln1118_88_fu_53871_p0.read().is_01() || !mul_ln1118_88_fu_53871_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_88_fu_53871_p0.read()) * sc_bigint<5>(mul_ln1118_88_fu_53871_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_890_fu_69942_p0() {
    mul_ln1118_890_fu_69942_p0 =  (sc_lv<12>) (sext_ln1116_90_cast_fu_53909_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_890_fu_69942_p1() {
    mul_ln1118_890_fu_69942_p1 = tmp_890_reg_101007.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_890_fu_69942_p2() {
    mul_ln1118_890_fu_69942_p2 = (!mul_ln1118_890_fu_69942_p0.read().is_01() || !mul_ln1118_890_fu_69942_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_890_fu_69942_p0.read()) * sc_bigint<5>(mul_ln1118_890_fu_69942_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_891_fu_69961_p0() {
    mul_ln1118_891_fu_69961_p0 =  (sc_lv<12>) (sext_ln1116_91_cast_fu_53931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_891_fu_69961_p1() {
    mul_ln1118_891_fu_69961_p1 = tmp_891_reg_101012.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_891_fu_69961_p2() {
    mul_ln1118_891_fu_69961_p2 = (!mul_ln1118_891_fu_69961_p0.read().is_01() || !mul_ln1118_891_fu_69961_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_891_fu_69961_p0.read()) * sc_bigint<5>(mul_ln1118_891_fu_69961_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_892_fu_69980_p0() {
    mul_ln1118_892_fu_69980_p0 =  (sc_lv<12>) (sext_ln1116_92_cast_fu_53953_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_892_fu_69980_p1() {
    mul_ln1118_892_fu_69980_p1 = tmp_892_reg_101017.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_892_fu_69980_p2() {
    mul_ln1118_892_fu_69980_p2 = (!mul_ln1118_892_fu_69980_p0.read().is_01() || !mul_ln1118_892_fu_69980_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_892_fu_69980_p0.read()) * sc_bigint<5>(mul_ln1118_892_fu_69980_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_893_fu_69999_p0() {
    mul_ln1118_893_fu_69999_p0 =  (sc_lv<12>) (sext_ln1116_93_cast_fu_53975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_893_fu_69999_p1() {
    mul_ln1118_893_fu_69999_p1 = tmp_893_reg_101022.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_893_fu_69999_p2() {
    mul_ln1118_893_fu_69999_p2 = (!mul_ln1118_893_fu_69999_p0.read().is_01() || !mul_ln1118_893_fu_69999_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_893_fu_69999_p0.read()) * sc_bigint<5>(mul_ln1118_893_fu_69999_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_894_fu_70018_p0() {
    mul_ln1118_894_fu_70018_p0 =  (sc_lv<12>) (sext_ln1116_94_cast_fu_53997_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_894_fu_70018_p1() {
    mul_ln1118_894_fu_70018_p1 = tmp_894_reg_101027.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_894_fu_70018_p2() {
    mul_ln1118_894_fu_70018_p2 = (!mul_ln1118_894_fu_70018_p0.read().is_01() || !mul_ln1118_894_fu_70018_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_894_fu_70018_p0.read()) * sc_bigint<5>(mul_ln1118_894_fu_70018_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_895_fu_70037_p0() {
    mul_ln1118_895_fu_70037_p0 =  (sc_lv<12>) (sext_ln1116_95_cast_fu_54019_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_895_fu_70037_p1() {
    mul_ln1118_895_fu_70037_p1 = tmp_895_reg_101032.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_895_fu_70037_p2() {
    mul_ln1118_895_fu_70037_p2 = (!mul_ln1118_895_fu_70037_p0.read().is_01() || !mul_ln1118_895_fu_70037_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_895_fu_70037_p0.read()) * sc_bigint<5>(mul_ln1118_895_fu_70037_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_896_fu_70056_p0() {
    mul_ln1118_896_fu_70056_p0 =  (sc_lv<12>) (sext_ln1116_96_cast_fu_54041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_896_fu_70056_p1() {
    mul_ln1118_896_fu_70056_p1 = tmp_896_reg_101037.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_896_fu_70056_p2() {
    mul_ln1118_896_fu_70056_p2 = (!mul_ln1118_896_fu_70056_p0.read().is_01() || !mul_ln1118_896_fu_70056_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_896_fu_70056_p0.read()) * sc_bigint<5>(mul_ln1118_896_fu_70056_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_897_fu_70075_p0() {
    mul_ln1118_897_fu_70075_p0 =  (sc_lv<12>) (sext_ln1116_97_cast_fu_54063_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_897_fu_70075_p1() {
    mul_ln1118_897_fu_70075_p1 = tmp_897_reg_101042.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_897_fu_70075_p2() {
    mul_ln1118_897_fu_70075_p2 = (!mul_ln1118_897_fu_70075_p0.read().is_01() || !mul_ln1118_897_fu_70075_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_897_fu_70075_p0.read()) * sc_bigint<5>(mul_ln1118_897_fu_70075_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_898_fu_70094_p0() {
    mul_ln1118_898_fu_70094_p0 =  (sc_lv<12>) (sext_ln1116_98_cast_fu_54085_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_898_fu_70094_p1() {
    mul_ln1118_898_fu_70094_p1 = tmp_898_reg_101047.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_898_fu_70094_p2() {
    mul_ln1118_898_fu_70094_p2 = (!mul_ln1118_898_fu_70094_p0.read().is_01() || !mul_ln1118_898_fu_70094_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_898_fu_70094_p0.read()) * sc_bigint<5>(mul_ln1118_898_fu_70094_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_899_fu_70113_p0() {
    mul_ln1118_899_fu_70113_p0 =  (sc_lv<12>) (sext_ln1116_99_cast_fu_54107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_899_fu_70113_p1() {
    mul_ln1118_899_fu_70113_p1 = tmp_899_reg_101052.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_899_fu_70113_p2() {
    mul_ln1118_899_fu_70113_p2 = (!mul_ln1118_899_fu_70113_p0.read().is_01() || !mul_ln1118_899_fu_70113_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_899_fu_70113_p0.read()) * sc_bigint<5>(mul_ln1118_899_fu_70113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_89_fu_53893_p0() {
    mul_ln1118_89_fu_53893_p0 =  (sc_lv<12>) (sext_ln1116_89_cast_fu_53887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_89_fu_53893_p1() {
    mul_ln1118_89_fu_53893_p1 = tmp_89_reg_96476.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_89_fu_53893_p2() {
    mul_ln1118_89_fu_53893_p2 = (!mul_ln1118_89_fu_53893_p0.read().is_01() || !mul_ln1118_89_fu_53893_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_89_fu_53893_p0.read()) * sc_bigint<5>(mul_ln1118_89_fu_53893_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_900_fu_70132_p0() {
    mul_ln1118_900_fu_70132_p0 =  (sc_lv<12>) (sext_ln1116_100_cast_fu_54129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_900_fu_70132_p1() {
    mul_ln1118_900_fu_70132_p1 = tmp_900_reg_101057.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_900_fu_70132_p2() {
    mul_ln1118_900_fu_70132_p2 = (!mul_ln1118_900_fu_70132_p0.read().is_01() || !mul_ln1118_900_fu_70132_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_900_fu_70132_p0.read()) * sc_bigint<5>(mul_ln1118_900_fu_70132_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_901_fu_70151_p0() {
    mul_ln1118_901_fu_70151_p0 =  (sc_lv<12>) (sext_ln1116_101_cast_fu_54151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_901_fu_70151_p1() {
    mul_ln1118_901_fu_70151_p1 = tmp_901_reg_101062.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_901_fu_70151_p2() {
    mul_ln1118_901_fu_70151_p2 = (!mul_ln1118_901_fu_70151_p0.read().is_01() || !mul_ln1118_901_fu_70151_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_901_fu_70151_p0.read()) * sc_bigint<5>(mul_ln1118_901_fu_70151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_902_fu_70170_p0() {
    mul_ln1118_902_fu_70170_p0 =  (sc_lv<12>) (sext_ln1116_102_cast_reg_96606.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_902_fu_70170_p1() {
    mul_ln1118_902_fu_70170_p1 = tmp_902_reg_101067.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_902_fu_70170_p2() {
    mul_ln1118_902_fu_70170_p2 = (!mul_ln1118_902_fu_70170_p0.read().is_01() || !mul_ln1118_902_fu_70170_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_902_fu_70170_p0.read()) * sc_bigint<5>(mul_ln1118_902_fu_70170_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_903_fu_36485_p0() {
    mul_ln1118_903_fu_36485_p0 =  (sc_lv<12>) (sext_ln1116_103_cast_fu_23993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_903_fu_36485_p1() {
    mul_ln1118_903_fu_36485_p1 = tmp_903_fu_36471_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_903_fu_36485_p2() {
    mul_ln1118_903_fu_36485_p2 = (!mul_ln1118_903_fu_36485_p0.read().is_01() || !mul_ln1118_903_fu_36485_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_903_fu_36485_p0.read()) * sc_bigint<5>(mul_ln1118_903_fu_36485_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_904_fu_36515_p0() {
    mul_ln1118_904_fu_36515_p0 =  (sc_lv<12>) (sext_ln1116_104_cast_fu_24035_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_904_fu_36515_p1() {
    mul_ln1118_904_fu_36515_p1 = tmp_904_fu_36501_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_904_fu_36515_p2() {
    mul_ln1118_904_fu_36515_p2 = (!mul_ln1118_904_fu_36515_p0.read().is_01() || !mul_ln1118_904_fu_36515_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_904_fu_36515_p0.read()) * sc_bigint<5>(mul_ln1118_904_fu_36515_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_905_fu_36545_p0() {
    mul_ln1118_905_fu_36545_p0 =  (sc_lv<12>) (sext_ln1116_105_cast_fu_24077_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_905_fu_36545_p1() {
    mul_ln1118_905_fu_36545_p1 = tmp_905_fu_36531_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_905_fu_36545_p2() {
    mul_ln1118_905_fu_36545_p2 = (!mul_ln1118_905_fu_36545_p0.read().is_01() || !mul_ln1118_905_fu_36545_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_905_fu_36545_p0.read()) * sc_bigint<5>(mul_ln1118_905_fu_36545_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_906_fu_36575_p0() {
    mul_ln1118_906_fu_36575_p0 =  (sc_lv<12>) (sext_ln1116_106_cast_fu_24119_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_906_fu_36575_p1() {
    mul_ln1118_906_fu_36575_p1 = tmp_906_fu_36561_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_906_fu_36575_p2() {
    mul_ln1118_906_fu_36575_p2 = (!mul_ln1118_906_fu_36575_p0.read().is_01() || !mul_ln1118_906_fu_36575_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_906_fu_36575_p0.read()) * sc_bigint<5>(mul_ln1118_906_fu_36575_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_907_fu_36605_p0() {
    mul_ln1118_907_fu_36605_p0 =  (sc_lv<12>) (sext_ln1116_107_cast_fu_24161_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_907_fu_36605_p1() {
    mul_ln1118_907_fu_36605_p1 = tmp_907_fu_36591_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_907_fu_36605_p2() {
    mul_ln1118_907_fu_36605_p2 = (!mul_ln1118_907_fu_36605_p0.read().is_01() || !mul_ln1118_907_fu_36605_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_907_fu_36605_p0.read()) * sc_bigint<5>(mul_ln1118_907_fu_36605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_908_fu_36635_p0() {
    mul_ln1118_908_fu_36635_p0 =  (sc_lv<12>) (sext_ln1116_108_cast_fu_24203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_908_fu_36635_p1() {
    mul_ln1118_908_fu_36635_p1 = tmp_908_fu_36621_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_908_fu_36635_p2() {
    mul_ln1118_908_fu_36635_p2 = (!mul_ln1118_908_fu_36635_p0.read().is_01() || !mul_ln1118_908_fu_36635_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_908_fu_36635_p0.read()) * sc_bigint<5>(mul_ln1118_908_fu_36635_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_909_fu_70188_p0() {
    mul_ln1118_909_fu_70188_p0 =  (sc_lv<12>) (sext_ln1116_109_cast_fu_54191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_909_fu_70188_p1() {
    mul_ln1118_909_fu_70188_p1 = tmp_909_reg_101102.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_909_fu_70188_p2() {
    mul_ln1118_909_fu_70188_p2 = (!mul_ln1118_909_fu_70188_p0.read().is_01() || !mul_ln1118_909_fu_70188_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_909_fu_70188_p0.read()) * sc_bigint<5>(mul_ln1118_909_fu_70188_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_90_fu_53915_p0() {
    mul_ln1118_90_fu_53915_p0 =  (sc_lv<12>) (sext_ln1116_90_cast_fu_53909_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_90_fu_53915_p1() {
    mul_ln1118_90_fu_53915_p1 = tmp_90_reg_96486.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_90_fu_53915_p2() {
    mul_ln1118_90_fu_53915_p2 = (!mul_ln1118_90_fu_53915_p0.read().is_01() || !mul_ln1118_90_fu_53915_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_90_fu_53915_p0.read()) * sc_bigint<5>(mul_ln1118_90_fu_53915_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_910_fu_70207_p0() {
    mul_ln1118_910_fu_70207_p0 =  (sc_lv<12>) (sext_ln1116_110_cast_fu_54213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_910_fu_70207_p1() {
    mul_ln1118_910_fu_70207_p1 = tmp_910_reg_101107.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_910_fu_70207_p2() {
    mul_ln1118_910_fu_70207_p2 = (!mul_ln1118_910_fu_70207_p0.read().is_01() || !mul_ln1118_910_fu_70207_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_910_fu_70207_p0.read()) * sc_bigint<5>(mul_ln1118_910_fu_70207_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_911_fu_70226_p0() {
    mul_ln1118_911_fu_70226_p0 =  (sc_lv<12>) (sext_ln1116_111_cast_fu_54235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_911_fu_70226_p1() {
    mul_ln1118_911_fu_70226_p1 = tmp_911_reg_101112.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_911_fu_70226_p2() {
    mul_ln1118_911_fu_70226_p2 = (!mul_ln1118_911_fu_70226_p0.read().is_01() || !mul_ln1118_911_fu_70226_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_911_fu_70226_p0.read()) * sc_bigint<5>(mul_ln1118_911_fu_70226_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_912_fu_70245_p0() {
    mul_ln1118_912_fu_70245_p0 =  (sc_lv<12>) (sext_ln1116_112_cast_fu_54257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_912_fu_70245_p1() {
    mul_ln1118_912_fu_70245_p1 = tmp_912_reg_101117.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_912_fu_70245_p2() {
    mul_ln1118_912_fu_70245_p2 = (!mul_ln1118_912_fu_70245_p0.read().is_01() || !mul_ln1118_912_fu_70245_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_912_fu_70245_p0.read()) * sc_bigint<5>(mul_ln1118_912_fu_70245_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_913_fu_70264_p0() {
    mul_ln1118_913_fu_70264_p0 =  (sc_lv<12>) (sext_ln1116_113_cast_fu_54279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_913_fu_70264_p1() {
    mul_ln1118_913_fu_70264_p1 = tmp_913_reg_101122.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_913_fu_70264_p2() {
    mul_ln1118_913_fu_70264_p2 = (!mul_ln1118_913_fu_70264_p0.read().is_01() || !mul_ln1118_913_fu_70264_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_913_fu_70264_p0.read()) * sc_bigint<5>(mul_ln1118_913_fu_70264_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_914_fu_70283_p0() {
    mul_ln1118_914_fu_70283_p0 =  (sc_lv<12>) (sext_ln1116_114_cast_fu_54301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_914_fu_70283_p1() {
    mul_ln1118_914_fu_70283_p1 = tmp_914_reg_101127.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_914_fu_70283_p2() {
    mul_ln1118_914_fu_70283_p2 = (!mul_ln1118_914_fu_70283_p0.read().is_01() || !mul_ln1118_914_fu_70283_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_914_fu_70283_p0.read()) * sc_bigint<5>(mul_ln1118_914_fu_70283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_915_fu_70302_p0() {
    mul_ln1118_915_fu_70302_p0 =  (sc_lv<12>) (sext_ln1116_115_cast_fu_54323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_915_fu_70302_p1() {
    mul_ln1118_915_fu_70302_p1 = tmp_915_reg_101132.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_915_fu_70302_p2() {
    mul_ln1118_915_fu_70302_p2 = (!mul_ln1118_915_fu_70302_p0.read().is_01() || !mul_ln1118_915_fu_70302_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_915_fu_70302_p0.read()) * sc_bigint<5>(mul_ln1118_915_fu_70302_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_916_fu_70321_p0() {
    mul_ln1118_916_fu_70321_p0 =  (sc_lv<12>) (sext_ln1116_116_cast_fu_54345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_916_fu_70321_p1() {
    mul_ln1118_916_fu_70321_p1 = tmp_916_reg_101137.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_916_fu_70321_p2() {
    mul_ln1118_916_fu_70321_p2 = (!mul_ln1118_916_fu_70321_p0.read().is_01() || !mul_ln1118_916_fu_70321_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_916_fu_70321_p0.read()) * sc_bigint<5>(mul_ln1118_916_fu_70321_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_917_fu_70340_p0() {
    mul_ln1118_917_fu_70340_p0 =  (sc_lv<12>) (sext_ln1116_117_cast_fu_54367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_917_fu_70340_p1() {
    mul_ln1118_917_fu_70340_p1 = tmp_917_reg_101142.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_917_fu_70340_p2() {
    mul_ln1118_917_fu_70340_p2 = (!mul_ln1118_917_fu_70340_p0.read().is_01() || !mul_ln1118_917_fu_70340_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_917_fu_70340_p0.read()) * sc_bigint<5>(mul_ln1118_917_fu_70340_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_918_fu_70359_p0() {
    mul_ln1118_918_fu_70359_p0 =  (sc_lv<12>) (sext_ln1116_118_cast_fu_54389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_918_fu_70359_p1() {
    mul_ln1118_918_fu_70359_p1 = tmp_918_reg_101147.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_918_fu_70359_p2() {
    mul_ln1118_918_fu_70359_p2 = (!mul_ln1118_918_fu_70359_p0.read().is_01() || !mul_ln1118_918_fu_70359_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_918_fu_70359_p0.read()) * sc_bigint<5>(mul_ln1118_918_fu_70359_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_919_fu_70378_p0() {
    mul_ln1118_919_fu_70378_p0 =  (sc_lv<12>) (sext_ln1116_119_cast_fu_54411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_919_fu_70378_p1() {
    mul_ln1118_919_fu_70378_p1 = tmp_919_reg_101152.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_919_fu_70378_p2() {
    mul_ln1118_919_fu_70378_p2 = (!mul_ln1118_919_fu_70378_p0.read().is_01() || !mul_ln1118_919_fu_70378_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_919_fu_70378_p0.read()) * sc_bigint<5>(mul_ln1118_919_fu_70378_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_91_fu_53937_p0() {
    mul_ln1118_91_fu_53937_p0 =  (sc_lv<12>) (sext_ln1116_91_cast_fu_53931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_91_fu_53937_p1() {
    mul_ln1118_91_fu_53937_p1 = tmp_91_reg_96496.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_91_fu_53937_p2() {
    mul_ln1118_91_fu_53937_p2 = (!mul_ln1118_91_fu_53937_p0.read().is_01() || !mul_ln1118_91_fu_53937_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_91_fu_53937_p0.read()) * sc_bigint<5>(mul_ln1118_91_fu_53937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_920_fu_70397_p0() {
    mul_ln1118_920_fu_70397_p0 =  (sc_lv<12>) (sext_ln1116_120_cast_fu_54433_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_920_fu_70397_p1() {
    mul_ln1118_920_fu_70397_p1 = tmp_920_reg_101157.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_920_fu_70397_p2() {
    mul_ln1118_920_fu_70397_p2 = (!mul_ln1118_920_fu_70397_p0.read().is_01() || !mul_ln1118_920_fu_70397_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_920_fu_70397_p0.read()) * sc_bigint<5>(mul_ln1118_920_fu_70397_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_921_fu_70416_p0() {
    mul_ln1118_921_fu_70416_p0 =  (sc_lv<12>) (sext_ln1116_121_cast_fu_54455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_921_fu_70416_p1() {
    mul_ln1118_921_fu_70416_p1 = tmp_921_reg_101162.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_921_fu_70416_p2() {
    mul_ln1118_921_fu_70416_p2 = (!mul_ln1118_921_fu_70416_p0.read().is_01() || !mul_ln1118_921_fu_70416_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_921_fu_70416_p0.read()) * sc_bigint<5>(mul_ln1118_921_fu_70416_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_922_fu_70435_p0() {
    mul_ln1118_922_fu_70435_p0 =  (sc_lv<12>) (sext_ln1116_122_cast_fu_54477_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_922_fu_70435_p1() {
    mul_ln1118_922_fu_70435_p1 = tmp_922_reg_101167.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_922_fu_70435_p2() {
    mul_ln1118_922_fu_70435_p2 = (!mul_ln1118_922_fu_70435_p0.read().is_01() || !mul_ln1118_922_fu_70435_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_922_fu_70435_p0.read()) * sc_bigint<5>(mul_ln1118_922_fu_70435_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_923_fu_70454_p0() {
    mul_ln1118_923_fu_70454_p0 =  (sc_lv<12>) (sext_ln1116_123_cast_fu_54499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_923_fu_70454_p1() {
    mul_ln1118_923_fu_70454_p1 = tmp_923_reg_101172.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_923_fu_70454_p2() {
    mul_ln1118_923_fu_70454_p2 = (!mul_ln1118_923_fu_70454_p0.read().is_01() || !mul_ln1118_923_fu_70454_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_923_fu_70454_p0.read()) * sc_bigint<5>(mul_ln1118_923_fu_70454_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_924_fu_70473_p0() {
    mul_ln1118_924_fu_70473_p0 =  (sc_lv<12>) (sext_ln1116_124_cast_fu_54521_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_924_fu_70473_p1() {
    mul_ln1118_924_fu_70473_p1 = tmp_924_reg_101177.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_924_fu_70473_p2() {
    mul_ln1118_924_fu_70473_p2 = (!mul_ln1118_924_fu_70473_p0.read().is_01() || !mul_ln1118_924_fu_70473_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_924_fu_70473_p0.read()) * sc_bigint<5>(mul_ln1118_924_fu_70473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_925_fu_70492_p0() {
    mul_ln1118_925_fu_70492_p0 =  (sc_lv<12>) (sext_ln1116_125_cast_fu_54543_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_925_fu_70492_p1() {
    mul_ln1118_925_fu_70492_p1 = tmp_925_reg_101182.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_925_fu_70492_p2() {
    mul_ln1118_925_fu_70492_p2 = (!mul_ln1118_925_fu_70492_p0.read().is_01() || !mul_ln1118_925_fu_70492_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_925_fu_70492_p0.read()) * sc_bigint<5>(mul_ln1118_925_fu_70492_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_926_fu_70511_p0() {
    mul_ln1118_926_fu_70511_p0 =  (sc_lv<12>) (sext_ln1116_126_cast_fu_54565_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_926_fu_70511_p1() {
    mul_ln1118_926_fu_70511_p1 = tmp_926_reg_101187.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_926_fu_70511_p2() {
    mul_ln1118_926_fu_70511_p2 = (!mul_ln1118_926_fu_70511_p0.read().is_01() || !mul_ln1118_926_fu_70511_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_926_fu_70511_p0.read()) * sc_bigint<5>(mul_ln1118_926_fu_70511_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_927_fu_70530_p0() {
    mul_ln1118_927_fu_70530_p0 =  (sc_lv<12>) (sext_ln1116_127_cast_fu_54587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_927_fu_70530_p1() {
    mul_ln1118_927_fu_70530_p1 = tmp_927_reg_101192.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_927_fu_70530_p2() {
    mul_ln1118_927_fu_70530_p2 = (!mul_ln1118_927_fu_70530_p0.read().is_01() || !mul_ln1118_927_fu_70530_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_927_fu_70530_p0.read()) * sc_bigint<5>(mul_ln1118_927_fu_70530_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_928_fu_70549_p0() {
    mul_ln1118_928_fu_70549_p0 =  (sc_lv<12>) (sext_ln1116_128_cast_fu_54609_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_928_fu_70549_p1() {
    mul_ln1118_928_fu_70549_p1 = tmp_928_reg_101197.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_928_fu_70549_p2() {
    mul_ln1118_928_fu_70549_p2 = (!mul_ln1118_928_fu_70549_p0.read().is_01() || !mul_ln1118_928_fu_70549_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_928_fu_70549_p0.read()) * sc_bigint<5>(mul_ln1118_928_fu_70549_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_929_fu_70568_p0() {
    mul_ln1118_929_fu_70568_p0 =  (sc_lv<12>) (sext_ln1116_129_cast_fu_54631_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_929_fu_70568_p1() {
    mul_ln1118_929_fu_70568_p1 = tmp_929_reg_101202.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_929_fu_70568_p2() {
    mul_ln1118_929_fu_70568_p2 = (!mul_ln1118_929_fu_70568_p0.read().is_01() || !mul_ln1118_929_fu_70568_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_929_fu_70568_p0.read()) * sc_bigint<5>(mul_ln1118_929_fu_70568_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_92_fu_53959_p0() {
    mul_ln1118_92_fu_53959_p0 =  (sc_lv<12>) (sext_ln1116_92_cast_fu_53953_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_92_fu_53959_p1() {
    mul_ln1118_92_fu_53959_p1 = tmp_92_reg_96506.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_92_fu_53959_p2() {
    mul_ln1118_92_fu_53959_p2 = (!mul_ln1118_92_fu_53959_p0.read().is_01() || !mul_ln1118_92_fu_53959_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_92_fu_53959_p0.read()) * sc_bigint<5>(mul_ln1118_92_fu_53959_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_930_fu_70587_p0() {
    mul_ln1118_930_fu_70587_p0 =  (sc_lv<12>) (sext_ln1116_130_cast_fu_54653_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_930_fu_70587_p1() {
    mul_ln1118_930_fu_70587_p1 = tmp_930_reg_101207.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_930_fu_70587_p2() {
    mul_ln1118_930_fu_70587_p2 = (!mul_ln1118_930_fu_70587_p0.read().is_01() || !mul_ln1118_930_fu_70587_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_930_fu_70587_p0.read()) * sc_bigint<5>(mul_ln1118_930_fu_70587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_931_fu_70606_p0() {
    mul_ln1118_931_fu_70606_p0 =  (sc_lv<12>) (sext_ln1116_131_cast_fu_54675_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_931_fu_70606_p1() {
    mul_ln1118_931_fu_70606_p1 = tmp_931_reg_101212.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_931_fu_70606_p2() {
    mul_ln1118_931_fu_70606_p2 = (!mul_ln1118_931_fu_70606_p0.read().is_01() || !mul_ln1118_931_fu_70606_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_931_fu_70606_p0.read()) * sc_bigint<5>(mul_ln1118_931_fu_70606_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_932_fu_36895_p0() {
    mul_ln1118_932_fu_36895_p0 =  (sc_lv<12>) (sext_ln1116_132_cast_fu_24659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_932_fu_36895_p1() {
    mul_ln1118_932_fu_36895_p1 = tmp_932_fu_36881_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_932_fu_36895_p2() {
    mul_ln1118_932_fu_36895_p2 = (!mul_ln1118_932_fu_36895_p0.read().is_01() || !mul_ln1118_932_fu_36895_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_932_fu_36895_p0.read()) * sc_bigint<5>(mul_ln1118_932_fu_36895_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_933_fu_36925_p0() {
    mul_ln1118_933_fu_36925_p0 =  (sc_lv<12>) (sext_ln1116_133_cast_fu_24701_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_933_fu_36925_p1() {
    mul_ln1118_933_fu_36925_p1 = tmp_933_fu_36911_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_933_fu_36925_p2() {
    mul_ln1118_933_fu_36925_p2 = (!mul_ln1118_933_fu_36925_p0.read().is_01() || !mul_ln1118_933_fu_36925_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_933_fu_36925_p0.read()) * sc_bigint<5>(mul_ln1118_933_fu_36925_p1.read());
}

}

