#include "dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1831_fu_76989_p2() {
    mul_ln1118_1831_fu_76989_p2 = (!mul_ln1118_1831_fu_76989_p0.read().is_01() || !mul_ln1118_1831_fu_76989_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1831_fu_76989_p0.read()) * sc_bigint<5>(mul_ln1118_1831_fu_76989_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1832_fu_77021_p0() {
    mul_ln1118_1832_fu_77021_p0 =  (sc_lv<3>) (sext_ln1116_32_fu_22713_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1832_fu_77021_p1() {
    mul_ln1118_1832_fu_77021_p1 = tmp_1832_fu_77007_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1832_fu_77021_p2() {
    mul_ln1118_1832_fu_77021_p2 = (!mul_ln1118_1832_fu_77021_p0.read().is_01() || !mul_ln1118_1832_fu_77021_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1832_fu_77021_p0.read()) * sc_bigint<5>(mul_ln1118_1832_fu_77021_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1833_fu_77053_p0() {
    mul_ln1118_1833_fu_77053_p0 =  (sc_lv<3>) (sext_ln1116_33_fu_22757_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1833_fu_77053_p1() {
    mul_ln1118_1833_fu_77053_p1 = tmp_1833_fu_77039_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1833_fu_77053_p2() {
    mul_ln1118_1833_fu_77053_p2 = (!mul_ln1118_1833_fu_77053_p0.read().is_01() || !mul_ln1118_1833_fu_77053_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1833_fu_77053_p0.read()) * sc_bigint<5>(mul_ln1118_1833_fu_77053_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1834_fu_77073_p0() {
    mul_ln1118_1834_fu_77073_p0 =  (sc_lv<3>) (sext_ln1116_34_fu_22801_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1834_fu_77073_p1() {
    mul_ln1118_1834_fu_77073_p1 = tmp_1834_fu_77059_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1834_fu_77073_p2() {
    mul_ln1118_1834_fu_77073_p2 = (!mul_ln1118_1834_fu_77073_p0.read().is_01() || !mul_ln1118_1834_fu_77073_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1834_fu_77073_p0.read()) * sc_bigint<5>(mul_ln1118_1834_fu_77073_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1835_fu_77105_p0() {
    mul_ln1118_1835_fu_77105_p0 =  (sc_lv<3>) (sext_ln1116_35_fu_22833_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1835_fu_77105_p1() {
    mul_ln1118_1835_fu_77105_p1 = tmp_1835_fu_77091_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1835_fu_77105_p2() {
    mul_ln1118_1835_fu_77105_p2 = (!mul_ln1118_1835_fu_77105_p0.read().is_01() || !mul_ln1118_1835_fu_77105_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1835_fu_77105_p0.read()) * sc_bigint<5>(mul_ln1118_1835_fu_77105_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1836_fu_77137_p0() {
    mul_ln1118_1836_fu_77137_p0 =  (sc_lv<3>) (sext_ln1116_36_fu_22877_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1836_fu_77137_p1() {
    mul_ln1118_1836_fu_77137_p1 = tmp_1836_fu_77123_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1836_fu_77137_p2() {
    mul_ln1118_1836_fu_77137_p2 = (!mul_ln1118_1836_fu_77137_p0.read().is_01() || !mul_ln1118_1836_fu_77137_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1836_fu_77137_p0.read()) * sc_bigint<5>(mul_ln1118_1836_fu_77137_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1837_fu_77157_p0() {
    mul_ln1118_1837_fu_77157_p0 =  (sc_lv<3>) (sext_ln1116_37_fu_22921_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1837_fu_77157_p1() {
    mul_ln1118_1837_fu_77157_p1 = tmp_1837_fu_77143_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1837_fu_77157_p2() {
    mul_ln1118_1837_fu_77157_p2 = (!mul_ln1118_1837_fu_77157_p0.read().is_01() || !mul_ln1118_1837_fu_77157_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1837_fu_77157_p0.read()) * sc_bigint<5>(mul_ln1118_1837_fu_77157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1838_fu_77189_p0() {
    mul_ln1118_1838_fu_77189_p0 =  (sc_lv<3>) (sext_ln1116_38_fu_22953_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1838_fu_77189_p1() {
    mul_ln1118_1838_fu_77189_p1 = tmp_1838_fu_77175_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1838_fu_77189_p2() {
    mul_ln1118_1838_fu_77189_p2 = (!mul_ln1118_1838_fu_77189_p0.read().is_01() || !mul_ln1118_1838_fu_77189_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1838_fu_77189_p0.read()) * sc_bigint<5>(mul_ln1118_1838_fu_77189_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1839_fu_77221_p0() {
    mul_ln1118_1839_fu_77221_p0 =  (sc_lv<3>) (sext_ln1116_39_fu_22997_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1839_fu_77221_p1() {
    mul_ln1118_1839_fu_77221_p1 = tmp_1839_fu_77207_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1839_fu_77221_p2() {
    mul_ln1118_1839_fu_77221_p2 = (!mul_ln1118_1839_fu_77221_p0.read().is_01() || !mul_ln1118_1839_fu_77221_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1839_fu_77221_p0.read()) * sc_bigint<5>(mul_ln1118_1839_fu_77221_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_183_fu_28601_p0() {
    mul_ln1118_183_fu_28601_p0 =  (sc_lv<3>) (sext_ln1116_183_fu_28593_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_183_fu_28601_p1() {
    mul_ln1118_183_fu_28601_p1 = tmp_183_fu_28583_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_183_fu_28601_p2() {
    mul_ln1118_183_fu_28601_p2 = (!mul_ln1118_183_fu_28601_p0.read().is_01() || !mul_ln1118_183_fu_28601_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_183_fu_28601_p0.read()) * sc_bigint<5>(mul_ln1118_183_fu_28601_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1840_fu_77241_p0() {
    mul_ln1118_1840_fu_77241_p0 = select_ln76_31_fu_23023_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1840_fu_77241_p1() {
    mul_ln1118_1840_fu_77241_p1 = tmp_1840_fu_77227_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1840_fu_77241_p2() {
    mul_ln1118_1840_fu_77241_p2 = (!mul_ln1118_1840_fu_77241_p0.read().is_01() || !mul_ln1118_1840_fu_77241_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1840_fu_77241_p0.read()) * sc_bigint<5>(mul_ln1118_1840_fu_77241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1841_fu_77273_p0() {
    mul_ln1118_1841_fu_77273_p0 =  (sc_lv<3>) (sext_ln1116_41_fu_23063_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1841_fu_77273_p1() {
    mul_ln1118_1841_fu_77273_p1 = tmp_1841_fu_77259_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1841_fu_77273_p2() {
    mul_ln1118_1841_fu_77273_p2 = (!mul_ln1118_1841_fu_77273_p0.read().is_01() || !mul_ln1118_1841_fu_77273_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1841_fu_77273_p0.read()) * sc_bigint<5>(mul_ln1118_1841_fu_77273_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1842_fu_77305_p0() {
    mul_ln1118_1842_fu_77305_p0 =  (sc_lv<3>) (sext_ln1116_42_fu_23107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1842_fu_77305_p1() {
    mul_ln1118_1842_fu_77305_p1 = tmp_1842_fu_77291_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1842_fu_77305_p2() {
    mul_ln1118_1842_fu_77305_p2 = (!mul_ln1118_1842_fu_77305_p0.read().is_01() || !mul_ln1118_1842_fu_77305_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1842_fu_77305_p0.read()) * sc_bigint<5>(mul_ln1118_1842_fu_77305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1843_fu_77325_p0() {
    mul_ln1118_1843_fu_77325_p0 = select_ln76_34_fu_23133_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1843_fu_77325_p1() {
    mul_ln1118_1843_fu_77325_p1 = tmp_1843_fu_77311_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1843_fu_77325_p2() {
    mul_ln1118_1843_fu_77325_p2 = (!mul_ln1118_1843_fu_77325_p0.read().is_01() || !mul_ln1118_1843_fu_77325_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1843_fu_77325_p0.read()) * sc_bigint<5>(mul_ln1118_1843_fu_77325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1844_fu_77357_p0() {
    mul_ln1118_1844_fu_77357_p0 =  (sc_lv<3>) (sext_ln1116_44_fu_23173_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1844_fu_77357_p1() {
    mul_ln1118_1844_fu_77357_p1 = tmp_1844_fu_77343_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1844_fu_77357_p2() {
    mul_ln1118_1844_fu_77357_p2 = (!mul_ln1118_1844_fu_77357_p0.read().is_01() || !mul_ln1118_1844_fu_77357_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1844_fu_77357_p0.read()) * sc_bigint<5>(mul_ln1118_1844_fu_77357_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1845_fu_77389_p0() {
    mul_ln1118_1845_fu_77389_p0 =  (sc_lv<3>) (sext_ln1116_45_fu_23217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1845_fu_77389_p1() {
    mul_ln1118_1845_fu_77389_p1 = tmp_1845_fu_77375_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1845_fu_77389_p2() {
    mul_ln1118_1845_fu_77389_p2 = (!mul_ln1118_1845_fu_77389_p0.read().is_01() || !mul_ln1118_1845_fu_77389_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1845_fu_77389_p0.read()) * sc_bigint<5>(mul_ln1118_1845_fu_77389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1846_fu_77409_p0() {
    mul_ln1118_1846_fu_77409_p0 =  (sc_lv<3>) (sext_ln1116_46_fu_23261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1846_fu_77409_p1() {
    mul_ln1118_1846_fu_77409_p1 = tmp_1846_fu_77395_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1846_fu_77409_p2() {
    mul_ln1118_1846_fu_77409_p2 = (!mul_ln1118_1846_fu_77409_p0.read().is_01() || !mul_ln1118_1846_fu_77409_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1846_fu_77409_p0.read()) * sc_bigint<5>(mul_ln1118_1846_fu_77409_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1847_fu_77441_p0() {
    mul_ln1118_1847_fu_77441_p0 =  (sc_lv<3>) (sext_ln1116_47_fu_23293_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1847_fu_77441_p1() {
    mul_ln1118_1847_fu_77441_p1 = tmp_1847_fu_77427_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1847_fu_77441_p2() {
    mul_ln1118_1847_fu_77441_p2 = (!mul_ln1118_1847_fu_77441_p0.read().is_01() || !mul_ln1118_1847_fu_77441_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1847_fu_77441_p0.read()) * sc_bigint<5>(mul_ln1118_1847_fu_77441_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1848_fu_77473_p0() {
    mul_ln1118_1848_fu_77473_p0 =  (sc_lv<3>) (sext_ln1116_48_fu_23337_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1848_fu_77473_p1() {
    mul_ln1118_1848_fu_77473_p1 = tmp_1848_fu_77459_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1848_fu_77473_p2() {
    mul_ln1118_1848_fu_77473_p2 = (!mul_ln1118_1848_fu_77473_p0.read().is_01() || !mul_ln1118_1848_fu_77473_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1848_fu_77473_p0.read()) * sc_bigint<5>(mul_ln1118_1848_fu_77473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1849_fu_77493_p0() {
    mul_ln1118_1849_fu_77493_p0 =  (sc_lv<3>) (sext_ln1116_49_fu_23381_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1849_fu_77493_p1() {
    mul_ln1118_1849_fu_77493_p1 = tmp_1849_fu_77479_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1849_fu_77493_p2() {
    mul_ln1118_1849_fu_77493_p2 = (!mul_ln1118_1849_fu_77493_p0.read().is_01() || !mul_ln1118_1849_fu_77493_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1849_fu_77493_p0.read()) * sc_bigint<5>(mul_ln1118_1849_fu_77493_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_184_fu_28645_p0() {
    mul_ln1118_184_fu_28645_p0 =  (sc_lv<3>) (sext_ln1116_184_fu_28637_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_184_fu_28645_p1() {
    mul_ln1118_184_fu_28645_p1 = tmp_184_fu_28627_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_184_fu_28645_p2() {
    mul_ln1118_184_fu_28645_p2 = (!mul_ln1118_184_fu_28645_p0.read().is_01() || !mul_ln1118_184_fu_28645_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_184_fu_28645_p0.read()) * sc_bigint<5>(mul_ln1118_184_fu_28645_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1850_fu_77525_p0() {
    mul_ln1118_1850_fu_77525_p0 =  (sc_lv<3>) (sext_ln1116_50_fu_23413_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1850_fu_77525_p1() {
    mul_ln1118_1850_fu_77525_p1 = tmp_1850_fu_77511_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1850_fu_77525_p2() {
    mul_ln1118_1850_fu_77525_p2 = (!mul_ln1118_1850_fu_77525_p0.read().is_01() || !mul_ln1118_1850_fu_77525_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1850_fu_77525_p0.read()) * sc_bigint<5>(mul_ln1118_1850_fu_77525_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1851_fu_77557_p0() {
    mul_ln1118_1851_fu_77557_p0 =  (sc_lv<3>) (sext_ln1116_51_fu_23457_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1851_fu_77557_p1() {
    mul_ln1118_1851_fu_77557_p1 = tmp_1851_fu_77543_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1851_fu_77557_p2() {
    mul_ln1118_1851_fu_77557_p2 = (!mul_ln1118_1851_fu_77557_p0.read().is_01() || !mul_ln1118_1851_fu_77557_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1851_fu_77557_p0.read()) * sc_bigint<5>(mul_ln1118_1851_fu_77557_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1852_fu_77577_p0() {
    mul_ln1118_1852_fu_77577_p0 = select_ln76_43_fu_23483_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1852_fu_77577_p1() {
    mul_ln1118_1852_fu_77577_p1 = tmp_1852_fu_77563_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1852_fu_77577_p2() {
    mul_ln1118_1852_fu_77577_p2 = (!mul_ln1118_1852_fu_77577_p0.read().is_01() || !mul_ln1118_1852_fu_77577_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1852_fu_77577_p0.read()) * sc_bigint<5>(mul_ln1118_1852_fu_77577_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1853_fu_77609_p0() {
    mul_ln1118_1853_fu_77609_p0 =  (sc_lv<3>) (sext_ln1116_53_fu_23523_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1853_fu_77609_p1() {
    mul_ln1118_1853_fu_77609_p1 = tmp_1853_fu_77595_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1853_fu_77609_p2() {
    mul_ln1118_1853_fu_77609_p2 = (!mul_ln1118_1853_fu_77609_p0.read().is_01() || !mul_ln1118_1853_fu_77609_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1853_fu_77609_p0.read()) * sc_bigint<5>(mul_ln1118_1853_fu_77609_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1854_fu_77641_p0() {
    mul_ln1118_1854_fu_77641_p0 =  (sc_lv<3>) (sext_ln1116_54_fu_23567_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1854_fu_77641_p1() {
    mul_ln1118_1854_fu_77641_p1 = tmp_1854_fu_77627_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1854_fu_77641_p2() {
    mul_ln1118_1854_fu_77641_p2 = (!mul_ln1118_1854_fu_77641_p0.read().is_01() || !mul_ln1118_1854_fu_77641_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1854_fu_77641_p0.read()) * sc_bigint<5>(mul_ln1118_1854_fu_77641_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1855_fu_77673_p0() {
    mul_ln1118_1855_fu_77673_p0 =  (sc_lv<3>) (sext_ln1116_55_fu_23611_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1855_fu_77673_p1() {
    mul_ln1118_1855_fu_77673_p1 = tmp_1855_fu_77659_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1855_fu_77673_p2() {
    mul_ln1118_1855_fu_77673_p2 = (!mul_ln1118_1855_fu_77673_p0.read().is_01() || !mul_ln1118_1855_fu_77673_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1855_fu_77673_p0.read()) * sc_bigint<5>(mul_ln1118_1855_fu_77673_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1856_fu_77705_p0() {
    mul_ln1118_1856_fu_77705_p0 =  (sc_lv<3>) (sext_ln1116_56_fu_23655_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1856_fu_77705_p1() {
    mul_ln1118_1856_fu_77705_p1 = tmp_1856_fu_77691_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1856_fu_77705_p2() {
    mul_ln1118_1856_fu_77705_p2 = (!mul_ln1118_1856_fu_77705_p0.read().is_01() || !mul_ln1118_1856_fu_77705_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1856_fu_77705_p0.read()) * sc_bigint<5>(mul_ln1118_1856_fu_77705_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1857_fu_77737_p0() {
    mul_ln1118_1857_fu_77737_p0 =  (sc_lv<3>) (sext_ln1116_57_fu_23699_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1857_fu_77737_p1() {
    mul_ln1118_1857_fu_77737_p1 = tmp_1857_fu_77723_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1857_fu_77737_p2() {
    mul_ln1118_1857_fu_77737_p2 = (!mul_ln1118_1857_fu_77737_p0.read().is_01() || !mul_ln1118_1857_fu_77737_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1857_fu_77737_p0.read()) * sc_bigint<5>(mul_ln1118_1857_fu_77737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1858_fu_77769_p0() {
    mul_ln1118_1858_fu_77769_p0 =  (sc_lv<3>) (sext_ln1116_58_fu_23743_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1858_fu_77769_p1() {
    mul_ln1118_1858_fu_77769_p1 = tmp_1858_fu_77755_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1858_fu_77769_p2() {
    mul_ln1118_1858_fu_77769_p2 = (!mul_ln1118_1858_fu_77769_p0.read().is_01() || !mul_ln1118_1858_fu_77769_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1858_fu_77769_p0.read()) * sc_bigint<5>(mul_ln1118_1858_fu_77769_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1859_fu_77789_p0() {
    mul_ln1118_1859_fu_77789_p0 =  (sc_lv<3>) (sext_ln1116_59_fu_23787_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1859_fu_77789_p1() {
    mul_ln1118_1859_fu_77789_p1 = tmp_1859_fu_77775_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1859_fu_77789_p2() {
    mul_ln1118_1859_fu_77789_p2 = (!mul_ln1118_1859_fu_77789_p0.read().is_01() || !mul_ln1118_1859_fu_77789_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1859_fu_77789_p0.read()) * sc_bigint<5>(mul_ln1118_1859_fu_77789_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_185_fu_28677_p0() {
    mul_ln1118_185_fu_28677_p0 =  (sc_lv<3>) (sext_ln1116_185_fu_28669_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_185_fu_28677_p1() {
    mul_ln1118_185_fu_28677_p1 = tmp_185_fu_28659_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_185_fu_28677_p2() {
    mul_ln1118_185_fu_28677_p2 = (!mul_ln1118_185_fu_28677_p0.read().is_01() || !mul_ln1118_185_fu_28677_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_185_fu_28677_p0.read()) * sc_bigint<5>(mul_ln1118_185_fu_28677_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1860_fu_77821_p0() {
    mul_ln1118_1860_fu_77821_p0 =  (sc_lv<3>) (sext_ln1116_60_fu_23819_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1860_fu_77821_p1() {
    mul_ln1118_1860_fu_77821_p1 = tmp_1860_fu_77807_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1860_fu_77821_p2() {
    mul_ln1118_1860_fu_77821_p2 = (!mul_ln1118_1860_fu_77821_p0.read().is_01() || !mul_ln1118_1860_fu_77821_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1860_fu_77821_p0.read()) * sc_bigint<5>(mul_ln1118_1860_fu_77821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1861_fu_77853_p0() {
    mul_ln1118_1861_fu_77853_p0 =  (sc_lv<3>) (sext_ln1116_61_fu_23863_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1861_fu_77853_p1() {
    mul_ln1118_1861_fu_77853_p1 = tmp_1861_fu_77839_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1861_fu_77853_p2() {
    mul_ln1118_1861_fu_77853_p2 = (!mul_ln1118_1861_fu_77853_p0.read().is_01() || !mul_ln1118_1861_fu_77853_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1861_fu_77853_p0.read()) * sc_bigint<5>(mul_ln1118_1861_fu_77853_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1862_fu_77873_p0() {
    mul_ln1118_1862_fu_77873_p0 =  (sc_lv<3>) (sext_ln1116_62_fu_23907_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1862_fu_77873_p1() {
    mul_ln1118_1862_fu_77873_p1 = tmp_1862_fu_77859_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1862_fu_77873_p2() {
    mul_ln1118_1862_fu_77873_p2 = (!mul_ln1118_1862_fu_77873_p0.read().is_01() || !mul_ln1118_1862_fu_77873_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1862_fu_77873_p0.read()) * sc_bigint<5>(mul_ln1118_1862_fu_77873_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1863_fu_77905_p0() {
    mul_ln1118_1863_fu_77905_p0 =  (sc_lv<3>) (sext_ln1116_63_fu_23939_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1863_fu_77905_p1() {
    mul_ln1118_1863_fu_77905_p1 = tmp_1863_fu_77891_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1863_fu_77905_p2() {
    mul_ln1118_1863_fu_77905_p2 = (!mul_ln1118_1863_fu_77905_p0.read().is_01() || !mul_ln1118_1863_fu_77905_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1863_fu_77905_p0.read()) * sc_bigint<5>(mul_ln1118_1863_fu_77905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1864_fu_77937_p0() {
    mul_ln1118_1864_fu_77937_p0 =  (sc_lv<3>) (sext_ln1116_64_fu_23983_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1864_fu_77937_p1() {
    mul_ln1118_1864_fu_77937_p1 = tmp_1864_fu_77923_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1864_fu_77937_p2() {
    mul_ln1118_1864_fu_77937_p2 = (!mul_ln1118_1864_fu_77937_p0.read().is_01() || !mul_ln1118_1864_fu_77937_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1864_fu_77937_p0.read()) * sc_bigint<5>(mul_ln1118_1864_fu_77937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1865_fu_77957_p0() {
    mul_ln1118_1865_fu_77957_p0 = select_ln76_56_fu_24009_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1865_fu_77957_p1() {
    mul_ln1118_1865_fu_77957_p1 = tmp_1865_fu_77943_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1865_fu_77957_p2() {
    mul_ln1118_1865_fu_77957_p2 = (!mul_ln1118_1865_fu_77957_p0.read().is_01() || !mul_ln1118_1865_fu_77957_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1865_fu_77957_p0.read()) * sc_bigint<5>(mul_ln1118_1865_fu_77957_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1866_fu_77989_p0() {
    mul_ln1118_1866_fu_77989_p0 =  (sc_lv<3>) (sext_ln1116_66_fu_24049_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1866_fu_77989_p1() {
    mul_ln1118_1866_fu_77989_p1 = tmp_1866_fu_77975_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1866_fu_77989_p2() {
    mul_ln1118_1866_fu_77989_p2 = (!mul_ln1118_1866_fu_77989_p0.read().is_01() || !mul_ln1118_1866_fu_77989_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1866_fu_77989_p0.read()) * sc_bigint<5>(mul_ln1118_1866_fu_77989_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1867_fu_78021_p0() {
    mul_ln1118_1867_fu_78021_p0 =  (sc_lv<3>) (sext_ln1116_67_fu_24093_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1867_fu_78021_p1() {
    mul_ln1118_1867_fu_78021_p1 = tmp_1867_fu_78007_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1867_fu_78021_p2() {
    mul_ln1118_1867_fu_78021_p2 = (!mul_ln1118_1867_fu_78021_p0.read().is_01() || !mul_ln1118_1867_fu_78021_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1867_fu_78021_p0.read()) * sc_bigint<5>(mul_ln1118_1867_fu_78021_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1868_fu_78041_p0() {
    mul_ln1118_1868_fu_78041_p0 = select_ln76_59_fu_24119_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1868_fu_78041_p1() {
    mul_ln1118_1868_fu_78041_p1 = tmp_1868_fu_78027_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1868_fu_78041_p2() {
    mul_ln1118_1868_fu_78041_p2 = (!mul_ln1118_1868_fu_78041_p0.read().is_01() || !mul_ln1118_1868_fu_78041_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1868_fu_78041_p0.read()) * sc_bigint<5>(mul_ln1118_1868_fu_78041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1869_fu_78073_p0() {
    mul_ln1118_1869_fu_78073_p0 =  (sc_lv<3>) (sext_ln1116_69_fu_24159_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1869_fu_78073_p1() {
    mul_ln1118_1869_fu_78073_p1 = tmp_1869_fu_78059_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1869_fu_78073_p2() {
    mul_ln1118_1869_fu_78073_p2 = (!mul_ln1118_1869_fu_78073_p0.read().is_01() || !mul_ln1118_1869_fu_78073_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1869_fu_78073_p0.read()) * sc_bigint<5>(mul_ln1118_1869_fu_78073_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_186_fu_28721_p0() {
    mul_ln1118_186_fu_28721_p0 =  (sc_lv<3>) (sext_ln1116_186_fu_28713_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_186_fu_28721_p1() {
    mul_ln1118_186_fu_28721_p1 = tmp_186_fu_28703_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_186_fu_28721_p2() {
    mul_ln1118_186_fu_28721_p2 = (!mul_ln1118_186_fu_28721_p0.read().is_01() || !mul_ln1118_186_fu_28721_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_186_fu_28721_p0.read()) * sc_bigint<5>(mul_ln1118_186_fu_28721_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1870_fu_78105_p0() {
    mul_ln1118_1870_fu_78105_p0 =  (sc_lv<3>) (sext_ln1116_70_fu_24203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1870_fu_78105_p1() {
    mul_ln1118_1870_fu_78105_p1 = tmp_1870_fu_78091_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1870_fu_78105_p2() {
    mul_ln1118_1870_fu_78105_p2 = (!mul_ln1118_1870_fu_78105_p0.read().is_01() || !mul_ln1118_1870_fu_78105_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1870_fu_78105_p0.read()) * sc_bigint<5>(mul_ln1118_1870_fu_78105_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1871_fu_78125_p0() {
    mul_ln1118_1871_fu_78125_p0 = select_ln76_62_fu_24229_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1871_fu_78125_p1() {
    mul_ln1118_1871_fu_78125_p1 = tmp_1871_fu_78111_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1871_fu_78125_p2() {
    mul_ln1118_1871_fu_78125_p2 = (!mul_ln1118_1871_fu_78125_p0.read().is_01() || !mul_ln1118_1871_fu_78125_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1871_fu_78125_p0.read()) * sc_bigint<5>(mul_ln1118_1871_fu_78125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1872_fu_78157_p0() {
    mul_ln1118_1872_fu_78157_p0 =  (sc_lv<3>) (sext_ln1116_72_fu_24269_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1872_fu_78157_p1() {
    mul_ln1118_1872_fu_78157_p1 = tmp_1872_fu_78143_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1872_fu_78157_p2() {
    mul_ln1118_1872_fu_78157_p2 = (!mul_ln1118_1872_fu_78157_p0.read().is_01() || !mul_ln1118_1872_fu_78157_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1872_fu_78157_p0.read()) * sc_bigint<5>(mul_ln1118_1872_fu_78157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1873_fu_78189_p0() {
    mul_ln1118_1873_fu_78189_p0 =  (sc_lv<3>) (sext_ln1116_73_fu_24313_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1873_fu_78189_p1() {
    mul_ln1118_1873_fu_78189_p1 = tmp_1873_fu_78175_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1873_fu_78189_p2() {
    mul_ln1118_1873_fu_78189_p2 = (!mul_ln1118_1873_fu_78189_p0.read().is_01() || !mul_ln1118_1873_fu_78189_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1873_fu_78189_p0.read()) * sc_bigint<5>(mul_ln1118_1873_fu_78189_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1874_fu_78209_p0() {
    mul_ln1118_1874_fu_78209_p0 = select_ln76_65_fu_24339_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1874_fu_78209_p1() {
    mul_ln1118_1874_fu_78209_p1 = tmp_1874_fu_78195_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1874_fu_78209_p2() {
    mul_ln1118_1874_fu_78209_p2 = (!mul_ln1118_1874_fu_78209_p0.read().is_01() || !mul_ln1118_1874_fu_78209_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1874_fu_78209_p0.read()) * sc_bigint<5>(mul_ln1118_1874_fu_78209_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1875_fu_78241_p0() {
    mul_ln1118_1875_fu_78241_p0 =  (sc_lv<3>) (sext_ln1116_75_fu_24379_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1875_fu_78241_p1() {
    mul_ln1118_1875_fu_78241_p1 = tmp_1875_fu_78227_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1875_fu_78241_p2() {
    mul_ln1118_1875_fu_78241_p2 = (!mul_ln1118_1875_fu_78241_p0.read().is_01() || !mul_ln1118_1875_fu_78241_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1875_fu_78241_p0.read()) * sc_bigint<5>(mul_ln1118_1875_fu_78241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1876_fu_78273_p0() {
    mul_ln1118_1876_fu_78273_p0 =  (sc_lv<3>) (sext_ln1116_76_fu_24423_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1876_fu_78273_p1() {
    mul_ln1118_1876_fu_78273_p1 = tmp_1876_fu_78259_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1876_fu_78273_p2() {
    mul_ln1118_1876_fu_78273_p2 = (!mul_ln1118_1876_fu_78273_p0.read().is_01() || !mul_ln1118_1876_fu_78273_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1876_fu_78273_p0.read()) * sc_bigint<5>(mul_ln1118_1876_fu_78273_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1877_fu_78293_p0() {
    mul_ln1118_1877_fu_78293_p0 = select_ln76_68_fu_24449_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1877_fu_78293_p1() {
    mul_ln1118_1877_fu_78293_p1 = tmp_1877_fu_78279_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1877_fu_78293_p2() {
    mul_ln1118_1877_fu_78293_p2 = (!mul_ln1118_1877_fu_78293_p0.read().is_01() || !mul_ln1118_1877_fu_78293_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1877_fu_78293_p0.read()) * sc_bigint<5>(mul_ln1118_1877_fu_78293_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1878_fu_78325_p0() {
    mul_ln1118_1878_fu_78325_p0 =  (sc_lv<3>) (sext_ln1116_78_fu_24489_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1878_fu_78325_p1() {
    mul_ln1118_1878_fu_78325_p1 = tmp_1878_fu_78311_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1878_fu_78325_p2() {
    mul_ln1118_1878_fu_78325_p2 = (!mul_ln1118_1878_fu_78325_p0.read().is_01() || !mul_ln1118_1878_fu_78325_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1878_fu_78325_p0.read()) * sc_bigint<5>(mul_ln1118_1878_fu_78325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1879_fu_78357_p0() {
    mul_ln1118_1879_fu_78357_p0 =  (sc_lv<3>) (sext_ln1116_79_fu_24533_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1879_fu_78357_p1() {
    mul_ln1118_1879_fu_78357_p1 = tmp_1879_fu_78343_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1879_fu_78357_p2() {
    mul_ln1118_1879_fu_78357_p2 = (!mul_ln1118_1879_fu_78357_p0.read().is_01() || !mul_ln1118_1879_fu_78357_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1879_fu_78357_p0.read()) * sc_bigint<5>(mul_ln1118_1879_fu_78357_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_187_fu_28765_p0() {
    mul_ln1118_187_fu_28765_p0 =  (sc_lv<3>) (sext_ln1116_187_fu_28757_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_187_fu_28765_p1() {
    mul_ln1118_187_fu_28765_p1 = tmp_187_fu_28747_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_187_fu_28765_p2() {
    mul_ln1118_187_fu_28765_p2 = (!mul_ln1118_187_fu_28765_p0.read().is_01() || !mul_ln1118_187_fu_28765_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_187_fu_28765_p0.read()) * sc_bigint<5>(mul_ln1118_187_fu_28765_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1880_fu_78389_p0() {
    mul_ln1118_1880_fu_78389_p0 =  (sc_lv<3>) (sext_ln1116_80_fu_24577_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1880_fu_78389_p1() {
    mul_ln1118_1880_fu_78389_p1 = tmp_1880_fu_78375_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1880_fu_78389_p2() {
    mul_ln1118_1880_fu_78389_p2 = (!mul_ln1118_1880_fu_78389_p0.read().is_01() || !mul_ln1118_1880_fu_78389_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1880_fu_78389_p0.read()) * sc_bigint<5>(mul_ln1118_1880_fu_78389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1881_fu_78421_p0() {
    mul_ln1118_1881_fu_78421_p0 =  (sc_lv<3>) (sext_ln1116_81_fu_24621_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1881_fu_78421_p1() {
    mul_ln1118_1881_fu_78421_p1 = tmp_1881_fu_78407_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1881_fu_78421_p2() {
    mul_ln1118_1881_fu_78421_p2 = (!mul_ln1118_1881_fu_78421_p0.read().is_01() || !mul_ln1118_1881_fu_78421_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1881_fu_78421_p0.read()) * sc_bigint<5>(mul_ln1118_1881_fu_78421_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1882_fu_78453_p0() {
    mul_ln1118_1882_fu_78453_p0 =  (sc_lv<3>) (sext_ln1116_82_fu_24665_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1882_fu_78453_p1() {
    mul_ln1118_1882_fu_78453_p1 = tmp_1882_fu_78439_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1882_fu_78453_p2() {
    mul_ln1118_1882_fu_78453_p2 = (!mul_ln1118_1882_fu_78453_p0.read().is_01() || !mul_ln1118_1882_fu_78453_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1882_fu_78453_p0.read()) * sc_bigint<5>(mul_ln1118_1882_fu_78453_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1883_fu_78485_p0() {
    mul_ln1118_1883_fu_78485_p0 =  (sc_lv<3>) (sext_ln1116_83_fu_24709_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1883_fu_78485_p1() {
    mul_ln1118_1883_fu_78485_p1 = tmp_1883_fu_78471_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1883_fu_78485_p2() {
    mul_ln1118_1883_fu_78485_p2 = (!mul_ln1118_1883_fu_78485_p0.read().is_01() || !mul_ln1118_1883_fu_78485_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1883_fu_78485_p0.read()) * sc_bigint<5>(mul_ln1118_1883_fu_78485_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1884_fu_78505_p0() {
    mul_ln1118_1884_fu_78505_p0 =  (sc_lv<3>) (sext_ln1116_84_fu_24753_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1884_fu_78505_p1() {
    mul_ln1118_1884_fu_78505_p1 = tmp_1884_fu_78491_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1884_fu_78505_p2() {
    mul_ln1118_1884_fu_78505_p2 = (!mul_ln1118_1884_fu_78505_p0.read().is_01() || !mul_ln1118_1884_fu_78505_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1884_fu_78505_p0.read()) * sc_bigint<5>(mul_ln1118_1884_fu_78505_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1885_fu_78537_p0() {
    mul_ln1118_1885_fu_78537_p0 =  (sc_lv<3>) (sext_ln1116_85_fu_24785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1885_fu_78537_p1() {
    mul_ln1118_1885_fu_78537_p1 = tmp_1885_fu_78523_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1885_fu_78537_p2() {
    mul_ln1118_1885_fu_78537_p2 = (!mul_ln1118_1885_fu_78537_p0.read().is_01() || !mul_ln1118_1885_fu_78537_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1885_fu_78537_p0.read()) * sc_bigint<5>(mul_ln1118_1885_fu_78537_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1886_fu_78569_p0() {
    mul_ln1118_1886_fu_78569_p0 =  (sc_lv<3>) (sext_ln1116_86_fu_24829_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1886_fu_78569_p1() {
    mul_ln1118_1886_fu_78569_p1 = tmp_1886_fu_78555_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1886_fu_78569_p2() {
    mul_ln1118_1886_fu_78569_p2 = (!mul_ln1118_1886_fu_78569_p0.read().is_01() || !mul_ln1118_1886_fu_78569_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1886_fu_78569_p0.read()) * sc_bigint<5>(mul_ln1118_1886_fu_78569_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1887_fu_78589_p0() {
    mul_ln1118_1887_fu_78589_p0 =  (sc_lv<3>) (sext_ln1116_87_fu_24873_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1887_fu_78589_p1() {
    mul_ln1118_1887_fu_78589_p1 = tmp_1887_fu_78575_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1887_fu_78589_p2() {
    mul_ln1118_1887_fu_78589_p2 = (!mul_ln1118_1887_fu_78589_p0.read().is_01() || !mul_ln1118_1887_fu_78589_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1887_fu_78589_p0.read()) * sc_bigint<5>(mul_ln1118_1887_fu_78589_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1888_fu_78621_p0() {
    mul_ln1118_1888_fu_78621_p0 =  (sc_lv<3>) (sext_ln1116_88_fu_24905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1888_fu_78621_p1() {
    mul_ln1118_1888_fu_78621_p1 = tmp_1888_fu_78607_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1888_fu_78621_p2() {
    mul_ln1118_1888_fu_78621_p2 = (!mul_ln1118_1888_fu_78621_p0.read().is_01() || !mul_ln1118_1888_fu_78621_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1888_fu_78621_p0.read()) * sc_bigint<5>(mul_ln1118_1888_fu_78621_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1889_fu_78653_p0() {
    mul_ln1118_1889_fu_78653_p0 =  (sc_lv<3>) (sext_ln1116_89_fu_24949_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1889_fu_78653_p1() {
    mul_ln1118_1889_fu_78653_p1 = tmp_1889_fu_78639_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1889_fu_78653_p2() {
    mul_ln1118_1889_fu_78653_p2 = (!mul_ln1118_1889_fu_78653_p0.read().is_01() || !mul_ln1118_1889_fu_78653_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1889_fu_78653_p0.read()) * sc_bigint<5>(mul_ln1118_1889_fu_78653_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_188_fu_28797_p0() {
    mul_ln1118_188_fu_28797_p0 =  (sc_lv<3>) (sext_ln1116_188_fu_28789_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_188_fu_28797_p1() {
    mul_ln1118_188_fu_28797_p1 = tmp_188_fu_28779_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_188_fu_28797_p2() {
    mul_ln1118_188_fu_28797_p2 = (!mul_ln1118_188_fu_28797_p0.read().is_01() || !mul_ln1118_188_fu_28797_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_188_fu_28797_p0.read()) * sc_bigint<5>(mul_ln1118_188_fu_28797_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1890_fu_78673_p0() {
    mul_ln1118_1890_fu_78673_p0 = select_ln76_81_fu_24975_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1890_fu_78673_p1() {
    mul_ln1118_1890_fu_78673_p1 = tmp_1890_fu_78659_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1890_fu_78673_p2() {
    mul_ln1118_1890_fu_78673_p2 = (!mul_ln1118_1890_fu_78673_p0.read().is_01() || !mul_ln1118_1890_fu_78673_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1890_fu_78673_p0.read()) * sc_bigint<5>(mul_ln1118_1890_fu_78673_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1891_fu_78705_p0() {
    mul_ln1118_1891_fu_78705_p0 =  (sc_lv<3>) (sext_ln1116_91_fu_25015_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1891_fu_78705_p1() {
    mul_ln1118_1891_fu_78705_p1 = tmp_1891_fu_78691_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1891_fu_78705_p2() {
    mul_ln1118_1891_fu_78705_p2 = (!mul_ln1118_1891_fu_78705_p0.read().is_01() || !mul_ln1118_1891_fu_78705_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1891_fu_78705_p0.read()) * sc_bigint<5>(mul_ln1118_1891_fu_78705_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1892_fu_78737_p0() {
    mul_ln1118_1892_fu_78737_p0 =  (sc_lv<3>) (sext_ln1116_92_fu_25059_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1892_fu_78737_p1() {
    mul_ln1118_1892_fu_78737_p1 = tmp_1892_fu_78723_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1892_fu_78737_p2() {
    mul_ln1118_1892_fu_78737_p2 = (!mul_ln1118_1892_fu_78737_p0.read().is_01() || !mul_ln1118_1892_fu_78737_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1892_fu_78737_p0.read()) * sc_bigint<5>(mul_ln1118_1892_fu_78737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1893_fu_78757_p0() {
    mul_ln1118_1893_fu_78757_p0 = select_ln76_84_fu_25085_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1893_fu_78757_p1() {
    mul_ln1118_1893_fu_78757_p1 = tmp_1893_fu_78743_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1893_fu_78757_p2() {
    mul_ln1118_1893_fu_78757_p2 = (!mul_ln1118_1893_fu_78757_p0.read().is_01() || !mul_ln1118_1893_fu_78757_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1893_fu_78757_p0.read()) * sc_bigint<5>(mul_ln1118_1893_fu_78757_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1894_fu_78789_p0() {
    mul_ln1118_1894_fu_78789_p0 =  (sc_lv<3>) (sext_ln1116_94_fu_25125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1894_fu_78789_p1() {
    mul_ln1118_1894_fu_78789_p1 = tmp_1894_fu_78775_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1894_fu_78789_p2() {
    mul_ln1118_1894_fu_78789_p2 = (!mul_ln1118_1894_fu_78789_p0.read().is_01() || !mul_ln1118_1894_fu_78789_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1894_fu_78789_p0.read()) * sc_bigint<5>(mul_ln1118_1894_fu_78789_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1895_fu_78821_p0() {
    mul_ln1118_1895_fu_78821_p0 =  (sc_lv<3>) (sext_ln1116_95_fu_25169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1895_fu_78821_p1() {
    mul_ln1118_1895_fu_78821_p1 = tmp_1895_fu_78807_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1895_fu_78821_p2() {
    mul_ln1118_1895_fu_78821_p2 = (!mul_ln1118_1895_fu_78821_p0.read().is_01() || !mul_ln1118_1895_fu_78821_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1895_fu_78821_p0.read()) * sc_bigint<5>(mul_ln1118_1895_fu_78821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1896_fu_78841_p0() {
    mul_ln1118_1896_fu_78841_p0 = select_ln76_87_fu_25195_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1896_fu_78841_p1() {
    mul_ln1118_1896_fu_78841_p1 = tmp_1896_fu_78827_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1896_fu_78841_p2() {
    mul_ln1118_1896_fu_78841_p2 = (!mul_ln1118_1896_fu_78841_p0.read().is_01() || !mul_ln1118_1896_fu_78841_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1896_fu_78841_p0.read()) * sc_bigint<5>(mul_ln1118_1896_fu_78841_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1897_fu_78873_p0() {
    mul_ln1118_1897_fu_78873_p0 =  (sc_lv<3>) (sext_ln1116_97_fu_25235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1897_fu_78873_p1() {
    mul_ln1118_1897_fu_78873_p1 = tmp_1897_fu_78859_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1897_fu_78873_p2() {
    mul_ln1118_1897_fu_78873_p2 = (!mul_ln1118_1897_fu_78873_p0.read().is_01() || !mul_ln1118_1897_fu_78873_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1897_fu_78873_p0.read()) * sc_bigint<5>(mul_ln1118_1897_fu_78873_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1898_fu_78905_p0() {
    mul_ln1118_1898_fu_78905_p0 =  (sc_lv<3>) (sext_ln1116_98_fu_25279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1898_fu_78905_p1() {
    mul_ln1118_1898_fu_78905_p1 = tmp_1898_fu_78891_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1898_fu_78905_p2() {
    mul_ln1118_1898_fu_78905_p2 = (!mul_ln1118_1898_fu_78905_p0.read().is_01() || !mul_ln1118_1898_fu_78905_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1898_fu_78905_p0.read()) * sc_bigint<5>(mul_ln1118_1898_fu_78905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1899_fu_78925_p0() {
    mul_ln1118_1899_fu_78925_p0 = select_ln76_90_fu_25305_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1899_fu_78925_p1() {
    mul_ln1118_1899_fu_78925_p1 = tmp_1899_fu_78911_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1899_fu_78925_p2() {
    mul_ln1118_1899_fu_78925_p2 = (!mul_ln1118_1899_fu_78925_p0.read().is_01() || !mul_ln1118_1899_fu_78925_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1899_fu_78925_p0.read()) * sc_bigint<5>(mul_ln1118_1899_fu_78925_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_189_fu_28841_p0() {
    mul_ln1118_189_fu_28841_p0 =  (sc_lv<3>) (sext_ln1116_189_fu_28833_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_189_fu_28841_p1() {
    mul_ln1118_189_fu_28841_p1 = tmp_189_fu_28823_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_189_fu_28841_p2() {
    mul_ln1118_189_fu_28841_p2 = (!mul_ln1118_189_fu_28841_p0.read().is_01() || !mul_ln1118_189_fu_28841_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_189_fu_28841_p0.read()) * sc_bigint<5>(mul_ln1118_189_fu_28841_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_18_fu_82481_p0() {
    mul_ln1118_18_fu_82481_p0 =  (sc_lv<3>) (sext_ln1116_18_fu_82475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_18_fu_82481_p1() {
    mul_ln1118_18_fu_82481_p1 = tmp_19_reg_105890.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_18_fu_82481_p2() {
    mul_ln1118_18_fu_82481_p2 = (!mul_ln1118_18_fu_82481_p0.read().is_01() || !mul_ln1118_18_fu_82481_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_18_fu_82481_p0.read()) * sc_bigint<5>(mul_ln1118_18_fu_82481_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1900_fu_78957_p0() {
    mul_ln1118_1900_fu_78957_p0 =  (sc_lv<3>) (sext_ln1116_100_fu_25345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1900_fu_78957_p1() {
    mul_ln1118_1900_fu_78957_p1 = tmp_1900_fu_78943_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1900_fu_78957_p2() {
    mul_ln1118_1900_fu_78957_p2 = (!mul_ln1118_1900_fu_78957_p0.read().is_01() || !mul_ln1118_1900_fu_78957_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1900_fu_78957_p0.read()) * sc_bigint<5>(mul_ln1118_1900_fu_78957_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1901_fu_78989_p0() {
    mul_ln1118_1901_fu_78989_p0 =  (sc_lv<3>) (sext_ln1116_101_fu_25389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1901_fu_78989_p1() {
    mul_ln1118_1901_fu_78989_p1 = tmp_1901_fu_78975_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1901_fu_78989_p2() {
    mul_ln1118_1901_fu_78989_p2 = (!mul_ln1118_1901_fu_78989_p0.read().is_01() || !mul_ln1118_1901_fu_78989_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1901_fu_78989_p0.read()) * sc_bigint<5>(mul_ln1118_1901_fu_78989_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1902_fu_79009_p0() {
    mul_ln1118_1902_fu_79009_p0 = select_ln76_93_fu_25415_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1902_fu_79009_p1() {
    mul_ln1118_1902_fu_79009_p1 = tmp_1902_fu_78995_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1902_fu_79009_p2() {
    mul_ln1118_1902_fu_79009_p2 = (!mul_ln1118_1902_fu_79009_p0.read().is_01() || !mul_ln1118_1902_fu_79009_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1902_fu_79009_p0.read()) * sc_bigint<5>(mul_ln1118_1902_fu_79009_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1903_fu_79041_p0() {
    mul_ln1118_1903_fu_79041_p0 =  (sc_lv<3>) (sext_ln1116_103_fu_25455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1903_fu_79041_p1() {
    mul_ln1118_1903_fu_79041_p1 = tmp_1903_fu_79027_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1903_fu_79041_p2() {
    mul_ln1118_1903_fu_79041_p2 = (!mul_ln1118_1903_fu_79041_p0.read().is_01() || !mul_ln1118_1903_fu_79041_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1903_fu_79041_p0.read()) * sc_bigint<5>(mul_ln1118_1903_fu_79041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1904_fu_79073_p0() {
    mul_ln1118_1904_fu_79073_p0 =  (sc_lv<3>) (sext_ln1116_104_fu_25499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1904_fu_79073_p1() {
    mul_ln1118_1904_fu_79073_p1 = tmp_1904_fu_79059_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1904_fu_79073_p2() {
    mul_ln1118_1904_fu_79073_p2 = (!mul_ln1118_1904_fu_79073_p0.read().is_01() || !mul_ln1118_1904_fu_79073_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1904_fu_79073_p0.read()) * sc_bigint<5>(mul_ln1118_1904_fu_79073_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1905_fu_79105_p0() {
    mul_ln1118_1905_fu_79105_p0 =  (sc_lv<3>) (sext_ln1116_105_fu_25543_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1905_fu_79105_p1() {
    mul_ln1118_1905_fu_79105_p1 = tmp_1905_fu_79091_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1905_fu_79105_p2() {
    mul_ln1118_1905_fu_79105_p2 = (!mul_ln1118_1905_fu_79105_p0.read().is_01() || !mul_ln1118_1905_fu_79105_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1905_fu_79105_p0.read()) * sc_bigint<5>(mul_ln1118_1905_fu_79105_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1906_fu_79137_p0() {
    mul_ln1118_1906_fu_79137_p0 =  (sc_lv<3>) (sext_ln1116_106_fu_25587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1906_fu_79137_p1() {
    mul_ln1118_1906_fu_79137_p1 = tmp_1906_fu_79123_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1906_fu_79137_p2() {
    mul_ln1118_1906_fu_79137_p2 = (!mul_ln1118_1906_fu_79137_p0.read().is_01() || !mul_ln1118_1906_fu_79137_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1906_fu_79137_p0.read()) * sc_bigint<5>(mul_ln1118_1906_fu_79137_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1907_fu_79169_p0() {
    mul_ln1118_1907_fu_79169_p0 =  (sc_lv<3>) (sext_ln1116_107_fu_25631_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1907_fu_79169_p1() {
    mul_ln1118_1907_fu_79169_p1 = tmp_1907_fu_79155_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1907_fu_79169_p2() {
    mul_ln1118_1907_fu_79169_p2 = (!mul_ln1118_1907_fu_79169_p0.read().is_01() || !mul_ln1118_1907_fu_79169_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1907_fu_79169_p0.read()) * sc_bigint<5>(mul_ln1118_1907_fu_79169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1908_fu_79201_p0() {
    mul_ln1118_1908_fu_79201_p0 =  (sc_lv<3>) (sext_ln1116_108_fu_25675_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1908_fu_79201_p1() {
    mul_ln1118_1908_fu_79201_p1 = tmp_1908_fu_79187_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1908_fu_79201_p2() {
    mul_ln1118_1908_fu_79201_p2 = (!mul_ln1118_1908_fu_79201_p0.read().is_01() || !mul_ln1118_1908_fu_79201_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1908_fu_79201_p0.read()) * sc_bigint<5>(mul_ln1118_1908_fu_79201_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1909_fu_79221_p0() {
    mul_ln1118_1909_fu_79221_p0 =  (sc_lv<3>) (sext_ln1116_109_fu_25719_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1909_fu_79221_p1() {
    mul_ln1118_1909_fu_79221_p1 = tmp_1909_fu_79207_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1909_fu_79221_p2() {
    mul_ln1118_1909_fu_79221_p2 = (!mul_ln1118_1909_fu_79221_p0.read().is_01() || !mul_ln1118_1909_fu_79221_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1909_fu_79221_p0.read()) * sc_bigint<5>(mul_ln1118_1909_fu_79221_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_190_fu_83292_p0() {
    mul_ln1118_190_fu_83292_p0 =  (sc_lv<3>) (sext_ln1116_190_reg_106488.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_190_fu_83292_p1() {
    mul_ln1118_190_fu_83292_p1 = tmp_190_reg_106483.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_190_fu_83292_p2() {
    mul_ln1118_190_fu_83292_p2 = (!mul_ln1118_190_fu_83292_p0.read().is_01() || !mul_ln1118_190_fu_83292_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_190_fu_83292_p0.read()) * sc_bigint<5>(mul_ln1118_190_fu_83292_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1910_fu_79253_p0() {
    mul_ln1118_1910_fu_79253_p0 =  (sc_lv<3>) (sext_ln1116_110_fu_25751_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1910_fu_79253_p1() {
    mul_ln1118_1910_fu_79253_p1 = tmp_1910_fu_79239_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1910_fu_79253_p2() {
    mul_ln1118_1910_fu_79253_p2 = (!mul_ln1118_1910_fu_79253_p0.read().is_01() || !mul_ln1118_1910_fu_79253_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1910_fu_79253_p0.read()) * sc_bigint<5>(mul_ln1118_1910_fu_79253_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1911_fu_79285_p0() {
    mul_ln1118_1911_fu_79285_p0 =  (sc_lv<3>) (sext_ln1116_111_fu_25795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1911_fu_79285_p1() {
    mul_ln1118_1911_fu_79285_p1 = tmp_1911_fu_79271_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1911_fu_79285_p2() {
    mul_ln1118_1911_fu_79285_p2 = (!mul_ln1118_1911_fu_79285_p0.read().is_01() || !mul_ln1118_1911_fu_79285_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1911_fu_79285_p0.read()) * sc_bigint<5>(mul_ln1118_1911_fu_79285_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1912_fu_79305_p0() {
    mul_ln1118_1912_fu_79305_p0 =  (sc_lv<3>) (sext_ln1116_112_fu_25839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1912_fu_79305_p1() {
    mul_ln1118_1912_fu_79305_p1 = tmp_1912_fu_79291_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1912_fu_79305_p2() {
    mul_ln1118_1912_fu_79305_p2 = (!mul_ln1118_1912_fu_79305_p0.read().is_01() || !mul_ln1118_1912_fu_79305_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1912_fu_79305_p0.read()) * sc_bigint<5>(mul_ln1118_1912_fu_79305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1913_fu_79337_p0() {
    mul_ln1118_1913_fu_79337_p0 =  (sc_lv<3>) (sext_ln1116_113_fu_25871_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1913_fu_79337_p1() {
    mul_ln1118_1913_fu_79337_p1 = tmp_1913_fu_79323_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1913_fu_79337_p2() {
    mul_ln1118_1913_fu_79337_p2 = (!mul_ln1118_1913_fu_79337_p0.read().is_01() || !mul_ln1118_1913_fu_79337_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1913_fu_79337_p0.read()) * sc_bigint<5>(mul_ln1118_1913_fu_79337_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1914_fu_79369_p0() {
    mul_ln1118_1914_fu_79369_p0 =  (sc_lv<3>) (sext_ln1116_114_fu_25915_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1914_fu_79369_p1() {
    mul_ln1118_1914_fu_79369_p1 = tmp_1914_fu_79355_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1914_fu_79369_p2() {
    mul_ln1118_1914_fu_79369_p2 = (!mul_ln1118_1914_fu_79369_p0.read().is_01() || !mul_ln1118_1914_fu_79369_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1914_fu_79369_p0.read()) * sc_bigint<5>(mul_ln1118_1914_fu_79369_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1915_fu_79389_p0() {
    mul_ln1118_1915_fu_79389_p0 = select_ln76_106_fu_25941_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1915_fu_79389_p1() {
    mul_ln1118_1915_fu_79389_p1 = tmp_1915_fu_79375_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1915_fu_79389_p2() {
    mul_ln1118_1915_fu_79389_p2 = (!mul_ln1118_1915_fu_79389_p0.read().is_01() || !mul_ln1118_1915_fu_79389_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1915_fu_79389_p0.read()) * sc_bigint<5>(mul_ln1118_1915_fu_79389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1916_fu_79421_p0() {
    mul_ln1118_1916_fu_79421_p0 =  (sc_lv<3>) (sext_ln1116_116_fu_25981_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1916_fu_79421_p1() {
    mul_ln1118_1916_fu_79421_p1 = tmp_1916_fu_79407_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1916_fu_79421_p2() {
    mul_ln1118_1916_fu_79421_p2 = (!mul_ln1118_1916_fu_79421_p0.read().is_01() || !mul_ln1118_1916_fu_79421_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1916_fu_79421_p0.read()) * sc_bigint<5>(mul_ln1118_1916_fu_79421_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1917_fu_79453_p0() {
    mul_ln1118_1917_fu_79453_p0 =  (sc_lv<3>) (sext_ln1116_117_fu_26025_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1917_fu_79453_p1() {
    mul_ln1118_1917_fu_79453_p1 = tmp_1917_fu_79439_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1917_fu_79453_p2() {
    mul_ln1118_1917_fu_79453_p2 = (!mul_ln1118_1917_fu_79453_p0.read().is_01() || !mul_ln1118_1917_fu_79453_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1917_fu_79453_p0.read()) * sc_bigint<5>(mul_ln1118_1917_fu_79453_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1918_fu_79473_p0() {
    mul_ln1118_1918_fu_79473_p0 = select_ln76_109_fu_26051_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1918_fu_79473_p1() {
    mul_ln1118_1918_fu_79473_p1 = tmp_1918_fu_79459_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1918_fu_79473_p2() {
    mul_ln1118_1918_fu_79473_p2 = (!mul_ln1118_1918_fu_79473_p0.read().is_01() || !mul_ln1118_1918_fu_79473_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1918_fu_79473_p0.read()) * sc_bigint<5>(mul_ln1118_1918_fu_79473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1919_fu_79505_p0() {
    mul_ln1118_1919_fu_79505_p0 =  (sc_lv<3>) (sext_ln1116_119_fu_26091_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1919_fu_79505_p1() {
    mul_ln1118_1919_fu_79505_p1 = tmp_1919_fu_79491_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1919_fu_79505_p2() {
    mul_ln1118_1919_fu_79505_p2 = (!mul_ln1118_1919_fu_79505_p0.read().is_01() || !mul_ln1118_1919_fu_79505_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1919_fu_79505_p0.read()) * sc_bigint<5>(mul_ln1118_1919_fu_79505_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_191_fu_28907_p0() {
    mul_ln1118_191_fu_28907_p0 =  (sc_lv<3>) (sext_ln1116_191_fu_28899_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_191_fu_28907_p1() {
    mul_ln1118_191_fu_28907_p1 = tmp_191_fu_28889_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_191_fu_28907_p2() {
    mul_ln1118_191_fu_28907_p2 = (!mul_ln1118_191_fu_28907_p0.read().is_01() || !mul_ln1118_191_fu_28907_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_191_fu_28907_p0.read()) * sc_bigint<5>(mul_ln1118_191_fu_28907_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1920_fu_79537_p0() {
    mul_ln1118_1920_fu_79537_p0 =  (sc_lv<3>) (sext_ln1116_120_fu_26135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1920_fu_79537_p1() {
    mul_ln1118_1920_fu_79537_p1 = tmp_1920_fu_79523_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1920_fu_79537_p2() {
    mul_ln1118_1920_fu_79537_p2 = (!mul_ln1118_1920_fu_79537_p0.read().is_01() || !mul_ln1118_1920_fu_79537_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1920_fu_79537_p0.read()) * sc_bigint<5>(mul_ln1118_1920_fu_79537_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1921_fu_79557_p0() {
    mul_ln1118_1921_fu_79557_p0 = select_ln76_112_fu_26161_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1921_fu_79557_p1() {
    mul_ln1118_1921_fu_79557_p1 = tmp_1921_fu_79543_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1921_fu_79557_p2() {
    mul_ln1118_1921_fu_79557_p2 = (!mul_ln1118_1921_fu_79557_p0.read().is_01() || !mul_ln1118_1921_fu_79557_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1921_fu_79557_p0.read()) * sc_bigint<5>(mul_ln1118_1921_fu_79557_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1922_fu_79589_p0() {
    mul_ln1118_1922_fu_79589_p0 =  (sc_lv<3>) (sext_ln1116_122_fu_26201_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1922_fu_79589_p1() {
    mul_ln1118_1922_fu_79589_p1 = tmp_1922_fu_79575_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1922_fu_79589_p2() {
    mul_ln1118_1922_fu_79589_p2 = (!mul_ln1118_1922_fu_79589_p0.read().is_01() || !mul_ln1118_1922_fu_79589_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1922_fu_79589_p0.read()) * sc_bigint<5>(mul_ln1118_1922_fu_79589_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1923_fu_79621_p0() {
    mul_ln1118_1923_fu_79621_p0 =  (sc_lv<3>) (sext_ln1116_123_fu_26245_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1923_fu_79621_p1() {
    mul_ln1118_1923_fu_79621_p1 = tmp_1923_fu_79607_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1923_fu_79621_p2() {
    mul_ln1118_1923_fu_79621_p2 = (!mul_ln1118_1923_fu_79621_p0.read().is_01() || !mul_ln1118_1923_fu_79621_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1923_fu_79621_p0.read()) * sc_bigint<5>(mul_ln1118_1923_fu_79621_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1924_fu_79641_p0() {
    mul_ln1118_1924_fu_79641_p0 = select_ln76_115_fu_26271_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1924_fu_79641_p1() {
    mul_ln1118_1924_fu_79641_p1 = tmp_1924_fu_79627_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1924_fu_79641_p2() {
    mul_ln1118_1924_fu_79641_p2 = (!mul_ln1118_1924_fu_79641_p0.read().is_01() || !mul_ln1118_1924_fu_79641_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1924_fu_79641_p0.read()) * sc_bigint<5>(mul_ln1118_1924_fu_79641_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1925_fu_79673_p0() {
    mul_ln1118_1925_fu_79673_p0 =  (sc_lv<3>) (sext_ln1116_125_fu_26311_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1925_fu_79673_p1() {
    mul_ln1118_1925_fu_79673_p1 = tmp_1925_fu_79659_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1925_fu_79673_p2() {
    mul_ln1118_1925_fu_79673_p2 = (!mul_ln1118_1925_fu_79673_p0.read().is_01() || !mul_ln1118_1925_fu_79673_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1925_fu_79673_p0.read()) * sc_bigint<5>(mul_ln1118_1925_fu_79673_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1926_fu_79705_p0() {
    mul_ln1118_1926_fu_79705_p0 =  (sc_lv<3>) (sext_ln1116_126_fu_26355_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1926_fu_79705_p1() {
    mul_ln1118_1926_fu_79705_p1 = tmp_1926_fu_79691_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1926_fu_79705_p2() {
    mul_ln1118_1926_fu_79705_p2 = (!mul_ln1118_1926_fu_79705_p0.read().is_01() || !mul_ln1118_1926_fu_79705_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1926_fu_79705_p0.read()) * sc_bigint<5>(mul_ln1118_1926_fu_79705_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1927_fu_79725_p0() {
    mul_ln1118_1927_fu_79725_p0 = select_ln76_118_fu_26381_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1927_fu_79725_p1() {
    mul_ln1118_1927_fu_79725_p1 = tmp_1927_fu_79711_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1927_fu_79725_p2() {
    mul_ln1118_1927_fu_79725_p2 = (!mul_ln1118_1927_fu_79725_p0.read().is_01() || !mul_ln1118_1927_fu_79725_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1927_fu_79725_p0.read()) * sc_bigint<5>(mul_ln1118_1927_fu_79725_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1928_fu_79757_p0() {
    mul_ln1118_1928_fu_79757_p0 =  (sc_lv<3>) (sext_ln1116_128_fu_26421_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1928_fu_79757_p1() {
    mul_ln1118_1928_fu_79757_p1 = tmp_1928_fu_79743_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1928_fu_79757_p2() {
    mul_ln1118_1928_fu_79757_p2 = (!mul_ln1118_1928_fu_79757_p0.read().is_01() || !mul_ln1118_1928_fu_79757_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1928_fu_79757_p0.read()) * sc_bigint<5>(mul_ln1118_1928_fu_79757_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1929_fu_79789_p0() {
    mul_ln1118_1929_fu_79789_p0 =  (sc_lv<3>) (sext_ln1116_129_fu_26465_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1929_fu_79789_p1() {
    mul_ln1118_1929_fu_79789_p1 = tmp_1929_fu_79775_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1929_fu_79789_p2() {
    mul_ln1118_1929_fu_79789_p2 = (!mul_ln1118_1929_fu_79789_p0.read().is_01() || !mul_ln1118_1929_fu_79789_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1929_fu_79789_p0.read()) * sc_bigint<5>(mul_ln1118_1929_fu_79789_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_192_fu_28951_p0() {
    mul_ln1118_192_fu_28951_p0 =  (sc_lv<3>) (sext_ln1116_192_fu_28943_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_192_fu_28951_p1() {
    mul_ln1118_192_fu_28951_p1 = tmp_192_fu_28933_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_192_fu_28951_p2() {
    mul_ln1118_192_fu_28951_p2 = (!mul_ln1118_192_fu_28951_p0.read().is_01() || !mul_ln1118_192_fu_28951_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_192_fu_28951_p0.read()) * sc_bigint<5>(mul_ln1118_192_fu_28951_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1930_fu_79809_p0() {
    mul_ln1118_1930_fu_79809_p0 =  (sc_lv<3>) (sext_ln1116_130_fu_26509_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1930_fu_79809_p1() {
    mul_ln1118_1930_fu_79809_p1 = tmp_1930_fu_79795_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1930_fu_79809_p2() {
    mul_ln1118_1930_fu_79809_p2 = (!mul_ln1118_1930_fu_79809_p0.read().is_01() || !mul_ln1118_1930_fu_79809_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1930_fu_79809_p0.read()) * sc_bigint<5>(mul_ln1118_1930_fu_79809_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1931_fu_79841_p0() {
    mul_ln1118_1931_fu_79841_p0 =  (sc_lv<3>) (sext_ln1116_131_fu_26553_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1931_fu_79841_p1() {
    mul_ln1118_1931_fu_79841_p1 = tmp_1931_fu_79827_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1931_fu_79841_p2() {
    mul_ln1118_1931_fu_79841_p2 = (!mul_ln1118_1931_fu_79841_p0.read().is_01() || !mul_ln1118_1931_fu_79841_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1931_fu_79841_p0.read()) * sc_bigint<5>(mul_ln1118_1931_fu_79841_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1932_fu_79873_p0() {
    mul_ln1118_1932_fu_79873_p0 =  (sc_lv<3>) (sext_ln1116_132_fu_26597_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1932_fu_79873_p1() {
    mul_ln1118_1932_fu_79873_p1 = tmp_1932_fu_79859_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1932_fu_79873_p2() {
    mul_ln1118_1932_fu_79873_p2 = (!mul_ln1118_1932_fu_79873_p0.read().is_01() || !mul_ln1118_1932_fu_79873_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1932_fu_79873_p0.read()) * sc_bigint<5>(mul_ln1118_1932_fu_79873_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1933_fu_79893_p0() {
    mul_ln1118_1933_fu_79893_p0 =  (sc_lv<3>) (sext_ln1116_133_fu_26641_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1933_fu_79893_p1() {
    mul_ln1118_1933_fu_79893_p1 = tmp_1933_fu_79879_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1933_fu_79893_p2() {
    mul_ln1118_1933_fu_79893_p2 = (!mul_ln1118_1933_fu_79893_p0.read().is_01() || !mul_ln1118_1933_fu_79893_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1933_fu_79893_p0.read()) * sc_bigint<5>(mul_ln1118_1933_fu_79893_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1934_fu_79925_p0() {
    mul_ln1118_1934_fu_79925_p0 =  (sc_lv<3>) (sext_ln1116_134_fu_26685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1934_fu_79925_p1() {
    mul_ln1118_1934_fu_79925_p1 = tmp_1934_fu_79911_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1934_fu_79925_p2() {
    mul_ln1118_1934_fu_79925_p2 = (!mul_ln1118_1934_fu_79925_p0.read().is_01() || !mul_ln1118_1934_fu_79925_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1934_fu_79925_p0.read()) * sc_bigint<5>(mul_ln1118_1934_fu_79925_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1935_fu_79957_p0() {
    mul_ln1118_1935_fu_79957_p0 =  (sc_lv<3>) (sext_ln1116_135_fu_26717_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1935_fu_79957_p1() {
    mul_ln1118_1935_fu_79957_p1 = tmp_1935_fu_79943_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1935_fu_79957_p2() {
    mul_ln1118_1935_fu_79957_p2 = (!mul_ln1118_1935_fu_79957_p0.read().is_01() || !mul_ln1118_1935_fu_79957_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1935_fu_79957_p0.read()) * sc_bigint<5>(mul_ln1118_1935_fu_79957_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1936_fu_79977_p0() {
    mul_ln1118_1936_fu_79977_p0 =  (sc_lv<3>) (sext_ln1116_136_fu_26761_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1936_fu_79977_p1() {
    mul_ln1118_1936_fu_79977_p1 = tmp_1936_fu_79963_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1936_fu_79977_p2() {
    mul_ln1118_1936_fu_79977_p2 = (!mul_ln1118_1936_fu_79977_p0.read().is_01() || !mul_ln1118_1936_fu_79977_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1936_fu_79977_p0.read()) * sc_bigint<5>(mul_ln1118_1936_fu_79977_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1937_fu_80009_p0() {
    mul_ln1118_1937_fu_80009_p0 =  (sc_lv<3>) (sext_ln1116_137_fu_26805_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1937_fu_80009_p1() {
    mul_ln1118_1937_fu_80009_p1 = tmp_1937_fu_79995_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1937_fu_80009_p2() {
    mul_ln1118_1937_fu_80009_p2 = (!mul_ln1118_1937_fu_80009_p0.read().is_01() || !mul_ln1118_1937_fu_80009_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1937_fu_80009_p0.read()) * sc_bigint<5>(mul_ln1118_1937_fu_80009_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1938_fu_80041_p0() {
    mul_ln1118_1938_fu_80041_p0 =  (sc_lv<3>) (sext_ln1116_138_fu_26837_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1938_fu_80041_p1() {
    mul_ln1118_1938_fu_80041_p1 = tmp_1938_fu_80027_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1938_fu_80041_p2() {
    mul_ln1118_1938_fu_80041_p2 = (!mul_ln1118_1938_fu_80041_p0.read().is_01() || !mul_ln1118_1938_fu_80041_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1938_fu_80041_p0.read()) * sc_bigint<5>(mul_ln1118_1938_fu_80041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1939_fu_80061_p0() {
    mul_ln1118_1939_fu_80061_p0 =  (sc_lv<3>) (sext_ln1116_139_fu_26881_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1939_fu_80061_p1() {
    mul_ln1118_1939_fu_80061_p1 = tmp_1939_fu_80047_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1939_fu_80061_p2() {
    mul_ln1118_1939_fu_80061_p2 = (!mul_ln1118_1939_fu_80061_p0.read().is_01() || !mul_ln1118_1939_fu_80061_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1939_fu_80061_p0.read()) * sc_bigint<5>(mul_ln1118_1939_fu_80061_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_193_fu_83312_p0() {
    mul_ln1118_193_fu_83312_p0 =  (sc_lv<3>) (sext_ln1116_193_reg_106506.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_193_fu_83312_p1() {
    mul_ln1118_193_fu_83312_p1 = tmp_193_reg_106501.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_193_fu_83312_p2() {
    mul_ln1118_193_fu_83312_p2 = (!mul_ln1118_193_fu_83312_p0.read().is_01() || !mul_ln1118_193_fu_83312_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_193_fu_83312_p0.read()) * sc_bigint<5>(mul_ln1118_193_fu_83312_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1940_fu_80093_p0() {
    mul_ln1118_1940_fu_80093_p0 = select_ln76_131_fu_26907_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1940_fu_80093_p1() {
    mul_ln1118_1940_fu_80093_p1 = tmp_1940_fu_80079_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1940_fu_80093_p2() {
    mul_ln1118_1940_fu_80093_p2 = (!mul_ln1118_1940_fu_80093_p0.read().is_01() || !mul_ln1118_1940_fu_80093_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1940_fu_80093_p0.read()) * sc_bigint<5>(mul_ln1118_1940_fu_80093_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1941_fu_80125_p0() {
    mul_ln1118_1941_fu_80125_p0 =  (sc_lv<3>) (sext_ln1116_141_fu_26947_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1941_fu_80125_p1() {
    mul_ln1118_1941_fu_80125_p1 = tmp_1941_fu_80111_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1941_fu_80125_p2() {
    mul_ln1118_1941_fu_80125_p2 = (!mul_ln1118_1941_fu_80125_p0.read().is_01() || !mul_ln1118_1941_fu_80125_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1941_fu_80125_p0.read()) * sc_bigint<5>(mul_ln1118_1941_fu_80125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1942_fu_80145_p0() {
    mul_ln1118_1942_fu_80145_p0 =  (sc_lv<3>) (sext_ln1116_142_fu_26991_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1942_fu_80145_p1() {
    mul_ln1118_1942_fu_80145_p1 = tmp_1942_fu_80131_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1942_fu_80145_p2() {
    mul_ln1118_1942_fu_80145_p2 = (!mul_ln1118_1942_fu_80145_p0.read().is_01() || !mul_ln1118_1942_fu_80145_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1942_fu_80145_p0.read()) * sc_bigint<5>(mul_ln1118_1942_fu_80145_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1943_fu_80177_p0() {
    mul_ln1118_1943_fu_80177_p0 = select_ln76_134_fu_27017_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1943_fu_80177_p1() {
    mul_ln1118_1943_fu_80177_p1 = tmp_1943_fu_80163_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1943_fu_80177_p2() {
    mul_ln1118_1943_fu_80177_p2 = (!mul_ln1118_1943_fu_80177_p0.read().is_01() || !mul_ln1118_1943_fu_80177_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1943_fu_80177_p0.read()) * sc_bigint<5>(mul_ln1118_1943_fu_80177_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1944_fu_80209_p0() {
    mul_ln1118_1944_fu_80209_p0 =  (sc_lv<3>) (sext_ln1116_144_fu_27057_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1944_fu_80209_p1() {
    mul_ln1118_1944_fu_80209_p1 = tmp_1944_fu_80195_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1944_fu_80209_p2() {
    mul_ln1118_1944_fu_80209_p2 = (!mul_ln1118_1944_fu_80209_p0.read().is_01() || !mul_ln1118_1944_fu_80209_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1944_fu_80209_p0.read()) * sc_bigint<5>(mul_ln1118_1944_fu_80209_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1945_fu_80229_p0() {
    mul_ln1118_1945_fu_80229_p0 =  (sc_lv<3>) (sext_ln1116_145_fu_27101_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1945_fu_80229_p1() {
    mul_ln1118_1945_fu_80229_p1 = tmp_1945_fu_80215_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1945_fu_80229_p2() {
    mul_ln1118_1945_fu_80229_p2 = (!mul_ln1118_1945_fu_80229_p0.read().is_01() || !mul_ln1118_1945_fu_80229_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1945_fu_80229_p0.read()) * sc_bigint<5>(mul_ln1118_1945_fu_80229_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1946_fu_80261_p0() {
    mul_ln1118_1946_fu_80261_p0 =  (sc_lv<3>) (sext_ln1116_146_fu_27145_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1946_fu_80261_p1() {
    mul_ln1118_1946_fu_80261_p1 = tmp_1946_fu_80247_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1946_fu_80261_p2() {
    mul_ln1118_1946_fu_80261_p2 = (!mul_ln1118_1946_fu_80261_p0.read().is_01() || !mul_ln1118_1946_fu_80261_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1946_fu_80261_p0.read()) * sc_bigint<5>(mul_ln1118_1946_fu_80261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1947_fu_80293_p0() {
    mul_ln1118_1947_fu_80293_p0 =  (sc_lv<3>) (sext_ln1116_147_fu_27177_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1947_fu_80293_p1() {
    mul_ln1118_1947_fu_80293_p1 = tmp_1947_fu_80279_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1947_fu_80293_p2() {
    mul_ln1118_1947_fu_80293_p2 = (!mul_ln1118_1947_fu_80293_p0.read().is_01() || !mul_ln1118_1947_fu_80293_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1947_fu_80293_p0.read()) * sc_bigint<5>(mul_ln1118_1947_fu_80293_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1948_fu_80313_p0() {
    mul_ln1118_1948_fu_80313_p0 =  (sc_lv<3>) (sext_ln1116_148_fu_27221_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1948_fu_80313_p1() {
    mul_ln1118_1948_fu_80313_p1 = tmp_1948_fu_80299_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1948_fu_80313_p2() {
    mul_ln1118_1948_fu_80313_p2 = (!mul_ln1118_1948_fu_80313_p0.read().is_01() || !mul_ln1118_1948_fu_80313_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1948_fu_80313_p0.read()) * sc_bigint<5>(mul_ln1118_1948_fu_80313_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1949_fu_80345_p0() {
    mul_ln1118_1949_fu_80345_p0 =  (sc_lv<3>) (sext_ln1116_149_fu_27265_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1949_fu_80345_p1() {
    mul_ln1118_1949_fu_80345_p1 = tmp_1949_fu_80331_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1949_fu_80345_p2() {
    mul_ln1118_1949_fu_80345_p2 = (!mul_ln1118_1949_fu_80345_p0.read().is_01() || !mul_ln1118_1949_fu_80345_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1949_fu_80345_p0.read()) * sc_bigint<5>(mul_ln1118_1949_fu_80345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_194_fu_29017_p0() {
    mul_ln1118_194_fu_29017_p0 =  (sc_lv<3>) (sext_ln1116_194_fu_29009_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_194_fu_29017_p1() {
    mul_ln1118_194_fu_29017_p1 = tmp_194_fu_28999_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_194_fu_29017_p2() {
    mul_ln1118_194_fu_29017_p2 = (!mul_ln1118_194_fu_29017_p0.read().is_01() || !mul_ln1118_194_fu_29017_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_194_fu_29017_p0.read()) * sc_bigint<5>(mul_ln1118_194_fu_29017_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1950_fu_80377_p0() {
    mul_ln1118_1950_fu_80377_p0 =  (sc_lv<3>) (sext_ln1116_150_fu_27297_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1950_fu_80377_p1() {
    mul_ln1118_1950_fu_80377_p1 = tmp_1950_fu_80363_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1950_fu_80377_p2() {
    mul_ln1118_1950_fu_80377_p2 = (!mul_ln1118_1950_fu_80377_p0.read().is_01() || !mul_ln1118_1950_fu_80377_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1950_fu_80377_p0.read()) * sc_bigint<5>(mul_ln1118_1950_fu_80377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1951_fu_80397_p0() {
    mul_ln1118_1951_fu_80397_p0 =  (sc_lv<3>) (sext_ln1116_151_fu_27341_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1951_fu_80397_p1() {
    mul_ln1118_1951_fu_80397_p1 = tmp_1951_fu_80383_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1951_fu_80397_p2() {
    mul_ln1118_1951_fu_80397_p2 = (!mul_ln1118_1951_fu_80397_p0.read().is_01() || !mul_ln1118_1951_fu_80397_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1951_fu_80397_p0.read()) * sc_bigint<5>(mul_ln1118_1951_fu_80397_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1952_fu_80429_p0() {
    mul_ln1118_1952_fu_80429_p0 = select_ln76_143_fu_27367_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1952_fu_80429_p1() {
    mul_ln1118_1952_fu_80429_p1 = tmp_1952_fu_80415_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1952_fu_80429_p2() {
    mul_ln1118_1952_fu_80429_p2 = (!mul_ln1118_1952_fu_80429_p0.read().is_01() || !mul_ln1118_1952_fu_80429_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1952_fu_80429_p0.read()) * sc_bigint<5>(mul_ln1118_1952_fu_80429_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1953_fu_80461_p0() {
    mul_ln1118_1953_fu_80461_p0 =  (sc_lv<3>) (sext_ln1116_153_fu_27407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1953_fu_80461_p1() {
    mul_ln1118_1953_fu_80461_p1 = tmp_1953_fu_80447_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1953_fu_80461_p2() {
    mul_ln1118_1953_fu_80461_p2 = (!mul_ln1118_1953_fu_80461_p0.read().is_01() || !mul_ln1118_1953_fu_80461_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1953_fu_80461_p0.read()) * sc_bigint<5>(mul_ln1118_1953_fu_80461_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1954_fu_80493_p0() {
    mul_ln1118_1954_fu_80493_p0 =  (sc_lv<3>) (sext_ln1116_154_fu_27451_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1954_fu_80493_p1() {
    mul_ln1118_1954_fu_80493_p1 = tmp_1954_fu_80479_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1954_fu_80493_p2() {
    mul_ln1118_1954_fu_80493_p2 = (!mul_ln1118_1954_fu_80493_p0.read().is_01() || !mul_ln1118_1954_fu_80493_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1954_fu_80493_p0.read()) * sc_bigint<5>(mul_ln1118_1954_fu_80493_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1955_fu_80525_p0() {
    mul_ln1118_1955_fu_80525_p0 =  (sc_lv<3>) (sext_ln1116_155_fu_27495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1955_fu_80525_p1() {
    mul_ln1118_1955_fu_80525_p1 = tmp_1955_fu_80511_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1955_fu_80525_p2() {
    mul_ln1118_1955_fu_80525_p2 = (!mul_ln1118_1955_fu_80525_p0.read().is_01() || !mul_ln1118_1955_fu_80525_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1955_fu_80525_p0.read()) * sc_bigint<5>(mul_ln1118_1955_fu_80525_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1956_fu_80557_p0() {
    mul_ln1118_1956_fu_80557_p0 =  (sc_lv<3>) (sext_ln1116_156_fu_27539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1956_fu_80557_p1() {
    mul_ln1118_1956_fu_80557_p1 = tmp_1956_fu_80543_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1956_fu_80557_p2() {
    mul_ln1118_1956_fu_80557_p2 = (!mul_ln1118_1956_fu_80557_p0.read().is_01() || !mul_ln1118_1956_fu_80557_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1956_fu_80557_p0.read()) * sc_bigint<5>(mul_ln1118_1956_fu_80557_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1957_fu_80589_p0() {
    mul_ln1118_1957_fu_80589_p0 =  (sc_lv<3>) (sext_ln1116_157_fu_27583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1957_fu_80589_p1() {
    mul_ln1118_1957_fu_80589_p1 = tmp_1957_fu_80575_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1957_fu_80589_p2() {
    mul_ln1118_1957_fu_80589_p2 = (!mul_ln1118_1957_fu_80589_p0.read().is_01() || !mul_ln1118_1957_fu_80589_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1957_fu_80589_p0.read()) * sc_bigint<5>(mul_ln1118_1957_fu_80589_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1958_fu_80609_p0() {
    mul_ln1118_1958_fu_80609_p0 =  (sc_lv<3>) (sext_ln1116_158_fu_27627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1958_fu_80609_p1() {
    mul_ln1118_1958_fu_80609_p1 = tmp_1958_fu_80595_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1958_fu_80609_p2() {
    mul_ln1118_1958_fu_80609_p2 = (!mul_ln1118_1958_fu_80609_p0.read().is_01() || !mul_ln1118_1958_fu_80609_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1958_fu_80609_p0.read()) * sc_bigint<5>(mul_ln1118_1958_fu_80609_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1959_fu_80641_p0() {
    mul_ln1118_1959_fu_80641_p0 =  (sc_lv<3>) (sext_ln1116_159_fu_27671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1959_fu_80641_p1() {
    mul_ln1118_1959_fu_80641_p1 = tmp_1959_fu_80627_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1959_fu_80641_p2() {
    mul_ln1118_1959_fu_80641_p2 = (!mul_ln1118_1959_fu_80641_p0.read().is_01() || !mul_ln1118_1959_fu_80641_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1959_fu_80641_p0.read()) * sc_bigint<5>(mul_ln1118_1959_fu_80641_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_195_fu_29061_p0() {
    mul_ln1118_195_fu_29061_p0 =  (sc_lv<3>) (sext_ln1116_195_fu_29053_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_195_fu_29061_p1() {
    mul_ln1118_195_fu_29061_p1 = tmp_195_fu_29043_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_195_fu_29061_p2() {
    mul_ln1118_195_fu_29061_p2 = (!mul_ln1118_195_fu_29061_p0.read().is_01() || !mul_ln1118_195_fu_29061_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_195_fu_29061_p0.read()) * sc_bigint<5>(mul_ln1118_195_fu_29061_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1960_fu_80673_p0() {
    mul_ln1118_1960_fu_80673_p0 =  (sc_lv<3>) (sext_ln1116_160_fu_27703_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1960_fu_80673_p1() {
    mul_ln1118_1960_fu_80673_p1 = tmp_1960_fu_80659_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1960_fu_80673_p2() {
    mul_ln1118_1960_fu_80673_p2 = (!mul_ln1118_1960_fu_80673_p0.read().is_01() || !mul_ln1118_1960_fu_80673_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1960_fu_80673_p0.read()) * sc_bigint<5>(mul_ln1118_1960_fu_80673_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1961_fu_80693_p0() {
    mul_ln1118_1961_fu_80693_p0 =  (sc_lv<3>) (sext_ln1116_161_fu_27747_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1961_fu_80693_p1() {
    mul_ln1118_1961_fu_80693_p1 = tmp_1961_fu_80679_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1961_fu_80693_p2() {
    mul_ln1118_1961_fu_80693_p2 = (!mul_ln1118_1961_fu_80693_p0.read().is_01() || !mul_ln1118_1961_fu_80693_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1961_fu_80693_p0.read()) * sc_bigint<5>(mul_ln1118_1961_fu_80693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1962_fu_80725_p0() {
    mul_ln1118_1962_fu_80725_p0 =  (sc_lv<3>) (sext_ln1116_162_fu_27791_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1962_fu_80725_p1() {
    mul_ln1118_1962_fu_80725_p1 = tmp_1962_fu_80711_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1962_fu_80725_p2() {
    mul_ln1118_1962_fu_80725_p2 = (!mul_ln1118_1962_fu_80725_p0.read().is_01() || !mul_ln1118_1962_fu_80725_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1962_fu_80725_p0.read()) * sc_bigint<5>(mul_ln1118_1962_fu_80725_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1963_fu_80757_p0() {
    mul_ln1118_1963_fu_80757_p0 =  (sc_lv<3>) (sext_ln1116_163_fu_27823_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1963_fu_80757_p1() {
    mul_ln1118_1963_fu_80757_p1 = tmp_1963_fu_80743_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1963_fu_80757_p2() {
    mul_ln1118_1963_fu_80757_p2 = (!mul_ln1118_1963_fu_80757_p0.read().is_01() || !mul_ln1118_1963_fu_80757_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1963_fu_80757_p0.read()) * sc_bigint<5>(mul_ln1118_1963_fu_80757_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1964_fu_80777_p0() {
    mul_ln1118_1964_fu_80777_p0 =  (sc_lv<3>) (sext_ln1116_164_fu_27867_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1964_fu_80777_p1() {
    mul_ln1118_1964_fu_80777_p1 = tmp_1964_fu_80763_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1964_fu_80777_p2() {
    mul_ln1118_1964_fu_80777_p2 = (!mul_ln1118_1964_fu_80777_p0.read().is_01() || !mul_ln1118_1964_fu_80777_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1964_fu_80777_p0.read()) * sc_bigint<5>(mul_ln1118_1964_fu_80777_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1965_fu_80809_p0() {
    mul_ln1118_1965_fu_80809_p0 = select_ln76_156_fu_27893_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1965_fu_80809_p1() {
    mul_ln1118_1965_fu_80809_p1 = tmp_1965_fu_80795_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1965_fu_80809_p2() {
    mul_ln1118_1965_fu_80809_p2 = (!mul_ln1118_1965_fu_80809_p0.read().is_01() || !mul_ln1118_1965_fu_80809_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1965_fu_80809_p0.read()) * sc_bigint<5>(mul_ln1118_1965_fu_80809_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1966_fu_80841_p0() {
    mul_ln1118_1966_fu_80841_p0 =  (sc_lv<3>) (sext_ln1116_166_fu_27933_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1966_fu_80841_p1() {
    mul_ln1118_1966_fu_80841_p1 = tmp_1966_fu_80827_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1966_fu_80841_p2() {
    mul_ln1118_1966_fu_80841_p2 = (!mul_ln1118_1966_fu_80841_p0.read().is_01() || !mul_ln1118_1966_fu_80841_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1966_fu_80841_p0.read()) * sc_bigint<5>(mul_ln1118_1966_fu_80841_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1967_fu_80861_p0() {
    mul_ln1118_1967_fu_80861_p0 =  (sc_lv<3>) (sext_ln1116_167_fu_27977_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1967_fu_80861_p1() {
    mul_ln1118_1967_fu_80861_p1 = tmp_1967_fu_80847_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1967_fu_80861_p2() {
    mul_ln1118_1967_fu_80861_p2 = (!mul_ln1118_1967_fu_80861_p0.read().is_01() || !mul_ln1118_1967_fu_80861_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1967_fu_80861_p0.read()) * sc_bigint<5>(mul_ln1118_1967_fu_80861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1968_fu_80893_p0() {
    mul_ln1118_1968_fu_80893_p0 = select_ln76_159_fu_28003_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1968_fu_80893_p1() {
    mul_ln1118_1968_fu_80893_p1 = tmp_1968_fu_80879_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1968_fu_80893_p2() {
    mul_ln1118_1968_fu_80893_p2 = (!mul_ln1118_1968_fu_80893_p0.read().is_01() || !mul_ln1118_1968_fu_80893_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1968_fu_80893_p0.read()) * sc_bigint<5>(mul_ln1118_1968_fu_80893_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1969_fu_80925_p0() {
    mul_ln1118_1969_fu_80925_p0 =  (sc_lv<3>) (sext_ln1116_169_fu_28043_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1969_fu_80925_p1() {
    mul_ln1118_1969_fu_80925_p1 = tmp_1969_fu_80911_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1969_fu_80925_p2() {
    mul_ln1118_1969_fu_80925_p2 = (!mul_ln1118_1969_fu_80925_p0.read().is_01() || !mul_ln1118_1969_fu_80925_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1969_fu_80925_p0.read()) * sc_bigint<5>(mul_ln1118_1969_fu_80925_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_196_fu_83332_p0() {
    mul_ln1118_196_fu_83332_p0 =  (sc_lv<3>) (sext_ln1116_196_reg_106524.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_196_fu_83332_p1() {
    mul_ln1118_196_fu_83332_p1 = tmp_196_reg_106519.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_196_fu_83332_p2() {
    mul_ln1118_196_fu_83332_p2 = (!mul_ln1118_196_fu_83332_p0.read().is_01() || !mul_ln1118_196_fu_83332_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_196_fu_83332_p0.read()) * sc_bigint<5>(mul_ln1118_196_fu_83332_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1970_fu_80945_p0() {
    mul_ln1118_1970_fu_80945_p0 =  (sc_lv<3>) (sext_ln1116_170_fu_28087_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1970_fu_80945_p1() {
    mul_ln1118_1970_fu_80945_p1 = tmp_1970_fu_80931_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1970_fu_80945_p2() {
    mul_ln1118_1970_fu_80945_p2 = (!mul_ln1118_1970_fu_80945_p0.read().is_01() || !mul_ln1118_1970_fu_80945_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1970_fu_80945_p0.read()) * sc_bigint<5>(mul_ln1118_1970_fu_80945_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1971_fu_80977_p0() {
    mul_ln1118_1971_fu_80977_p0 = select_ln76_162_fu_28113_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1971_fu_80977_p1() {
    mul_ln1118_1971_fu_80977_p1 = tmp_1971_fu_80963_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1971_fu_80977_p2() {
    mul_ln1118_1971_fu_80977_p2 = (!mul_ln1118_1971_fu_80977_p0.read().is_01() || !mul_ln1118_1971_fu_80977_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1971_fu_80977_p0.read()) * sc_bigint<5>(mul_ln1118_1971_fu_80977_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1972_fu_81009_p0() {
    mul_ln1118_1972_fu_81009_p0 =  (sc_lv<3>) (sext_ln1116_172_fu_28153_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1972_fu_81009_p1() {
    mul_ln1118_1972_fu_81009_p1 = tmp_1972_fu_80995_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1972_fu_81009_p2() {
    mul_ln1118_1972_fu_81009_p2 = (!mul_ln1118_1972_fu_81009_p0.read().is_01() || !mul_ln1118_1972_fu_81009_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1972_fu_81009_p0.read()) * sc_bigint<5>(mul_ln1118_1972_fu_81009_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1973_fu_81029_p0() {
    mul_ln1118_1973_fu_81029_p0 =  (sc_lv<3>) (sext_ln1116_173_fu_28197_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1973_fu_81029_p1() {
    mul_ln1118_1973_fu_81029_p1 = tmp_1973_fu_81015_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1973_fu_81029_p2() {
    mul_ln1118_1973_fu_81029_p2 = (!mul_ln1118_1973_fu_81029_p0.read().is_01() || !mul_ln1118_1973_fu_81029_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1973_fu_81029_p0.read()) * sc_bigint<5>(mul_ln1118_1973_fu_81029_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1974_fu_81061_p0() {
    mul_ln1118_1974_fu_81061_p0 = select_ln76_165_fu_28223_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1974_fu_81061_p1() {
    mul_ln1118_1974_fu_81061_p1 = tmp_1974_fu_81047_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1974_fu_81061_p2() {
    mul_ln1118_1974_fu_81061_p2 = (!mul_ln1118_1974_fu_81061_p0.read().is_01() || !mul_ln1118_1974_fu_81061_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1974_fu_81061_p0.read()) * sc_bigint<5>(mul_ln1118_1974_fu_81061_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1975_fu_81093_p0() {
    mul_ln1118_1975_fu_81093_p0 =  (sc_lv<3>) (sext_ln1116_175_fu_28263_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1975_fu_81093_p1() {
    mul_ln1118_1975_fu_81093_p1 = tmp_1975_fu_81079_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1975_fu_81093_p2() {
    mul_ln1118_1975_fu_81093_p2 = (!mul_ln1118_1975_fu_81093_p0.read().is_01() || !mul_ln1118_1975_fu_81093_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1975_fu_81093_p0.read()) * sc_bigint<5>(mul_ln1118_1975_fu_81093_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1976_fu_81113_p0() {
    mul_ln1118_1976_fu_81113_p0 =  (sc_lv<3>) (sext_ln1116_176_fu_28307_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1976_fu_81113_p1() {
    mul_ln1118_1976_fu_81113_p1 = tmp_1976_fu_81099_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1976_fu_81113_p2() {
    mul_ln1118_1976_fu_81113_p2 = (!mul_ln1118_1976_fu_81113_p0.read().is_01() || !mul_ln1118_1976_fu_81113_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1976_fu_81113_p0.read()) * sc_bigint<5>(mul_ln1118_1976_fu_81113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1977_fu_81145_p0() {
    mul_ln1118_1977_fu_81145_p0 = select_ln76_168_fu_28333_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1977_fu_81145_p1() {
    mul_ln1118_1977_fu_81145_p1 = tmp_1977_fu_81131_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1977_fu_81145_p2() {
    mul_ln1118_1977_fu_81145_p2 = (!mul_ln1118_1977_fu_81145_p0.read().is_01() || !mul_ln1118_1977_fu_81145_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1977_fu_81145_p0.read()) * sc_bigint<5>(mul_ln1118_1977_fu_81145_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1978_fu_81177_p0() {
    mul_ln1118_1978_fu_81177_p0 =  (sc_lv<3>) (sext_ln1116_178_fu_28373_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1978_fu_81177_p1() {
    mul_ln1118_1978_fu_81177_p1 = tmp_1978_fu_81163_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1978_fu_81177_p2() {
    mul_ln1118_1978_fu_81177_p2 = (!mul_ln1118_1978_fu_81177_p0.read().is_01() || !mul_ln1118_1978_fu_81177_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1978_fu_81177_p0.read()) * sc_bigint<5>(mul_ln1118_1978_fu_81177_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1979_fu_81209_p0() {
    mul_ln1118_1979_fu_81209_p0 =  (sc_lv<3>) (sext_ln1116_179_fu_28417_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1979_fu_81209_p1() {
    mul_ln1118_1979_fu_81209_p1 = tmp_1979_fu_81195_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1979_fu_81209_p2() {
    mul_ln1118_1979_fu_81209_p2 = (!mul_ln1118_1979_fu_81209_p0.read().is_01() || !mul_ln1118_1979_fu_81209_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1979_fu_81209_p0.read()) * sc_bigint<5>(mul_ln1118_1979_fu_81209_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_197_fu_29127_p0() {
    mul_ln1118_197_fu_29127_p0 =  (sc_lv<3>) (sext_ln1116_197_fu_29119_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_197_fu_29127_p1() {
    mul_ln1118_197_fu_29127_p1 = tmp_197_fu_29109_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_197_fu_29127_p2() {
    mul_ln1118_197_fu_29127_p2 = (!mul_ln1118_197_fu_29127_p0.read().is_01() || !mul_ln1118_197_fu_29127_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_197_fu_29127_p0.read()) * sc_bigint<5>(mul_ln1118_197_fu_29127_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1980_fu_81241_p0() {
    mul_ln1118_1980_fu_81241_p0 =  (sc_lv<3>) (sext_ln1116_180_fu_28461_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1980_fu_81241_p1() {
    mul_ln1118_1980_fu_81241_p1 = tmp_1980_fu_81227_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1980_fu_81241_p2() {
    mul_ln1118_1980_fu_81241_p2 = (!mul_ln1118_1980_fu_81241_p0.read().is_01() || !mul_ln1118_1980_fu_81241_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1980_fu_81241_p0.read()) * sc_bigint<5>(mul_ln1118_1980_fu_81241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1981_fu_81273_p0() {
    mul_ln1118_1981_fu_81273_p0 =  (sc_lv<3>) (sext_ln1116_181_fu_28505_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1981_fu_81273_p1() {
    mul_ln1118_1981_fu_81273_p1 = tmp_1981_fu_81259_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1981_fu_81273_p2() {
    mul_ln1118_1981_fu_81273_p2 = (!mul_ln1118_1981_fu_81273_p0.read().is_01() || !mul_ln1118_1981_fu_81273_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1981_fu_81273_p0.read()) * sc_bigint<5>(mul_ln1118_1981_fu_81273_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1982_fu_81305_p0() {
    mul_ln1118_1982_fu_81305_p0 =  (sc_lv<3>) (sext_ln1116_182_fu_28549_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1982_fu_81305_p1() {
    mul_ln1118_1982_fu_81305_p1 = tmp_1982_fu_81291_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1982_fu_81305_p2() {
    mul_ln1118_1982_fu_81305_p2 = (!mul_ln1118_1982_fu_81305_p0.read().is_01() || !mul_ln1118_1982_fu_81305_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1982_fu_81305_p0.read()) * sc_bigint<5>(mul_ln1118_1982_fu_81305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1983_fu_81325_p0() {
    mul_ln1118_1983_fu_81325_p0 =  (sc_lv<3>) (sext_ln1116_183_fu_28593_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1983_fu_81325_p1() {
    mul_ln1118_1983_fu_81325_p1 = tmp_1983_fu_81311_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1983_fu_81325_p2() {
    mul_ln1118_1983_fu_81325_p2 = (!mul_ln1118_1983_fu_81325_p0.read().is_01() || !mul_ln1118_1983_fu_81325_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1983_fu_81325_p0.read()) * sc_bigint<5>(mul_ln1118_1983_fu_81325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1984_fu_81357_p0() {
    mul_ln1118_1984_fu_81357_p0 =  (sc_lv<3>) (sext_ln1116_184_fu_28637_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1984_fu_81357_p1() {
    mul_ln1118_1984_fu_81357_p1 = tmp_1984_fu_81343_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1984_fu_81357_p2() {
    mul_ln1118_1984_fu_81357_p2 = (!mul_ln1118_1984_fu_81357_p0.read().is_01() || !mul_ln1118_1984_fu_81357_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1984_fu_81357_p0.read()) * sc_bigint<5>(mul_ln1118_1984_fu_81357_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1985_fu_81389_p0() {
    mul_ln1118_1985_fu_81389_p0 =  (sc_lv<3>) (sext_ln1116_185_fu_28669_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1985_fu_81389_p1() {
    mul_ln1118_1985_fu_81389_p1 = tmp_1985_fu_81375_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1985_fu_81389_p2() {
    mul_ln1118_1985_fu_81389_p2 = (!mul_ln1118_1985_fu_81389_p0.read().is_01() || !mul_ln1118_1985_fu_81389_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1985_fu_81389_p0.read()) * sc_bigint<5>(mul_ln1118_1985_fu_81389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1986_fu_81409_p0() {
    mul_ln1118_1986_fu_81409_p0 =  (sc_lv<3>) (sext_ln1116_186_fu_28713_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1986_fu_81409_p1() {
    mul_ln1118_1986_fu_81409_p1 = tmp_1986_fu_81395_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1986_fu_81409_p2() {
    mul_ln1118_1986_fu_81409_p2 = (!mul_ln1118_1986_fu_81409_p0.read().is_01() || !mul_ln1118_1986_fu_81409_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1986_fu_81409_p0.read()) * sc_bigint<5>(mul_ln1118_1986_fu_81409_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1987_fu_81441_p0() {
    mul_ln1118_1987_fu_81441_p0 =  (sc_lv<3>) (sext_ln1116_187_fu_28757_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1987_fu_81441_p1() {
    mul_ln1118_1987_fu_81441_p1 = tmp_1987_fu_81427_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1987_fu_81441_p2() {
    mul_ln1118_1987_fu_81441_p2 = (!mul_ln1118_1987_fu_81441_p0.read().is_01() || !mul_ln1118_1987_fu_81441_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1987_fu_81441_p0.read()) * sc_bigint<5>(mul_ln1118_1987_fu_81441_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1988_fu_81473_p0() {
    mul_ln1118_1988_fu_81473_p0 =  (sc_lv<3>) (sext_ln1116_188_fu_28789_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1988_fu_81473_p1() {
    mul_ln1118_1988_fu_81473_p1 = tmp_1988_fu_81459_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1988_fu_81473_p2() {
    mul_ln1118_1988_fu_81473_p2 = (!mul_ln1118_1988_fu_81473_p0.read().is_01() || !mul_ln1118_1988_fu_81473_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1988_fu_81473_p0.read()) * sc_bigint<5>(mul_ln1118_1988_fu_81473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1989_fu_81493_p0() {
    mul_ln1118_1989_fu_81493_p0 =  (sc_lv<3>) (sext_ln1116_189_fu_28833_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1989_fu_81493_p1() {
    mul_ln1118_1989_fu_81493_p1 = tmp_1989_fu_81479_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1989_fu_81493_p2() {
    mul_ln1118_1989_fu_81493_p2 = (!mul_ln1118_1989_fu_81493_p0.read().is_01() || !mul_ln1118_1989_fu_81493_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1989_fu_81493_p0.read()) * sc_bigint<5>(mul_ln1118_1989_fu_81493_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_198_fu_29171_p0() {
    mul_ln1118_198_fu_29171_p0 =  (sc_lv<3>) (sext_ln1116_198_fu_29163_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_198_fu_29171_p1() {
    mul_ln1118_198_fu_29171_p1 = tmp_198_fu_29153_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_198_fu_29171_p2() {
    mul_ln1118_198_fu_29171_p2 = (!mul_ln1118_198_fu_29171_p0.read().is_01() || !mul_ln1118_198_fu_29171_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_198_fu_29171_p0.read()) * sc_bigint<5>(mul_ln1118_198_fu_29171_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1990_fu_81525_p0() {
    mul_ln1118_1990_fu_81525_p0 = select_ln76_181_fu_28859_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1990_fu_81525_p1() {
    mul_ln1118_1990_fu_81525_p1 = tmp_1990_fu_81511_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1990_fu_81525_p2() {
    mul_ln1118_1990_fu_81525_p2 = (!mul_ln1118_1990_fu_81525_p0.read().is_01() || !mul_ln1118_1990_fu_81525_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1990_fu_81525_p0.read()) * sc_bigint<5>(mul_ln1118_1990_fu_81525_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1991_fu_81557_p0() {
    mul_ln1118_1991_fu_81557_p0 =  (sc_lv<3>) (sext_ln1116_191_fu_28899_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1991_fu_81557_p1() {
    mul_ln1118_1991_fu_81557_p1 = tmp_1991_fu_81543_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1991_fu_81557_p2() {
    mul_ln1118_1991_fu_81557_p2 = (!mul_ln1118_1991_fu_81557_p0.read().is_01() || !mul_ln1118_1991_fu_81557_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1991_fu_81557_p0.read()) * sc_bigint<5>(mul_ln1118_1991_fu_81557_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1992_fu_81577_p0() {
    mul_ln1118_1992_fu_81577_p0 =  (sc_lv<3>) (sext_ln1116_192_fu_28943_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1992_fu_81577_p1() {
    mul_ln1118_1992_fu_81577_p1 = tmp_1992_fu_81563_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1992_fu_81577_p2() {
    mul_ln1118_1992_fu_81577_p2 = (!mul_ln1118_1992_fu_81577_p0.read().is_01() || !mul_ln1118_1992_fu_81577_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1992_fu_81577_p0.read()) * sc_bigint<5>(mul_ln1118_1992_fu_81577_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1993_fu_81609_p0() {
    mul_ln1118_1993_fu_81609_p0 = select_ln76_184_fu_28969_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1993_fu_81609_p1() {
    mul_ln1118_1993_fu_81609_p1 = tmp_1993_fu_81595_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1993_fu_81609_p2() {
    mul_ln1118_1993_fu_81609_p2 = (!mul_ln1118_1993_fu_81609_p0.read().is_01() || !mul_ln1118_1993_fu_81609_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1993_fu_81609_p0.read()) * sc_bigint<5>(mul_ln1118_1993_fu_81609_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1994_fu_81641_p0() {
    mul_ln1118_1994_fu_81641_p0 =  (sc_lv<3>) (sext_ln1116_194_fu_29009_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1994_fu_81641_p1() {
    mul_ln1118_1994_fu_81641_p1 = tmp_1994_fu_81627_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1994_fu_81641_p2() {
    mul_ln1118_1994_fu_81641_p2 = (!mul_ln1118_1994_fu_81641_p0.read().is_01() || !mul_ln1118_1994_fu_81641_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1994_fu_81641_p0.read()) * sc_bigint<5>(mul_ln1118_1994_fu_81641_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1995_fu_81661_p0() {
    mul_ln1118_1995_fu_81661_p0 =  (sc_lv<3>) (sext_ln1116_195_fu_29053_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1995_fu_81661_p1() {
    mul_ln1118_1995_fu_81661_p1 = tmp_1995_fu_81647_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1995_fu_81661_p2() {
    mul_ln1118_1995_fu_81661_p2 = (!mul_ln1118_1995_fu_81661_p0.read().is_01() || !mul_ln1118_1995_fu_81661_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1995_fu_81661_p0.read()) * sc_bigint<5>(mul_ln1118_1995_fu_81661_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1996_fu_81693_p0() {
    mul_ln1118_1996_fu_81693_p0 = select_ln76_187_fu_29079_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1996_fu_81693_p1() {
    mul_ln1118_1996_fu_81693_p1 = tmp_1996_fu_81679_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1996_fu_81693_p2() {
    mul_ln1118_1996_fu_81693_p2 = (!mul_ln1118_1996_fu_81693_p0.read().is_01() || !mul_ln1118_1996_fu_81693_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1996_fu_81693_p0.read()) * sc_bigint<5>(mul_ln1118_1996_fu_81693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1997_fu_81725_p0() {
    mul_ln1118_1997_fu_81725_p0 =  (sc_lv<3>) (sext_ln1116_197_fu_29119_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1997_fu_81725_p1() {
    mul_ln1118_1997_fu_81725_p1 = tmp_1997_fu_81711_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1997_fu_81725_p2() {
    mul_ln1118_1997_fu_81725_p2 = (!mul_ln1118_1997_fu_81725_p0.read().is_01() || !mul_ln1118_1997_fu_81725_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1997_fu_81725_p0.read()) * sc_bigint<5>(mul_ln1118_1997_fu_81725_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1998_fu_81745_p0() {
    mul_ln1118_1998_fu_81745_p0 =  (sc_lv<3>) (sext_ln1116_198_fu_29163_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1998_fu_81745_p1() {
    mul_ln1118_1998_fu_81745_p1 = tmp_1998_fu_81731_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1998_fu_81745_p2() {
    mul_ln1118_1998_fu_81745_p2 = (!mul_ln1118_1998_fu_81745_p0.read().is_01() || !mul_ln1118_1998_fu_81745_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1998_fu_81745_p0.read()) * sc_bigint<5>(mul_ln1118_1998_fu_81745_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1999_fu_81777_p0() {
    mul_ln1118_1999_fu_81777_p0 = select_ln76_190_fu_29189_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1999_fu_81777_p1() {
    mul_ln1118_1999_fu_81777_p1 = tmp_1999_fu_81763_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1999_fu_81777_p2() {
    mul_ln1118_1999_fu_81777_p2 = (!mul_ln1118_1999_fu_81777_p0.read().is_01() || !mul_ln1118_1999_fu_81777_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1999_fu_81777_p0.read()) * sc_bigint<5>(mul_ln1118_1999_fu_81777_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_199_fu_83352_p0() {
    mul_ln1118_199_fu_83352_p0 =  (sc_lv<3>) (sext_ln1116_199_reg_106542.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_199_fu_83352_p1() {
    mul_ln1118_199_fu_83352_p1 = tmp_199_reg_106537.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_199_fu_83352_p2() {
    mul_ln1118_199_fu_83352_p2 = (!mul_ln1118_199_fu_83352_p0.read().is_01() || !mul_ln1118_199_fu_83352_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_199_fu_83352_p0.read()) * sc_bigint<5>(mul_ln1118_199_fu_83352_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_19_fu_22227_p0() {
    mul_ln1118_19_fu_22227_p0 =  (sc_lv<3>) (sext_ln1116_19_fu_22219_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_19_fu_22227_p1() {
    mul_ln1118_19_fu_22227_p1 = tmp_20_fu_22209_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_19_fu_22227_p2() {
    mul_ln1118_19_fu_22227_p2 = (!mul_ln1118_19_fu_22227_p0.read().is_01() || !mul_ln1118_19_fu_22227_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_19_fu_22227_p0.read()) * sc_bigint<5>(mul_ln1118_19_fu_22227_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2000_fu_81809_p0() {
    mul_ln1118_2000_fu_81809_p0 =  (sc_lv<3>) (sext_ln1116_200_fu_29229_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2000_fu_81809_p1() {
    mul_ln1118_2000_fu_81809_p1 = tmp_2000_fu_81795_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2000_fu_81809_p2() {
    mul_ln1118_2000_fu_81809_p2 = (!mul_ln1118_2000_fu_81809_p0.read().is_01() || !mul_ln1118_2000_fu_81809_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_2000_fu_81809_p0.read()) * sc_bigint<5>(mul_ln1118_2000_fu_81809_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2001_fu_81829_p0() {
    mul_ln1118_2001_fu_81829_p0 =  (sc_lv<3>) (sext_ln1116_201_fu_29273_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2001_fu_81829_p1() {
    mul_ln1118_2001_fu_81829_p1 = tmp_2001_fu_81815_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2001_fu_81829_p2() {
    mul_ln1118_2001_fu_81829_p2 = (!mul_ln1118_2001_fu_81829_p0.read().is_01() || !mul_ln1118_2001_fu_81829_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_2001_fu_81829_p0.read()) * sc_bigint<5>(mul_ln1118_2001_fu_81829_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2002_fu_81861_p0() {
    mul_ln1118_2002_fu_81861_p0 = select_ln76_193_fu_29299_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2002_fu_81861_p1() {
    mul_ln1118_2002_fu_81861_p1 = tmp_2002_fu_81847_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2002_fu_81861_p2() {
    mul_ln1118_2002_fu_81861_p2 = (!mul_ln1118_2002_fu_81861_p0.read().is_01() || !mul_ln1118_2002_fu_81861_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_2002_fu_81861_p0.read()) * sc_bigint<5>(mul_ln1118_2002_fu_81861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2003_fu_81893_p0() {
    mul_ln1118_2003_fu_81893_p0 =  (sc_lv<3>) (sext_ln1116_203_fu_29339_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2003_fu_81893_p1() {
    mul_ln1118_2003_fu_81893_p1 = tmp_2003_fu_81879_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2003_fu_81893_p2() {
    mul_ln1118_2003_fu_81893_p2 = (!mul_ln1118_2003_fu_81893_p0.read().is_01() || !mul_ln1118_2003_fu_81893_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_2003_fu_81893_p0.read()) * sc_bigint<5>(mul_ln1118_2003_fu_81893_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2004_fu_81925_p0() {
    mul_ln1118_2004_fu_81925_p0 =  (sc_lv<3>) (sext_ln1116_204_fu_29383_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2004_fu_81925_p1() {
    mul_ln1118_2004_fu_81925_p1 = tmp_2004_fu_81911_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2004_fu_81925_p2() {
    mul_ln1118_2004_fu_81925_p2 = (!mul_ln1118_2004_fu_81925_p0.read().is_01() || !mul_ln1118_2004_fu_81925_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_2004_fu_81925_p0.read()) * sc_bigint<5>(mul_ln1118_2004_fu_81925_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2005_fu_81957_p0() {
    mul_ln1118_2005_fu_81957_p0 =  (sc_lv<3>) (sext_ln1116_205_fu_29427_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2005_fu_81957_p1() {
    mul_ln1118_2005_fu_81957_p1 = tmp_2005_fu_81943_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2005_fu_81957_p2() {
    mul_ln1118_2005_fu_81957_p2 = (!mul_ln1118_2005_fu_81957_p0.read().is_01() || !mul_ln1118_2005_fu_81957_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_2005_fu_81957_p0.read()) * sc_bigint<5>(mul_ln1118_2005_fu_81957_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_200_fu_29237_p0() {
    mul_ln1118_200_fu_29237_p0 =  (sc_lv<3>) (sext_ln1116_200_fu_29229_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_200_fu_29237_p1() {
    mul_ln1118_200_fu_29237_p1 = tmp_200_fu_29219_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_200_fu_29237_p2() {
    mul_ln1118_200_fu_29237_p2 = (!mul_ln1118_200_fu_29237_p0.read().is_01() || !mul_ln1118_200_fu_29237_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_200_fu_29237_p0.read()) * sc_bigint<5>(mul_ln1118_200_fu_29237_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_201_fu_29281_p0() {
    mul_ln1118_201_fu_29281_p0 =  (sc_lv<3>) (sext_ln1116_201_fu_29273_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_201_fu_29281_p1() {
    mul_ln1118_201_fu_29281_p1 = tmp_201_fu_29263_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_201_fu_29281_p2() {
    mul_ln1118_201_fu_29281_p2 = (!mul_ln1118_201_fu_29281_p0.read().is_01() || !mul_ln1118_201_fu_29281_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_201_fu_29281_p0.read()) * sc_bigint<5>(mul_ln1118_201_fu_29281_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_202_fu_83372_p0() {
    mul_ln1118_202_fu_83372_p0 =  (sc_lv<3>) (sext_ln1116_202_reg_106560.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_202_fu_83372_p1() {
    mul_ln1118_202_fu_83372_p1 = tmp_202_reg_106555.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_202_fu_83372_p2() {
    mul_ln1118_202_fu_83372_p2 = (!mul_ln1118_202_fu_83372_p0.read().is_01() || !mul_ln1118_202_fu_83372_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_202_fu_83372_p0.read()) * sc_bigint<5>(mul_ln1118_202_fu_83372_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_203_fu_29347_p0() {
    mul_ln1118_203_fu_29347_p0 =  (sc_lv<3>) (sext_ln1116_203_fu_29339_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_203_fu_29347_p1() {
    mul_ln1118_203_fu_29347_p1 = tmp_203_fu_29329_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_203_fu_29347_p2() {
    mul_ln1118_203_fu_29347_p2 = (!mul_ln1118_203_fu_29347_p0.read().is_01() || !mul_ln1118_203_fu_29347_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_203_fu_29347_p0.read()) * sc_bigint<5>(mul_ln1118_203_fu_29347_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_204_fu_29391_p0() {
    mul_ln1118_204_fu_29391_p0 =  (sc_lv<3>) (sext_ln1116_204_fu_29383_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_204_fu_29391_p1() {
    mul_ln1118_204_fu_29391_p1 = tmp_204_fu_29373_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_204_fu_29391_p2() {
    mul_ln1118_204_fu_29391_p2 = (!mul_ln1118_204_fu_29391_p0.read().is_01() || !mul_ln1118_204_fu_29391_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_204_fu_29391_p0.read()) * sc_bigint<5>(mul_ln1118_204_fu_29391_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_205_fu_29435_p0() {
    mul_ln1118_205_fu_29435_p0 =  (sc_lv<3>) (sext_ln1116_205_fu_29427_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_205_fu_29435_p1() {
    mul_ln1118_205_fu_29435_p1 = tmp_205_fu_29417_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_205_fu_29435_p2() {
    mul_ln1118_205_fu_29435_p2 = (!mul_ln1118_205_fu_29435_p0.read().is_01() || !mul_ln1118_205_fu_29435_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_205_fu_29435_p0.read()) * sc_bigint<5>(mul_ln1118_205_fu_29435_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_206_fu_29479_p0() {
    mul_ln1118_206_fu_29479_p0 =  (sc_lv<3>) (sext_ln1116_206_fu_29471_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_206_fu_29479_p1() {
    mul_ln1118_206_fu_29479_p1 = tmp_206_fu_29461_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_206_fu_29479_p2() {
    mul_ln1118_206_fu_29479_p2 = (!mul_ln1118_206_fu_29479_p0.read().is_01() || !mul_ln1118_206_fu_29479_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_206_fu_29479_p0.read()) * sc_bigint<5>(mul_ln1118_206_fu_29479_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_207_fu_29523_p0() {
    mul_ln1118_207_fu_29523_p0 =  (sc_lv<3>) (sext_ln1116_207_fu_29515_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_207_fu_29523_p1() {
    mul_ln1118_207_fu_29523_p1 = tmp_207_fu_29505_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_207_fu_29523_p2() {
    mul_ln1118_207_fu_29523_p2 = (!mul_ln1118_207_fu_29523_p0.read().is_01() || !mul_ln1118_207_fu_29523_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_207_fu_29523_p0.read()) * sc_bigint<5>(mul_ln1118_207_fu_29523_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_208_fu_29567_p0() {
    mul_ln1118_208_fu_29567_p0 =  (sc_lv<3>) (sext_ln1116_208_fu_29559_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_208_fu_29567_p1() {
    mul_ln1118_208_fu_29567_p1 = tmp_208_fu_29549_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_208_fu_29567_p2() {
    mul_ln1118_208_fu_29567_p2 = (!mul_ln1118_208_fu_29567_p0.read().is_01() || !mul_ln1118_208_fu_29567_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_208_fu_29567_p0.read()) * sc_bigint<5>(mul_ln1118_208_fu_29567_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_209_fu_30031_p0() {
    mul_ln1118_209_fu_30031_p0 =  (sc_lv<3>) (sext_ln1116_fu_21855_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_209_fu_30031_p1() {
    mul_ln1118_209_fu_30031_p1 = tmp_209_fu_30017_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_209_fu_30031_p2() {
    mul_ln1118_209_fu_30031_p2 = (!mul_ln1118_209_fu_30031_p0.read().is_01() || !mul_ln1118_209_fu_30031_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_209_fu_30031_p0.read()) * sc_bigint<5>(mul_ln1118_209_fu_30031_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_20_fu_22271_p0() {
    mul_ln1118_20_fu_22271_p0 =  (sc_lv<3>) (sext_ln1116_20_fu_22263_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_20_fu_22271_p1() {
    mul_ln1118_20_fu_22271_p1 = tmp_s_fu_22253_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_20_fu_22271_p2() {
    mul_ln1118_20_fu_22271_p2 = (!mul_ln1118_20_fu_22271_p0.read().is_01() || !mul_ln1118_20_fu_22271_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_20_fu_22271_p0.read()) * sc_bigint<5>(mul_ln1118_20_fu_22271_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_210_fu_30051_p0() {
    mul_ln1118_210_fu_30051_p0 =  (sc_lv<3>) (sext_ln1116_10_fu_21887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_210_fu_30051_p1() {
    mul_ln1118_210_fu_30051_p1 = tmp_210_fu_30037_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_210_fu_30051_p2() {
    mul_ln1118_210_fu_30051_p2 = (!mul_ln1118_210_fu_30051_p0.read().is_01() || !mul_ln1118_210_fu_30051_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_210_fu_30051_p0.read()) * sc_bigint<5>(mul_ln1118_210_fu_30051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_211_fu_30083_p0() {
    mul_ln1118_211_fu_30083_p0 =  (sc_lv<3>) (sext_ln1116_11_fu_21931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_211_fu_30083_p1() {
    mul_ln1118_211_fu_30083_p1 = tmp_211_fu_30069_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_211_fu_30083_p2() {
    mul_ln1118_211_fu_30083_p2 = (!mul_ln1118_211_fu_30083_p0.read().is_01() || !mul_ln1118_211_fu_30083_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_211_fu_30083_p0.read()) * sc_bigint<5>(mul_ln1118_211_fu_30083_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_212_fu_30115_p0() {
    mul_ln1118_212_fu_30115_p0 =  (sc_lv<3>) (sext_ln1116_12_fu_21975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_212_fu_30115_p1() {
    mul_ln1118_212_fu_30115_p1 = tmp_212_fu_30101_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_212_fu_30115_p2() {
    mul_ln1118_212_fu_30115_p2 = (!mul_ln1118_212_fu_30115_p0.read().is_01() || !mul_ln1118_212_fu_30115_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_212_fu_30115_p0.read()) * sc_bigint<5>(mul_ln1118_212_fu_30115_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_213_fu_30135_p0() {
    mul_ln1118_213_fu_30135_p0 =  (sc_lv<3>) (sext_ln1116_13_fu_22007_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_213_fu_30135_p1() {
    mul_ln1118_213_fu_30135_p1 = tmp_213_fu_30121_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_213_fu_30135_p2() {
    mul_ln1118_213_fu_30135_p2 = (!mul_ln1118_213_fu_30135_p0.read().is_01() || !mul_ln1118_213_fu_30135_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_213_fu_30135_p0.read()) * sc_bigint<5>(mul_ln1118_213_fu_30135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_214_fu_30167_p0() {
    mul_ln1118_214_fu_30167_p0 =  (sc_lv<3>) (sext_ln1116_14_fu_22051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_214_fu_30167_p1() {
    mul_ln1118_214_fu_30167_p1 = tmp_214_fu_30153_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_214_fu_30167_p2() {
    mul_ln1118_214_fu_30167_p2 = (!mul_ln1118_214_fu_30167_p0.read().is_01() || !mul_ln1118_214_fu_30167_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_214_fu_30167_p0.read()) * sc_bigint<5>(mul_ln1118_214_fu_30167_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_215_fu_84522_p0() {
    mul_ln1118_215_fu_84522_p0 =  (sc_lv<3>) (sext_ln1116_15_fu_82451_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_215_fu_84522_p1() {
    mul_ln1118_215_fu_84522_p1 = tmp_215_reg_106943.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_215_fu_84522_p2() {
    mul_ln1118_215_fu_84522_p2 = (!mul_ln1118_215_fu_84522_p0.read().is_01() || !mul_ln1118_215_fu_84522_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_215_fu_84522_p0.read()) * sc_bigint<5>(mul_ln1118_215_fu_84522_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_216_fu_30209_p0() {
    mul_ln1118_216_fu_30209_p0 =  (sc_lv<3>) (sext_ln1116_16_fu_22113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_216_fu_30209_p1() {
    mul_ln1118_216_fu_30209_p1 = tmp_216_fu_30195_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_216_fu_30209_p2() {
    mul_ln1118_216_fu_30209_p2 = (!mul_ln1118_216_fu_30209_p0.read().is_01() || !mul_ln1118_216_fu_30209_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_216_fu_30209_p0.read()) * sc_bigint<5>(mul_ln1118_216_fu_30209_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_217_fu_30241_p0() {
    mul_ln1118_217_fu_30241_p0 =  (sc_lv<3>) (sext_ln1116_17_fu_22157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_217_fu_30241_p1() {
    mul_ln1118_217_fu_30241_p1 = tmp_217_fu_30227_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_217_fu_30241_p2() {
    mul_ln1118_217_fu_30241_p2 = (!mul_ln1118_217_fu_30241_p0.read().is_01() || !mul_ln1118_217_fu_30241_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_217_fu_30241_p0.read()) * sc_bigint<5>(mul_ln1118_217_fu_30241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_218_fu_84543_p0() {
    mul_ln1118_218_fu_84543_p0 =  (sc_lv<3>) (sext_ln1116_18_fu_82475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_218_fu_84543_p1() {
    mul_ln1118_218_fu_84543_p1 = tmp_218_reg_106948.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_218_fu_84543_p2() {
    mul_ln1118_218_fu_84543_p2 = (!mul_ln1118_218_fu_84543_p0.read().is_01() || !mul_ln1118_218_fu_84543_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_218_fu_84543_p0.read()) * sc_bigint<5>(mul_ln1118_218_fu_84543_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_219_fu_30283_p0() {
    mul_ln1118_219_fu_30283_p0 =  (sc_lv<3>) (sext_ln1116_19_fu_22219_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_219_fu_30283_p1() {
    mul_ln1118_219_fu_30283_p1 = tmp_219_fu_30269_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_219_fu_30283_p2() {
    mul_ln1118_219_fu_30283_p2 = (!mul_ln1118_219_fu_30283_p0.read().is_01() || !mul_ln1118_219_fu_30283_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_219_fu_30283_p0.read()) * sc_bigint<5>(mul_ln1118_219_fu_30283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_21_fu_82505_p0() {
    mul_ln1118_21_fu_82505_p0 =  (sc_lv<3>) (sext_ln1116_21_fu_82499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_21_fu_82505_p1() {
    mul_ln1118_21_fu_82505_p1 = tmp_21_reg_105900.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_21_fu_82505_p2() {
    mul_ln1118_21_fu_82505_p2 = (!mul_ln1118_21_fu_82505_p0.read().is_01() || !mul_ln1118_21_fu_82505_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_21_fu_82505_p0.read()) * sc_bigint<5>(mul_ln1118_21_fu_82505_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_220_fu_30315_p0() {
    mul_ln1118_220_fu_30315_p0 =  (sc_lv<3>) (sext_ln1116_20_fu_22263_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_220_fu_30315_p1() {
    mul_ln1118_220_fu_30315_p1 = tmp_220_fu_30301_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_220_fu_30315_p2() {
    mul_ln1118_220_fu_30315_p2 = (!mul_ln1118_220_fu_30315_p0.read().is_01() || !mul_ln1118_220_fu_30315_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_220_fu_30315_p0.read()) * sc_bigint<5>(mul_ln1118_220_fu_30315_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_221_fu_84564_p0() {
    mul_ln1118_221_fu_84564_p0 =  (sc_lv<3>) (sext_ln1116_21_fu_82499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_221_fu_84564_p1() {
    mul_ln1118_221_fu_84564_p1 = tmp_221_reg_106953.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_221_fu_84564_p2() {
    mul_ln1118_221_fu_84564_p2 = (!mul_ln1118_221_fu_84564_p0.read().is_01() || !mul_ln1118_221_fu_84564_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_221_fu_84564_p0.read()) * sc_bigint<5>(mul_ln1118_221_fu_84564_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_222_fu_30357_p0() {
    mul_ln1118_222_fu_30357_p0 =  (sc_lv<3>) (sext_ln1116_22_fu_22325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_222_fu_30357_p1() {
    mul_ln1118_222_fu_30357_p1 = tmp_222_fu_30343_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_222_fu_30357_p2() {
    mul_ln1118_222_fu_30357_p2 = (!mul_ln1118_222_fu_30357_p0.read().is_01() || !mul_ln1118_222_fu_30357_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_222_fu_30357_p0.read()) * sc_bigint<5>(mul_ln1118_222_fu_30357_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_223_fu_30389_p0() {
    mul_ln1118_223_fu_30389_p0 =  (sc_lv<3>) (sext_ln1116_23_fu_22369_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_223_fu_30389_p1() {
    mul_ln1118_223_fu_30389_p1 = tmp_223_fu_30375_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_223_fu_30389_p2() {
    mul_ln1118_223_fu_30389_p2 = (!mul_ln1118_223_fu_30389_p0.read().is_01() || !mul_ln1118_223_fu_30389_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_223_fu_30389_p0.read()) * sc_bigint<5>(mul_ln1118_223_fu_30389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_224_fu_84585_p0() {
    mul_ln1118_224_fu_84585_p0 =  (sc_lv<3>) (sext_ln1116_24_fu_82523_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_224_fu_84585_p1() {
    mul_ln1118_224_fu_84585_p1 = tmp_224_reg_106958.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_224_fu_84585_p2() {
    mul_ln1118_224_fu_84585_p2 = (!mul_ln1118_224_fu_84585_p0.read().is_01() || !mul_ln1118_224_fu_84585_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_224_fu_84585_p0.read()) * sc_bigint<5>(mul_ln1118_224_fu_84585_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_225_fu_30431_p0() {
    mul_ln1118_225_fu_30431_p0 =  (sc_lv<3>) (sext_ln1116_25_fu_22431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_225_fu_30431_p1() {
    mul_ln1118_225_fu_30431_p1 = tmp_225_fu_30417_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_225_fu_30431_p2() {
    mul_ln1118_225_fu_30431_p2 = (!mul_ln1118_225_fu_30431_p0.read().is_01() || !mul_ln1118_225_fu_30431_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_225_fu_30431_p0.read()) * sc_bigint<5>(mul_ln1118_225_fu_30431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_226_fu_30463_p0() {
    mul_ln1118_226_fu_30463_p0 =  (sc_lv<3>) (sext_ln1116_26_fu_22475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_226_fu_30463_p1() {
    mul_ln1118_226_fu_30463_p1 = tmp_226_fu_30449_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_226_fu_30463_p2() {
    mul_ln1118_226_fu_30463_p2 = (!mul_ln1118_226_fu_30463_p0.read().is_01() || !mul_ln1118_226_fu_30463_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_226_fu_30463_p0.read()) * sc_bigint<5>(mul_ln1118_226_fu_30463_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_227_fu_84606_p0() {
    mul_ln1118_227_fu_84606_p0 =  (sc_lv<3>) (sext_ln1116_27_fu_82547_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_227_fu_84606_p1() {
    mul_ln1118_227_fu_84606_p1 = tmp_227_reg_106963.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_227_fu_84606_p2() {
    mul_ln1118_227_fu_84606_p2 = (!mul_ln1118_227_fu_84606_p0.read().is_01() || !mul_ln1118_227_fu_84606_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_227_fu_84606_p0.read()) * sc_bigint<5>(mul_ln1118_227_fu_84606_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_228_fu_30505_p0() {
    mul_ln1118_228_fu_30505_p0 =  (sc_lv<3>) (sext_ln1116_28_fu_22537_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_228_fu_30505_p1() {
    mul_ln1118_228_fu_30505_p1 = tmp_228_fu_30491_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_228_fu_30505_p2() {
    mul_ln1118_228_fu_30505_p2 = (!mul_ln1118_228_fu_30505_p0.read().is_01() || !mul_ln1118_228_fu_30505_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_228_fu_30505_p0.read()) * sc_bigint<5>(mul_ln1118_228_fu_30505_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_229_fu_30537_p0() {
    mul_ln1118_229_fu_30537_p0 =  (sc_lv<3>) (sext_ln1116_29_fu_22581_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_229_fu_30537_p1() {
    mul_ln1118_229_fu_30537_p1 = tmp_229_fu_30523_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_229_fu_30537_p2() {
    mul_ln1118_229_fu_30537_p2 = (!mul_ln1118_229_fu_30537_p0.read().is_01() || !mul_ln1118_229_fu_30537_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_229_fu_30537_p0.read()) * sc_bigint<5>(mul_ln1118_229_fu_30537_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_22_fu_22333_p0() {
    mul_ln1118_22_fu_22333_p0 =  (sc_lv<3>) (sext_ln1116_22_fu_22325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_22_fu_22333_p1() {
    mul_ln1118_22_fu_22333_p1 = tmp_22_fu_22315_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_22_fu_22333_p2() {
    mul_ln1118_22_fu_22333_p2 = (!mul_ln1118_22_fu_22333_p0.read().is_01() || !mul_ln1118_22_fu_22333_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_22_fu_22333_p0.read()) * sc_bigint<5>(mul_ln1118_22_fu_22333_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_230_fu_30569_p0() {
    mul_ln1118_230_fu_30569_p0 =  (sc_lv<3>) (sext_ln1116_30_fu_22625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_230_fu_30569_p1() {
    mul_ln1118_230_fu_30569_p1 = tmp_230_fu_30555_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_230_fu_30569_p2() {
    mul_ln1118_230_fu_30569_p2 = (!mul_ln1118_230_fu_30569_p0.read().is_01() || !mul_ln1118_230_fu_30569_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_230_fu_30569_p0.read()) * sc_bigint<5>(mul_ln1118_230_fu_30569_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_231_fu_30601_p0() {
    mul_ln1118_231_fu_30601_p0 =  (sc_lv<3>) (sext_ln1116_31_fu_22669_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_231_fu_30601_p1() {
    mul_ln1118_231_fu_30601_p1 = tmp_231_fu_30587_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_231_fu_30601_p2() {
    mul_ln1118_231_fu_30601_p2 = (!mul_ln1118_231_fu_30601_p0.read().is_01() || !mul_ln1118_231_fu_30601_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_231_fu_30601_p0.read()) * sc_bigint<5>(mul_ln1118_231_fu_30601_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_232_fu_30633_p0() {
    mul_ln1118_232_fu_30633_p0 =  (sc_lv<3>) (sext_ln1116_32_fu_22713_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_232_fu_30633_p1() {
    mul_ln1118_232_fu_30633_p1 = tmp_232_fu_30619_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_232_fu_30633_p2() {
    mul_ln1118_232_fu_30633_p2 = (!mul_ln1118_232_fu_30633_p0.read().is_01() || !mul_ln1118_232_fu_30633_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_232_fu_30633_p0.read()) * sc_bigint<5>(mul_ln1118_232_fu_30633_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_233_fu_30665_p0() {
    mul_ln1118_233_fu_30665_p0 =  (sc_lv<3>) (sext_ln1116_33_fu_22757_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_233_fu_30665_p1() {
    mul_ln1118_233_fu_30665_p1 = tmp_233_fu_30651_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_233_fu_30665_p2() {
    mul_ln1118_233_fu_30665_p2 = (!mul_ln1118_233_fu_30665_p0.read().is_01() || !mul_ln1118_233_fu_30665_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_233_fu_30665_p0.read()) * sc_bigint<5>(mul_ln1118_233_fu_30665_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_234_fu_30697_p0() {
    mul_ln1118_234_fu_30697_p0 =  (sc_lv<3>) (sext_ln1116_34_fu_22801_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_234_fu_30697_p1() {
    mul_ln1118_234_fu_30697_p1 = tmp_234_fu_30683_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_234_fu_30697_p2() {
    mul_ln1118_234_fu_30697_p2 = (!mul_ln1118_234_fu_30697_p0.read().is_01() || !mul_ln1118_234_fu_30697_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_234_fu_30697_p0.read()) * sc_bigint<5>(mul_ln1118_234_fu_30697_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_235_fu_30717_p0() {
    mul_ln1118_235_fu_30717_p0 =  (sc_lv<3>) (sext_ln1116_35_fu_22833_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_235_fu_30717_p1() {
    mul_ln1118_235_fu_30717_p1 = tmp_235_fu_30703_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_235_fu_30717_p2() {
    mul_ln1118_235_fu_30717_p2 = (!mul_ln1118_235_fu_30717_p0.read().is_01() || !mul_ln1118_235_fu_30717_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_235_fu_30717_p0.read()) * sc_bigint<5>(mul_ln1118_235_fu_30717_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_236_fu_30749_p0() {
    mul_ln1118_236_fu_30749_p0 =  (sc_lv<3>) (sext_ln1116_36_fu_22877_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_236_fu_30749_p1() {
    mul_ln1118_236_fu_30749_p1 = tmp_236_fu_30735_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_236_fu_30749_p2() {
    mul_ln1118_236_fu_30749_p2 = (!mul_ln1118_236_fu_30749_p0.read().is_01() || !mul_ln1118_236_fu_30749_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_236_fu_30749_p0.read()) * sc_bigint<5>(mul_ln1118_236_fu_30749_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_237_fu_30781_p0() {
    mul_ln1118_237_fu_30781_p0 =  (sc_lv<3>) (sext_ln1116_37_fu_22921_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_237_fu_30781_p1() {
    mul_ln1118_237_fu_30781_p1 = tmp_237_fu_30767_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_237_fu_30781_p2() {
    mul_ln1118_237_fu_30781_p2 = (!mul_ln1118_237_fu_30781_p0.read().is_01() || !mul_ln1118_237_fu_30781_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_237_fu_30781_p0.read()) * sc_bigint<5>(mul_ln1118_237_fu_30781_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_238_fu_30801_p0() {
    mul_ln1118_238_fu_30801_p0 =  (sc_lv<3>) (sext_ln1116_38_fu_22953_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_238_fu_30801_p1() {
    mul_ln1118_238_fu_30801_p1 = tmp_238_fu_30787_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_238_fu_30801_p2() {
    mul_ln1118_238_fu_30801_p2 = (!mul_ln1118_238_fu_30801_p0.read().is_01() || !mul_ln1118_238_fu_30801_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_238_fu_30801_p0.read()) * sc_bigint<5>(mul_ln1118_238_fu_30801_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_239_fu_30833_p0() {
    mul_ln1118_239_fu_30833_p0 =  (sc_lv<3>) (sext_ln1116_39_fu_22997_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_239_fu_30833_p1() {
    mul_ln1118_239_fu_30833_p1 = tmp_239_fu_30819_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_239_fu_30833_p2() {
    mul_ln1118_239_fu_30833_p2 = (!mul_ln1118_239_fu_30833_p0.read().is_01() || !mul_ln1118_239_fu_30833_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_239_fu_30833_p0.read()) * sc_bigint<5>(mul_ln1118_239_fu_30833_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_23_fu_22377_p0() {
    mul_ln1118_23_fu_22377_p0 =  (sc_lv<3>) (sext_ln1116_23_fu_22369_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_23_fu_22377_p1() {
    mul_ln1118_23_fu_22377_p1 = tmp_23_fu_22359_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_23_fu_22377_p2() {
    mul_ln1118_23_fu_22377_p2 = (!mul_ln1118_23_fu_22377_p0.read().is_01() || !mul_ln1118_23_fu_22377_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_23_fu_22377_p0.read()) * sc_bigint<5>(mul_ln1118_23_fu_22377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_240_fu_84649_p0() {
    mul_ln1118_240_fu_84649_p0 =  (sc_lv<3>) (sext_ln1116_40_reg_105940.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_240_fu_84649_p1() {
    mul_ln1118_240_fu_84649_p1 = tmp_240_reg_106978.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_240_fu_84649_p2() {
    mul_ln1118_240_fu_84649_p2 = (!mul_ln1118_240_fu_84649_p0.read().is_01() || !mul_ln1118_240_fu_84649_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_240_fu_84649_p0.read()) * sc_bigint<5>(mul_ln1118_240_fu_84649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_241_fu_30875_p0() {
    mul_ln1118_241_fu_30875_p0 =  (sc_lv<3>) (sext_ln1116_41_fu_23063_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_241_fu_30875_p1() {
    mul_ln1118_241_fu_30875_p1 = tmp_241_fu_30861_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_241_fu_30875_p2() {
    mul_ln1118_241_fu_30875_p2 = (!mul_ln1118_241_fu_30875_p0.read().is_01() || !mul_ln1118_241_fu_30875_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_241_fu_30875_p0.read()) * sc_bigint<5>(mul_ln1118_241_fu_30875_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_242_fu_30907_p0() {
    mul_ln1118_242_fu_30907_p0 =  (sc_lv<3>) (sext_ln1116_42_fu_23107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_242_fu_30907_p1() {
    mul_ln1118_242_fu_30907_p1 = tmp_242_fu_30893_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_242_fu_30907_p2() {
    mul_ln1118_242_fu_30907_p2 = (!mul_ln1118_242_fu_30907_p0.read().is_01() || !mul_ln1118_242_fu_30907_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_242_fu_30907_p0.read()) * sc_bigint<5>(mul_ln1118_242_fu_30907_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_243_fu_84669_p0() {
    mul_ln1118_243_fu_84669_p0 =  (sc_lv<3>) (sext_ln1116_43_reg_105958.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_243_fu_84669_p1() {
    mul_ln1118_243_fu_84669_p1 = tmp_243_reg_106983.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_243_fu_84669_p2() {
    mul_ln1118_243_fu_84669_p2 = (!mul_ln1118_243_fu_84669_p0.read().is_01() || !mul_ln1118_243_fu_84669_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_243_fu_84669_p0.read()) * sc_bigint<5>(mul_ln1118_243_fu_84669_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_244_fu_30949_p0() {
    mul_ln1118_244_fu_30949_p0 =  (sc_lv<3>) (sext_ln1116_44_fu_23173_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_244_fu_30949_p1() {
    mul_ln1118_244_fu_30949_p1 = tmp_244_fu_30935_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_244_fu_30949_p2() {
    mul_ln1118_244_fu_30949_p2 = (!mul_ln1118_244_fu_30949_p0.read().is_01() || !mul_ln1118_244_fu_30949_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_244_fu_30949_p0.read()) * sc_bigint<5>(mul_ln1118_244_fu_30949_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_245_fu_30981_p0() {
    mul_ln1118_245_fu_30981_p0 =  (sc_lv<3>) (sext_ln1116_45_fu_23217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_245_fu_30981_p1() {
    mul_ln1118_245_fu_30981_p1 = tmp_245_fu_30967_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_245_fu_30981_p2() {
    mul_ln1118_245_fu_30981_p2 = (!mul_ln1118_245_fu_30981_p0.read().is_01() || !mul_ln1118_245_fu_30981_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_245_fu_30981_p0.read()) * sc_bigint<5>(mul_ln1118_245_fu_30981_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_246_fu_31013_p0() {
    mul_ln1118_246_fu_31013_p0 =  (sc_lv<3>) (sext_ln1116_46_fu_23261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_246_fu_31013_p1() {
    mul_ln1118_246_fu_31013_p1 = tmp_246_fu_30999_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_246_fu_31013_p2() {
    mul_ln1118_246_fu_31013_p2 = (!mul_ln1118_246_fu_31013_p0.read().is_01() || !mul_ln1118_246_fu_31013_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_246_fu_31013_p0.read()) * sc_bigint<5>(mul_ln1118_246_fu_31013_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_247_fu_31033_p0() {
    mul_ln1118_247_fu_31033_p0 =  (sc_lv<3>) (sext_ln1116_47_fu_23293_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_247_fu_31033_p1() {
    mul_ln1118_247_fu_31033_p1 = tmp_247_fu_31019_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_247_fu_31033_p2() {
    mul_ln1118_247_fu_31033_p2 = (!mul_ln1118_247_fu_31033_p0.read().is_01() || !mul_ln1118_247_fu_31033_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_247_fu_31033_p0.read()) * sc_bigint<5>(mul_ln1118_247_fu_31033_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_248_fu_31065_p0() {
    mul_ln1118_248_fu_31065_p0 =  (sc_lv<3>) (sext_ln1116_48_fu_23337_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_248_fu_31065_p1() {
    mul_ln1118_248_fu_31065_p1 = tmp_248_fu_31051_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_248_fu_31065_p2() {
    mul_ln1118_248_fu_31065_p2 = (!mul_ln1118_248_fu_31065_p0.read().is_01() || !mul_ln1118_248_fu_31065_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_248_fu_31065_p0.read()) * sc_bigint<5>(mul_ln1118_248_fu_31065_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_249_fu_31097_p0() {
    mul_ln1118_249_fu_31097_p0 =  (sc_lv<3>) (sext_ln1116_49_fu_23381_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_249_fu_31097_p1() {
    mul_ln1118_249_fu_31097_p1 = tmp_249_fu_31083_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_249_fu_31097_p2() {
    mul_ln1118_249_fu_31097_p2 = (!mul_ln1118_249_fu_31097_p0.read().is_01() || !mul_ln1118_249_fu_31097_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_249_fu_31097_p0.read()) * sc_bigint<5>(mul_ln1118_249_fu_31097_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_24_fu_82529_p0() {
    mul_ln1118_24_fu_82529_p0 =  (sc_lv<3>) (sext_ln1116_24_fu_82523_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_24_fu_82529_p1() {
    mul_ln1118_24_fu_82529_p1 = tmp_24_reg_105910.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_24_fu_82529_p2() {
    mul_ln1118_24_fu_82529_p2 = (!mul_ln1118_24_fu_82529_p0.read().is_01() || !mul_ln1118_24_fu_82529_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_24_fu_82529_p0.read()) * sc_bigint<5>(mul_ln1118_24_fu_82529_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_250_fu_31117_p0() {
    mul_ln1118_250_fu_31117_p0 =  (sc_lv<3>) (sext_ln1116_50_fu_23413_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_250_fu_31117_p1() {
    mul_ln1118_250_fu_31117_p1 = tmp_250_fu_31103_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_250_fu_31117_p2() {
    mul_ln1118_250_fu_31117_p2 = (!mul_ln1118_250_fu_31117_p0.read().is_01() || !mul_ln1118_250_fu_31117_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_250_fu_31117_p0.read()) * sc_bigint<5>(mul_ln1118_250_fu_31117_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_251_fu_31149_p0() {
    mul_ln1118_251_fu_31149_p0 =  (sc_lv<3>) (sext_ln1116_51_fu_23457_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_251_fu_31149_p1() {
    mul_ln1118_251_fu_31149_p1 = tmp_251_fu_31135_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_251_fu_31149_p2() {
    mul_ln1118_251_fu_31149_p2 = (!mul_ln1118_251_fu_31149_p0.read().is_01() || !mul_ln1118_251_fu_31149_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_251_fu_31149_p0.read()) * sc_bigint<5>(mul_ln1118_251_fu_31149_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_252_fu_84711_p0() {
    mul_ln1118_252_fu_84711_p0 =  (sc_lv<3>) (sext_ln1116_52_reg_105986.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_252_fu_84711_p1() {
    mul_ln1118_252_fu_84711_p1 = tmp_252_reg_106998.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_252_fu_84711_p2() {
    mul_ln1118_252_fu_84711_p2 = (!mul_ln1118_252_fu_84711_p0.read().is_01() || !mul_ln1118_252_fu_84711_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_252_fu_84711_p0.read()) * sc_bigint<5>(mul_ln1118_252_fu_84711_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_253_fu_31191_p0() {
    mul_ln1118_253_fu_31191_p0 =  (sc_lv<3>) (sext_ln1116_53_fu_23523_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_253_fu_31191_p1() {
    mul_ln1118_253_fu_31191_p1 = tmp_253_fu_31177_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_253_fu_31191_p2() {
    mul_ln1118_253_fu_31191_p2 = (!mul_ln1118_253_fu_31191_p0.read().is_01() || !mul_ln1118_253_fu_31191_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_253_fu_31191_p0.read()) * sc_bigint<5>(mul_ln1118_253_fu_31191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_254_fu_31223_p0() {
    mul_ln1118_254_fu_31223_p0 =  (sc_lv<3>) (sext_ln1116_54_fu_23567_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_254_fu_31223_p1() {
    mul_ln1118_254_fu_31223_p1 = tmp_254_fu_31209_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_254_fu_31223_p2() {
    mul_ln1118_254_fu_31223_p2 = (!mul_ln1118_254_fu_31223_p0.read().is_01() || !mul_ln1118_254_fu_31223_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_254_fu_31223_p0.read()) * sc_bigint<5>(mul_ln1118_254_fu_31223_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_255_fu_31255_p0() {
    mul_ln1118_255_fu_31255_p0 =  (sc_lv<3>) (sext_ln1116_55_fu_23611_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_255_fu_31255_p1() {
    mul_ln1118_255_fu_31255_p1 = tmp_255_fu_31241_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_255_fu_31255_p2() {
    mul_ln1118_255_fu_31255_p2 = (!mul_ln1118_255_fu_31255_p0.read().is_01() || !mul_ln1118_255_fu_31255_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_255_fu_31255_p0.read()) * sc_bigint<5>(mul_ln1118_255_fu_31255_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_256_fu_31287_p0() {
    mul_ln1118_256_fu_31287_p0 =  (sc_lv<3>) (sext_ln1116_56_fu_23655_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_256_fu_31287_p1() {
    mul_ln1118_256_fu_31287_p1 = tmp_256_fu_31273_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_256_fu_31287_p2() {
    mul_ln1118_256_fu_31287_p2 = (!mul_ln1118_256_fu_31287_p0.read().is_01() || !mul_ln1118_256_fu_31287_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_256_fu_31287_p0.read()) * sc_bigint<5>(mul_ln1118_256_fu_31287_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_257_fu_31319_p0() {
    mul_ln1118_257_fu_31319_p0 =  (sc_lv<3>) (sext_ln1116_57_fu_23699_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_257_fu_31319_p1() {
    mul_ln1118_257_fu_31319_p1 = tmp_257_fu_31305_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_257_fu_31319_p2() {
    mul_ln1118_257_fu_31319_p2 = (!mul_ln1118_257_fu_31319_p0.read().is_01() || !mul_ln1118_257_fu_31319_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_257_fu_31319_p0.read()) * sc_bigint<5>(mul_ln1118_257_fu_31319_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_258_fu_31351_p0() {
    mul_ln1118_258_fu_31351_p0 =  (sc_lv<3>) (sext_ln1116_58_fu_23743_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_258_fu_31351_p1() {
    mul_ln1118_258_fu_31351_p1 = tmp_258_fu_31337_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_258_fu_31351_p2() {
    mul_ln1118_258_fu_31351_p2 = (!mul_ln1118_258_fu_31351_p0.read().is_01() || !mul_ln1118_258_fu_31351_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_258_fu_31351_p0.read()) * sc_bigint<5>(mul_ln1118_258_fu_31351_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_259_fu_31383_p0() {
    mul_ln1118_259_fu_31383_p0 =  (sc_lv<3>) (sext_ln1116_59_fu_23787_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_259_fu_31383_p1() {
    mul_ln1118_259_fu_31383_p1 = tmp_259_fu_31369_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_259_fu_31383_p2() {
    mul_ln1118_259_fu_31383_p2 = (!mul_ln1118_259_fu_31383_p0.read().is_01() || !mul_ln1118_259_fu_31383_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_259_fu_31383_p0.read()) * sc_bigint<5>(mul_ln1118_259_fu_31383_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_25_fu_22439_p0() {
    mul_ln1118_25_fu_22439_p0 =  (sc_lv<3>) (sext_ln1116_25_fu_22431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_25_fu_22439_p1() {
    mul_ln1118_25_fu_22439_p1 = tmp_25_fu_22421_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_25_fu_22439_p2() {
    mul_ln1118_25_fu_22439_p2 = (!mul_ln1118_25_fu_22439_p0.read().is_01() || !mul_ln1118_25_fu_22439_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_25_fu_22439_p0.read()) * sc_bigint<5>(mul_ln1118_25_fu_22439_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_260_fu_31403_p0() {
    mul_ln1118_260_fu_31403_p0 =  (sc_lv<3>) (sext_ln1116_60_fu_23819_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_260_fu_31403_p1() {
    mul_ln1118_260_fu_31403_p1 = tmp_260_fu_31389_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_260_fu_31403_p2() {
    mul_ln1118_260_fu_31403_p2 = (!mul_ln1118_260_fu_31403_p0.read().is_01() || !mul_ln1118_260_fu_31403_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_260_fu_31403_p0.read()) * sc_bigint<5>(mul_ln1118_260_fu_31403_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_261_fu_31435_p0() {
    mul_ln1118_261_fu_31435_p0 =  (sc_lv<3>) (sext_ln1116_61_fu_23863_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_261_fu_31435_p1() {
    mul_ln1118_261_fu_31435_p1 = tmp_261_fu_31421_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_261_fu_31435_p2() {
    mul_ln1118_261_fu_31435_p2 = (!mul_ln1118_261_fu_31435_p0.read().is_01() || !mul_ln1118_261_fu_31435_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_261_fu_31435_p0.read()) * sc_bigint<5>(mul_ln1118_261_fu_31435_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_262_fu_31467_p0() {
    mul_ln1118_262_fu_31467_p0 =  (sc_lv<3>) (sext_ln1116_62_fu_23907_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_262_fu_31467_p1() {
    mul_ln1118_262_fu_31467_p1 = tmp_262_fu_31453_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_262_fu_31467_p2() {
    mul_ln1118_262_fu_31467_p2 = (!mul_ln1118_262_fu_31467_p0.read().is_01() || !mul_ln1118_262_fu_31467_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_262_fu_31467_p0.read()) * sc_bigint<5>(mul_ln1118_262_fu_31467_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_263_fu_31487_p0() {
    mul_ln1118_263_fu_31487_p0 =  (sc_lv<3>) (sext_ln1116_63_fu_23939_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_263_fu_31487_p1() {
    mul_ln1118_263_fu_31487_p1 = tmp_263_fu_31473_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_263_fu_31487_p2() {
    mul_ln1118_263_fu_31487_p2 = (!mul_ln1118_263_fu_31487_p0.read().is_01() || !mul_ln1118_263_fu_31487_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_263_fu_31487_p0.read()) * sc_bigint<5>(mul_ln1118_263_fu_31487_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_264_fu_31519_p0() {
    mul_ln1118_264_fu_31519_p0 =  (sc_lv<3>) (sext_ln1116_64_fu_23983_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_264_fu_31519_p1() {
    mul_ln1118_264_fu_31519_p1 = tmp_264_fu_31505_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_264_fu_31519_p2() {
    mul_ln1118_264_fu_31519_p2 = (!mul_ln1118_264_fu_31519_p0.read().is_01() || !mul_ln1118_264_fu_31519_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_264_fu_31519_p0.read()) * sc_bigint<5>(mul_ln1118_264_fu_31519_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_265_fu_84753_p0() {
    mul_ln1118_265_fu_84753_p0 =  (sc_lv<3>) (sext_ln1116_65_reg_106014.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_265_fu_84753_p1() {
    mul_ln1118_265_fu_84753_p1 = tmp_265_reg_107013.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_265_fu_84753_p2() {
    mul_ln1118_265_fu_84753_p2 = (!mul_ln1118_265_fu_84753_p0.read().is_01() || !mul_ln1118_265_fu_84753_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_265_fu_84753_p0.read()) * sc_bigint<5>(mul_ln1118_265_fu_84753_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_266_fu_31561_p0() {
    mul_ln1118_266_fu_31561_p0 =  (sc_lv<3>) (sext_ln1116_66_fu_24049_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_266_fu_31561_p1() {
    mul_ln1118_266_fu_31561_p1 = tmp_266_fu_31547_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_266_fu_31561_p2() {
    mul_ln1118_266_fu_31561_p2 = (!mul_ln1118_266_fu_31561_p0.read().is_01() || !mul_ln1118_266_fu_31561_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_266_fu_31561_p0.read()) * sc_bigint<5>(mul_ln1118_266_fu_31561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_267_fu_31593_p0() {
    mul_ln1118_267_fu_31593_p0 =  (sc_lv<3>) (sext_ln1116_67_fu_24093_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_267_fu_31593_p1() {
    mul_ln1118_267_fu_31593_p1 = tmp_267_fu_31579_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_267_fu_31593_p2() {
    mul_ln1118_267_fu_31593_p2 = (!mul_ln1118_267_fu_31593_p0.read().is_01() || !mul_ln1118_267_fu_31593_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_267_fu_31593_p0.read()) * sc_bigint<5>(mul_ln1118_267_fu_31593_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_268_fu_84773_p0() {
    mul_ln1118_268_fu_84773_p0 =  (sc_lv<3>) (sext_ln1116_68_reg_106032.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_268_fu_84773_p1() {
    mul_ln1118_268_fu_84773_p1 = tmp_268_reg_107018.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_268_fu_84773_p2() {
    mul_ln1118_268_fu_84773_p2 = (!mul_ln1118_268_fu_84773_p0.read().is_01() || !mul_ln1118_268_fu_84773_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_268_fu_84773_p0.read()) * sc_bigint<5>(mul_ln1118_268_fu_84773_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_269_fu_31635_p0() {
    mul_ln1118_269_fu_31635_p0 =  (sc_lv<3>) (sext_ln1116_69_fu_24159_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_269_fu_31635_p1() {
    mul_ln1118_269_fu_31635_p1 = tmp_269_fu_31621_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_269_fu_31635_p2() {
    mul_ln1118_269_fu_31635_p2 = (!mul_ln1118_269_fu_31635_p0.read().is_01() || !mul_ln1118_269_fu_31635_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_269_fu_31635_p0.read()) * sc_bigint<5>(mul_ln1118_269_fu_31635_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_26_fu_22483_p0() {
    mul_ln1118_26_fu_22483_p0 =  (sc_lv<3>) (sext_ln1116_26_fu_22475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_26_fu_22483_p1() {
    mul_ln1118_26_fu_22483_p1 = tmp_26_fu_22465_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_26_fu_22483_p2() {
    mul_ln1118_26_fu_22483_p2 = (!mul_ln1118_26_fu_22483_p0.read().is_01() || !mul_ln1118_26_fu_22483_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_26_fu_22483_p0.read()) * sc_bigint<5>(mul_ln1118_26_fu_22483_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_270_fu_31667_p0() {
    mul_ln1118_270_fu_31667_p0 =  (sc_lv<3>) (sext_ln1116_70_fu_24203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_270_fu_31667_p1() {
    mul_ln1118_270_fu_31667_p1 = tmp_270_fu_31653_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_270_fu_31667_p2() {
    mul_ln1118_270_fu_31667_p2 = (!mul_ln1118_270_fu_31667_p0.read().is_01() || !mul_ln1118_270_fu_31667_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_270_fu_31667_p0.read()) * sc_bigint<5>(mul_ln1118_270_fu_31667_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_271_fu_84793_p0() {
    mul_ln1118_271_fu_84793_p0 =  (sc_lv<3>) (sext_ln1116_71_reg_106050.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_271_fu_84793_p1() {
    mul_ln1118_271_fu_84793_p1 = tmp_271_reg_107023.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_271_fu_84793_p2() {
    mul_ln1118_271_fu_84793_p2 = (!mul_ln1118_271_fu_84793_p0.read().is_01() || !mul_ln1118_271_fu_84793_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_271_fu_84793_p0.read()) * sc_bigint<5>(mul_ln1118_271_fu_84793_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_272_fu_31709_p0() {
    mul_ln1118_272_fu_31709_p0 =  (sc_lv<3>) (sext_ln1116_72_fu_24269_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_272_fu_31709_p1() {
    mul_ln1118_272_fu_31709_p1 = tmp_272_fu_31695_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_272_fu_31709_p2() {
    mul_ln1118_272_fu_31709_p2 = (!mul_ln1118_272_fu_31709_p0.read().is_01() || !mul_ln1118_272_fu_31709_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_272_fu_31709_p0.read()) * sc_bigint<5>(mul_ln1118_272_fu_31709_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_273_fu_31741_p0() {
    mul_ln1118_273_fu_31741_p0 =  (sc_lv<3>) (sext_ln1116_73_fu_24313_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_273_fu_31741_p1() {
    mul_ln1118_273_fu_31741_p1 = tmp_273_fu_31727_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_273_fu_31741_p2() {
    mul_ln1118_273_fu_31741_p2 = (!mul_ln1118_273_fu_31741_p0.read().is_01() || !mul_ln1118_273_fu_31741_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_273_fu_31741_p0.read()) * sc_bigint<5>(mul_ln1118_273_fu_31741_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_274_fu_84813_p0() {
    mul_ln1118_274_fu_84813_p0 =  (sc_lv<3>) (sext_ln1116_74_reg_106068.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_274_fu_84813_p1() {
    mul_ln1118_274_fu_84813_p1 = tmp_274_reg_107028.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_274_fu_84813_p2() {
    mul_ln1118_274_fu_84813_p2 = (!mul_ln1118_274_fu_84813_p0.read().is_01() || !mul_ln1118_274_fu_84813_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_274_fu_84813_p0.read()) * sc_bigint<5>(mul_ln1118_274_fu_84813_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_275_fu_31783_p0() {
    mul_ln1118_275_fu_31783_p0 =  (sc_lv<3>) (sext_ln1116_75_fu_24379_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_275_fu_31783_p1() {
    mul_ln1118_275_fu_31783_p1 = tmp_275_fu_31769_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_275_fu_31783_p2() {
    mul_ln1118_275_fu_31783_p2 = (!mul_ln1118_275_fu_31783_p0.read().is_01() || !mul_ln1118_275_fu_31783_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_275_fu_31783_p0.read()) * sc_bigint<5>(mul_ln1118_275_fu_31783_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_276_fu_31815_p0() {
    mul_ln1118_276_fu_31815_p0 =  (sc_lv<3>) (sext_ln1116_76_fu_24423_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_276_fu_31815_p1() {
    mul_ln1118_276_fu_31815_p1 = tmp_276_fu_31801_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_276_fu_31815_p2() {
    mul_ln1118_276_fu_31815_p2 = (!mul_ln1118_276_fu_31815_p0.read().is_01() || !mul_ln1118_276_fu_31815_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_276_fu_31815_p0.read()) * sc_bigint<5>(mul_ln1118_276_fu_31815_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_277_fu_84833_p0() {
    mul_ln1118_277_fu_84833_p0 =  (sc_lv<3>) (sext_ln1116_77_reg_106086.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_277_fu_84833_p1() {
    mul_ln1118_277_fu_84833_p1 = tmp_277_reg_107033.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_277_fu_84833_p2() {
    mul_ln1118_277_fu_84833_p2 = (!mul_ln1118_277_fu_84833_p0.read().is_01() || !mul_ln1118_277_fu_84833_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_277_fu_84833_p0.read()) * sc_bigint<5>(mul_ln1118_277_fu_84833_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_278_fu_31857_p0() {
    mul_ln1118_278_fu_31857_p0 =  (sc_lv<3>) (sext_ln1116_78_fu_24489_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_278_fu_31857_p1() {
    mul_ln1118_278_fu_31857_p1 = tmp_278_fu_31843_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_278_fu_31857_p2() {
    mul_ln1118_278_fu_31857_p2 = (!mul_ln1118_278_fu_31857_p0.read().is_01() || !mul_ln1118_278_fu_31857_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_278_fu_31857_p0.read()) * sc_bigint<5>(mul_ln1118_278_fu_31857_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_279_fu_31889_p0() {
    mul_ln1118_279_fu_31889_p0 =  (sc_lv<3>) (sext_ln1116_79_fu_24533_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_279_fu_31889_p1() {
    mul_ln1118_279_fu_31889_p1 = tmp_279_fu_31875_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_279_fu_31889_p2() {
    mul_ln1118_279_fu_31889_p2 = (!mul_ln1118_279_fu_31889_p0.read().is_01() || !mul_ln1118_279_fu_31889_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_279_fu_31889_p0.read()) * sc_bigint<5>(mul_ln1118_279_fu_31889_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_27_fu_82553_p0() {
    mul_ln1118_27_fu_82553_p0 =  (sc_lv<3>) (sext_ln1116_27_fu_82547_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_27_fu_82553_p1() {
    mul_ln1118_27_fu_82553_p1 = tmp_27_reg_105920.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_27_fu_82553_p2() {
    mul_ln1118_27_fu_82553_p2 = (!mul_ln1118_27_fu_82553_p0.read().is_01() || !mul_ln1118_27_fu_82553_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_27_fu_82553_p0.read()) * sc_bigint<5>(mul_ln1118_27_fu_82553_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_280_fu_31921_p0() {
    mul_ln1118_280_fu_31921_p0 =  (sc_lv<3>) (sext_ln1116_80_fu_24577_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_280_fu_31921_p1() {
    mul_ln1118_280_fu_31921_p1 = tmp_280_fu_31907_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_280_fu_31921_p2() {
    mul_ln1118_280_fu_31921_p2 = (!mul_ln1118_280_fu_31921_p0.read().is_01() || !mul_ln1118_280_fu_31921_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_280_fu_31921_p0.read()) * sc_bigint<5>(mul_ln1118_280_fu_31921_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_281_fu_31953_p0() {
    mul_ln1118_281_fu_31953_p0 =  (sc_lv<3>) (sext_ln1116_81_fu_24621_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_281_fu_31953_p1() {
    mul_ln1118_281_fu_31953_p1 = tmp_281_fu_31939_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_281_fu_31953_p2() {
    mul_ln1118_281_fu_31953_p2 = (!mul_ln1118_281_fu_31953_p0.read().is_01() || !mul_ln1118_281_fu_31953_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_281_fu_31953_p0.read()) * sc_bigint<5>(mul_ln1118_281_fu_31953_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_282_fu_31985_p0() {
    mul_ln1118_282_fu_31985_p0 =  (sc_lv<3>) (sext_ln1116_82_fu_24665_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_282_fu_31985_p1() {
    mul_ln1118_282_fu_31985_p1 = tmp_282_fu_31971_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_282_fu_31985_p2() {
    mul_ln1118_282_fu_31985_p2 = (!mul_ln1118_282_fu_31985_p0.read().is_01() || !mul_ln1118_282_fu_31985_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_282_fu_31985_p0.read()) * sc_bigint<5>(mul_ln1118_282_fu_31985_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_283_fu_32017_p0() {
    mul_ln1118_283_fu_32017_p0 =  (sc_lv<3>) (sext_ln1116_83_fu_24709_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_283_fu_32017_p1() {
    mul_ln1118_283_fu_32017_p1 = tmp_283_fu_32003_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_283_fu_32017_p2() {
    mul_ln1118_283_fu_32017_p2 = (!mul_ln1118_283_fu_32017_p0.read().is_01() || !mul_ln1118_283_fu_32017_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_283_fu_32017_p0.read()) * sc_bigint<5>(mul_ln1118_283_fu_32017_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_284_fu_32049_p0() {
    mul_ln1118_284_fu_32049_p0 =  (sc_lv<3>) (sext_ln1116_84_fu_24753_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_284_fu_32049_p1() {
    mul_ln1118_284_fu_32049_p1 = tmp_284_fu_32035_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_284_fu_32049_p2() {
    mul_ln1118_284_fu_32049_p2 = (!mul_ln1118_284_fu_32049_p0.read().is_01() || !mul_ln1118_284_fu_32049_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_284_fu_32049_p0.read()) * sc_bigint<5>(mul_ln1118_284_fu_32049_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_285_fu_32069_p0() {
    mul_ln1118_285_fu_32069_p0 =  (sc_lv<3>) (sext_ln1116_85_fu_24785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_285_fu_32069_p1() {
    mul_ln1118_285_fu_32069_p1 = tmp_285_fu_32055_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_285_fu_32069_p2() {
    mul_ln1118_285_fu_32069_p2 = (!mul_ln1118_285_fu_32069_p0.read().is_01() || !mul_ln1118_285_fu_32069_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_285_fu_32069_p0.read()) * sc_bigint<5>(mul_ln1118_285_fu_32069_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_286_fu_32101_p0() {
    mul_ln1118_286_fu_32101_p0 =  (sc_lv<3>) (sext_ln1116_86_fu_24829_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_286_fu_32101_p1() {
    mul_ln1118_286_fu_32101_p1 = tmp_286_fu_32087_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_286_fu_32101_p2() {
    mul_ln1118_286_fu_32101_p2 = (!mul_ln1118_286_fu_32101_p0.read().is_01() || !mul_ln1118_286_fu_32101_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_286_fu_32101_p0.read()) * sc_bigint<5>(mul_ln1118_286_fu_32101_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_287_fu_32133_p0() {
    mul_ln1118_287_fu_32133_p0 =  (sc_lv<3>) (sext_ln1116_87_fu_24873_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_287_fu_32133_p1() {
    mul_ln1118_287_fu_32133_p1 = tmp_287_fu_32119_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_287_fu_32133_p2() {
    mul_ln1118_287_fu_32133_p2 = (!mul_ln1118_287_fu_32133_p0.read().is_01() || !mul_ln1118_287_fu_32133_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_287_fu_32133_p0.read()) * sc_bigint<5>(mul_ln1118_287_fu_32133_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_288_fu_32153_p0() {
    mul_ln1118_288_fu_32153_p0 =  (sc_lv<3>) (sext_ln1116_88_fu_24905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_288_fu_32153_p1() {
    mul_ln1118_288_fu_32153_p1 = tmp_288_fu_32139_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_288_fu_32153_p2() {
    mul_ln1118_288_fu_32153_p2 = (!mul_ln1118_288_fu_32153_p0.read().is_01() || !mul_ln1118_288_fu_32153_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_288_fu_32153_p0.read()) * sc_bigint<5>(mul_ln1118_288_fu_32153_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_289_fu_32185_p0() {
    mul_ln1118_289_fu_32185_p0 =  (sc_lv<3>) (sext_ln1116_89_fu_24949_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_289_fu_32185_p1() {
    mul_ln1118_289_fu_32185_p1 = tmp_289_fu_32171_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_289_fu_32185_p2() {
    mul_ln1118_289_fu_32185_p2 = (!mul_ln1118_289_fu_32185_p0.read().is_01() || !mul_ln1118_289_fu_32185_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_289_fu_32185_p0.read()) * sc_bigint<5>(mul_ln1118_289_fu_32185_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_28_fu_22545_p0() {
    mul_ln1118_28_fu_22545_p0 =  (sc_lv<3>) (sext_ln1116_28_fu_22537_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_28_fu_22545_p1() {
    mul_ln1118_28_fu_22545_p1 = tmp_28_fu_22527_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_28_fu_22545_p2() {
    mul_ln1118_28_fu_22545_p2 = (!mul_ln1118_28_fu_22545_p0.read().is_01() || !mul_ln1118_28_fu_22545_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_28_fu_22545_p0.read()) * sc_bigint<5>(mul_ln1118_28_fu_22545_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_290_fu_84875_p0() {
    mul_ln1118_290_fu_84875_p0 =  (sc_lv<3>) (sext_ln1116_90_reg_106114.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_290_fu_84875_p1() {
    mul_ln1118_290_fu_84875_p1 = tmp_290_reg_107048.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_290_fu_84875_p2() {
    mul_ln1118_290_fu_84875_p2 = (!mul_ln1118_290_fu_84875_p0.read().is_01() || !mul_ln1118_290_fu_84875_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_290_fu_84875_p0.read()) * sc_bigint<5>(mul_ln1118_290_fu_84875_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_291_fu_32227_p0() {
    mul_ln1118_291_fu_32227_p0 =  (sc_lv<3>) (sext_ln1116_91_fu_25015_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_291_fu_32227_p1() {
    mul_ln1118_291_fu_32227_p1 = tmp_291_fu_32213_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_291_fu_32227_p2() {
    mul_ln1118_291_fu_32227_p2 = (!mul_ln1118_291_fu_32227_p0.read().is_01() || !mul_ln1118_291_fu_32227_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_291_fu_32227_p0.read()) * sc_bigint<5>(mul_ln1118_291_fu_32227_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_292_fu_32259_p0() {
    mul_ln1118_292_fu_32259_p0 =  (sc_lv<3>) (sext_ln1116_92_fu_25059_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_292_fu_32259_p1() {
    mul_ln1118_292_fu_32259_p1 = tmp_292_fu_32245_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_292_fu_32259_p2() {
    mul_ln1118_292_fu_32259_p2 = (!mul_ln1118_292_fu_32259_p0.read().is_01() || !mul_ln1118_292_fu_32259_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_292_fu_32259_p0.read()) * sc_bigint<5>(mul_ln1118_292_fu_32259_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_293_fu_84895_p0() {
    mul_ln1118_293_fu_84895_p0 =  (sc_lv<3>) (sext_ln1116_93_reg_106132.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_293_fu_84895_p1() {
    mul_ln1118_293_fu_84895_p1 = tmp_293_reg_107053.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_293_fu_84895_p2() {
    mul_ln1118_293_fu_84895_p2 = (!mul_ln1118_293_fu_84895_p0.read().is_01() || !mul_ln1118_293_fu_84895_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_293_fu_84895_p0.read()) * sc_bigint<5>(mul_ln1118_293_fu_84895_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_294_fu_32301_p0() {
    mul_ln1118_294_fu_32301_p0 =  (sc_lv<3>) (sext_ln1116_94_fu_25125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_294_fu_32301_p1() {
    mul_ln1118_294_fu_32301_p1 = tmp_294_fu_32287_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_294_fu_32301_p2() {
    mul_ln1118_294_fu_32301_p2 = (!mul_ln1118_294_fu_32301_p0.read().is_01() || !mul_ln1118_294_fu_32301_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_294_fu_32301_p0.read()) * sc_bigint<5>(mul_ln1118_294_fu_32301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_295_fu_32333_p0() {
    mul_ln1118_295_fu_32333_p0 =  (sc_lv<3>) (sext_ln1116_95_fu_25169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_295_fu_32333_p1() {
    mul_ln1118_295_fu_32333_p1 = tmp_295_fu_32319_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_295_fu_32333_p2() {
    mul_ln1118_295_fu_32333_p2 = (!mul_ln1118_295_fu_32333_p0.read().is_01() || !mul_ln1118_295_fu_32333_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_295_fu_32333_p0.read()) * sc_bigint<5>(mul_ln1118_295_fu_32333_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_296_fu_84915_p0() {
    mul_ln1118_296_fu_84915_p0 =  (sc_lv<3>) (sext_ln1116_96_reg_106150.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_296_fu_84915_p1() {
    mul_ln1118_296_fu_84915_p1 = tmp_296_reg_107058.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_296_fu_84915_p2() {
    mul_ln1118_296_fu_84915_p2 = (!mul_ln1118_296_fu_84915_p0.read().is_01() || !mul_ln1118_296_fu_84915_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_296_fu_84915_p0.read()) * sc_bigint<5>(mul_ln1118_296_fu_84915_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_297_fu_32375_p0() {
    mul_ln1118_297_fu_32375_p0 =  (sc_lv<3>) (sext_ln1116_97_fu_25235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_297_fu_32375_p1() {
    mul_ln1118_297_fu_32375_p1 = tmp_297_fu_32361_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_297_fu_32375_p2() {
    mul_ln1118_297_fu_32375_p2 = (!mul_ln1118_297_fu_32375_p0.read().is_01() || !mul_ln1118_297_fu_32375_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_297_fu_32375_p0.read()) * sc_bigint<5>(mul_ln1118_297_fu_32375_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_298_fu_32407_p0() {
    mul_ln1118_298_fu_32407_p0 =  (sc_lv<3>) (sext_ln1116_98_fu_25279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_298_fu_32407_p1() {
    mul_ln1118_298_fu_32407_p1 = tmp_298_fu_32393_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_298_fu_32407_p2() {
    mul_ln1118_298_fu_32407_p2 = (!mul_ln1118_298_fu_32407_p0.read().is_01() || !mul_ln1118_298_fu_32407_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_298_fu_32407_p0.read()) * sc_bigint<5>(mul_ln1118_298_fu_32407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_299_fu_84935_p0() {
    mul_ln1118_299_fu_84935_p0 =  (sc_lv<3>) (sext_ln1116_99_reg_106168.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_299_fu_84935_p1() {
    mul_ln1118_299_fu_84935_p1 = tmp_299_reg_107063.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_299_fu_84935_p2() {
    mul_ln1118_299_fu_84935_p2 = (!mul_ln1118_299_fu_84935_p0.read().is_01() || !mul_ln1118_299_fu_84935_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_299_fu_84935_p0.read()) * sc_bigint<5>(mul_ln1118_299_fu_84935_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_29_fu_22589_p0() {
    mul_ln1118_29_fu_22589_p0 =  (sc_lv<3>) (sext_ln1116_29_fu_22581_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_29_fu_22589_p1() {
    mul_ln1118_29_fu_22589_p1 = tmp_29_fu_22571_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_29_fu_22589_p2() {
    mul_ln1118_29_fu_22589_p2 = (!mul_ln1118_29_fu_22589_p0.read().is_01() || !mul_ln1118_29_fu_22589_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_29_fu_22589_p0.read()) * sc_bigint<5>(mul_ln1118_29_fu_22589_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_300_fu_32449_p0() {
    mul_ln1118_300_fu_32449_p0 =  (sc_lv<3>) (sext_ln1116_100_fu_25345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_300_fu_32449_p1() {
    mul_ln1118_300_fu_32449_p1 = tmp_300_fu_32435_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_300_fu_32449_p2() {
    mul_ln1118_300_fu_32449_p2 = (!mul_ln1118_300_fu_32449_p0.read().is_01() || !mul_ln1118_300_fu_32449_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_300_fu_32449_p0.read()) * sc_bigint<5>(mul_ln1118_300_fu_32449_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_301_fu_32481_p0() {
    mul_ln1118_301_fu_32481_p0 =  (sc_lv<3>) (sext_ln1116_101_fu_25389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_301_fu_32481_p1() {
    mul_ln1118_301_fu_32481_p1 = tmp_301_fu_32467_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_301_fu_32481_p2() {
    mul_ln1118_301_fu_32481_p2 = (!mul_ln1118_301_fu_32481_p0.read().is_01() || !mul_ln1118_301_fu_32481_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_301_fu_32481_p0.read()) * sc_bigint<5>(mul_ln1118_301_fu_32481_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_302_fu_84955_p0() {
    mul_ln1118_302_fu_84955_p0 =  (sc_lv<3>) (sext_ln1116_102_reg_106186.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_302_fu_84955_p1() {
    mul_ln1118_302_fu_84955_p1 = tmp_302_reg_107068.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_302_fu_84955_p2() {
    mul_ln1118_302_fu_84955_p2 = (!mul_ln1118_302_fu_84955_p0.read().is_01() || !mul_ln1118_302_fu_84955_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_302_fu_84955_p0.read()) * sc_bigint<5>(mul_ln1118_302_fu_84955_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_303_fu_32523_p0() {
    mul_ln1118_303_fu_32523_p0 =  (sc_lv<3>) (sext_ln1116_103_fu_25455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_303_fu_32523_p1() {
    mul_ln1118_303_fu_32523_p1 = tmp_303_fu_32509_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_303_fu_32523_p2() {
    mul_ln1118_303_fu_32523_p2 = (!mul_ln1118_303_fu_32523_p0.read().is_01() || !mul_ln1118_303_fu_32523_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_303_fu_32523_p0.read()) * sc_bigint<5>(mul_ln1118_303_fu_32523_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_304_fu_32555_p0() {
    mul_ln1118_304_fu_32555_p0 =  (sc_lv<3>) (sext_ln1116_104_fu_25499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_304_fu_32555_p1() {
    mul_ln1118_304_fu_32555_p1 = tmp_304_fu_32541_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_304_fu_32555_p2() {
    mul_ln1118_304_fu_32555_p2 = (!mul_ln1118_304_fu_32555_p0.read().is_01() || !mul_ln1118_304_fu_32555_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_304_fu_32555_p0.read()) * sc_bigint<5>(mul_ln1118_304_fu_32555_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_305_fu_32587_p0() {
    mul_ln1118_305_fu_32587_p0 =  (sc_lv<3>) (sext_ln1116_105_fu_25543_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_305_fu_32587_p1() {
    mul_ln1118_305_fu_32587_p1 = tmp_305_fu_32573_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_305_fu_32587_p2() {
    mul_ln1118_305_fu_32587_p2 = (!mul_ln1118_305_fu_32587_p0.read().is_01() || !mul_ln1118_305_fu_32587_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_305_fu_32587_p0.read()) * sc_bigint<5>(mul_ln1118_305_fu_32587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_306_fu_32619_p0() {
    mul_ln1118_306_fu_32619_p0 =  (sc_lv<3>) (sext_ln1116_106_fu_25587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_306_fu_32619_p1() {
    mul_ln1118_306_fu_32619_p1 = tmp_306_fu_32605_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_306_fu_32619_p2() {
    mul_ln1118_306_fu_32619_p2 = (!mul_ln1118_306_fu_32619_p0.read().is_01() || !mul_ln1118_306_fu_32619_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_306_fu_32619_p0.read()) * sc_bigint<5>(mul_ln1118_306_fu_32619_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_307_fu_32651_p0() {
    mul_ln1118_307_fu_32651_p0 =  (sc_lv<3>) (sext_ln1116_107_fu_25631_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_307_fu_32651_p1() {
    mul_ln1118_307_fu_32651_p1 = tmp_307_fu_32637_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_307_fu_32651_p2() {
    mul_ln1118_307_fu_32651_p2 = (!mul_ln1118_307_fu_32651_p0.read().is_01() || !mul_ln1118_307_fu_32651_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_307_fu_32651_p0.read()) * sc_bigint<5>(mul_ln1118_307_fu_32651_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_308_fu_32683_p0() {
    mul_ln1118_308_fu_32683_p0 =  (sc_lv<3>) (sext_ln1116_108_fu_25675_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_308_fu_32683_p1() {
    mul_ln1118_308_fu_32683_p1 = tmp_308_fu_32669_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_308_fu_32683_p2() {
    mul_ln1118_308_fu_32683_p2 = (!mul_ln1118_308_fu_32683_p0.read().is_01() || !mul_ln1118_308_fu_32683_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_308_fu_32683_p0.read()) * sc_bigint<5>(mul_ln1118_308_fu_32683_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_309_fu_32715_p0() {
    mul_ln1118_309_fu_32715_p0 =  (sc_lv<3>) (sext_ln1116_109_fu_25719_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_309_fu_32715_p1() {
    mul_ln1118_309_fu_32715_p1 = tmp_309_fu_32701_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_309_fu_32715_p2() {
    mul_ln1118_309_fu_32715_p2 = (!mul_ln1118_309_fu_32715_p0.read().is_01() || !mul_ln1118_309_fu_32715_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_309_fu_32715_p0.read()) * sc_bigint<5>(mul_ln1118_309_fu_32715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_30_fu_22633_p0() {
    mul_ln1118_30_fu_22633_p0 =  (sc_lv<3>) (sext_ln1116_30_fu_22625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_30_fu_22633_p1() {
    mul_ln1118_30_fu_22633_p1 = tmp_30_fu_22615_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_30_fu_22633_p2() {
    mul_ln1118_30_fu_22633_p2 = (!mul_ln1118_30_fu_22633_p0.read().is_01() || !mul_ln1118_30_fu_22633_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_30_fu_22633_p0.read()) * sc_bigint<5>(mul_ln1118_30_fu_22633_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_310_fu_32735_p0() {
    mul_ln1118_310_fu_32735_p0 =  (sc_lv<3>) (sext_ln1116_110_fu_25751_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_310_fu_32735_p1() {
    mul_ln1118_310_fu_32735_p1 = tmp_310_fu_32721_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_310_fu_32735_p2() {
    mul_ln1118_310_fu_32735_p2 = (!mul_ln1118_310_fu_32735_p0.read().is_01() || !mul_ln1118_310_fu_32735_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_310_fu_32735_p0.read()) * sc_bigint<5>(mul_ln1118_310_fu_32735_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_311_fu_32767_p0() {
    mul_ln1118_311_fu_32767_p0 =  (sc_lv<3>) (sext_ln1116_111_fu_25795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_311_fu_32767_p1() {
    mul_ln1118_311_fu_32767_p1 = tmp_311_fu_32753_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_311_fu_32767_p2() {
    mul_ln1118_311_fu_32767_p2 = (!mul_ln1118_311_fu_32767_p0.read().is_01() || !mul_ln1118_311_fu_32767_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_311_fu_32767_p0.read()) * sc_bigint<5>(mul_ln1118_311_fu_32767_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_312_fu_32799_p0() {
    mul_ln1118_312_fu_32799_p0 =  (sc_lv<3>) (sext_ln1116_112_fu_25839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_312_fu_32799_p1() {
    mul_ln1118_312_fu_32799_p1 = tmp_312_fu_32785_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_312_fu_32799_p2() {
    mul_ln1118_312_fu_32799_p2 = (!mul_ln1118_312_fu_32799_p0.read().is_01() || !mul_ln1118_312_fu_32799_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_312_fu_32799_p0.read()) * sc_bigint<5>(mul_ln1118_312_fu_32799_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_313_fu_32819_p0() {
    mul_ln1118_313_fu_32819_p0 =  (sc_lv<3>) (sext_ln1116_113_fu_25871_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_313_fu_32819_p1() {
    mul_ln1118_313_fu_32819_p1 = tmp_313_fu_32805_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_313_fu_32819_p2() {
    mul_ln1118_313_fu_32819_p2 = (!mul_ln1118_313_fu_32819_p0.read().is_01() || !mul_ln1118_313_fu_32819_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_313_fu_32819_p0.read()) * sc_bigint<5>(mul_ln1118_313_fu_32819_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_314_fu_32851_p0() {
    mul_ln1118_314_fu_32851_p0 =  (sc_lv<3>) (sext_ln1116_114_fu_25915_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_314_fu_32851_p1() {
    mul_ln1118_314_fu_32851_p1 = tmp_314_fu_32837_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_314_fu_32851_p2() {
    mul_ln1118_314_fu_32851_p2 = (!mul_ln1118_314_fu_32851_p0.read().is_01() || !mul_ln1118_314_fu_32851_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_314_fu_32851_p0.read()) * sc_bigint<5>(mul_ln1118_314_fu_32851_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_315_fu_84997_p0() {
    mul_ln1118_315_fu_84997_p0 =  (sc_lv<3>) (sext_ln1116_115_reg_106214.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_315_fu_84997_p1() {
    mul_ln1118_315_fu_84997_p1 = tmp_315_reg_107083.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_315_fu_84997_p2() {
    mul_ln1118_315_fu_84997_p2 = (!mul_ln1118_315_fu_84997_p0.read().is_01() || !mul_ln1118_315_fu_84997_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_315_fu_84997_p0.read()) * sc_bigint<5>(mul_ln1118_315_fu_84997_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_316_fu_32893_p0() {
    mul_ln1118_316_fu_32893_p0 =  (sc_lv<3>) (sext_ln1116_116_fu_25981_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_316_fu_32893_p1() {
    mul_ln1118_316_fu_32893_p1 = tmp_316_fu_32879_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_316_fu_32893_p2() {
    mul_ln1118_316_fu_32893_p2 = (!mul_ln1118_316_fu_32893_p0.read().is_01() || !mul_ln1118_316_fu_32893_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_316_fu_32893_p0.read()) * sc_bigint<5>(mul_ln1118_316_fu_32893_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_317_fu_32925_p0() {
    mul_ln1118_317_fu_32925_p0 =  (sc_lv<3>) (sext_ln1116_117_fu_26025_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_317_fu_32925_p1() {
    mul_ln1118_317_fu_32925_p1 = tmp_317_fu_32911_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_317_fu_32925_p2() {
    mul_ln1118_317_fu_32925_p2 = (!mul_ln1118_317_fu_32925_p0.read().is_01() || !mul_ln1118_317_fu_32925_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_317_fu_32925_p0.read()) * sc_bigint<5>(mul_ln1118_317_fu_32925_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_318_fu_85017_p0() {
    mul_ln1118_318_fu_85017_p0 =  (sc_lv<3>) (sext_ln1116_118_reg_106232.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_318_fu_85017_p1() {
    mul_ln1118_318_fu_85017_p1 = tmp_318_reg_107088.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_318_fu_85017_p2() {
    mul_ln1118_318_fu_85017_p2 = (!mul_ln1118_318_fu_85017_p0.read().is_01() || !mul_ln1118_318_fu_85017_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_318_fu_85017_p0.read()) * sc_bigint<5>(mul_ln1118_318_fu_85017_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_319_fu_32967_p0() {
    mul_ln1118_319_fu_32967_p0 =  (sc_lv<3>) (sext_ln1116_119_fu_26091_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_319_fu_32967_p1() {
    mul_ln1118_319_fu_32967_p1 = tmp_319_fu_32953_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_319_fu_32967_p2() {
    mul_ln1118_319_fu_32967_p2 = (!mul_ln1118_319_fu_32967_p0.read().is_01() || !mul_ln1118_319_fu_32967_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_319_fu_32967_p0.read()) * sc_bigint<5>(mul_ln1118_319_fu_32967_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_31_fu_22677_p0() {
    mul_ln1118_31_fu_22677_p0 =  (sc_lv<3>) (sext_ln1116_31_fu_22669_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_31_fu_22677_p1() {
    mul_ln1118_31_fu_22677_p1 = tmp_31_fu_22659_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_31_fu_22677_p2() {
    mul_ln1118_31_fu_22677_p2 = (!mul_ln1118_31_fu_22677_p0.read().is_01() || !mul_ln1118_31_fu_22677_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_31_fu_22677_p0.read()) * sc_bigint<5>(mul_ln1118_31_fu_22677_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_320_fu_32999_p0() {
    mul_ln1118_320_fu_32999_p0 =  (sc_lv<3>) (sext_ln1116_120_fu_26135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_320_fu_32999_p1() {
    mul_ln1118_320_fu_32999_p1 = tmp_320_fu_32985_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_320_fu_32999_p2() {
    mul_ln1118_320_fu_32999_p2 = (!mul_ln1118_320_fu_32999_p0.read().is_01() || !mul_ln1118_320_fu_32999_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_320_fu_32999_p0.read()) * sc_bigint<5>(mul_ln1118_320_fu_32999_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_321_fu_85037_p0() {
    mul_ln1118_321_fu_85037_p0 =  (sc_lv<3>) (sext_ln1116_121_reg_106250.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_321_fu_85037_p1() {
    mul_ln1118_321_fu_85037_p1 = tmp_321_reg_107093.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_321_fu_85037_p2() {
    mul_ln1118_321_fu_85037_p2 = (!mul_ln1118_321_fu_85037_p0.read().is_01() || !mul_ln1118_321_fu_85037_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_321_fu_85037_p0.read()) * sc_bigint<5>(mul_ln1118_321_fu_85037_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_322_fu_33041_p0() {
    mul_ln1118_322_fu_33041_p0 =  (sc_lv<3>) (sext_ln1116_122_fu_26201_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_322_fu_33041_p1() {
    mul_ln1118_322_fu_33041_p1 = tmp_322_fu_33027_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_322_fu_33041_p2() {
    mul_ln1118_322_fu_33041_p2 = (!mul_ln1118_322_fu_33041_p0.read().is_01() || !mul_ln1118_322_fu_33041_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_322_fu_33041_p0.read()) * sc_bigint<5>(mul_ln1118_322_fu_33041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_323_fu_33073_p0() {
    mul_ln1118_323_fu_33073_p0 =  (sc_lv<3>) (sext_ln1116_123_fu_26245_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_323_fu_33073_p1() {
    mul_ln1118_323_fu_33073_p1 = tmp_323_fu_33059_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_323_fu_33073_p2() {
    mul_ln1118_323_fu_33073_p2 = (!mul_ln1118_323_fu_33073_p0.read().is_01() || !mul_ln1118_323_fu_33073_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_323_fu_33073_p0.read()) * sc_bigint<5>(mul_ln1118_323_fu_33073_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_324_fu_85057_p0() {
    mul_ln1118_324_fu_85057_p0 =  (sc_lv<3>) (sext_ln1116_124_reg_106268.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_324_fu_85057_p1() {
    mul_ln1118_324_fu_85057_p1 = tmp_324_reg_107098.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_324_fu_85057_p2() {
    mul_ln1118_324_fu_85057_p2 = (!mul_ln1118_324_fu_85057_p0.read().is_01() || !mul_ln1118_324_fu_85057_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_324_fu_85057_p0.read()) * sc_bigint<5>(mul_ln1118_324_fu_85057_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_325_fu_33115_p0() {
    mul_ln1118_325_fu_33115_p0 =  (sc_lv<3>) (sext_ln1116_125_fu_26311_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_325_fu_33115_p1() {
    mul_ln1118_325_fu_33115_p1 = tmp_325_fu_33101_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_325_fu_33115_p2() {
    mul_ln1118_325_fu_33115_p2 = (!mul_ln1118_325_fu_33115_p0.read().is_01() || !mul_ln1118_325_fu_33115_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_325_fu_33115_p0.read()) * sc_bigint<5>(mul_ln1118_325_fu_33115_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_326_fu_33147_p0() {
    mul_ln1118_326_fu_33147_p0 =  (sc_lv<3>) (sext_ln1116_126_fu_26355_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_326_fu_33147_p1() {
    mul_ln1118_326_fu_33147_p1 = tmp_326_fu_33133_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_326_fu_33147_p2() {
    mul_ln1118_326_fu_33147_p2 = (!mul_ln1118_326_fu_33147_p0.read().is_01() || !mul_ln1118_326_fu_33147_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_326_fu_33147_p0.read()) * sc_bigint<5>(mul_ln1118_326_fu_33147_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_327_fu_85077_p0() {
    mul_ln1118_327_fu_85077_p0 =  (sc_lv<3>) (sext_ln1116_127_reg_106286.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_327_fu_85077_p1() {
    mul_ln1118_327_fu_85077_p1 = tmp_327_reg_107103.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_327_fu_85077_p2() {
    mul_ln1118_327_fu_85077_p2 = (!mul_ln1118_327_fu_85077_p0.read().is_01() || !mul_ln1118_327_fu_85077_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_327_fu_85077_p0.read()) * sc_bigint<5>(mul_ln1118_327_fu_85077_p1.read());
}

}

