#include "dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1531_fu_82435_p2() {
    mul_ln1118_1531_fu_82435_p2 = (!mul_ln1118_1531_fu_82435_p0.read().is_01() || !mul_ln1118_1531_fu_82435_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1531_fu_82435_p0.read()) * sc_bigint<5>(mul_ln1118_1531_fu_82435_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1532_fu_45535_p0() {
    mul_ln1118_1532_fu_45535_p0 =  (sc_lv<12>) (sext_ln1116_132_cast_fu_24659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1532_fu_45535_p1() {
    mul_ln1118_1532_fu_45535_p1 = tmp_1532_fu_45521_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1532_fu_45535_p2() {
    mul_ln1118_1532_fu_45535_p2 = (!mul_ln1118_1532_fu_45535_p0.read().is_01() || !mul_ln1118_1532_fu_45535_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1532_fu_45535_p0.read()) * sc_bigint<5>(mul_ln1118_1532_fu_45535_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1533_fu_45565_p0() {
    mul_ln1118_1533_fu_45565_p0 =  (sc_lv<12>) (sext_ln1116_133_cast_fu_24701_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1533_fu_45565_p1() {
    mul_ln1118_1533_fu_45565_p1 = tmp_1533_fu_45551_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1533_fu_45565_p2() {
    mul_ln1118_1533_fu_45565_p2 = (!mul_ln1118_1533_fu_45565_p0.read().is_01() || !mul_ln1118_1533_fu_45565_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1533_fu_45565_p0.read()) * sc_bigint<5>(mul_ln1118_1533_fu_45565_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1534_fu_82454_p0() {
    mul_ln1118_1534_fu_82454_p0 =  (sc_lv<12>) (sext_ln1116_134_cast_fu_54697_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1534_fu_82454_p1() {
    mul_ln1118_1534_fu_82454_p1 = tmp_1534_reg_104227.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1534_fu_82454_p2() {
    mul_ln1118_1534_fu_82454_p2 = (!mul_ln1118_1534_fu_82454_p0.read().is_01() || !mul_ln1118_1534_fu_82454_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1534_fu_82454_p0.read()) * sc_bigint<5>(mul_ln1118_1534_fu_82454_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1535_fu_82473_p0() {
    mul_ln1118_1535_fu_82473_p0 =  (sc_lv<12>) (sext_ln1116_135_cast_fu_54719_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1535_fu_82473_p1() {
    mul_ln1118_1535_fu_82473_p1 = tmp_1535_reg_104232.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1535_fu_82473_p2() {
    mul_ln1118_1535_fu_82473_p2 = (!mul_ln1118_1535_fu_82473_p0.read().is_01() || !mul_ln1118_1535_fu_82473_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1535_fu_82473_p0.read()) * sc_bigint<5>(mul_ln1118_1535_fu_82473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1536_fu_82492_p0() {
    mul_ln1118_1536_fu_82492_p0 =  (sc_lv<12>) (sext_ln1116_136_cast_fu_54741_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1536_fu_82492_p1() {
    mul_ln1118_1536_fu_82492_p1 = tmp_1536_reg_104237.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1536_fu_82492_p2() {
    mul_ln1118_1536_fu_82492_p2 = (!mul_ln1118_1536_fu_82492_p0.read().is_01() || !mul_ln1118_1536_fu_82492_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1536_fu_82492_p0.read()) * sc_bigint<5>(mul_ln1118_1536_fu_82492_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1537_fu_82511_p0() {
    mul_ln1118_1537_fu_82511_p0 =  (sc_lv<12>) (sext_ln1116_137_cast_fu_54763_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1537_fu_82511_p1() {
    mul_ln1118_1537_fu_82511_p1 = tmp_1537_reg_104242.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1537_fu_82511_p2() {
    mul_ln1118_1537_fu_82511_p2 = (!mul_ln1118_1537_fu_82511_p0.read().is_01() || !mul_ln1118_1537_fu_82511_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1537_fu_82511_p0.read()) * sc_bigint<5>(mul_ln1118_1537_fu_82511_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1538_fu_82530_p0() {
    mul_ln1118_1538_fu_82530_p0 =  (sc_lv<12>) (sext_ln1116_138_cast_fu_54785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1538_fu_82530_p1() {
    mul_ln1118_1538_fu_82530_p1 = tmp_1538_reg_104247.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1538_fu_82530_p2() {
    mul_ln1118_1538_fu_82530_p2 = (!mul_ln1118_1538_fu_82530_p0.read().is_01() || !mul_ln1118_1538_fu_82530_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1538_fu_82530_p0.read()) * sc_bigint<5>(mul_ln1118_1538_fu_82530_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1539_fu_82549_p0() {
    mul_ln1118_1539_fu_82549_p0 =  (sc_lv<12>) (sext_ln1116_139_cast_fu_54807_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1539_fu_82549_p1() {
    mul_ln1118_1539_fu_82549_p1 = tmp_1539_reg_104252.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1539_fu_82549_p2() {
    mul_ln1118_1539_fu_82549_p2 = (!mul_ln1118_1539_fu_82549_p0.read().is_01() || !mul_ln1118_1539_fu_82549_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1539_fu_82549_p0.read()) * sc_bigint<5>(mul_ln1118_1539_fu_82549_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_153_fu_25101_p0() {
    mul_ln1118_153_fu_25101_p0 =  (sc_lv<12>) (sext_ln1116_153_cast_fu_25093_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_153_fu_25101_p1() {
    mul_ln1118_153_fu_25101_p1 = tmp_153_fu_25083_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_153_fu_25101_p2() {
    mul_ln1118_153_fu_25101_p2 = (!mul_ln1118_153_fu_25101_p0.read().is_01() || !mul_ln1118_153_fu_25101_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_153_fu_25101_p0.read()) * sc_bigint<5>(mul_ln1118_153_fu_25101_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1540_fu_82568_p0() {
    mul_ln1118_1540_fu_82568_p0 =  (sc_lv<12>) (sext_ln1116_140_cast_fu_54829_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1540_fu_82568_p1() {
    mul_ln1118_1540_fu_82568_p1 = tmp_1540_reg_104257.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1540_fu_82568_p2() {
    mul_ln1118_1540_fu_82568_p2 = (!mul_ln1118_1540_fu_82568_p0.read().is_01() || !mul_ln1118_1540_fu_82568_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1540_fu_82568_p0.read()) * sc_bigint<5>(mul_ln1118_1540_fu_82568_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1541_fu_82587_p0() {
    mul_ln1118_1541_fu_82587_p0 =  (sc_lv<12>) (sext_ln1116_141_cast_fu_54851_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1541_fu_82587_p1() {
    mul_ln1118_1541_fu_82587_p1 = tmp_1541_reg_104262.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1541_fu_82587_p2() {
    mul_ln1118_1541_fu_82587_p2 = (!mul_ln1118_1541_fu_82587_p0.read().is_01() || !mul_ln1118_1541_fu_82587_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1541_fu_82587_p0.read()) * sc_bigint<5>(mul_ln1118_1541_fu_82587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1542_fu_82606_p0() {
    mul_ln1118_1542_fu_82606_p0 =  (sc_lv<12>) (sext_ln1116_142_cast_fu_54873_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1542_fu_82606_p1() {
    mul_ln1118_1542_fu_82606_p1 = tmp_1542_reg_104267.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1542_fu_82606_p2() {
    mul_ln1118_1542_fu_82606_p2 = (!mul_ln1118_1542_fu_82606_p0.read().is_01() || !mul_ln1118_1542_fu_82606_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1542_fu_82606_p0.read()) * sc_bigint<5>(mul_ln1118_1542_fu_82606_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1543_fu_82625_p0() {
    mul_ln1118_1543_fu_82625_p0 =  (sc_lv<12>) (sext_ln1116_143_cast_fu_54895_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1543_fu_82625_p1() {
    mul_ln1118_1543_fu_82625_p1 = tmp_1543_reg_104272.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1543_fu_82625_p2() {
    mul_ln1118_1543_fu_82625_p2 = (!mul_ln1118_1543_fu_82625_p0.read().is_01() || !mul_ln1118_1543_fu_82625_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1543_fu_82625_p0.read()) * sc_bigint<5>(mul_ln1118_1543_fu_82625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1544_fu_82644_p0() {
    mul_ln1118_1544_fu_82644_p0 =  (sc_lv<12>) (sext_ln1116_144_cast_fu_54917_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1544_fu_82644_p1() {
    mul_ln1118_1544_fu_82644_p1 = tmp_1544_reg_104277.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1544_fu_82644_p2() {
    mul_ln1118_1544_fu_82644_p2 = (!mul_ln1118_1544_fu_82644_p0.read().is_01() || !mul_ln1118_1544_fu_82644_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1544_fu_82644_p0.read()) * sc_bigint<5>(mul_ln1118_1544_fu_82644_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1545_fu_82663_p0() {
    mul_ln1118_1545_fu_82663_p0 =  (sc_lv<12>) (sext_ln1116_145_cast_fu_54939_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1545_fu_82663_p1() {
    mul_ln1118_1545_fu_82663_p1 = tmp_1545_reg_104282.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1545_fu_82663_p2() {
    mul_ln1118_1545_fu_82663_p2 = (!mul_ln1118_1545_fu_82663_p0.read().is_01() || !mul_ln1118_1545_fu_82663_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1545_fu_82663_p0.read()) * sc_bigint<5>(mul_ln1118_1545_fu_82663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1546_fu_82682_p0() {
    mul_ln1118_1546_fu_82682_p0 =  (sc_lv<12>) (sext_ln1116_146_cast_fu_54961_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1546_fu_82682_p1() {
    mul_ln1118_1546_fu_82682_p1 = tmp_1546_reg_104287.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1546_fu_82682_p2() {
    mul_ln1118_1546_fu_82682_p2 = (!mul_ln1118_1546_fu_82682_p0.read().is_01() || !mul_ln1118_1546_fu_82682_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1546_fu_82682_p0.read()) * sc_bigint<5>(mul_ln1118_1546_fu_82682_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1547_fu_82701_p0() {
    mul_ln1118_1547_fu_82701_p0 =  (sc_lv<12>) (sext_ln1116_147_cast_fu_54983_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1547_fu_82701_p1() {
    mul_ln1118_1547_fu_82701_p1 = tmp_1547_reg_104292.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1547_fu_82701_p2() {
    mul_ln1118_1547_fu_82701_p2 = (!mul_ln1118_1547_fu_82701_p0.read().is_01() || !mul_ln1118_1547_fu_82701_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1547_fu_82701_p0.read()) * sc_bigint<5>(mul_ln1118_1547_fu_82701_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1548_fu_82720_p0() {
    mul_ln1118_1548_fu_82720_p0 =  (sc_lv<12>) (sext_ln1116_148_cast_fu_55005_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1548_fu_82720_p1() {
    mul_ln1118_1548_fu_82720_p1 = tmp_1548_reg_104297.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1548_fu_82720_p2() {
    mul_ln1118_1548_fu_82720_p2 = (!mul_ln1118_1548_fu_82720_p0.read().is_01() || !mul_ln1118_1548_fu_82720_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1548_fu_82720_p0.read()) * sc_bigint<5>(mul_ln1118_1548_fu_82720_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1549_fu_82739_p0() {
    mul_ln1118_1549_fu_82739_p0 =  (sc_lv<12>) (sext_ln1116_149_cast_fu_55027_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1549_fu_82739_p1() {
    mul_ln1118_1549_fu_82739_p1 = tmp_1549_reg_104302.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1549_fu_82739_p2() {
    mul_ln1118_1549_fu_82739_p2 = (!mul_ln1118_1549_fu_82739_p0.read().is_01() || !mul_ln1118_1549_fu_82739_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1549_fu_82739_p0.read()) * sc_bigint<5>(mul_ln1118_1549_fu_82739_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_154_fu_25143_p0() {
    mul_ln1118_154_fu_25143_p0 =  (sc_lv<12>) (sext_ln1116_154_cast_fu_25135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_154_fu_25143_p1() {
    mul_ln1118_154_fu_25143_p1 = tmp_154_fu_25125_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_154_fu_25143_p2() {
    mul_ln1118_154_fu_25143_p2 = (!mul_ln1118_154_fu_25143_p0.read().is_01() || !mul_ln1118_154_fu_25143_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_154_fu_25143_p0.read()) * sc_bigint<5>(mul_ln1118_154_fu_25143_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1550_fu_82758_p0() {
    mul_ln1118_1550_fu_82758_p0 =  (sc_lv<12>) (sext_ln1116_150_cast_fu_55049_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1550_fu_82758_p1() {
    mul_ln1118_1550_fu_82758_p1 = tmp_1550_reg_104307.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1550_fu_82758_p2() {
    mul_ln1118_1550_fu_82758_p2 = (!mul_ln1118_1550_fu_82758_p0.read().is_01() || !mul_ln1118_1550_fu_82758_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1550_fu_82758_p0.read()) * sc_bigint<5>(mul_ln1118_1550_fu_82758_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1551_fu_82777_p0() {
    mul_ln1118_1551_fu_82777_p0 =  (sc_lv<12>) (sext_ln1116_151_cast_reg_97064.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1551_fu_82777_p1() {
    mul_ln1118_1551_fu_82777_p1 = tmp_1551_reg_104312.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1551_fu_82777_p2() {
    mul_ln1118_1551_fu_82777_p2 = (!mul_ln1118_1551_fu_82777_p0.read().is_01() || !mul_ln1118_1551_fu_82777_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1551_fu_82777_p0.read()) * sc_bigint<5>(mul_ln1118_1551_fu_82777_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1552_fu_82795_p0() {
    mul_ln1118_1552_fu_82795_p0 =  (sc_lv<12>) (sext_ln1116_152_cast_reg_97082.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1552_fu_82795_p1() {
    mul_ln1118_1552_fu_82795_p1 = tmp_1552_reg_104317.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1552_fu_82795_p2() {
    mul_ln1118_1552_fu_82795_p2 = (!mul_ln1118_1552_fu_82795_p0.read().is_01() || !mul_ln1118_1552_fu_82795_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1552_fu_82795_p0.read()) * sc_bigint<5>(mul_ln1118_1552_fu_82795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1553_fu_45785_p0() {
    mul_ln1118_1553_fu_45785_p0 =  (sc_lv<12>) (sext_ln1116_153_cast_fu_25093_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1553_fu_45785_p1() {
    mul_ln1118_1553_fu_45785_p1 = tmp_1553_fu_45771_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1553_fu_45785_p2() {
    mul_ln1118_1553_fu_45785_p2 = (!mul_ln1118_1553_fu_45785_p0.read().is_01() || !mul_ln1118_1553_fu_45785_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1553_fu_45785_p0.read()) * sc_bigint<5>(mul_ln1118_1553_fu_45785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1554_fu_45815_p0() {
    mul_ln1118_1554_fu_45815_p0 =  (sc_lv<12>) (sext_ln1116_154_cast_fu_25135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1554_fu_45815_p1() {
    mul_ln1118_1554_fu_45815_p1 = tmp_1554_fu_45801_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1554_fu_45815_p2() {
    mul_ln1118_1554_fu_45815_p2 = (!mul_ln1118_1554_fu_45815_p0.read().is_01() || !mul_ln1118_1554_fu_45815_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1554_fu_45815_p0.read()) * sc_bigint<5>(mul_ln1118_1554_fu_45815_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1555_fu_45845_p0() {
    mul_ln1118_1555_fu_45845_p0 =  (sc_lv<12>) (sext_ln1116_155_cast_fu_25177_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1555_fu_45845_p1() {
    mul_ln1118_1555_fu_45845_p1 = tmp_1555_fu_45831_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1555_fu_45845_p2() {
    mul_ln1118_1555_fu_45845_p2 = (!mul_ln1118_1555_fu_45845_p0.read().is_01() || !mul_ln1118_1555_fu_45845_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1555_fu_45845_p0.read()) * sc_bigint<5>(mul_ln1118_1555_fu_45845_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1556_fu_45875_p0() {
    mul_ln1118_1556_fu_45875_p0 =  (sc_lv<12>) (sext_ln1116_156_cast_fu_25219_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1556_fu_45875_p1() {
    mul_ln1118_1556_fu_45875_p1 = tmp_1556_fu_45861_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1556_fu_45875_p2() {
    mul_ln1118_1556_fu_45875_p2 = (!mul_ln1118_1556_fu_45875_p0.read().is_01() || !mul_ln1118_1556_fu_45875_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1556_fu_45875_p0.read()) * sc_bigint<5>(mul_ln1118_1556_fu_45875_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1557_fu_45905_p0() {
    mul_ln1118_1557_fu_45905_p0 =  (sc_lv<12>) (sext_ln1116_157_cast_fu_25261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1557_fu_45905_p1() {
    mul_ln1118_1557_fu_45905_p1 = tmp_1557_fu_45891_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1557_fu_45905_p2() {
    mul_ln1118_1557_fu_45905_p2 = (!mul_ln1118_1557_fu_45905_p0.read().is_01() || !mul_ln1118_1557_fu_45905_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1557_fu_45905_p0.read()) * sc_bigint<5>(mul_ln1118_1557_fu_45905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1558_fu_45935_p0() {
    mul_ln1118_1558_fu_45935_p0 =  (sc_lv<12>) (sext_ln1116_158_cast_fu_25303_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1558_fu_45935_p1() {
    mul_ln1118_1558_fu_45935_p1 = tmp_1558_fu_45921_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1558_fu_45935_p2() {
    mul_ln1118_1558_fu_45935_p2 = (!mul_ln1118_1558_fu_45935_p0.read().is_01() || !mul_ln1118_1558_fu_45935_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1558_fu_45935_p0.read()) * sc_bigint<5>(mul_ln1118_1558_fu_45935_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1559_fu_82813_p0() {
    mul_ln1118_1559_fu_82813_p0 =  (sc_lv<12>) (sext_ln1116_159_cast_fu_55107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1559_fu_82813_p1() {
    mul_ln1118_1559_fu_82813_p1 = tmp_1559_reg_104352.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1559_fu_82813_p2() {
    mul_ln1118_1559_fu_82813_p2 = (!mul_ln1118_1559_fu_82813_p0.read().is_01() || !mul_ln1118_1559_fu_82813_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1559_fu_82813_p0.read()) * sc_bigint<5>(mul_ln1118_1559_fu_82813_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_155_fu_25185_p0() {
    mul_ln1118_155_fu_25185_p0 =  (sc_lv<12>) (sext_ln1116_155_cast_fu_25177_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_155_fu_25185_p1() {
    mul_ln1118_155_fu_25185_p1 = tmp_155_fu_25167_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_155_fu_25185_p2() {
    mul_ln1118_155_fu_25185_p2 = (!mul_ln1118_155_fu_25185_p0.read().is_01() || !mul_ln1118_155_fu_25185_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_155_fu_25185_p0.read()) * sc_bigint<5>(mul_ln1118_155_fu_25185_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1560_fu_82832_p0() {
    mul_ln1118_1560_fu_82832_p0 =  (sc_lv<12>) (sext_ln1116_160_cast_fu_55129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1560_fu_82832_p1() {
    mul_ln1118_1560_fu_82832_p1 = tmp_1560_reg_104357.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1560_fu_82832_p2() {
    mul_ln1118_1560_fu_82832_p2 = (!mul_ln1118_1560_fu_82832_p0.read().is_01() || !mul_ln1118_1560_fu_82832_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1560_fu_82832_p0.read()) * sc_bigint<5>(mul_ln1118_1560_fu_82832_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1561_fu_82851_p0() {
    mul_ln1118_1561_fu_82851_p0 =  (sc_lv<12>) (sext_ln1116_161_cast_fu_55151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1561_fu_82851_p1() {
    mul_ln1118_1561_fu_82851_p1 = tmp_1561_reg_104362.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1561_fu_82851_p2() {
    mul_ln1118_1561_fu_82851_p2 = (!mul_ln1118_1561_fu_82851_p0.read().is_01() || !mul_ln1118_1561_fu_82851_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1561_fu_82851_p0.read()) * sc_bigint<5>(mul_ln1118_1561_fu_82851_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1562_fu_82870_p0() {
    mul_ln1118_1562_fu_82870_p0 =  (sc_lv<12>) (sext_ln1116_162_cast_fu_55173_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1562_fu_82870_p1() {
    mul_ln1118_1562_fu_82870_p1 = tmp_1562_reg_104367.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1562_fu_82870_p2() {
    mul_ln1118_1562_fu_82870_p2 = (!mul_ln1118_1562_fu_82870_p0.read().is_01() || !mul_ln1118_1562_fu_82870_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1562_fu_82870_p0.read()) * sc_bigint<5>(mul_ln1118_1562_fu_82870_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1563_fu_82889_p0() {
    mul_ln1118_1563_fu_82889_p0 =  (sc_lv<12>) (sext_ln1116_163_cast_fu_55195_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1563_fu_82889_p1() {
    mul_ln1118_1563_fu_82889_p1 = tmp_1563_reg_104372.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1563_fu_82889_p2() {
    mul_ln1118_1563_fu_82889_p2 = (!mul_ln1118_1563_fu_82889_p0.read().is_01() || !mul_ln1118_1563_fu_82889_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1563_fu_82889_p0.read()) * sc_bigint<5>(mul_ln1118_1563_fu_82889_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1564_fu_82908_p0() {
    mul_ln1118_1564_fu_82908_p0 =  (sc_lv<12>) (sext_ln1116_164_cast_fu_55217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1564_fu_82908_p1() {
    mul_ln1118_1564_fu_82908_p1 = tmp_1564_reg_104377.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1564_fu_82908_p2() {
    mul_ln1118_1564_fu_82908_p2 = (!mul_ln1118_1564_fu_82908_p0.read().is_01() || !mul_ln1118_1564_fu_82908_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1564_fu_82908_p0.read()) * sc_bigint<5>(mul_ln1118_1564_fu_82908_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1565_fu_82927_p0() {
    mul_ln1118_1565_fu_82927_p0 =  (sc_lv<12>) (sext_ln1116_165_cast_fu_55239_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1565_fu_82927_p1() {
    mul_ln1118_1565_fu_82927_p1 = tmp_1565_reg_104382.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1565_fu_82927_p2() {
    mul_ln1118_1565_fu_82927_p2 = (!mul_ln1118_1565_fu_82927_p0.read().is_01() || !mul_ln1118_1565_fu_82927_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1565_fu_82927_p0.read()) * sc_bigint<5>(mul_ln1118_1565_fu_82927_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1566_fu_82946_p0() {
    mul_ln1118_1566_fu_82946_p0 =  (sc_lv<12>) (sext_ln1116_166_cast_fu_55261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1566_fu_82946_p1() {
    mul_ln1118_1566_fu_82946_p1 = tmp_1566_reg_104387.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1566_fu_82946_p2() {
    mul_ln1118_1566_fu_82946_p2 = (!mul_ln1118_1566_fu_82946_p0.read().is_01() || !mul_ln1118_1566_fu_82946_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1566_fu_82946_p0.read()) * sc_bigint<5>(mul_ln1118_1566_fu_82946_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1567_fu_82965_p0() {
    mul_ln1118_1567_fu_82965_p0 =  (sc_lv<12>) (sext_ln1116_167_cast_fu_55283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1567_fu_82965_p1() {
    mul_ln1118_1567_fu_82965_p1 = tmp_1567_reg_104392.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1567_fu_82965_p2() {
    mul_ln1118_1567_fu_82965_p2 = (!mul_ln1118_1567_fu_82965_p0.read().is_01() || !mul_ln1118_1567_fu_82965_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1567_fu_82965_p0.read()) * sc_bigint<5>(mul_ln1118_1567_fu_82965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1568_fu_82984_p0() {
    mul_ln1118_1568_fu_82984_p0 =  (sc_lv<12>) (sext_ln1116_168_cast_fu_55305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1568_fu_82984_p1() {
    mul_ln1118_1568_fu_82984_p1 = tmp_1568_reg_104397.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1568_fu_82984_p2() {
    mul_ln1118_1568_fu_82984_p2 = (!mul_ln1118_1568_fu_82984_p0.read().is_01() || !mul_ln1118_1568_fu_82984_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1568_fu_82984_p0.read()) * sc_bigint<5>(mul_ln1118_1568_fu_82984_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1569_fu_83003_p0() {
    mul_ln1118_1569_fu_83003_p0 =  (sc_lv<12>) (sext_ln1116_169_cast_fu_55327_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1569_fu_83003_p1() {
    mul_ln1118_1569_fu_83003_p1 = tmp_1569_reg_104402.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1569_fu_83003_p2() {
    mul_ln1118_1569_fu_83003_p2 = (!mul_ln1118_1569_fu_83003_p0.read().is_01() || !mul_ln1118_1569_fu_83003_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1569_fu_83003_p0.read()) * sc_bigint<5>(mul_ln1118_1569_fu_83003_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_156_fu_25227_p0() {
    mul_ln1118_156_fu_25227_p0 =  (sc_lv<12>) (sext_ln1116_156_cast_fu_25219_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_156_fu_25227_p1() {
    mul_ln1118_156_fu_25227_p1 = tmp_156_fu_25209_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_156_fu_25227_p2() {
    mul_ln1118_156_fu_25227_p2 = (!mul_ln1118_156_fu_25227_p0.read().is_01() || !mul_ln1118_156_fu_25227_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_156_fu_25227_p0.read()) * sc_bigint<5>(mul_ln1118_156_fu_25227_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1570_fu_83022_p0() {
    mul_ln1118_1570_fu_83022_p0 =  (sc_lv<12>) (sext_ln1116_170_cast_fu_55349_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1570_fu_83022_p1() {
    mul_ln1118_1570_fu_83022_p1 = tmp_1570_reg_104407.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1570_fu_83022_p2() {
    mul_ln1118_1570_fu_83022_p2 = (!mul_ln1118_1570_fu_83022_p0.read().is_01() || !mul_ln1118_1570_fu_83022_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1570_fu_83022_p0.read()) * sc_bigint<5>(mul_ln1118_1570_fu_83022_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1571_fu_83041_p0() {
    mul_ln1118_1571_fu_83041_p0 =  (sc_lv<12>) (sext_ln1116_171_cast_fu_55371_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1571_fu_83041_p1() {
    mul_ln1118_1571_fu_83041_p1 = tmp_1571_reg_104412.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1571_fu_83041_p2() {
    mul_ln1118_1571_fu_83041_p2 = (!mul_ln1118_1571_fu_83041_p0.read().is_01() || !mul_ln1118_1571_fu_83041_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1571_fu_83041_p0.read()) * sc_bigint<5>(mul_ln1118_1571_fu_83041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1572_fu_83060_p0() {
    mul_ln1118_1572_fu_83060_p0 =  (sc_lv<12>) (sext_ln1116_172_cast_fu_55393_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1572_fu_83060_p1() {
    mul_ln1118_1572_fu_83060_p1 = tmp_1572_reg_104417.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1572_fu_83060_p2() {
    mul_ln1118_1572_fu_83060_p2 = (!mul_ln1118_1572_fu_83060_p0.read().is_01() || !mul_ln1118_1572_fu_83060_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1572_fu_83060_p0.read()) * sc_bigint<5>(mul_ln1118_1572_fu_83060_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1573_fu_83079_p0() {
    mul_ln1118_1573_fu_83079_p0 =  (sc_lv<12>) (sext_ln1116_173_cast_fu_55415_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1573_fu_83079_p1() {
    mul_ln1118_1573_fu_83079_p1 = tmp_1573_reg_104422.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1573_fu_83079_p2() {
    mul_ln1118_1573_fu_83079_p2 = (!mul_ln1118_1573_fu_83079_p0.read().is_01() || !mul_ln1118_1573_fu_83079_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1573_fu_83079_p0.read()) * sc_bigint<5>(mul_ln1118_1573_fu_83079_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1574_fu_83098_p0() {
    mul_ln1118_1574_fu_83098_p0 =  (sc_lv<12>) (sext_ln1116_174_cast_fu_55437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1574_fu_83098_p1() {
    mul_ln1118_1574_fu_83098_p1 = tmp_1574_reg_104427.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1574_fu_83098_p2() {
    mul_ln1118_1574_fu_83098_p2 = (!mul_ln1118_1574_fu_83098_p0.read().is_01() || !mul_ln1118_1574_fu_83098_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1574_fu_83098_p0.read()) * sc_bigint<5>(mul_ln1118_1574_fu_83098_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1575_fu_83117_p0() {
    mul_ln1118_1575_fu_83117_p0 =  (sc_lv<12>) (sext_ln1116_175_cast_fu_55459_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1575_fu_83117_p1() {
    mul_ln1118_1575_fu_83117_p1 = tmp_1575_reg_104432.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1575_fu_83117_p2() {
    mul_ln1118_1575_fu_83117_p2 = (!mul_ln1118_1575_fu_83117_p0.read().is_01() || !mul_ln1118_1575_fu_83117_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1575_fu_83117_p0.read()) * sc_bigint<5>(mul_ln1118_1575_fu_83117_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1576_fu_83136_p0() {
    mul_ln1118_1576_fu_83136_p0 =  (sc_lv<12>) (sext_ln1116_176_cast_reg_97300.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1576_fu_83136_p1() {
    mul_ln1118_1576_fu_83136_p1 = tmp_1576_reg_104437.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1576_fu_83136_p2() {
    mul_ln1118_1576_fu_83136_p2 = (!mul_ln1118_1576_fu_83136_p0.read().is_01() || !mul_ln1118_1576_fu_83136_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1576_fu_83136_p0.read()) * sc_bigint<5>(mul_ln1118_1576_fu_83136_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1577_fu_83154_p0() {
    mul_ln1118_1577_fu_83154_p0 =  (sc_lv<12>) (sext_ln1116_177_cast_reg_97318.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1577_fu_83154_p1() {
    mul_ln1118_1577_fu_83154_p1 = tmp_1577_reg_104442.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1577_fu_83154_p2() {
    mul_ln1118_1577_fu_83154_p2 = (!mul_ln1118_1577_fu_83154_p0.read().is_01() || !mul_ln1118_1577_fu_83154_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1577_fu_83154_p0.read()) * sc_bigint<5>(mul_ln1118_1577_fu_83154_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1578_fu_46155_p0() {
    mul_ln1118_1578_fu_46155_p0 =  (sc_lv<12>) (sext_ln1116_178_cast_fu_25695_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1578_fu_46155_p1() {
    mul_ln1118_1578_fu_46155_p1 = tmp_1578_fu_46141_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1578_fu_46155_p2() {
    mul_ln1118_1578_fu_46155_p2 = (!mul_ln1118_1578_fu_46155_p0.read().is_01() || !mul_ln1118_1578_fu_46155_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1578_fu_46155_p0.read()) * sc_bigint<5>(mul_ln1118_1578_fu_46155_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1579_fu_46185_p0() {
    mul_ln1118_1579_fu_46185_p0 =  (sc_lv<12>) (sext_ln1116_179_cast_fu_25737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1579_fu_46185_p1() {
    mul_ln1118_1579_fu_46185_p1 = tmp_1579_fu_46171_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1579_fu_46185_p2() {
    mul_ln1118_1579_fu_46185_p2 = (!mul_ln1118_1579_fu_46185_p0.read().is_01() || !mul_ln1118_1579_fu_46185_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1579_fu_46185_p0.read()) * sc_bigint<5>(mul_ln1118_1579_fu_46185_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_157_fu_25269_p0() {
    mul_ln1118_157_fu_25269_p0 =  (sc_lv<12>) (sext_ln1116_157_cast_fu_25261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_157_fu_25269_p1() {
    mul_ln1118_157_fu_25269_p1 = tmp_157_fu_25251_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_157_fu_25269_p2() {
    mul_ln1118_157_fu_25269_p2 = (!mul_ln1118_157_fu_25269_p0.read().is_01() || !mul_ln1118_157_fu_25269_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_157_fu_25269_p0.read()) * sc_bigint<5>(mul_ln1118_157_fu_25269_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1580_fu_46215_p0() {
    mul_ln1118_1580_fu_46215_p0 =  (sc_lv<12>) (sext_ln1116_180_cast_fu_25779_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1580_fu_46215_p1() {
    mul_ln1118_1580_fu_46215_p1 = tmp_1580_fu_46201_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1580_fu_46215_p2() {
    mul_ln1118_1580_fu_46215_p2 = (!mul_ln1118_1580_fu_46215_p0.read().is_01() || !mul_ln1118_1580_fu_46215_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1580_fu_46215_p0.read()) * sc_bigint<5>(mul_ln1118_1580_fu_46215_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1581_fu_46245_p0() {
    mul_ln1118_1581_fu_46245_p0 =  (sc_lv<12>) (sext_ln1116_181_cast_fu_25821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1581_fu_46245_p1() {
    mul_ln1118_1581_fu_46245_p1 = tmp_1581_fu_46231_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1581_fu_46245_p2() {
    mul_ln1118_1581_fu_46245_p2 = (!mul_ln1118_1581_fu_46245_p0.read().is_01() || !mul_ln1118_1581_fu_46245_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1581_fu_46245_p0.read()) * sc_bigint<5>(mul_ln1118_1581_fu_46245_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1582_fu_46275_p0() {
    mul_ln1118_1582_fu_46275_p0 =  (sc_lv<12>) (sext_ln1116_182_cast_fu_25863_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1582_fu_46275_p1() {
    mul_ln1118_1582_fu_46275_p1 = tmp_1582_fu_46261_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1582_fu_46275_p2() {
    mul_ln1118_1582_fu_46275_p2 = (!mul_ln1118_1582_fu_46275_p0.read().is_01() || !mul_ln1118_1582_fu_46275_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1582_fu_46275_p0.read()) * sc_bigint<5>(mul_ln1118_1582_fu_46275_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1583_fu_46305_p0() {
    mul_ln1118_1583_fu_46305_p0 =  (sc_lv<12>) (sext_ln1116_183_cast_fu_25905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1583_fu_46305_p1() {
    mul_ln1118_1583_fu_46305_p1 = tmp_1583_fu_46291_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1583_fu_46305_p2() {
    mul_ln1118_1583_fu_46305_p2 = (!mul_ln1118_1583_fu_46305_p0.read().is_01() || !mul_ln1118_1583_fu_46305_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1583_fu_46305_p0.read()) * sc_bigint<5>(mul_ln1118_1583_fu_46305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1584_fu_83172_p0() {
    mul_ln1118_1584_fu_83172_p0 =  (sc_lv<12>) (sext_ln1116_184_cast_fu_55517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1584_fu_83172_p1() {
    mul_ln1118_1584_fu_83172_p1 = tmp_1584_reg_104477.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1584_fu_83172_p2() {
    mul_ln1118_1584_fu_83172_p2 = (!mul_ln1118_1584_fu_83172_p0.read().is_01() || !mul_ln1118_1584_fu_83172_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1584_fu_83172_p0.read()) * sc_bigint<5>(mul_ln1118_1584_fu_83172_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1585_fu_83191_p0() {
    mul_ln1118_1585_fu_83191_p0 =  (sc_lv<12>) (sext_ln1116_185_cast_fu_55539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1585_fu_83191_p1() {
    mul_ln1118_1585_fu_83191_p1 = tmp_1585_reg_104482.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1585_fu_83191_p2() {
    mul_ln1118_1585_fu_83191_p2 = (!mul_ln1118_1585_fu_83191_p0.read().is_01() || !mul_ln1118_1585_fu_83191_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1585_fu_83191_p0.read()) * sc_bigint<5>(mul_ln1118_1585_fu_83191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1586_fu_83210_p0() {
    mul_ln1118_1586_fu_83210_p0 =  (sc_lv<12>) (sext_ln1116_186_cast_fu_55561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1586_fu_83210_p1() {
    mul_ln1118_1586_fu_83210_p1 = tmp_1586_reg_104487.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1586_fu_83210_p2() {
    mul_ln1118_1586_fu_83210_p2 = (!mul_ln1118_1586_fu_83210_p0.read().is_01() || !mul_ln1118_1586_fu_83210_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1586_fu_83210_p0.read()) * sc_bigint<5>(mul_ln1118_1586_fu_83210_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1587_fu_83229_p0() {
    mul_ln1118_1587_fu_83229_p0 =  (sc_lv<12>) (sext_ln1116_187_cast_fu_55583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1587_fu_83229_p1() {
    mul_ln1118_1587_fu_83229_p1 = tmp_1587_reg_104492.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1587_fu_83229_p2() {
    mul_ln1118_1587_fu_83229_p2 = (!mul_ln1118_1587_fu_83229_p0.read().is_01() || !mul_ln1118_1587_fu_83229_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1587_fu_83229_p0.read()) * sc_bigint<5>(mul_ln1118_1587_fu_83229_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1588_fu_83248_p0() {
    mul_ln1118_1588_fu_83248_p0 =  (sc_lv<12>) (sext_ln1116_188_cast_fu_55605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1588_fu_83248_p1() {
    mul_ln1118_1588_fu_83248_p1 = tmp_1588_reg_104497.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1588_fu_83248_p2() {
    mul_ln1118_1588_fu_83248_p2 = (!mul_ln1118_1588_fu_83248_p0.read().is_01() || !mul_ln1118_1588_fu_83248_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1588_fu_83248_p0.read()) * sc_bigint<5>(mul_ln1118_1588_fu_83248_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1589_fu_83267_p0() {
    mul_ln1118_1589_fu_83267_p0 =  (sc_lv<12>) (sext_ln1116_189_cast_fu_55627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1589_fu_83267_p1() {
    mul_ln1118_1589_fu_83267_p1 = tmp_1589_reg_104502.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1589_fu_83267_p2() {
    mul_ln1118_1589_fu_83267_p2 = (!mul_ln1118_1589_fu_83267_p0.read().is_01() || !mul_ln1118_1589_fu_83267_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1589_fu_83267_p0.read()) * sc_bigint<5>(mul_ln1118_1589_fu_83267_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_158_fu_25311_p0() {
    mul_ln1118_158_fu_25311_p0 =  (sc_lv<12>) (sext_ln1116_158_cast_fu_25303_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_158_fu_25311_p1() {
    mul_ln1118_158_fu_25311_p1 = tmp_158_fu_25293_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_158_fu_25311_p2() {
    mul_ln1118_158_fu_25311_p2 = (!mul_ln1118_158_fu_25311_p0.read().is_01() || !mul_ln1118_158_fu_25311_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_158_fu_25311_p0.read()) * sc_bigint<5>(mul_ln1118_158_fu_25311_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1590_fu_83286_p0() {
    mul_ln1118_1590_fu_83286_p0 =  (sc_lv<12>) (sext_ln1116_190_cast_fu_55649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1590_fu_83286_p1() {
    mul_ln1118_1590_fu_83286_p1 = tmp_1590_reg_104507.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1590_fu_83286_p2() {
    mul_ln1118_1590_fu_83286_p2 = (!mul_ln1118_1590_fu_83286_p0.read().is_01() || !mul_ln1118_1590_fu_83286_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1590_fu_83286_p0.read()) * sc_bigint<5>(mul_ln1118_1590_fu_83286_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1591_fu_83305_p0() {
    mul_ln1118_1591_fu_83305_p0 =  (sc_lv<12>) (sext_ln1116_191_cast_fu_55671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1591_fu_83305_p1() {
    mul_ln1118_1591_fu_83305_p1 = tmp_1591_reg_104512.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1591_fu_83305_p2() {
    mul_ln1118_1591_fu_83305_p2 = (!mul_ln1118_1591_fu_83305_p0.read().is_01() || !mul_ln1118_1591_fu_83305_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1591_fu_83305_p0.read()) * sc_bigint<5>(mul_ln1118_1591_fu_83305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1592_fu_83324_p0() {
    mul_ln1118_1592_fu_83324_p0 =  (sc_lv<12>) (sext_ln1116_192_cast_fu_55693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1592_fu_83324_p1() {
    mul_ln1118_1592_fu_83324_p1 = tmp_1592_reg_104517.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1592_fu_83324_p2() {
    mul_ln1118_1592_fu_83324_p2 = (!mul_ln1118_1592_fu_83324_p0.read().is_01() || !mul_ln1118_1592_fu_83324_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1592_fu_83324_p0.read()) * sc_bigint<5>(mul_ln1118_1592_fu_83324_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1593_fu_83343_p0() {
    mul_ln1118_1593_fu_83343_p0 =  (sc_lv<12>) (sext_ln1116_193_cast_fu_55715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1593_fu_83343_p1() {
    mul_ln1118_1593_fu_83343_p1 = tmp_1593_reg_104522.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1593_fu_83343_p2() {
    mul_ln1118_1593_fu_83343_p2 = (!mul_ln1118_1593_fu_83343_p0.read().is_01() || !mul_ln1118_1593_fu_83343_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1593_fu_83343_p0.read()) * sc_bigint<5>(mul_ln1118_1593_fu_83343_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1594_fu_83362_p0() {
    mul_ln1118_1594_fu_83362_p0 =  (sc_lv<12>) (sext_ln1116_194_cast_fu_55737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1594_fu_83362_p1() {
    mul_ln1118_1594_fu_83362_p1 = tmp_1594_reg_104527.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1594_fu_83362_p2() {
    mul_ln1118_1594_fu_83362_p2 = (!mul_ln1118_1594_fu_83362_p0.read().is_01() || !mul_ln1118_1594_fu_83362_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1594_fu_83362_p0.read()) * sc_bigint<5>(mul_ln1118_1594_fu_83362_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1595_fu_83381_p0() {
    mul_ln1118_1595_fu_83381_p0 =  (sc_lv<12>) (sext_ln1116_195_cast_fu_55759_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1595_fu_83381_p1() {
    mul_ln1118_1595_fu_83381_p1 = tmp_1595_reg_104532.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1595_fu_83381_p2() {
    mul_ln1118_1595_fu_83381_p2 = (!mul_ln1118_1595_fu_83381_p0.read().is_01() || !mul_ln1118_1595_fu_83381_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1595_fu_83381_p0.read()) * sc_bigint<5>(mul_ln1118_1595_fu_83381_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1596_fu_83400_p0() {
    mul_ln1118_1596_fu_83400_p0 =  (sc_lv<12>) (sext_ln1116_196_cast_fu_55781_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1596_fu_83400_p1() {
    mul_ln1118_1596_fu_83400_p1 = tmp_1596_reg_104537.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1596_fu_83400_p2() {
    mul_ln1118_1596_fu_83400_p2 = (!mul_ln1118_1596_fu_83400_p0.read().is_01() || !mul_ln1118_1596_fu_83400_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1596_fu_83400_p0.read()) * sc_bigint<5>(mul_ln1118_1596_fu_83400_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1597_fu_83419_p0() {
    mul_ln1118_1597_fu_83419_p0 =  (sc_lv<12>) (sext_ln1116_197_cast_fu_55803_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1597_fu_83419_p1() {
    mul_ln1118_1597_fu_83419_p1 = tmp_1597_reg_104542.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1597_fu_83419_p2() {
    mul_ln1118_1597_fu_83419_p2 = (!mul_ln1118_1597_fu_83419_p0.read().is_01() || !mul_ln1118_1597_fu_83419_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1597_fu_83419_p0.read()) * sc_bigint<5>(mul_ln1118_1597_fu_83419_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1598_fu_83438_p0() {
    mul_ln1118_1598_fu_83438_p0 =  (sc_lv<12>) (sext_ln1116_198_cast_fu_55825_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1598_fu_83438_p1() {
    mul_ln1118_1598_fu_83438_p1 = tmp_1598_reg_104547.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1598_fu_83438_p2() {
    mul_ln1118_1598_fu_83438_p2 = (!mul_ln1118_1598_fu_83438_p0.read().is_01() || !mul_ln1118_1598_fu_83438_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1598_fu_83438_p0.read()) * sc_bigint<5>(mul_ln1118_1598_fu_83438_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1599_fu_83457_p0() {
    mul_ln1118_1599_fu_83457_p0 =  (sc_lv<12>) (sext_ln1116_199_cast_fu_55847_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1599_fu_83457_p1() {
    mul_ln1118_1599_fu_83457_p1 = tmp_1599_reg_104552.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1599_fu_83457_p2() {
    mul_ln1118_1599_fu_83457_p2 = (!mul_ln1118_1599_fu_83457_p0.read().is_01() || !mul_ln1118_1599_fu_83457_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1599_fu_83457_p0.read()) * sc_bigint<5>(mul_ln1118_1599_fu_83457_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_159_fu_55113_p0() {
    mul_ln1118_159_fu_55113_p0 =  (sc_lv<12>) (sext_ln1116_159_cast_fu_55107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_159_fu_55113_p1() {
    mul_ln1118_159_fu_55113_p1 = tmp_159_reg_97130.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_159_fu_55113_p2() {
    mul_ln1118_159_fu_55113_p2 = (!mul_ln1118_159_fu_55113_p0.read().is_01() || !mul_ln1118_159_fu_55113_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_159_fu_55113_p0.read()) * sc_bigint<5>(mul_ln1118_159_fu_55113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_15_fu_52669_p0() {
    mul_ln1118_15_fu_52669_p0 =  (sc_lv<12>) (sext_ln1116_15_cast_fu_52663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_15_fu_52669_p1() {
    mul_ln1118_15_fu_52669_p1 = tmp_16_reg_95810.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_15_fu_52669_p2() {
    mul_ln1118_15_fu_52669_p2 = (!mul_ln1118_15_fu_52669_p0.read().is_01() || !mul_ln1118_15_fu_52669_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_15_fu_52669_p0.read()) * sc_bigint<5>(mul_ln1118_15_fu_52669_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1600_fu_83476_p0() {
    mul_ln1118_1600_fu_83476_p0 =  (sc_lv<12>) (sext_ln1116_200_cast_fu_55869_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1600_fu_83476_p1() {
    mul_ln1118_1600_fu_83476_p1 = tmp_1600_reg_104557.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1600_fu_83476_p2() {
    mul_ln1118_1600_fu_83476_p2 = (!mul_ln1118_1600_fu_83476_p0.read().is_01() || !mul_ln1118_1600_fu_83476_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1600_fu_83476_p0.read()) * sc_bigint<5>(mul_ln1118_1600_fu_83476_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1601_fu_83495_p0() {
    mul_ln1118_1601_fu_83495_p0 =  (sc_lv<12>) (sext_ln1116_201_cast_reg_97536.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1601_fu_83495_p1() {
    mul_ln1118_1601_fu_83495_p1 = tmp_1601_reg_104562.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1601_fu_83495_p2() {
    mul_ln1118_1601_fu_83495_p2 = (!mul_ln1118_1601_fu_83495_p0.read().is_01() || !mul_ln1118_1601_fu_83495_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1601_fu_83495_p0.read()) * sc_bigint<5>(mul_ln1118_1601_fu_83495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1602_fu_83513_p0() {
    mul_ln1118_1602_fu_83513_p0 =  (sc_lv<12>) (sext_ln1116_202_cast_reg_97554.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1602_fu_83513_p1() {
    mul_ln1118_1602_fu_83513_p1 = tmp_1602_reg_104567.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1602_fu_83513_p2() {
    mul_ln1118_1602_fu_83513_p2 = (!mul_ln1118_1602_fu_83513_p0.read().is_01() || !mul_ln1118_1602_fu_83513_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1602_fu_83513_p0.read()) * sc_bigint<5>(mul_ln1118_1602_fu_83513_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1603_fu_46525_p0() {
    mul_ln1118_1603_fu_46525_p0 =  (sc_lv<12>) (sext_ln1116_203_cast_fu_26297_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1603_fu_46525_p1() {
    mul_ln1118_1603_fu_46525_p1 = tmp_1603_fu_46511_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1603_fu_46525_p2() {
    mul_ln1118_1603_fu_46525_p2 = (!mul_ln1118_1603_fu_46525_p0.read().is_01() || !mul_ln1118_1603_fu_46525_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1603_fu_46525_p0.read()) * sc_bigint<5>(mul_ln1118_1603_fu_46525_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1604_fu_46555_p0() {
    mul_ln1118_1604_fu_46555_p0 =  (sc_lv<12>) (sext_ln1116_204_cast_fu_26339_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1604_fu_46555_p1() {
    mul_ln1118_1604_fu_46555_p1 = tmp_1604_fu_46541_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1604_fu_46555_p2() {
    mul_ln1118_1604_fu_46555_p2 = (!mul_ln1118_1604_fu_46555_p0.read().is_01() || !mul_ln1118_1604_fu_46555_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1604_fu_46555_p0.read()) * sc_bigint<5>(mul_ln1118_1604_fu_46555_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1605_fu_46585_p0() {
    mul_ln1118_1605_fu_46585_p0 =  (sc_lv<12>) (sext_ln1116_205_cast_fu_26381_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1605_fu_46585_p1() {
    mul_ln1118_1605_fu_46585_p1 = tmp_1605_fu_46571_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1605_fu_46585_p2() {
    mul_ln1118_1605_fu_46585_p2 = (!mul_ln1118_1605_fu_46585_p0.read().is_01() || !mul_ln1118_1605_fu_46585_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1605_fu_46585_p0.read()) * sc_bigint<5>(mul_ln1118_1605_fu_46585_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1606_fu_46615_p0() {
    mul_ln1118_1606_fu_46615_p0 =  (sc_lv<12>) (sext_ln1116_206_cast_fu_26423_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1606_fu_46615_p1() {
    mul_ln1118_1606_fu_46615_p1 = tmp_1606_fu_46601_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1606_fu_46615_p2() {
    mul_ln1118_1606_fu_46615_p2 = (!mul_ln1118_1606_fu_46615_p0.read().is_01() || !mul_ln1118_1606_fu_46615_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1606_fu_46615_p0.read()) * sc_bigint<5>(mul_ln1118_1606_fu_46615_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1607_fu_46645_p0() {
    mul_ln1118_1607_fu_46645_p0 =  (sc_lv<12>) (sext_ln1116_207_cast_fu_26465_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1607_fu_46645_p1() {
    mul_ln1118_1607_fu_46645_p1 = tmp_1607_fu_46631_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1607_fu_46645_p2() {
    mul_ln1118_1607_fu_46645_p2 = (!mul_ln1118_1607_fu_46645_p0.read().is_01() || !mul_ln1118_1607_fu_46645_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1607_fu_46645_p0.read()) * sc_bigint<5>(mul_ln1118_1607_fu_46645_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1608_fu_46675_p0() {
    mul_ln1118_1608_fu_46675_p0 =  (sc_lv<12>) (sext_ln1116_208_cast_fu_26507_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1608_fu_46675_p1() {
    mul_ln1118_1608_fu_46675_p1 = tmp_1608_fu_46661_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1608_fu_46675_p2() {
    mul_ln1118_1608_fu_46675_p2 = (!mul_ln1118_1608_fu_46675_p0.read().is_01() || !mul_ln1118_1608_fu_46675_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1608_fu_46675_p0.read()) * sc_bigint<5>(mul_ln1118_1608_fu_46675_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1609_fu_84519_p0() {
    mul_ln1118_1609_fu_84519_p0 =  (sc_lv<12>) (sext_ln1116_cast_fu_52531_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1609_fu_84519_p1() {
    mul_ln1118_1609_fu_84519_p1 = tmp_1609_reg_104602.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1609_fu_84519_p2() {
    mul_ln1118_1609_fu_84519_p2 = (!mul_ln1118_1609_fu_84519_p0.read().is_01() || !mul_ln1118_1609_fu_84519_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1609_fu_84519_p0.read()) * sc_bigint<5>(mul_ln1118_1609_fu_84519_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_160_fu_55135_p0() {
    mul_ln1118_160_fu_55135_p0 =  (sc_lv<12>) (sext_ln1116_160_cast_fu_55129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_160_fu_55135_p1() {
    mul_ln1118_160_fu_55135_p1 = tmp_160_reg_97140.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_160_fu_55135_p2() {
    mul_ln1118_160_fu_55135_p2 = (!mul_ln1118_160_fu_55135_p0.read().is_01() || !mul_ln1118_160_fu_55135_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_160_fu_55135_p0.read()) * sc_bigint<5>(mul_ln1118_160_fu_55135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1610_fu_84538_p0() {
    mul_ln1118_1610_fu_84538_p0 =  (sc_lv<12>) (sext_ln1116_10_cast_fu_52553_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1610_fu_84538_p1() {
    mul_ln1118_1610_fu_84538_p1 = tmp_1610_reg_104607.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1610_fu_84538_p2() {
    mul_ln1118_1610_fu_84538_p2 = (!mul_ln1118_1610_fu_84538_p0.read().is_01() || !mul_ln1118_1610_fu_84538_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1610_fu_84538_p0.read()) * sc_bigint<5>(mul_ln1118_1610_fu_84538_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1611_fu_84557_p0() {
    mul_ln1118_1611_fu_84557_p0 =  (sc_lv<12>) (sext_ln1116_11_cast_fu_52575_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1611_fu_84557_p1() {
    mul_ln1118_1611_fu_84557_p1 = tmp_1611_reg_104612.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1611_fu_84557_p2() {
    mul_ln1118_1611_fu_84557_p2 = (!mul_ln1118_1611_fu_84557_p0.read().is_01() || !mul_ln1118_1611_fu_84557_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1611_fu_84557_p0.read()) * sc_bigint<5>(mul_ln1118_1611_fu_84557_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1612_fu_84576_p0() {
    mul_ln1118_1612_fu_84576_p0 =  (sc_lv<12>) (sext_ln1116_12_cast_fu_52597_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1612_fu_84576_p1() {
    mul_ln1118_1612_fu_84576_p1 = tmp_1612_reg_104617.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1612_fu_84576_p2() {
    mul_ln1118_1612_fu_84576_p2 = (!mul_ln1118_1612_fu_84576_p0.read().is_01() || !mul_ln1118_1612_fu_84576_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1612_fu_84576_p0.read()) * sc_bigint<5>(mul_ln1118_1612_fu_84576_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1613_fu_84595_p0() {
    mul_ln1118_1613_fu_84595_p0 =  (sc_lv<12>) (sext_ln1116_13_cast_fu_52619_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1613_fu_84595_p1() {
    mul_ln1118_1613_fu_84595_p1 = tmp_1613_reg_104622.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1613_fu_84595_p2() {
    mul_ln1118_1613_fu_84595_p2 = (!mul_ln1118_1613_fu_84595_p0.read().is_01() || !mul_ln1118_1613_fu_84595_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1613_fu_84595_p0.read()) * sc_bigint<5>(mul_ln1118_1613_fu_84595_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1614_fu_84614_p0() {
    mul_ln1118_1614_fu_84614_p0 =  (sc_lv<12>) (sext_ln1116_14_cast_fu_52641_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1614_fu_84614_p1() {
    mul_ln1118_1614_fu_84614_p1 = tmp_1614_reg_104627.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1614_fu_84614_p2() {
    mul_ln1118_1614_fu_84614_p2 = (!mul_ln1118_1614_fu_84614_p0.read().is_01() || !mul_ln1118_1614_fu_84614_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1614_fu_84614_p0.read()) * sc_bigint<5>(mul_ln1118_1614_fu_84614_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1615_fu_84633_p0() {
    mul_ln1118_1615_fu_84633_p0 =  (sc_lv<12>) (sext_ln1116_15_cast_fu_52663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1615_fu_84633_p1() {
    mul_ln1118_1615_fu_84633_p1 = tmp_1615_reg_104632.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1615_fu_84633_p2() {
    mul_ln1118_1615_fu_84633_p2 = (!mul_ln1118_1615_fu_84633_p0.read().is_01() || !mul_ln1118_1615_fu_84633_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1615_fu_84633_p0.read()) * sc_bigint<5>(mul_ln1118_1615_fu_84633_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1616_fu_84652_p0() {
    mul_ln1118_1616_fu_84652_p0 =  (sc_lv<12>) (sext_ln1116_16_cast_fu_52685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1616_fu_84652_p1() {
    mul_ln1118_1616_fu_84652_p1 = tmp_1616_reg_104637.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1616_fu_84652_p2() {
    mul_ln1118_1616_fu_84652_p2 = (!mul_ln1118_1616_fu_84652_p0.read().is_01() || !mul_ln1118_1616_fu_84652_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1616_fu_84652_p0.read()) * sc_bigint<5>(mul_ln1118_1616_fu_84652_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1617_fu_84671_p0() {
    mul_ln1118_1617_fu_84671_p0 =  (sc_lv<12>) (sext_ln1116_17_cast_fu_52707_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1617_fu_84671_p1() {
    mul_ln1118_1617_fu_84671_p1 = tmp_1617_reg_104642.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1617_fu_84671_p2() {
    mul_ln1118_1617_fu_84671_p2 = (!mul_ln1118_1617_fu_84671_p0.read().is_01() || !mul_ln1118_1617_fu_84671_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1617_fu_84671_p0.read()) * sc_bigint<5>(mul_ln1118_1617_fu_84671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1618_fu_84690_p0() {
    mul_ln1118_1618_fu_84690_p0 =  (sc_lv<12>) (sext_ln1116_18_cast_fu_52729_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1618_fu_84690_p1() {
    mul_ln1118_1618_fu_84690_p1 = tmp_1618_reg_104647.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1618_fu_84690_p2() {
    mul_ln1118_1618_fu_84690_p2 = (!mul_ln1118_1618_fu_84690_p0.read().is_01() || !mul_ln1118_1618_fu_84690_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1618_fu_84690_p0.read()) * sc_bigint<5>(mul_ln1118_1618_fu_84690_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1619_fu_84709_p0() {
    mul_ln1118_1619_fu_84709_p0 =  (sc_lv<12>) (sext_ln1116_19_cast_fu_52751_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1619_fu_84709_p1() {
    mul_ln1118_1619_fu_84709_p1 = tmp_1619_reg_104652.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1619_fu_84709_p2() {
    mul_ln1118_1619_fu_84709_p2 = (!mul_ln1118_1619_fu_84709_p0.read().is_01() || !mul_ln1118_1619_fu_84709_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1619_fu_84709_p0.read()) * sc_bigint<5>(mul_ln1118_1619_fu_84709_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_161_fu_55157_p0() {
    mul_ln1118_161_fu_55157_p0 =  (sc_lv<12>) (sext_ln1116_161_cast_fu_55151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_161_fu_55157_p1() {
    mul_ln1118_161_fu_55157_p1 = tmp_161_reg_97150.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_161_fu_55157_p2() {
    mul_ln1118_161_fu_55157_p2 = (!mul_ln1118_161_fu_55157_p0.read().is_01() || !mul_ln1118_161_fu_55157_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_161_fu_55157_p0.read()) * sc_bigint<5>(mul_ln1118_161_fu_55157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1620_fu_84728_p0() {
    mul_ln1118_1620_fu_84728_p0 =  (sc_lv<12>) (sext_ln1116_20_cast_fu_52773_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1620_fu_84728_p1() {
    mul_ln1118_1620_fu_84728_p1 = tmp_1620_reg_104657.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1620_fu_84728_p2() {
    mul_ln1118_1620_fu_84728_p2 = (!mul_ln1118_1620_fu_84728_p0.read().is_01() || !mul_ln1118_1620_fu_84728_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1620_fu_84728_p0.read()) * sc_bigint<5>(mul_ln1118_1620_fu_84728_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1621_fu_84747_p0() {
    mul_ln1118_1621_fu_84747_p0 =  (sc_lv<12>) (sext_ln1116_21_cast_fu_52795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1621_fu_84747_p1() {
    mul_ln1118_1621_fu_84747_p1 = tmp_1621_reg_104662.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1621_fu_84747_p2() {
    mul_ln1118_1621_fu_84747_p2 = (!mul_ln1118_1621_fu_84747_p0.read().is_01() || !mul_ln1118_1621_fu_84747_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1621_fu_84747_p0.read()) * sc_bigint<5>(mul_ln1118_1621_fu_84747_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1622_fu_84766_p0() {
    mul_ln1118_1622_fu_84766_p0 =  (sc_lv<12>) (sext_ln1116_22_cast_fu_52817_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1622_fu_84766_p1() {
    mul_ln1118_1622_fu_84766_p1 = tmp_1622_reg_104667.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1622_fu_84766_p2() {
    mul_ln1118_1622_fu_84766_p2 = (!mul_ln1118_1622_fu_84766_p0.read().is_01() || !mul_ln1118_1622_fu_84766_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1622_fu_84766_p0.read()) * sc_bigint<5>(mul_ln1118_1622_fu_84766_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1623_fu_84785_p0() {
    mul_ln1118_1623_fu_84785_p0 =  (sc_lv<12>) (sext_ln1116_23_cast_fu_52839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1623_fu_84785_p1() {
    mul_ln1118_1623_fu_84785_p1 = tmp_1623_reg_104672.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1623_fu_84785_p2() {
    mul_ln1118_1623_fu_84785_p2 = (!mul_ln1118_1623_fu_84785_p0.read().is_01() || !mul_ln1118_1623_fu_84785_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1623_fu_84785_p0.read()) * sc_bigint<5>(mul_ln1118_1623_fu_84785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1624_fu_84804_p0() {
    mul_ln1118_1624_fu_84804_p0 =  (sc_lv<12>) (sext_ln1116_24_cast_fu_52861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1624_fu_84804_p1() {
    mul_ln1118_1624_fu_84804_p1 = tmp_1624_reg_104677.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1624_fu_84804_p2() {
    mul_ln1118_1624_fu_84804_p2 = (!mul_ln1118_1624_fu_84804_p0.read().is_01() || !mul_ln1118_1624_fu_84804_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1624_fu_84804_p0.read()) * sc_bigint<5>(mul_ln1118_1624_fu_84804_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1625_fu_84823_p0() {
    mul_ln1118_1625_fu_84823_p0 =  (sc_lv<12>) (sext_ln1116_25_cast_fu_52883_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1625_fu_84823_p1() {
    mul_ln1118_1625_fu_84823_p1 = tmp_1625_reg_104682.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1625_fu_84823_p2() {
    mul_ln1118_1625_fu_84823_p2 = (!mul_ln1118_1625_fu_84823_p0.read().is_01() || !mul_ln1118_1625_fu_84823_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1625_fu_84823_p0.read()) * sc_bigint<5>(mul_ln1118_1625_fu_84823_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1626_fu_84842_p0() {
    mul_ln1118_1626_fu_84842_p0 =  (sc_lv<12>) (sext_ln1116_26_cast_fu_52905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1626_fu_84842_p1() {
    mul_ln1118_1626_fu_84842_p1 = tmp_1626_reg_104687.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1626_fu_84842_p2() {
    mul_ln1118_1626_fu_84842_p2 = (!mul_ln1118_1626_fu_84842_p0.read().is_01() || !mul_ln1118_1626_fu_84842_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1626_fu_84842_p0.read()) * sc_bigint<5>(mul_ln1118_1626_fu_84842_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1627_fu_84861_p0() {
    mul_ln1118_1627_fu_84861_p0 =  (sc_lv<12>) (sext_ln1116_27_cast_fu_52927_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1627_fu_84861_p1() {
    mul_ln1118_1627_fu_84861_p1 = tmp_1627_reg_104692.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1627_fu_84861_p2() {
    mul_ln1118_1627_fu_84861_p2 = (!mul_ln1118_1627_fu_84861_p0.read().is_01() || !mul_ln1118_1627_fu_84861_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1627_fu_84861_p0.read()) * sc_bigint<5>(mul_ln1118_1627_fu_84861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1628_fu_46895_p0() {
    mul_ln1118_1628_fu_46895_p0 =  (sc_lv<12>) (sext_ln1116_28_cast_fu_22199_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1628_fu_46895_p1() {
    mul_ln1118_1628_fu_46895_p1 = tmp_1628_fu_46881_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1628_fu_46895_p2() {
    mul_ln1118_1628_fu_46895_p2 = (!mul_ln1118_1628_fu_46895_p0.read().is_01() || !mul_ln1118_1628_fu_46895_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1628_fu_46895_p0.read()) * sc_bigint<5>(mul_ln1118_1628_fu_46895_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1629_fu_46925_p0() {
    mul_ln1118_1629_fu_46925_p0 =  (sc_lv<12>) (sext_ln1116_29_cast_fu_22241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1629_fu_46925_p1() {
    mul_ln1118_1629_fu_46925_p1 = tmp_1629_fu_46911_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1629_fu_46925_p2() {
    mul_ln1118_1629_fu_46925_p2 = (!mul_ln1118_1629_fu_46925_p0.read().is_01() || !mul_ln1118_1629_fu_46925_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1629_fu_46925_p0.read()) * sc_bigint<5>(mul_ln1118_1629_fu_46925_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_162_fu_55179_p0() {
    mul_ln1118_162_fu_55179_p0 =  (sc_lv<12>) (sext_ln1116_162_cast_fu_55173_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_162_fu_55179_p1() {
    mul_ln1118_162_fu_55179_p1 = tmp_162_reg_97160.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_162_fu_55179_p2() {
    mul_ln1118_162_fu_55179_p2 = (!mul_ln1118_162_fu_55179_p0.read().is_01() || !mul_ln1118_162_fu_55179_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_162_fu_55179_p0.read()) * sc_bigint<5>(mul_ln1118_162_fu_55179_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1630_fu_46955_p0() {
    mul_ln1118_1630_fu_46955_p0 =  (sc_lv<12>) (sext_ln1116_30_cast_fu_22283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1630_fu_46955_p1() {
    mul_ln1118_1630_fu_46955_p1 = tmp_1630_fu_46941_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1630_fu_46955_p2() {
    mul_ln1118_1630_fu_46955_p2 = (!mul_ln1118_1630_fu_46955_p0.read().is_01() || !mul_ln1118_1630_fu_46955_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1630_fu_46955_p0.read()) * sc_bigint<5>(mul_ln1118_1630_fu_46955_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1631_fu_46985_p0() {
    mul_ln1118_1631_fu_46985_p0 =  (sc_lv<12>) (sext_ln1116_31_cast_fu_22325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1631_fu_46985_p1() {
    mul_ln1118_1631_fu_46985_p1 = tmp_1631_fu_46971_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1631_fu_46985_p2() {
    mul_ln1118_1631_fu_46985_p2 = (!mul_ln1118_1631_fu_46985_p0.read().is_01() || !mul_ln1118_1631_fu_46985_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1631_fu_46985_p0.read()) * sc_bigint<5>(mul_ln1118_1631_fu_46985_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1632_fu_47015_p0() {
    mul_ln1118_1632_fu_47015_p0 =  (sc_lv<12>) (sext_ln1116_32_cast_fu_22367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1632_fu_47015_p1() {
    mul_ln1118_1632_fu_47015_p1 = tmp_1632_fu_47001_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1632_fu_47015_p2() {
    mul_ln1118_1632_fu_47015_p2 = (!mul_ln1118_1632_fu_47015_p0.read().is_01() || !mul_ln1118_1632_fu_47015_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1632_fu_47015_p0.read()) * sc_bigint<5>(mul_ln1118_1632_fu_47015_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1633_fu_47045_p0() {
    mul_ln1118_1633_fu_47045_p0 =  (sc_lv<12>) (sext_ln1116_33_cast_fu_22409_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1633_fu_47045_p1() {
    mul_ln1118_1633_fu_47045_p1 = tmp_1633_fu_47031_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1633_fu_47045_p2() {
    mul_ln1118_1633_fu_47045_p2 = (!mul_ln1118_1633_fu_47045_p0.read().is_01() || !mul_ln1118_1633_fu_47045_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1633_fu_47045_p0.read()) * sc_bigint<5>(mul_ln1118_1633_fu_47045_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1634_fu_84880_p0() {
    mul_ln1118_1634_fu_84880_p0 =  (sc_lv<12>) (sext_ln1116_34_cast_fu_52949_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1634_fu_84880_p1() {
    mul_ln1118_1634_fu_84880_p1 = tmp_1634_reg_104727.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1634_fu_84880_p2() {
    mul_ln1118_1634_fu_84880_p2 = (!mul_ln1118_1634_fu_84880_p0.read().is_01() || !mul_ln1118_1634_fu_84880_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1634_fu_84880_p0.read()) * sc_bigint<5>(mul_ln1118_1634_fu_84880_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1635_fu_84899_p0() {
    mul_ln1118_1635_fu_84899_p0 =  (sc_lv<12>) (sext_ln1116_35_cast_fu_52971_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1635_fu_84899_p1() {
    mul_ln1118_1635_fu_84899_p1 = tmp_1635_reg_104732.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1635_fu_84899_p2() {
    mul_ln1118_1635_fu_84899_p2 = (!mul_ln1118_1635_fu_84899_p0.read().is_01() || !mul_ln1118_1635_fu_84899_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1635_fu_84899_p0.read()) * sc_bigint<5>(mul_ln1118_1635_fu_84899_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1636_fu_84918_p0() {
    mul_ln1118_1636_fu_84918_p0 =  (sc_lv<12>) (sext_ln1116_36_cast_fu_52993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1636_fu_84918_p1() {
    mul_ln1118_1636_fu_84918_p1 = tmp_1636_reg_104737.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1636_fu_84918_p2() {
    mul_ln1118_1636_fu_84918_p2 = (!mul_ln1118_1636_fu_84918_p0.read().is_01() || !mul_ln1118_1636_fu_84918_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1636_fu_84918_p0.read()) * sc_bigint<5>(mul_ln1118_1636_fu_84918_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1637_fu_84937_p0() {
    mul_ln1118_1637_fu_84937_p0 =  (sc_lv<12>) (sext_ln1116_37_cast_fu_53015_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1637_fu_84937_p1() {
    mul_ln1118_1637_fu_84937_p1 = tmp_1637_reg_104742.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1637_fu_84937_p2() {
    mul_ln1118_1637_fu_84937_p2 = (!mul_ln1118_1637_fu_84937_p0.read().is_01() || !mul_ln1118_1637_fu_84937_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1637_fu_84937_p0.read()) * sc_bigint<5>(mul_ln1118_1637_fu_84937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1638_fu_84956_p0() {
    mul_ln1118_1638_fu_84956_p0 =  (sc_lv<12>) (sext_ln1116_38_cast_fu_53037_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1638_fu_84956_p1() {
    mul_ln1118_1638_fu_84956_p1 = tmp_1638_reg_104747.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1638_fu_84956_p2() {
    mul_ln1118_1638_fu_84956_p2 = (!mul_ln1118_1638_fu_84956_p0.read().is_01() || !mul_ln1118_1638_fu_84956_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1638_fu_84956_p0.read()) * sc_bigint<5>(mul_ln1118_1638_fu_84956_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1639_fu_84975_p0() {
    mul_ln1118_1639_fu_84975_p0 =  (sc_lv<12>) (sext_ln1116_39_cast_fu_53059_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1639_fu_84975_p1() {
    mul_ln1118_1639_fu_84975_p1 = tmp_1639_reg_104752.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1639_fu_84975_p2() {
    mul_ln1118_1639_fu_84975_p2 = (!mul_ln1118_1639_fu_84975_p0.read().is_01() || !mul_ln1118_1639_fu_84975_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1639_fu_84975_p0.read()) * sc_bigint<5>(mul_ln1118_1639_fu_84975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_163_fu_55201_p0() {
    mul_ln1118_163_fu_55201_p0 =  (sc_lv<12>) (sext_ln1116_163_cast_fu_55195_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_163_fu_55201_p1() {
    mul_ln1118_163_fu_55201_p1 = tmp_163_reg_97170.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_163_fu_55201_p2() {
    mul_ln1118_163_fu_55201_p2 = (!mul_ln1118_163_fu_55201_p0.read().is_01() || !mul_ln1118_163_fu_55201_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_163_fu_55201_p0.read()) * sc_bigint<5>(mul_ln1118_163_fu_55201_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1640_fu_84994_p0() {
    mul_ln1118_1640_fu_84994_p0 =  (sc_lv<12>) (sext_ln1116_40_cast_fu_53081_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1640_fu_84994_p1() {
    mul_ln1118_1640_fu_84994_p1 = tmp_1640_reg_104757.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1640_fu_84994_p2() {
    mul_ln1118_1640_fu_84994_p2 = (!mul_ln1118_1640_fu_84994_p0.read().is_01() || !mul_ln1118_1640_fu_84994_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1640_fu_84994_p0.read()) * sc_bigint<5>(mul_ln1118_1640_fu_84994_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1641_fu_85013_p0() {
    mul_ln1118_1641_fu_85013_p0 =  (sc_lv<12>) (sext_ln1116_41_cast_fu_53103_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1641_fu_85013_p1() {
    mul_ln1118_1641_fu_85013_p1 = tmp_1641_reg_104762.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1641_fu_85013_p2() {
    mul_ln1118_1641_fu_85013_p2 = (!mul_ln1118_1641_fu_85013_p0.read().is_01() || !mul_ln1118_1641_fu_85013_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1641_fu_85013_p0.read()) * sc_bigint<5>(mul_ln1118_1641_fu_85013_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1642_fu_85032_p0() {
    mul_ln1118_1642_fu_85032_p0 =  (sc_lv<12>) (sext_ln1116_42_cast_fu_53125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1642_fu_85032_p1() {
    mul_ln1118_1642_fu_85032_p1 = tmp_1642_reg_104767.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1642_fu_85032_p2() {
    mul_ln1118_1642_fu_85032_p2 = (!mul_ln1118_1642_fu_85032_p0.read().is_01() || !mul_ln1118_1642_fu_85032_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1642_fu_85032_p0.read()) * sc_bigint<5>(mul_ln1118_1642_fu_85032_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1643_fu_85051_p0() {
    mul_ln1118_1643_fu_85051_p0 =  (sc_lv<12>) (sext_ln1116_43_cast_fu_53147_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1643_fu_85051_p1() {
    mul_ln1118_1643_fu_85051_p1 = tmp_1643_reg_104772.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1643_fu_85051_p2() {
    mul_ln1118_1643_fu_85051_p2 = (!mul_ln1118_1643_fu_85051_p0.read().is_01() || !mul_ln1118_1643_fu_85051_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1643_fu_85051_p0.read()) * sc_bigint<5>(mul_ln1118_1643_fu_85051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1644_fu_85070_p0() {
    mul_ln1118_1644_fu_85070_p0 =  (sc_lv<12>) (sext_ln1116_44_cast_fu_53169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1644_fu_85070_p1() {
    mul_ln1118_1644_fu_85070_p1 = tmp_1644_reg_104777.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1644_fu_85070_p2() {
    mul_ln1118_1644_fu_85070_p2 = (!mul_ln1118_1644_fu_85070_p0.read().is_01() || !mul_ln1118_1644_fu_85070_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1644_fu_85070_p0.read()) * sc_bigint<5>(mul_ln1118_1644_fu_85070_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1645_fu_85089_p0() {
    mul_ln1118_1645_fu_85089_p0 =  (sc_lv<12>) (sext_ln1116_45_cast_fu_53191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1645_fu_85089_p1() {
    mul_ln1118_1645_fu_85089_p1 = tmp_1645_reg_104782.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1645_fu_85089_p2() {
    mul_ln1118_1645_fu_85089_p2 = (!mul_ln1118_1645_fu_85089_p0.read().is_01() || !mul_ln1118_1645_fu_85089_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1645_fu_85089_p0.read()) * sc_bigint<5>(mul_ln1118_1645_fu_85089_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1646_fu_85108_p0() {
    mul_ln1118_1646_fu_85108_p0 =  (sc_lv<12>) (sext_ln1116_46_cast_fu_53213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1646_fu_85108_p1() {
    mul_ln1118_1646_fu_85108_p1 = tmp_1646_reg_104787.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1646_fu_85108_p2() {
    mul_ln1118_1646_fu_85108_p2 = (!mul_ln1118_1646_fu_85108_p0.read().is_01() || !mul_ln1118_1646_fu_85108_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1646_fu_85108_p0.read()) * sc_bigint<5>(mul_ln1118_1646_fu_85108_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1647_fu_85127_p0() {
    mul_ln1118_1647_fu_85127_p0 =  (sc_lv<12>) (sext_ln1116_47_cast_fu_53235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1647_fu_85127_p1() {
    mul_ln1118_1647_fu_85127_p1 = tmp_1647_reg_104792.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1647_fu_85127_p2() {
    mul_ln1118_1647_fu_85127_p2 = (!mul_ln1118_1647_fu_85127_p0.read().is_01() || !mul_ln1118_1647_fu_85127_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1647_fu_85127_p0.read()) * sc_bigint<5>(mul_ln1118_1647_fu_85127_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1648_fu_85146_p0() {
    mul_ln1118_1648_fu_85146_p0 =  (sc_lv<12>) (sext_ln1116_48_cast_fu_53257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1648_fu_85146_p1() {
    mul_ln1118_1648_fu_85146_p1 = tmp_1648_reg_104797.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1648_fu_85146_p2() {
    mul_ln1118_1648_fu_85146_p2 = (!mul_ln1118_1648_fu_85146_p0.read().is_01() || !mul_ln1118_1648_fu_85146_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1648_fu_85146_p0.read()) * sc_bigint<5>(mul_ln1118_1648_fu_85146_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1649_fu_85165_p0() {
    mul_ln1118_1649_fu_85165_p0 =  (sc_lv<12>) (sext_ln1116_49_cast_fu_53279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1649_fu_85165_p1() {
    mul_ln1118_1649_fu_85165_p1 = tmp_1649_reg_104802.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1649_fu_85165_p2() {
    mul_ln1118_1649_fu_85165_p2 = (!mul_ln1118_1649_fu_85165_p0.read().is_01() || !mul_ln1118_1649_fu_85165_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1649_fu_85165_p0.read()) * sc_bigint<5>(mul_ln1118_1649_fu_85165_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_164_fu_55223_p0() {
    mul_ln1118_164_fu_55223_p0 =  (sc_lv<12>) (sext_ln1116_164_cast_fu_55217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_164_fu_55223_p1() {
    mul_ln1118_164_fu_55223_p1 = tmp_164_reg_97180.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_164_fu_55223_p2() {
    mul_ln1118_164_fu_55223_p2 = (!mul_ln1118_164_fu_55223_p0.read().is_01() || !mul_ln1118_164_fu_55223_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_164_fu_55223_p0.read()) * sc_bigint<5>(mul_ln1118_164_fu_55223_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1650_fu_85184_p0() {
    mul_ln1118_1650_fu_85184_p0 =  (sc_lv<12>) (sext_ln1116_50_cast_fu_53301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1650_fu_85184_p1() {
    mul_ln1118_1650_fu_85184_p1 = tmp_1650_reg_104807.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1650_fu_85184_p2() {
    mul_ln1118_1650_fu_85184_p2 = (!mul_ln1118_1650_fu_85184_p0.read().is_01() || !mul_ln1118_1650_fu_85184_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1650_fu_85184_p0.read()) * sc_bigint<5>(mul_ln1118_1650_fu_85184_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1651_fu_85203_p0() {
    mul_ln1118_1651_fu_85203_p0 =  (sc_lv<12>) (sext_ln1116_51_cast_fu_53323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1651_fu_85203_p1() {
    mul_ln1118_1651_fu_85203_p1 = tmp_1651_reg_104812.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1651_fu_85203_p2() {
    mul_ln1118_1651_fu_85203_p2 = (!mul_ln1118_1651_fu_85203_p0.read().is_01() || !mul_ln1118_1651_fu_85203_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1651_fu_85203_p0.read()) * sc_bigint<5>(mul_ln1118_1651_fu_85203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1652_fu_85222_p0() {
    mul_ln1118_1652_fu_85222_p0 =  (sc_lv<12>) (sext_ln1116_52_cast_reg_96150.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1652_fu_85222_p1() {
    mul_ln1118_1652_fu_85222_p1 = tmp_1652_reg_104817.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1652_fu_85222_p2() {
    mul_ln1118_1652_fu_85222_p2 = (!mul_ln1118_1652_fu_85222_p0.read().is_01() || !mul_ln1118_1652_fu_85222_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1652_fu_85222_p0.read()) * sc_bigint<5>(mul_ln1118_1652_fu_85222_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1653_fu_47265_p0() {
    mul_ln1118_1653_fu_47265_p0 =  (sc_lv<12>) (sext_ln1116_53_cast_fu_22797_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1653_fu_47265_p1() {
    mul_ln1118_1653_fu_47265_p1 = tmp_1653_fu_47251_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1653_fu_47265_p2() {
    mul_ln1118_1653_fu_47265_p2 = (!mul_ln1118_1653_fu_47265_p0.read().is_01() || !mul_ln1118_1653_fu_47265_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1653_fu_47265_p0.read()) * sc_bigint<5>(mul_ln1118_1653_fu_47265_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1654_fu_47295_p0() {
    mul_ln1118_1654_fu_47295_p0 =  (sc_lv<12>) (sext_ln1116_54_cast_fu_22839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1654_fu_47295_p1() {
    mul_ln1118_1654_fu_47295_p1 = tmp_1654_fu_47281_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1654_fu_47295_p2() {
    mul_ln1118_1654_fu_47295_p2 = (!mul_ln1118_1654_fu_47295_p0.read().is_01() || !mul_ln1118_1654_fu_47295_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1654_fu_47295_p0.read()) * sc_bigint<5>(mul_ln1118_1654_fu_47295_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1655_fu_47325_p0() {
    mul_ln1118_1655_fu_47325_p0 =  (sc_lv<12>) (sext_ln1116_55_cast_fu_22881_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1655_fu_47325_p1() {
    mul_ln1118_1655_fu_47325_p1 = tmp_1655_fu_47311_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1655_fu_47325_p2() {
    mul_ln1118_1655_fu_47325_p2 = (!mul_ln1118_1655_fu_47325_p0.read().is_01() || !mul_ln1118_1655_fu_47325_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1655_fu_47325_p0.read()) * sc_bigint<5>(mul_ln1118_1655_fu_47325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1656_fu_47355_p0() {
    mul_ln1118_1656_fu_47355_p0 =  (sc_lv<12>) (sext_ln1116_56_cast_fu_22923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1656_fu_47355_p1() {
    mul_ln1118_1656_fu_47355_p1 = tmp_1656_fu_47341_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1656_fu_47355_p2() {
    mul_ln1118_1656_fu_47355_p2 = (!mul_ln1118_1656_fu_47355_p0.read().is_01() || !mul_ln1118_1656_fu_47355_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1656_fu_47355_p0.read()) * sc_bigint<5>(mul_ln1118_1656_fu_47355_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1657_fu_47385_p0() {
    mul_ln1118_1657_fu_47385_p0 =  (sc_lv<12>) (sext_ln1116_57_cast_fu_22965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1657_fu_47385_p1() {
    mul_ln1118_1657_fu_47385_p1 = tmp_1657_fu_47371_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1657_fu_47385_p2() {
    mul_ln1118_1657_fu_47385_p2 = (!mul_ln1118_1657_fu_47385_p0.read().is_01() || !mul_ln1118_1657_fu_47385_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1657_fu_47385_p0.read()) * sc_bigint<5>(mul_ln1118_1657_fu_47385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1658_fu_47415_p0() {
    mul_ln1118_1658_fu_47415_p0 =  (sc_lv<12>) (sext_ln1116_58_cast_fu_23007_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1658_fu_47415_p1() {
    mul_ln1118_1658_fu_47415_p1 = tmp_1658_fu_47401_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1658_fu_47415_p2() {
    mul_ln1118_1658_fu_47415_p2 = (!mul_ln1118_1658_fu_47415_p0.read().is_01() || !mul_ln1118_1658_fu_47415_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1658_fu_47415_p0.read()) * sc_bigint<5>(mul_ln1118_1658_fu_47415_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1659_fu_85240_p0() {
    mul_ln1118_1659_fu_85240_p0 =  (sc_lv<12>) (sext_ln1116_59_cast_fu_53363_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1659_fu_85240_p1() {
    mul_ln1118_1659_fu_85240_p1 = tmp_1659_reg_104852.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1659_fu_85240_p2() {
    mul_ln1118_1659_fu_85240_p2 = (!mul_ln1118_1659_fu_85240_p0.read().is_01() || !mul_ln1118_1659_fu_85240_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1659_fu_85240_p0.read()) * sc_bigint<5>(mul_ln1118_1659_fu_85240_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_165_fu_55245_p0() {
    mul_ln1118_165_fu_55245_p0 =  (sc_lv<12>) (sext_ln1116_165_cast_fu_55239_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_165_fu_55245_p1() {
    mul_ln1118_165_fu_55245_p1 = tmp_165_reg_97190.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_165_fu_55245_p2() {
    mul_ln1118_165_fu_55245_p2 = (!mul_ln1118_165_fu_55245_p0.read().is_01() || !mul_ln1118_165_fu_55245_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_165_fu_55245_p0.read()) * sc_bigint<5>(mul_ln1118_165_fu_55245_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1660_fu_85259_p0() {
    mul_ln1118_1660_fu_85259_p0 =  (sc_lv<12>) (sext_ln1116_60_cast_fu_53385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1660_fu_85259_p1() {
    mul_ln1118_1660_fu_85259_p1 = tmp_1660_reg_104857.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1660_fu_85259_p2() {
    mul_ln1118_1660_fu_85259_p2 = (!mul_ln1118_1660_fu_85259_p0.read().is_01() || !mul_ln1118_1660_fu_85259_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1660_fu_85259_p0.read()) * sc_bigint<5>(mul_ln1118_1660_fu_85259_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1661_fu_85278_p0() {
    mul_ln1118_1661_fu_85278_p0 =  (sc_lv<12>) (sext_ln1116_61_cast_fu_53407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1661_fu_85278_p1() {
    mul_ln1118_1661_fu_85278_p1 = tmp_1661_reg_104862.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1661_fu_85278_p2() {
    mul_ln1118_1661_fu_85278_p2 = (!mul_ln1118_1661_fu_85278_p0.read().is_01() || !mul_ln1118_1661_fu_85278_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1661_fu_85278_p0.read()) * sc_bigint<5>(mul_ln1118_1661_fu_85278_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1662_fu_85297_p0() {
    mul_ln1118_1662_fu_85297_p0 =  (sc_lv<12>) (sext_ln1116_62_cast_fu_53429_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1662_fu_85297_p1() {
    mul_ln1118_1662_fu_85297_p1 = tmp_1662_reg_104867.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1662_fu_85297_p2() {
    mul_ln1118_1662_fu_85297_p2 = (!mul_ln1118_1662_fu_85297_p0.read().is_01() || !mul_ln1118_1662_fu_85297_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1662_fu_85297_p0.read()) * sc_bigint<5>(mul_ln1118_1662_fu_85297_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1663_fu_85316_p0() {
    mul_ln1118_1663_fu_85316_p0 =  (sc_lv<12>) (sext_ln1116_63_cast_fu_53451_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1663_fu_85316_p1() {
    mul_ln1118_1663_fu_85316_p1 = tmp_1663_reg_104872.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1663_fu_85316_p2() {
    mul_ln1118_1663_fu_85316_p2 = (!mul_ln1118_1663_fu_85316_p0.read().is_01() || !mul_ln1118_1663_fu_85316_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1663_fu_85316_p0.read()) * sc_bigint<5>(mul_ln1118_1663_fu_85316_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1664_fu_85335_p0() {
    mul_ln1118_1664_fu_85335_p0 =  (sc_lv<12>) (sext_ln1116_64_cast_fu_53473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1664_fu_85335_p1() {
    mul_ln1118_1664_fu_85335_p1 = tmp_1664_reg_104877.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1664_fu_85335_p2() {
    mul_ln1118_1664_fu_85335_p2 = (!mul_ln1118_1664_fu_85335_p0.read().is_01() || !mul_ln1118_1664_fu_85335_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1664_fu_85335_p0.read()) * sc_bigint<5>(mul_ln1118_1664_fu_85335_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1665_fu_85354_p0() {
    mul_ln1118_1665_fu_85354_p0 =  (sc_lv<12>) (sext_ln1116_65_cast_fu_53495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1665_fu_85354_p1() {
    mul_ln1118_1665_fu_85354_p1 = tmp_1665_reg_104882.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1665_fu_85354_p2() {
    mul_ln1118_1665_fu_85354_p2 = (!mul_ln1118_1665_fu_85354_p0.read().is_01() || !mul_ln1118_1665_fu_85354_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1665_fu_85354_p0.read()) * sc_bigint<5>(mul_ln1118_1665_fu_85354_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1666_fu_85373_p0() {
    mul_ln1118_1666_fu_85373_p0 =  (sc_lv<12>) (sext_ln1116_66_cast_fu_53517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1666_fu_85373_p1() {
    mul_ln1118_1666_fu_85373_p1 = tmp_1666_reg_104887.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1666_fu_85373_p2() {
    mul_ln1118_1666_fu_85373_p2 = (!mul_ln1118_1666_fu_85373_p0.read().is_01() || !mul_ln1118_1666_fu_85373_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1666_fu_85373_p0.read()) * sc_bigint<5>(mul_ln1118_1666_fu_85373_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1667_fu_85392_p0() {
    mul_ln1118_1667_fu_85392_p0 =  (sc_lv<12>) (sext_ln1116_67_cast_fu_53539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1667_fu_85392_p1() {
    mul_ln1118_1667_fu_85392_p1 = tmp_1667_reg_104892.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1667_fu_85392_p2() {
    mul_ln1118_1667_fu_85392_p2 = (!mul_ln1118_1667_fu_85392_p0.read().is_01() || !mul_ln1118_1667_fu_85392_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1667_fu_85392_p0.read()) * sc_bigint<5>(mul_ln1118_1667_fu_85392_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1668_fu_85411_p0() {
    mul_ln1118_1668_fu_85411_p0 =  (sc_lv<12>) (sext_ln1116_68_cast_fu_53561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1668_fu_85411_p1() {
    mul_ln1118_1668_fu_85411_p1 = tmp_1668_reg_104897.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1668_fu_85411_p2() {
    mul_ln1118_1668_fu_85411_p2 = (!mul_ln1118_1668_fu_85411_p0.read().is_01() || !mul_ln1118_1668_fu_85411_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1668_fu_85411_p0.read()) * sc_bigint<5>(mul_ln1118_1668_fu_85411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1669_fu_85430_p0() {
    mul_ln1118_1669_fu_85430_p0 =  (sc_lv<12>) (sext_ln1116_69_cast_fu_53583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1669_fu_85430_p1() {
    mul_ln1118_1669_fu_85430_p1 = tmp_1669_reg_104902.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1669_fu_85430_p2() {
    mul_ln1118_1669_fu_85430_p2 = (!mul_ln1118_1669_fu_85430_p0.read().is_01() || !mul_ln1118_1669_fu_85430_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1669_fu_85430_p0.read()) * sc_bigint<5>(mul_ln1118_1669_fu_85430_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_166_fu_55267_p0() {
    mul_ln1118_166_fu_55267_p0 =  (sc_lv<12>) (sext_ln1116_166_cast_fu_55261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_166_fu_55267_p1() {
    mul_ln1118_166_fu_55267_p1 = tmp_166_reg_97200.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_166_fu_55267_p2() {
    mul_ln1118_166_fu_55267_p2 = (!mul_ln1118_166_fu_55267_p0.read().is_01() || !mul_ln1118_166_fu_55267_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_166_fu_55267_p0.read()) * sc_bigint<5>(mul_ln1118_166_fu_55267_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1670_fu_85449_p0() {
    mul_ln1118_1670_fu_85449_p0 =  (sc_lv<12>) (sext_ln1116_70_cast_fu_53605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1670_fu_85449_p1() {
    mul_ln1118_1670_fu_85449_p1 = tmp_1670_reg_104907.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1670_fu_85449_p2() {
    mul_ln1118_1670_fu_85449_p2 = (!mul_ln1118_1670_fu_85449_p0.read().is_01() || !mul_ln1118_1670_fu_85449_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1670_fu_85449_p0.read()) * sc_bigint<5>(mul_ln1118_1670_fu_85449_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1671_fu_85468_p0() {
    mul_ln1118_1671_fu_85468_p0 =  (sc_lv<12>) (sext_ln1116_71_cast_fu_53627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1671_fu_85468_p1() {
    mul_ln1118_1671_fu_85468_p1 = tmp_1671_reg_104912.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1671_fu_85468_p2() {
    mul_ln1118_1671_fu_85468_p2 = (!mul_ln1118_1671_fu_85468_p0.read().is_01() || !mul_ln1118_1671_fu_85468_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1671_fu_85468_p0.read()) * sc_bigint<5>(mul_ln1118_1671_fu_85468_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1672_fu_85487_p0() {
    mul_ln1118_1672_fu_85487_p0 =  (sc_lv<12>) (sext_ln1116_72_cast_fu_53649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1672_fu_85487_p1() {
    mul_ln1118_1672_fu_85487_p1 = tmp_1672_reg_104917.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1672_fu_85487_p2() {
    mul_ln1118_1672_fu_85487_p2 = (!mul_ln1118_1672_fu_85487_p0.read().is_01() || !mul_ln1118_1672_fu_85487_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1672_fu_85487_p0.read()) * sc_bigint<5>(mul_ln1118_1672_fu_85487_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1673_fu_85506_p0() {
    mul_ln1118_1673_fu_85506_p0 =  (sc_lv<12>) (sext_ln1116_73_cast_fu_53671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1673_fu_85506_p1() {
    mul_ln1118_1673_fu_85506_p1 = tmp_1673_reg_104922.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1673_fu_85506_p2() {
    mul_ln1118_1673_fu_85506_p2 = (!mul_ln1118_1673_fu_85506_p0.read().is_01() || !mul_ln1118_1673_fu_85506_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1673_fu_85506_p0.read()) * sc_bigint<5>(mul_ln1118_1673_fu_85506_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1674_fu_85525_p0() {
    mul_ln1118_1674_fu_85525_p0 =  (sc_lv<12>) (sext_ln1116_74_cast_fu_53693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1674_fu_85525_p1() {
    mul_ln1118_1674_fu_85525_p1 = tmp_1674_reg_104927.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1674_fu_85525_p2() {
    mul_ln1118_1674_fu_85525_p2 = (!mul_ln1118_1674_fu_85525_p0.read().is_01() || !mul_ln1118_1674_fu_85525_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1674_fu_85525_p0.read()) * sc_bigint<5>(mul_ln1118_1674_fu_85525_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1675_fu_85544_p0() {
    mul_ln1118_1675_fu_85544_p0 =  (sc_lv<12>) (sext_ln1116_75_cast_fu_53715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1675_fu_85544_p1() {
    mul_ln1118_1675_fu_85544_p1 = tmp_1675_reg_104932.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1675_fu_85544_p2() {
    mul_ln1118_1675_fu_85544_p2 = (!mul_ln1118_1675_fu_85544_p0.read().is_01() || !mul_ln1118_1675_fu_85544_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1675_fu_85544_p0.read()) * sc_bigint<5>(mul_ln1118_1675_fu_85544_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1676_fu_85563_p0() {
    mul_ln1118_1676_fu_85563_p0 =  (sc_lv<12>) (sext_ln1116_76_cast_fu_53737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1676_fu_85563_p1() {
    mul_ln1118_1676_fu_85563_p1 = tmp_1676_reg_104937.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1676_fu_85563_p2() {
    mul_ln1118_1676_fu_85563_p2 = (!mul_ln1118_1676_fu_85563_p0.read().is_01() || !mul_ln1118_1676_fu_85563_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1676_fu_85563_p0.read()) * sc_bigint<5>(mul_ln1118_1676_fu_85563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1677_fu_85582_p0() {
    mul_ln1118_1677_fu_85582_p0 =  (sc_lv<12>) (sext_ln1116_77_cast_reg_96378.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1677_fu_85582_p1() {
    mul_ln1118_1677_fu_85582_p1 = tmp_1677_reg_104942.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1677_fu_85582_p2() {
    mul_ln1118_1677_fu_85582_p2 = (!mul_ln1118_1677_fu_85582_p0.read().is_01() || !mul_ln1118_1677_fu_85582_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1677_fu_85582_p0.read()) * sc_bigint<5>(mul_ln1118_1677_fu_85582_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1678_fu_47635_p0() {
    mul_ln1118_1678_fu_47635_p0 =  (sc_lv<12>) (sext_ln1116_78_cast_fu_23395_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1678_fu_47635_p1() {
    mul_ln1118_1678_fu_47635_p1 = tmp_1678_fu_47621_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1678_fu_47635_p2() {
    mul_ln1118_1678_fu_47635_p2 = (!mul_ln1118_1678_fu_47635_p0.read().is_01() || !mul_ln1118_1678_fu_47635_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1678_fu_47635_p0.read()) * sc_bigint<5>(mul_ln1118_1678_fu_47635_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1679_fu_47665_p0() {
    mul_ln1118_1679_fu_47665_p0 =  (sc_lv<12>) (sext_ln1116_79_cast_fu_23437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1679_fu_47665_p1() {
    mul_ln1118_1679_fu_47665_p1 = tmp_1679_fu_47651_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1679_fu_47665_p2() {
    mul_ln1118_1679_fu_47665_p2 = (!mul_ln1118_1679_fu_47665_p0.read().is_01() || !mul_ln1118_1679_fu_47665_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1679_fu_47665_p0.read()) * sc_bigint<5>(mul_ln1118_1679_fu_47665_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_167_fu_55289_p0() {
    mul_ln1118_167_fu_55289_p0 =  (sc_lv<12>) (sext_ln1116_167_cast_fu_55283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_167_fu_55289_p1() {
    mul_ln1118_167_fu_55289_p1 = tmp_167_reg_97210.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_167_fu_55289_p2() {
    mul_ln1118_167_fu_55289_p2 = (!mul_ln1118_167_fu_55289_p0.read().is_01() || !mul_ln1118_167_fu_55289_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_167_fu_55289_p0.read()) * sc_bigint<5>(mul_ln1118_167_fu_55289_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1680_fu_47695_p0() {
    mul_ln1118_1680_fu_47695_p0 =  (sc_lv<12>) (sext_ln1116_80_cast_fu_23479_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1680_fu_47695_p1() {
    mul_ln1118_1680_fu_47695_p1 = tmp_1680_fu_47681_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1680_fu_47695_p2() {
    mul_ln1118_1680_fu_47695_p2 = (!mul_ln1118_1680_fu_47695_p0.read().is_01() || !mul_ln1118_1680_fu_47695_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1680_fu_47695_p0.read()) * sc_bigint<5>(mul_ln1118_1680_fu_47695_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1681_fu_47725_p0() {
    mul_ln1118_1681_fu_47725_p0 =  (sc_lv<12>) (sext_ln1116_81_cast_fu_23521_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1681_fu_47725_p1() {
    mul_ln1118_1681_fu_47725_p1 = tmp_1681_fu_47711_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1681_fu_47725_p2() {
    mul_ln1118_1681_fu_47725_p2 = (!mul_ln1118_1681_fu_47725_p0.read().is_01() || !mul_ln1118_1681_fu_47725_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1681_fu_47725_p0.read()) * sc_bigint<5>(mul_ln1118_1681_fu_47725_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1682_fu_47755_p0() {
    mul_ln1118_1682_fu_47755_p0 =  (sc_lv<12>) (sext_ln1116_82_cast_fu_23563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1682_fu_47755_p1() {
    mul_ln1118_1682_fu_47755_p1 = tmp_1682_fu_47741_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1682_fu_47755_p2() {
    mul_ln1118_1682_fu_47755_p2 = (!mul_ln1118_1682_fu_47755_p0.read().is_01() || !mul_ln1118_1682_fu_47755_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1682_fu_47755_p0.read()) * sc_bigint<5>(mul_ln1118_1682_fu_47755_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1683_fu_47785_p0() {
    mul_ln1118_1683_fu_47785_p0 =  (sc_lv<12>) (sext_ln1116_83_cast_fu_23605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1683_fu_47785_p1() {
    mul_ln1118_1683_fu_47785_p1 = tmp_1683_fu_47771_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1683_fu_47785_p2() {
    mul_ln1118_1683_fu_47785_p2 = (!mul_ln1118_1683_fu_47785_p0.read().is_01() || !mul_ln1118_1683_fu_47785_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1683_fu_47785_p0.read()) * sc_bigint<5>(mul_ln1118_1683_fu_47785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1684_fu_85600_p0() {
    mul_ln1118_1684_fu_85600_p0 =  (sc_lv<12>) (sext_ln1116_84_cast_fu_53777_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1684_fu_85600_p1() {
    mul_ln1118_1684_fu_85600_p1 = tmp_1684_reg_104977.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1684_fu_85600_p2() {
    mul_ln1118_1684_fu_85600_p2 = (!mul_ln1118_1684_fu_85600_p0.read().is_01() || !mul_ln1118_1684_fu_85600_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1684_fu_85600_p0.read()) * sc_bigint<5>(mul_ln1118_1684_fu_85600_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1685_fu_85619_p0() {
    mul_ln1118_1685_fu_85619_p0 =  (sc_lv<12>) (sext_ln1116_85_cast_fu_53799_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1685_fu_85619_p1() {
    mul_ln1118_1685_fu_85619_p1 = tmp_1685_reg_104982.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1685_fu_85619_p2() {
    mul_ln1118_1685_fu_85619_p2 = (!mul_ln1118_1685_fu_85619_p0.read().is_01() || !mul_ln1118_1685_fu_85619_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1685_fu_85619_p0.read()) * sc_bigint<5>(mul_ln1118_1685_fu_85619_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1686_fu_85638_p0() {
    mul_ln1118_1686_fu_85638_p0 =  (sc_lv<12>) (sext_ln1116_86_cast_fu_53821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1686_fu_85638_p1() {
    mul_ln1118_1686_fu_85638_p1 = tmp_1686_reg_104987.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1686_fu_85638_p2() {
    mul_ln1118_1686_fu_85638_p2 = (!mul_ln1118_1686_fu_85638_p0.read().is_01() || !mul_ln1118_1686_fu_85638_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1686_fu_85638_p0.read()) * sc_bigint<5>(mul_ln1118_1686_fu_85638_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1687_fu_85657_p0() {
    mul_ln1118_1687_fu_85657_p0 =  (sc_lv<12>) (sext_ln1116_87_cast_fu_53843_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1687_fu_85657_p1() {
    mul_ln1118_1687_fu_85657_p1 = tmp_1687_reg_104992.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1687_fu_85657_p2() {
    mul_ln1118_1687_fu_85657_p2 = (!mul_ln1118_1687_fu_85657_p0.read().is_01() || !mul_ln1118_1687_fu_85657_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1687_fu_85657_p0.read()) * sc_bigint<5>(mul_ln1118_1687_fu_85657_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1688_fu_85676_p0() {
    mul_ln1118_1688_fu_85676_p0 =  (sc_lv<12>) (sext_ln1116_88_cast_fu_53865_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1688_fu_85676_p1() {
    mul_ln1118_1688_fu_85676_p1 = tmp_1688_reg_104997.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1688_fu_85676_p2() {
    mul_ln1118_1688_fu_85676_p2 = (!mul_ln1118_1688_fu_85676_p0.read().is_01() || !mul_ln1118_1688_fu_85676_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1688_fu_85676_p0.read()) * sc_bigint<5>(mul_ln1118_1688_fu_85676_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1689_fu_85695_p0() {
    mul_ln1118_1689_fu_85695_p0 =  (sc_lv<12>) (sext_ln1116_89_cast_fu_53887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1689_fu_85695_p1() {
    mul_ln1118_1689_fu_85695_p1 = tmp_1689_reg_105002.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1689_fu_85695_p2() {
    mul_ln1118_1689_fu_85695_p2 = (!mul_ln1118_1689_fu_85695_p0.read().is_01() || !mul_ln1118_1689_fu_85695_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1689_fu_85695_p0.read()) * sc_bigint<5>(mul_ln1118_1689_fu_85695_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_168_fu_55311_p0() {
    mul_ln1118_168_fu_55311_p0 =  (sc_lv<12>) (sext_ln1116_168_cast_fu_55305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_168_fu_55311_p1() {
    mul_ln1118_168_fu_55311_p1 = tmp_168_reg_97220.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_168_fu_55311_p2() {
    mul_ln1118_168_fu_55311_p2 = (!mul_ln1118_168_fu_55311_p0.read().is_01() || !mul_ln1118_168_fu_55311_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_168_fu_55311_p0.read()) * sc_bigint<5>(mul_ln1118_168_fu_55311_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1690_fu_85714_p0() {
    mul_ln1118_1690_fu_85714_p0 =  (sc_lv<12>) (sext_ln1116_90_cast_fu_53909_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1690_fu_85714_p1() {
    mul_ln1118_1690_fu_85714_p1 = tmp_1690_reg_105007.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1690_fu_85714_p2() {
    mul_ln1118_1690_fu_85714_p2 = (!mul_ln1118_1690_fu_85714_p0.read().is_01() || !mul_ln1118_1690_fu_85714_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1690_fu_85714_p0.read()) * sc_bigint<5>(mul_ln1118_1690_fu_85714_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1691_fu_85733_p0() {
    mul_ln1118_1691_fu_85733_p0 =  (sc_lv<12>) (sext_ln1116_91_cast_fu_53931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1691_fu_85733_p1() {
    mul_ln1118_1691_fu_85733_p1 = tmp_1691_reg_105012.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1691_fu_85733_p2() {
    mul_ln1118_1691_fu_85733_p2 = (!mul_ln1118_1691_fu_85733_p0.read().is_01() || !mul_ln1118_1691_fu_85733_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1691_fu_85733_p0.read()) * sc_bigint<5>(mul_ln1118_1691_fu_85733_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1692_fu_85752_p0() {
    mul_ln1118_1692_fu_85752_p0 =  (sc_lv<12>) (sext_ln1116_92_cast_fu_53953_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1692_fu_85752_p1() {
    mul_ln1118_1692_fu_85752_p1 = tmp_1692_reg_105017.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1692_fu_85752_p2() {
    mul_ln1118_1692_fu_85752_p2 = (!mul_ln1118_1692_fu_85752_p0.read().is_01() || !mul_ln1118_1692_fu_85752_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1692_fu_85752_p0.read()) * sc_bigint<5>(mul_ln1118_1692_fu_85752_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1693_fu_85771_p0() {
    mul_ln1118_1693_fu_85771_p0 =  (sc_lv<12>) (sext_ln1116_93_cast_fu_53975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1693_fu_85771_p1() {
    mul_ln1118_1693_fu_85771_p1 = tmp_1693_reg_105022.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1693_fu_85771_p2() {
    mul_ln1118_1693_fu_85771_p2 = (!mul_ln1118_1693_fu_85771_p0.read().is_01() || !mul_ln1118_1693_fu_85771_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1693_fu_85771_p0.read()) * sc_bigint<5>(mul_ln1118_1693_fu_85771_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1694_fu_85790_p0() {
    mul_ln1118_1694_fu_85790_p0 =  (sc_lv<12>) (sext_ln1116_94_cast_fu_53997_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1694_fu_85790_p1() {
    mul_ln1118_1694_fu_85790_p1 = tmp_1694_reg_105027.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1694_fu_85790_p2() {
    mul_ln1118_1694_fu_85790_p2 = (!mul_ln1118_1694_fu_85790_p0.read().is_01() || !mul_ln1118_1694_fu_85790_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1694_fu_85790_p0.read()) * sc_bigint<5>(mul_ln1118_1694_fu_85790_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1695_fu_85809_p0() {
    mul_ln1118_1695_fu_85809_p0 =  (sc_lv<12>) (sext_ln1116_95_cast_fu_54019_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1695_fu_85809_p1() {
    mul_ln1118_1695_fu_85809_p1 = tmp_1695_reg_105032.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1695_fu_85809_p2() {
    mul_ln1118_1695_fu_85809_p2 = (!mul_ln1118_1695_fu_85809_p0.read().is_01() || !mul_ln1118_1695_fu_85809_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1695_fu_85809_p0.read()) * sc_bigint<5>(mul_ln1118_1695_fu_85809_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1696_fu_85828_p0() {
    mul_ln1118_1696_fu_85828_p0 =  (sc_lv<12>) (sext_ln1116_96_cast_fu_54041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1696_fu_85828_p1() {
    mul_ln1118_1696_fu_85828_p1 = tmp_1696_reg_105037.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1696_fu_85828_p2() {
    mul_ln1118_1696_fu_85828_p2 = (!mul_ln1118_1696_fu_85828_p0.read().is_01() || !mul_ln1118_1696_fu_85828_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1696_fu_85828_p0.read()) * sc_bigint<5>(mul_ln1118_1696_fu_85828_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1697_fu_85847_p0() {
    mul_ln1118_1697_fu_85847_p0 =  (sc_lv<12>) (sext_ln1116_97_cast_fu_54063_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1697_fu_85847_p1() {
    mul_ln1118_1697_fu_85847_p1 = tmp_1697_reg_105042.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1697_fu_85847_p2() {
    mul_ln1118_1697_fu_85847_p2 = (!mul_ln1118_1697_fu_85847_p0.read().is_01() || !mul_ln1118_1697_fu_85847_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1697_fu_85847_p0.read()) * sc_bigint<5>(mul_ln1118_1697_fu_85847_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1698_fu_85866_p0() {
    mul_ln1118_1698_fu_85866_p0 =  (sc_lv<12>) (sext_ln1116_98_cast_fu_54085_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1698_fu_85866_p1() {
    mul_ln1118_1698_fu_85866_p1 = tmp_1698_reg_105047.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1698_fu_85866_p2() {
    mul_ln1118_1698_fu_85866_p2 = (!mul_ln1118_1698_fu_85866_p0.read().is_01() || !mul_ln1118_1698_fu_85866_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1698_fu_85866_p0.read()) * sc_bigint<5>(mul_ln1118_1698_fu_85866_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1699_fu_85885_p0() {
    mul_ln1118_1699_fu_85885_p0 =  (sc_lv<12>) (sext_ln1116_99_cast_fu_54107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1699_fu_85885_p1() {
    mul_ln1118_1699_fu_85885_p1 = tmp_1699_reg_105052.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1699_fu_85885_p2() {
    mul_ln1118_1699_fu_85885_p2 = (!mul_ln1118_1699_fu_85885_p0.read().is_01() || !mul_ln1118_1699_fu_85885_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1699_fu_85885_p0.read()) * sc_bigint<5>(mul_ln1118_1699_fu_85885_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_169_fu_55333_p0() {
    mul_ln1118_169_fu_55333_p0 =  (sc_lv<12>) (sext_ln1116_169_cast_fu_55327_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_169_fu_55333_p1() {
    mul_ln1118_169_fu_55333_p1 = tmp_169_reg_97230.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_169_fu_55333_p2() {
    mul_ln1118_169_fu_55333_p2 = (!mul_ln1118_169_fu_55333_p0.read().is_01() || !mul_ln1118_169_fu_55333_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_169_fu_55333_p0.read()) * sc_bigint<5>(mul_ln1118_169_fu_55333_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_16_fu_52691_p0() {
    mul_ln1118_16_fu_52691_p0 =  (sc_lv<12>) (sext_ln1116_16_cast_fu_52685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_16_fu_52691_p1() {
    mul_ln1118_16_fu_52691_p1 = tmp_17_reg_95820.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_16_fu_52691_p2() {
    mul_ln1118_16_fu_52691_p2 = (!mul_ln1118_16_fu_52691_p0.read().is_01() || !mul_ln1118_16_fu_52691_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_16_fu_52691_p0.read()) * sc_bigint<5>(mul_ln1118_16_fu_52691_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1700_fu_85904_p0() {
    mul_ln1118_1700_fu_85904_p0 =  (sc_lv<12>) (sext_ln1116_100_cast_fu_54129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1700_fu_85904_p1() {
    mul_ln1118_1700_fu_85904_p1 = tmp_1700_reg_105057.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1700_fu_85904_p2() {
    mul_ln1118_1700_fu_85904_p2 = (!mul_ln1118_1700_fu_85904_p0.read().is_01() || !mul_ln1118_1700_fu_85904_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1700_fu_85904_p0.read()) * sc_bigint<5>(mul_ln1118_1700_fu_85904_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1701_fu_85923_p0() {
    mul_ln1118_1701_fu_85923_p0 =  (sc_lv<12>) (sext_ln1116_101_cast_fu_54151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1701_fu_85923_p1() {
    mul_ln1118_1701_fu_85923_p1 = tmp_1701_reg_105062.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1701_fu_85923_p2() {
    mul_ln1118_1701_fu_85923_p2 = (!mul_ln1118_1701_fu_85923_p0.read().is_01() || !mul_ln1118_1701_fu_85923_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1701_fu_85923_p0.read()) * sc_bigint<5>(mul_ln1118_1701_fu_85923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1702_fu_85942_p0() {
    mul_ln1118_1702_fu_85942_p0 =  (sc_lv<12>) (sext_ln1116_102_cast_reg_96606.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1702_fu_85942_p1() {
    mul_ln1118_1702_fu_85942_p1 = tmp_1702_reg_105067.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1702_fu_85942_p2() {
    mul_ln1118_1702_fu_85942_p2 = (!mul_ln1118_1702_fu_85942_p0.read().is_01() || !mul_ln1118_1702_fu_85942_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1702_fu_85942_p0.read()) * sc_bigint<5>(mul_ln1118_1702_fu_85942_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1703_fu_48005_p0() {
    mul_ln1118_1703_fu_48005_p0 =  (sc_lv<12>) (sext_ln1116_103_cast_fu_23993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1703_fu_48005_p1() {
    mul_ln1118_1703_fu_48005_p1 = tmp_1703_fu_47991_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1703_fu_48005_p2() {
    mul_ln1118_1703_fu_48005_p2 = (!mul_ln1118_1703_fu_48005_p0.read().is_01() || !mul_ln1118_1703_fu_48005_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1703_fu_48005_p0.read()) * sc_bigint<5>(mul_ln1118_1703_fu_48005_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1704_fu_48035_p0() {
    mul_ln1118_1704_fu_48035_p0 =  (sc_lv<12>) (sext_ln1116_104_cast_fu_24035_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1704_fu_48035_p1() {
    mul_ln1118_1704_fu_48035_p1 = tmp_1704_fu_48021_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1704_fu_48035_p2() {
    mul_ln1118_1704_fu_48035_p2 = (!mul_ln1118_1704_fu_48035_p0.read().is_01() || !mul_ln1118_1704_fu_48035_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1704_fu_48035_p0.read()) * sc_bigint<5>(mul_ln1118_1704_fu_48035_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1705_fu_48065_p0() {
    mul_ln1118_1705_fu_48065_p0 =  (sc_lv<12>) (sext_ln1116_105_cast_fu_24077_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1705_fu_48065_p1() {
    mul_ln1118_1705_fu_48065_p1 = tmp_1705_fu_48051_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1705_fu_48065_p2() {
    mul_ln1118_1705_fu_48065_p2 = (!mul_ln1118_1705_fu_48065_p0.read().is_01() || !mul_ln1118_1705_fu_48065_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1705_fu_48065_p0.read()) * sc_bigint<5>(mul_ln1118_1705_fu_48065_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1706_fu_48095_p0() {
    mul_ln1118_1706_fu_48095_p0 =  (sc_lv<12>) (sext_ln1116_106_cast_fu_24119_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1706_fu_48095_p1() {
    mul_ln1118_1706_fu_48095_p1 = tmp_1706_fu_48081_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1706_fu_48095_p2() {
    mul_ln1118_1706_fu_48095_p2 = (!mul_ln1118_1706_fu_48095_p0.read().is_01() || !mul_ln1118_1706_fu_48095_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1706_fu_48095_p0.read()) * sc_bigint<5>(mul_ln1118_1706_fu_48095_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1707_fu_48125_p0() {
    mul_ln1118_1707_fu_48125_p0 =  (sc_lv<12>) (sext_ln1116_107_cast_fu_24161_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1707_fu_48125_p1() {
    mul_ln1118_1707_fu_48125_p1 = tmp_1707_fu_48111_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1707_fu_48125_p2() {
    mul_ln1118_1707_fu_48125_p2 = (!mul_ln1118_1707_fu_48125_p0.read().is_01() || !mul_ln1118_1707_fu_48125_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1707_fu_48125_p0.read()) * sc_bigint<5>(mul_ln1118_1707_fu_48125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1708_fu_48155_p0() {
    mul_ln1118_1708_fu_48155_p0 =  (sc_lv<12>) (sext_ln1116_108_cast_fu_24203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1708_fu_48155_p1() {
    mul_ln1118_1708_fu_48155_p1 = tmp_1708_fu_48141_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1708_fu_48155_p2() {
    mul_ln1118_1708_fu_48155_p2 = (!mul_ln1118_1708_fu_48155_p0.read().is_01() || !mul_ln1118_1708_fu_48155_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1708_fu_48155_p0.read()) * sc_bigint<5>(mul_ln1118_1708_fu_48155_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1709_fu_85960_p0() {
    mul_ln1118_1709_fu_85960_p0 =  (sc_lv<12>) (sext_ln1116_109_cast_fu_54191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1709_fu_85960_p1() {
    mul_ln1118_1709_fu_85960_p1 = tmp_1709_reg_105102.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1709_fu_85960_p2() {
    mul_ln1118_1709_fu_85960_p2 = (!mul_ln1118_1709_fu_85960_p0.read().is_01() || !mul_ln1118_1709_fu_85960_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1709_fu_85960_p0.read()) * sc_bigint<5>(mul_ln1118_1709_fu_85960_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_170_fu_55355_p0() {
    mul_ln1118_170_fu_55355_p0 =  (sc_lv<12>) (sext_ln1116_170_cast_fu_55349_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_170_fu_55355_p1() {
    mul_ln1118_170_fu_55355_p1 = tmp_170_reg_97240.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_170_fu_55355_p2() {
    mul_ln1118_170_fu_55355_p2 = (!mul_ln1118_170_fu_55355_p0.read().is_01() || !mul_ln1118_170_fu_55355_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_170_fu_55355_p0.read()) * sc_bigint<5>(mul_ln1118_170_fu_55355_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1710_fu_85979_p0() {
    mul_ln1118_1710_fu_85979_p0 =  (sc_lv<12>) (sext_ln1116_110_cast_fu_54213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1710_fu_85979_p1() {
    mul_ln1118_1710_fu_85979_p1 = tmp_1710_reg_105107.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1710_fu_85979_p2() {
    mul_ln1118_1710_fu_85979_p2 = (!mul_ln1118_1710_fu_85979_p0.read().is_01() || !mul_ln1118_1710_fu_85979_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1710_fu_85979_p0.read()) * sc_bigint<5>(mul_ln1118_1710_fu_85979_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1711_fu_85998_p0() {
    mul_ln1118_1711_fu_85998_p0 =  (sc_lv<12>) (sext_ln1116_111_cast_fu_54235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1711_fu_85998_p1() {
    mul_ln1118_1711_fu_85998_p1 = tmp_1711_reg_105112.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1711_fu_85998_p2() {
    mul_ln1118_1711_fu_85998_p2 = (!mul_ln1118_1711_fu_85998_p0.read().is_01() || !mul_ln1118_1711_fu_85998_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1711_fu_85998_p0.read()) * sc_bigint<5>(mul_ln1118_1711_fu_85998_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1712_fu_86017_p0() {
    mul_ln1118_1712_fu_86017_p0 =  (sc_lv<12>) (sext_ln1116_112_cast_fu_54257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1712_fu_86017_p1() {
    mul_ln1118_1712_fu_86017_p1 = tmp_1712_reg_105117.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1712_fu_86017_p2() {
    mul_ln1118_1712_fu_86017_p2 = (!mul_ln1118_1712_fu_86017_p0.read().is_01() || !mul_ln1118_1712_fu_86017_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1712_fu_86017_p0.read()) * sc_bigint<5>(mul_ln1118_1712_fu_86017_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1713_fu_86036_p0() {
    mul_ln1118_1713_fu_86036_p0 =  (sc_lv<12>) (sext_ln1116_113_cast_fu_54279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1713_fu_86036_p1() {
    mul_ln1118_1713_fu_86036_p1 = tmp_1713_reg_105122.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1713_fu_86036_p2() {
    mul_ln1118_1713_fu_86036_p2 = (!mul_ln1118_1713_fu_86036_p0.read().is_01() || !mul_ln1118_1713_fu_86036_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1713_fu_86036_p0.read()) * sc_bigint<5>(mul_ln1118_1713_fu_86036_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1714_fu_86055_p0() {
    mul_ln1118_1714_fu_86055_p0 =  (sc_lv<12>) (sext_ln1116_114_cast_fu_54301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1714_fu_86055_p1() {
    mul_ln1118_1714_fu_86055_p1 = tmp_1714_reg_105127.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1714_fu_86055_p2() {
    mul_ln1118_1714_fu_86055_p2 = (!mul_ln1118_1714_fu_86055_p0.read().is_01() || !mul_ln1118_1714_fu_86055_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1714_fu_86055_p0.read()) * sc_bigint<5>(mul_ln1118_1714_fu_86055_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1715_fu_86074_p0() {
    mul_ln1118_1715_fu_86074_p0 =  (sc_lv<12>) (sext_ln1116_115_cast_fu_54323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1715_fu_86074_p1() {
    mul_ln1118_1715_fu_86074_p1 = tmp_1715_reg_105132.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1715_fu_86074_p2() {
    mul_ln1118_1715_fu_86074_p2 = (!mul_ln1118_1715_fu_86074_p0.read().is_01() || !mul_ln1118_1715_fu_86074_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1715_fu_86074_p0.read()) * sc_bigint<5>(mul_ln1118_1715_fu_86074_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1716_fu_86093_p0() {
    mul_ln1118_1716_fu_86093_p0 =  (sc_lv<12>) (sext_ln1116_116_cast_fu_54345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1716_fu_86093_p1() {
    mul_ln1118_1716_fu_86093_p1 = tmp_1716_reg_105137.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1716_fu_86093_p2() {
    mul_ln1118_1716_fu_86093_p2 = (!mul_ln1118_1716_fu_86093_p0.read().is_01() || !mul_ln1118_1716_fu_86093_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1716_fu_86093_p0.read()) * sc_bigint<5>(mul_ln1118_1716_fu_86093_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1717_fu_86112_p0() {
    mul_ln1118_1717_fu_86112_p0 =  (sc_lv<12>) (sext_ln1116_117_cast_fu_54367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1717_fu_86112_p1() {
    mul_ln1118_1717_fu_86112_p1 = tmp_1717_reg_105142.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1717_fu_86112_p2() {
    mul_ln1118_1717_fu_86112_p2 = (!mul_ln1118_1717_fu_86112_p0.read().is_01() || !mul_ln1118_1717_fu_86112_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1717_fu_86112_p0.read()) * sc_bigint<5>(mul_ln1118_1717_fu_86112_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1718_fu_86131_p0() {
    mul_ln1118_1718_fu_86131_p0 =  (sc_lv<12>) (sext_ln1116_118_cast_fu_54389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1718_fu_86131_p1() {
    mul_ln1118_1718_fu_86131_p1 = tmp_1718_reg_105147.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1718_fu_86131_p2() {
    mul_ln1118_1718_fu_86131_p2 = (!mul_ln1118_1718_fu_86131_p0.read().is_01() || !mul_ln1118_1718_fu_86131_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1718_fu_86131_p0.read()) * sc_bigint<5>(mul_ln1118_1718_fu_86131_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1719_fu_86150_p0() {
    mul_ln1118_1719_fu_86150_p0 =  (sc_lv<12>) (sext_ln1116_119_cast_fu_54411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1719_fu_86150_p1() {
    mul_ln1118_1719_fu_86150_p1 = tmp_1719_reg_105152.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1719_fu_86150_p2() {
    mul_ln1118_1719_fu_86150_p2 = (!mul_ln1118_1719_fu_86150_p0.read().is_01() || !mul_ln1118_1719_fu_86150_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1719_fu_86150_p0.read()) * sc_bigint<5>(mul_ln1118_1719_fu_86150_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_171_fu_55377_p0() {
    mul_ln1118_171_fu_55377_p0 =  (sc_lv<12>) (sext_ln1116_171_cast_fu_55371_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_171_fu_55377_p1() {
    mul_ln1118_171_fu_55377_p1 = tmp_171_reg_97250.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_171_fu_55377_p2() {
    mul_ln1118_171_fu_55377_p2 = (!mul_ln1118_171_fu_55377_p0.read().is_01() || !mul_ln1118_171_fu_55377_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_171_fu_55377_p0.read()) * sc_bigint<5>(mul_ln1118_171_fu_55377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1720_fu_86169_p0() {
    mul_ln1118_1720_fu_86169_p0 =  (sc_lv<12>) (sext_ln1116_120_cast_fu_54433_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1720_fu_86169_p1() {
    mul_ln1118_1720_fu_86169_p1 = tmp_1720_reg_105157.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1720_fu_86169_p2() {
    mul_ln1118_1720_fu_86169_p2 = (!mul_ln1118_1720_fu_86169_p0.read().is_01() || !mul_ln1118_1720_fu_86169_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1720_fu_86169_p0.read()) * sc_bigint<5>(mul_ln1118_1720_fu_86169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1721_fu_86188_p0() {
    mul_ln1118_1721_fu_86188_p0 =  (sc_lv<12>) (sext_ln1116_121_cast_fu_54455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1721_fu_86188_p1() {
    mul_ln1118_1721_fu_86188_p1 = tmp_1721_reg_105162.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1721_fu_86188_p2() {
    mul_ln1118_1721_fu_86188_p2 = (!mul_ln1118_1721_fu_86188_p0.read().is_01() || !mul_ln1118_1721_fu_86188_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1721_fu_86188_p0.read()) * sc_bigint<5>(mul_ln1118_1721_fu_86188_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1722_fu_86207_p0() {
    mul_ln1118_1722_fu_86207_p0 =  (sc_lv<12>) (sext_ln1116_122_cast_fu_54477_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1722_fu_86207_p1() {
    mul_ln1118_1722_fu_86207_p1 = tmp_1722_reg_105167.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1722_fu_86207_p2() {
    mul_ln1118_1722_fu_86207_p2 = (!mul_ln1118_1722_fu_86207_p0.read().is_01() || !mul_ln1118_1722_fu_86207_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1722_fu_86207_p0.read()) * sc_bigint<5>(mul_ln1118_1722_fu_86207_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1723_fu_86226_p0() {
    mul_ln1118_1723_fu_86226_p0 =  (sc_lv<12>) (sext_ln1116_123_cast_fu_54499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1723_fu_86226_p1() {
    mul_ln1118_1723_fu_86226_p1 = tmp_1723_reg_105172.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1723_fu_86226_p2() {
    mul_ln1118_1723_fu_86226_p2 = (!mul_ln1118_1723_fu_86226_p0.read().is_01() || !mul_ln1118_1723_fu_86226_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1723_fu_86226_p0.read()) * sc_bigint<5>(mul_ln1118_1723_fu_86226_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1724_fu_86245_p0() {
    mul_ln1118_1724_fu_86245_p0 =  (sc_lv<12>) (sext_ln1116_124_cast_fu_54521_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1724_fu_86245_p1() {
    mul_ln1118_1724_fu_86245_p1 = tmp_1724_reg_105177.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1724_fu_86245_p2() {
    mul_ln1118_1724_fu_86245_p2 = (!mul_ln1118_1724_fu_86245_p0.read().is_01() || !mul_ln1118_1724_fu_86245_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1724_fu_86245_p0.read()) * sc_bigint<5>(mul_ln1118_1724_fu_86245_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1725_fu_86264_p0() {
    mul_ln1118_1725_fu_86264_p0 =  (sc_lv<12>) (sext_ln1116_125_cast_fu_54543_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1725_fu_86264_p1() {
    mul_ln1118_1725_fu_86264_p1 = tmp_1725_reg_105182.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1725_fu_86264_p2() {
    mul_ln1118_1725_fu_86264_p2 = (!mul_ln1118_1725_fu_86264_p0.read().is_01() || !mul_ln1118_1725_fu_86264_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1725_fu_86264_p0.read()) * sc_bigint<5>(mul_ln1118_1725_fu_86264_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1726_fu_86283_p0() {
    mul_ln1118_1726_fu_86283_p0 =  (sc_lv<12>) (sext_ln1116_126_cast_fu_54565_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1726_fu_86283_p1() {
    mul_ln1118_1726_fu_86283_p1 = tmp_1726_reg_105187.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1726_fu_86283_p2() {
    mul_ln1118_1726_fu_86283_p2 = (!mul_ln1118_1726_fu_86283_p0.read().is_01() || !mul_ln1118_1726_fu_86283_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1726_fu_86283_p0.read()) * sc_bigint<5>(mul_ln1118_1726_fu_86283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1727_fu_86302_p0() {
    mul_ln1118_1727_fu_86302_p0 =  (sc_lv<12>) (sext_ln1116_127_cast_fu_54587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1727_fu_86302_p1() {
    mul_ln1118_1727_fu_86302_p1 = tmp_1727_reg_105192.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1727_fu_86302_p2() {
    mul_ln1118_1727_fu_86302_p2 = (!mul_ln1118_1727_fu_86302_p0.read().is_01() || !mul_ln1118_1727_fu_86302_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1727_fu_86302_p0.read()) * sc_bigint<5>(mul_ln1118_1727_fu_86302_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1728_fu_86321_p0() {
    mul_ln1118_1728_fu_86321_p0 =  (sc_lv<12>) (sext_ln1116_128_cast_fu_54609_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1728_fu_86321_p1() {
    mul_ln1118_1728_fu_86321_p1 = tmp_1728_reg_105197.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1728_fu_86321_p2() {
    mul_ln1118_1728_fu_86321_p2 = (!mul_ln1118_1728_fu_86321_p0.read().is_01() || !mul_ln1118_1728_fu_86321_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1728_fu_86321_p0.read()) * sc_bigint<5>(mul_ln1118_1728_fu_86321_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1729_fu_86340_p0() {
    mul_ln1118_1729_fu_86340_p0 =  (sc_lv<12>) (sext_ln1116_129_cast_fu_54631_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1729_fu_86340_p1() {
    mul_ln1118_1729_fu_86340_p1 = tmp_1729_reg_105202.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1729_fu_86340_p2() {
    mul_ln1118_1729_fu_86340_p2 = (!mul_ln1118_1729_fu_86340_p0.read().is_01() || !mul_ln1118_1729_fu_86340_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1729_fu_86340_p0.read()) * sc_bigint<5>(mul_ln1118_1729_fu_86340_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_172_fu_55399_p0() {
    mul_ln1118_172_fu_55399_p0 =  (sc_lv<12>) (sext_ln1116_172_cast_fu_55393_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_172_fu_55399_p1() {
    mul_ln1118_172_fu_55399_p1 = tmp_172_reg_97260.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_172_fu_55399_p2() {
    mul_ln1118_172_fu_55399_p2 = (!mul_ln1118_172_fu_55399_p0.read().is_01() || !mul_ln1118_172_fu_55399_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_172_fu_55399_p0.read()) * sc_bigint<5>(mul_ln1118_172_fu_55399_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1730_fu_86359_p0() {
    mul_ln1118_1730_fu_86359_p0 =  (sc_lv<12>) (sext_ln1116_130_cast_fu_54653_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1730_fu_86359_p1() {
    mul_ln1118_1730_fu_86359_p1 = tmp_1730_reg_105207.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1730_fu_86359_p2() {
    mul_ln1118_1730_fu_86359_p2 = (!mul_ln1118_1730_fu_86359_p0.read().is_01() || !mul_ln1118_1730_fu_86359_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1730_fu_86359_p0.read()) * sc_bigint<5>(mul_ln1118_1730_fu_86359_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1731_fu_86378_p0() {
    mul_ln1118_1731_fu_86378_p0 =  (sc_lv<12>) (sext_ln1116_131_cast_fu_54675_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1731_fu_86378_p1() {
    mul_ln1118_1731_fu_86378_p1 = tmp_1731_reg_105212.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1731_fu_86378_p2() {
    mul_ln1118_1731_fu_86378_p2 = (!mul_ln1118_1731_fu_86378_p0.read().is_01() || !mul_ln1118_1731_fu_86378_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1731_fu_86378_p0.read()) * sc_bigint<5>(mul_ln1118_1731_fu_86378_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1732_fu_48415_p0() {
    mul_ln1118_1732_fu_48415_p0 =  (sc_lv<12>) (sext_ln1116_132_cast_fu_24659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1732_fu_48415_p1() {
    mul_ln1118_1732_fu_48415_p1 = tmp_1732_fu_48401_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1732_fu_48415_p2() {
    mul_ln1118_1732_fu_48415_p2 = (!mul_ln1118_1732_fu_48415_p0.read().is_01() || !mul_ln1118_1732_fu_48415_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1732_fu_48415_p0.read()) * sc_bigint<5>(mul_ln1118_1732_fu_48415_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1733_fu_48445_p0() {
    mul_ln1118_1733_fu_48445_p0 =  (sc_lv<12>) (sext_ln1116_133_cast_fu_24701_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1733_fu_48445_p1() {
    mul_ln1118_1733_fu_48445_p1 = tmp_1733_fu_48431_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1733_fu_48445_p2() {
    mul_ln1118_1733_fu_48445_p2 = (!mul_ln1118_1733_fu_48445_p0.read().is_01() || !mul_ln1118_1733_fu_48445_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1733_fu_48445_p0.read()) * sc_bigint<5>(mul_ln1118_1733_fu_48445_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1734_fu_86397_p0() {
    mul_ln1118_1734_fu_86397_p0 =  (sc_lv<12>) (sext_ln1116_134_cast_fu_54697_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1734_fu_86397_p1() {
    mul_ln1118_1734_fu_86397_p1 = tmp_1734_reg_105227.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1734_fu_86397_p2() {
    mul_ln1118_1734_fu_86397_p2 = (!mul_ln1118_1734_fu_86397_p0.read().is_01() || !mul_ln1118_1734_fu_86397_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1734_fu_86397_p0.read()) * sc_bigint<5>(mul_ln1118_1734_fu_86397_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1735_fu_86416_p0() {
    mul_ln1118_1735_fu_86416_p0 =  (sc_lv<12>) (sext_ln1116_135_cast_fu_54719_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1735_fu_86416_p1() {
    mul_ln1118_1735_fu_86416_p1 = tmp_1735_reg_105232.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1735_fu_86416_p2() {
    mul_ln1118_1735_fu_86416_p2 = (!mul_ln1118_1735_fu_86416_p0.read().is_01() || !mul_ln1118_1735_fu_86416_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1735_fu_86416_p0.read()) * sc_bigint<5>(mul_ln1118_1735_fu_86416_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1736_fu_86435_p0() {
    mul_ln1118_1736_fu_86435_p0 =  (sc_lv<12>) (sext_ln1116_136_cast_fu_54741_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1736_fu_86435_p1() {
    mul_ln1118_1736_fu_86435_p1 = tmp_1736_reg_105237.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1736_fu_86435_p2() {
    mul_ln1118_1736_fu_86435_p2 = (!mul_ln1118_1736_fu_86435_p0.read().is_01() || !mul_ln1118_1736_fu_86435_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1736_fu_86435_p0.read()) * sc_bigint<5>(mul_ln1118_1736_fu_86435_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1737_fu_86454_p0() {
    mul_ln1118_1737_fu_86454_p0 =  (sc_lv<12>) (sext_ln1116_137_cast_fu_54763_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1737_fu_86454_p1() {
    mul_ln1118_1737_fu_86454_p1 = tmp_1737_reg_105242.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1737_fu_86454_p2() {
    mul_ln1118_1737_fu_86454_p2 = (!mul_ln1118_1737_fu_86454_p0.read().is_01() || !mul_ln1118_1737_fu_86454_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1737_fu_86454_p0.read()) * sc_bigint<5>(mul_ln1118_1737_fu_86454_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1738_fu_86473_p0() {
    mul_ln1118_1738_fu_86473_p0 =  (sc_lv<12>) (sext_ln1116_138_cast_fu_54785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1738_fu_86473_p1() {
    mul_ln1118_1738_fu_86473_p1 = tmp_1738_reg_105247.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1738_fu_86473_p2() {
    mul_ln1118_1738_fu_86473_p2 = (!mul_ln1118_1738_fu_86473_p0.read().is_01() || !mul_ln1118_1738_fu_86473_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1738_fu_86473_p0.read()) * sc_bigint<5>(mul_ln1118_1738_fu_86473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1739_fu_86492_p0() {
    mul_ln1118_1739_fu_86492_p0 =  (sc_lv<12>) (sext_ln1116_139_cast_fu_54807_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1739_fu_86492_p1() {
    mul_ln1118_1739_fu_86492_p1 = tmp_1739_reg_105252.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1739_fu_86492_p2() {
    mul_ln1118_1739_fu_86492_p2 = (!mul_ln1118_1739_fu_86492_p0.read().is_01() || !mul_ln1118_1739_fu_86492_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1739_fu_86492_p0.read()) * sc_bigint<5>(mul_ln1118_1739_fu_86492_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_173_fu_55421_p0() {
    mul_ln1118_173_fu_55421_p0 =  (sc_lv<12>) (sext_ln1116_173_cast_fu_55415_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_173_fu_55421_p1() {
    mul_ln1118_173_fu_55421_p1 = tmp_173_reg_97270.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_173_fu_55421_p2() {
    mul_ln1118_173_fu_55421_p2 = (!mul_ln1118_173_fu_55421_p0.read().is_01() || !mul_ln1118_173_fu_55421_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_173_fu_55421_p0.read()) * sc_bigint<5>(mul_ln1118_173_fu_55421_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1740_fu_86511_p0() {
    mul_ln1118_1740_fu_86511_p0 =  (sc_lv<12>) (sext_ln1116_140_cast_fu_54829_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1740_fu_86511_p1() {
    mul_ln1118_1740_fu_86511_p1 = tmp_1740_reg_105257.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1740_fu_86511_p2() {
    mul_ln1118_1740_fu_86511_p2 = (!mul_ln1118_1740_fu_86511_p0.read().is_01() || !mul_ln1118_1740_fu_86511_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1740_fu_86511_p0.read()) * sc_bigint<5>(mul_ln1118_1740_fu_86511_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1741_fu_86530_p0() {
    mul_ln1118_1741_fu_86530_p0 =  (sc_lv<12>) (sext_ln1116_141_cast_fu_54851_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1741_fu_86530_p1() {
    mul_ln1118_1741_fu_86530_p1 = tmp_1741_reg_105262.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1741_fu_86530_p2() {
    mul_ln1118_1741_fu_86530_p2 = (!mul_ln1118_1741_fu_86530_p0.read().is_01() || !mul_ln1118_1741_fu_86530_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1741_fu_86530_p0.read()) * sc_bigint<5>(mul_ln1118_1741_fu_86530_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1742_fu_86549_p0() {
    mul_ln1118_1742_fu_86549_p0 =  (sc_lv<12>) (sext_ln1116_142_cast_fu_54873_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1742_fu_86549_p1() {
    mul_ln1118_1742_fu_86549_p1 = tmp_1742_reg_105267.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1742_fu_86549_p2() {
    mul_ln1118_1742_fu_86549_p2 = (!mul_ln1118_1742_fu_86549_p0.read().is_01() || !mul_ln1118_1742_fu_86549_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1742_fu_86549_p0.read()) * sc_bigint<5>(mul_ln1118_1742_fu_86549_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1743_fu_86568_p0() {
    mul_ln1118_1743_fu_86568_p0 =  (sc_lv<12>) (sext_ln1116_143_cast_fu_54895_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1743_fu_86568_p1() {
    mul_ln1118_1743_fu_86568_p1 = tmp_1743_reg_105272.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1743_fu_86568_p2() {
    mul_ln1118_1743_fu_86568_p2 = (!mul_ln1118_1743_fu_86568_p0.read().is_01() || !mul_ln1118_1743_fu_86568_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1743_fu_86568_p0.read()) * sc_bigint<5>(mul_ln1118_1743_fu_86568_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1744_fu_86587_p0() {
    mul_ln1118_1744_fu_86587_p0 =  (sc_lv<12>) (sext_ln1116_144_cast_fu_54917_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1744_fu_86587_p1() {
    mul_ln1118_1744_fu_86587_p1 = tmp_1744_reg_105277.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1744_fu_86587_p2() {
    mul_ln1118_1744_fu_86587_p2 = (!mul_ln1118_1744_fu_86587_p0.read().is_01() || !mul_ln1118_1744_fu_86587_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1744_fu_86587_p0.read()) * sc_bigint<5>(mul_ln1118_1744_fu_86587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1745_fu_86606_p0() {
    mul_ln1118_1745_fu_86606_p0 =  (sc_lv<12>) (sext_ln1116_145_cast_fu_54939_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1745_fu_86606_p1() {
    mul_ln1118_1745_fu_86606_p1 = tmp_1745_reg_105282.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1745_fu_86606_p2() {
    mul_ln1118_1745_fu_86606_p2 = (!mul_ln1118_1745_fu_86606_p0.read().is_01() || !mul_ln1118_1745_fu_86606_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1745_fu_86606_p0.read()) * sc_bigint<5>(mul_ln1118_1745_fu_86606_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1746_fu_86625_p0() {
    mul_ln1118_1746_fu_86625_p0 =  (sc_lv<12>) (sext_ln1116_146_cast_fu_54961_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1746_fu_86625_p1() {
    mul_ln1118_1746_fu_86625_p1 = tmp_1746_reg_105287.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1746_fu_86625_p2() {
    mul_ln1118_1746_fu_86625_p2 = (!mul_ln1118_1746_fu_86625_p0.read().is_01() || !mul_ln1118_1746_fu_86625_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1746_fu_86625_p0.read()) * sc_bigint<5>(mul_ln1118_1746_fu_86625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1747_fu_86644_p0() {
    mul_ln1118_1747_fu_86644_p0 =  (sc_lv<12>) (sext_ln1116_147_cast_fu_54983_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1747_fu_86644_p1() {
    mul_ln1118_1747_fu_86644_p1 = tmp_1747_reg_105292.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1747_fu_86644_p2() {
    mul_ln1118_1747_fu_86644_p2 = (!mul_ln1118_1747_fu_86644_p0.read().is_01() || !mul_ln1118_1747_fu_86644_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1747_fu_86644_p0.read()) * sc_bigint<5>(mul_ln1118_1747_fu_86644_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1748_fu_86663_p0() {
    mul_ln1118_1748_fu_86663_p0 =  (sc_lv<12>) (sext_ln1116_148_cast_fu_55005_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1748_fu_86663_p1() {
    mul_ln1118_1748_fu_86663_p1 = tmp_1748_reg_105297.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1748_fu_86663_p2() {
    mul_ln1118_1748_fu_86663_p2 = (!mul_ln1118_1748_fu_86663_p0.read().is_01() || !mul_ln1118_1748_fu_86663_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1748_fu_86663_p0.read()) * sc_bigint<5>(mul_ln1118_1748_fu_86663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1749_fu_86682_p0() {
    mul_ln1118_1749_fu_86682_p0 =  (sc_lv<12>) (sext_ln1116_149_cast_fu_55027_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1749_fu_86682_p1() {
    mul_ln1118_1749_fu_86682_p1 = tmp_1749_reg_105302.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1749_fu_86682_p2() {
    mul_ln1118_1749_fu_86682_p2 = (!mul_ln1118_1749_fu_86682_p0.read().is_01() || !mul_ln1118_1749_fu_86682_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1749_fu_86682_p0.read()) * sc_bigint<5>(mul_ln1118_1749_fu_86682_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_174_fu_55443_p0() {
    mul_ln1118_174_fu_55443_p0 =  (sc_lv<12>) (sext_ln1116_174_cast_fu_55437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_174_fu_55443_p1() {
    mul_ln1118_174_fu_55443_p1 = tmp_174_reg_97280.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_174_fu_55443_p2() {
    mul_ln1118_174_fu_55443_p2 = (!mul_ln1118_174_fu_55443_p0.read().is_01() || !mul_ln1118_174_fu_55443_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_174_fu_55443_p0.read()) * sc_bigint<5>(mul_ln1118_174_fu_55443_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1750_fu_86701_p0() {
    mul_ln1118_1750_fu_86701_p0 =  (sc_lv<12>) (sext_ln1116_150_cast_fu_55049_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1750_fu_86701_p1() {
    mul_ln1118_1750_fu_86701_p1 = tmp_1750_reg_105307.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1750_fu_86701_p2() {
    mul_ln1118_1750_fu_86701_p2 = (!mul_ln1118_1750_fu_86701_p0.read().is_01() || !mul_ln1118_1750_fu_86701_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1750_fu_86701_p0.read()) * sc_bigint<5>(mul_ln1118_1750_fu_86701_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1751_fu_86720_p0() {
    mul_ln1118_1751_fu_86720_p0 =  (sc_lv<12>) (sext_ln1116_151_cast_reg_97064.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1751_fu_86720_p1() {
    mul_ln1118_1751_fu_86720_p1 = tmp_1751_reg_105312.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1751_fu_86720_p2() {
    mul_ln1118_1751_fu_86720_p2 = (!mul_ln1118_1751_fu_86720_p0.read().is_01() || !mul_ln1118_1751_fu_86720_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1751_fu_86720_p0.read()) * sc_bigint<5>(mul_ln1118_1751_fu_86720_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1752_fu_86738_p0() {
    mul_ln1118_1752_fu_86738_p0 =  (sc_lv<12>) (sext_ln1116_152_cast_reg_97082.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1752_fu_86738_p1() {
    mul_ln1118_1752_fu_86738_p1 = tmp_1752_reg_105317.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1752_fu_86738_p2() {
    mul_ln1118_1752_fu_86738_p2 = (!mul_ln1118_1752_fu_86738_p0.read().is_01() || !mul_ln1118_1752_fu_86738_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1752_fu_86738_p0.read()) * sc_bigint<5>(mul_ln1118_1752_fu_86738_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1753_fu_48665_p0() {
    mul_ln1118_1753_fu_48665_p0 =  (sc_lv<12>) (sext_ln1116_153_cast_fu_25093_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1753_fu_48665_p1() {
    mul_ln1118_1753_fu_48665_p1 = tmp_1753_fu_48651_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1753_fu_48665_p2() {
    mul_ln1118_1753_fu_48665_p2 = (!mul_ln1118_1753_fu_48665_p0.read().is_01() || !mul_ln1118_1753_fu_48665_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1753_fu_48665_p0.read()) * sc_bigint<5>(mul_ln1118_1753_fu_48665_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1754_fu_48695_p0() {
    mul_ln1118_1754_fu_48695_p0 =  (sc_lv<12>) (sext_ln1116_154_cast_fu_25135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1754_fu_48695_p1() {
    mul_ln1118_1754_fu_48695_p1 = tmp_1754_fu_48681_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1754_fu_48695_p2() {
    mul_ln1118_1754_fu_48695_p2 = (!mul_ln1118_1754_fu_48695_p0.read().is_01() || !mul_ln1118_1754_fu_48695_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1754_fu_48695_p0.read()) * sc_bigint<5>(mul_ln1118_1754_fu_48695_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1755_fu_48725_p0() {
    mul_ln1118_1755_fu_48725_p0 =  (sc_lv<12>) (sext_ln1116_155_cast_fu_25177_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1755_fu_48725_p1() {
    mul_ln1118_1755_fu_48725_p1 = tmp_1755_fu_48711_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1755_fu_48725_p2() {
    mul_ln1118_1755_fu_48725_p2 = (!mul_ln1118_1755_fu_48725_p0.read().is_01() || !mul_ln1118_1755_fu_48725_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1755_fu_48725_p0.read()) * sc_bigint<5>(mul_ln1118_1755_fu_48725_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1756_fu_48755_p0() {
    mul_ln1118_1756_fu_48755_p0 =  (sc_lv<12>) (sext_ln1116_156_cast_fu_25219_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1756_fu_48755_p1() {
    mul_ln1118_1756_fu_48755_p1 = tmp_1756_fu_48741_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1756_fu_48755_p2() {
    mul_ln1118_1756_fu_48755_p2 = (!mul_ln1118_1756_fu_48755_p0.read().is_01() || !mul_ln1118_1756_fu_48755_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1756_fu_48755_p0.read()) * sc_bigint<5>(mul_ln1118_1756_fu_48755_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1757_fu_48785_p0() {
    mul_ln1118_1757_fu_48785_p0 =  (sc_lv<12>) (sext_ln1116_157_cast_fu_25261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1757_fu_48785_p1() {
    mul_ln1118_1757_fu_48785_p1 = tmp_1757_fu_48771_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1757_fu_48785_p2() {
    mul_ln1118_1757_fu_48785_p2 = (!mul_ln1118_1757_fu_48785_p0.read().is_01() || !mul_ln1118_1757_fu_48785_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1757_fu_48785_p0.read()) * sc_bigint<5>(mul_ln1118_1757_fu_48785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1758_fu_48815_p0() {
    mul_ln1118_1758_fu_48815_p0 =  (sc_lv<12>) (sext_ln1116_158_cast_fu_25303_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1758_fu_48815_p1() {
    mul_ln1118_1758_fu_48815_p1 = tmp_1758_fu_48801_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1758_fu_48815_p2() {
    mul_ln1118_1758_fu_48815_p2 = (!mul_ln1118_1758_fu_48815_p0.read().is_01() || !mul_ln1118_1758_fu_48815_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1758_fu_48815_p0.read()) * sc_bigint<5>(mul_ln1118_1758_fu_48815_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1759_fu_86756_p0() {
    mul_ln1118_1759_fu_86756_p0 =  (sc_lv<12>) (sext_ln1116_159_cast_fu_55107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1759_fu_86756_p1() {
    mul_ln1118_1759_fu_86756_p1 = tmp_1759_reg_105352.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1759_fu_86756_p2() {
    mul_ln1118_1759_fu_86756_p2 = (!mul_ln1118_1759_fu_86756_p0.read().is_01() || !mul_ln1118_1759_fu_86756_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1759_fu_86756_p0.read()) * sc_bigint<5>(mul_ln1118_1759_fu_86756_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_175_fu_55465_p0() {
    mul_ln1118_175_fu_55465_p0 =  (sc_lv<12>) (sext_ln1116_175_cast_fu_55459_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_175_fu_55465_p1() {
    mul_ln1118_175_fu_55465_p1 = tmp_175_reg_97290.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_175_fu_55465_p2() {
    mul_ln1118_175_fu_55465_p2 = (!mul_ln1118_175_fu_55465_p0.read().is_01() || !mul_ln1118_175_fu_55465_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_175_fu_55465_p0.read()) * sc_bigint<5>(mul_ln1118_175_fu_55465_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1760_fu_86775_p0() {
    mul_ln1118_1760_fu_86775_p0 =  (sc_lv<12>) (sext_ln1116_160_cast_fu_55129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1760_fu_86775_p1() {
    mul_ln1118_1760_fu_86775_p1 = tmp_1760_reg_105357.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1760_fu_86775_p2() {
    mul_ln1118_1760_fu_86775_p2 = (!mul_ln1118_1760_fu_86775_p0.read().is_01() || !mul_ln1118_1760_fu_86775_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1760_fu_86775_p0.read()) * sc_bigint<5>(mul_ln1118_1760_fu_86775_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1761_fu_86794_p0() {
    mul_ln1118_1761_fu_86794_p0 =  (sc_lv<12>) (sext_ln1116_161_cast_fu_55151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1761_fu_86794_p1() {
    mul_ln1118_1761_fu_86794_p1 = tmp_1761_reg_105362.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1761_fu_86794_p2() {
    mul_ln1118_1761_fu_86794_p2 = (!mul_ln1118_1761_fu_86794_p0.read().is_01() || !mul_ln1118_1761_fu_86794_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1761_fu_86794_p0.read()) * sc_bigint<5>(mul_ln1118_1761_fu_86794_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1762_fu_86813_p0() {
    mul_ln1118_1762_fu_86813_p0 =  (sc_lv<12>) (sext_ln1116_162_cast_fu_55173_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1762_fu_86813_p1() {
    mul_ln1118_1762_fu_86813_p1 = tmp_1762_reg_105367.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1762_fu_86813_p2() {
    mul_ln1118_1762_fu_86813_p2 = (!mul_ln1118_1762_fu_86813_p0.read().is_01() || !mul_ln1118_1762_fu_86813_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1762_fu_86813_p0.read()) * sc_bigint<5>(mul_ln1118_1762_fu_86813_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1763_fu_86832_p0() {
    mul_ln1118_1763_fu_86832_p0 =  (sc_lv<12>) (sext_ln1116_163_cast_fu_55195_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1763_fu_86832_p1() {
    mul_ln1118_1763_fu_86832_p1 = tmp_1763_reg_105372.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1763_fu_86832_p2() {
    mul_ln1118_1763_fu_86832_p2 = (!mul_ln1118_1763_fu_86832_p0.read().is_01() || !mul_ln1118_1763_fu_86832_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1763_fu_86832_p0.read()) * sc_bigint<5>(mul_ln1118_1763_fu_86832_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1764_fu_86851_p0() {
    mul_ln1118_1764_fu_86851_p0 =  (sc_lv<12>) (sext_ln1116_164_cast_fu_55217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1764_fu_86851_p1() {
    mul_ln1118_1764_fu_86851_p1 = tmp_1764_reg_105377.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1764_fu_86851_p2() {
    mul_ln1118_1764_fu_86851_p2 = (!mul_ln1118_1764_fu_86851_p0.read().is_01() || !mul_ln1118_1764_fu_86851_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1764_fu_86851_p0.read()) * sc_bigint<5>(mul_ln1118_1764_fu_86851_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1765_fu_86870_p0() {
    mul_ln1118_1765_fu_86870_p0 =  (sc_lv<12>) (sext_ln1116_165_cast_fu_55239_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1765_fu_86870_p1() {
    mul_ln1118_1765_fu_86870_p1 = tmp_1765_reg_105382.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1765_fu_86870_p2() {
    mul_ln1118_1765_fu_86870_p2 = (!mul_ln1118_1765_fu_86870_p0.read().is_01() || !mul_ln1118_1765_fu_86870_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1765_fu_86870_p0.read()) * sc_bigint<5>(mul_ln1118_1765_fu_86870_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1766_fu_86889_p0() {
    mul_ln1118_1766_fu_86889_p0 =  (sc_lv<12>) (sext_ln1116_166_cast_fu_55261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1766_fu_86889_p1() {
    mul_ln1118_1766_fu_86889_p1 = tmp_1766_reg_105387.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1766_fu_86889_p2() {
    mul_ln1118_1766_fu_86889_p2 = (!mul_ln1118_1766_fu_86889_p0.read().is_01() || !mul_ln1118_1766_fu_86889_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1766_fu_86889_p0.read()) * sc_bigint<5>(mul_ln1118_1766_fu_86889_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1767_fu_86908_p0() {
    mul_ln1118_1767_fu_86908_p0 =  (sc_lv<12>) (sext_ln1116_167_cast_fu_55283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1767_fu_86908_p1() {
    mul_ln1118_1767_fu_86908_p1 = tmp_1767_reg_105392.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1767_fu_86908_p2() {
    mul_ln1118_1767_fu_86908_p2 = (!mul_ln1118_1767_fu_86908_p0.read().is_01() || !mul_ln1118_1767_fu_86908_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1767_fu_86908_p0.read()) * sc_bigint<5>(mul_ln1118_1767_fu_86908_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1768_fu_86927_p0() {
    mul_ln1118_1768_fu_86927_p0 =  (sc_lv<12>) (sext_ln1116_168_cast_fu_55305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1768_fu_86927_p1() {
    mul_ln1118_1768_fu_86927_p1 = tmp_1768_reg_105397.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1768_fu_86927_p2() {
    mul_ln1118_1768_fu_86927_p2 = (!mul_ln1118_1768_fu_86927_p0.read().is_01() || !mul_ln1118_1768_fu_86927_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1768_fu_86927_p0.read()) * sc_bigint<5>(mul_ln1118_1768_fu_86927_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1769_fu_86946_p0() {
    mul_ln1118_1769_fu_86946_p0 =  (sc_lv<12>) (sext_ln1116_169_cast_fu_55327_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1769_fu_86946_p1() {
    mul_ln1118_1769_fu_86946_p1 = tmp_1769_reg_105402.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1769_fu_86946_p2() {
    mul_ln1118_1769_fu_86946_p2 = (!mul_ln1118_1769_fu_86946_p0.read().is_01() || !mul_ln1118_1769_fu_86946_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1769_fu_86946_p0.read()) * sc_bigint<5>(mul_ln1118_1769_fu_86946_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_176_fu_55484_p0() {
    mul_ln1118_176_fu_55484_p0 =  (sc_lv<12>) (sext_ln1116_176_cast_reg_97300.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_176_fu_55484_p1() {
    mul_ln1118_176_fu_55484_p1 = tmp_176_reg_97295.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_176_fu_55484_p2() {
    mul_ln1118_176_fu_55484_p2 = (!mul_ln1118_176_fu_55484_p0.read().is_01() || !mul_ln1118_176_fu_55484_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_176_fu_55484_p0.read()) * sc_bigint<5>(mul_ln1118_176_fu_55484_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1770_fu_86965_p0() {
    mul_ln1118_1770_fu_86965_p0 =  (sc_lv<12>) (sext_ln1116_170_cast_fu_55349_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1770_fu_86965_p1() {
    mul_ln1118_1770_fu_86965_p1 = tmp_1770_reg_105407.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1770_fu_86965_p2() {
    mul_ln1118_1770_fu_86965_p2 = (!mul_ln1118_1770_fu_86965_p0.read().is_01() || !mul_ln1118_1770_fu_86965_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1770_fu_86965_p0.read()) * sc_bigint<5>(mul_ln1118_1770_fu_86965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1771_fu_86984_p0() {
    mul_ln1118_1771_fu_86984_p0 =  (sc_lv<12>) (sext_ln1116_171_cast_fu_55371_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1771_fu_86984_p1() {
    mul_ln1118_1771_fu_86984_p1 = tmp_1771_reg_105412.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1771_fu_86984_p2() {
    mul_ln1118_1771_fu_86984_p2 = (!mul_ln1118_1771_fu_86984_p0.read().is_01() || !mul_ln1118_1771_fu_86984_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1771_fu_86984_p0.read()) * sc_bigint<5>(mul_ln1118_1771_fu_86984_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1772_fu_87003_p0() {
    mul_ln1118_1772_fu_87003_p0 =  (sc_lv<12>) (sext_ln1116_172_cast_fu_55393_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1772_fu_87003_p1() {
    mul_ln1118_1772_fu_87003_p1 = tmp_1772_reg_105417.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1772_fu_87003_p2() {
    mul_ln1118_1772_fu_87003_p2 = (!mul_ln1118_1772_fu_87003_p0.read().is_01() || !mul_ln1118_1772_fu_87003_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1772_fu_87003_p0.read()) * sc_bigint<5>(mul_ln1118_1772_fu_87003_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1773_fu_87022_p0() {
    mul_ln1118_1773_fu_87022_p0 =  (sc_lv<12>) (sext_ln1116_173_cast_fu_55415_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1773_fu_87022_p1() {
    mul_ln1118_1773_fu_87022_p1 = tmp_1773_reg_105422.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1773_fu_87022_p2() {
    mul_ln1118_1773_fu_87022_p2 = (!mul_ln1118_1773_fu_87022_p0.read().is_01() || !mul_ln1118_1773_fu_87022_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1773_fu_87022_p0.read()) * sc_bigint<5>(mul_ln1118_1773_fu_87022_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1774_fu_87041_p0() {
    mul_ln1118_1774_fu_87041_p0 =  (sc_lv<12>) (sext_ln1116_174_cast_fu_55437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1774_fu_87041_p1() {
    mul_ln1118_1774_fu_87041_p1 = tmp_1774_reg_105427.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1774_fu_87041_p2() {
    mul_ln1118_1774_fu_87041_p2 = (!mul_ln1118_1774_fu_87041_p0.read().is_01() || !mul_ln1118_1774_fu_87041_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1774_fu_87041_p0.read()) * sc_bigint<5>(mul_ln1118_1774_fu_87041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1775_fu_87060_p0() {
    mul_ln1118_1775_fu_87060_p0 =  (sc_lv<12>) (sext_ln1116_175_cast_fu_55459_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1775_fu_87060_p1() {
    mul_ln1118_1775_fu_87060_p1 = tmp_1775_reg_105432.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1775_fu_87060_p2() {
    mul_ln1118_1775_fu_87060_p2 = (!mul_ln1118_1775_fu_87060_p0.read().is_01() || !mul_ln1118_1775_fu_87060_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1775_fu_87060_p0.read()) * sc_bigint<5>(mul_ln1118_1775_fu_87060_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1776_fu_87079_p0() {
    mul_ln1118_1776_fu_87079_p0 =  (sc_lv<12>) (sext_ln1116_176_cast_reg_97300.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1776_fu_87079_p1() {
    mul_ln1118_1776_fu_87079_p1 = tmp_1776_reg_105437.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1776_fu_87079_p2() {
    mul_ln1118_1776_fu_87079_p2 = (!mul_ln1118_1776_fu_87079_p0.read().is_01() || !mul_ln1118_1776_fu_87079_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1776_fu_87079_p0.read()) * sc_bigint<5>(mul_ln1118_1776_fu_87079_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1777_fu_87097_p0() {
    mul_ln1118_1777_fu_87097_p0 =  (sc_lv<12>) (sext_ln1116_177_cast_reg_97318.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1777_fu_87097_p1() {
    mul_ln1118_1777_fu_87097_p1 = tmp_1777_reg_105442.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1777_fu_87097_p2() {
    mul_ln1118_1777_fu_87097_p2 = (!mul_ln1118_1777_fu_87097_p0.read().is_01() || !mul_ln1118_1777_fu_87097_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1777_fu_87097_p0.read()) * sc_bigint<5>(mul_ln1118_1777_fu_87097_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1778_fu_49035_p0() {
    mul_ln1118_1778_fu_49035_p0 =  (sc_lv<12>) (sext_ln1116_178_cast_fu_25695_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1778_fu_49035_p1() {
    mul_ln1118_1778_fu_49035_p1 = tmp_1778_fu_49021_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1778_fu_49035_p2() {
    mul_ln1118_1778_fu_49035_p2 = (!mul_ln1118_1778_fu_49035_p0.read().is_01() || !mul_ln1118_1778_fu_49035_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1778_fu_49035_p0.read()) * sc_bigint<5>(mul_ln1118_1778_fu_49035_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1779_fu_49065_p0() {
    mul_ln1118_1779_fu_49065_p0 =  (sc_lv<12>) (sext_ln1116_179_cast_fu_25737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1779_fu_49065_p1() {
    mul_ln1118_1779_fu_49065_p1 = tmp_1779_fu_49051_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1779_fu_49065_p2() {
    mul_ln1118_1779_fu_49065_p2 = (!mul_ln1118_1779_fu_49065_p0.read().is_01() || !mul_ln1118_1779_fu_49065_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1779_fu_49065_p0.read()) * sc_bigint<5>(mul_ln1118_1779_fu_49065_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_177_fu_55502_p0() {
    mul_ln1118_177_fu_55502_p0 =  (sc_lv<12>) (sext_ln1116_177_cast_reg_97318.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_177_fu_55502_p1() {
    mul_ln1118_177_fu_55502_p1 = tmp_177_reg_97313.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_177_fu_55502_p2() {
    mul_ln1118_177_fu_55502_p2 = (!mul_ln1118_177_fu_55502_p0.read().is_01() || !mul_ln1118_177_fu_55502_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_177_fu_55502_p0.read()) * sc_bigint<5>(mul_ln1118_177_fu_55502_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1780_fu_49095_p0() {
    mul_ln1118_1780_fu_49095_p0 =  (sc_lv<12>) (sext_ln1116_180_cast_fu_25779_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1780_fu_49095_p1() {
    mul_ln1118_1780_fu_49095_p1 = tmp_1780_fu_49081_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1780_fu_49095_p2() {
    mul_ln1118_1780_fu_49095_p2 = (!mul_ln1118_1780_fu_49095_p0.read().is_01() || !mul_ln1118_1780_fu_49095_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1780_fu_49095_p0.read()) * sc_bigint<5>(mul_ln1118_1780_fu_49095_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1781_fu_49125_p0() {
    mul_ln1118_1781_fu_49125_p0 =  (sc_lv<12>) (sext_ln1116_181_cast_fu_25821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1781_fu_49125_p1() {
    mul_ln1118_1781_fu_49125_p1 = tmp_1781_fu_49111_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1781_fu_49125_p2() {
    mul_ln1118_1781_fu_49125_p2 = (!mul_ln1118_1781_fu_49125_p0.read().is_01() || !mul_ln1118_1781_fu_49125_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1781_fu_49125_p0.read()) * sc_bigint<5>(mul_ln1118_1781_fu_49125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1782_fu_49155_p0() {
    mul_ln1118_1782_fu_49155_p0 =  (sc_lv<12>) (sext_ln1116_182_cast_fu_25863_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1782_fu_49155_p1() {
    mul_ln1118_1782_fu_49155_p1 = tmp_1782_fu_49141_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1782_fu_49155_p2() {
    mul_ln1118_1782_fu_49155_p2 = (!mul_ln1118_1782_fu_49155_p0.read().is_01() || !mul_ln1118_1782_fu_49155_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1782_fu_49155_p0.read()) * sc_bigint<5>(mul_ln1118_1782_fu_49155_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1783_fu_49185_p0() {
    mul_ln1118_1783_fu_49185_p0 =  (sc_lv<12>) (sext_ln1116_183_cast_fu_25905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1783_fu_49185_p1() {
    mul_ln1118_1783_fu_49185_p1 = tmp_1783_fu_49171_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1783_fu_49185_p2() {
    mul_ln1118_1783_fu_49185_p2 = (!mul_ln1118_1783_fu_49185_p0.read().is_01() || !mul_ln1118_1783_fu_49185_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1783_fu_49185_p0.read()) * sc_bigint<5>(mul_ln1118_1783_fu_49185_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1784_fu_87115_p0() {
    mul_ln1118_1784_fu_87115_p0 =  (sc_lv<12>) (sext_ln1116_184_cast_fu_55517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1784_fu_87115_p1() {
    mul_ln1118_1784_fu_87115_p1 = tmp_1784_reg_105477.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1784_fu_87115_p2() {
    mul_ln1118_1784_fu_87115_p2 = (!mul_ln1118_1784_fu_87115_p0.read().is_01() || !mul_ln1118_1784_fu_87115_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1784_fu_87115_p0.read()) * sc_bigint<5>(mul_ln1118_1784_fu_87115_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1785_fu_87134_p0() {
    mul_ln1118_1785_fu_87134_p0 =  (sc_lv<12>) (sext_ln1116_185_cast_fu_55539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1785_fu_87134_p1() {
    mul_ln1118_1785_fu_87134_p1 = tmp_1785_reg_105482.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1785_fu_87134_p2() {
    mul_ln1118_1785_fu_87134_p2 = (!mul_ln1118_1785_fu_87134_p0.read().is_01() || !mul_ln1118_1785_fu_87134_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1785_fu_87134_p0.read()) * sc_bigint<5>(mul_ln1118_1785_fu_87134_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1786_fu_87153_p0() {
    mul_ln1118_1786_fu_87153_p0 =  (sc_lv<12>) (sext_ln1116_186_cast_fu_55561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1786_fu_87153_p1() {
    mul_ln1118_1786_fu_87153_p1 = tmp_1786_reg_105487.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1786_fu_87153_p2() {
    mul_ln1118_1786_fu_87153_p2 = (!mul_ln1118_1786_fu_87153_p0.read().is_01() || !mul_ln1118_1786_fu_87153_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1786_fu_87153_p0.read()) * sc_bigint<5>(mul_ln1118_1786_fu_87153_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1787_fu_87172_p0() {
    mul_ln1118_1787_fu_87172_p0 =  (sc_lv<12>) (sext_ln1116_187_cast_fu_55583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1787_fu_87172_p1() {
    mul_ln1118_1787_fu_87172_p1 = tmp_1787_reg_105492.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1787_fu_87172_p2() {
    mul_ln1118_1787_fu_87172_p2 = (!mul_ln1118_1787_fu_87172_p0.read().is_01() || !mul_ln1118_1787_fu_87172_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1787_fu_87172_p0.read()) * sc_bigint<5>(mul_ln1118_1787_fu_87172_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1788_fu_87191_p0() {
    mul_ln1118_1788_fu_87191_p0 =  (sc_lv<12>) (sext_ln1116_188_cast_fu_55605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1788_fu_87191_p1() {
    mul_ln1118_1788_fu_87191_p1 = tmp_1788_reg_105497.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1788_fu_87191_p2() {
    mul_ln1118_1788_fu_87191_p2 = (!mul_ln1118_1788_fu_87191_p0.read().is_01() || !mul_ln1118_1788_fu_87191_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1788_fu_87191_p0.read()) * sc_bigint<5>(mul_ln1118_1788_fu_87191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1789_fu_87210_p0() {
    mul_ln1118_1789_fu_87210_p0 =  (sc_lv<12>) (sext_ln1116_189_cast_fu_55627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1789_fu_87210_p1() {
    mul_ln1118_1789_fu_87210_p1 = tmp_1789_reg_105502.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1789_fu_87210_p2() {
    mul_ln1118_1789_fu_87210_p2 = (!mul_ln1118_1789_fu_87210_p0.read().is_01() || !mul_ln1118_1789_fu_87210_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1789_fu_87210_p0.read()) * sc_bigint<5>(mul_ln1118_1789_fu_87210_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_178_fu_25703_p0() {
    mul_ln1118_178_fu_25703_p0 =  (sc_lv<12>) (sext_ln1116_178_cast_fu_25695_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_178_fu_25703_p1() {
    mul_ln1118_178_fu_25703_p1 = tmp_178_fu_25685_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_178_fu_25703_p2() {
    mul_ln1118_178_fu_25703_p2 = (!mul_ln1118_178_fu_25703_p0.read().is_01() || !mul_ln1118_178_fu_25703_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_178_fu_25703_p0.read()) * sc_bigint<5>(mul_ln1118_178_fu_25703_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1790_fu_87229_p0() {
    mul_ln1118_1790_fu_87229_p0 =  (sc_lv<12>) (sext_ln1116_190_cast_fu_55649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1790_fu_87229_p1() {
    mul_ln1118_1790_fu_87229_p1 = tmp_1790_reg_105507.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1790_fu_87229_p2() {
    mul_ln1118_1790_fu_87229_p2 = (!mul_ln1118_1790_fu_87229_p0.read().is_01() || !mul_ln1118_1790_fu_87229_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1790_fu_87229_p0.read()) * sc_bigint<5>(mul_ln1118_1790_fu_87229_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1791_fu_87248_p0() {
    mul_ln1118_1791_fu_87248_p0 =  (sc_lv<12>) (sext_ln1116_191_cast_fu_55671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1791_fu_87248_p1() {
    mul_ln1118_1791_fu_87248_p1 = tmp_1791_reg_105512.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1791_fu_87248_p2() {
    mul_ln1118_1791_fu_87248_p2 = (!mul_ln1118_1791_fu_87248_p0.read().is_01() || !mul_ln1118_1791_fu_87248_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1791_fu_87248_p0.read()) * sc_bigint<5>(mul_ln1118_1791_fu_87248_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1792_fu_87267_p0() {
    mul_ln1118_1792_fu_87267_p0 =  (sc_lv<12>) (sext_ln1116_192_cast_fu_55693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1792_fu_87267_p1() {
    mul_ln1118_1792_fu_87267_p1 = tmp_1792_reg_105517.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1792_fu_87267_p2() {
    mul_ln1118_1792_fu_87267_p2 = (!mul_ln1118_1792_fu_87267_p0.read().is_01() || !mul_ln1118_1792_fu_87267_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1792_fu_87267_p0.read()) * sc_bigint<5>(mul_ln1118_1792_fu_87267_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1793_fu_87286_p0() {
    mul_ln1118_1793_fu_87286_p0 =  (sc_lv<12>) (sext_ln1116_193_cast_fu_55715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1793_fu_87286_p1() {
    mul_ln1118_1793_fu_87286_p1 = tmp_1793_reg_105522.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1793_fu_87286_p2() {
    mul_ln1118_1793_fu_87286_p2 = (!mul_ln1118_1793_fu_87286_p0.read().is_01() || !mul_ln1118_1793_fu_87286_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1793_fu_87286_p0.read()) * sc_bigint<5>(mul_ln1118_1793_fu_87286_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1794_fu_87305_p0() {
    mul_ln1118_1794_fu_87305_p0 =  (sc_lv<12>) (sext_ln1116_194_cast_fu_55737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1794_fu_87305_p1() {
    mul_ln1118_1794_fu_87305_p1 = tmp_1794_reg_105527.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1794_fu_87305_p2() {
    mul_ln1118_1794_fu_87305_p2 = (!mul_ln1118_1794_fu_87305_p0.read().is_01() || !mul_ln1118_1794_fu_87305_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1794_fu_87305_p0.read()) * sc_bigint<5>(mul_ln1118_1794_fu_87305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1795_fu_87324_p0() {
    mul_ln1118_1795_fu_87324_p0 =  (sc_lv<12>) (sext_ln1116_195_cast_fu_55759_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1795_fu_87324_p1() {
    mul_ln1118_1795_fu_87324_p1 = tmp_1795_reg_105532.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1795_fu_87324_p2() {
    mul_ln1118_1795_fu_87324_p2 = (!mul_ln1118_1795_fu_87324_p0.read().is_01() || !mul_ln1118_1795_fu_87324_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1795_fu_87324_p0.read()) * sc_bigint<5>(mul_ln1118_1795_fu_87324_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1796_fu_87343_p0() {
    mul_ln1118_1796_fu_87343_p0 =  (sc_lv<12>) (sext_ln1116_196_cast_fu_55781_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1796_fu_87343_p1() {
    mul_ln1118_1796_fu_87343_p1 = tmp_1796_reg_105537.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1796_fu_87343_p2() {
    mul_ln1118_1796_fu_87343_p2 = (!mul_ln1118_1796_fu_87343_p0.read().is_01() || !mul_ln1118_1796_fu_87343_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1796_fu_87343_p0.read()) * sc_bigint<5>(mul_ln1118_1796_fu_87343_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1797_fu_87362_p0() {
    mul_ln1118_1797_fu_87362_p0 =  (sc_lv<12>) (sext_ln1116_197_cast_fu_55803_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1797_fu_87362_p1() {
    mul_ln1118_1797_fu_87362_p1 = tmp_1797_reg_105542.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1797_fu_87362_p2() {
    mul_ln1118_1797_fu_87362_p2 = (!mul_ln1118_1797_fu_87362_p0.read().is_01() || !mul_ln1118_1797_fu_87362_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1797_fu_87362_p0.read()) * sc_bigint<5>(mul_ln1118_1797_fu_87362_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1798_fu_87381_p0() {
    mul_ln1118_1798_fu_87381_p0 =  (sc_lv<12>) (sext_ln1116_198_cast_fu_55825_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1798_fu_87381_p1() {
    mul_ln1118_1798_fu_87381_p1 = tmp_1798_reg_105547.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1798_fu_87381_p2() {
    mul_ln1118_1798_fu_87381_p2 = (!mul_ln1118_1798_fu_87381_p0.read().is_01() || !mul_ln1118_1798_fu_87381_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1798_fu_87381_p0.read()) * sc_bigint<5>(mul_ln1118_1798_fu_87381_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1799_fu_87400_p0() {
    mul_ln1118_1799_fu_87400_p0 =  (sc_lv<12>) (sext_ln1116_199_cast_fu_55847_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1799_fu_87400_p1() {
    mul_ln1118_1799_fu_87400_p1 = tmp_1799_reg_105552.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1799_fu_87400_p2() {
    mul_ln1118_1799_fu_87400_p2 = (!mul_ln1118_1799_fu_87400_p0.read().is_01() || !mul_ln1118_1799_fu_87400_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1799_fu_87400_p0.read()) * sc_bigint<5>(mul_ln1118_1799_fu_87400_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_179_fu_25745_p0() {
    mul_ln1118_179_fu_25745_p0 =  (sc_lv<12>) (sext_ln1116_179_cast_fu_25737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_179_fu_25745_p1() {
    mul_ln1118_179_fu_25745_p1 = tmp_179_fu_25727_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_179_fu_25745_p2() {
    mul_ln1118_179_fu_25745_p2 = (!mul_ln1118_179_fu_25745_p0.read().is_01() || !mul_ln1118_179_fu_25745_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_179_fu_25745_p0.read()) * sc_bigint<5>(mul_ln1118_179_fu_25745_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_17_fu_52713_p0() {
    mul_ln1118_17_fu_52713_p0 =  (sc_lv<12>) (sext_ln1116_17_cast_fu_52707_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_17_fu_52713_p1() {
    mul_ln1118_17_fu_52713_p1 = tmp_18_reg_95830.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_17_fu_52713_p2() {
    mul_ln1118_17_fu_52713_p2 = (!mul_ln1118_17_fu_52713_p0.read().is_01() || !mul_ln1118_17_fu_52713_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_17_fu_52713_p0.read()) * sc_bigint<5>(mul_ln1118_17_fu_52713_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1800_fu_87419_p0() {
    mul_ln1118_1800_fu_87419_p0 =  (sc_lv<12>) (sext_ln1116_200_cast_fu_55869_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1800_fu_87419_p1() {
    mul_ln1118_1800_fu_87419_p1 = tmp_1800_reg_105557.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1800_fu_87419_p2() {
    mul_ln1118_1800_fu_87419_p2 = (!mul_ln1118_1800_fu_87419_p0.read().is_01() || !mul_ln1118_1800_fu_87419_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1800_fu_87419_p0.read()) * sc_bigint<5>(mul_ln1118_1800_fu_87419_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1801_fu_87438_p0() {
    mul_ln1118_1801_fu_87438_p0 =  (sc_lv<12>) (sext_ln1116_201_cast_reg_97536.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1801_fu_87438_p1() {
    mul_ln1118_1801_fu_87438_p1 = tmp_1801_reg_105562.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1801_fu_87438_p2() {
    mul_ln1118_1801_fu_87438_p2 = (!mul_ln1118_1801_fu_87438_p0.read().is_01() || !mul_ln1118_1801_fu_87438_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1801_fu_87438_p0.read()) * sc_bigint<5>(mul_ln1118_1801_fu_87438_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1802_fu_87456_p0() {
    mul_ln1118_1802_fu_87456_p0 =  (sc_lv<12>) (sext_ln1116_202_cast_reg_97554.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1802_fu_87456_p1() {
    mul_ln1118_1802_fu_87456_p1 = tmp_1802_reg_105567.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1802_fu_87456_p2() {
    mul_ln1118_1802_fu_87456_p2 = (!mul_ln1118_1802_fu_87456_p0.read().is_01() || !mul_ln1118_1802_fu_87456_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1802_fu_87456_p0.read()) * sc_bigint<5>(mul_ln1118_1802_fu_87456_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1803_fu_49405_p0() {
    mul_ln1118_1803_fu_49405_p0 =  (sc_lv<12>) (sext_ln1116_203_cast_fu_26297_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1803_fu_49405_p1() {
    mul_ln1118_1803_fu_49405_p1 = tmp_1803_fu_49391_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1803_fu_49405_p2() {
    mul_ln1118_1803_fu_49405_p2 = (!mul_ln1118_1803_fu_49405_p0.read().is_01() || !mul_ln1118_1803_fu_49405_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1803_fu_49405_p0.read()) * sc_bigint<5>(mul_ln1118_1803_fu_49405_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1804_fu_49435_p0() {
    mul_ln1118_1804_fu_49435_p0 =  (sc_lv<12>) (sext_ln1116_204_cast_fu_26339_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1804_fu_49435_p1() {
    mul_ln1118_1804_fu_49435_p1 = tmp_1804_fu_49421_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1804_fu_49435_p2() {
    mul_ln1118_1804_fu_49435_p2 = (!mul_ln1118_1804_fu_49435_p0.read().is_01() || !mul_ln1118_1804_fu_49435_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1804_fu_49435_p0.read()) * sc_bigint<5>(mul_ln1118_1804_fu_49435_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1805_fu_49465_p0() {
    mul_ln1118_1805_fu_49465_p0 =  (sc_lv<12>) (sext_ln1116_205_cast_fu_26381_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1805_fu_49465_p1() {
    mul_ln1118_1805_fu_49465_p1 = tmp_1805_fu_49451_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1805_fu_49465_p2() {
    mul_ln1118_1805_fu_49465_p2 = (!mul_ln1118_1805_fu_49465_p0.read().is_01() || !mul_ln1118_1805_fu_49465_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1805_fu_49465_p0.read()) * sc_bigint<5>(mul_ln1118_1805_fu_49465_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1806_fu_49495_p0() {
    mul_ln1118_1806_fu_49495_p0 =  (sc_lv<12>) (sext_ln1116_206_cast_fu_26423_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1806_fu_49495_p1() {
    mul_ln1118_1806_fu_49495_p1 = tmp_1806_fu_49481_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1806_fu_49495_p2() {
    mul_ln1118_1806_fu_49495_p2 = (!mul_ln1118_1806_fu_49495_p0.read().is_01() || !mul_ln1118_1806_fu_49495_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1806_fu_49495_p0.read()) * sc_bigint<5>(mul_ln1118_1806_fu_49495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1807_fu_49525_p0() {
    mul_ln1118_1807_fu_49525_p0 =  (sc_lv<12>) (sext_ln1116_207_cast_fu_26465_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1807_fu_49525_p1() {
    mul_ln1118_1807_fu_49525_p1 = tmp_1807_fu_49511_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1807_fu_49525_p2() {
    mul_ln1118_1807_fu_49525_p2 = (!mul_ln1118_1807_fu_49525_p0.read().is_01() || !mul_ln1118_1807_fu_49525_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1807_fu_49525_p0.read()) * sc_bigint<5>(mul_ln1118_1807_fu_49525_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1808_fu_49555_p0() {
    mul_ln1118_1808_fu_49555_p0 =  (sc_lv<12>) (sext_ln1116_208_cast_fu_26507_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1808_fu_49555_p1() {
    mul_ln1118_1808_fu_49555_p1 = tmp_1808_fu_49541_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1808_fu_49555_p2() {
    mul_ln1118_1808_fu_49555_p2 = (!mul_ln1118_1808_fu_49555_p0.read().is_01() || !mul_ln1118_1808_fu_49555_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1808_fu_49555_p0.read()) * sc_bigint<5>(mul_ln1118_1808_fu_49555_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1809_fu_88462_p0() {
    mul_ln1118_1809_fu_88462_p0 =  (sc_lv<12>) (sext_ln1116_cast_fu_52531_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1809_fu_88462_p1() {
    mul_ln1118_1809_fu_88462_p1 = tmp_1809_reg_105602.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1809_fu_88462_p2() {
    mul_ln1118_1809_fu_88462_p2 = (!mul_ln1118_1809_fu_88462_p0.read().is_01() || !mul_ln1118_1809_fu_88462_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1809_fu_88462_p0.read()) * sc_bigint<5>(mul_ln1118_1809_fu_88462_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_180_fu_25787_p0() {
    mul_ln1118_180_fu_25787_p0 =  (sc_lv<12>) (sext_ln1116_180_cast_fu_25779_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_180_fu_25787_p1() {
    mul_ln1118_180_fu_25787_p1 = tmp_180_fu_25769_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_180_fu_25787_p2() {
    mul_ln1118_180_fu_25787_p2 = (!mul_ln1118_180_fu_25787_p0.read().is_01() || !mul_ln1118_180_fu_25787_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_180_fu_25787_p0.read()) * sc_bigint<5>(mul_ln1118_180_fu_25787_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1810_fu_88481_p0() {
    mul_ln1118_1810_fu_88481_p0 =  (sc_lv<12>) (sext_ln1116_10_cast_fu_52553_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1810_fu_88481_p1() {
    mul_ln1118_1810_fu_88481_p1 = tmp_1810_reg_105607.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1810_fu_88481_p2() {
    mul_ln1118_1810_fu_88481_p2 = (!mul_ln1118_1810_fu_88481_p0.read().is_01() || !mul_ln1118_1810_fu_88481_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1810_fu_88481_p0.read()) * sc_bigint<5>(mul_ln1118_1810_fu_88481_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1811_fu_88500_p0() {
    mul_ln1118_1811_fu_88500_p0 =  (sc_lv<12>) (sext_ln1116_11_cast_fu_52575_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1811_fu_88500_p1() {
    mul_ln1118_1811_fu_88500_p1 = tmp_1811_reg_105612.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1811_fu_88500_p2() {
    mul_ln1118_1811_fu_88500_p2 = (!mul_ln1118_1811_fu_88500_p0.read().is_01() || !mul_ln1118_1811_fu_88500_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1811_fu_88500_p0.read()) * sc_bigint<5>(mul_ln1118_1811_fu_88500_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1812_fu_88519_p0() {
    mul_ln1118_1812_fu_88519_p0 =  (sc_lv<12>) (sext_ln1116_12_cast_fu_52597_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1812_fu_88519_p1() {
    mul_ln1118_1812_fu_88519_p1 = tmp_1812_reg_105617.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1812_fu_88519_p2() {
    mul_ln1118_1812_fu_88519_p2 = (!mul_ln1118_1812_fu_88519_p0.read().is_01() || !mul_ln1118_1812_fu_88519_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1812_fu_88519_p0.read()) * sc_bigint<5>(mul_ln1118_1812_fu_88519_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1813_fu_88538_p0() {
    mul_ln1118_1813_fu_88538_p0 =  (sc_lv<12>) (sext_ln1116_13_cast_fu_52619_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1813_fu_88538_p1() {
    mul_ln1118_1813_fu_88538_p1 = tmp_1813_reg_105622.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1813_fu_88538_p2() {
    mul_ln1118_1813_fu_88538_p2 = (!mul_ln1118_1813_fu_88538_p0.read().is_01() || !mul_ln1118_1813_fu_88538_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1813_fu_88538_p0.read()) * sc_bigint<5>(mul_ln1118_1813_fu_88538_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1814_fu_88557_p0() {
    mul_ln1118_1814_fu_88557_p0 =  (sc_lv<12>) (sext_ln1116_14_cast_fu_52641_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1814_fu_88557_p1() {
    mul_ln1118_1814_fu_88557_p1 = tmp_1814_reg_105627.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1814_fu_88557_p2() {
    mul_ln1118_1814_fu_88557_p2 = (!mul_ln1118_1814_fu_88557_p0.read().is_01() || !mul_ln1118_1814_fu_88557_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1814_fu_88557_p0.read()) * sc_bigint<5>(mul_ln1118_1814_fu_88557_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1815_fu_88576_p0() {
    mul_ln1118_1815_fu_88576_p0 =  (sc_lv<12>) (sext_ln1116_15_cast_fu_52663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1815_fu_88576_p1() {
    mul_ln1118_1815_fu_88576_p1 = tmp_1815_reg_105632.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1815_fu_88576_p2() {
    mul_ln1118_1815_fu_88576_p2 = (!mul_ln1118_1815_fu_88576_p0.read().is_01() || !mul_ln1118_1815_fu_88576_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1815_fu_88576_p0.read()) * sc_bigint<5>(mul_ln1118_1815_fu_88576_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1816_fu_88595_p0() {
    mul_ln1118_1816_fu_88595_p0 =  (sc_lv<12>) (sext_ln1116_16_cast_fu_52685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1816_fu_88595_p1() {
    mul_ln1118_1816_fu_88595_p1 = tmp_1816_reg_105637.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1816_fu_88595_p2() {
    mul_ln1118_1816_fu_88595_p2 = (!mul_ln1118_1816_fu_88595_p0.read().is_01() || !mul_ln1118_1816_fu_88595_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1816_fu_88595_p0.read()) * sc_bigint<5>(mul_ln1118_1816_fu_88595_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1817_fu_88614_p0() {
    mul_ln1118_1817_fu_88614_p0 =  (sc_lv<12>) (sext_ln1116_17_cast_fu_52707_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1817_fu_88614_p1() {
    mul_ln1118_1817_fu_88614_p1 = tmp_1817_reg_105642.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1817_fu_88614_p2() {
    mul_ln1118_1817_fu_88614_p2 = (!mul_ln1118_1817_fu_88614_p0.read().is_01() || !mul_ln1118_1817_fu_88614_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1817_fu_88614_p0.read()) * sc_bigint<5>(mul_ln1118_1817_fu_88614_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1818_fu_88633_p0() {
    mul_ln1118_1818_fu_88633_p0 =  (sc_lv<12>) (sext_ln1116_18_cast_fu_52729_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1818_fu_88633_p1() {
    mul_ln1118_1818_fu_88633_p1 = tmp_1818_reg_105647.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1818_fu_88633_p2() {
    mul_ln1118_1818_fu_88633_p2 = (!mul_ln1118_1818_fu_88633_p0.read().is_01() || !mul_ln1118_1818_fu_88633_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1818_fu_88633_p0.read()) * sc_bigint<5>(mul_ln1118_1818_fu_88633_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1819_fu_88652_p0() {
    mul_ln1118_1819_fu_88652_p0 =  (sc_lv<12>) (sext_ln1116_19_cast_fu_52751_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1819_fu_88652_p1() {
    mul_ln1118_1819_fu_88652_p1 = tmp_1819_reg_105652.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1819_fu_88652_p2() {
    mul_ln1118_1819_fu_88652_p2 = (!mul_ln1118_1819_fu_88652_p0.read().is_01() || !mul_ln1118_1819_fu_88652_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1819_fu_88652_p0.read()) * sc_bigint<5>(mul_ln1118_1819_fu_88652_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_181_fu_25829_p0() {
    mul_ln1118_181_fu_25829_p0 =  (sc_lv<12>) (sext_ln1116_181_cast_fu_25821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_181_fu_25829_p1() {
    mul_ln1118_181_fu_25829_p1 = tmp_181_fu_25811_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_181_fu_25829_p2() {
    mul_ln1118_181_fu_25829_p2 = (!mul_ln1118_181_fu_25829_p0.read().is_01() || !mul_ln1118_181_fu_25829_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_181_fu_25829_p0.read()) * sc_bigint<5>(mul_ln1118_181_fu_25829_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1820_fu_88671_p0() {
    mul_ln1118_1820_fu_88671_p0 =  (sc_lv<12>) (sext_ln1116_20_cast_fu_52773_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1820_fu_88671_p1() {
    mul_ln1118_1820_fu_88671_p1 = tmp_1820_reg_105657.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1820_fu_88671_p2() {
    mul_ln1118_1820_fu_88671_p2 = (!mul_ln1118_1820_fu_88671_p0.read().is_01() || !mul_ln1118_1820_fu_88671_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1820_fu_88671_p0.read()) * sc_bigint<5>(mul_ln1118_1820_fu_88671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1821_fu_88690_p0() {
    mul_ln1118_1821_fu_88690_p0 =  (sc_lv<12>) (sext_ln1116_21_cast_fu_52795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1821_fu_88690_p1() {
    mul_ln1118_1821_fu_88690_p1 = tmp_1821_reg_105662.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1821_fu_88690_p2() {
    mul_ln1118_1821_fu_88690_p2 = (!mul_ln1118_1821_fu_88690_p0.read().is_01() || !mul_ln1118_1821_fu_88690_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1821_fu_88690_p0.read()) * sc_bigint<5>(mul_ln1118_1821_fu_88690_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1822_fu_88709_p0() {
    mul_ln1118_1822_fu_88709_p0 =  (sc_lv<12>) (sext_ln1116_22_cast_fu_52817_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1822_fu_88709_p1() {
    mul_ln1118_1822_fu_88709_p1 = tmp_1822_reg_105667.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1822_fu_88709_p2() {
    mul_ln1118_1822_fu_88709_p2 = (!mul_ln1118_1822_fu_88709_p0.read().is_01() || !mul_ln1118_1822_fu_88709_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1822_fu_88709_p0.read()) * sc_bigint<5>(mul_ln1118_1822_fu_88709_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1823_fu_88728_p0() {
    mul_ln1118_1823_fu_88728_p0 =  (sc_lv<12>) (sext_ln1116_23_cast_fu_52839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1823_fu_88728_p1() {
    mul_ln1118_1823_fu_88728_p1 = tmp_1823_reg_105672.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1823_fu_88728_p2() {
    mul_ln1118_1823_fu_88728_p2 = (!mul_ln1118_1823_fu_88728_p0.read().is_01() || !mul_ln1118_1823_fu_88728_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1823_fu_88728_p0.read()) * sc_bigint<5>(mul_ln1118_1823_fu_88728_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1824_fu_88747_p0() {
    mul_ln1118_1824_fu_88747_p0 =  (sc_lv<12>) (sext_ln1116_24_cast_fu_52861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1824_fu_88747_p1() {
    mul_ln1118_1824_fu_88747_p1 = tmp_1824_reg_105677.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1824_fu_88747_p2() {
    mul_ln1118_1824_fu_88747_p2 = (!mul_ln1118_1824_fu_88747_p0.read().is_01() || !mul_ln1118_1824_fu_88747_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1824_fu_88747_p0.read()) * sc_bigint<5>(mul_ln1118_1824_fu_88747_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1825_fu_88766_p0() {
    mul_ln1118_1825_fu_88766_p0 =  (sc_lv<12>) (sext_ln1116_25_cast_fu_52883_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1825_fu_88766_p1() {
    mul_ln1118_1825_fu_88766_p1 = tmp_1825_reg_105682.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1825_fu_88766_p2() {
    mul_ln1118_1825_fu_88766_p2 = (!mul_ln1118_1825_fu_88766_p0.read().is_01() || !mul_ln1118_1825_fu_88766_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1825_fu_88766_p0.read()) * sc_bigint<5>(mul_ln1118_1825_fu_88766_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1826_fu_88785_p0() {
    mul_ln1118_1826_fu_88785_p0 =  (sc_lv<12>) (sext_ln1116_26_cast_fu_52905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1826_fu_88785_p1() {
    mul_ln1118_1826_fu_88785_p1 = tmp_1826_reg_105687.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1826_fu_88785_p2() {
    mul_ln1118_1826_fu_88785_p2 = (!mul_ln1118_1826_fu_88785_p0.read().is_01() || !mul_ln1118_1826_fu_88785_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1826_fu_88785_p0.read()) * sc_bigint<5>(mul_ln1118_1826_fu_88785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1827_fu_88804_p0() {
    mul_ln1118_1827_fu_88804_p0 =  (sc_lv<12>) (sext_ln1116_27_cast_fu_52927_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1827_fu_88804_p1() {
    mul_ln1118_1827_fu_88804_p1 = tmp_1827_reg_105692.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1827_fu_88804_p2() {
    mul_ln1118_1827_fu_88804_p2 = (!mul_ln1118_1827_fu_88804_p0.read().is_01() || !mul_ln1118_1827_fu_88804_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1827_fu_88804_p0.read()) * sc_bigint<5>(mul_ln1118_1827_fu_88804_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1828_fu_49775_p0() {
    mul_ln1118_1828_fu_49775_p0 =  (sc_lv<12>) (sext_ln1116_28_cast_fu_22199_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1828_fu_49775_p1() {
    mul_ln1118_1828_fu_49775_p1 = tmp_1828_fu_49761_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1828_fu_49775_p2() {
    mul_ln1118_1828_fu_49775_p2 = (!mul_ln1118_1828_fu_49775_p0.read().is_01() || !mul_ln1118_1828_fu_49775_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1828_fu_49775_p0.read()) * sc_bigint<5>(mul_ln1118_1828_fu_49775_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1829_fu_49805_p0() {
    mul_ln1118_1829_fu_49805_p0 =  (sc_lv<12>) (sext_ln1116_29_cast_fu_22241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1829_fu_49805_p1() {
    mul_ln1118_1829_fu_49805_p1 = tmp_1829_fu_49791_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1829_fu_49805_p2() {
    mul_ln1118_1829_fu_49805_p2 = (!mul_ln1118_1829_fu_49805_p0.read().is_01() || !mul_ln1118_1829_fu_49805_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1829_fu_49805_p0.read()) * sc_bigint<5>(mul_ln1118_1829_fu_49805_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_182_fu_25871_p0() {
    mul_ln1118_182_fu_25871_p0 =  (sc_lv<12>) (sext_ln1116_182_cast_fu_25863_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_182_fu_25871_p1() {
    mul_ln1118_182_fu_25871_p1 = tmp_182_fu_25853_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_182_fu_25871_p2() {
    mul_ln1118_182_fu_25871_p2 = (!mul_ln1118_182_fu_25871_p0.read().is_01() || !mul_ln1118_182_fu_25871_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_182_fu_25871_p0.read()) * sc_bigint<5>(mul_ln1118_182_fu_25871_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1830_fu_49835_p0() {
    mul_ln1118_1830_fu_49835_p0 =  (sc_lv<12>) (sext_ln1116_30_cast_fu_22283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1830_fu_49835_p1() {
    mul_ln1118_1830_fu_49835_p1 = tmp_1830_fu_49821_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1830_fu_49835_p2() {
    mul_ln1118_1830_fu_49835_p2 = (!mul_ln1118_1830_fu_49835_p0.read().is_01() || !mul_ln1118_1830_fu_49835_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1830_fu_49835_p0.read()) * sc_bigint<5>(mul_ln1118_1830_fu_49835_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1831_fu_49865_p0() {
    mul_ln1118_1831_fu_49865_p0 =  (sc_lv<12>) (sext_ln1116_31_cast_fu_22325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1831_fu_49865_p1() {
    mul_ln1118_1831_fu_49865_p1 = tmp_1831_fu_49851_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1831_fu_49865_p2() {
    mul_ln1118_1831_fu_49865_p2 = (!mul_ln1118_1831_fu_49865_p0.read().is_01() || !mul_ln1118_1831_fu_49865_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1831_fu_49865_p0.read()) * sc_bigint<5>(mul_ln1118_1831_fu_49865_p1.read());
}

}

