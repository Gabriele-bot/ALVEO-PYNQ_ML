#include "dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_683_fu_33371_p4() {
    tmp_683_fu_33371_p4 = w11_V_q0.read().range(3374, 3370);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_703_fu_33591_p4() {
    tmp_703_fu_33591_p4 = w11_V_q0.read().range(3474, 3470);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_704_fu_33621_p4() {
    tmp_704_fu_33621_p4 = w11_V_q0.read().range(3479, 3475);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_705_fu_33651_p4() {
    tmp_705_fu_33651_p4 = w11_V_q0.read().range(3484, 3480);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_706_fu_33681_p4() {
    tmp_706_fu_33681_p4 = w11_V_q0.read().range(3489, 3485);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_707_fu_33711_p4() {
    tmp_707_fu_33711_p4 = w11_V_q0.read().range(3494, 3490);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_708_fu_33741_p4() {
    tmp_708_fu_33741_p4 = w11_V_q0.read().range(3499, 3495);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_732_fu_34001_p4() {
    tmp_732_fu_34001_p4 = w11_V_q0.read().range(3619, 3615);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_733_fu_34031_p4() {
    tmp_733_fu_34031_p4 = w11_V_q0.read().range(3624, 3620);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_753_fu_34251_p4() {
    tmp_753_fu_34251_p4 = w11_V_q0.read().range(3724, 3720);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_754_fu_34281_p4() {
    tmp_754_fu_34281_p4 = w11_V_q0.read().range(3729, 3725);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_755_fu_34311_p4() {
    tmp_755_fu_34311_p4 = w11_V_q0.read().range(3734, 3730);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_756_fu_34341_p4() {
    tmp_756_fu_34341_p4 = w11_V_q0.read().range(3739, 3735);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_757_fu_34371_p4() {
    tmp_757_fu_34371_p4 = w11_V_q0.read().range(3744, 3740);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_758_fu_34401_p4() {
    tmp_758_fu_34401_p4 = w11_V_q0.read().range(3749, 3745);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_778_fu_34621_p4() {
    tmp_778_fu_34621_p4 = w11_V_q0.read().range(3849, 3845);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_779_fu_34651_p4() {
    tmp_779_fu_34651_p4 = w11_V_q0.read().range(3854, 3850);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_780_fu_34681_p4() {
    tmp_780_fu_34681_p4 = w11_V_q0.read().range(3859, 3855);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_781_fu_34711_p4() {
    tmp_781_fu_34711_p4 = w11_V_q0.read().range(3864, 3860);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_782_fu_34741_p4() {
    tmp_782_fu_34741_p4 = w11_V_q0.read().range(3869, 3865);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_783_fu_34771_p4() {
    tmp_783_fu_34771_p4 = w11_V_q0.read().range(3874, 3870);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_78_fu_23385_p4() {
    tmp_78_fu_23385_p4 = w11_V_q0.read().range(349, 345);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_79_fu_23427_p4() {
    tmp_79_fu_23427_p4 = w11_V_q0.read().range(354, 350);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_803_fu_34991_p4() {
    tmp_803_fu_34991_p4 = w11_V_q0.read().range(3974, 3970);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_804_fu_35021_p4() {
    tmp_804_fu_35021_p4 = w11_V_q0.read().range(3979, 3975);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_805_fu_35051_p4() {
    tmp_805_fu_35051_p4 = w11_V_q0.read().range(3984, 3980);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_806_fu_35081_p4() {
    tmp_806_fu_35081_p4 = w11_V_q0.read().range(3989, 3985);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_807_fu_35111_p4() {
    tmp_807_fu_35111_p4 = w11_V_q0.read().range(3994, 3990);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_808_fu_35141_p4() {
    tmp_808_fu_35141_p4 = w11_V_q0.read().range(3999, 3995);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_80_fu_23469_p4() {
    tmp_80_fu_23469_p4 = w11_V_q0.read().range(359, 355);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_81_fu_23511_p4() {
    tmp_81_fu_23511_p4 = w11_V_q0.read().range(364, 360);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_828_fu_35361_p4() {
    tmp_828_fu_35361_p4 = w11_V_q0.read().range(4099, 4095);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_829_fu_35391_p4() {
    tmp_829_fu_35391_p4 = w11_V_q0.read().range(4104, 4100);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_82_fu_23553_p4() {
    tmp_82_fu_23553_p4 = w11_V_q0.read().range(369, 365);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_830_fu_35421_p4() {
    tmp_830_fu_35421_p4 = w11_V_q0.read().range(4109, 4105);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_831_fu_35451_p4() {
    tmp_831_fu_35451_p4 = w11_V_q0.read().range(4114, 4110);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_832_fu_35481_p4() {
    tmp_832_fu_35481_p4 = w11_V_q0.read().range(4119, 4115);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_833_fu_35511_p4() {
    tmp_833_fu_35511_p4 = w11_V_q0.read().range(4124, 4120);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_83_fu_23595_p4() {
    tmp_83_fu_23595_p4 = w11_V_q0.read().range(374, 370);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_853_fu_35731_p4() {
    tmp_853_fu_35731_p4 = w11_V_q0.read().range(4224, 4220);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_854_fu_35761_p4() {
    tmp_854_fu_35761_p4 = w11_V_q0.read().range(4229, 4225);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_855_fu_35791_p4() {
    tmp_855_fu_35791_p4 = w11_V_q0.read().range(4234, 4230);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_856_fu_35821_p4() {
    tmp_856_fu_35821_p4 = w11_V_q0.read().range(4239, 4235);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_857_fu_35851_p4() {
    tmp_857_fu_35851_p4 = w11_V_q0.read().range(4244, 4240);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_858_fu_35881_p4() {
    tmp_858_fu_35881_p4 = w11_V_q0.read().range(4249, 4245);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_878_fu_36101_p4() {
    tmp_878_fu_36101_p4 = w11_V_q0.read().range(4349, 4345);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_879_fu_36131_p4() {
    tmp_879_fu_36131_p4 = w11_V_q0.read().range(4354, 4350);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_880_fu_36161_p4() {
    tmp_880_fu_36161_p4 = w11_V_q0.read().range(4359, 4355);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_881_fu_36191_p4() {
    tmp_881_fu_36191_p4 = w11_V_q0.read().range(4364, 4360);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_882_fu_36221_p4() {
    tmp_882_fu_36221_p4 = w11_V_q0.read().range(4369, 4365);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_883_fu_36251_p4() {
    tmp_883_fu_36251_p4 = w11_V_q0.read().range(4374, 4370);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_903_fu_36471_p4() {
    tmp_903_fu_36471_p4 = w11_V_q0.read().range(4474, 4470);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_904_fu_36501_p4() {
    tmp_904_fu_36501_p4 = w11_V_q0.read().range(4479, 4475);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_905_fu_36531_p4() {
    tmp_905_fu_36531_p4 = w11_V_q0.read().range(4484, 4480);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_906_fu_36561_p4() {
    tmp_906_fu_36561_p4 = w11_V_q0.read().range(4489, 4485);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_907_fu_36591_p4() {
    tmp_907_fu_36591_p4 = w11_V_q0.read().range(4494, 4490);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_908_fu_36621_p4() {
    tmp_908_fu_36621_p4 = w11_V_q0.read().range(4499, 4495);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_932_fu_36881_p4() {
    tmp_932_fu_36881_p4 = w11_V_q0.read().range(4619, 4615);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_933_fu_36911_p4() {
    tmp_933_fu_36911_p4 = w11_V_q0.read().range(4624, 4620);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_953_fu_37131_p4() {
    tmp_953_fu_37131_p4 = w11_V_q0.read().range(4724, 4720);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_954_fu_37161_p4() {
    tmp_954_fu_37161_p4 = w11_V_q0.read().range(4729, 4725);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_955_fu_37191_p4() {
    tmp_955_fu_37191_p4 = w11_V_q0.read().range(4734, 4730);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_956_fu_37221_p4() {
    tmp_956_fu_37221_p4 = w11_V_q0.read().range(4739, 4735);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_957_fu_37251_p4() {
    tmp_957_fu_37251_p4 = w11_V_q0.read().range(4744, 4740);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_958_fu_37281_p4() {
    tmp_958_fu_37281_p4 = w11_V_q0.read().range(4749, 4745);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_978_fu_37501_p4() {
    tmp_978_fu_37501_p4 = w11_V_q0.read().range(4849, 4845);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_979_fu_37531_p4() {
    tmp_979_fu_37531_p4 = w11_V_q0.read().range(4854, 4850);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_980_fu_37561_p4() {
    tmp_980_fu_37561_p4 = w11_V_q0.read().range(4859, 4855);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_981_fu_37591_p4() {
    tmp_981_fu_37591_p4 = w11_V_q0.read().range(4864, 4860);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_982_fu_37621_p4() {
    tmp_982_fu_37621_p4 = w11_V_q0.read().range(4869, 4865);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_tmp_983_fu_37651_p4() {
    tmp_983_fu_37651_p4 = w11_V_q0.read().range(4874, 4870);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln3_fu_52543_p4() {
    trunc_ln3_fu_52543_p4 = mul_ln1118_fu_52537_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1002_fu_71349_p4() {
    trunc_ln708_1002_fu_71349_p4 = mul_ln1118_984_fu_71343_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1003_fu_71368_p4() {
    trunc_ln708_1003_fu_71368_p4 = mul_ln1118_985_fu_71362_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1004_fu_71387_p4() {
    trunc_ln708_1004_fu_71387_p4 = mul_ln1118_986_fu_71381_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1005_fu_71406_p4() {
    trunc_ln708_1005_fu_71406_p4 = mul_ln1118_987_fu_71400_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1006_fu_71425_p4() {
    trunc_ln708_1006_fu_71425_p4 = mul_ln1118_988_fu_71419_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1007_fu_71444_p4() {
    trunc_ln708_1007_fu_71444_p4 = mul_ln1118_989_fu_71438_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1008_fu_71463_p4() {
    trunc_ln708_1008_fu_71463_p4 = mul_ln1118_990_fu_71457_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1009_fu_71482_p4() {
    trunc_ln708_1009_fu_71482_p4 = mul_ln1118_991_fu_71476_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1010_fu_71501_p4() {
    trunc_ln708_1010_fu_71501_p4 = mul_ln1118_992_fu_71495_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1011_fu_71520_p4() {
    trunc_ln708_1011_fu_71520_p4 = mul_ln1118_993_fu_71514_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1012_fu_71539_p4() {
    trunc_ln708_1012_fu_71539_p4 = mul_ln1118_994_fu_71533_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1013_fu_71558_p4() {
    trunc_ln708_1013_fu_71558_p4 = mul_ln1118_995_fu_71552_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1014_fu_71577_p4() {
    trunc_ln708_1014_fu_71577_p4 = mul_ln1118_996_fu_71571_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1015_fu_71596_p4() {
    trunc_ln708_1015_fu_71596_p4 = mul_ln1118_997_fu_71590_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1016_fu_71615_p4() {
    trunc_ln708_1016_fu_71615_p4 = mul_ln1118_998_fu_71609_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1017_fu_71634_p4() {
    trunc_ln708_1017_fu_71634_p4 = mul_ln1118_999_fu_71628_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1018_fu_71653_p4() {
    trunc_ln708_1018_fu_71653_p4 = mul_ln1118_1000_fu_71647_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1019_fu_71671_p4() {
    trunc_ln708_1019_fu_71671_p4 = mul_ln1118_1001_fu_71666_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1020_fu_71689_p4() {
    trunc_ln708_1020_fu_71689_p4 = mul_ln1118_1002_fu_71684_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1027_fu_72696_p4() {
    trunc_ln708_1027_fu_72696_p4 = mul_ln1118_1009_fu_72690_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1028_fu_72715_p4() {
    trunc_ln708_1028_fu_72715_p4 = mul_ln1118_1010_fu_72709_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1029_fu_72734_p4() {
    trunc_ln708_1029_fu_72734_p4 = mul_ln1118_1011_fu_72728_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_102_fu_53789_p4() {
    trunc_ln708_102_fu_53789_p4 = mul_ln1118_84_fu_53783_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1030_fu_72753_p4() {
    trunc_ln708_1030_fu_72753_p4 = mul_ln1118_1012_fu_72747_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1031_fu_72772_p4() {
    trunc_ln708_1031_fu_72772_p4 = mul_ln1118_1013_fu_72766_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1032_fu_72791_p4() {
    trunc_ln708_1032_fu_72791_p4 = mul_ln1118_1014_fu_72785_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1033_fu_72810_p4() {
    trunc_ln708_1033_fu_72810_p4 = mul_ln1118_1015_fu_72804_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1034_fu_72829_p4() {
    trunc_ln708_1034_fu_72829_p4 = mul_ln1118_1016_fu_72823_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1035_fu_72848_p4() {
    trunc_ln708_1035_fu_72848_p4 = mul_ln1118_1017_fu_72842_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1036_fu_72867_p4() {
    trunc_ln708_1036_fu_72867_p4 = mul_ln1118_1018_fu_72861_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1037_fu_72886_p4() {
    trunc_ln708_1037_fu_72886_p4 = mul_ln1118_1019_fu_72880_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1038_fu_72905_p4() {
    trunc_ln708_1038_fu_72905_p4 = mul_ln1118_1020_fu_72899_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1039_fu_72924_p4() {
    trunc_ln708_1039_fu_72924_p4 = mul_ln1118_1021_fu_72918_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_103_fu_53811_p4() {
    trunc_ln708_103_fu_53811_p4 = mul_ln1118_85_fu_53805_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1040_fu_72943_p4() {
    trunc_ln708_1040_fu_72943_p4 = mul_ln1118_1022_fu_72937_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1041_fu_72962_p4() {
    trunc_ln708_1041_fu_72962_p4 = mul_ln1118_1023_fu_72956_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1042_fu_72981_p4() {
    trunc_ln708_1042_fu_72981_p4 = mul_ln1118_1024_fu_72975_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1043_fu_73000_p4() {
    trunc_ln708_1043_fu_73000_p4 = mul_ln1118_1025_fu_72994_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1044_fu_73019_p4() {
    trunc_ln708_1044_fu_73019_p4 = mul_ln1118_1026_fu_73013_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1045_fu_73038_p4() {
    trunc_ln708_1045_fu_73038_p4 = mul_ln1118_1027_fu_73032_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_104_fu_53833_p4() {
    trunc_ln708_104_fu_53833_p4 = mul_ln1118_86_fu_53827_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1052_fu_73057_p4() {
    trunc_ln708_1052_fu_73057_p4 = mul_ln1118_1034_fu_73051_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1053_fu_73076_p4() {
    trunc_ln708_1053_fu_73076_p4 = mul_ln1118_1035_fu_73070_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1054_fu_73095_p4() {
    trunc_ln708_1054_fu_73095_p4 = mul_ln1118_1036_fu_73089_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1055_fu_73114_p4() {
    trunc_ln708_1055_fu_73114_p4 = mul_ln1118_1037_fu_73108_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1056_fu_73133_p4() {
    trunc_ln708_1056_fu_73133_p4 = mul_ln1118_1038_fu_73127_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1057_fu_73152_p4() {
    trunc_ln708_1057_fu_73152_p4 = mul_ln1118_1039_fu_73146_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1058_fu_73171_p4() {
    trunc_ln708_1058_fu_73171_p4 = mul_ln1118_1040_fu_73165_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1059_fu_73190_p4() {
    trunc_ln708_1059_fu_73190_p4 = mul_ln1118_1041_fu_73184_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_105_fu_53855_p4() {
    trunc_ln708_105_fu_53855_p4 = mul_ln1118_87_fu_53849_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1060_fu_73209_p4() {
    trunc_ln708_1060_fu_73209_p4 = mul_ln1118_1042_fu_73203_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1061_fu_73228_p4() {
    trunc_ln708_1061_fu_73228_p4 = mul_ln1118_1043_fu_73222_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1062_fu_73247_p4() {
    trunc_ln708_1062_fu_73247_p4 = mul_ln1118_1044_fu_73241_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1063_fu_73266_p4() {
    trunc_ln708_1063_fu_73266_p4 = mul_ln1118_1045_fu_73260_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1064_fu_73285_p4() {
    trunc_ln708_1064_fu_73285_p4 = mul_ln1118_1046_fu_73279_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1065_fu_73304_p4() {
    trunc_ln708_1065_fu_73304_p4 = mul_ln1118_1047_fu_73298_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1066_fu_73323_p4() {
    trunc_ln708_1066_fu_73323_p4 = mul_ln1118_1048_fu_73317_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1067_fu_73342_p4() {
    trunc_ln708_1067_fu_73342_p4 = mul_ln1118_1049_fu_73336_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1068_fu_73361_p4() {
    trunc_ln708_1068_fu_73361_p4 = mul_ln1118_1050_fu_73355_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1069_fu_73380_p4() {
    trunc_ln708_1069_fu_73380_p4 = mul_ln1118_1051_fu_73374_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_106_fu_53877_p4() {
    trunc_ln708_106_fu_53877_p4 = mul_ln1118_88_fu_53871_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1070_fu_73398_p4() {
    trunc_ln708_1070_fu_73398_p4 = mul_ln1118_1052_fu_73393_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1077_fu_73417_p4() {
    trunc_ln708_1077_fu_73417_p4 = mul_ln1118_1059_fu_73411_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1078_fu_73436_p4() {
    trunc_ln708_1078_fu_73436_p4 = mul_ln1118_1060_fu_73430_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1079_fu_73455_p4() {
    trunc_ln708_1079_fu_73455_p4 = mul_ln1118_1061_fu_73449_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_107_fu_53899_p4() {
    trunc_ln708_107_fu_53899_p4 = mul_ln1118_89_fu_53893_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1080_fu_73474_p4() {
    trunc_ln708_1080_fu_73474_p4 = mul_ln1118_1062_fu_73468_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1081_fu_73493_p4() {
    trunc_ln708_1081_fu_73493_p4 = mul_ln1118_1063_fu_73487_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1082_fu_73512_p4() {
    trunc_ln708_1082_fu_73512_p4 = mul_ln1118_1064_fu_73506_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1083_fu_73531_p4() {
    trunc_ln708_1083_fu_73531_p4 = mul_ln1118_1065_fu_73525_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1084_fu_73550_p4() {
    trunc_ln708_1084_fu_73550_p4 = mul_ln1118_1066_fu_73544_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1085_fu_73569_p4() {
    trunc_ln708_1085_fu_73569_p4 = mul_ln1118_1067_fu_73563_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1086_fu_73588_p4() {
    trunc_ln708_1086_fu_73588_p4 = mul_ln1118_1068_fu_73582_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1087_fu_73607_p4() {
    trunc_ln708_1087_fu_73607_p4 = mul_ln1118_1069_fu_73601_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1088_fu_73626_p4() {
    trunc_ln708_1088_fu_73626_p4 = mul_ln1118_1070_fu_73620_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1089_fu_73645_p4() {
    trunc_ln708_1089_fu_73645_p4 = mul_ln1118_1071_fu_73639_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_108_fu_53921_p4() {
    trunc_ln708_108_fu_53921_p4 = mul_ln1118_90_fu_53915_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1090_fu_73664_p4() {
    trunc_ln708_1090_fu_73664_p4 = mul_ln1118_1072_fu_73658_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1091_fu_73683_p4() {
    trunc_ln708_1091_fu_73683_p4 = mul_ln1118_1073_fu_73677_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1092_fu_73702_p4() {
    trunc_ln708_1092_fu_73702_p4 = mul_ln1118_1074_fu_73696_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1093_fu_73721_p4() {
    trunc_ln708_1093_fu_73721_p4 = mul_ln1118_1075_fu_73715_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1094_fu_73740_p4() {
    trunc_ln708_1094_fu_73740_p4 = mul_ln1118_1076_fu_73734_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1095_fu_73758_p4() {
    trunc_ln708_1095_fu_73758_p4 = mul_ln1118_1077_fu_73753_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_109_fu_53943_p4() {
    trunc_ln708_109_fu_53943_p4 = mul_ln1118_91_fu_53937_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1102_fu_73777_p4() {
    trunc_ln708_1102_fu_73777_p4 = mul_ln1118_1084_fu_73771_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1103_fu_73796_p4() {
    trunc_ln708_1103_fu_73796_p4 = mul_ln1118_1085_fu_73790_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1104_fu_73815_p4() {
    trunc_ln708_1104_fu_73815_p4 = mul_ln1118_1086_fu_73809_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1105_fu_73834_p4() {
    trunc_ln708_1105_fu_73834_p4 = mul_ln1118_1087_fu_73828_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1106_fu_73853_p4() {
    trunc_ln708_1106_fu_73853_p4 = mul_ln1118_1088_fu_73847_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1107_fu_73872_p4() {
    trunc_ln708_1107_fu_73872_p4 = mul_ln1118_1089_fu_73866_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1108_fu_73891_p4() {
    trunc_ln708_1108_fu_73891_p4 = mul_ln1118_1090_fu_73885_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1109_fu_73910_p4() {
    trunc_ln708_1109_fu_73910_p4 = mul_ln1118_1091_fu_73904_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_110_fu_53965_p4() {
    trunc_ln708_110_fu_53965_p4 = mul_ln1118_92_fu_53959_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1110_fu_73929_p4() {
    trunc_ln708_1110_fu_73929_p4 = mul_ln1118_1092_fu_73923_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1111_fu_73948_p4() {
    trunc_ln708_1111_fu_73948_p4 = mul_ln1118_1093_fu_73942_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1112_fu_73967_p4() {
    trunc_ln708_1112_fu_73967_p4 = mul_ln1118_1094_fu_73961_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1113_fu_73986_p4() {
    trunc_ln708_1113_fu_73986_p4 = mul_ln1118_1095_fu_73980_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1114_fu_74005_p4() {
    trunc_ln708_1114_fu_74005_p4 = mul_ln1118_1096_fu_73999_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1115_fu_74024_p4() {
    trunc_ln708_1115_fu_74024_p4 = mul_ln1118_1097_fu_74018_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1116_fu_74043_p4() {
    trunc_ln708_1116_fu_74043_p4 = mul_ln1118_1098_fu_74037_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1117_fu_74062_p4() {
    trunc_ln708_1117_fu_74062_p4 = mul_ln1118_1099_fu_74056_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1118_fu_74081_p4() {
    trunc_ln708_1118_fu_74081_p4 = mul_ln1118_1100_fu_74075_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1119_fu_74100_p4() {
    trunc_ln708_1119_fu_74100_p4 = mul_ln1118_1101_fu_74094_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_111_fu_53987_p4() {
    trunc_ln708_111_fu_53987_p4 = mul_ln1118_93_fu_53981_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1120_fu_74118_p4() {
    trunc_ln708_1120_fu_74118_p4 = mul_ln1118_1102_fu_74113_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1127_fu_74137_p4() {
    trunc_ln708_1127_fu_74137_p4 = mul_ln1118_1109_fu_74131_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1128_fu_74156_p4() {
    trunc_ln708_1128_fu_74156_p4 = mul_ln1118_1110_fu_74150_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1129_fu_74175_p4() {
    trunc_ln708_1129_fu_74175_p4 = mul_ln1118_1111_fu_74169_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_112_fu_54009_p4() {
    trunc_ln708_112_fu_54009_p4 = mul_ln1118_94_fu_54003_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1130_fu_74194_p4() {
    trunc_ln708_1130_fu_74194_p4 = mul_ln1118_1112_fu_74188_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1131_fu_74213_p4() {
    trunc_ln708_1131_fu_74213_p4 = mul_ln1118_1113_fu_74207_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1132_fu_74232_p4() {
    trunc_ln708_1132_fu_74232_p4 = mul_ln1118_1114_fu_74226_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1133_fu_74251_p4() {
    trunc_ln708_1133_fu_74251_p4 = mul_ln1118_1115_fu_74245_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1134_fu_74270_p4() {
    trunc_ln708_1134_fu_74270_p4 = mul_ln1118_1116_fu_74264_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1135_fu_74289_p4() {
    trunc_ln708_1135_fu_74289_p4 = mul_ln1118_1117_fu_74283_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1136_fu_74308_p4() {
    trunc_ln708_1136_fu_74308_p4 = mul_ln1118_1118_fu_74302_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1137_fu_74327_p4() {
    trunc_ln708_1137_fu_74327_p4 = mul_ln1118_1119_fu_74321_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1138_fu_74346_p4() {
    trunc_ln708_1138_fu_74346_p4 = mul_ln1118_1120_fu_74340_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1139_fu_74365_p4() {
    trunc_ln708_1139_fu_74365_p4 = mul_ln1118_1121_fu_74359_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_113_fu_54031_p4() {
    trunc_ln708_113_fu_54031_p4 = mul_ln1118_95_fu_54025_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1140_fu_74384_p4() {
    trunc_ln708_1140_fu_74384_p4 = mul_ln1118_1122_fu_74378_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1141_fu_74403_p4() {
    trunc_ln708_1141_fu_74403_p4 = mul_ln1118_1123_fu_74397_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1142_fu_74422_p4() {
    trunc_ln708_1142_fu_74422_p4 = mul_ln1118_1124_fu_74416_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1143_fu_74441_p4() {
    trunc_ln708_1143_fu_74441_p4 = mul_ln1118_1125_fu_74435_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1144_fu_74460_p4() {
    trunc_ln708_1144_fu_74460_p4 = mul_ln1118_1126_fu_74454_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1145_fu_74479_p4() {
    trunc_ln708_1145_fu_74479_p4 = mul_ln1118_1127_fu_74473_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1146_fu_74498_p4() {
    trunc_ln708_1146_fu_74498_p4 = mul_ln1118_1128_fu_74492_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1147_fu_74517_p4() {
    trunc_ln708_1147_fu_74517_p4 = mul_ln1118_1129_fu_74511_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1148_fu_74536_p4() {
    trunc_ln708_1148_fu_74536_p4 = mul_ln1118_1130_fu_74530_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1149_fu_74555_p4() {
    trunc_ln708_1149_fu_74555_p4 = mul_ln1118_1131_fu_74549_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_114_fu_54053_p4() {
    trunc_ln708_114_fu_54053_p4 = mul_ln1118_96_fu_54047_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1152_fu_74574_p4() {
    trunc_ln708_1152_fu_74574_p4 = mul_ln1118_1134_fu_74568_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1153_fu_74593_p4() {
    trunc_ln708_1153_fu_74593_p4 = mul_ln1118_1135_fu_74587_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1154_fu_74612_p4() {
    trunc_ln708_1154_fu_74612_p4 = mul_ln1118_1136_fu_74606_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1155_fu_74631_p4() {
    trunc_ln708_1155_fu_74631_p4 = mul_ln1118_1137_fu_74625_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1156_fu_74650_p4() {
    trunc_ln708_1156_fu_74650_p4 = mul_ln1118_1138_fu_74644_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1157_fu_74669_p4() {
    trunc_ln708_1157_fu_74669_p4 = mul_ln1118_1139_fu_74663_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1158_fu_74688_p4() {
    trunc_ln708_1158_fu_74688_p4 = mul_ln1118_1140_fu_74682_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1159_fu_74707_p4() {
    trunc_ln708_1159_fu_74707_p4 = mul_ln1118_1141_fu_74701_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_115_fu_54075_p4() {
    trunc_ln708_115_fu_54075_p4 = mul_ln1118_97_fu_54069_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1160_fu_74726_p4() {
    trunc_ln708_1160_fu_74726_p4 = mul_ln1118_1142_fu_74720_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1161_fu_74745_p4() {
    trunc_ln708_1161_fu_74745_p4 = mul_ln1118_1143_fu_74739_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1162_fu_74764_p4() {
    trunc_ln708_1162_fu_74764_p4 = mul_ln1118_1144_fu_74758_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1163_fu_74783_p4() {
    trunc_ln708_1163_fu_74783_p4 = mul_ln1118_1145_fu_74777_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1164_fu_74802_p4() {
    trunc_ln708_1164_fu_74802_p4 = mul_ln1118_1146_fu_74796_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1165_fu_74821_p4() {
    trunc_ln708_1165_fu_74821_p4 = mul_ln1118_1147_fu_74815_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1166_fu_74840_p4() {
    trunc_ln708_1166_fu_74840_p4 = mul_ln1118_1148_fu_74834_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1167_fu_74859_p4() {
    trunc_ln708_1167_fu_74859_p4 = mul_ln1118_1149_fu_74853_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1168_fu_74878_p4() {
    trunc_ln708_1168_fu_74878_p4 = mul_ln1118_1150_fu_74872_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1169_fu_74896_p4() {
    trunc_ln708_1169_fu_74896_p4 = mul_ln1118_1151_fu_74891_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_116_fu_54097_p4() {
    trunc_ln708_116_fu_54097_p4 = mul_ln1118_98_fu_54091_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1170_fu_74914_p4() {
    trunc_ln708_1170_fu_74914_p4 = mul_ln1118_1152_fu_74909_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1177_fu_74933_p4() {
    trunc_ln708_1177_fu_74933_p4 = mul_ln1118_1159_fu_74927_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1178_fu_74952_p4() {
    trunc_ln708_1178_fu_74952_p4 = mul_ln1118_1160_fu_74946_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1179_fu_74971_p4() {
    trunc_ln708_1179_fu_74971_p4 = mul_ln1118_1161_fu_74965_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_117_fu_54119_p4() {
    trunc_ln708_117_fu_54119_p4 = mul_ln1118_99_fu_54113_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1180_fu_74990_p4() {
    trunc_ln708_1180_fu_74990_p4 = mul_ln1118_1162_fu_74984_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1181_fu_75009_p4() {
    trunc_ln708_1181_fu_75009_p4 = mul_ln1118_1163_fu_75003_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1182_fu_75028_p4() {
    trunc_ln708_1182_fu_75028_p4 = mul_ln1118_1164_fu_75022_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1183_fu_75047_p4() {
    trunc_ln708_1183_fu_75047_p4 = mul_ln1118_1165_fu_75041_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1184_fu_75066_p4() {
    trunc_ln708_1184_fu_75066_p4 = mul_ln1118_1166_fu_75060_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1185_fu_75085_p4() {
    trunc_ln708_1185_fu_75085_p4 = mul_ln1118_1167_fu_75079_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1186_fu_75104_p4() {
    trunc_ln708_1186_fu_75104_p4 = mul_ln1118_1168_fu_75098_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1187_fu_75123_p4() {
    trunc_ln708_1187_fu_75123_p4 = mul_ln1118_1169_fu_75117_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1188_fu_75142_p4() {
    trunc_ln708_1188_fu_75142_p4 = mul_ln1118_1170_fu_75136_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1189_fu_75161_p4() {
    trunc_ln708_1189_fu_75161_p4 = mul_ln1118_1171_fu_75155_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_118_fu_54141_p4() {
    trunc_ln708_118_fu_54141_p4 = mul_ln1118_100_fu_54135_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1190_fu_75180_p4() {
    trunc_ln708_1190_fu_75180_p4 = mul_ln1118_1172_fu_75174_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1191_fu_75199_p4() {
    trunc_ln708_1191_fu_75199_p4 = mul_ln1118_1173_fu_75193_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1192_fu_75218_p4() {
    trunc_ln708_1192_fu_75218_p4 = mul_ln1118_1174_fu_75212_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1193_fu_75237_p4() {
    trunc_ln708_1193_fu_75237_p4 = mul_ln1118_1175_fu_75231_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1194_fu_75255_p4() {
    trunc_ln708_1194_fu_75255_p4 = mul_ln1118_1176_fu_75250_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1195_fu_75273_p4() {
    trunc_ln708_1195_fu_75273_p4 = mul_ln1118_1177_fu_75268_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_119_fu_54163_p4() {
    trunc_ln708_119_fu_54163_p4 = mul_ln1118_101_fu_54157_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1202_fu_75292_p4() {
    trunc_ln708_1202_fu_75292_p4 = mul_ln1118_1184_fu_75286_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1203_fu_75311_p4() {
    trunc_ln708_1203_fu_75311_p4 = mul_ln1118_1185_fu_75305_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1204_fu_75330_p4() {
    trunc_ln708_1204_fu_75330_p4 = mul_ln1118_1186_fu_75324_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1205_fu_75349_p4() {
    trunc_ln708_1205_fu_75349_p4 = mul_ln1118_1187_fu_75343_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1206_fu_75368_p4() {
    trunc_ln708_1206_fu_75368_p4 = mul_ln1118_1188_fu_75362_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1207_fu_75387_p4() {
    trunc_ln708_1207_fu_75387_p4 = mul_ln1118_1189_fu_75381_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1208_fu_75406_p4() {
    trunc_ln708_1208_fu_75406_p4 = mul_ln1118_1190_fu_75400_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1209_fu_75425_p4() {
    trunc_ln708_1209_fu_75425_p4 = mul_ln1118_1191_fu_75419_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_120_fu_54181_p4() {
    trunc_ln708_120_fu_54181_p4 = mul_ln1118_102_fu_54176_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1210_fu_75444_p4() {
    trunc_ln708_1210_fu_75444_p4 = mul_ln1118_1192_fu_75438_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1211_fu_75463_p4() {
    trunc_ln708_1211_fu_75463_p4 = mul_ln1118_1193_fu_75457_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1212_fu_75482_p4() {
    trunc_ln708_1212_fu_75482_p4 = mul_ln1118_1194_fu_75476_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1213_fu_75501_p4() {
    trunc_ln708_1213_fu_75501_p4 = mul_ln1118_1195_fu_75495_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1214_fu_75520_p4() {
    trunc_ln708_1214_fu_75520_p4 = mul_ln1118_1196_fu_75514_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1215_fu_75539_p4() {
    trunc_ln708_1215_fu_75539_p4 = mul_ln1118_1197_fu_75533_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1216_fu_75558_p4() {
    trunc_ln708_1216_fu_75558_p4 = mul_ln1118_1198_fu_75552_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1217_fu_75577_p4() {
    trunc_ln708_1217_fu_75577_p4 = mul_ln1118_1199_fu_75571_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1218_fu_75596_p4() {
    trunc_ln708_1218_fu_75596_p4 = mul_ln1118_1200_fu_75590_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1219_fu_75614_p4() {
    trunc_ln708_1219_fu_75614_p4 = mul_ln1118_1201_fu_75609_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1220_fu_75632_p4() {
    trunc_ln708_1220_fu_75632_p4 = mul_ln1118_1202_fu_75627_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1227_fu_76639_p4() {
    trunc_ln708_1227_fu_76639_p4 = mul_ln1118_1209_fu_76633_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1228_fu_76658_p4() {
    trunc_ln708_1228_fu_76658_p4 = mul_ln1118_1210_fu_76652_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1229_fu_76677_p4() {
    trunc_ln708_1229_fu_76677_p4 = mul_ln1118_1211_fu_76671_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1230_fu_76696_p4() {
    trunc_ln708_1230_fu_76696_p4 = mul_ln1118_1212_fu_76690_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1231_fu_76715_p4() {
    trunc_ln708_1231_fu_76715_p4 = mul_ln1118_1213_fu_76709_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1232_fu_76734_p4() {
    trunc_ln708_1232_fu_76734_p4 = mul_ln1118_1214_fu_76728_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1233_fu_76753_p4() {
    trunc_ln708_1233_fu_76753_p4 = mul_ln1118_1215_fu_76747_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1234_fu_76772_p4() {
    trunc_ln708_1234_fu_76772_p4 = mul_ln1118_1216_fu_76766_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1235_fu_76791_p4() {
    trunc_ln708_1235_fu_76791_p4 = mul_ln1118_1217_fu_76785_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1236_fu_76810_p4() {
    trunc_ln708_1236_fu_76810_p4 = mul_ln1118_1218_fu_76804_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1237_fu_76829_p4() {
    trunc_ln708_1237_fu_76829_p4 = mul_ln1118_1219_fu_76823_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1238_fu_76848_p4() {
    trunc_ln708_1238_fu_76848_p4 = mul_ln1118_1220_fu_76842_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1239_fu_76867_p4() {
    trunc_ln708_1239_fu_76867_p4 = mul_ln1118_1221_fu_76861_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1240_fu_76886_p4() {
    trunc_ln708_1240_fu_76886_p4 = mul_ln1118_1222_fu_76880_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1241_fu_76905_p4() {
    trunc_ln708_1241_fu_76905_p4 = mul_ln1118_1223_fu_76899_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1242_fu_76924_p4() {
    trunc_ln708_1242_fu_76924_p4 = mul_ln1118_1224_fu_76918_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1243_fu_76943_p4() {
    trunc_ln708_1243_fu_76943_p4 = mul_ln1118_1225_fu_76937_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1244_fu_76962_p4() {
    trunc_ln708_1244_fu_76962_p4 = mul_ln1118_1226_fu_76956_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1245_fu_76981_p4() {
    trunc_ln708_1245_fu_76981_p4 = mul_ln1118_1227_fu_76975_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1252_fu_77000_p4() {
    trunc_ln708_1252_fu_77000_p4 = mul_ln1118_1234_fu_76994_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1253_fu_77019_p4() {
    trunc_ln708_1253_fu_77019_p4 = mul_ln1118_1235_fu_77013_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1254_fu_77038_p4() {
    trunc_ln708_1254_fu_77038_p4 = mul_ln1118_1236_fu_77032_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1255_fu_77057_p4() {
    trunc_ln708_1255_fu_77057_p4 = mul_ln1118_1237_fu_77051_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1256_fu_77076_p4() {
    trunc_ln708_1256_fu_77076_p4 = mul_ln1118_1238_fu_77070_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1257_fu_77095_p4() {
    trunc_ln708_1257_fu_77095_p4 = mul_ln1118_1239_fu_77089_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1258_fu_77114_p4() {
    trunc_ln708_1258_fu_77114_p4 = mul_ln1118_1240_fu_77108_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1259_fu_77133_p4() {
    trunc_ln708_1259_fu_77133_p4 = mul_ln1118_1241_fu_77127_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1260_fu_77152_p4() {
    trunc_ln708_1260_fu_77152_p4 = mul_ln1118_1242_fu_77146_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1261_fu_77171_p4() {
    trunc_ln708_1261_fu_77171_p4 = mul_ln1118_1243_fu_77165_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1262_fu_77190_p4() {
    trunc_ln708_1262_fu_77190_p4 = mul_ln1118_1244_fu_77184_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1263_fu_77209_p4() {
    trunc_ln708_1263_fu_77209_p4 = mul_ln1118_1245_fu_77203_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1264_fu_77228_p4() {
    trunc_ln708_1264_fu_77228_p4 = mul_ln1118_1246_fu_77222_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1265_fu_77247_p4() {
    trunc_ln708_1265_fu_77247_p4 = mul_ln1118_1247_fu_77241_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1266_fu_77266_p4() {
    trunc_ln708_1266_fu_77266_p4 = mul_ln1118_1248_fu_77260_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1267_fu_77285_p4() {
    trunc_ln708_1267_fu_77285_p4 = mul_ln1118_1249_fu_77279_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1268_fu_77304_p4() {
    trunc_ln708_1268_fu_77304_p4 = mul_ln1118_1250_fu_77298_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1269_fu_77323_p4() {
    trunc_ln708_1269_fu_77323_p4 = mul_ln1118_1251_fu_77317_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1270_fu_77341_p4() {
    trunc_ln708_1270_fu_77341_p4 = mul_ln1118_1252_fu_77336_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1277_fu_77360_p4() {
    trunc_ln708_1277_fu_77360_p4 = mul_ln1118_1259_fu_77354_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1278_fu_77379_p4() {
    trunc_ln708_1278_fu_77379_p4 = mul_ln1118_1260_fu_77373_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1279_fu_77398_p4() {
    trunc_ln708_1279_fu_77398_p4 = mul_ln1118_1261_fu_77392_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_127_fu_54203_p4() {
    trunc_ln708_127_fu_54203_p4 = mul_ln1118_109_fu_54197_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1280_fu_77417_p4() {
    trunc_ln708_1280_fu_77417_p4 = mul_ln1118_1262_fu_77411_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1281_fu_77436_p4() {
    trunc_ln708_1281_fu_77436_p4 = mul_ln1118_1263_fu_77430_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1282_fu_77455_p4() {
    trunc_ln708_1282_fu_77455_p4 = mul_ln1118_1264_fu_77449_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1283_fu_77474_p4() {
    trunc_ln708_1283_fu_77474_p4 = mul_ln1118_1265_fu_77468_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1284_fu_77493_p4() {
    trunc_ln708_1284_fu_77493_p4 = mul_ln1118_1266_fu_77487_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1285_fu_77512_p4() {
    trunc_ln708_1285_fu_77512_p4 = mul_ln1118_1267_fu_77506_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1286_fu_77531_p4() {
    trunc_ln708_1286_fu_77531_p4 = mul_ln1118_1268_fu_77525_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1287_fu_77550_p4() {
    trunc_ln708_1287_fu_77550_p4 = mul_ln1118_1269_fu_77544_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1288_fu_77569_p4() {
    trunc_ln708_1288_fu_77569_p4 = mul_ln1118_1270_fu_77563_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1289_fu_77588_p4() {
    trunc_ln708_1289_fu_77588_p4 = mul_ln1118_1271_fu_77582_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_128_fu_54225_p4() {
    trunc_ln708_128_fu_54225_p4 = mul_ln1118_110_fu_54219_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1290_fu_77607_p4() {
    trunc_ln708_1290_fu_77607_p4 = mul_ln1118_1272_fu_77601_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1291_fu_77626_p4() {
    trunc_ln708_1291_fu_77626_p4 = mul_ln1118_1273_fu_77620_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1292_fu_77645_p4() {
    trunc_ln708_1292_fu_77645_p4 = mul_ln1118_1274_fu_77639_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1293_fu_77664_p4() {
    trunc_ln708_1293_fu_77664_p4 = mul_ln1118_1275_fu_77658_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1294_fu_77683_p4() {
    trunc_ln708_1294_fu_77683_p4 = mul_ln1118_1276_fu_77677_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1295_fu_77701_p4() {
    trunc_ln708_1295_fu_77701_p4 = mul_ln1118_1277_fu_77696_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_129_fu_54247_p4() {
    trunc_ln708_129_fu_54247_p4 = mul_ln1118_111_fu_54241_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1302_fu_77720_p4() {
    trunc_ln708_1302_fu_77720_p4 = mul_ln1118_1284_fu_77714_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1303_fu_77739_p4() {
    trunc_ln708_1303_fu_77739_p4 = mul_ln1118_1285_fu_77733_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1304_fu_77758_p4() {
    trunc_ln708_1304_fu_77758_p4 = mul_ln1118_1286_fu_77752_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1305_fu_77777_p4() {
    trunc_ln708_1305_fu_77777_p4 = mul_ln1118_1287_fu_77771_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1306_fu_77796_p4() {
    trunc_ln708_1306_fu_77796_p4 = mul_ln1118_1288_fu_77790_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1307_fu_77815_p4() {
    trunc_ln708_1307_fu_77815_p4 = mul_ln1118_1289_fu_77809_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1308_fu_77834_p4() {
    trunc_ln708_1308_fu_77834_p4 = mul_ln1118_1290_fu_77828_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1309_fu_77853_p4() {
    trunc_ln708_1309_fu_77853_p4 = mul_ln1118_1291_fu_77847_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_130_fu_54269_p4() {
    trunc_ln708_130_fu_54269_p4 = mul_ln1118_112_fu_54263_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1310_fu_77872_p4() {
    trunc_ln708_1310_fu_77872_p4 = mul_ln1118_1292_fu_77866_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1311_fu_77891_p4() {
    trunc_ln708_1311_fu_77891_p4 = mul_ln1118_1293_fu_77885_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1312_fu_77910_p4() {
    trunc_ln708_1312_fu_77910_p4 = mul_ln1118_1294_fu_77904_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1313_fu_77929_p4() {
    trunc_ln708_1313_fu_77929_p4 = mul_ln1118_1295_fu_77923_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1314_fu_77948_p4() {
    trunc_ln708_1314_fu_77948_p4 = mul_ln1118_1296_fu_77942_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1315_fu_77967_p4() {
    trunc_ln708_1315_fu_77967_p4 = mul_ln1118_1297_fu_77961_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1316_fu_77986_p4() {
    trunc_ln708_1316_fu_77986_p4 = mul_ln1118_1298_fu_77980_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1317_fu_78005_p4() {
    trunc_ln708_1317_fu_78005_p4 = mul_ln1118_1299_fu_77999_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1318_fu_78024_p4() {
    trunc_ln708_1318_fu_78024_p4 = mul_ln1118_1300_fu_78018_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1319_fu_78043_p4() {
    trunc_ln708_1319_fu_78043_p4 = mul_ln1118_1301_fu_78037_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_131_fu_54291_p4() {
    trunc_ln708_131_fu_54291_p4 = mul_ln1118_113_fu_54285_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1320_fu_78061_p4() {
    trunc_ln708_1320_fu_78061_p4 = mul_ln1118_1302_fu_78056_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1327_fu_78080_p4() {
    trunc_ln708_1327_fu_78080_p4 = mul_ln1118_1309_fu_78074_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1328_fu_78099_p4() {
    trunc_ln708_1328_fu_78099_p4 = mul_ln1118_1310_fu_78093_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1329_fu_78118_p4() {
    trunc_ln708_1329_fu_78118_p4 = mul_ln1118_1311_fu_78112_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_132_fu_54313_p4() {
    trunc_ln708_132_fu_54313_p4 = mul_ln1118_114_fu_54307_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1330_fu_78137_p4() {
    trunc_ln708_1330_fu_78137_p4 = mul_ln1118_1312_fu_78131_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1331_fu_78156_p4() {
    trunc_ln708_1331_fu_78156_p4 = mul_ln1118_1313_fu_78150_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1332_fu_78175_p4() {
    trunc_ln708_1332_fu_78175_p4 = mul_ln1118_1314_fu_78169_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1333_fu_78194_p4() {
    trunc_ln708_1333_fu_78194_p4 = mul_ln1118_1315_fu_78188_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1334_fu_78213_p4() {
    trunc_ln708_1334_fu_78213_p4 = mul_ln1118_1316_fu_78207_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1335_fu_78232_p4() {
    trunc_ln708_1335_fu_78232_p4 = mul_ln1118_1317_fu_78226_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1336_fu_78251_p4() {
    trunc_ln708_1336_fu_78251_p4 = mul_ln1118_1318_fu_78245_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1337_fu_78270_p4() {
    trunc_ln708_1337_fu_78270_p4 = mul_ln1118_1319_fu_78264_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1338_fu_78289_p4() {
    trunc_ln708_1338_fu_78289_p4 = mul_ln1118_1320_fu_78283_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1339_fu_78308_p4() {
    trunc_ln708_1339_fu_78308_p4 = mul_ln1118_1321_fu_78302_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_133_fu_54335_p4() {
    trunc_ln708_133_fu_54335_p4 = mul_ln1118_115_fu_54329_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1340_fu_78327_p4() {
    trunc_ln708_1340_fu_78327_p4 = mul_ln1118_1322_fu_78321_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1341_fu_78346_p4() {
    trunc_ln708_1341_fu_78346_p4 = mul_ln1118_1323_fu_78340_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1342_fu_78365_p4() {
    trunc_ln708_1342_fu_78365_p4 = mul_ln1118_1324_fu_78359_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1343_fu_78384_p4() {
    trunc_ln708_1343_fu_78384_p4 = mul_ln1118_1325_fu_78378_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1344_fu_78403_p4() {
    trunc_ln708_1344_fu_78403_p4 = mul_ln1118_1326_fu_78397_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1345_fu_78422_p4() {
    trunc_ln708_1345_fu_78422_p4 = mul_ln1118_1327_fu_78416_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1346_fu_78441_p4() {
    trunc_ln708_1346_fu_78441_p4 = mul_ln1118_1328_fu_78435_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1347_fu_78460_p4() {
    trunc_ln708_1347_fu_78460_p4 = mul_ln1118_1329_fu_78454_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1348_fu_78479_p4() {
    trunc_ln708_1348_fu_78479_p4 = mul_ln1118_1330_fu_78473_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1349_fu_78498_p4() {
    trunc_ln708_1349_fu_78498_p4 = mul_ln1118_1331_fu_78492_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_134_fu_54357_p4() {
    trunc_ln708_134_fu_54357_p4 = mul_ln1118_116_fu_54351_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1352_fu_78517_p4() {
    trunc_ln708_1352_fu_78517_p4 = mul_ln1118_1334_fu_78511_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1353_fu_78536_p4() {
    trunc_ln708_1353_fu_78536_p4 = mul_ln1118_1335_fu_78530_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1354_fu_78555_p4() {
    trunc_ln708_1354_fu_78555_p4 = mul_ln1118_1336_fu_78549_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1355_fu_78574_p4() {
    trunc_ln708_1355_fu_78574_p4 = mul_ln1118_1337_fu_78568_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1356_fu_78593_p4() {
    trunc_ln708_1356_fu_78593_p4 = mul_ln1118_1338_fu_78587_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1357_fu_78612_p4() {
    trunc_ln708_1357_fu_78612_p4 = mul_ln1118_1339_fu_78606_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1358_fu_78631_p4() {
    trunc_ln708_1358_fu_78631_p4 = mul_ln1118_1340_fu_78625_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1359_fu_78650_p4() {
    trunc_ln708_1359_fu_78650_p4 = mul_ln1118_1341_fu_78644_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_135_fu_54379_p4() {
    trunc_ln708_135_fu_54379_p4 = mul_ln1118_117_fu_54373_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1360_fu_78669_p4() {
    trunc_ln708_1360_fu_78669_p4 = mul_ln1118_1342_fu_78663_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1361_fu_78688_p4() {
    trunc_ln708_1361_fu_78688_p4 = mul_ln1118_1343_fu_78682_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1362_fu_78707_p4() {
    trunc_ln708_1362_fu_78707_p4 = mul_ln1118_1344_fu_78701_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1363_fu_78726_p4() {
    trunc_ln708_1363_fu_78726_p4 = mul_ln1118_1345_fu_78720_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1364_fu_78745_p4() {
    trunc_ln708_1364_fu_78745_p4 = mul_ln1118_1346_fu_78739_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1365_fu_78764_p4() {
    trunc_ln708_1365_fu_78764_p4 = mul_ln1118_1347_fu_78758_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1366_fu_78783_p4() {
    trunc_ln708_1366_fu_78783_p4 = mul_ln1118_1348_fu_78777_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1367_fu_78802_p4() {
    trunc_ln708_1367_fu_78802_p4 = mul_ln1118_1349_fu_78796_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1368_fu_78821_p4() {
    trunc_ln708_1368_fu_78821_p4 = mul_ln1118_1350_fu_78815_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1369_fu_78839_p4() {
    trunc_ln708_1369_fu_78839_p4 = mul_ln1118_1351_fu_78834_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_136_fu_54401_p4() {
    trunc_ln708_136_fu_54401_p4 = mul_ln1118_118_fu_54395_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1370_fu_78857_p4() {
    trunc_ln708_1370_fu_78857_p4 = mul_ln1118_1352_fu_78852_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1377_fu_78876_p4() {
    trunc_ln708_1377_fu_78876_p4 = mul_ln1118_1359_fu_78870_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1378_fu_78895_p4() {
    trunc_ln708_1378_fu_78895_p4 = mul_ln1118_1360_fu_78889_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1379_fu_78914_p4() {
    trunc_ln708_1379_fu_78914_p4 = mul_ln1118_1361_fu_78908_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_137_fu_54423_p4() {
    trunc_ln708_137_fu_54423_p4 = mul_ln1118_119_fu_54417_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1380_fu_78933_p4() {
    trunc_ln708_1380_fu_78933_p4 = mul_ln1118_1362_fu_78927_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1381_fu_78952_p4() {
    trunc_ln708_1381_fu_78952_p4 = mul_ln1118_1363_fu_78946_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1382_fu_78971_p4() {
    trunc_ln708_1382_fu_78971_p4 = mul_ln1118_1364_fu_78965_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1383_fu_78990_p4() {
    trunc_ln708_1383_fu_78990_p4 = mul_ln1118_1365_fu_78984_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1384_fu_79009_p4() {
    trunc_ln708_1384_fu_79009_p4 = mul_ln1118_1366_fu_79003_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1385_fu_79028_p4() {
    trunc_ln708_1385_fu_79028_p4 = mul_ln1118_1367_fu_79022_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1386_fu_79047_p4() {
    trunc_ln708_1386_fu_79047_p4 = mul_ln1118_1368_fu_79041_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1387_fu_79066_p4() {
    trunc_ln708_1387_fu_79066_p4 = mul_ln1118_1369_fu_79060_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1388_fu_79085_p4() {
    trunc_ln708_1388_fu_79085_p4 = mul_ln1118_1370_fu_79079_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1389_fu_79104_p4() {
    trunc_ln708_1389_fu_79104_p4 = mul_ln1118_1371_fu_79098_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_138_fu_54445_p4() {
    trunc_ln708_138_fu_54445_p4 = mul_ln1118_120_fu_54439_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1390_fu_79123_p4() {
    trunc_ln708_1390_fu_79123_p4 = mul_ln1118_1372_fu_79117_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1391_fu_79142_p4() {
    trunc_ln708_1391_fu_79142_p4 = mul_ln1118_1373_fu_79136_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1392_fu_79161_p4() {
    trunc_ln708_1392_fu_79161_p4 = mul_ln1118_1374_fu_79155_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1393_fu_79180_p4() {
    trunc_ln708_1393_fu_79180_p4 = mul_ln1118_1375_fu_79174_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1394_fu_79198_p4() {
    trunc_ln708_1394_fu_79198_p4 = mul_ln1118_1376_fu_79193_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1395_fu_79216_p4() {
    trunc_ln708_1395_fu_79216_p4 = mul_ln1118_1377_fu_79211_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_139_fu_54467_p4() {
    trunc_ln708_139_fu_54467_p4 = mul_ln1118_121_fu_54461_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1402_fu_79235_p4() {
    trunc_ln708_1402_fu_79235_p4 = mul_ln1118_1384_fu_79229_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1403_fu_79254_p4() {
    trunc_ln708_1403_fu_79254_p4 = mul_ln1118_1385_fu_79248_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1404_fu_79273_p4() {
    trunc_ln708_1404_fu_79273_p4 = mul_ln1118_1386_fu_79267_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1405_fu_79292_p4() {
    trunc_ln708_1405_fu_79292_p4 = mul_ln1118_1387_fu_79286_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1406_fu_79311_p4() {
    trunc_ln708_1406_fu_79311_p4 = mul_ln1118_1388_fu_79305_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1407_fu_79330_p4() {
    trunc_ln708_1407_fu_79330_p4 = mul_ln1118_1389_fu_79324_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1408_fu_79349_p4() {
    trunc_ln708_1408_fu_79349_p4 = mul_ln1118_1390_fu_79343_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1409_fu_79368_p4() {
    trunc_ln708_1409_fu_79368_p4 = mul_ln1118_1391_fu_79362_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_140_fu_54489_p4() {
    trunc_ln708_140_fu_54489_p4 = mul_ln1118_122_fu_54483_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1410_fu_79387_p4() {
    trunc_ln708_1410_fu_79387_p4 = mul_ln1118_1392_fu_79381_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1411_fu_79406_p4() {
    trunc_ln708_1411_fu_79406_p4 = mul_ln1118_1393_fu_79400_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1412_fu_79425_p4() {
    trunc_ln708_1412_fu_79425_p4 = mul_ln1118_1394_fu_79419_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1413_fu_79444_p4() {
    trunc_ln708_1413_fu_79444_p4 = mul_ln1118_1395_fu_79438_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1414_fu_79463_p4() {
    trunc_ln708_1414_fu_79463_p4 = mul_ln1118_1396_fu_79457_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1415_fu_79482_p4() {
    trunc_ln708_1415_fu_79482_p4 = mul_ln1118_1397_fu_79476_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1416_fu_79501_p4() {
    trunc_ln708_1416_fu_79501_p4 = mul_ln1118_1398_fu_79495_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1417_fu_79520_p4() {
    trunc_ln708_1417_fu_79520_p4 = mul_ln1118_1399_fu_79514_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1418_fu_79539_p4() {
    trunc_ln708_1418_fu_79539_p4 = mul_ln1118_1400_fu_79533_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1419_fu_79557_p4() {
    trunc_ln708_1419_fu_79557_p4 = mul_ln1118_1401_fu_79552_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_141_fu_54511_p4() {
    trunc_ln708_141_fu_54511_p4 = mul_ln1118_123_fu_54505_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1420_fu_79575_p4() {
    trunc_ln708_1420_fu_79575_p4 = mul_ln1118_1402_fu_79570_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1427_fu_80582_p4() {
    trunc_ln708_1427_fu_80582_p4 = mul_ln1118_1409_fu_80576_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1428_fu_80601_p4() {
    trunc_ln708_1428_fu_80601_p4 = mul_ln1118_1410_fu_80595_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1429_fu_80620_p4() {
    trunc_ln708_1429_fu_80620_p4 = mul_ln1118_1411_fu_80614_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_142_fu_54533_p4() {
    trunc_ln708_142_fu_54533_p4 = mul_ln1118_124_fu_54527_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1430_fu_80639_p4() {
    trunc_ln708_1430_fu_80639_p4 = mul_ln1118_1412_fu_80633_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1431_fu_80658_p4() {
    trunc_ln708_1431_fu_80658_p4 = mul_ln1118_1413_fu_80652_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1432_fu_80677_p4() {
    trunc_ln708_1432_fu_80677_p4 = mul_ln1118_1414_fu_80671_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1433_fu_80696_p4() {
    trunc_ln708_1433_fu_80696_p4 = mul_ln1118_1415_fu_80690_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1434_fu_80715_p4() {
    trunc_ln708_1434_fu_80715_p4 = mul_ln1118_1416_fu_80709_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1435_fu_80734_p4() {
    trunc_ln708_1435_fu_80734_p4 = mul_ln1118_1417_fu_80728_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1436_fu_80753_p4() {
    trunc_ln708_1436_fu_80753_p4 = mul_ln1118_1418_fu_80747_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1437_fu_80772_p4() {
    trunc_ln708_1437_fu_80772_p4 = mul_ln1118_1419_fu_80766_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1438_fu_80791_p4() {
    trunc_ln708_1438_fu_80791_p4 = mul_ln1118_1420_fu_80785_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1439_fu_80810_p4() {
    trunc_ln708_1439_fu_80810_p4 = mul_ln1118_1421_fu_80804_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_143_fu_54555_p4() {
    trunc_ln708_143_fu_54555_p4 = mul_ln1118_125_fu_54549_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1440_fu_80829_p4() {
    trunc_ln708_1440_fu_80829_p4 = mul_ln1118_1422_fu_80823_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1441_fu_80848_p4() {
    trunc_ln708_1441_fu_80848_p4 = mul_ln1118_1423_fu_80842_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1442_fu_80867_p4() {
    trunc_ln708_1442_fu_80867_p4 = mul_ln1118_1424_fu_80861_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1443_fu_80886_p4() {
    trunc_ln708_1443_fu_80886_p4 = mul_ln1118_1425_fu_80880_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1444_fu_80905_p4() {
    trunc_ln708_1444_fu_80905_p4 = mul_ln1118_1426_fu_80899_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1445_fu_80924_p4() {
    trunc_ln708_1445_fu_80924_p4 = mul_ln1118_1427_fu_80918_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_144_fu_54577_p4() {
    trunc_ln708_144_fu_54577_p4 = mul_ln1118_126_fu_54571_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1452_fu_80943_p4() {
    trunc_ln708_1452_fu_80943_p4 = mul_ln1118_1434_fu_80937_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1453_fu_80962_p4() {
    trunc_ln708_1453_fu_80962_p4 = mul_ln1118_1435_fu_80956_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1454_fu_80981_p4() {
    trunc_ln708_1454_fu_80981_p4 = mul_ln1118_1436_fu_80975_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1455_fu_81000_p4() {
    trunc_ln708_1455_fu_81000_p4 = mul_ln1118_1437_fu_80994_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1456_fu_81019_p4() {
    trunc_ln708_1456_fu_81019_p4 = mul_ln1118_1438_fu_81013_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1457_fu_81038_p4() {
    trunc_ln708_1457_fu_81038_p4 = mul_ln1118_1439_fu_81032_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1458_fu_81057_p4() {
    trunc_ln708_1458_fu_81057_p4 = mul_ln1118_1440_fu_81051_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1459_fu_81076_p4() {
    trunc_ln708_1459_fu_81076_p4 = mul_ln1118_1441_fu_81070_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_145_fu_54599_p4() {
    trunc_ln708_145_fu_54599_p4 = mul_ln1118_127_fu_54593_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1460_fu_81095_p4() {
    trunc_ln708_1460_fu_81095_p4 = mul_ln1118_1442_fu_81089_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1461_fu_81114_p4() {
    trunc_ln708_1461_fu_81114_p4 = mul_ln1118_1443_fu_81108_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1462_fu_81133_p4() {
    trunc_ln708_1462_fu_81133_p4 = mul_ln1118_1444_fu_81127_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1463_fu_81152_p4() {
    trunc_ln708_1463_fu_81152_p4 = mul_ln1118_1445_fu_81146_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1464_fu_81171_p4() {
    trunc_ln708_1464_fu_81171_p4 = mul_ln1118_1446_fu_81165_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1465_fu_81190_p4() {
    trunc_ln708_1465_fu_81190_p4 = mul_ln1118_1447_fu_81184_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1466_fu_81209_p4() {
    trunc_ln708_1466_fu_81209_p4 = mul_ln1118_1448_fu_81203_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1467_fu_81228_p4() {
    trunc_ln708_1467_fu_81228_p4 = mul_ln1118_1449_fu_81222_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1468_fu_81247_p4() {
    trunc_ln708_1468_fu_81247_p4 = mul_ln1118_1450_fu_81241_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1469_fu_81266_p4() {
    trunc_ln708_1469_fu_81266_p4 = mul_ln1118_1451_fu_81260_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_146_fu_54621_p4() {
    trunc_ln708_146_fu_54621_p4 = mul_ln1118_128_fu_54615_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1470_fu_81284_p4() {
    trunc_ln708_1470_fu_81284_p4 = mul_ln1118_1452_fu_81279_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1477_fu_81303_p4() {
    trunc_ln708_1477_fu_81303_p4 = mul_ln1118_1459_fu_81297_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1478_fu_81322_p4() {
    trunc_ln708_1478_fu_81322_p4 = mul_ln1118_1460_fu_81316_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1479_fu_81341_p4() {
    trunc_ln708_1479_fu_81341_p4 = mul_ln1118_1461_fu_81335_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_147_fu_54643_p4() {
    trunc_ln708_147_fu_54643_p4 = mul_ln1118_129_fu_54637_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1480_fu_81360_p4() {
    trunc_ln708_1480_fu_81360_p4 = mul_ln1118_1462_fu_81354_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1481_fu_81379_p4() {
    trunc_ln708_1481_fu_81379_p4 = mul_ln1118_1463_fu_81373_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1482_fu_81398_p4() {
    trunc_ln708_1482_fu_81398_p4 = mul_ln1118_1464_fu_81392_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1483_fu_81417_p4() {
    trunc_ln708_1483_fu_81417_p4 = mul_ln1118_1465_fu_81411_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1484_fu_81436_p4() {
    trunc_ln708_1484_fu_81436_p4 = mul_ln1118_1466_fu_81430_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1485_fu_81455_p4() {
    trunc_ln708_1485_fu_81455_p4 = mul_ln1118_1467_fu_81449_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1486_fu_81474_p4() {
    trunc_ln708_1486_fu_81474_p4 = mul_ln1118_1468_fu_81468_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1487_fu_81493_p4() {
    trunc_ln708_1487_fu_81493_p4 = mul_ln1118_1469_fu_81487_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1488_fu_81512_p4() {
    trunc_ln708_1488_fu_81512_p4 = mul_ln1118_1470_fu_81506_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1489_fu_81531_p4() {
    trunc_ln708_1489_fu_81531_p4 = mul_ln1118_1471_fu_81525_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_148_fu_54665_p4() {
    trunc_ln708_148_fu_54665_p4 = mul_ln1118_130_fu_54659_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1490_fu_81550_p4() {
    trunc_ln708_1490_fu_81550_p4 = mul_ln1118_1472_fu_81544_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1491_fu_81569_p4() {
    trunc_ln708_1491_fu_81569_p4 = mul_ln1118_1473_fu_81563_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1492_fu_81588_p4() {
    trunc_ln708_1492_fu_81588_p4 = mul_ln1118_1474_fu_81582_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1493_fu_81607_p4() {
    trunc_ln708_1493_fu_81607_p4 = mul_ln1118_1475_fu_81601_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1494_fu_81626_p4() {
    trunc_ln708_1494_fu_81626_p4 = mul_ln1118_1476_fu_81620_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1495_fu_81644_p4() {
    trunc_ln708_1495_fu_81644_p4 = mul_ln1118_1477_fu_81639_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_149_fu_54687_p4() {
    trunc_ln708_149_fu_54687_p4 = mul_ln1118_131_fu_54681_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1502_fu_81663_p4() {
    trunc_ln708_1502_fu_81663_p4 = mul_ln1118_1484_fu_81657_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1503_fu_81682_p4() {
    trunc_ln708_1503_fu_81682_p4 = mul_ln1118_1485_fu_81676_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1504_fu_81701_p4() {
    trunc_ln708_1504_fu_81701_p4 = mul_ln1118_1486_fu_81695_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1505_fu_81720_p4() {
    trunc_ln708_1505_fu_81720_p4 = mul_ln1118_1487_fu_81714_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1506_fu_81739_p4() {
    trunc_ln708_1506_fu_81739_p4 = mul_ln1118_1488_fu_81733_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1507_fu_81758_p4() {
    trunc_ln708_1507_fu_81758_p4 = mul_ln1118_1489_fu_81752_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1508_fu_81777_p4() {
    trunc_ln708_1508_fu_81777_p4 = mul_ln1118_1490_fu_81771_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1509_fu_81796_p4() {
    trunc_ln708_1509_fu_81796_p4 = mul_ln1118_1491_fu_81790_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1510_fu_81815_p4() {
    trunc_ln708_1510_fu_81815_p4 = mul_ln1118_1492_fu_81809_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1511_fu_81834_p4() {
    trunc_ln708_1511_fu_81834_p4 = mul_ln1118_1493_fu_81828_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1512_fu_81853_p4() {
    trunc_ln708_1512_fu_81853_p4 = mul_ln1118_1494_fu_81847_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1513_fu_81872_p4() {
    trunc_ln708_1513_fu_81872_p4 = mul_ln1118_1495_fu_81866_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1514_fu_81891_p4() {
    trunc_ln708_1514_fu_81891_p4 = mul_ln1118_1496_fu_81885_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1515_fu_81910_p4() {
    trunc_ln708_1515_fu_81910_p4 = mul_ln1118_1497_fu_81904_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1516_fu_81929_p4() {
    trunc_ln708_1516_fu_81929_p4 = mul_ln1118_1498_fu_81923_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1517_fu_81948_p4() {
    trunc_ln708_1517_fu_81948_p4 = mul_ln1118_1499_fu_81942_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1518_fu_81967_p4() {
    trunc_ln708_1518_fu_81967_p4 = mul_ln1118_1500_fu_81961_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1519_fu_81986_p4() {
    trunc_ln708_1519_fu_81986_p4 = mul_ln1118_1501_fu_81980_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1520_fu_82004_p4() {
    trunc_ln708_1520_fu_82004_p4 = mul_ln1118_1502_fu_81999_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1527_fu_82023_p4() {
    trunc_ln708_1527_fu_82023_p4 = mul_ln1118_1509_fu_82017_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1528_fu_82042_p4() {
    trunc_ln708_1528_fu_82042_p4 = mul_ln1118_1510_fu_82036_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1529_fu_82061_p4() {
    trunc_ln708_1529_fu_82061_p4 = mul_ln1118_1511_fu_82055_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_152_fu_54709_p4() {
    trunc_ln708_152_fu_54709_p4 = mul_ln1118_134_fu_54703_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1530_fu_82080_p4() {
    trunc_ln708_1530_fu_82080_p4 = mul_ln1118_1512_fu_82074_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1531_fu_82099_p4() {
    trunc_ln708_1531_fu_82099_p4 = mul_ln1118_1513_fu_82093_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1532_fu_82118_p4() {
    trunc_ln708_1532_fu_82118_p4 = mul_ln1118_1514_fu_82112_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1533_fu_82137_p4() {
    trunc_ln708_1533_fu_82137_p4 = mul_ln1118_1515_fu_82131_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1534_fu_82156_p4() {
    trunc_ln708_1534_fu_82156_p4 = mul_ln1118_1516_fu_82150_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1535_fu_82175_p4() {
    trunc_ln708_1535_fu_82175_p4 = mul_ln1118_1517_fu_82169_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1536_fu_82194_p4() {
    trunc_ln708_1536_fu_82194_p4 = mul_ln1118_1518_fu_82188_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1537_fu_82213_p4() {
    trunc_ln708_1537_fu_82213_p4 = mul_ln1118_1519_fu_82207_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1538_fu_82232_p4() {
    trunc_ln708_1538_fu_82232_p4 = mul_ln1118_1520_fu_82226_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1539_fu_82251_p4() {
    trunc_ln708_1539_fu_82251_p4 = mul_ln1118_1521_fu_82245_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_153_fu_54731_p4() {
    trunc_ln708_153_fu_54731_p4 = mul_ln1118_135_fu_54725_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1540_fu_82270_p4() {
    trunc_ln708_1540_fu_82270_p4 = mul_ln1118_1522_fu_82264_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1541_fu_82289_p4() {
    trunc_ln708_1541_fu_82289_p4 = mul_ln1118_1523_fu_82283_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1542_fu_82308_p4() {
    trunc_ln708_1542_fu_82308_p4 = mul_ln1118_1524_fu_82302_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1543_fu_82327_p4() {
    trunc_ln708_1543_fu_82327_p4 = mul_ln1118_1525_fu_82321_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1544_fu_82346_p4() {
    trunc_ln708_1544_fu_82346_p4 = mul_ln1118_1526_fu_82340_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1545_fu_82365_p4() {
    trunc_ln708_1545_fu_82365_p4 = mul_ln1118_1527_fu_82359_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1546_fu_82384_p4() {
    trunc_ln708_1546_fu_82384_p4 = mul_ln1118_1528_fu_82378_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1547_fu_82403_p4() {
    trunc_ln708_1547_fu_82403_p4 = mul_ln1118_1529_fu_82397_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1548_fu_82422_p4() {
    trunc_ln708_1548_fu_82422_p4 = mul_ln1118_1530_fu_82416_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1549_fu_82441_p4() {
    trunc_ln708_1549_fu_82441_p4 = mul_ln1118_1531_fu_82435_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_154_fu_54753_p4() {
    trunc_ln708_154_fu_54753_p4 = mul_ln1118_136_fu_54747_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1552_fu_82460_p4() {
    trunc_ln708_1552_fu_82460_p4 = mul_ln1118_1534_fu_82454_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1553_fu_82479_p4() {
    trunc_ln708_1553_fu_82479_p4 = mul_ln1118_1535_fu_82473_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1554_fu_82498_p4() {
    trunc_ln708_1554_fu_82498_p4 = mul_ln1118_1536_fu_82492_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1555_fu_82517_p4() {
    trunc_ln708_1555_fu_82517_p4 = mul_ln1118_1537_fu_82511_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1556_fu_82536_p4() {
    trunc_ln708_1556_fu_82536_p4 = mul_ln1118_1538_fu_82530_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1557_fu_82555_p4() {
    trunc_ln708_1557_fu_82555_p4 = mul_ln1118_1539_fu_82549_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1558_fu_82574_p4() {
    trunc_ln708_1558_fu_82574_p4 = mul_ln1118_1540_fu_82568_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1559_fu_82593_p4() {
    trunc_ln708_1559_fu_82593_p4 = mul_ln1118_1541_fu_82587_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_155_fu_54775_p4() {
    trunc_ln708_155_fu_54775_p4 = mul_ln1118_137_fu_54769_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1560_fu_82612_p4() {
    trunc_ln708_1560_fu_82612_p4 = mul_ln1118_1542_fu_82606_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1561_fu_82631_p4() {
    trunc_ln708_1561_fu_82631_p4 = mul_ln1118_1543_fu_82625_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1562_fu_82650_p4() {
    trunc_ln708_1562_fu_82650_p4 = mul_ln1118_1544_fu_82644_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1563_fu_82669_p4() {
    trunc_ln708_1563_fu_82669_p4 = mul_ln1118_1545_fu_82663_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1564_fu_82688_p4() {
    trunc_ln708_1564_fu_82688_p4 = mul_ln1118_1546_fu_82682_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1565_fu_82707_p4() {
    trunc_ln708_1565_fu_82707_p4 = mul_ln1118_1547_fu_82701_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1566_fu_82726_p4() {
    trunc_ln708_1566_fu_82726_p4 = mul_ln1118_1548_fu_82720_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1567_fu_82745_p4() {
    trunc_ln708_1567_fu_82745_p4 = mul_ln1118_1549_fu_82739_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1568_fu_82764_p4() {
    trunc_ln708_1568_fu_82764_p4 = mul_ln1118_1550_fu_82758_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1569_fu_82782_p4() {
    trunc_ln708_1569_fu_82782_p4 = mul_ln1118_1551_fu_82777_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_156_fu_54797_p4() {
    trunc_ln708_156_fu_54797_p4 = mul_ln1118_138_fu_54791_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1570_fu_82800_p4() {
    trunc_ln708_1570_fu_82800_p4 = mul_ln1118_1552_fu_82795_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1577_fu_82819_p4() {
    trunc_ln708_1577_fu_82819_p4 = mul_ln1118_1559_fu_82813_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1578_fu_82838_p4() {
    trunc_ln708_1578_fu_82838_p4 = mul_ln1118_1560_fu_82832_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1579_fu_82857_p4() {
    trunc_ln708_1579_fu_82857_p4 = mul_ln1118_1561_fu_82851_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_157_fu_54819_p4() {
    trunc_ln708_157_fu_54819_p4 = mul_ln1118_139_fu_54813_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1580_fu_82876_p4() {
    trunc_ln708_1580_fu_82876_p4 = mul_ln1118_1562_fu_82870_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1581_fu_82895_p4() {
    trunc_ln708_1581_fu_82895_p4 = mul_ln1118_1563_fu_82889_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1582_fu_82914_p4() {
    trunc_ln708_1582_fu_82914_p4 = mul_ln1118_1564_fu_82908_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1583_fu_82933_p4() {
    trunc_ln708_1583_fu_82933_p4 = mul_ln1118_1565_fu_82927_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1584_fu_82952_p4() {
    trunc_ln708_1584_fu_82952_p4 = mul_ln1118_1566_fu_82946_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1585_fu_82971_p4() {
    trunc_ln708_1585_fu_82971_p4 = mul_ln1118_1567_fu_82965_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1586_fu_82990_p4() {
    trunc_ln708_1586_fu_82990_p4 = mul_ln1118_1568_fu_82984_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1587_fu_83009_p4() {
    trunc_ln708_1587_fu_83009_p4 = mul_ln1118_1569_fu_83003_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1588_fu_83028_p4() {
    trunc_ln708_1588_fu_83028_p4 = mul_ln1118_1570_fu_83022_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1589_fu_83047_p4() {
    trunc_ln708_1589_fu_83047_p4 = mul_ln1118_1571_fu_83041_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_158_fu_54841_p4() {
    trunc_ln708_158_fu_54841_p4 = mul_ln1118_140_fu_54835_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1590_fu_83066_p4() {
    trunc_ln708_1590_fu_83066_p4 = mul_ln1118_1572_fu_83060_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1591_fu_83085_p4() {
    trunc_ln708_1591_fu_83085_p4 = mul_ln1118_1573_fu_83079_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1592_fu_83104_p4() {
    trunc_ln708_1592_fu_83104_p4 = mul_ln1118_1574_fu_83098_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1593_fu_83123_p4() {
    trunc_ln708_1593_fu_83123_p4 = mul_ln1118_1575_fu_83117_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1594_fu_83141_p4() {
    trunc_ln708_1594_fu_83141_p4 = mul_ln1118_1576_fu_83136_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1595_fu_83159_p4() {
    trunc_ln708_1595_fu_83159_p4 = mul_ln1118_1577_fu_83154_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_159_fu_54863_p4() {
    trunc_ln708_159_fu_54863_p4 = mul_ln1118_141_fu_54857_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1602_fu_83178_p4() {
    trunc_ln708_1602_fu_83178_p4 = mul_ln1118_1584_fu_83172_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1603_fu_83197_p4() {
    trunc_ln708_1603_fu_83197_p4 = mul_ln1118_1585_fu_83191_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1604_fu_83216_p4() {
    trunc_ln708_1604_fu_83216_p4 = mul_ln1118_1586_fu_83210_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1605_fu_83235_p4() {
    trunc_ln708_1605_fu_83235_p4 = mul_ln1118_1587_fu_83229_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1606_fu_83254_p4() {
    trunc_ln708_1606_fu_83254_p4 = mul_ln1118_1588_fu_83248_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1607_fu_83273_p4() {
    trunc_ln708_1607_fu_83273_p4 = mul_ln1118_1589_fu_83267_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1608_fu_83292_p4() {
    trunc_ln708_1608_fu_83292_p4 = mul_ln1118_1590_fu_83286_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1609_fu_83311_p4() {
    trunc_ln708_1609_fu_83311_p4 = mul_ln1118_1591_fu_83305_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_160_fu_54885_p4() {
    trunc_ln708_160_fu_54885_p4 = mul_ln1118_142_fu_54879_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1610_fu_83330_p4() {
    trunc_ln708_1610_fu_83330_p4 = mul_ln1118_1592_fu_83324_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1611_fu_83349_p4() {
    trunc_ln708_1611_fu_83349_p4 = mul_ln1118_1593_fu_83343_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1612_fu_83368_p4() {
    trunc_ln708_1612_fu_83368_p4 = mul_ln1118_1594_fu_83362_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1613_fu_83387_p4() {
    trunc_ln708_1613_fu_83387_p4 = mul_ln1118_1595_fu_83381_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1614_fu_83406_p4() {
    trunc_ln708_1614_fu_83406_p4 = mul_ln1118_1596_fu_83400_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1615_fu_83425_p4() {
    trunc_ln708_1615_fu_83425_p4 = mul_ln1118_1597_fu_83419_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1616_fu_83444_p4() {
    trunc_ln708_1616_fu_83444_p4 = mul_ln1118_1598_fu_83438_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1617_fu_83463_p4() {
    trunc_ln708_1617_fu_83463_p4 = mul_ln1118_1599_fu_83457_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1618_fu_83482_p4() {
    trunc_ln708_1618_fu_83482_p4 = mul_ln1118_1600_fu_83476_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1619_fu_83500_p4() {
    trunc_ln708_1619_fu_83500_p4 = mul_ln1118_1601_fu_83495_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_161_fu_54907_p4() {
    trunc_ln708_161_fu_54907_p4 = mul_ln1118_143_fu_54901_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1620_fu_83518_p4() {
    trunc_ln708_1620_fu_83518_p4 = mul_ln1118_1602_fu_83513_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1627_fu_84525_p4() {
    trunc_ln708_1627_fu_84525_p4 = mul_ln1118_1609_fu_84519_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1628_fu_84544_p4() {
    trunc_ln708_1628_fu_84544_p4 = mul_ln1118_1610_fu_84538_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1629_fu_84563_p4() {
    trunc_ln708_1629_fu_84563_p4 = mul_ln1118_1611_fu_84557_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_162_fu_54929_p4() {
    trunc_ln708_162_fu_54929_p4 = mul_ln1118_144_fu_54923_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1630_fu_84582_p4() {
    trunc_ln708_1630_fu_84582_p4 = mul_ln1118_1612_fu_84576_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1631_fu_84601_p4() {
    trunc_ln708_1631_fu_84601_p4 = mul_ln1118_1613_fu_84595_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1632_fu_84620_p4() {
    trunc_ln708_1632_fu_84620_p4 = mul_ln1118_1614_fu_84614_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1633_fu_84639_p4() {
    trunc_ln708_1633_fu_84639_p4 = mul_ln1118_1615_fu_84633_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1634_fu_84658_p4() {
    trunc_ln708_1634_fu_84658_p4 = mul_ln1118_1616_fu_84652_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1635_fu_84677_p4() {
    trunc_ln708_1635_fu_84677_p4 = mul_ln1118_1617_fu_84671_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1636_fu_84696_p4() {
    trunc_ln708_1636_fu_84696_p4 = mul_ln1118_1618_fu_84690_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1637_fu_84715_p4() {
    trunc_ln708_1637_fu_84715_p4 = mul_ln1118_1619_fu_84709_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1638_fu_84734_p4() {
    trunc_ln708_1638_fu_84734_p4 = mul_ln1118_1620_fu_84728_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1639_fu_84753_p4() {
    trunc_ln708_1639_fu_84753_p4 = mul_ln1118_1621_fu_84747_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_163_fu_54951_p4() {
    trunc_ln708_163_fu_54951_p4 = mul_ln1118_145_fu_54945_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1640_fu_84772_p4() {
    trunc_ln708_1640_fu_84772_p4 = mul_ln1118_1622_fu_84766_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1641_fu_84791_p4() {
    trunc_ln708_1641_fu_84791_p4 = mul_ln1118_1623_fu_84785_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1642_fu_84810_p4() {
    trunc_ln708_1642_fu_84810_p4 = mul_ln1118_1624_fu_84804_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1643_fu_84829_p4() {
    trunc_ln708_1643_fu_84829_p4 = mul_ln1118_1625_fu_84823_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1644_fu_84848_p4() {
    trunc_ln708_1644_fu_84848_p4 = mul_ln1118_1626_fu_84842_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1645_fu_84867_p4() {
    trunc_ln708_1645_fu_84867_p4 = mul_ln1118_1627_fu_84861_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_164_fu_54973_p4() {
    trunc_ln708_164_fu_54973_p4 = mul_ln1118_146_fu_54967_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1652_fu_84886_p4() {
    trunc_ln708_1652_fu_84886_p4 = mul_ln1118_1634_fu_84880_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1653_fu_84905_p4() {
    trunc_ln708_1653_fu_84905_p4 = mul_ln1118_1635_fu_84899_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1654_fu_84924_p4() {
    trunc_ln708_1654_fu_84924_p4 = mul_ln1118_1636_fu_84918_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1655_fu_84943_p4() {
    trunc_ln708_1655_fu_84943_p4 = mul_ln1118_1637_fu_84937_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1656_fu_84962_p4() {
    trunc_ln708_1656_fu_84962_p4 = mul_ln1118_1638_fu_84956_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1657_fu_84981_p4() {
    trunc_ln708_1657_fu_84981_p4 = mul_ln1118_1639_fu_84975_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1658_fu_85000_p4() {
    trunc_ln708_1658_fu_85000_p4 = mul_ln1118_1640_fu_84994_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1659_fu_85019_p4() {
    trunc_ln708_1659_fu_85019_p4 = mul_ln1118_1641_fu_85013_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_165_fu_54995_p4() {
    trunc_ln708_165_fu_54995_p4 = mul_ln1118_147_fu_54989_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1660_fu_85038_p4() {
    trunc_ln708_1660_fu_85038_p4 = mul_ln1118_1642_fu_85032_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1661_fu_85057_p4() {
    trunc_ln708_1661_fu_85057_p4 = mul_ln1118_1643_fu_85051_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1662_fu_85076_p4() {
    trunc_ln708_1662_fu_85076_p4 = mul_ln1118_1644_fu_85070_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1663_fu_85095_p4() {
    trunc_ln708_1663_fu_85095_p4 = mul_ln1118_1645_fu_85089_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1664_fu_85114_p4() {
    trunc_ln708_1664_fu_85114_p4 = mul_ln1118_1646_fu_85108_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1665_fu_85133_p4() {
    trunc_ln708_1665_fu_85133_p4 = mul_ln1118_1647_fu_85127_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1666_fu_85152_p4() {
    trunc_ln708_1666_fu_85152_p4 = mul_ln1118_1648_fu_85146_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1667_fu_85171_p4() {
    trunc_ln708_1667_fu_85171_p4 = mul_ln1118_1649_fu_85165_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1668_fu_85190_p4() {
    trunc_ln708_1668_fu_85190_p4 = mul_ln1118_1650_fu_85184_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1669_fu_85209_p4() {
    trunc_ln708_1669_fu_85209_p4 = mul_ln1118_1651_fu_85203_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_166_fu_55017_p4() {
    trunc_ln708_166_fu_55017_p4 = mul_ln1118_148_fu_55011_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1670_fu_85227_p4() {
    trunc_ln708_1670_fu_85227_p4 = mul_ln1118_1652_fu_85222_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1677_fu_85246_p4() {
    trunc_ln708_1677_fu_85246_p4 = mul_ln1118_1659_fu_85240_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1678_fu_85265_p4() {
    trunc_ln708_1678_fu_85265_p4 = mul_ln1118_1660_fu_85259_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1679_fu_85284_p4() {
    trunc_ln708_1679_fu_85284_p4 = mul_ln1118_1661_fu_85278_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_167_fu_55039_p4() {
    trunc_ln708_167_fu_55039_p4 = mul_ln1118_149_fu_55033_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1680_fu_85303_p4() {
    trunc_ln708_1680_fu_85303_p4 = mul_ln1118_1662_fu_85297_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1681_fu_85322_p4() {
    trunc_ln708_1681_fu_85322_p4 = mul_ln1118_1663_fu_85316_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1682_fu_85341_p4() {
    trunc_ln708_1682_fu_85341_p4 = mul_ln1118_1664_fu_85335_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1683_fu_85360_p4() {
    trunc_ln708_1683_fu_85360_p4 = mul_ln1118_1665_fu_85354_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1684_fu_85379_p4() {
    trunc_ln708_1684_fu_85379_p4 = mul_ln1118_1666_fu_85373_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1685_fu_85398_p4() {
    trunc_ln708_1685_fu_85398_p4 = mul_ln1118_1667_fu_85392_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1686_fu_85417_p4() {
    trunc_ln708_1686_fu_85417_p4 = mul_ln1118_1668_fu_85411_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1687_fu_85436_p4() {
    trunc_ln708_1687_fu_85436_p4 = mul_ln1118_1669_fu_85430_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1688_fu_85455_p4() {
    trunc_ln708_1688_fu_85455_p4 = mul_ln1118_1670_fu_85449_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1689_fu_85474_p4() {
    trunc_ln708_1689_fu_85474_p4 = mul_ln1118_1671_fu_85468_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_168_fu_55061_p4() {
    trunc_ln708_168_fu_55061_p4 = mul_ln1118_150_fu_55055_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1690_fu_85493_p4() {
    trunc_ln708_1690_fu_85493_p4 = mul_ln1118_1672_fu_85487_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1691_fu_85512_p4() {
    trunc_ln708_1691_fu_85512_p4 = mul_ln1118_1673_fu_85506_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1692_fu_85531_p4() {
    trunc_ln708_1692_fu_85531_p4 = mul_ln1118_1674_fu_85525_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1693_fu_85550_p4() {
    trunc_ln708_1693_fu_85550_p4 = mul_ln1118_1675_fu_85544_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1694_fu_85569_p4() {
    trunc_ln708_1694_fu_85569_p4 = mul_ln1118_1676_fu_85563_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1695_fu_85587_p4() {
    trunc_ln708_1695_fu_85587_p4 = mul_ln1118_1677_fu_85582_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_169_fu_55079_p4() {
    trunc_ln708_169_fu_55079_p4 = mul_ln1118_151_fu_55074_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1702_fu_85606_p4() {
    trunc_ln708_1702_fu_85606_p4 = mul_ln1118_1684_fu_85600_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1703_fu_85625_p4() {
    trunc_ln708_1703_fu_85625_p4 = mul_ln1118_1685_fu_85619_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1704_fu_85644_p4() {
    trunc_ln708_1704_fu_85644_p4 = mul_ln1118_1686_fu_85638_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1705_fu_85663_p4() {
    trunc_ln708_1705_fu_85663_p4 = mul_ln1118_1687_fu_85657_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1706_fu_85682_p4() {
    trunc_ln708_1706_fu_85682_p4 = mul_ln1118_1688_fu_85676_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1707_fu_85701_p4() {
    trunc_ln708_1707_fu_85701_p4 = mul_ln1118_1689_fu_85695_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1708_fu_85720_p4() {
    trunc_ln708_1708_fu_85720_p4 = mul_ln1118_1690_fu_85714_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1709_fu_85739_p4() {
    trunc_ln708_1709_fu_85739_p4 = mul_ln1118_1691_fu_85733_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_170_fu_55097_p4() {
    trunc_ln708_170_fu_55097_p4 = mul_ln1118_152_fu_55092_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1710_fu_85758_p4() {
    trunc_ln708_1710_fu_85758_p4 = mul_ln1118_1692_fu_85752_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1711_fu_85777_p4() {
    trunc_ln708_1711_fu_85777_p4 = mul_ln1118_1693_fu_85771_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1712_fu_85796_p4() {
    trunc_ln708_1712_fu_85796_p4 = mul_ln1118_1694_fu_85790_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1713_fu_85815_p4() {
    trunc_ln708_1713_fu_85815_p4 = mul_ln1118_1695_fu_85809_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1714_fu_85834_p4() {
    trunc_ln708_1714_fu_85834_p4 = mul_ln1118_1696_fu_85828_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1715_fu_85853_p4() {
    trunc_ln708_1715_fu_85853_p4 = mul_ln1118_1697_fu_85847_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1716_fu_85872_p4() {
    trunc_ln708_1716_fu_85872_p4 = mul_ln1118_1698_fu_85866_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1717_fu_85891_p4() {
    trunc_ln708_1717_fu_85891_p4 = mul_ln1118_1699_fu_85885_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1718_fu_85910_p4() {
    trunc_ln708_1718_fu_85910_p4 = mul_ln1118_1700_fu_85904_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1719_fu_85929_p4() {
    trunc_ln708_1719_fu_85929_p4 = mul_ln1118_1701_fu_85923_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1720_fu_85947_p4() {
    trunc_ln708_1720_fu_85947_p4 = mul_ln1118_1702_fu_85942_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1727_fu_85966_p4() {
    trunc_ln708_1727_fu_85966_p4 = mul_ln1118_1709_fu_85960_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1728_fu_85985_p4() {
    trunc_ln708_1728_fu_85985_p4 = mul_ln1118_1710_fu_85979_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1729_fu_86004_p4() {
    trunc_ln708_1729_fu_86004_p4 = mul_ln1118_1711_fu_85998_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1730_fu_86023_p4() {
    trunc_ln708_1730_fu_86023_p4 = mul_ln1118_1712_fu_86017_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1731_fu_86042_p4() {
    trunc_ln708_1731_fu_86042_p4 = mul_ln1118_1713_fu_86036_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1732_fu_86061_p4() {
    trunc_ln708_1732_fu_86061_p4 = mul_ln1118_1714_fu_86055_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1733_fu_86080_p4() {
    trunc_ln708_1733_fu_86080_p4 = mul_ln1118_1715_fu_86074_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1734_fu_86099_p4() {
    trunc_ln708_1734_fu_86099_p4 = mul_ln1118_1716_fu_86093_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1735_fu_86118_p4() {
    trunc_ln708_1735_fu_86118_p4 = mul_ln1118_1717_fu_86112_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1736_fu_86137_p4() {
    trunc_ln708_1736_fu_86137_p4 = mul_ln1118_1718_fu_86131_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1737_fu_86156_p4() {
    trunc_ln708_1737_fu_86156_p4 = mul_ln1118_1719_fu_86150_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1738_fu_86175_p4() {
    trunc_ln708_1738_fu_86175_p4 = mul_ln1118_1720_fu_86169_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1739_fu_86194_p4() {
    trunc_ln708_1739_fu_86194_p4 = mul_ln1118_1721_fu_86188_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1740_fu_86213_p4() {
    trunc_ln708_1740_fu_86213_p4 = mul_ln1118_1722_fu_86207_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1741_fu_86232_p4() {
    trunc_ln708_1741_fu_86232_p4 = mul_ln1118_1723_fu_86226_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1742_fu_86251_p4() {
    trunc_ln708_1742_fu_86251_p4 = mul_ln1118_1724_fu_86245_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1743_fu_86270_p4() {
    trunc_ln708_1743_fu_86270_p4 = mul_ln1118_1725_fu_86264_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1744_fu_86289_p4() {
    trunc_ln708_1744_fu_86289_p4 = mul_ln1118_1726_fu_86283_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1745_fu_86308_p4() {
    trunc_ln708_1745_fu_86308_p4 = mul_ln1118_1727_fu_86302_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1746_fu_86327_p4() {
    trunc_ln708_1746_fu_86327_p4 = mul_ln1118_1728_fu_86321_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1747_fu_86346_p4() {
    trunc_ln708_1747_fu_86346_p4 = mul_ln1118_1729_fu_86340_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1748_fu_86365_p4() {
    trunc_ln708_1748_fu_86365_p4 = mul_ln1118_1730_fu_86359_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1749_fu_86384_p4() {
    trunc_ln708_1749_fu_86384_p4 = mul_ln1118_1731_fu_86378_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1752_fu_86403_p4() {
    trunc_ln708_1752_fu_86403_p4 = mul_ln1118_1734_fu_86397_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1753_fu_86422_p4() {
    trunc_ln708_1753_fu_86422_p4 = mul_ln1118_1735_fu_86416_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1754_fu_86441_p4() {
    trunc_ln708_1754_fu_86441_p4 = mul_ln1118_1736_fu_86435_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1755_fu_86460_p4() {
    trunc_ln708_1755_fu_86460_p4 = mul_ln1118_1737_fu_86454_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1756_fu_86479_p4() {
    trunc_ln708_1756_fu_86479_p4 = mul_ln1118_1738_fu_86473_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1757_fu_86498_p4() {
    trunc_ln708_1757_fu_86498_p4 = mul_ln1118_1739_fu_86492_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1758_fu_86517_p4() {
    trunc_ln708_1758_fu_86517_p4 = mul_ln1118_1740_fu_86511_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1759_fu_86536_p4() {
    trunc_ln708_1759_fu_86536_p4 = mul_ln1118_1741_fu_86530_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1760_fu_86555_p4() {
    trunc_ln708_1760_fu_86555_p4 = mul_ln1118_1742_fu_86549_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1761_fu_86574_p4() {
    trunc_ln708_1761_fu_86574_p4 = mul_ln1118_1743_fu_86568_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1762_fu_86593_p4() {
    trunc_ln708_1762_fu_86593_p4 = mul_ln1118_1744_fu_86587_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1763_fu_86612_p4() {
    trunc_ln708_1763_fu_86612_p4 = mul_ln1118_1745_fu_86606_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1764_fu_86631_p4() {
    trunc_ln708_1764_fu_86631_p4 = mul_ln1118_1746_fu_86625_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1765_fu_86650_p4() {
    trunc_ln708_1765_fu_86650_p4 = mul_ln1118_1747_fu_86644_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1766_fu_86669_p4() {
    trunc_ln708_1766_fu_86669_p4 = mul_ln1118_1748_fu_86663_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1767_fu_86688_p4() {
    trunc_ln708_1767_fu_86688_p4 = mul_ln1118_1749_fu_86682_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1768_fu_86707_p4() {
    trunc_ln708_1768_fu_86707_p4 = mul_ln1118_1750_fu_86701_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1769_fu_86725_p4() {
    trunc_ln708_1769_fu_86725_p4 = mul_ln1118_1751_fu_86720_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1770_fu_86743_p4() {
    trunc_ln708_1770_fu_86743_p4 = mul_ln1118_1752_fu_86738_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1777_fu_86762_p4() {
    trunc_ln708_1777_fu_86762_p4 = mul_ln1118_1759_fu_86756_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1778_fu_86781_p4() {
    trunc_ln708_1778_fu_86781_p4 = mul_ln1118_1760_fu_86775_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1779_fu_86800_p4() {
    trunc_ln708_1779_fu_86800_p4 = mul_ln1118_1761_fu_86794_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_177_fu_55119_p4() {
    trunc_ln708_177_fu_55119_p4 = mul_ln1118_159_fu_55113_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1780_fu_86819_p4() {
    trunc_ln708_1780_fu_86819_p4 = mul_ln1118_1762_fu_86813_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1781_fu_86838_p4() {
    trunc_ln708_1781_fu_86838_p4 = mul_ln1118_1763_fu_86832_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1782_fu_86857_p4() {
    trunc_ln708_1782_fu_86857_p4 = mul_ln1118_1764_fu_86851_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1783_fu_86876_p4() {
    trunc_ln708_1783_fu_86876_p4 = mul_ln1118_1765_fu_86870_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1784_fu_86895_p4() {
    trunc_ln708_1784_fu_86895_p4 = mul_ln1118_1766_fu_86889_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1785_fu_86914_p4() {
    trunc_ln708_1785_fu_86914_p4 = mul_ln1118_1767_fu_86908_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1786_fu_86933_p4() {
    trunc_ln708_1786_fu_86933_p4 = mul_ln1118_1768_fu_86927_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1787_fu_86952_p4() {
    trunc_ln708_1787_fu_86952_p4 = mul_ln1118_1769_fu_86946_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1788_fu_86971_p4() {
    trunc_ln708_1788_fu_86971_p4 = mul_ln1118_1770_fu_86965_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1789_fu_86990_p4() {
    trunc_ln708_1789_fu_86990_p4 = mul_ln1118_1771_fu_86984_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_178_fu_55141_p4() {
    trunc_ln708_178_fu_55141_p4 = mul_ln1118_160_fu_55135_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1790_fu_87009_p4() {
    trunc_ln708_1790_fu_87009_p4 = mul_ln1118_1772_fu_87003_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1791_fu_87028_p4() {
    trunc_ln708_1791_fu_87028_p4 = mul_ln1118_1773_fu_87022_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1792_fu_87047_p4() {
    trunc_ln708_1792_fu_87047_p4 = mul_ln1118_1774_fu_87041_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1793_fu_87066_p4() {
    trunc_ln708_1793_fu_87066_p4 = mul_ln1118_1775_fu_87060_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1794_fu_87084_p4() {
    trunc_ln708_1794_fu_87084_p4 = mul_ln1118_1776_fu_87079_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1795_fu_87102_p4() {
    trunc_ln708_1795_fu_87102_p4 = mul_ln1118_1777_fu_87097_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_179_fu_55163_p4() {
    trunc_ln708_179_fu_55163_p4 = mul_ln1118_161_fu_55157_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1802_fu_87121_p4() {
    trunc_ln708_1802_fu_87121_p4 = mul_ln1118_1784_fu_87115_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1803_fu_87140_p4() {
    trunc_ln708_1803_fu_87140_p4 = mul_ln1118_1785_fu_87134_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1804_fu_87159_p4() {
    trunc_ln708_1804_fu_87159_p4 = mul_ln1118_1786_fu_87153_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1805_fu_87178_p4() {
    trunc_ln708_1805_fu_87178_p4 = mul_ln1118_1787_fu_87172_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1806_fu_87197_p4() {
    trunc_ln708_1806_fu_87197_p4 = mul_ln1118_1788_fu_87191_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1807_fu_87216_p4() {
    trunc_ln708_1807_fu_87216_p4 = mul_ln1118_1789_fu_87210_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1808_fu_87235_p4() {
    trunc_ln708_1808_fu_87235_p4 = mul_ln1118_1790_fu_87229_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1809_fu_87254_p4() {
    trunc_ln708_1809_fu_87254_p4 = mul_ln1118_1791_fu_87248_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_180_fu_55185_p4() {
    trunc_ln708_180_fu_55185_p4 = mul_ln1118_162_fu_55179_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1810_fu_87273_p4() {
    trunc_ln708_1810_fu_87273_p4 = mul_ln1118_1792_fu_87267_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1811_fu_87292_p4() {
    trunc_ln708_1811_fu_87292_p4 = mul_ln1118_1793_fu_87286_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1812_fu_87311_p4() {
    trunc_ln708_1812_fu_87311_p4 = mul_ln1118_1794_fu_87305_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1813_fu_87330_p4() {
    trunc_ln708_1813_fu_87330_p4 = mul_ln1118_1795_fu_87324_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1814_fu_87349_p4() {
    trunc_ln708_1814_fu_87349_p4 = mul_ln1118_1796_fu_87343_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1815_fu_87368_p4() {
    trunc_ln708_1815_fu_87368_p4 = mul_ln1118_1797_fu_87362_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1816_fu_87387_p4() {
    trunc_ln708_1816_fu_87387_p4 = mul_ln1118_1798_fu_87381_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1817_fu_87406_p4() {
    trunc_ln708_1817_fu_87406_p4 = mul_ln1118_1799_fu_87400_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1818_fu_87425_p4() {
    trunc_ln708_1818_fu_87425_p4 = mul_ln1118_1800_fu_87419_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1819_fu_87443_p4() {
    trunc_ln708_1819_fu_87443_p4 = mul_ln1118_1801_fu_87438_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_181_fu_55207_p4() {
    trunc_ln708_181_fu_55207_p4 = mul_ln1118_163_fu_55201_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1820_fu_87461_p4() {
    trunc_ln708_1820_fu_87461_p4 = mul_ln1118_1802_fu_87456_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1827_fu_88468_p4() {
    trunc_ln708_1827_fu_88468_p4 = mul_ln1118_1809_fu_88462_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1828_fu_88487_p4() {
    trunc_ln708_1828_fu_88487_p4 = mul_ln1118_1810_fu_88481_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1829_fu_88506_p4() {
    trunc_ln708_1829_fu_88506_p4 = mul_ln1118_1811_fu_88500_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_182_fu_55229_p4() {
    trunc_ln708_182_fu_55229_p4 = mul_ln1118_164_fu_55223_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1830_fu_88525_p4() {
    trunc_ln708_1830_fu_88525_p4 = mul_ln1118_1812_fu_88519_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1831_fu_88544_p4() {
    trunc_ln708_1831_fu_88544_p4 = mul_ln1118_1813_fu_88538_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1832_fu_88563_p4() {
    trunc_ln708_1832_fu_88563_p4 = mul_ln1118_1814_fu_88557_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1833_fu_88582_p4() {
    trunc_ln708_1833_fu_88582_p4 = mul_ln1118_1815_fu_88576_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1834_fu_88601_p4() {
    trunc_ln708_1834_fu_88601_p4 = mul_ln1118_1816_fu_88595_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1835_fu_88620_p4() {
    trunc_ln708_1835_fu_88620_p4 = mul_ln1118_1817_fu_88614_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1836_fu_88639_p4() {
    trunc_ln708_1836_fu_88639_p4 = mul_ln1118_1818_fu_88633_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1837_fu_88658_p4() {
    trunc_ln708_1837_fu_88658_p4 = mul_ln1118_1819_fu_88652_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1838_fu_88677_p4() {
    trunc_ln708_1838_fu_88677_p4 = mul_ln1118_1820_fu_88671_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1839_fu_88696_p4() {
    trunc_ln708_1839_fu_88696_p4 = mul_ln1118_1821_fu_88690_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_183_fu_55251_p4() {
    trunc_ln708_183_fu_55251_p4 = mul_ln1118_165_fu_55245_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1840_fu_88715_p4() {
    trunc_ln708_1840_fu_88715_p4 = mul_ln1118_1822_fu_88709_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1841_fu_88734_p4() {
    trunc_ln708_1841_fu_88734_p4 = mul_ln1118_1823_fu_88728_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1842_fu_88753_p4() {
    trunc_ln708_1842_fu_88753_p4 = mul_ln1118_1824_fu_88747_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1843_fu_88772_p4() {
    trunc_ln708_1843_fu_88772_p4 = mul_ln1118_1825_fu_88766_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1844_fu_88791_p4() {
    trunc_ln708_1844_fu_88791_p4 = mul_ln1118_1826_fu_88785_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1845_fu_88810_p4() {
    trunc_ln708_1845_fu_88810_p4 = mul_ln1118_1827_fu_88804_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_184_fu_55273_p4() {
    trunc_ln708_184_fu_55273_p4 = mul_ln1118_166_fu_55267_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1852_fu_88829_p4() {
    trunc_ln708_1852_fu_88829_p4 = mul_ln1118_1834_fu_88823_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1853_fu_88848_p4() {
    trunc_ln708_1853_fu_88848_p4 = mul_ln1118_1835_fu_88842_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1854_fu_88867_p4() {
    trunc_ln708_1854_fu_88867_p4 = mul_ln1118_1836_fu_88861_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1855_fu_88886_p4() {
    trunc_ln708_1855_fu_88886_p4 = mul_ln1118_1837_fu_88880_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1856_fu_88905_p4() {
    trunc_ln708_1856_fu_88905_p4 = mul_ln1118_1838_fu_88899_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1857_fu_88924_p4() {
    trunc_ln708_1857_fu_88924_p4 = mul_ln1118_1839_fu_88918_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1858_fu_88943_p4() {
    trunc_ln708_1858_fu_88943_p4 = mul_ln1118_1840_fu_88937_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1859_fu_88962_p4() {
    trunc_ln708_1859_fu_88962_p4 = mul_ln1118_1841_fu_88956_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_185_fu_55295_p4() {
    trunc_ln708_185_fu_55295_p4 = mul_ln1118_167_fu_55289_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1860_fu_88981_p4() {
    trunc_ln708_1860_fu_88981_p4 = mul_ln1118_1842_fu_88975_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1861_fu_89000_p4() {
    trunc_ln708_1861_fu_89000_p4 = mul_ln1118_1843_fu_88994_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1862_fu_89019_p4() {
    trunc_ln708_1862_fu_89019_p4 = mul_ln1118_1844_fu_89013_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1863_fu_89038_p4() {
    trunc_ln708_1863_fu_89038_p4 = mul_ln1118_1845_fu_89032_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1864_fu_89057_p4() {
    trunc_ln708_1864_fu_89057_p4 = mul_ln1118_1846_fu_89051_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1865_fu_89076_p4() {
    trunc_ln708_1865_fu_89076_p4 = mul_ln1118_1847_fu_89070_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1866_fu_89095_p4() {
    trunc_ln708_1866_fu_89095_p4 = mul_ln1118_1848_fu_89089_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1867_fu_89114_p4() {
    trunc_ln708_1867_fu_89114_p4 = mul_ln1118_1849_fu_89108_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1868_fu_89133_p4() {
    trunc_ln708_1868_fu_89133_p4 = mul_ln1118_1850_fu_89127_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1869_fu_89152_p4() {
    trunc_ln708_1869_fu_89152_p4 = mul_ln1118_1851_fu_89146_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_186_fu_55317_p4() {
    trunc_ln708_186_fu_55317_p4 = mul_ln1118_168_fu_55311_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1877_fu_89171_p4() {
    trunc_ln708_1877_fu_89171_p4 = mul_ln1118_1859_fu_89165_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1878_fu_89190_p4() {
    trunc_ln708_1878_fu_89190_p4 = mul_ln1118_1860_fu_89184_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1879_fu_89209_p4() {
    trunc_ln708_1879_fu_89209_p4 = mul_ln1118_1861_fu_89203_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_187_fu_55339_p4() {
    trunc_ln708_187_fu_55339_p4 = mul_ln1118_169_fu_55333_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1880_fu_89228_p4() {
    trunc_ln708_1880_fu_89228_p4 = mul_ln1118_1862_fu_89222_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1881_fu_89247_p4() {
    trunc_ln708_1881_fu_89247_p4 = mul_ln1118_1863_fu_89241_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1882_fu_89266_p4() {
    trunc_ln708_1882_fu_89266_p4 = mul_ln1118_1864_fu_89260_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1883_fu_89285_p4() {
    trunc_ln708_1883_fu_89285_p4 = mul_ln1118_1865_fu_89279_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1884_fu_89304_p4() {
    trunc_ln708_1884_fu_89304_p4 = mul_ln1118_1866_fu_89298_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1885_fu_89323_p4() {
    trunc_ln708_1885_fu_89323_p4 = mul_ln1118_1867_fu_89317_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1886_fu_89342_p4() {
    trunc_ln708_1886_fu_89342_p4 = mul_ln1118_1868_fu_89336_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1887_fu_89361_p4() {
    trunc_ln708_1887_fu_89361_p4 = mul_ln1118_1869_fu_89355_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1888_fu_89380_p4() {
    trunc_ln708_1888_fu_89380_p4 = mul_ln1118_1870_fu_89374_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1889_fu_89399_p4() {
    trunc_ln708_1889_fu_89399_p4 = mul_ln1118_1871_fu_89393_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_188_fu_55361_p4() {
    trunc_ln708_188_fu_55361_p4 = mul_ln1118_170_fu_55355_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1890_fu_89418_p4() {
    trunc_ln708_1890_fu_89418_p4 = mul_ln1118_1872_fu_89412_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1891_fu_89437_p4() {
    trunc_ln708_1891_fu_89437_p4 = mul_ln1118_1873_fu_89431_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1892_fu_89456_p4() {
    trunc_ln708_1892_fu_89456_p4 = mul_ln1118_1874_fu_89450_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1893_fu_89475_p4() {
    trunc_ln708_1893_fu_89475_p4 = mul_ln1118_1875_fu_89469_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1894_fu_89494_p4() {
    trunc_ln708_1894_fu_89494_p4 = mul_ln1118_1876_fu_89488_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_189_fu_55383_p4() {
    trunc_ln708_189_fu_55383_p4 = mul_ln1118_171_fu_55377_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1902_fu_89513_p4() {
    trunc_ln708_1902_fu_89513_p4 = mul_ln1118_1884_fu_89507_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1903_fu_89532_p4() {
    trunc_ln708_1903_fu_89532_p4 = mul_ln1118_1885_fu_89526_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1904_fu_89551_p4() {
    trunc_ln708_1904_fu_89551_p4 = mul_ln1118_1886_fu_89545_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1905_fu_89570_p4() {
    trunc_ln708_1905_fu_89570_p4 = mul_ln1118_1887_fu_89564_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1906_fu_89589_p4() {
    trunc_ln708_1906_fu_89589_p4 = mul_ln1118_1888_fu_89583_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1907_fu_89608_p4() {
    trunc_ln708_1907_fu_89608_p4 = mul_ln1118_1889_fu_89602_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1908_fu_89627_p4() {
    trunc_ln708_1908_fu_89627_p4 = mul_ln1118_1890_fu_89621_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1909_fu_89646_p4() {
    trunc_ln708_1909_fu_89646_p4 = mul_ln1118_1891_fu_89640_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_190_fu_55405_p4() {
    trunc_ln708_190_fu_55405_p4 = mul_ln1118_172_fu_55399_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1910_fu_89665_p4() {
    trunc_ln708_1910_fu_89665_p4 = mul_ln1118_1892_fu_89659_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1911_fu_89684_p4() {
    trunc_ln708_1911_fu_89684_p4 = mul_ln1118_1893_fu_89678_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1912_fu_89703_p4() {
    trunc_ln708_1912_fu_89703_p4 = mul_ln1118_1894_fu_89697_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1913_fu_89722_p4() {
    trunc_ln708_1913_fu_89722_p4 = mul_ln1118_1895_fu_89716_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1914_fu_89741_p4() {
    trunc_ln708_1914_fu_89741_p4 = mul_ln1118_1896_fu_89735_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1915_fu_89760_p4() {
    trunc_ln708_1915_fu_89760_p4 = mul_ln1118_1897_fu_89754_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1916_fu_89779_p4() {
    trunc_ln708_1916_fu_89779_p4 = mul_ln1118_1898_fu_89773_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1917_fu_89798_p4() {
    trunc_ln708_1917_fu_89798_p4 = mul_ln1118_1899_fu_89792_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1918_fu_89817_p4() {
    trunc_ln708_1918_fu_89817_p4 = mul_ln1118_1900_fu_89811_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1919_fu_89836_p4() {
    trunc_ln708_1919_fu_89836_p4 = mul_ln1118_1901_fu_89830_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_191_fu_55427_p4() {
    trunc_ln708_191_fu_55427_p4 = mul_ln1118_173_fu_55421_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1927_fu_89855_p4() {
    trunc_ln708_1927_fu_89855_p4 = mul_ln1118_1909_fu_89849_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1928_fu_89874_p4() {
    trunc_ln708_1928_fu_89874_p4 = mul_ln1118_1910_fu_89868_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1929_fu_89893_p4() {
    trunc_ln708_1929_fu_89893_p4 = mul_ln1118_1911_fu_89887_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_192_fu_55449_p4() {
    trunc_ln708_192_fu_55449_p4 = mul_ln1118_174_fu_55443_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1930_fu_89912_p4() {
    trunc_ln708_1930_fu_89912_p4 = mul_ln1118_1912_fu_89906_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1931_fu_89931_p4() {
    trunc_ln708_1931_fu_89931_p4 = mul_ln1118_1913_fu_89925_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1932_fu_89950_p4() {
    trunc_ln708_1932_fu_89950_p4 = mul_ln1118_1914_fu_89944_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1933_fu_89969_p4() {
    trunc_ln708_1933_fu_89969_p4 = mul_ln1118_1915_fu_89963_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1934_fu_89988_p4() {
    trunc_ln708_1934_fu_89988_p4 = mul_ln1118_1916_fu_89982_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1935_fu_90007_p4() {
    trunc_ln708_1935_fu_90007_p4 = mul_ln1118_1917_fu_90001_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1936_fu_90026_p4() {
    trunc_ln708_1936_fu_90026_p4 = mul_ln1118_1918_fu_90020_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1937_fu_90045_p4() {
    trunc_ln708_1937_fu_90045_p4 = mul_ln1118_1919_fu_90039_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1938_fu_90064_p4() {
    trunc_ln708_1938_fu_90064_p4 = mul_ln1118_1920_fu_90058_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1939_fu_90083_p4() {
    trunc_ln708_1939_fu_90083_p4 = mul_ln1118_1921_fu_90077_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_193_fu_55471_p4() {
    trunc_ln708_193_fu_55471_p4 = mul_ln1118_175_fu_55465_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1940_fu_90102_p4() {
    trunc_ln708_1940_fu_90102_p4 = mul_ln1118_1922_fu_90096_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1941_fu_90121_p4() {
    trunc_ln708_1941_fu_90121_p4 = mul_ln1118_1923_fu_90115_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1942_fu_90140_p4() {
    trunc_ln708_1942_fu_90140_p4 = mul_ln1118_1924_fu_90134_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1943_fu_90159_p4() {
    trunc_ln708_1943_fu_90159_p4 = mul_ln1118_1925_fu_90153_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1944_fu_90178_p4() {
    trunc_ln708_1944_fu_90178_p4 = mul_ln1118_1926_fu_90172_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1945_fu_90197_p4() {
    trunc_ln708_1945_fu_90197_p4 = mul_ln1118_1927_fu_90191_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1946_fu_90216_p4() {
    trunc_ln708_1946_fu_90216_p4 = mul_ln1118_1928_fu_90210_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1947_fu_90235_p4() {
    trunc_ln708_1947_fu_90235_p4 = mul_ln1118_1929_fu_90229_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1948_fu_90254_p4() {
    trunc_ln708_1948_fu_90254_p4 = mul_ln1118_1930_fu_90248_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1949_fu_90273_p4() {
    trunc_ln708_1949_fu_90273_p4 = mul_ln1118_1931_fu_90267_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_194_fu_55489_p4() {
    trunc_ln708_194_fu_55489_p4 = mul_ln1118_176_fu_55484_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1952_fu_90292_p4() {
    trunc_ln708_1952_fu_90292_p4 = mul_ln1118_1934_fu_90286_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1953_fu_90311_p4() {
    trunc_ln708_1953_fu_90311_p4 = mul_ln1118_1935_fu_90305_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1954_fu_90330_p4() {
    trunc_ln708_1954_fu_90330_p4 = mul_ln1118_1936_fu_90324_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1955_fu_90349_p4() {
    trunc_ln708_1955_fu_90349_p4 = mul_ln1118_1937_fu_90343_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1956_fu_90368_p4() {
    trunc_ln708_1956_fu_90368_p4 = mul_ln1118_1938_fu_90362_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1957_fu_90387_p4() {
    trunc_ln708_1957_fu_90387_p4 = mul_ln1118_1939_fu_90381_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1958_fu_90406_p4() {
    trunc_ln708_1958_fu_90406_p4 = mul_ln1118_1940_fu_90400_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1959_fu_90425_p4() {
    trunc_ln708_1959_fu_90425_p4 = mul_ln1118_1941_fu_90419_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_195_fu_55507_p4() {
    trunc_ln708_195_fu_55507_p4 = mul_ln1118_177_fu_55502_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1960_fu_90444_p4() {
    trunc_ln708_1960_fu_90444_p4 = mul_ln1118_1942_fu_90438_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1961_fu_90463_p4() {
    trunc_ln708_1961_fu_90463_p4 = mul_ln1118_1943_fu_90457_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1962_fu_90482_p4() {
    trunc_ln708_1962_fu_90482_p4 = mul_ln1118_1944_fu_90476_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1963_fu_90501_p4() {
    trunc_ln708_1963_fu_90501_p4 = mul_ln1118_1945_fu_90495_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1964_fu_90520_p4() {
    trunc_ln708_1964_fu_90520_p4 = mul_ln1118_1946_fu_90514_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1965_fu_90539_p4() {
    trunc_ln708_1965_fu_90539_p4 = mul_ln1118_1947_fu_90533_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1966_fu_90558_p4() {
    trunc_ln708_1966_fu_90558_p4 = mul_ln1118_1948_fu_90552_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1967_fu_90577_p4() {
    trunc_ln708_1967_fu_90577_p4 = mul_ln1118_1949_fu_90571_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1968_fu_90596_p4() {
    trunc_ln708_1968_fu_90596_p4 = mul_ln1118_1950_fu_90590_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1977_fu_90615_p4() {
    trunc_ln708_1977_fu_90615_p4 = mul_ln1118_1959_fu_90609_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1978_fu_90634_p4() {
    trunc_ln708_1978_fu_90634_p4 = mul_ln1118_1960_fu_90628_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1979_fu_90653_p4() {
    trunc_ln708_1979_fu_90653_p4 = mul_ln1118_1961_fu_90647_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1980_fu_90672_p4() {
    trunc_ln708_1980_fu_90672_p4 = mul_ln1118_1962_fu_90666_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1981_fu_90691_p4() {
    trunc_ln708_1981_fu_90691_p4 = mul_ln1118_1963_fu_90685_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1982_fu_90710_p4() {
    trunc_ln708_1982_fu_90710_p4 = mul_ln1118_1964_fu_90704_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1983_fu_90729_p4() {
    trunc_ln708_1983_fu_90729_p4 = mul_ln1118_1965_fu_90723_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1984_fu_90748_p4() {
    trunc_ln708_1984_fu_90748_p4 = mul_ln1118_1966_fu_90742_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1985_fu_90767_p4() {
    trunc_ln708_1985_fu_90767_p4 = mul_ln1118_1967_fu_90761_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1986_fu_90786_p4() {
    trunc_ln708_1986_fu_90786_p4 = mul_ln1118_1968_fu_90780_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1987_fu_90805_p4() {
    trunc_ln708_1987_fu_90805_p4 = mul_ln1118_1969_fu_90799_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1988_fu_90824_p4() {
    trunc_ln708_1988_fu_90824_p4 = mul_ln1118_1970_fu_90818_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1989_fu_90843_p4() {
    trunc_ln708_1989_fu_90843_p4 = mul_ln1118_1971_fu_90837_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1990_fu_90862_p4() {
    trunc_ln708_1990_fu_90862_p4 = mul_ln1118_1972_fu_90856_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1991_fu_90881_p4() {
    trunc_ln708_1991_fu_90881_p4 = mul_ln1118_1973_fu_90875_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1992_fu_90900_p4() {
    trunc_ln708_1992_fu_90900_p4 = mul_ln1118_1974_fu_90894_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_1993_fu_90919_p4() {
    trunc_ln708_1993_fu_90919_p4 = mul_ln1118_1975_fu_90913_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_2002_fu_90938_p4() {
    trunc_ln708_2002_fu_90938_p4 = mul_ln1118_1984_fu_90932_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_2003_fu_90957_p4() {
    trunc_ln708_2003_fu_90957_p4 = mul_ln1118_1985_fu_90951_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_2004_fu_90976_p4() {
    trunc_ln708_2004_fu_90976_p4 = mul_ln1118_1986_fu_90970_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_2005_fu_90995_p4() {
    trunc_ln708_2005_fu_90995_p4 = mul_ln1118_1987_fu_90989_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_2006_fu_91014_p4() {
    trunc_ln708_2006_fu_91014_p4 = mul_ln1118_1988_fu_91008_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_2007_fu_91033_p4() {
    trunc_ln708_2007_fu_91033_p4 = mul_ln1118_1989_fu_91027_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_2008_fu_91052_p4() {
    trunc_ln708_2008_fu_91052_p4 = mul_ln1118_1990_fu_91046_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_2009_fu_91071_p4() {
    trunc_ln708_2009_fu_91071_p4 = mul_ln1118_1991_fu_91065_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_2010_fu_91090_p4() {
    trunc_ln708_2010_fu_91090_p4 = mul_ln1118_1992_fu_91084_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_2011_fu_91109_p4() {
    trunc_ln708_2011_fu_91109_p4 = mul_ln1118_1993_fu_91103_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_2012_fu_91128_p4() {
    trunc_ln708_2012_fu_91128_p4 = mul_ln1118_1994_fu_91122_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_2013_fu_91147_p4() {
    trunc_ln708_2013_fu_91147_p4 = mul_ln1118_1995_fu_91141_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_2014_fu_91166_p4() {
    trunc_ln708_2014_fu_91166_p4 = mul_ln1118_1996_fu_91160_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_2015_fu_91185_p4() {
    trunc_ln708_2015_fu_91185_p4 = mul_ln1118_1997_fu_91179_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_2016_fu_91204_p4() {
    trunc_ln708_2016_fu_91204_p4 = mul_ln1118_1998_fu_91198_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_2017_fu_91223_p4() {
    trunc_ln708_2017_fu_91223_p4 = mul_ln1118_1999_fu_91217_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_2018_fu_91242_p4() {
    trunc_ln708_2018_fu_91242_p4 = mul_ln1118_2000_fu_91236_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_2023_fu_91252_p4() {
    trunc_ln708_2023_fu_91252_p4 = mul_ln1118_2005_reg_106582.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_2024_fu_91281_p4() {
    trunc_ln708_2024_fu_91281_p4 = and_ln1118_fu_91276_p2.read().range(11, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_202_fu_55529_p4() {
    trunc_ln708_202_fu_55529_p4 = mul_ln1118_184_fu_55523_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_203_fu_55551_p4() {
    trunc_ln708_203_fu_55551_p4 = mul_ln1118_185_fu_55545_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_204_fu_55573_p4() {
    trunc_ln708_204_fu_55573_p4 = mul_ln1118_186_fu_55567_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_205_fu_55595_p4() {
    trunc_ln708_205_fu_55595_p4 = mul_ln1118_187_fu_55589_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_206_fu_55617_p4() {
    trunc_ln708_206_fu_55617_p4 = mul_ln1118_188_fu_55611_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_207_fu_55639_p4() {
    trunc_ln708_207_fu_55639_p4 = mul_ln1118_189_fu_55633_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_208_fu_55661_p4() {
    trunc_ln708_208_fu_55661_p4 = mul_ln1118_190_fu_55655_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_209_fu_55683_p4() {
    trunc_ln708_209_fu_55683_p4 = mul_ln1118_191_fu_55677_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_210_fu_55705_p4() {
    trunc_ln708_210_fu_55705_p4 = mul_ln1118_192_fu_55699_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_211_fu_55727_p4() {
    trunc_ln708_211_fu_55727_p4 = mul_ln1118_193_fu_55721_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_212_fu_55749_p4() {
    trunc_ln708_212_fu_55749_p4 = mul_ln1118_194_fu_55743_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_213_fu_55771_p4() {
    trunc_ln708_213_fu_55771_p4 = mul_ln1118_195_fu_55765_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_214_fu_55793_p4() {
    trunc_ln708_214_fu_55793_p4 = mul_ln1118_196_fu_55787_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_215_fu_55815_p4() {
    trunc_ln708_215_fu_55815_p4 = mul_ln1118_197_fu_55809_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_216_fu_55837_p4() {
    trunc_ln708_216_fu_55837_p4 = mul_ln1118_198_fu_55831_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_217_fu_55859_p4() {
    trunc_ln708_217_fu_55859_p4 = mul_ln1118_199_fu_55853_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_218_fu_55881_p4() {
    trunc_ln708_218_fu_55881_p4 = mul_ln1118_200_fu_55875_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_219_fu_55899_p4() {
    trunc_ln708_219_fu_55899_p4 = mul_ln1118_201_fu_55894_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_220_fu_55917_p4() {
    trunc_ln708_220_fu_55917_p4 = mul_ln1118_202_fu_55912_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_227_fu_56924_p4() {
    trunc_ln708_227_fu_56924_p4 = mul_ln1118_209_fu_56918_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_228_fu_56943_p4() {
    trunc_ln708_228_fu_56943_p4 = mul_ln1118_210_fu_56937_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_229_fu_56962_p4() {
    trunc_ln708_229_fu_56962_p4 = mul_ln1118_211_fu_56956_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_230_fu_56981_p4() {
    trunc_ln708_230_fu_56981_p4 = mul_ln1118_212_fu_56975_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_231_fu_57000_p4() {
    trunc_ln708_231_fu_57000_p4 = mul_ln1118_213_fu_56994_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_232_fu_57019_p4() {
    trunc_ln708_232_fu_57019_p4 = mul_ln1118_214_fu_57013_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_233_fu_57038_p4() {
    trunc_ln708_233_fu_57038_p4 = mul_ln1118_215_fu_57032_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_234_fu_57057_p4() {
    trunc_ln708_234_fu_57057_p4 = mul_ln1118_216_fu_57051_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_235_fu_57076_p4() {
    trunc_ln708_235_fu_57076_p4 = mul_ln1118_217_fu_57070_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_236_fu_57095_p4() {
    trunc_ln708_236_fu_57095_p4 = mul_ln1118_218_fu_57089_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_237_fu_57114_p4() {
    trunc_ln708_237_fu_57114_p4 = mul_ln1118_219_fu_57108_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_238_fu_57133_p4() {
    trunc_ln708_238_fu_57133_p4 = mul_ln1118_220_fu_57127_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_239_fu_57152_p4() {
    trunc_ln708_239_fu_57152_p4 = mul_ln1118_221_fu_57146_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_240_fu_57171_p4() {
    trunc_ln708_240_fu_57171_p4 = mul_ln1118_222_fu_57165_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_241_fu_57190_p4() {
    trunc_ln708_241_fu_57190_p4 = mul_ln1118_223_fu_57184_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_242_fu_57209_p4() {
    trunc_ln708_242_fu_57209_p4 = mul_ln1118_224_fu_57203_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_243_fu_57228_p4() {
    trunc_ln708_243_fu_57228_p4 = mul_ln1118_225_fu_57222_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_244_fu_57247_p4() {
    trunc_ln708_244_fu_57247_p4 = mul_ln1118_226_fu_57241_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_245_fu_57266_p4() {
    trunc_ln708_245_fu_57266_p4 = mul_ln1118_227_fu_57260_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_252_fu_57285_p4() {
    trunc_ln708_252_fu_57285_p4 = mul_ln1118_234_fu_57279_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_253_fu_57304_p4() {
    trunc_ln708_253_fu_57304_p4 = mul_ln1118_235_fu_57298_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_254_fu_57323_p4() {
    trunc_ln708_254_fu_57323_p4 = mul_ln1118_236_fu_57317_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_255_fu_57342_p4() {
    trunc_ln708_255_fu_57342_p4 = mul_ln1118_237_fu_57336_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_256_fu_57361_p4() {
    trunc_ln708_256_fu_57361_p4 = mul_ln1118_238_fu_57355_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_257_fu_57380_p4() {
    trunc_ln708_257_fu_57380_p4 = mul_ln1118_239_fu_57374_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_258_fu_57399_p4() {
    trunc_ln708_258_fu_57399_p4 = mul_ln1118_240_fu_57393_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_259_fu_57418_p4() {
    trunc_ln708_259_fu_57418_p4 = mul_ln1118_241_fu_57412_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_260_fu_57437_p4() {
    trunc_ln708_260_fu_57437_p4 = mul_ln1118_242_fu_57431_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_261_fu_57456_p4() {
    trunc_ln708_261_fu_57456_p4 = mul_ln1118_243_fu_57450_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_262_fu_57475_p4() {
    trunc_ln708_262_fu_57475_p4 = mul_ln1118_244_fu_57469_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_263_fu_57494_p4() {
    trunc_ln708_263_fu_57494_p4 = mul_ln1118_245_fu_57488_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_264_fu_57513_p4() {
    trunc_ln708_264_fu_57513_p4 = mul_ln1118_246_fu_57507_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_265_fu_57532_p4() {
    trunc_ln708_265_fu_57532_p4 = mul_ln1118_247_fu_57526_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_266_fu_57551_p4() {
    trunc_ln708_266_fu_57551_p4 = mul_ln1118_248_fu_57545_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_267_fu_57570_p4() {
    trunc_ln708_267_fu_57570_p4 = mul_ln1118_249_fu_57564_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_268_fu_57589_p4() {
    trunc_ln708_268_fu_57589_p4 = mul_ln1118_250_fu_57583_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_269_fu_57608_p4() {
    trunc_ln708_269_fu_57608_p4 = mul_ln1118_251_fu_57602_p2.read().range(15, 4);
}

}

