#include "dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_262_V_read288_phi_reg_20036() {
    ap_phi_reg_pp0_iter0_data_262_V_read288_phi_reg_20036 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_263_V_read289_phi_reg_20048() {
    ap_phi_reg_pp0_iter0_data_263_V_read289_phi_reg_20048 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_264_V_read290_phi_reg_20060() {
    ap_phi_reg_pp0_iter0_data_264_V_read290_phi_reg_20060 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_265_V_read291_phi_reg_20072() {
    ap_phi_reg_pp0_iter0_data_265_V_read291_phi_reg_20072 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_266_V_read292_phi_reg_20084() {
    ap_phi_reg_pp0_iter0_data_266_V_read292_phi_reg_20084 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_267_V_read293_phi_reg_20096() {
    ap_phi_reg_pp0_iter0_data_267_V_read293_phi_reg_20096 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_268_V_read294_phi_reg_20108() {
    ap_phi_reg_pp0_iter0_data_268_V_read294_phi_reg_20108 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_269_V_read295_phi_reg_20120() {
    ap_phi_reg_pp0_iter0_data_269_V_read295_phi_reg_20120 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_26_V_read52_phi_reg_17204() {
    ap_phi_reg_pp0_iter0_data_26_V_read52_phi_reg_17204 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_270_V_read296_phi_reg_20132() {
    ap_phi_reg_pp0_iter0_data_270_V_read296_phi_reg_20132 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_271_V_read297_phi_reg_20144() {
    ap_phi_reg_pp0_iter0_data_271_V_read297_phi_reg_20144 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_272_V_read298_phi_reg_20156() {
    ap_phi_reg_pp0_iter0_data_272_V_read298_phi_reg_20156 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_273_V_read299_phi_reg_20168() {
    ap_phi_reg_pp0_iter0_data_273_V_read299_phi_reg_20168 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_274_V_read300_phi_reg_20180() {
    ap_phi_reg_pp0_iter0_data_274_V_read300_phi_reg_20180 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_275_V_read301_phi_reg_20192() {
    ap_phi_reg_pp0_iter0_data_275_V_read301_phi_reg_20192 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_276_V_read302_phi_reg_20204() {
    ap_phi_reg_pp0_iter0_data_276_V_read302_phi_reg_20204 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_277_V_read303_phi_reg_20216() {
    ap_phi_reg_pp0_iter0_data_277_V_read303_phi_reg_20216 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_278_V_read304_phi_reg_20228() {
    ap_phi_reg_pp0_iter0_data_278_V_read304_phi_reg_20228 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_279_V_read305_phi_reg_20240() {
    ap_phi_reg_pp0_iter0_data_279_V_read305_phi_reg_20240 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_27_V_read53_phi_reg_17216() {
    ap_phi_reg_pp0_iter0_data_27_V_read53_phi_reg_17216 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_280_V_read306_phi_reg_20252() {
    ap_phi_reg_pp0_iter0_data_280_V_read306_phi_reg_20252 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_281_V_read307_phi_reg_20264() {
    ap_phi_reg_pp0_iter0_data_281_V_read307_phi_reg_20264 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_282_V_read308_phi_reg_20276() {
    ap_phi_reg_pp0_iter0_data_282_V_read308_phi_reg_20276 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_283_V_read309_phi_reg_20288() {
    ap_phi_reg_pp0_iter0_data_283_V_read309_phi_reg_20288 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_284_V_read310_phi_reg_20300() {
    ap_phi_reg_pp0_iter0_data_284_V_read310_phi_reg_20300 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_285_V_read311_phi_reg_20312() {
    ap_phi_reg_pp0_iter0_data_285_V_read311_phi_reg_20312 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_286_V_read312_phi_reg_20324() {
    ap_phi_reg_pp0_iter0_data_286_V_read312_phi_reg_20324 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_287_V_read313_phi_reg_20336() {
    ap_phi_reg_pp0_iter0_data_287_V_read313_phi_reg_20336 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_288_V_read314_phi_reg_20348() {
    ap_phi_reg_pp0_iter0_data_288_V_read314_phi_reg_20348 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_289_V_read315_phi_reg_20360() {
    ap_phi_reg_pp0_iter0_data_289_V_read315_phi_reg_20360 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_28_V_read54_phi_reg_17228() {
    ap_phi_reg_pp0_iter0_data_28_V_read54_phi_reg_17228 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_290_V_read316_phi_reg_20372() {
    ap_phi_reg_pp0_iter0_data_290_V_read316_phi_reg_20372 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_291_V_read317_phi_reg_20384() {
    ap_phi_reg_pp0_iter0_data_291_V_read317_phi_reg_20384 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_292_V_read318_phi_reg_20396() {
    ap_phi_reg_pp0_iter0_data_292_V_read318_phi_reg_20396 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_293_V_read319_phi_reg_20408() {
    ap_phi_reg_pp0_iter0_data_293_V_read319_phi_reg_20408 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_294_V_read320_phi_reg_20420() {
    ap_phi_reg_pp0_iter0_data_294_V_read320_phi_reg_20420 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_295_V_read321_phi_reg_20432() {
    ap_phi_reg_pp0_iter0_data_295_V_read321_phi_reg_20432 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_296_V_read322_phi_reg_20444() {
    ap_phi_reg_pp0_iter0_data_296_V_read322_phi_reg_20444 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_297_V_read323_phi_reg_20456() {
    ap_phi_reg_pp0_iter0_data_297_V_read323_phi_reg_20456 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_298_V_read324_phi_reg_20468() {
    ap_phi_reg_pp0_iter0_data_298_V_read324_phi_reg_20468 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_299_V_read325_phi_reg_20480() {
    ap_phi_reg_pp0_iter0_data_299_V_read325_phi_reg_20480 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_29_V_read55_phi_reg_17240() {
    ap_phi_reg_pp0_iter0_data_29_V_read55_phi_reg_17240 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_2_V_read28_phi_reg_16916() {
    ap_phi_reg_pp0_iter0_data_2_V_read28_phi_reg_16916 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_300_V_read326_phi_reg_20492() {
    ap_phi_reg_pp0_iter0_data_300_V_read326_phi_reg_20492 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_301_V_read327_phi_reg_20504() {
    ap_phi_reg_pp0_iter0_data_301_V_read327_phi_reg_20504 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_302_V_read328_phi_reg_20516() {
    ap_phi_reg_pp0_iter0_data_302_V_read328_phi_reg_20516 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_303_V_read329_phi_reg_20528() {
    ap_phi_reg_pp0_iter0_data_303_V_read329_phi_reg_20528 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_304_V_read330_phi_reg_20540() {
    ap_phi_reg_pp0_iter0_data_304_V_read330_phi_reg_20540 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_305_V_read331_phi_reg_20552() {
    ap_phi_reg_pp0_iter0_data_305_V_read331_phi_reg_20552 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_306_V_read332_phi_reg_20564() {
    ap_phi_reg_pp0_iter0_data_306_V_read332_phi_reg_20564 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_307_V_read333_phi_reg_20576() {
    ap_phi_reg_pp0_iter0_data_307_V_read333_phi_reg_20576 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_308_V_read334_phi_reg_20588() {
    ap_phi_reg_pp0_iter0_data_308_V_read334_phi_reg_20588 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_309_V_read335_phi_reg_20600() {
    ap_phi_reg_pp0_iter0_data_309_V_read335_phi_reg_20600 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_30_V_read56_phi_reg_17252() {
    ap_phi_reg_pp0_iter0_data_30_V_read56_phi_reg_17252 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_310_V_read336_phi_reg_20612() {
    ap_phi_reg_pp0_iter0_data_310_V_read336_phi_reg_20612 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_311_V_read337_phi_reg_20624() {
    ap_phi_reg_pp0_iter0_data_311_V_read337_phi_reg_20624 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_312_V_read338_phi_reg_20636() {
    ap_phi_reg_pp0_iter0_data_312_V_read338_phi_reg_20636 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_313_V_read339_phi_reg_20648() {
    ap_phi_reg_pp0_iter0_data_313_V_read339_phi_reg_20648 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_314_V_read340_phi_reg_20660() {
    ap_phi_reg_pp0_iter0_data_314_V_read340_phi_reg_20660 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_315_V_read341_phi_reg_20672() {
    ap_phi_reg_pp0_iter0_data_315_V_read341_phi_reg_20672 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_316_V_read342_phi_reg_20684() {
    ap_phi_reg_pp0_iter0_data_316_V_read342_phi_reg_20684 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_317_V_read343_phi_reg_20696() {
    ap_phi_reg_pp0_iter0_data_317_V_read343_phi_reg_20696 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_318_V_read344_phi_reg_20708() {
    ap_phi_reg_pp0_iter0_data_318_V_read344_phi_reg_20708 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_319_V_read345_phi_reg_20720() {
    ap_phi_reg_pp0_iter0_data_319_V_read345_phi_reg_20720 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_31_V_read57_phi_reg_17264() {
    ap_phi_reg_pp0_iter0_data_31_V_read57_phi_reg_17264 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_320_V_read346_phi_reg_20732() {
    ap_phi_reg_pp0_iter0_data_320_V_read346_phi_reg_20732 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_321_V_read347_phi_reg_20744() {
    ap_phi_reg_pp0_iter0_data_321_V_read347_phi_reg_20744 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_322_V_read348_phi_reg_20756() {
    ap_phi_reg_pp0_iter0_data_322_V_read348_phi_reg_20756 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_323_V_read349_phi_reg_20768() {
    ap_phi_reg_pp0_iter0_data_323_V_read349_phi_reg_20768 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_324_V_read350_phi_reg_20780() {
    ap_phi_reg_pp0_iter0_data_324_V_read350_phi_reg_20780 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_325_V_read351_phi_reg_20792() {
    ap_phi_reg_pp0_iter0_data_325_V_read351_phi_reg_20792 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_326_V_read352_phi_reg_20804() {
    ap_phi_reg_pp0_iter0_data_326_V_read352_phi_reg_20804 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_327_V_read353_phi_reg_20816() {
    ap_phi_reg_pp0_iter0_data_327_V_read353_phi_reg_20816 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_328_V_read354_phi_reg_20828() {
    ap_phi_reg_pp0_iter0_data_328_V_read354_phi_reg_20828 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_329_V_read355_phi_reg_20840() {
    ap_phi_reg_pp0_iter0_data_329_V_read355_phi_reg_20840 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_32_V_read58_phi_reg_17276() {
    ap_phi_reg_pp0_iter0_data_32_V_read58_phi_reg_17276 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_330_V_read356_phi_reg_20852() {
    ap_phi_reg_pp0_iter0_data_330_V_read356_phi_reg_20852 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_331_V_read357_phi_reg_20864() {
    ap_phi_reg_pp0_iter0_data_331_V_read357_phi_reg_20864 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_332_V_read358_phi_reg_20876() {
    ap_phi_reg_pp0_iter0_data_332_V_read358_phi_reg_20876 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_333_V_read359_phi_reg_20888() {
    ap_phi_reg_pp0_iter0_data_333_V_read359_phi_reg_20888 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_334_V_read360_phi_reg_20900() {
    ap_phi_reg_pp0_iter0_data_334_V_read360_phi_reg_20900 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_335_V_read361_phi_reg_20912() {
    ap_phi_reg_pp0_iter0_data_335_V_read361_phi_reg_20912 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_336_V_read362_phi_reg_20924() {
    ap_phi_reg_pp0_iter0_data_336_V_read362_phi_reg_20924 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_337_V_read363_phi_reg_20936() {
    ap_phi_reg_pp0_iter0_data_337_V_read363_phi_reg_20936 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_338_V_read364_phi_reg_20948() {
    ap_phi_reg_pp0_iter0_data_338_V_read364_phi_reg_20948 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_339_V_read365_phi_reg_20960() {
    ap_phi_reg_pp0_iter0_data_339_V_read365_phi_reg_20960 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_33_V_read59_phi_reg_17288() {
    ap_phi_reg_pp0_iter0_data_33_V_read59_phi_reg_17288 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_340_V_read366_phi_reg_20972() {
    ap_phi_reg_pp0_iter0_data_340_V_read366_phi_reg_20972 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_341_V_read367_phi_reg_20984() {
    ap_phi_reg_pp0_iter0_data_341_V_read367_phi_reg_20984 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_342_V_read368_phi_reg_20996() {
    ap_phi_reg_pp0_iter0_data_342_V_read368_phi_reg_20996 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_343_V_read369_phi_reg_21008() {
    ap_phi_reg_pp0_iter0_data_343_V_read369_phi_reg_21008 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_344_V_read370_phi_reg_21020() {
    ap_phi_reg_pp0_iter0_data_344_V_read370_phi_reg_21020 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_345_V_read371_phi_reg_21032() {
    ap_phi_reg_pp0_iter0_data_345_V_read371_phi_reg_21032 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_346_V_read372_phi_reg_21044() {
    ap_phi_reg_pp0_iter0_data_346_V_read372_phi_reg_21044 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_347_V_read373_phi_reg_21056() {
    ap_phi_reg_pp0_iter0_data_347_V_read373_phi_reg_21056 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_348_V_read374_phi_reg_21068() {
    ap_phi_reg_pp0_iter0_data_348_V_read374_phi_reg_21068 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_349_V_read375_phi_reg_21080() {
    ap_phi_reg_pp0_iter0_data_349_V_read375_phi_reg_21080 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_34_V_read60_phi_reg_17300() {
    ap_phi_reg_pp0_iter0_data_34_V_read60_phi_reg_17300 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_350_V_read376_phi_reg_21092() {
    ap_phi_reg_pp0_iter0_data_350_V_read376_phi_reg_21092 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_351_V_read377_phi_reg_21104() {
    ap_phi_reg_pp0_iter0_data_351_V_read377_phi_reg_21104 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_352_V_read378_phi_reg_21116() {
    ap_phi_reg_pp0_iter0_data_352_V_read378_phi_reg_21116 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_353_V_read379_phi_reg_21128() {
    ap_phi_reg_pp0_iter0_data_353_V_read379_phi_reg_21128 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_354_V_read380_phi_reg_21140() {
    ap_phi_reg_pp0_iter0_data_354_V_read380_phi_reg_21140 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_355_V_read381_phi_reg_21152() {
    ap_phi_reg_pp0_iter0_data_355_V_read381_phi_reg_21152 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_356_V_read382_phi_reg_21164() {
    ap_phi_reg_pp0_iter0_data_356_V_read382_phi_reg_21164 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_357_V_read383_phi_reg_21176() {
    ap_phi_reg_pp0_iter0_data_357_V_read383_phi_reg_21176 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_358_V_read384_phi_reg_21188() {
    ap_phi_reg_pp0_iter0_data_358_V_read384_phi_reg_21188 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_359_V_read385_phi_reg_21200() {
    ap_phi_reg_pp0_iter0_data_359_V_read385_phi_reg_21200 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_35_V_read61_phi_reg_17312() {
    ap_phi_reg_pp0_iter0_data_35_V_read61_phi_reg_17312 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_360_V_read386_phi_reg_21212() {
    ap_phi_reg_pp0_iter0_data_360_V_read386_phi_reg_21212 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_361_V_read387_phi_reg_21224() {
    ap_phi_reg_pp0_iter0_data_361_V_read387_phi_reg_21224 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_362_V_read388_phi_reg_21236() {
    ap_phi_reg_pp0_iter0_data_362_V_read388_phi_reg_21236 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_363_V_read389_phi_reg_21248() {
    ap_phi_reg_pp0_iter0_data_363_V_read389_phi_reg_21248 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_364_V_read390_phi_reg_21260() {
    ap_phi_reg_pp0_iter0_data_364_V_read390_phi_reg_21260 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_365_V_read391_phi_reg_21272() {
    ap_phi_reg_pp0_iter0_data_365_V_read391_phi_reg_21272 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_366_V_read392_phi_reg_21284() {
    ap_phi_reg_pp0_iter0_data_366_V_read392_phi_reg_21284 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_367_V_read393_phi_reg_21296() {
    ap_phi_reg_pp0_iter0_data_367_V_read393_phi_reg_21296 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_368_V_read394_phi_reg_21308() {
    ap_phi_reg_pp0_iter0_data_368_V_read394_phi_reg_21308 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_369_V_read395_phi_reg_21320() {
    ap_phi_reg_pp0_iter0_data_369_V_read395_phi_reg_21320 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_36_V_read62_phi_reg_17324() {
    ap_phi_reg_pp0_iter0_data_36_V_read62_phi_reg_17324 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_370_V_read396_phi_reg_21332() {
    ap_phi_reg_pp0_iter0_data_370_V_read396_phi_reg_21332 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_371_V_read397_phi_reg_21344() {
    ap_phi_reg_pp0_iter0_data_371_V_read397_phi_reg_21344 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_372_V_read398_phi_reg_21356() {
    ap_phi_reg_pp0_iter0_data_372_V_read398_phi_reg_21356 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_373_V_read399_phi_reg_21368() {
    ap_phi_reg_pp0_iter0_data_373_V_read399_phi_reg_21368 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_374_V_read400_phi_reg_21380() {
    ap_phi_reg_pp0_iter0_data_374_V_read400_phi_reg_21380 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_375_V_read401_phi_reg_21392() {
    ap_phi_reg_pp0_iter0_data_375_V_read401_phi_reg_21392 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_376_V_read402_phi_reg_21404() {
    ap_phi_reg_pp0_iter0_data_376_V_read402_phi_reg_21404 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_377_V_read403_phi_reg_21416() {
    ap_phi_reg_pp0_iter0_data_377_V_read403_phi_reg_21416 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_378_V_read404_phi_reg_21428() {
    ap_phi_reg_pp0_iter0_data_378_V_read404_phi_reg_21428 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_379_V_read405_phi_reg_21440() {
    ap_phi_reg_pp0_iter0_data_379_V_read405_phi_reg_21440 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_37_V_read63_phi_reg_17336() {
    ap_phi_reg_pp0_iter0_data_37_V_read63_phi_reg_17336 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_380_V_read406_phi_reg_21452() {
    ap_phi_reg_pp0_iter0_data_380_V_read406_phi_reg_21452 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_381_V_read407_phi_reg_21464() {
    ap_phi_reg_pp0_iter0_data_381_V_read407_phi_reg_21464 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_382_V_read408_phi_reg_21476() {
    ap_phi_reg_pp0_iter0_data_382_V_read408_phi_reg_21476 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_383_V_read409_phi_reg_21488() {
    ap_phi_reg_pp0_iter0_data_383_V_read409_phi_reg_21488 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_384_V_read410_phi_reg_21500() {
    ap_phi_reg_pp0_iter0_data_384_V_read410_phi_reg_21500 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_385_V_read411_phi_reg_21512() {
    ap_phi_reg_pp0_iter0_data_385_V_read411_phi_reg_21512 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_386_V_read412_phi_reg_21524() {
    ap_phi_reg_pp0_iter0_data_386_V_read412_phi_reg_21524 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_387_V_read413_phi_reg_21536() {
    ap_phi_reg_pp0_iter0_data_387_V_read413_phi_reg_21536 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_388_V_read414_phi_reg_21548() {
    ap_phi_reg_pp0_iter0_data_388_V_read414_phi_reg_21548 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_389_V_read415_phi_reg_21560() {
    ap_phi_reg_pp0_iter0_data_389_V_read415_phi_reg_21560 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_38_V_read64_phi_reg_17348() {
    ap_phi_reg_pp0_iter0_data_38_V_read64_phi_reg_17348 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_390_V_read416_phi_reg_21572() {
    ap_phi_reg_pp0_iter0_data_390_V_read416_phi_reg_21572 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_391_V_read417_phi_reg_21584() {
    ap_phi_reg_pp0_iter0_data_391_V_read417_phi_reg_21584 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_392_V_read418_phi_reg_21596() {
    ap_phi_reg_pp0_iter0_data_392_V_read418_phi_reg_21596 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_393_V_read419_phi_reg_21608() {
    ap_phi_reg_pp0_iter0_data_393_V_read419_phi_reg_21608 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_394_V_read420_phi_reg_21620() {
    ap_phi_reg_pp0_iter0_data_394_V_read420_phi_reg_21620 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_395_V_read421_phi_reg_21632() {
    ap_phi_reg_pp0_iter0_data_395_V_read421_phi_reg_21632 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_396_V_read422_phi_reg_21644() {
    ap_phi_reg_pp0_iter0_data_396_V_read422_phi_reg_21644 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_397_V_read423_phi_reg_21656() {
    ap_phi_reg_pp0_iter0_data_397_V_read423_phi_reg_21656 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_398_V_read424_phi_reg_21668() {
    ap_phi_reg_pp0_iter0_data_398_V_read424_phi_reg_21668 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_399_V_read425_phi_reg_21680() {
    ap_phi_reg_pp0_iter0_data_399_V_read425_phi_reg_21680 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_39_V_read65_phi_reg_17360() {
    ap_phi_reg_pp0_iter0_data_39_V_read65_phi_reg_17360 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_3_V_read29_phi_reg_16928() {
    ap_phi_reg_pp0_iter0_data_3_V_read29_phi_reg_16928 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_40_V_read66_phi_reg_17372() {
    ap_phi_reg_pp0_iter0_data_40_V_read66_phi_reg_17372 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_41_V_read67_phi_reg_17384() {
    ap_phi_reg_pp0_iter0_data_41_V_read67_phi_reg_17384 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_42_V_read68_phi_reg_17396() {
    ap_phi_reg_pp0_iter0_data_42_V_read68_phi_reg_17396 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_43_V_read69_phi_reg_17408() {
    ap_phi_reg_pp0_iter0_data_43_V_read69_phi_reg_17408 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_44_V_read70_phi_reg_17420() {
    ap_phi_reg_pp0_iter0_data_44_V_read70_phi_reg_17420 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_45_V_read71_phi_reg_17432() {
    ap_phi_reg_pp0_iter0_data_45_V_read71_phi_reg_17432 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_46_V_read72_phi_reg_17444() {
    ap_phi_reg_pp0_iter0_data_46_V_read72_phi_reg_17444 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_47_V_read73_phi_reg_17456() {
    ap_phi_reg_pp0_iter0_data_47_V_read73_phi_reg_17456 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_48_V_read74_phi_reg_17468() {
    ap_phi_reg_pp0_iter0_data_48_V_read74_phi_reg_17468 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_49_V_read75_phi_reg_17480() {
    ap_phi_reg_pp0_iter0_data_49_V_read75_phi_reg_17480 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_4_V_read30_phi_reg_16940() {
    ap_phi_reg_pp0_iter0_data_4_V_read30_phi_reg_16940 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_50_V_read76_phi_reg_17492() {
    ap_phi_reg_pp0_iter0_data_50_V_read76_phi_reg_17492 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_51_V_read77_phi_reg_17504() {
    ap_phi_reg_pp0_iter0_data_51_V_read77_phi_reg_17504 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_52_V_read78_phi_reg_17516() {
    ap_phi_reg_pp0_iter0_data_52_V_read78_phi_reg_17516 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_53_V_read79_phi_reg_17528() {
    ap_phi_reg_pp0_iter0_data_53_V_read79_phi_reg_17528 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_54_V_read80_phi_reg_17540() {
    ap_phi_reg_pp0_iter0_data_54_V_read80_phi_reg_17540 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_55_V_read81_phi_reg_17552() {
    ap_phi_reg_pp0_iter0_data_55_V_read81_phi_reg_17552 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_56_V_read82_phi_reg_17564() {
    ap_phi_reg_pp0_iter0_data_56_V_read82_phi_reg_17564 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_57_V_read83_phi_reg_17576() {
    ap_phi_reg_pp0_iter0_data_57_V_read83_phi_reg_17576 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_58_V_read84_phi_reg_17588() {
    ap_phi_reg_pp0_iter0_data_58_V_read84_phi_reg_17588 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_59_V_read85_phi_reg_17600() {
    ap_phi_reg_pp0_iter0_data_59_V_read85_phi_reg_17600 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_5_V_read31_phi_reg_16952() {
    ap_phi_reg_pp0_iter0_data_5_V_read31_phi_reg_16952 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_60_V_read86_phi_reg_17612() {
    ap_phi_reg_pp0_iter0_data_60_V_read86_phi_reg_17612 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_61_V_read87_phi_reg_17624() {
    ap_phi_reg_pp0_iter0_data_61_V_read87_phi_reg_17624 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_62_V_read88_phi_reg_17636() {
    ap_phi_reg_pp0_iter0_data_62_V_read88_phi_reg_17636 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_63_V_read89_phi_reg_17648() {
    ap_phi_reg_pp0_iter0_data_63_V_read89_phi_reg_17648 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_64_V_read90_phi_reg_17660() {
    ap_phi_reg_pp0_iter0_data_64_V_read90_phi_reg_17660 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_65_V_read91_phi_reg_17672() {
    ap_phi_reg_pp0_iter0_data_65_V_read91_phi_reg_17672 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_66_V_read92_phi_reg_17684() {
    ap_phi_reg_pp0_iter0_data_66_V_read92_phi_reg_17684 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_67_V_read93_phi_reg_17696() {
    ap_phi_reg_pp0_iter0_data_67_V_read93_phi_reg_17696 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_68_V_read94_phi_reg_17708() {
    ap_phi_reg_pp0_iter0_data_68_V_read94_phi_reg_17708 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_69_V_read95_phi_reg_17720() {
    ap_phi_reg_pp0_iter0_data_69_V_read95_phi_reg_17720 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_6_V_read32_phi_reg_16964() {
    ap_phi_reg_pp0_iter0_data_6_V_read32_phi_reg_16964 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_70_V_read96_phi_reg_17732() {
    ap_phi_reg_pp0_iter0_data_70_V_read96_phi_reg_17732 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_71_V_read97_phi_reg_17744() {
    ap_phi_reg_pp0_iter0_data_71_V_read97_phi_reg_17744 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_72_V_read98_phi_reg_17756() {
    ap_phi_reg_pp0_iter0_data_72_V_read98_phi_reg_17756 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_73_V_read99_phi_reg_17768() {
    ap_phi_reg_pp0_iter0_data_73_V_read99_phi_reg_17768 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_74_V_read100_phi_reg_17780() {
    ap_phi_reg_pp0_iter0_data_74_V_read100_phi_reg_17780 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_75_V_read101_phi_reg_17792() {
    ap_phi_reg_pp0_iter0_data_75_V_read101_phi_reg_17792 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_76_V_read102_phi_reg_17804() {
    ap_phi_reg_pp0_iter0_data_76_V_read102_phi_reg_17804 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_77_V_read103_phi_reg_17816() {
    ap_phi_reg_pp0_iter0_data_77_V_read103_phi_reg_17816 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_78_V_read104_phi_reg_17828() {
    ap_phi_reg_pp0_iter0_data_78_V_read104_phi_reg_17828 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_79_V_read105_phi_reg_17840() {
    ap_phi_reg_pp0_iter0_data_79_V_read105_phi_reg_17840 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_7_V_read33_phi_reg_16976() {
    ap_phi_reg_pp0_iter0_data_7_V_read33_phi_reg_16976 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_80_V_read106_phi_reg_17852() {
    ap_phi_reg_pp0_iter0_data_80_V_read106_phi_reg_17852 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_81_V_read107_phi_reg_17864() {
    ap_phi_reg_pp0_iter0_data_81_V_read107_phi_reg_17864 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_82_V_read108_phi_reg_17876() {
    ap_phi_reg_pp0_iter0_data_82_V_read108_phi_reg_17876 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_83_V_read109_phi_reg_17888() {
    ap_phi_reg_pp0_iter0_data_83_V_read109_phi_reg_17888 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_84_V_read110_phi_reg_17900() {
    ap_phi_reg_pp0_iter0_data_84_V_read110_phi_reg_17900 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_85_V_read111_phi_reg_17912() {
    ap_phi_reg_pp0_iter0_data_85_V_read111_phi_reg_17912 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_86_V_read112_phi_reg_17924() {
    ap_phi_reg_pp0_iter0_data_86_V_read112_phi_reg_17924 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_87_V_read113_phi_reg_17936() {
    ap_phi_reg_pp0_iter0_data_87_V_read113_phi_reg_17936 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_88_V_read114_phi_reg_17948() {
    ap_phi_reg_pp0_iter0_data_88_V_read114_phi_reg_17948 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_89_V_read115_phi_reg_17960() {
    ap_phi_reg_pp0_iter0_data_89_V_read115_phi_reg_17960 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_8_V_read34_phi_reg_16988() {
    ap_phi_reg_pp0_iter0_data_8_V_read34_phi_reg_16988 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_90_V_read116_phi_reg_17972() {
    ap_phi_reg_pp0_iter0_data_90_V_read116_phi_reg_17972 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_91_V_read117_phi_reg_17984() {
    ap_phi_reg_pp0_iter0_data_91_V_read117_phi_reg_17984 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_92_V_read118_phi_reg_17996() {
    ap_phi_reg_pp0_iter0_data_92_V_read118_phi_reg_17996 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_93_V_read119_phi_reg_18008() {
    ap_phi_reg_pp0_iter0_data_93_V_read119_phi_reg_18008 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_94_V_read120_phi_reg_18020() {
    ap_phi_reg_pp0_iter0_data_94_V_read120_phi_reg_18020 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_95_V_read121_phi_reg_18032() {
    ap_phi_reg_pp0_iter0_data_95_V_read121_phi_reg_18032 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_96_V_read122_phi_reg_18044() {
    ap_phi_reg_pp0_iter0_data_96_V_read122_phi_reg_18044 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_97_V_read123_phi_reg_18056() {
    ap_phi_reg_pp0_iter0_data_97_V_read123_phi_reg_18056 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_98_V_read124_phi_reg_18068() {
    ap_phi_reg_pp0_iter0_data_98_V_read124_phi_reg_18068 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_99_V_read125_phi_reg_18080() {
    ap_phi_reg_pp0_iter0_data_99_V_read125_phi_reg_18080 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_9_V_read35_phi_reg_17000() {
    ap_phi_reg_pp0_iter0_data_9_V_read35_phi_reg_17000 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_ready() {
    if ((esl_seteq<1,1,1>(ap_phi_mux_w_index25_phi_fu_11281_p6.read(), ap_const_lv1_1) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        ap_ready = ap_const_logic_1;
    } else {
        ap_ready = ap_const_logic_0;
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_reset_idle_pp0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_idle_pp0_0to3.read()))) {
        ap_reset_idle_pp0 = ap_const_logic_1;
    } else {
        ap_reset_idle_pp0 = ap_const_logic_0;
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_0() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter3_reg.read()))) {
        ap_return_0 = acc_0_V_fu_103695_p2.read();
    } else {
        ap_return_0 = ap_return_0_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_1() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter3_reg.read()))) {
        ap_return_1 = acc_1_V_fu_103705_p2.read();
    } else {
        ap_return_1 = ap_return_1_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_2() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter3_reg.read()))) {
        ap_return_2 = acc_2_V_fu_103715_p2.read();
    } else {
        ap_return_2 = ap_return_2_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_3() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter3_reg.read()))) {
        ap_return_3 = acc_3_V_fu_103725_p2.read();
    } else {
        ap_return_3 = ap_return_3_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_4() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter3_reg.read()))) {
        ap_return_4 = acc_4_V_fu_103735_p2.read();
    } else {
        ap_return_4 = ap_return_4_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_5() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter3_reg.read()))) {
        ap_return_5 = acc_5_V_fu_103745_p2.read();
    } else {
        ap_return_5 = ap_return_5_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter3_reg.read()))) {
        ap_return_6 = acc_6_V_fu_103755_p2.read();
    } else {
        ap_return_6 = ap_return_6_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_7() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter3_reg.read()))) {
        ap_return_7 = acc_7_V_fu_103765_p2.read();
    } else {
        ap_return_7 = ap_return_7_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_8() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter3_reg.read()))) {
        ap_return_8 = acc_8_V_fu_103775_p2.read();
    } else {
        ap_return_8 = ap_return_8_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_9() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter4.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter3_reg.read()))) {
        ap_return_9 = acc_9_V_fu_103785_p2.read();
    } else {
        ap_return_9 = ap_return_9_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1000_fu_52533_p0() {
    mul_ln1118_1000_fu_52533_p0 =  (sc_lv<3>) (sext_ln1116_200_fu_29229_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1000_fu_52533_p1() {
    mul_ln1118_1000_fu_52533_p1 = tmp_1000_fu_52519_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1000_fu_52533_p2() {
    mul_ln1118_1000_fu_52533_p2 = (!mul_ln1118_1000_fu_52533_p0.read().is_01() || !mul_ln1118_1000_fu_52533_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1000_fu_52533_p0.read()) * sc_bigint<5>(mul_ln1118_1000_fu_52533_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1001_fu_52565_p0() {
    mul_ln1118_1001_fu_52565_p0 =  (sc_lv<3>) (sext_ln1116_201_fu_29273_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1001_fu_52565_p1() {
    mul_ln1118_1001_fu_52565_p1 = tmp_1001_fu_52551_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1001_fu_52565_p2() {
    mul_ln1118_1001_fu_52565_p2 = (!mul_ln1118_1001_fu_52565_p0.read().is_01() || !mul_ln1118_1001_fu_52565_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1001_fu_52565_p0.read()) * sc_bigint<5>(mul_ln1118_1001_fu_52565_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1002_fu_91584_p0() {
    mul_ln1118_1002_fu_91584_p0 =  (sc_lv<3>) (sext_ln1116_202_reg_106560.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1002_fu_91584_p1() {
    mul_ln1118_1002_fu_91584_p1 = tmp_1002_reg_109128.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1002_fu_91584_p2() {
    mul_ln1118_1002_fu_91584_p2 = (!mul_ln1118_1002_fu_91584_p0.read().is_01() || !mul_ln1118_1002_fu_91584_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1002_fu_91584_p0.read()) * sc_bigint<5>(mul_ln1118_1002_fu_91584_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1003_fu_52607_p0() {
    mul_ln1118_1003_fu_52607_p0 =  (sc_lv<3>) (sext_ln1116_203_fu_29339_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1003_fu_52607_p1() {
    mul_ln1118_1003_fu_52607_p1 = tmp_1003_fu_52593_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1003_fu_52607_p2() {
    mul_ln1118_1003_fu_52607_p2 = (!mul_ln1118_1003_fu_52607_p0.read().is_01() || !mul_ln1118_1003_fu_52607_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1003_fu_52607_p0.read()) * sc_bigint<5>(mul_ln1118_1003_fu_52607_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1004_fu_52639_p0() {
    mul_ln1118_1004_fu_52639_p0 =  (sc_lv<3>) (sext_ln1116_204_fu_29383_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1004_fu_52639_p1() {
    mul_ln1118_1004_fu_52639_p1 = tmp_1004_fu_52625_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1004_fu_52639_p2() {
    mul_ln1118_1004_fu_52639_p2 = (!mul_ln1118_1004_fu_52639_p0.read().is_01() || !mul_ln1118_1004_fu_52639_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1004_fu_52639_p0.read()) * sc_bigint<5>(mul_ln1118_1004_fu_52639_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1005_fu_52671_p0() {
    mul_ln1118_1005_fu_52671_p0 =  (sc_lv<3>) (sext_ln1116_205_fu_29427_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1005_fu_52671_p1() {
    mul_ln1118_1005_fu_52671_p1 = tmp_1005_fu_52657_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1005_fu_52671_p2() {
    mul_ln1118_1005_fu_52671_p2 = (!mul_ln1118_1005_fu_52671_p0.read().is_01() || !mul_ln1118_1005_fu_52671_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1005_fu_52671_p0.read()) * sc_bigint<5>(mul_ln1118_1005_fu_52671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1006_fu_52703_p0() {
    mul_ln1118_1006_fu_52703_p0 =  (sc_lv<3>) (sext_ln1116_206_fu_29471_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1006_fu_52703_p1() {
    mul_ln1118_1006_fu_52703_p1 = tmp_1006_fu_52689_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1006_fu_52703_p2() {
    mul_ln1118_1006_fu_52703_p2 = (!mul_ln1118_1006_fu_52703_p0.read().is_01() || !mul_ln1118_1006_fu_52703_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1006_fu_52703_p0.read()) * sc_bigint<5>(mul_ln1118_1006_fu_52703_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1007_fu_52735_p0() {
    mul_ln1118_1007_fu_52735_p0 =  (sc_lv<3>) (sext_ln1116_207_fu_29515_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1007_fu_52735_p1() {
    mul_ln1118_1007_fu_52735_p1 = tmp_1007_fu_52721_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1007_fu_52735_p2() {
    mul_ln1118_1007_fu_52735_p2 = (!mul_ln1118_1007_fu_52735_p0.read().is_01() || !mul_ln1118_1007_fu_52735_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1007_fu_52735_p0.read()) * sc_bigint<5>(mul_ln1118_1007_fu_52735_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1008_fu_52767_p0() {
    mul_ln1118_1008_fu_52767_p0 =  (sc_lv<3>) (sext_ln1116_208_fu_29559_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1008_fu_52767_p1() {
    mul_ln1118_1008_fu_52767_p1 = tmp_1008_fu_52753_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1008_fu_52767_p2() {
    mul_ln1118_1008_fu_52767_p2 = (!mul_ln1118_1008_fu_52767_p0.read().is_01() || !mul_ln1118_1008_fu_52767_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1008_fu_52767_p0.read()) * sc_bigint<5>(mul_ln1118_1008_fu_52767_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1009_fu_53231_p0() {
    mul_ln1118_1009_fu_53231_p0 =  (sc_lv<3>) (sext_ln1116_fu_21855_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1009_fu_53231_p1() {
    mul_ln1118_1009_fu_53231_p1 = tmp_1009_fu_53217_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1009_fu_53231_p2() {
    mul_ln1118_1009_fu_53231_p2 = (!mul_ln1118_1009_fu_53231_p0.read().is_01() || !mul_ln1118_1009_fu_53231_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1009_fu_53231_p0.read()) * sc_bigint<5>(mul_ln1118_1009_fu_53231_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_100_fu_25353_p0() {
    mul_ln1118_100_fu_25353_p0 =  (sc_lv<3>) (sext_ln1116_100_fu_25345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_100_fu_25353_p1() {
    mul_ln1118_100_fu_25353_p1 = tmp_100_fu_25335_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_100_fu_25353_p2() {
    mul_ln1118_100_fu_25353_p2 = (!mul_ln1118_100_fu_25353_p0.read().is_01() || !mul_ln1118_100_fu_25353_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_100_fu_25353_p0.read()) * sc_bigint<5>(mul_ln1118_100_fu_25353_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1010_fu_53251_p0() {
    mul_ln1118_1010_fu_53251_p0 =  (sc_lv<3>) (sext_ln1116_10_fu_21887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1010_fu_53251_p1() {
    mul_ln1118_1010_fu_53251_p1 = tmp_1010_fu_53237_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1010_fu_53251_p2() {
    mul_ln1118_1010_fu_53251_p2 = (!mul_ln1118_1010_fu_53251_p0.read().is_01() || !mul_ln1118_1010_fu_53251_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1010_fu_53251_p0.read()) * sc_bigint<5>(mul_ln1118_1010_fu_53251_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1011_fu_53283_p0() {
    mul_ln1118_1011_fu_53283_p0 =  (sc_lv<3>) (sext_ln1116_11_fu_21931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1011_fu_53283_p1() {
    mul_ln1118_1011_fu_53283_p1 = tmp_1011_fu_53269_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1011_fu_53283_p2() {
    mul_ln1118_1011_fu_53283_p2 = (!mul_ln1118_1011_fu_53283_p0.read().is_01() || !mul_ln1118_1011_fu_53283_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1011_fu_53283_p0.read()) * sc_bigint<5>(mul_ln1118_1011_fu_53283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1012_fu_53315_p0() {
    mul_ln1118_1012_fu_53315_p0 =  (sc_lv<3>) (sext_ln1116_12_fu_21975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1012_fu_53315_p1() {
    mul_ln1118_1012_fu_53315_p1 = tmp_1012_fu_53301_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1012_fu_53315_p2() {
    mul_ln1118_1012_fu_53315_p2 = (!mul_ln1118_1012_fu_53315_p0.read().is_01() || !mul_ln1118_1012_fu_53315_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1012_fu_53315_p0.read()) * sc_bigint<5>(mul_ln1118_1012_fu_53315_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1013_fu_53335_p0() {
    mul_ln1118_1013_fu_53335_p0 =  (sc_lv<3>) (sext_ln1116_13_fu_22007_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1013_fu_53335_p1() {
    mul_ln1118_1013_fu_53335_p1 = tmp_1013_fu_53321_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1013_fu_53335_p2() {
    mul_ln1118_1013_fu_53335_p2 = (!mul_ln1118_1013_fu_53335_p0.read().is_01() || !mul_ln1118_1013_fu_53335_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1013_fu_53335_p0.read()) * sc_bigint<5>(mul_ln1118_1013_fu_53335_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1014_fu_53367_p0() {
    mul_ln1118_1014_fu_53367_p0 =  (sc_lv<3>) (sext_ln1116_14_fu_22051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1014_fu_53367_p1() {
    mul_ln1118_1014_fu_53367_p1 = tmp_1014_fu_53353_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1014_fu_53367_p2() {
    mul_ln1118_1014_fu_53367_p2 = (!mul_ln1118_1014_fu_53367_p0.read().is_01() || !mul_ln1118_1014_fu_53367_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1014_fu_53367_p0.read()) * sc_bigint<5>(mul_ln1118_1014_fu_53367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1015_fu_92734_p0() {
    mul_ln1118_1015_fu_92734_p0 =  (sc_lv<3>) (sext_ln1116_15_fu_82451_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1015_fu_92734_p1() {
    mul_ln1118_1015_fu_92734_p1 = tmp_1015_reg_109503.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1015_fu_92734_p2() {
    mul_ln1118_1015_fu_92734_p2 = (!mul_ln1118_1015_fu_92734_p0.read().is_01() || !mul_ln1118_1015_fu_92734_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1015_fu_92734_p0.read()) * sc_bigint<5>(mul_ln1118_1015_fu_92734_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1016_fu_53409_p0() {
    mul_ln1118_1016_fu_53409_p0 =  (sc_lv<3>) (sext_ln1116_16_fu_22113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1016_fu_53409_p1() {
    mul_ln1118_1016_fu_53409_p1 = tmp_1016_fu_53395_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1016_fu_53409_p2() {
    mul_ln1118_1016_fu_53409_p2 = (!mul_ln1118_1016_fu_53409_p0.read().is_01() || !mul_ln1118_1016_fu_53409_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1016_fu_53409_p0.read()) * sc_bigint<5>(mul_ln1118_1016_fu_53409_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1017_fu_53441_p0() {
    mul_ln1118_1017_fu_53441_p0 =  (sc_lv<3>) (sext_ln1116_17_fu_22157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1017_fu_53441_p1() {
    mul_ln1118_1017_fu_53441_p1 = tmp_1017_fu_53427_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1017_fu_53441_p2() {
    mul_ln1118_1017_fu_53441_p2 = (!mul_ln1118_1017_fu_53441_p0.read().is_01() || !mul_ln1118_1017_fu_53441_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1017_fu_53441_p0.read()) * sc_bigint<5>(mul_ln1118_1017_fu_53441_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1018_fu_92755_p0() {
    mul_ln1118_1018_fu_92755_p0 =  (sc_lv<3>) (sext_ln1116_18_fu_82475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1018_fu_92755_p1() {
    mul_ln1118_1018_fu_92755_p1 = tmp_1018_reg_109508.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1018_fu_92755_p2() {
    mul_ln1118_1018_fu_92755_p2 = (!mul_ln1118_1018_fu_92755_p0.read().is_01() || !mul_ln1118_1018_fu_92755_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1018_fu_92755_p0.read()) * sc_bigint<5>(mul_ln1118_1018_fu_92755_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1019_fu_53483_p0() {
    mul_ln1118_1019_fu_53483_p0 =  (sc_lv<3>) (sext_ln1116_19_fu_22219_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1019_fu_53483_p1() {
    mul_ln1118_1019_fu_53483_p1 = tmp_1019_fu_53469_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1019_fu_53483_p2() {
    mul_ln1118_1019_fu_53483_p2 = (!mul_ln1118_1019_fu_53483_p0.read().is_01() || !mul_ln1118_1019_fu_53483_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1019_fu_53483_p0.read()) * sc_bigint<5>(mul_ln1118_1019_fu_53483_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_101_fu_25397_p0() {
    mul_ln1118_101_fu_25397_p0 =  (sc_lv<3>) (sext_ln1116_101_fu_25389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_101_fu_25397_p1() {
    mul_ln1118_101_fu_25397_p1 = tmp_101_fu_25379_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_101_fu_25397_p2() {
    mul_ln1118_101_fu_25397_p2 = (!mul_ln1118_101_fu_25397_p0.read().is_01() || !mul_ln1118_101_fu_25397_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_101_fu_25397_p0.read()) * sc_bigint<5>(mul_ln1118_101_fu_25397_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1020_fu_53515_p0() {
    mul_ln1118_1020_fu_53515_p0 =  (sc_lv<3>) (sext_ln1116_20_fu_22263_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1020_fu_53515_p1() {
    mul_ln1118_1020_fu_53515_p1 = tmp_1020_fu_53501_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1020_fu_53515_p2() {
    mul_ln1118_1020_fu_53515_p2 = (!mul_ln1118_1020_fu_53515_p0.read().is_01() || !mul_ln1118_1020_fu_53515_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1020_fu_53515_p0.read()) * sc_bigint<5>(mul_ln1118_1020_fu_53515_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1021_fu_92776_p0() {
    mul_ln1118_1021_fu_92776_p0 =  (sc_lv<3>) (sext_ln1116_21_fu_82499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1021_fu_92776_p1() {
    mul_ln1118_1021_fu_92776_p1 = tmp_1021_reg_109513.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1021_fu_92776_p2() {
    mul_ln1118_1021_fu_92776_p2 = (!mul_ln1118_1021_fu_92776_p0.read().is_01() || !mul_ln1118_1021_fu_92776_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1021_fu_92776_p0.read()) * sc_bigint<5>(mul_ln1118_1021_fu_92776_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1022_fu_53557_p0() {
    mul_ln1118_1022_fu_53557_p0 =  (sc_lv<3>) (sext_ln1116_22_fu_22325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1022_fu_53557_p1() {
    mul_ln1118_1022_fu_53557_p1 = tmp_1022_fu_53543_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1022_fu_53557_p2() {
    mul_ln1118_1022_fu_53557_p2 = (!mul_ln1118_1022_fu_53557_p0.read().is_01() || !mul_ln1118_1022_fu_53557_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1022_fu_53557_p0.read()) * sc_bigint<5>(mul_ln1118_1022_fu_53557_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1023_fu_53589_p0() {
    mul_ln1118_1023_fu_53589_p0 =  (sc_lv<3>) (sext_ln1116_23_fu_22369_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1023_fu_53589_p1() {
    mul_ln1118_1023_fu_53589_p1 = tmp_1023_fu_53575_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1023_fu_53589_p2() {
    mul_ln1118_1023_fu_53589_p2 = (!mul_ln1118_1023_fu_53589_p0.read().is_01() || !mul_ln1118_1023_fu_53589_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1023_fu_53589_p0.read()) * sc_bigint<5>(mul_ln1118_1023_fu_53589_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1024_fu_92797_p0() {
    mul_ln1118_1024_fu_92797_p0 =  (sc_lv<3>) (sext_ln1116_24_fu_82523_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1024_fu_92797_p1() {
    mul_ln1118_1024_fu_92797_p1 = tmp_1024_reg_109518.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1024_fu_92797_p2() {
    mul_ln1118_1024_fu_92797_p2 = (!mul_ln1118_1024_fu_92797_p0.read().is_01() || !mul_ln1118_1024_fu_92797_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1024_fu_92797_p0.read()) * sc_bigint<5>(mul_ln1118_1024_fu_92797_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1025_fu_53631_p0() {
    mul_ln1118_1025_fu_53631_p0 =  (sc_lv<3>) (sext_ln1116_25_fu_22431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1025_fu_53631_p1() {
    mul_ln1118_1025_fu_53631_p1 = tmp_1025_fu_53617_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1025_fu_53631_p2() {
    mul_ln1118_1025_fu_53631_p2 = (!mul_ln1118_1025_fu_53631_p0.read().is_01() || !mul_ln1118_1025_fu_53631_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1025_fu_53631_p0.read()) * sc_bigint<5>(mul_ln1118_1025_fu_53631_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1026_fu_53663_p0() {
    mul_ln1118_1026_fu_53663_p0 =  (sc_lv<3>) (sext_ln1116_26_fu_22475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1026_fu_53663_p1() {
    mul_ln1118_1026_fu_53663_p1 = tmp_1026_fu_53649_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1026_fu_53663_p2() {
    mul_ln1118_1026_fu_53663_p2 = (!mul_ln1118_1026_fu_53663_p0.read().is_01() || !mul_ln1118_1026_fu_53663_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1026_fu_53663_p0.read()) * sc_bigint<5>(mul_ln1118_1026_fu_53663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1027_fu_92818_p0() {
    mul_ln1118_1027_fu_92818_p0 =  (sc_lv<3>) (sext_ln1116_27_fu_82547_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1027_fu_92818_p1() {
    mul_ln1118_1027_fu_92818_p1 = tmp_1027_reg_109523.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1027_fu_92818_p2() {
    mul_ln1118_1027_fu_92818_p2 = (!mul_ln1118_1027_fu_92818_p0.read().is_01() || !mul_ln1118_1027_fu_92818_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1027_fu_92818_p0.read()) * sc_bigint<5>(mul_ln1118_1027_fu_92818_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1028_fu_53705_p0() {
    mul_ln1118_1028_fu_53705_p0 =  (sc_lv<3>) (sext_ln1116_28_fu_22537_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1028_fu_53705_p1() {
    mul_ln1118_1028_fu_53705_p1 = tmp_1028_fu_53691_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1028_fu_53705_p2() {
    mul_ln1118_1028_fu_53705_p2 = (!mul_ln1118_1028_fu_53705_p0.read().is_01() || !mul_ln1118_1028_fu_53705_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1028_fu_53705_p0.read()) * sc_bigint<5>(mul_ln1118_1028_fu_53705_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1029_fu_53737_p0() {
    mul_ln1118_1029_fu_53737_p0 =  (sc_lv<3>) (sext_ln1116_29_fu_22581_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1029_fu_53737_p1() {
    mul_ln1118_1029_fu_53737_p1 = tmp_1029_fu_53723_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1029_fu_53737_p2() {
    mul_ln1118_1029_fu_53737_p2 = (!mul_ln1118_1029_fu_53737_p0.read().is_01() || !mul_ln1118_1029_fu_53737_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1029_fu_53737_p0.read()) * sc_bigint<5>(mul_ln1118_1029_fu_53737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_102_fu_82902_p0() {
    mul_ln1118_102_fu_82902_p0 =  (sc_lv<3>) (sext_ln1116_102_reg_106186.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_102_fu_82902_p1() {
    mul_ln1118_102_fu_82902_p1 = tmp_102_reg_106181.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_102_fu_82902_p2() {
    mul_ln1118_102_fu_82902_p2 = (!mul_ln1118_102_fu_82902_p0.read().is_01() || !mul_ln1118_102_fu_82902_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_102_fu_82902_p0.read()) * sc_bigint<5>(mul_ln1118_102_fu_82902_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1030_fu_53769_p0() {
    mul_ln1118_1030_fu_53769_p0 =  (sc_lv<3>) (sext_ln1116_30_fu_22625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1030_fu_53769_p1() {
    mul_ln1118_1030_fu_53769_p1 = tmp_1030_fu_53755_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1030_fu_53769_p2() {
    mul_ln1118_1030_fu_53769_p2 = (!mul_ln1118_1030_fu_53769_p0.read().is_01() || !mul_ln1118_1030_fu_53769_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1030_fu_53769_p0.read()) * sc_bigint<5>(mul_ln1118_1030_fu_53769_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1031_fu_53801_p0() {
    mul_ln1118_1031_fu_53801_p0 =  (sc_lv<3>) (sext_ln1116_31_fu_22669_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1031_fu_53801_p1() {
    mul_ln1118_1031_fu_53801_p1 = tmp_1031_fu_53787_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1031_fu_53801_p2() {
    mul_ln1118_1031_fu_53801_p2 = (!mul_ln1118_1031_fu_53801_p0.read().is_01() || !mul_ln1118_1031_fu_53801_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1031_fu_53801_p0.read()) * sc_bigint<5>(mul_ln1118_1031_fu_53801_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1032_fu_53833_p0() {
    mul_ln1118_1032_fu_53833_p0 =  (sc_lv<3>) (sext_ln1116_32_fu_22713_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1032_fu_53833_p1() {
    mul_ln1118_1032_fu_53833_p1 = tmp_1032_fu_53819_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1032_fu_53833_p2() {
    mul_ln1118_1032_fu_53833_p2 = (!mul_ln1118_1032_fu_53833_p0.read().is_01() || !mul_ln1118_1032_fu_53833_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1032_fu_53833_p0.read()) * sc_bigint<5>(mul_ln1118_1032_fu_53833_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1033_fu_53865_p0() {
    mul_ln1118_1033_fu_53865_p0 =  (sc_lv<3>) (sext_ln1116_33_fu_22757_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1033_fu_53865_p1() {
    mul_ln1118_1033_fu_53865_p1 = tmp_1033_fu_53851_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1033_fu_53865_p2() {
    mul_ln1118_1033_fu_53865_p2 = (!mul_ln1118_1033_fu_53865_p0.read().is_01() || !mul_ln1118_1033_fu_53865_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1033_fu_53865_p0.read()) * sc_bigint<5>(mul_ln1118_1033_fu_53865_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1034_fu_53897_p0() {
    mul_ln1118_1034_fu_53897_p0 =  (sc_lv<3>) (sext_ln1116_34_fu_22801_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1034_fu_53897_p1() {
    mul_ln1118_1034_fu_53897_p1 = tmp_1034_fu_53883_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1034_fu_53897_p2() {
    mul_ln1118_1034_fu_53897_p2 = (!mul_ln1118_1034_fu_53897_p0.read().is_01() || !mul_ln1118_1034_fu_53897_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1034_fu_53897_p0.read()) * sc_bigint<5>(mul_ln1118_1034_fu_53897_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1035_fu_53917_p0() {
    mul_ln1118_1035_fu_53917_p0 =  (sc_lv<3>) (sext_ln1116_35_fu_22833_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1035_fu_53917_p1() {
    mul_ln1118_1035_fu_53917_p1 = tmp_1035_fu_53903_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1035_fu_53917_p2() {
    mul_ln1118_1035_fu_53917_p2 = (!mul_ln1118_1035_fu_53917_p0.read().is_01() || !mul_ln1118_1035_fu_53917_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1035_fu_53917_p0.read()) * sc_bigint<5>(mul_ln1118_1035_fu_53917_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1036_fu_53949_p0() {
    mul_ln1118_1036_fu_53949_p0 =  (sc_lv<3>) (sext_ln1116_36_fu_22877_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1036_fu_53949_p1() {
    mul_ln1118_1036_fu_53949_p1 = tmp_1036_fu_53935_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1036_fu_53949_p2() {
    mul_ln1118_1036_fu_53949_p2 = (!mul_ln1118_1036_fu_53949_p0.read().is_01() || !mul_ln1118_1036_fu_53949_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1036_fu_53949_p0.read()) * sc_bigint<5>(mul_ln1118_1036_fu_53949_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1037_fu_53981_p0() {
    mul_ln1118_1037_fu_53981_p0 =  (sc_lv<3>) (sext_ln1116_37_fu_22921_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1037_fu_53981_p1() {
    mul_ln1118_1037_fu_53981_p1 = tmp_1037_fu_53967_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1037_fu_53981_p2() {
    mul_ln1118_1037_fu_53981_p2 = (!mul_ln1118_1037_fu_53981_p0.read().is_01() || !mul_ln1118_1037_fu_53981_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1037_fu_53981_p0.read()) * sc_bigint<5>(mul_ln1118_1037_fu_53981_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1038_fu_54001_p0() {
    mul_ln1118_1038_fu_54001_p0 =  (sc_lv<3>) (sext_ln1116_38_fu_22953_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1038_fu_54001_p1() {
    mul_ln1118_1038_fu_54001_p1 = tmp_1038_fu_53987_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1038_fu_54001_p2() {
    mul_ln1118_1038_fu_54001_p2 = (!mul_ln1118_1038_fu_54001_p0.read().is_01() || !mul_ln1118_1038_fu_54001_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1038_fu_54001_p0.read()) * sc_bigint<5>(mul_ln1118_1038_fu_54001_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1039_fu_54033_p0() {
    mul_ln1118_1039_fu_54033_p0 =  (sc_lv<3>) (sext_ln1116_39_fu_22997_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1039_fu_54033_p1() {
    mul_ln1118_1039_fu_54033_p1 = tmp_1039_fu_54019_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1039_fu_54033_p2() {
    mul_ln1118_1039_fu_54033_p2 = (!mul_ln1118_1039_fu_54033_p0.read().is_01() || !mul_ln1118_1039_fu_54033_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1039_fu_54033_p0.read()) * sc_bigint<5>(mul_ln1118_1039_fu_54033_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_103_fu_25463_p0() {
    mul_ln1118_103_fu_25463_p0 =  (sc_lv<3>) (sext_ln1116_103_fu_25455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_103_fu_25463_p1() {
    mul_ln1118_103_fu_25463_p1 = tmp_103_fu_25445_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_103_fu_25463_p2() {
    mul_ln1118_103_fu_25463_p2 = (!mul_ln1118_103_fu_25463_p0.read().is_01() || !mul_ln1118_103_fu_25463_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_103_fu_25463_p0.read()) * sc_bigint<5>(mul_ln1118_103_fu_25463_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1040_fu_92861_p0() {
    mul_ln1118_1040_fu_92861_p0 =  (sc_lv<3>) (sext_ln1116_40_reg_105940.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1040_fu_92861_p1() {
    mul_ln1118_1040_fu_92861_p1 = tmp_1040_reg_109538.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1040_fu_92861_p2() {
    mul_ln1118_1040_fu_92861_p2 = (!mul_ln1118_1040_fu_92861_p0.read().is_01() || !mul_ln1118_1040_fu_92861_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1040_fu_92861_p0.read()) * sc_bigint<5>(mul_ln1118_1040_fu_92861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1041_fu_54075_p0() {
    mul_ln1118_1041_fu_54075_p0 =  (sc_lv<3>) (sext_ln1116_41_fu_23063_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1041_fu_54075_p1() {
    mul_ln1118_1041_fu_54075_p1 = tmp_1041_fu_54061_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1041_fu_54075_p2() {
    mul_ln1118_1041_fu_54075_p2 = (!mul_ln1118_1041_fu_54075_p0.read().is_01() || !mul_ln1118_1041_fu_54075_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1041_fu_54075_p0.read()) * sc_bigint<5>(mul_ln1118_1041_fu_54075_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1042_fu_54107_p0() {
    mul_ln1118_1042_fu_54107_p0 =  (sc_lv<3>) (sext_ln1116_42_fu_23107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1042_fu_54107_p1() {
    mul_ln1118_1042_fu_54107_p1 = tmp_1042_fu_54093_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1042_fu_54107_p2() {
    mul_ln1118_1042_fu_54107_p2 = (!mul_ln1118_1042_fu_54107_p0.read().is_01() || !mul_ln1118_1042_fu_54107_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1042_fu_54107_p0.read()) * sc_bigint<5>(mul_ln1118_1042_fu_54107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1043_fu_92881_p0() {
    mul_ln1118_1043_fu_92881_p0 =  (sc_lv<3>) (sext_ln1116_43_reg_105958.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1043_fu_92881_p1() {
    mul_ln1118_1043_fu_92881_p1 = tmp_1043_reg_109543.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1043_fu_92881_p2() {
    mul_ln1118_1043_fu_92881_p2 = (!mul_ln1118_1043_fu_92881_p0.read().is_01() || !mul_ln1118_1043_fu_92881_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1043_fu_92881_p0.read()) * sc_bigint<5>(mul_ln1118_1043_fu_92881_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1044_fu_54149_p0() {
    mul_ln1118_1044_fu_54149_p0 =  (sc_lv<3>) (sext_ln1116_44_fu_23173_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1044_fu_54149_p1() {
    mul_ln1118_1044_fu_54149_p1 = tmp_1044_fu_54135_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1044_fu_54149_p2() {
    mul_ln1118_1044_fu_54149_p2 = (!mul_ln1118_1044_fu_54149_p0.read().is_01() || !mul_ln1118_1044_fu_54149_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1044_fu_54149_p0.read()) * sc_bigint<5>(mul_ln1118_1044_fu_54149_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1045_fu_54181_p0() {
    mul_ln1118_1045_fu_54181_p0 =  (sc_lv<3>) (sext_ln1116_45_fu_23217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1045_fu_54181_p1() {
    mul_ln1118_1045_fu_54181_p1 = tmp_1045_fu_54167_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1045_fu_54181_p2() {
    mul_ln1118_1045_fu_54181_p2 = (!mul_ln1118_1045_fu_54181_p0.read().is_01() || !mul_ln1118_1045_fu_54181_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1045_fu_54181_p0.read()) * sc_bigint<5>(mul_ln1118_1045_fu_54181_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1046_fu_54213_p0() {
    mul_ln1118_1046_fu_54213_p0 =  (sc_lv<3>) (sext_ln1116_46_fu_23261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1046_fu_54213_p1() {
    mul_ln1118_1046_fu_54213_p1 = tmp_1046_fu_54199_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1046_fu_54213_p2() {
    mul_ln1118_1046_fu_54213_p2 = (!mul_ln1118_1046_fu_54213_p0.read().is_01() || !mul_ln1118_1046_fu_54213_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1046_fu_54213_p0.read()) * sc_bigint<5>(mul_ln1118_1046_fu_54213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1047_fu_54233_p0() {
    mul_ln1118_1047_fu_54233_p0 =  (sc_lv<3>) (sext_ln1116_47_fu_23293_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1047_fu_54233_p1() {
    mul_ln1118_1047_fu_54233_p1 = tmp_1047_fu_54219_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1047_fu_54233_p2() {
    mul_ln1118_1047_fu_54233_p2 = (!mul_ln1118_1047_fu_54233_p0.read().is_01() || !mul_ln1118_1047_fu_54233_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1047_fu_54233_p0.read()) * sc_bigint<5>(mul_ln1118_1047_fu_54233_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1048_fu_54265_p0() {
    mul_ln1118_1048_fu_54265_p0 =  (sc_lv<3>) (sext_ln1116_48_fu_23337_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1048_fu_54265_p1() {
    mul_ln1118_1048_fu_54265_p1 = tmp_1048_fu_54251_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1048_fu_54265_p2() {
    mul_ln1118_1048_fu_54265_p2 = (!mul_ln1118_1048_fu_54265_p0.read().is_01() || !mul_ln1118_1048_fu_54265_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1048_fu_54265_p0.read()) * sc_bigint<5>(mul_ln1118_1048_fu_54265_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1049_fu_54297_p0() {
    mul_ln1118_1049_fu_54297_p0 =  (sc_lv<3>) (sext_ln1116_49_fu_23381_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1049_fu_54297_p1() {
    mul_ln1118_1049_fu_54297_p1 = tmp_1049_fu_54283_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1049_fu_54297_p2() {
    mul_ln1118_1049_fu_54297_p2 = (!mul_ln1118_1049_fu_54297_p0.read().is_01() || !mul_ln1118_1049_fu_54297_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1049_fu_54297_p0.read()) * sc_bigint<5>(mul_ln1118_1049_fu_54297_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_104_fu_25507_p0() {
    mul_ln1118_104_fu_25507_p0 =  (sc_lv<3>) (sext_ln1116_104_fu_25499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_104_fu_25507_p1() {
    mul_ln1118_104_fu_25507_p1 = tmp_104_fu_25489_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_104_fu_25507_p2() {
    mul_ln1118_104_fu_25507_p2 = (!mul_ln1118_104_fu_25507_p0.read().is_01() || !mul_ln1118_104_fu_25507_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_104_fu_25507_p0.read()) * sc_bigint<5>(mul_ln1118_104_fu_25507_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1050_fu_54317_p0() {
    mul_ln1118_1050_fu_54317_p0 =  (sc_lv<3>) (sext_ln1116_50_fu_23413_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1050_fu_54317_p1() {
    mul_ln1118_1050_fu_54317_p1 = tmp_1050_fu_54303_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1050_fu_54317_p2() {
    mul_ln1118_1050_fu_54317_p2 = (!mul_ln1118_1050_fu_54317_p0.read().is_01() || !mul_ln1118_1050_fu_54317_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1050_fu_54317_p0.read()) * sc_bigint<5>(mul_ln1118_1050_fu_54317_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1051_fu_54349_p0() {
    mul_ln1118_1051_fu_54349_p0 =  (sc_lv<3>) (sext_ln1116_51_fu_23457_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1051_fu_54349_p1() {
    mul_ln1118_1051_fu_54349_p1 = tmp_1051_fu_54335_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1051_fu_54349_p2() {
    mul_ln1118_1051_fu_54349_p2 = (!mul_ln1118_1051_fu_54349_p0.read().is_01() || !mul_ln1118_1051_fu_54349_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1051_fu_54349_p0.read()) * sc_bigint<5>(mul_ln1118_1051_fu_54349_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1052_fu_92923_p0() {
    mul_ln1118_1052_fu_92923_p0 =  (sc_lv<3>) (sext_ln1116_52_reg_105986.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1052_fu_92923_p1() {
    mul_ln1118_1052_fu_92923_p1 = tmp_1052_reg_109558.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1052_fu_92923_p2() {
    mul_ln1118_1052_fu_92923_p2 = (!mul_ln1118_1052_fu_92923_p0.read().is_01() || !mul_ln1118_1052_fu_92923_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1052_fu_92923_p0.read()) * sc_bigint<5>(mul_ln1118_1052_fu_92923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1053_fu_54391_p0() {
    mul_ln1118_1053_fu_54391_p0 =  (sc_lv<3>) (sext_ln1116_53_fu_23523_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1053_fu_54391_p1() {
    mul_ln1118_1053_fu_54391_p1 = tmp_1053_fu_54377_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1053_fu_54391_p2() {
    mul_ln1118_1053_fu_54391_p2 = (!mul_ln1118_1053_fu_54391_p0.read().is_01() || !mul_ln1118_1053_fu_54391_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1053_fu_54391_p0.read()) * sc_bigint<5>(mul_ln1118_1053_fu_54391_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1054_fu_54423_p0() {
    mul_ln1118_1054_fu_54423_p0 =  (sc_lv<3>) (sext_ln1116_54_fu_23567_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1054_fu_54423_p1() {
    mul_ln1118_1054_fu_54423_p1 = tmp_1054_fu_54409_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1054_fu_54423_p2() {
    mul_ln1118_1054_fu_54423_p2 = (!mul_ln1118_1054_fu_54423_p0.read().is_01() || !mul_ln1118_1054_fu_54423_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1054_fu_54423_p0.read()) * sc_bigint<5>(mul_ln1118_1054_fu_54423_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1055_fu_54455_p0() {
    mul_ln1118_1055_fu_54455_p0 =  (sc_lv<3>) (sext_ln1116_55_fu_23611_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1055_fu_54455_p1() {
    mul_ln1118_1055_fu_54455_p1 = tmp_1055_fu_54441_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1055_fu_54455_p2() {
    mul_ln1118_1055_fu_54455_p2 = (!mul_ln1118_1055_fu_54455_p0.read().is_01() || !mul_ln1118_1055_fu_54455_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1055_fu_54455_p0.read()) * sc_bigint<5>(mul_ln1118_1055_fu_54455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1056_fu_54487_p0() {
    mul_ln1118_1056_fu_54487_p0 =  (sc_lv<3>) (sext_ln1116_56_fu_23655_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1056_fu_54487_p1() {
    mul_ln1118_1056_fu_54487_p1 = tmp_1056_fu_54473_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1056_fu_54487_p2() {
    mul_ln1118_1056_fu_54487_p2 = (!mul_ln1118_1056_fu_54487_p0.read().is_01() || !mul_ln1118_1056_fu_54487_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1056_fu_54487_p0.read()) * sc_bigint<5>(mul_ln1118_1056_fu_54487_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1057_fu_54519_p0() {
    mul_ln1118_1057_fu_54519_p0 =  (sc_lv<3>) (sext_ln1116_57_fu_23699_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1057_fu_54519_p1() {
    mul_ln1118_1057_fu_54519_p1 = tmp_1057_fu_54505_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1057_fu_54519_p2() {
    mul_ln1118_1057_fu_54519_p2 = (!mul_ln1118_1057_fu_54519_p0.read().is_01() || !mul_ln1118_1057_fu_54519_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1057_fu_54519_p0.read()) * sc_bigint<5>(mul_ln1118_1057_fu_54519_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1058_fu_54551_p0() {
    mul_ln1118_1058_fu_54551_p0 =  (sc_lv<3>) (sext_ln1116_58_fu_23743_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1058_fu_54551_p1() {
    mul_ln1118_1058_fu_54551_p1 = tmp_1058_fu_54537_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1058_fu_54551_p2() {
    mul_ln1118_1058_fu_54551_p2 = (!mul_ln1118_1058_fu_54551_p0.read().is_01() || !mul_ln1118_1058_fu_54551_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1058_fu_54551_p0.read()) * sc_bigint<5>(mul_ln1118_1058_fu_54551_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1059_fu_54583_p0() {
    mul_ln1118_1059_fu_54583_p0 =  (sc_lv<3>) (sext_ln1116_59_fu_23787_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1059_fu_54583_p1() {
    mul_ln1118_1059_fu_54583_p1 = tmp_1059_fu_54569_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1059_fu_54583_p2() {
    mul_ln1118_1059_fu_54583_p2 = (!mul_ln1118_1059_fu_54583_p0.read().is_01() || !mul_ln1118_1059_fu_54583_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1059_fu_54583_p0.read()) * sc_bigint<5>(mul_ln1118_1059_fu_54583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_105_fu_25551_p0() {
    mul_ln1118_105_fu_25551_p0 =  (sc_lv<3>) (sext_ln1116_105_fu_25543_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_105_fu_25551_p1() {
    mul_ln1118_105_fu_25551_p1 = tmp_105_fu_25533_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_105_fu_25551_p2() {
    mul_ln1118_105_fu_25551_p2 = (!mul_ln1118_105_fu_25551_p0.read().is_01() || !mul_ln1118_105_fu_25551_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_105_fu_25551_p0.read()) * sc_bigint<5>(mul_ln1118_105_fu_25551_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1060_fu_54603_p0() {
    mul_ln1118_1060_fu_54603_p0 =  (sc_lv<3>) (sext_ln1116_60_fu_23819_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1060_fu_54603_p1() {
    mul_ln1118_1060_fu_54603_p1 = tmp_1060_fu_54589_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1060_fu_54603_p2() {
    mul_ln1118_1060_fu_54603_p2 = (!mul_ln1118_1060_fu_54603_p0.read().is_01() || !mul_ln1118_1060_fu_54603_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1060_fu_54603_p0.read()) * sc_bigint<5>(mul_ln1118_1060_fu_54603_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1061_fu_54635_p0() {
    mul_ln1118_1061_fu_54635_p0 =  (sc_lv<3>) (sext_ln1116_61_fu_23863_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1061_fu_54635_p1() {
    mul_ln1118_1061_fu_54635_p1 = tmp_1061_fu_54621_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1061_fu_54635_p2() {
    mul_ln1118_1061_fu_54635_p2 = (!mul_ln1118_1061_fu_54635_p0.read().is_01() || !mul_ln1118_1061_fu_54635_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1061_fu_54635_p0.read()) * sc_bigint<5>(mul_ln1118_1061_fu_54635_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1062_fu_54667_p0() {
    mul_ln1118_1062_fu_54667_p0 =  (sc_lv<3>) (sext_ln1116_62_fu_23907_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1062_fu_54667_p1() {
    mul_ln1118_1062_fu_54667_p1 = tmp_1062_fu_54653_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1062_fu_54667_p2() {
    mul_ln1118_1062_fu_54667_p2 = (!mul_ln1118_1062_fu_54667_p0.read().is_01() || !mul_ln1118_1062_fu_54667_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1062_fu_54667_p0.read()) * sc_bigint<5>(mul_ln1118_1062_fu_54667_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1063_fu_54687_p0() {
    mul_ln1118_1063_fu_54687_p0 =  (sc_lv<3>) (sext_ln1116_63_fu_23939_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1063_fu_54687_p1() {
    mul_ln1118_1063_fu_54687_p1 = tmp_1063_fu_54673_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1063_fu_54687_p2() {
    mul_ln1118_1063_fu_54687_p2 = (!mul_ln1118_1063_fu_54687_p0.read().is_01() || !mul_ln1118_1063_fu_54687_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1063_fu_54687_p0.read()) * sc_bigint<5>(mul_ln1118_1063_fu_54687_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1064_fu_54719_p0() {
    mul_ln1118_1064_fu_54719_p0 =  (sc_lv<3>) (sext_ln1116_64_fu_23983_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1064_fu_54719_p1() {
    mul_ln1118_1064_fu_54719_p1 = tmp_1064_fu_54705_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1064_fu_54719_p2() {
    mul_ln1118_1064_fu_54719_p2 = (!mul_ln1118_1064_fu_54719_p0.read().is_01() || !mul_ln1118_1064_fu_54719_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1064_fu_54719_p0.read()) * sc_bigint<5>(mul_ln1118_1064_fu_54719_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1065_fu_92965_p0() {
    mul_ln1118_1065_fu_92965_p0 =  (sc_lv<3>) (sext_ln1116_65_reg_106014.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1065_fu_92965_p1() {
    mul_ln1118_1065_fu_92965_p1 = tmp_1065_reg_109573.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1065_fu_92965_p2() {
    mul_ln1118_1065_fu_92965_p2 = (!mul_ln1118_1065_fu_92965_p0.read().is_01() || !mul_ln1118_1065_fu_92965_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1065_fu_92965_p0.read()) * sc_bigint<5>(mul_ln1118_1065_fu_92965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1066_fu_54761_p0() {
    mul_ln1118_1066_fu_54761_p0 =  (sc_lv<3>) (sext_ln1116_66_fu_24049_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1066_fu_54761_p1() {
    mul_ln1118_1066_fu_54761_p1 = tmp_1066_fu_54747_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1066_fu_54761_p2() {
    mul_ln1118_1066_fu_54761_p2 = (!mul_ln1118_1066_fu_54761_p0.read().is_01() || !mul_ln1118_1066_fu_54761_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1066_fu_54761_p0.read()) * sc_bigint<5>(mul_ln1118_1066_fu_54761_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1067_fu_54793_p0() {
    mul_ln1118_1067_fu_54793_p0 =  (sc_lv<3>) (sext_ln1116_67_fu_24093_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1067_fu_54793_p1() {
    mul_ln1118_1067_fu_54793_p1 = tmp_1067_fu_54779_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1067_fu_54793_p2() {
    mul_ln1118_1067_fu_54793_p2 = (!mul_ln1118_1067_fu_54793_p0.read().is_01() || !mul_ln1118_1067_fu_54793_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1067_fu_54793_p0.read()) * sc_bigint<5>(mul_ln1118_1067_fu_54793_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1068_fu_92985_p0() {
    mul_ln1118_1068_fu_92985_p0 =  (sc_lv<3>) (sext_ln1116_68_reg_106032.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1068_fu_92985_p1() {
    mul_ln1118_1068_fu_92985_p1 = tmp_1068_reg_109578.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1068_fu_92985_p2() {
    mul_ln1118_1068_fu_92985_p2 = (!mul_ln1118_1068_fu_92985_p0.read().is_01() || !mul_ln1118_1068_fu_92985_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1068_fu_92985_p0.read()) * sc_bigint<5>(mul_ln1118_1068_fu_92985_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1069_fu_54835_p0() {
    mul_ln1118_1069_fu_54835_p0 =  (sc_lv<3>) (sext_ln1116_69_fu_24159_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1069_fu_54835_p1() {
    mul_ln1118_1069_fu_54835_p1 = tmp_1069_fu_54821_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1069_fu_54835_p2() {
    mul_ln1118_1069_fu_54835_p2 = (!mul_ln1118_1069_fu_54835_p0.read().is_01() || !mul_ln1118_1069_fu_54835_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1069_fu_54835_p0.read()) * sc_bigint<5>(mul_ln1118_1069_fu_54835_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_106_fu_25595_p0() {
    mul_ln1118_106_fu_25595_p0 =  (sc_lv<3>) (sext_ln1116_106_fu_25587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_106_fu_25595_p1() {
    mul_ln1118_106_fu_25595_p1 = tmp_106_fu_25577_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_106_fu_25595_p2() {
    mul_ln1118_106_fu_25595_p2 = (!mul_ln1118_106_fu_25595_p0.read().is_01() || !mul_ln1118_106_fu_25595_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_106_fu_25595_p0.read()) * sc_bigint<5>(mul_ln1118_106_fu_25595_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1070_fu_54867_p0() {
    mul_ln1118_1070_fu_54867_p0 =  (sc_lv<3>) (sext_ln1116_70_fu_24203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1070_fu_54867_p1() {
    mul_ln1118_1070_fu_54867_p1 = tmp_1070_fu_54853_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1070_fu_54867_p2() {
    mul_ln1118_1070_fu_54867_p2 = (!mul_ln1118_1070_fu_54867_p0.read().is_01() || !mul_ln1118_1070_fu_54867_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1070_fu_54867_p0.read()) * sc_bigint<5>(mul_ln1118_1070_fu_54867_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1071_fu_93005_p0() {
    mul_ln1118_1071_fu_93005_p0 =  (sc_lv<3>) (sext_ln1116_71_reg_106050.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1071_fu_93005_p1() {
    mul_ln1118_1071_fu_93005_p1 = tmp_1071_reg_109583.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1071_fu_93005_p2() {
    mul_ln1118_1071_fu_93005_p2 = (!mul_ln1118_1071_fu_93005_p0.read().is_01() || !mul_ln1118_1071_fu_93005_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1071_fu_93005_p0.read()) * sc_bigint<5>(mul_ln1118_1071_fu_93005_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1072_fu_54909_p0() {
    mul_ln1118_1072_fu_54909_p0 =  (sc_lv<3>) (sext_ln1116_72_fu_24269_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1072_fu_54909_p1() {
    mul_ln1118_1072_fu_54909_p1 = tmp_1072_fu_54895_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1072_fu_54909_p2() {
    mul_ln1118_1072_fu_54909_p2 = (!mul_ln1118_1072_fu_54909_p0.read().is_01() || !mul_ln1118_1072_fu_54909_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1072_fu_54909_p0.read()) * sc_bigint<5>(mul_ln1118_1072_fu_54909_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1073_fu_54941_p0() {
    mul_ln1118_1073_fu_54941_p0 =  (sc_lv<3>) (sext_ln1116_73_fu_24313_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1073_fu_54941_p1() {
    mul_ln1118_1073_fu_54941_p1 = tmp_1073_fu_54927_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1073_fu_54941_p2() {
    mul_ln1118_1073_fu_54941_p2 = (!mul_ln1118_1073_fu_54941_p0.read().is_01() || !mul_ln1118_1073_fu_54941_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1073_fu_54941_p0.read()) * sc_bigint<5>(mul_ln1118_1073_fu_54941_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1074_fu_93025_p0() {
    mul_ln1118_1074_fu_93025_p0 =  (sc_lv<3>) (sext_ln1116_74_reg_106068.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1074_fu_93025_p1() {
    mul_ln1118_1074_fu_93025_p1 = tmp_1074_reg_109588.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1074_fu_93025_p2() {
    mul_ln1118_1074_fu_93025_p2 = (!mul_ln1118_1074_fu_93025_p0.read().is_01() || !mul_ln1118_1074_fu_93025_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1074_fu_93025_p0.read()) * sc_bigint<5>(mul_ln1118_1074_fu_93025_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1075_fu_54983_p0() {
    mul_ln1118_1075_fu_54983_p0 =  (sc_lv<3>) (sext_ln1116_75_fu_24379_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1075_fu_54983_p1() {
    mul_ln1118_1075_fu_54983_p1 = tmp_1075_fu_54969_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1075_fu_54983_p2() {
    mul_ln1118_1075_fu_54983_p2 = (!mul_ln1118_1075_fu_54983_p0.read().is_01() || !mul_ln1118_1075_fu_54983_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1075_fu_54983_p0.read()) * sc_bigint<5>(mul_ln1118_1075_fu_54983_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1076_fu_55015_p0() {
    mul_ln1118_1076_fu_55015_p0 =  (sc_lv<3>) (sext_ln1116_76_fu_24423_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1076_fu_55015_p1() {
    mul_ln1118_1076_fu_55015_p1 = tmp_1076_fu_55001_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1076_fu_55015_p2() {
    mul_ln1118_1076_fu_55015_p2 = (!mul_ln1118_1076_fu_55015_p0.read().is_01() || !mul_ln1118_1076_fu_55015_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1076_fu_55015_p0.read()) * sc_bigint<5>(mul_ln1118_1076_fu_55015_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1077_fu_93045_p0() {
    mul_ln1118_1077_fu_93045_p0 =  (sc_lv<3>) (sext_ln1116_77_reg_106086.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1077_fu_93045_p1() {
    mul_ln1118_1077_fu_93045_p1 = tmp_1077_reg_109593.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1077_fu_93045_p2() {
    mul_ln1118_1077_fu_93045_p2 = (!mul_ln1118_1077_fu_93045_p0.read().is_01() || !mul_ln1118_1077_fu_93045_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1077_fu_93045_p0.read()) * sc_bigint<5>(mul_ln1118_1077_fu_93045_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1078_fu_55057_p0() {
    mul_ln1118_1078_fu_55057_p0 =  (sc_lv<3>) (sext_ln1116_78_fu_24489_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1078_fu_55057_p1() {
    mul_ln1118_1078_fu_55057_p1 = tmp_1078_fu_55043_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1078_fu_55057_p2() {
    mul_ln1118_1078_fu_55057_p2 = (!mul_ln1118_1078_fu_55057_p0.read().is_01() || !mul_ln1118_1078_fu_55057_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1078_fu_55057_p0.read()) * sc_bigint<5>(mul_ln1118_1078_fu_55057_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1079_fu_55089_p0() {
    mul_ln1118_1079_fu_55089_p0 =  (sc_lv<3>) (sext_ln1116_79_fu_24533_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1079_fu_55089_p1() {
    mul_ln1118_1079_fu_55089_p1 = tmp_1079_fu_55075_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1079_fu_55089_p2() {
    mul_ln1118_1079_fu_55089_p2 = (!mul_ln1118_1079_fu_55089_p0.read().is_01() || !mul_ln1118_1079_fu_55089_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1079_fu_55089_p0.read()) * sc_bigint<5>(mul_ln1118_1079_fu_55089_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_107_fu_25639_p0() {
    mul_ln1118_107_fu_25639_p0 =  (sc_lv<3>) (sext_ln1116_107_fu_25631_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_107_fu_25639_p1() {
    mul_ln1118_107_fu_25639_p1 = tmp_107_fu_25621_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_107_fu_25639_p2() {
    mul_ln1118_107_fu_25639_p2 = (!mul_ln1118_107_fu_25639_p0.read().is_01() || !mul_ln1118_107_fu_25639_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_107_fu_25639_p0.read()) * sc_bigint<5>(mul_ln1118_107_fu_25639_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1080_fu_55121_p0() {
    mul_ln1118_1080_fu_55121_p0 =  (sc_lv<3>) (sext_ln1116_80_fu_24577_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1080_fu_55121_p1() {
    mul_ln1118_1080_fu_55121_p1 = tmp_1080_fu_55107_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1080_fu_55121_p2() {
    mul_ln1118_1080_fu_55121_p2 = (!mul_ln1118_1080_fu_55121_p0.read().is_01() || !mul_ln1118_1080_fu_55121_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1080_fu_55121_p0.read()) * sc_bigint<5>(mul_ln1118_1080_fu_55121_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1081_fu_55153_p0() {
    mul_ln1118_1081_fu_55153_p0 =  (sc_lv<3>) (sext_ln1116_81_fu_24621_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1081_fu_55153_p1() {
    mul_ln1118_1081_fu_55153_p1 = tmp_1081_fu_55139_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1081_fu_55153_p2() {
    mul_ln1118_1081_fu_55153_p2 = (!mul_ln1118_1081_fu_55153_p0.read().is_01() || !mul_ln1118_1081_fu_55153_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1081_fu_55153_p0.read()) * sc_bigint<5>(mul_ln1118_1081_fu_55153_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1082_fu_55185_p0() {
    mul_ln1118_1082_fu_55185_p0 =  (sc_lv<3>) (sext_ln1116_82_fu_24665_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1082_fu_55185_p1() {
    mul_ln1118_1082_fu_55185_p1 = tmp_1082_fu_55171_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1082_fu_55185_p2() {
    mul_ln1118_1082_fu_55185_p2 = (!mul_ln1118_1082_fu_55185_p0.read().is_01() || !mul_ln1118_1082_fu_55185_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1082_fu_55185_p0.read()) * sc_bigint<5>(mul_ln1118_1082_fu_55185_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1083_fu_55217_p0() {
    mul_ln1118_1083_fu_55217_p0 =  (sc_lv<3>) (sext_ln1116_83_fu_24709_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1083_fu_55217_p1() {
    mul_ln1118_1083_fu_55217_p1 = tmp_1083_fu_55203_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1083_fu_55217_p2() {
    mul_ln1118_1083_fu_55217_p2 = (!mul_ln1118_1083_fu_55217_p0.read().is_01() || !mul_ln1118_1083_fu_55217_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1083_fu_55217_p0.read()) * sc_bigint<5>(mul_ln1118_1083_fu_55217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1084_fu_55249_p0() {
    mul_ln1118_1084_fu_55249_p0 =  (sc_lv<3>) (sext_ln1116_84_fu_24753_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1084_fu_55249_p1() {
    mul_ln1118_1084_fu_55249_p1 = tmp_1084_fu_55235_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1084_fu_55249_p2() {
    mul_ln1118_1084_fu_55249_p2 = (!mul_ln1118_1084_fu_55249_p0.read().is_01() || !mul_ln1118_1084_fu_55249_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1084_fu_55249_p0.read()) * sc_bigint<5>(mul_ln1118_1084_fu_55249_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1085_fu_55269_p0() {
    mul_ln1118_1085_fu_55269_p0 =  (sc_lv<3>) (sext_ln1116_85_fu_24785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1085_fu_55269_p1() {
    mul_ln1118_1085_fu_55269_p1 = tmp_1085_fu_55255_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1085_fu_55269_p2() {
    mul_ln1118_1085_fu_55269_p2 = (!mul_ln1118_1085_fu_55269_p0.read().is_01() || !mul_ln1118_1085_fu_55269_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1085_fu_55269_p0.read()) * sc_bigint<5>(mul_ln1118_1085_fu_55269_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1086_fu_55301_p0() {
    mul_ln1118_1086_fu_55301_p0 =  (sc_lv<3>) (sext_ln1116_86_fu_24829_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1086_fu_55301_p1() {
    mul_ln1118_1086_fu_55301_p1 = tmp_1086_fu_55287_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1086_fu_55301_p2() {
    mul_ln1118_1086_fu_55301_p2 = (!mul_ln1118_1086_fu_55301_p0.read().is_01() || !mul_ln1118_1086_fu_55301_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1086_fu_55301_p0.read()) * sc_bigint<5>(mul_ln1118_1086_fu_55301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1087_fu_55333_p0() {
    mul_ln1118_1087_fu_55333_p0 =  (sc_lv<3>) (sext_ln1116_87_fu_24873_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1087_fu_55333_p1() {
    mul_ln1118_1087_fu_55333_p1 = tmp_1087_fu_55319_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1087_fu_55333_p2() {
    mul_ln1118_1087_fu_55333_p2 = (!mul_ln1118_1087_fu_55333_p0.read().is_01() || !mul_ln1118_1087_fu_55333_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1087_fu_55333_p0.read()) * sc_bigint<5>(mul_ln1118_1087_fu_55333_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1088_fu_55353_p0() {
    mul_ln1118_1088_fu_55353_p0 =  (sc_lv<3>) (sext_ln1116_88_fu_24905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1088_fu_55353_p1() {
    mul_ln1118_1088_fu_55353_p1 = tmp_1088_fu_55339_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1088_fu_55353_p2() {
    mul_ln1118_1088_fu_55353_p2 = (!mul_ln1118_1088_fu_55353_p0.read().is_01() || !mul_ln1118_1088_fu_55353_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1088_fu_55353_p0.read()) * sc_bigint<5>(mul_ln1118_1088_fu_55353_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1089_fu_55385_p0() {
    mul_ln1118_1089_fu_55385_p0 =  (sc_lv<3>) (sext_ln1116_89_fu_24949_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1089_fu_55385_p1() {
    mul_ln1118_1089_fu_55385_p1 = tmp_1089_fu_55371_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1089_fu_55385_p2() {
    mul_ln1118_1089_fu_55385_p2 = (!mul_ln1118_1089_fu_55385_p0.read().is_01() || !mul_ln1118_1089_fu_55385_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1089_fu_55385_p0.read()) * sc_bigint<5>(mul_ln1118_1089_fu_55385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_108_fu_25683_p0() {
    mul_ln1118_108_fu_25683_p0 =  (sc_lv<3>) (sext_ln1116_108_fu_25675_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_108_fu_25683_p1() {
    mul_ln1118_108_fu_25683_p1 = tmp_108_fu_25665_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_108_fu_25683_p2() {
    mul_ln1118_108_fu_25683_p2 = (!mul_ln1118_108_fu_25683_p0.read().is_01() || !mul_ln1118_108_fu_25683_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_108_fu_25683_p0.read()) * sc_bigint<5>(mul_ln1118_108_fu_25683_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1090_fu_93087_p0() {
    mul_ln1118_1090_fu_93087_p0 =  (sc_lv<3>) (sext_ln1116_90_reg_106114.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1090_fu_93087_p1() {
    mul_ln1118_1090_fu_93087_p1 = tmp_1090_reg_109608.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1090_fu_93087_p2() {
    mul_ln1118_1090_fu_93087_p2 = (!mul_ln1118_1090_fu_93087_p0.read().is_01() || !mul_ln1118_1090_fu_93087_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1090_fu_93087_p0.read()) * sc_bigint<5>(mul_ln1118_1090_fu_93087_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1091_fu_55427_p0() {
    mul_ln1118_1091_fu_55427_p0 =  (sc_lv<3>) (sext_ln1116_91_fu_25015_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1091_fu_55427_p1() {
    mul_ln1118_1091_fu_55427_p1 = tmp_1091_fu_55413_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1091_fu_55427_p2() {
    mul_ln1118_1091_fu_55427_p2 = (!mul_ln1118_1091_fu_55427_p0.read().is_01() || !mul_ln1118_1091_fu_55427_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1091_fu_55427_p0.read()) * sc_bigint<5>(mul_ln1118_1091_fu_55427_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1092_fu_55459_p0() {
    mul_ln1118_1092_fu_55459_p0 =  (sc_lv<3>) (sext_ln1116_92_fu_25059_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1092_fu_55459_p1() {
    mul_ln1118_1092_fu_55459_p1 = tmp_1092_fu_55445_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1092_fu_55459_p2() {
    mul_ln1118_1092_fu_55459_p2 = (!mul_ln1118_1092_fu_55459_p0.read().is_01() || !mul_ln1118_1092_fu_55459_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1092_fu_55459_p0.read()) * sc_bigint<5>(mul_ln1118_1092_fu_55459_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1093_fu_93107_p0() {
    mul_ln1118_1093_fu_93107_p0 =  (sc_lv<3>) (sext_ln1116_93_reg_106132.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1093_fu_93107_p1() {
    mul_ln1118_1093_fu_93107_p1 = tmp_1093_reg_109613.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1093_fu_93107_p2() {
    mul_ln1118_1093_fu_93107_p2 = (!mul_ln1118_1093_fu_93107_p0.read().is_01() || !mul_ln1118_1093_fu_93107_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1093_fu_93107_p0.read()) * sc_bigint<5>(mul_ln1118_1093_fu_93107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1094_fu_55501_p0() {
    mul_ln1118_1094_fu_55501_p0 =  (sc_lv<3>) (sext_ln1116_94_fu_25125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1094_fu_55501_p1() {
    mul_ln1118_1094_fu_55501_p1 = tmp_1094_fu_55487_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1094_fu_55501_p2() {
    mul_ln1118_1094_fu_55501_p2 = (!mul_ln1118_1094_fu_55501_p0.read().is_01() || !mul_ln1118_1094_fu_55501_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1094_fu_55501_p0.read()) * sc_bigint<5>(mul_ln1118_1094_fu_55501_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1095_fu_55533_p0() {
    mul_ln1118_1095_fu_55533_p0 =  (sc_lv<3>) (sext_ln1116_95_fu_25169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1095_fu_55533_p1() {
    mul_ln1118_1095_fu_55533_p1 = tmp_1095_fu_55519_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1095_fu_55533_p2() {
    mul_ln1118_1095_fu_55533_p2 = (!mul_ln1118_1095_fu_55533_p0.read().is_01() || !mul_ln1118_1095_fu_55533_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1095_fu_55533_p0.read()) * sc_bigint<5>(mul_ln1118_1095_fu_55533_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1096_fu_93127_p0() {
    mul_ln1118_1096_fu_93127_p0 =  (sc_lv<3>) (sext_ln1116_96_reg_106150.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1096_fu_93127_p1() {
    mul_ln1118_1096_fu_93127_p1 = tmp_1096_reg_109618.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1096_fu_93127_p2() {
    mul_ln1118_1096_fu_93127_p2 = (!mul_ln1118_1096_fu_93127_p0.read().is_01() || !mul_ln1118_1096_fu_93127_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1096_fu_93127_p0.read()) * sc_bigint<5>(mul_ln1118_1096_fu_93127_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1097_fu_55575_p0() {
    mul_ln1118_1097_fu_55575_p0 =  (sc_lv<3>) (sext_ln1116_97_fu_25235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1097_fu_55575_p1() {
    mul_ln1118_1097_fu_55575_p1 = tmp_1097_fu_55561_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1097_fu_55575_p2() {
    mul_ln1118_1097_fu_55575_p2 = (!mul_ln1118_1097_fu_55575_p0.read().is_01() || !mul_ln1118_1097_fu_55575_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1097_fu_55575_p0.read()) * sc_bigint<5>(mul_ln1118_1097_fu_55575_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1098_fu_55607_p0() {
    mul_ln1118_1098_fu_55607_p0 =  (sc_lv<3>) (sext_ln1116_98_fu_25279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1098_fu_55607_p1() {
    mul_ln1118_1098_fu_55607_p1 = tmp_1098_fu_55593_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1098_fu_55607_p2() {
    mul_ln1118_1098_fu_55607_p2 = (!mul_ln1118_1098_fu_55607_p0.read().is_01() || !mul_ln1118_1098_fu_55607_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1098_fu_55607_p0.read()) * sc_bigint<5>(mul_ln1118_1098_fu_55607_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1099_fu_93147_p0() {
    mul_ln1118_1099_fu_93147_p0 =  (sc_lv<3>) (sext_ln1116_99_reg_106168.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1099_fu_93147_p1() {
    mul_ln1118_1099_fu_93147_p1 = tmp_1099_reg_109623.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1099_fu_93147_p2() {
    mul_ln1118_1099_fu_93147_p2 = (!mul_ln1118_1099_fu_93147_p0.read().is_01() || !mul_ln1118_1099_fu_93147_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1099_fu_93147_p0.read()) * sc_bigint<5>(mul_ln1118_1099_fu_93147_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_109_fu_25727_p0() {
    mul_ln1118_109_fu_25727_p0 =  (sc_lv<3>) (sext_ln1116_109_fu_25719_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_109_fu_25727_p1() {
    mul_ln1118_109_fu_25727_p1 = tmp_109_fu_25709_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_109_fu_25727_p2() {
    mul_ln1118_109_fu_25727_p2 = (!mul_ln1118_109_fu_25727_p0.read().is_01() || !mul_ln1118_109_fu_25727_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_109_fu_25727_p0.read()) * sc_bigint<5>(mul_ln1118_109_fu_25727_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_10_fu_21895_p0() {
    mul_ln1118_10_fu_21895_p0 =  (sc_lv<3>) (sext_ln1116_10_fu_21887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_10_fu_21895_p1() {
    mul_ln1118_10_fu_21895_p1 = tmp_11_fu_21877_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_10_fu_21895_p2() {
    mul_ln1118_10_fu_21895_p2 = (!mul_ln1118_10_fu_21895_p0.read().is_01() || !mul_ln1118_10_fu_21895_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_10_fu_21895_p0.read()) * sc_bigint<5>(mul_ln1118_10_fu_21895_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1100_fu_55649_p0() {
    mul_ln1118_1100_fu_55649_p0 =  (sc_lv<3>) (sext_ln1116_100_fu_25345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1100_fu_55649_p1() {
    mul_ln1118_1100_fu_55649_p1 = tmp_1100_fu_55635_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1100_fu_55649_p2() {
    mul_ln1118_1100_fu_55649_p2 = (!mul_ln1118_1100_fu_55649_p0.read().is_01() || !mul_ln1118_1100_fu_55649_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1100_fu_55649_p0.read()) * sc_bigint<5>(mul_ln1118_1100_fu_55649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1101_fu_55681_p0() {
    mul_ln1118_1101_fu_55681_p0 =  (sc_lv<3>) (sext_ln1116_101_fu_25389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1101_fu_55681_p1() {
    mul_ln1118_1101_fu_55681_p1 = tmp_1101_fu_55667_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1101_fu_55681_p2() {
    mul_ln1118_1101_fu_55681_p2 = (!mul_ln1118_1101_fu_55681_p0.read().is_01() || !mul_ln1118_1101_fu_55681_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1101_fu_55681_p0.read()) * sc_bigint<5>(mul_ln1118_1101_fu_55681_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1102_fu_93167_p0() {
    mul_ln1118_1102_fu_93167_p0 =  (sc_lv<3>) (sext_ln1116_102_reg_106186.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1102_fu_93167_p1() {
    mul_ln1118_1102_fu_93167_p1 = tmp_1102_reg_109628.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1102_fu_93167_p2() {
    mul_ln1118_1102_fu_93167_p2 = (!mul_ln1118_1102_fu_93167_p0.read().is_01() || !mul_ln1118_1102_fu_93167_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1102_fu_93167_p0.read()) * sc_bigint<5>(mul_ln1118_1102_fu_93167_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1103_fu_55723_p0() {
    mul_ln1118_1103_fu_55723_p0 =  (sc_lv<3>) (sext_ln1116_103_fu_25455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1103_fu_55723_p1() {
    mul_ln1118_1103_fu_55723_p1 = tmp_1103_fu_55709_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1103_fu_55723_p2() {
    mul_ln1118_1103_fu_55723_p2 = (!mul_ln1118_1103_fu_55723_p0.read().is_01() || !mul_ln1118_1103_fu_55723_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1103_fu_55723_p0.read()) * sc_bigint<5>(mul_ln1118_1103_fu_55723_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1104_fu_55755_p0() {
    mul_ln1118_1104_fu_55755_p0 =  (sc_lv<3>) (sext_ln1116_104_fu_25499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1104_fu_55755_p1() {
    mul_ln1118_1104_fu_55755_p1 = tmp_1104_fu_55741_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1104_fu_55755_p2() {
    mul_ln1118_1104_fu_55755_p2 = (!mul_ln1118_1104_fu_55755_p0.read().is_01() || !mul_ln1118_1104_fu_55755_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1104_fu_55755_p0.read()) * sc_bigint<5>(mul_ln1118_1104_fu_55755_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1105_fu_55787_p0() {
    mul_ln1118_1105_fu_55787_p0 =  (sc_lv<3>) (sext_ln1116_105_fu_25543_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1105_fu_55787_p1() {
    mul_ln1118_1105_fu_55787_p1 = tmp_1105_fu_55773_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1105_fu_55787_p2() {
    mul_ln1118_1105_fu_55787_p2 = (!mul_ln1118_1105_fu_55787_p0.read().is_01() || !mul_ln1118_1105_fu_55787_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1105_fu_55787_p0.read()) * sc_bigint<5>(mul_ln1118_1105_fu_55787_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1106_fu_55819_p0() {
    mul_ln1118_1106_fu_55819_p0 =  (sc_lv<3>) (sext_ln1116_106_fu_25587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1106_fu_55819_p1() {
    mul_ln1118_1106_fu_55819_p1 = tmp_1106_fu_55805_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1106_fu_55819_p2() {
    mul_ln1118_1106_fu_55819_p2 = (!mul_ln1118_1106_fu_55819_p0.read().is_01() || !mul_ln1118_1106_fu_55819_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1106_fu_55819_p0.read()) * sc_bigint<5>(mul_ln1118_1106_fu_55819_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1107_fu_55851_p0() {
    mul_ln1118_1107_fu_55851_p0 =  (sc_lv<3>) (sext_ln1116_107_fu_25631_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1107_fu_55851_p1() {
    mul_ln1118_1107_fu_55851_p1 = tmp_1107_fu_55837_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1107_fu_55851_p2() {
    mul_ln1118_1107_fu_55851_p2 = (!mul_ln1118_1107_fu_55851_p0.read().is_01() || !mul_ln1118_1107_fu_55851_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1107_fu_55851_p0.read()) * sc_bigint<5>(mul_ln1118_1107_fu_55851_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1108_fu_55883_p0() {
    mul_ln1118_1108_fu_55883_p0 =  (sc_lv<3>) (sext_ln1116_108_fu_25675_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1108_fu_55883_p1() {
    mul_ln1118_1108_fu_55883_p1 = tmp_1108_fu_55869_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1108_fu_55883_p2() {
    mul_ln1118_1108_fu_55883_p2 = (!mul_ln1118_1108_fu_55883_p0.read().is_01() || !mul_ln1118_1108_fu_55883_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1108_fu_55883_p0.read()) * sc_bigint<5>(mul_ln1118_1108_fu_55883_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1109_fu_55915_p0() {
    mul_ln1118_1109_fu_55915_p0 =  (sc_lv<3>) (sext_ln1116_109_fu_25719_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1109_fu_55915_p1() {
    mul_ln1118_1109_fu_55915_p1 = tmp_1109_fu_55901_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1109_fu_55915_p2() {
    mul_ln1118_1109_fu_55915_p2 = (!mul_ln1118_1109_fu_55915_p0.read().is_01() || !mul_ln1118_1109_fu_55915_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1109_fu_55915_p0.read()) * sc_bigint<5>(mul_ln1118_1109_fu_55915_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_110_fu_25759_p0() {
    mul_ln1118_110_fu_25759_p0 =  (sc_lv<3>) (sext_ln1116_110_fu_25751_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_110_fu_25759_p1() {
    mul_ln1118_110_fu_25759_p1 = tmp_110_fu_25741_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_110_fu_25759_p2() {
    mul_ln1118_110_fu_25759_p2 = (!mul_ln1118_110_fu_25759_p0.read().is_01() || !mul_ln1118_110_fu_25759_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_110_fu_25759_p0.read()) * sc_bigint<5>(mul_ln1118_110_fu_25759_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1110_fu_55935_p0() {
    mul_ln1118_1110_fu_55935_p0 =  (sc_lv<3>) (sext_ln1116_110_fu_25751_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1110_fu_55935_p1() {
    mul_ln1118_1110_fu_55935_p1 = tmp_1110_fu_55921_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1110_fu_55935_p2() {
    mul_ln1118_1110_fu_55935_p2 = (!mul_ln1118_1110_fu_55935_p0.read().is_01() || !mul_ln1118_1110_fu_55935_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1110_fu_55935_p0.read()) * sc_bigint<5>(mul_ln1118_1110_fu_55935_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1111_fu_55967_p0() {
    mul_ln1118_1111_fu_55967_p0 =  (sc_lv<3>) (sext_ln1116_111_fu_25795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1111_fu_55967_p1() {
    mul_ln1118_1111_fu_55967_p1 = tmp_1111_fu_55953_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1111_fu_55967_p2() {
    mul_ln1118_1111_fu_55967_p2 = (!mul_ln1118_1111_fu_55967_p0.read().is_01() || !mul_ln1118_1111_fu_55967_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1111_fu_55967_p0.read()) * sc_bigint<5>(mul_ln1118_1111_fu_55967_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1112_fu_55999_p0() {
    mul_ln1118_1112_fu_55999_p0 =  (sc_lv<3>) (sext_ln1116_112_fu_25839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1112_fu_55999_p1() {
    mul_ln1118_1112_fu_55999_p1 = tmp_1112_fu_55985_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1112_fu_55999_p2() {
    mul_ln1118_1112_fu_55999_p2 = (!mul_ln1118_1112_fu_55999_p0.read().is_01() || !mul_ln1118_1112_fu_55999_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1112_fu_55999_p0.read()) * sc_bigint<5>(mul_ln1118_1112_fu_55999_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1113_fu_56019_p0() {
    mul_ln1118_1113_fu_56019_p0 =  (sc_lv<3>) (sext_ln1116_113_fu_25871_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1113_fu_56019_p1() {
    mul_ln1118_1113_fu_56019_p1 = tmp_1113_fu_56005_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1113_fu_56019_p2() {
    mul_ln1118_1113_fu_56019_p2 = (!mul_ln1118_1113_fu_56019_p0.read().is_01() || !mul_ln1118_1113_fu_56019_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1113_fu_56019_p0.read()) * sc_bigint<5>(mul_ln1118_1113_fu_56019_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1114_fu_56051_p0() {
    mul_ln1118_1114_fu_56051_p0 =  (sc_lv<3>) (sext_ln1116_114_fu_25915_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1114_fu_56051_p1() {
    mul_ln1118_1114_fu_56051_p1 = tmp_1114_fu_56037_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1114_fu_56051_p2() {
    mul_ln1118_1114_fu_56051_p2 = (!mul_ln1118_1114_fu_56051_p0.read().is_01() || !mul_ln1118_1114_fu_56051_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1114_fu_56051_p0.read()) * sc_bigint<5>(mul_ln1118_1114_fu_56051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1115_fu_93209_p0() {
    mul_ln1118_1115_fu_93209_p0 =  (sc_lv<3>) (sext_ln1116_115_reg_106214.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1115_fu_93209_p1() {
    mul_ln1118_1115_fu_93209_p1 = tmp_1115_reg_109643.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1115_fu_93209_p2() {
    mul_ln1118_1115_fu_93209_p2 = (!mul_ln1118_1115_fu_93209_p0.read().is_01() || !mul_ln1118_1115_fu_93209_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1115_fu_93209_p0.read()) * sc_bigint<5>(mul_ln1118_1115_fu_93209_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1116_fu_56093_p0() {
    mul_ln1118_1116_fu_56093_p0 =  (sc_lv<3>) (sext_ln1116_116_fu_25981_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1116_fu_56093_p1() {
    mul_ln1118_1116_fu_56093_p1 = tmp_1116_fu_56079_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1116_fu_56093_p2() {
    mul_ln1118_1116_fu_56093_p2 = (!mul_ln1118_1116_fu_56093_p0.read().is_01() || !mul_ln1118_1116_fu_56093_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1116_fu_56093_p0.read()) * sc_bigint<5>(mul_ln1118_1116_fu_56093_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1117_fu_56125_p0() {
    mul_ln1118_1117_fu_56125_p0 =  (sc_lv<3>) (sext_ln1116_117_fu_26025_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1117_fu_56125_p1() {
    mul_ln1118_1117_fu_56125_p1 = tmp_1117_fu_56111_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1117_fu_56125_p2() {
    mul_ln1118_1117_fu_56125_p2 = (!mul_ln1118_1117_fu_56125_p0.read().is_01() || !mul_ln1118_1117_fu_56125_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1117_fu_56125_p0.read()) * sc_bigint<5>(mul_ln1118_1117_fu_56125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1118_fu_93229_p0() {
    mul_ln1118_1118_fu_93229_p0 =  (sc_lv<3>) (sext_ln1116_118_reg_106232.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1118_fu_93229_p1() {
    mul_ln1118_1118_fu_93229_p1 = tmp_1118_reg_109648.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1118_fu_93229_p2() {
    mul_ln1118_1118_fu_93229_p2 = (!mul_ln1118_1118_fu_93229_p0.read().is_01() || !mul_ln1118_1118_fu_93229_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1118_fu_93229_p0.read()) * sc_bigint<5>(mul_ln1118_1118_fu_93229_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1119_fu_56167_p0() {
    mul_ln1118_1119_fu_56167_p0 =  (sc_lv<3>) (sext_ln1116_119_fu_26091_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1119_fu_56167_p1() {
    mul_ln1118_1119_fu_56167_p1 = tmp_1119_fu_56153_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1119_fu_56167_p2() {
    mul_ln1118_1119_fu_56167_p2 = (!mul_ln1118_1119_fu_56167_p0.read().is_01() || !mul_ln1118_1119_fu_56167_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1119_fu_56167_p0.read()) * sc_bigint<5>(mul_ln1118_1119_fu_56167_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_111_fu_25803_p0() {
    mul_ln1118_111_fu_25803_p0 =  (sc_lv<3>) (sext_ln1116_111_fu_25795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_111_fu_25803_p1() {
    mul_ln1118_111_fu_25803_p1 = tmp_111_fu_25785_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_111_fu_25803_p2() {
    mul_ln1118_111_fu_25803_p2 = (!mul_ln1118_111_fu_25803_p0.read().is_01() || !mul_ln1118_111_fu_25803_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_111_fu_25803_p0.read()) * sc_bigint<5>(mul_ln1118_111_fu_25803_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1120_fu_56199_p0() {
    mul_ln1118_1120_fu_56199_p0 =  (sc_lv<3>) (sext_ln1116_120_fu_26135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1120_fu_56199_p1() {
    mul_ln1118_1120_fu_56199_p1 = tmp_1120_fu_56185_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1120_fu_56199_p2() {
    mul_ln1118_1120_fu_56199_p2 = (!mul_ln1118_1120_fu_56199_p0.read().is_01() || !mul_ln1118_1120_fu_56199_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1120_fu_56199_p0.read()) * sc_bigint<5>(mul_ln1118_1120_fu_56199_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1121_fu_93249_p0() {
    mul_ln1118_1121_fu_93249_p0 =  (sc_lv<3>) (sext_ln1116_121_reg_106250.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1121_fu_93249_p1() {
    mul_ln1118_1121_fu_93249_p1 = tmp_1121_reg_109653.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1121_fu_93249_p2() {
    mul_ln1118_1121_fu_93249_p2 = (!mul_ln1118_1121_fu_93249_p0.read().is_01() || !mul_ln1118_1121_fu_93249_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1121_fu_93249_p0.read()) * sc_bigint<5>(mul_ln1118_1121_fu_93249_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1122_fu_56241_p0() {
    mul_ln1118_1122_fu_56241_p0 =  (sc_lv<3>) (sext_ln1116_122_fu_26201_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1122_fu_56241_p1() {
    mul_ln1118_1122_fu_56241_p1 = tmp_1122_fu_56227_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1122_fu_56241_p2() {
    mul_ln1118_1122_fu_56241_p2 = (!mul_ln1118_1122_fu_56241_p0.read().is_01() || !mul_ln1118_1122_fu_56241_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1122_fu_56241_p0.read()) * sc_bigint<5>(mul_ln1118_1122_fu_56241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1123_fu_56273_p0() {
    mul_ln1118_1123_fu_56273_p0 =  (sc_lv<3>) (sext_ln1116_123_fu_26245_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1123_fu_56273_p1() {
    mul_ln1118_1123_fu_56273_p1 = tmp_1123_fu_56259_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1123_fu_56273_p2() {
    mul_ln1118_1123_fu_56273_p2 = (!mul_ln1118_1123_fu_56273_p0.read().is_01() || !mul_ln1118_1123_fu_56273_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1123_fu_56273_p0.read()) * sc_bigint<5>(mul_ln1118_1123_fu_56273_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1124_fu_93269_p0() {
    mul_ln1118_1124_fu_93269_p0 =  (sc_lv<3>) (sext_ln1116_124_reg_106268.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1124_fu_93269_p1() {
    mul_ln1118_1124_fu_93269_p1 = tmp_1124_reg_109658.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1124_fu_93269_p2() {
    mul_ln1118_1124_fu_93269_p2 = (!mul_ln1118_1124_fu_93269_p0.read().is_01() || !mul_ln1118_1124_fu_93269_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1124_fu_93269_p0.read()) * sc_bigint<5>(mul_ln1118_1124_fu_93269_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1125_fu_56315_p0() {
    mul_ln1118_1125_fu_56315_p0 =  (sc_lv<3>) (sext_ln1116_125_fu_26311_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1125_fu_56315_p1() {
    mul_ln1118_1125_fu_56315_p1 = tmp_1125_fu_56301_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1125_fu_56315_p2() {
    mul_ln1118_1125_fu_56315_p2 = (!mul_ln1118_1125_fu_56315_p0.read().is_01() || !mul_ln1118_1125_fu_56315_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1125_fu_56315_p0.read()) * sc_bigint<5>(mul_ln1118_1125_fu_56315_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1126_fu_56347_p0() {
    mul_ln1118_1126_fu_56347_p0 =  (sc_lv<3>) (sext_ln1116_126_fu_26355_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1126_fu_56347_p1() {
    mul_ln1118_1126_fu_56347_p1 = tmp_1126_fu_56333_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1126_fu_56347_p2() {
    mul_ln1118_1126_fu_56347_p2 = (!mul_ln1118_1126_fu_56347_p0.read().is_01() || !mul_ln1118_1126_fu_56347_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1126_fu_56347_p0.read()) * sc_bigint<5>(mul_ln1118_1126_fu_56347_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1127_fu_93289_p0() {
    mul_ln1118_1127_fu_93289_p0 =  (sc_lv<3>) (sext_ln1116_127_reg_106286.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1127_fu_93289_p1() {
    mul_ln1118_1127_fu_93289_p1 = tmp_1127_reg_109663.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1127_fu_93289_p2() {
    mul_ln1118_1127_fu_93289_p2 = (!mul_ln1118_1127_fu_93289_p0.read().is_01() || !mul_ln1118_1127_fu_93289_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1127_fu_93289_p0.read()) * sc_bigint<5>(mul_ln1118_1127_fu_93289_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1128_fu_56389_p0() {
    mul_ln1118_1128_fu_56389_p0 =  (sc_lv<3>) (sext_ln1116_128_fu_26421_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1128_fu_56389_p1() {
    mul_ln1118_1128_fu_56389_p1 = tmp_1128_fu_56375_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1128_fu_56389_p2() {
    mul_ln1118_1128_fu_56389_p2 = (!mul_ln1118_1128_fu_56389_p0.read().is_01() || !mul_ln1118_1128_fu_56389_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1128_fu_56389_p0.read()) * sc_bigint<5>(mul_ln1118_1128_fu_56389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1129_fu_56421_p0() {
    mul_ln1118_1129_fu_56421_p0 =  (sc_lv<3>) (sext_ln1116_129_fu_26465_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1129_fu_56421_p1() {
    mul_ln1118_1129_fu_56421_p1 = tmp_1129_fu_56407_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1129_fu_56421_p2() {
    mul_ln1118_1129_fu_56421_p2 = (!mul_ln1118_1129_fu_56421_p0.read().is_01() || !mul_ln1118_1129_fu_56421_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1129_fu_56421_p0.read()) * sc_bigint<5>(mul_ln1118_1129_fu_56421_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_112_fu_25847_p0() {
    mul_ln1118_112_fu_25847_p0 =  (sc_lv<3>) (sext_ln1116_112_fu_25839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_112_fu_25847_p1() {
    mul_ln1118_112_fu_25847_p1 = tmp_112_fu_25829_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_112_fu_25847_p2() {
    mul_ln1118_112_fu_25847_p2 = (!mul_ln1118_112_fu_25847_p0.read().is_01() || !mul_ln1118_112_fu_25847_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_112_fu_25847_p0.read()) * sc_bigint<5>(mul_ln1118_112_fu_25847_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1130_fu_56453_p0() {
    mul_ln1118_1130_fu_56453_p0 =  (sc_lv<3>) (sext_ln1116_130_fu_26509_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1130_fu_56453_p1() {
    mul_ln1118_1130_fu_56453_p1 = tmp_1130_fu_56439_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1130_fu_56453_p2() {
    mul_ln1118_1130_fu_56453_p2 = (!mul_ln1118_1130_fu_56453_p0.read().is_01() || !mul_ln1118_1130_fu_56453_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1130_fu_56453_p0.read()) * sc_bigint<5>(mul_ln1118_1130_fu_56453_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1131_fu_56485_p0() {
    mul_ln1118_1131_fu_56485_p0 =  (sc_lv<3>) (sext_ln1116_131_fu_26553_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1131_fu_56485_p1() {
    mul_ln1118_1131_fu_56485_p1 = tmp_1131_fu_56471_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1131_fu_56485_p2() {
    mul_ln1118_1131_fu_56485_p2 = (!mul_ln1118_1131_fu_56485_p0.read().is_01() || !mul_ln1118_1131_fu_56485_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1131_fu_56485_p0.read()) * sc_bigint<5>(mul_ln1118_1131_fu_56485_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1132_fu_56517_p0() {
    mul_ln1118_1132_fu_56517_p0 =  (sc_lv<3>) (sext_ln1116_132_fu_26597_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1132_fu_56517_p1() {
    mul_ln1118_1132_fu_56517_p1 = tmp_1132_fu_56503_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1132_fu_56517_p2() {
    mul_ln1118_1132_fu_56517_p2 = (!mul_ln1118_1132_fu_56517_p0.read().is_01() || !mul_ln1118_1132_fu_56517_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1132_fu_56517_p0.read()) * sc_bigint<5>(mul_ln1118_1132_fu_56517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1133_fu_56549_p0() {
    mul_ln1118_1133_fu_56549_p0 =  (sc_lv<3>) (sext_ln1116_133_fu_26641_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1133_fu_56549_p1() {
    mul_ln1118_1133_fu_56549_p1 = tmp_1133_fu_56535_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1133_fu_56549_p2() {
    mul_ln1118_1133_fu_56549_p2 = (!mul_ln1118_1133_fu_56549_p0.read().is_01() || !mul_ln1118_1133_fu_56549_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1133_fu_56549_p0.read()) * sc_bigint<5>(mul_ln1118_1133_fu_56549_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1134_fu_56581_p0() {
    mul_ln1118_1134_fu_56581_p0 =  (sc_lv<3>) (sext_ln1116_134_fu_26685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1134_fu_56581_p1() {
    mul_ln1118_1134_fu_56581_p1 = tmp_1134_fu_56567_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1134_fu_56581_p2() {
    mul_ln1118_1134_fu_56581_p2 = (!mul_ln1118_1134_fu_56581_p0.read().is_01() || !mul_ln1118_1134_fu_56581_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1134_fu_56581_p0.read()) * sc_bigint<5>(mul_ln1118_1134_fu_56581_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1135_fu_56601_p0() {
    mul_ln1118_1135_fu_56601_p0 =  (sc_lv<3>) (sext_ln1116_135_fu_26717_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1135_fu_56601_p1() {
    mul_ln1118_1135_fu_56601_p1 = tmp_1135_fu_56587_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1135_fu_56601_p2() {
    mul_ln1118_1135_fu_56601_p2 = (!mul_ln1118_1135_fu_56601_p0.read().is_01() || !mul_ln1118_1135_fu_56601_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1135_fu_56601_p0.read()) * sc_bigint<5>(mul_ln1118_1135_fu_56601_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1136_fu_56633_p0() {
    mul_ln1118_1136_fu_56633_p0 =  (sc_lv<3>) (sext_ln1116_136_fu_26761_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1136_fu_56633_p1() {
    mul_ln1118_1136_fu_56633_p1 = tmp_1136_fu_56619_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1136_fu_56633_p2() {
    mul_ln1118_1136_fu_56633_p2 = (!mul_ln1118_1136_fu_56633_p0.read().is_01() || !mul_ln1118_1136_fu_56633_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1136_fu_56633_p0.read()) * sc_bigint<5>(mul_ln1118_1136_fu_56633_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1137_fu_56665_p0() {
    mul_ln1118_1137_fu_56665_p0 =  (sc_lv<3>) (sext_ln1116_137_fu_26805_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1137_fu_56665_p1() {
    mul_ln1118_1137_fu_56665_p1 = tmp_1137_fu_56651_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1137_fu_56665_p2() {
    mul_ln1118_1137_fu_56665_p2 = (!mul_ln1118_1137_fu_56665_p0.read().is_01() || !mul_ln1118_1137_fu_56665_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1137_fu_56665_p0.read()) * sc_bigint<5>(mul_ln1118_1137_fu_56665_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1138_fu_56685_p0() {
    mul_ln1118_1138_fu_56685_p0 =  (sc_lv<3>) (sext_ln1116_138_fu_26837_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1138_fu_56685_p1() {
    mul_ln1118_1138_fu_56685_p1 = tmp_1138_fu_56671_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1138_fu_56685_p2() {
    mul_ln1118_1138_fu_56685_p2 = (!mul_ln1118_1138_fu_56685_p0.read().is_01() || !mul_ln1118_1138_fu_56685_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1138_fu_56685_p0.read()) * sc_bigint<5>(mul_ln1118_1138_fu_56685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1139_fu_56717_p0() {
    mul_ln1118_1139_fu_56717_p0 =  (sc_lv<3>) (sext_ln1116_139_fu_26881_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1139_fu_56717_p1() {
    mul_ln1118_1139_fu_56717_p1 = tmp_1139_fu_56703_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1139_fu_56717_p2() {
    mul_ln1118_1139_fu_56717_p2 = (!mul_ln1118_1139_fu_56717_p0.read().is_01() || !mul_ln1118_1139_fu_56717_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1139_fu_56717_p0.read()) * sc_bigint<5>(mul_ln1118_1139_fu_56717_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_113_fu_25879_p0() {
    mul_ln1118_113_fu_25879_p0 =  (sc_lv<3>) (sext_ln1116_113_fu_25871_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_113_fu_25879_p1() {
    mul_ln1118_113_fu_25879_p1 = tmp_113_fu_25861_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_113_fu_25879_p2() {
    mul_ln1118_113_fu_25879_p2 = (!mul_ln1118_113_fu_25879_p0.read().is_01() || !mul_ln1118_113_fu_25879_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_113_fu_25879_p0.read()) * sc_bigint<5>(mul_ln1118_113_fu_25879_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1140_fu_93331_p0() {
    mul_ln1118_1140_fu_93331_p0 =  (sc_lv<3>) (sext_ln1116_140_reg_106314.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1140_fu_93331_p1() {
    mul_ln1118_1140_fu_93331_p1 = tmp_1140_reg_109678.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1140_fu_93331_p2() {
    mul_ln1118_1140_fu_93331_p2 = (!mul_ln1118_1140_fu_93331_p0.read().is_01() || !mul_ln1118_1140_fu_93331_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1140_fu_93331_p0.read()) * sc_bigint<5>(mul_ln1118_1140_fu_93331_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1141_fu_56759_p0() {
    mul_ln1118_1141_fu_56759_p0 =  (sc_lv<3>) (sext_ln1116_141_fu_26947_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1141_fu_56759_p1() {
    mul_ln1118_1141_fu_56759_p1 = tmp_1141_fu_56745_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1141_fu_56759_p2() {
    mul_ln1118_1141_fu_56759_p2 = (!mul_ln1118_1141_fu_56759_p0.read().is_01() || !mul_ln1118_1141_fu_56759_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1141_fu_56759_p0.read()) * sc_bigint<5>(mul_ln1118_1141_fu_56759_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1142_fu_56791_p0() {
    mul_ln1118_1142_fu_56791_p0 =  (sc_lv<3>) (sext_ln1116_142_fu_26991_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1142_fu_56791_p1() {
    mul_ln1118_1142_fu_56791_p1 = tmp_1142_fu_56777_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1142_fu_56791_p2() {
    mul_ln1118_1142_fu_56791_p2 = (!mul_ln1118_1142_fu_56791_p0.read().is_01() || !mul_ln1118_1142_fu_56791_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1142_fu_56791_p0.read()) * sc_bigint<5>(mul_ln1118_1142_fu_56791_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1143_fu_93351_p0() {
    mul_ln1118_1143_fu_93351_p0 =  (sc_lv<3>) (sext_ln1116_143_reg_106332.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1143_fu_93351_p1() {
    mul_ln1118_1143_fu_93351_p1 = tmp_1143_reg_109683.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1143_fu_93351_p2() {
    mul_ln1118_1143_fu_93351_p2 = (!mul_ln1118_1143_fu_93351_p0.read().is_01() || !mul_ln1118_1143_fu_93351_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1143_fu_93351_p0.read()) * sc_bigint<5>(mul_ln1118_1143_fu_93351_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1144_fu_56833_p0() {
    mul_ln1118_1144_fu_56833_p0 =  (sc_lv<3>) (sext_ln1116_144_fu_27057_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1144_fu_56833_p1() {
    mul_ln1118_1144_fu_56833_p1 = tmp_1144_fu_56819_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1144_fu_56833_p2() {
    mul_ln1118_1144_fu_56833_p2 = (!mul_ln1118_1144_fu_56833_p0.read().is_01() || !mul_ln1118_1144_fu_56833_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1144_fu_56833_p0.read()) * sc_bigint<5>(mul_ln1118_1144_fu_56833_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1145_fu_56865_p0() {
    mul_ln1118_1145_fu_56865_p0 =  (sc_lv<3>) (sext_ln1116_145_fu_27101_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1145_fu_56865_p1() {
    mul_ln1118_1145_fu_56865_p1 = tmp_1145_fu_56851_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1145_fu_56865_p2() {
    mul_ln1118_1145_fu_56865_p2 = (!mul_ln1118_1145_fu_56865_p0.read().is_01() || !mul_ln1118_1145_fu_56865_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1145_fu_56865_p0.read()) * sc_bigint<5>(mul_ln1118_1145_fu_56865_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1146_fu_56897_p0() {
    mul_ln1118_1146_fu_56897_p0 =  (sc_lv<3>) (sext_ln1116_146_fu_27145_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1146_fu_56897_p1() {
    mul_ln1118_1146_fu_56897_p1 = tmp_1146_fu_56883_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1146_fu_56897_p2() {
    mul_ln1118_1146_fu_56897_p2 = (!mul_ln1118_1146_fu_56897_p0.read().is_01() || !mul_ln1118_1146_fu_56897_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1146_fu_56897_p0.read()) * sc_bigint<5>(mul_ln1118_1146_fu_56897_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1147_fu_56917_p0() {
    mul_ln1118_1147_fu_56917_p0 =  (sc_lv<3>) (sext_ln1116_147_fu_27177_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1147_fu_56917_p1() {
    mul_ln1118_1147_fu_56917_p1 = tmp_1147_fu_56903_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1147_fu_56917_p2() {
    mul_ln1118_1147_fu_56917_p2 = (!mul_ln1118_1147_fu_56917_p0.read().is_01() || !mul_ln1118_1147_fu_56917_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1147_fu_56917_p0.read()) * sc_bigint<5>(mul_ln1118_1147_fu_56917_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1148_fu_56949_p0() {
    mul_ln1118_1148_fu_56949_p0 =  (sc_lv<3>) (sext_ln1116_148_fu_27221_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1148_fu_56949_p1() {
    mul_ln1118_1148_fu_56949_p1 = tmp_1148_fu_56935_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1148_fu_56949_p2() {
    mul_ln1118_1148_fu_56949_p2 = (!mul_ln1118_1148_fu_56949_p0.read().is_01() || !mul_ln1118_1148_fu_56949_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1148_fu_56949_p0.read()) * sc_bigint<5>(mul_ln1118_1148_fu_56949_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1149_fu_56981_p0() {
    mul_ln1118_1149_fu_56981_p0 =  (sc_lv<3>) (sext_ln1116_149_fu_27265_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1149_fu_56981_p1() {
    mul_ln1118_1149_fu_56981_p1 = tmp_1149_fu_56967_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1149_fu_56981_p2() {
    mul_ln1118_1149_fu_56981_p2 = (!mul_ln1118_1149_fu_56981_p0.read().is_01() || !mul_ln1118_1149_fu_56981_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1149_fu_56981_p0.read()) * sc_bigint<5>(mul_ln1118_1149_fu_56981_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_114_fu_25923_p0() {
    mul_ln1118_114_fu_25923_p0 =  (sc_lv<3>) (sext_ln1116_114_fu_25915_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_114_fu_25923_p1() {
    mul_ln1118_114_fu_25923_p1 = tmp_114_fu_25905_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_114_fu_25923_p2() {
    mul_ln1118_114_fu_25923_p2 = (!mul_ln1118_114_fu_25923_p0.read().is_01() || !mul_ln1118_114_fu_25923_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_114_fu_25923_p0.read()) * sc_bigint<5>(mul_ln1118_114_fu_25923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1150_fu_57001_p0() {
    mul_ln1118_1150_fu_57001_p0 =  (sc_lv<3>) (sext_ln1116_150_fu_27297_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1150_fu_57001_p1() {
    mul_ln1118_1150_fu_57001_p1 = tmp_1150_fu_56987_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1150_fu_57001_p2() {
    mul_ln1118_1150_fu_57001_p2 = (!mul_ln1118_1150_fu_57001_p0.read().is_01() || !mul_ln1118_1150_fu_57001_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1150_fu_57001_p0.read()) * sc_bigint<5>(mul_ln1118_1150_fu_57001_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1151_fu_57033_p0() {
    mul_ln1118_1151_fu_57033_p0 =  (sc_lv<3>) (sext_ln1116_151_fu_27341_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1151_fu_57033_p1() {
    mul_ln1118_1151_fu_57033_p1 = tmp_1151_fu_57019_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1151_fu_57033_p2() {
    mul_ln1118_1151_fu_57033_p2 = (!mul_ln1118_1151_fu_57033_p0.read().is_01() || !mul_ln1118_1151_fu_57033_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1151_fu_57033_p0.read()) * sc_bigint<5>(mul_ln1118_1151_fu_57033_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1152_fu_93393_p0() {
    mul_ln1118_1152_fu_93393_p0 =  (sc_lv<3>) (sext_ln1116_152_reg_106360.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1152_fu_93393_p1() {
    mul_ln1118_1152_fu_93393_p1 = tmp_1152_reg_109698.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1152_fu_93393_p2() {
    mul_ln1118_1152_fu_93393_p2 = (!mul_ln1118_1152_fu_93393_p0.read().is_01() || !mul_ln1118_1152_fu_93393_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1152_fu_93393_p0.read()) * sc_bigint<5>(mul_ln1118_1152_fu_93393_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1153_fu_57075_p0() {
    mul_ln1118_1153_fu_57075_p0 =  (sc_lv<3>) (sext_ln1116_153_fu_27407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1153_fu_57075_p1() {
    mul_ln1118_1153_fu_57075_p1 = tmp_1153_fu_57061_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1153_fu_57075_p2() {
    mul_ln1118_1153_fu_57075_p2 = (!mul_ln1118_1153_fu_57075_p0.read().is_01() || !mul_ln1118_1153_fu_57075_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1153_fu_57075_p0.read()) * sc_bigint<5>(mul_ln1118_1153_fu_57075_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1154_fu_57107_p0() {
    mul_ln1118_1154_fu_57107_p0 =  (sc_lv<3>) (sext_ln1116_154_fu_27451_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1154_fu_57107_p1() {
    mul_ln1118_1154_fu_57107_p1 = tmp_1154_fu_57093_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1154_fu_57107_p2() {
    mul_ln1118_1154_fu_57107_p2 = (!mul_ln1118_1154_fu_57107_p0.read().is_01() || !mul_ln1118_1154_fu_57107_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1154_fu_57107_p0.read()) * sc_bigint<5>(mul_ln1118_1154_fu_57107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1155_fu_57139_p0() {
    mul_ln1118_1155_fu_57139_p0 =  (sc_lv<3>) (sext_ln1116_155_fu_27495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1155_fu_57139_p1() {
    mul_ln1118_1155_fu_57139_p1 = tmp_1155_fu_57125_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1155_fu_57139_p2() {
    mul_ln1118_1155_fu_57139_p2 = (!mul_ln1118_1155_fu_57139_p0.read().is_01() || !mul_ln1118_1155_fu_57139_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1155_fu_57139_p0.read()) * sc_bigint<5>(mul_ln1118_1155_fu_57139_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1156_fu_57171_p0() {
    mul_ln1118_1156_fu_57171_p0 =  (sc_lv<3>) (sext_ln1116_156_fu_27539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1156_fu_57171_p1() {
    mul_ln1118_1156_fu_57171_p1 = tmp_1156_fu_57157_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1156_fu_57171_p2() {
    mul_ln1118_1156_fu_57171_p2 = (!mul_ln1118_1156_fu_57171_p0.read().is_01() || !mul_ln1118_1156_fu_57171_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1156_fu_57171_p0.read()) * sc_bigint<5>(mul_ln1118_1156_fu_57171_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1157_fu_57203_p0() {
    mul_ln1118_1157_fu_57203_p0 =  (sc_lv<3>) (sext_ln1116_157_fu_27583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1157_fu_57203_p1() {
    mul_ln1118_1157_fu_57203_p1 = tmp_1157_fu_57189_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1157_fu_57203_p2() {
    mul_ln1118_1157_fu_57203_p2 = (!mul_ln1118_1157_fu_57203_p0.read().is_01() || !mul_ln1118_1157_fu_57203_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1157_fu_57203_p0.read()) * sc_bigint<5>(mul_ln1118_1157_fu_57203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1158_fu_57235_p0() {
    mul_ln1118_1158_fu_57235_p0 =  (sc_lv<3>) (sext_ln1116_158_fu_27627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1158_fu_57235_p1() {
    mul_ln1118_1158_fu_57235_p1 = tmp_1158_fu_57221_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1158_fu_57235_p2() {
    mul_ln1118_1158_fu_57235_p2 = (!mul_ln1118_1158_fu_57235_p0.read().is_01() || !mul_ln1118_1158_fu_57235_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1158_fu_57235_p0.read()) * sc_bigint<5>(mul_ln1118_1158_fu_57235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1159_fu_57267_p0() {
    mul_ln1118_1159_fu_57267_p0 =  (sc_lv<3>) (sext_ln1116_159_fu_27671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1159_fu_57267_p1() {
    mul_ln1118_1159_fu_57267_p1 = tmp_1159_fu_57253_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1159_fu_57267_p2() {
    mul_ln1118_1159_fu_57267_p2 = (!mul_ln1118_1159_fu_57267_p0.read().is_01() || !mul_ln1118_1159_fu_57267_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1159_fu_57267_p0.read()) * sc_bigint<5>(mul_ln1118_1159_fu_57267_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_115_fu_82944_p0() {
    mul_ln1118_115_fu_82944_p0 =  (sc_lv<3>) (sext_ln1116_115_reg_106214.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_115_fu_82944_p1() {
    mul_ln1118_115_fu_82944_p1 = tmp_115_reg_106209.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_115_fu_82944_p2() {
    mul_ln1118_115_fu_82944_p2 = (!mul_ln1118_115_fu_82944_p0.read().is_01() || !mul_ln1118_115_fu_82944_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_115_fu_82944_p0.read()) * sc_bigint<5>(mul_ln1118_115_fu_82944_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1160_fu_57287_p0() {
    mul_ln1118_1160_fu_57287_p0 =  (sc_lv<3>) (sext_ln1116_160_fu_27703_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1160_fu_57287_p1() {
    mul_ln1118_1160_fu_57287_p1 = tmp_1160_fu_57273_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1160_fu_57287_p2() {
    mul_ln1118_1160_fu_57287_p2 = (!mul_ln1118_1160_fu_57287_p0.read().is_01() || !mul_ln1118_1160_fu_57287_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1160_fu_57287_p0.read()) * sc_bigint<5>(mul_ln1118_1160_fu_57287_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1161_fu_57319_p0() {
    mul_ln1118_1161_fu_57319_p0 =  (sc_lv<3>) (sext_ln1116_161_fu_27747_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1161_fu_57319_p1() {
    mul_ln1118_1161_fu_57319_p1 = tmp_1161_fu_57305_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1161_fu_57319_p2() {
    mul_ln1118_1161_fu_57319_p2 = (!mul_ln1118_1161_fu_57319_p0.read().is_01() || !mul_ln1118_1161_fu_57319_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1161_fu_57319_p0.read()) * sc_bigint<5>(mul_ln1118_1161_fu_57319_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1162_fu_57351_p0() {
    mul_ln1118_1162_fu_57351_p0 =  (sc_lv<3>) (sext_ln1116_162_fu_27791_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1162_fu_57351_p1() {
    mul_ln1118_1162_fu_57351_p1 = tmp_1162_fu_57337_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1162_fu_57351_p2() {
    mul_ln1118_1162_fu_57351_p2 = (!mul_ln1118_1162_fu_57351_p0.read().is_01() || !mul_ln1118_1162_fu_57351_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1162_fu_57351_p0.read()) * sc_bigint<5>(mul_ln1118_1162_fu_57351_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1163_fu_57371_p0() {
    mul_ln1118_1163_fu_57371_p0 =  (sc_lv<3>) (sext_ln1116_163_fu_27823_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1163_fu_57371_p1() {
    mul_ln1118_1163_fu_57371_p1 = tmp_1163_fu_57357_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1163_fu_57371_p2() {
    mul_ln1118_1163_fu_57371_p2 = (!mul_ln1118_1163_fu_57371_p0.read().is_01() || !mul_ln1118_1163_fu_57371_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1163_fu_57371_p0.read()) * sc_bigint<5>(mul_ln1118_1163_fu_57371_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1164_fu_57403_p0() {
    mul_ln1118_1164_fu_57403_p0 =  (sc_lv<3>) (sext_ln1116_164_fu_27867_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1164_fu_57403_p1() {
    mul_ln1118_1164_fu_57403_p1 = tmp_1164_fu_57389_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1164_fu_57403_p2() {
    mul_ln1118_1164_fu_57403_p2 = (!mul_ln1118_1164_fu_57403_p0.read().is_01() || !mul_ln1118_1164_fu_57403_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1164_fu_57403_p0.read()) * sc_bigint<5>(mul_ln1118_1164_fu_57403_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1165_fu_93435_p0() {
    mul_ln1118_1165_fu_93435_p0 =  (sc_lv<3>) (sext_ln1116_165_reg_106388.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1165_fu_93435_p1() {
    mul_ln1118_1165_fu_93435_p1 = tmp_1165_reg_109713.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1165_fu_93435_p2() {
    mul_ln1118_1165_fu_93435_p2 = (!mul_ln1118_1165_fu_93435_p0.read().is_01() || !mul_ln1118_1165_fu_93435_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1165_fu_93435_p0.read()) * sc_bigint<5>(mul_ln1118_1165_fu_93435_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1166_fu_57445_p0() {
    mul_ln1118_1166_fu_57445_p0 =  (sc_lv<3>) (sext_ln1116_166_fu_27933_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1166_fu_57445_p1() {
    mul_ln1118_1166_fu_57445_p1 = tmp_1166_fu_57431_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1166_fu_57445_p2() {
    mul_ln1118_1166_fu_57445_p2 = (!mul_ln1118_1166_fu_57445_p0.read().is_01() || !mul_ln1118_1166_fu_57445_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1166_fu_57445_p0.read()) * sc_bigint<5>(mul_ln1118_1166_fu_57445_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1167_fu_57477_p0() {
    mul_ln1118_1167_fu_57477_p0 =  (sc_lv<3>) (sext_ln1116_167_fu_27977_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1167_fu_57477_p1() {
    mul_ln1118_1167_fu_57477_p1 = tmp_1167_fu_57463_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1167_fu_57477_p2() {
    mul_ln1118_1167_fu_57477_p2 = (!mul_ln1118_1167_fu_57477_p0.read().is_01() || !mul_ln1118_1167_fu_57477_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1167_fu_57477_p0.read()) * sc_bigint<5>(mul_ln1118_1167_fu_57477_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1168_fu_93455_p0() {
    mul_ln1118_1168_fu_93455_p0 =  (sc_lv<3>) (sext_ln1116_168_reg_106406.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1168_fu_93455_p1() {
    mul_ln1118_1168_fu_93455_p1 = tmp_1168_reg_109718.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1168_fu_93455_p2() {
    mul_ln1118_1168_fu_93455_p2 = (!mul_ln1118_1168_fu_93455_p0.read().is_01() || !mul_ln1118_1168_fu_93455_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1168_fu_93455_p0.read()) * sc_bigint<5>(mul_ln1118_1168_fu_93455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1169_fu_57519_p0() {
    mul_ln1118_1169_fu_57519_p0 =  (sc_lv<3>) (sext_ln1116_169_fu_28043_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1169_fu_57519_p1() {
    mul_ln1118_1169_fu_57519_p1 = tmp_1169_fu_57505_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1169_fu_57519_p2() {
    mul_ln1118_1169_fu_57519_p2 = (!mul_ln1118_1169_fu_57519_p0.read().is_01() || !mul_ln1118_1169_fu_57519_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1169_fu_57519_p0.read()) * sc_bigint<5>(mul_ln1118_1169_fu_57519_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_116_fu_25989_p0() {
    mul_ln1118_116_fu_25989_p0 =  (sc_lv<3>) (sext_ln1116_116_fu_25981_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_116_fu_25989_p1() {
    mul_ln1118_116_fu_25989_p1 = tmp_116_fu_25971_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_116_fu_25989_p2() {
    mul_ln1118_116_fu_25989_p2 = (!mul_ln1118_116_fu_25989_p0.read().is_01() || !mul_ln1118_116_fu_25989_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_116_fu_25989_p0.read()) * sc_bigint<5>(mul_ln1118_116_fu_25989_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1170_fu_57551_p0() {
    mul_ln1118_1170_fu_57551_p0 =  (sc_lv<3>) (sext_ln1116_170_fu_28087_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1170_fu_57551_p1() {
    mul_ln1118_1170_fu_57551_p1 = tmp_1170_fu_57537_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1170_fu_57551_p2() {
    mul_ln1118_1170_fu_57551_p2 = (!mul_ln1118_1170_fu_57551_p0.read().is_01() || !mul_ln1118_1170_fu_57551_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1170_fu_57551_p0.read()) * sc_bigint<5>(mul_ln1118_1170_fu_57551_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1171_fu_93475_p0() {
    mul_ln1118_1171_fu_93475_p0 =  (sc_lv<3>) (sext_ln1116_171_reg_106424.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1171_fu_93475_p1() {
    mul_ln1118_1171_fu_93475_p1 = tmp_1171_reg_109723.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1171_fu_93475_p2() {
    mul_ln1118_1171_fu_93475_p2 = (!mul_ln1118_1171_fu_93475_p0.read().is_01() || !mul_ln1118_1171_fu_93475_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1171_fu_93475_p0.read()) * sc_bigint<5>(mul_ln1118_1171_fu_93475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1172_fu_57593_p0() {
    mul_ln1118_1172_fu_57593_p0 =  (sc_lv<3>) (sext_ln1116_172_fu_28153_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1172_fu_57593_p1() {
    mul_ln1118_1172_fu_57593_p1 = tmp_1172_fu_57579_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1172_fu_57593_p2() {
    mul_ln1118_1172_fu_57593_p2 = (!mul_ln1118_1172_fu_57593_p0.read().is_01() || !mul_ln1118_1172_fu_57593_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1172_fu_57593_p0.read()) * sc_bigint<5>(mul_ln1118_1172_fu_57593_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1173_fu_57625_p0() {
    mul_ln1118_1173_fu_57625_p0 =  (sc_lv<3>) (sext_ln1116_173_fu_28197_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1173_fu_57625_p1() {
    mul_ln1118_1173_fu_57625_p1 = tmp_1173_fu_57611_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1173_fu_57625_p2() {
    mul_ln1118_1173_fu_57625_p2 = (!mul_ln1118_1173_fu_57625_p0.read().is_01() || !mul_ln1118_1173_fu_57625_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1173_fu_57625_p0.read()) * sc_bigint<5>(mul_ln1118_1173_fu_57625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1174_fu_93495_p0() {
    mul_ln1118_1174_fu_93495_p0 =  (sc_lv<3>) (sext_ln1116_174_reg_106442.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1174_fu_93495_p1() {
    mul_ln1118_1174_fu_93495_p1 = tmp_1174_reg_109728.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1174_fu_93495_p2() {
    mul_ln1118_1174_fu_93495_p2 = (!mul_ln1118_1174_fu_93495_p0.read().is_01() || !mul_ln1118_1174_fu_93495_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1174_fu_93495_p0.read()) * sc_bigint<5>(mul_ln1118_1174_fu_93495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1175_fu_57667_p0() {
    mul_ln1118_1175_fu_57667_p0 =  (sc_lv<3>) (sext_ln1116_175_fu_28263_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1175_fu_57667_p1() {
    mul_ln1118_1175_fu_57667_p1 = tmp_1175_fu_57653_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1175_fu_57667_p2() {
    mul_ln1118_1175_fu_57667_p2 = (!mul_ln1118_1175_fu_57667_p0.read().is_01() || !mul_ln1118_1175_fu_57667_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1175_fu_57667_p0.read()) * sc_bigint<5>(mul_ln1118_1175_fu_57667_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1176_fu_57699_p0() {
    mul_ln1118_1176_fu_57699_p0 =  (sc_lv<3>) (sext_ln1116_176_fu_28307_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1176_fu_57699_p1() {
    mul_ln1118_1176_fu_57699_p1 = tmp_1176_fu_57685_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1176_fu_57699_p2() {
    mul_ln1118_1176_fu_57699_p2 = (!mul_ln1118_1176_fu_57699_p0.read().is_01() || !mul_ln1118_1176_fu_57699_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1176_fu_57699_p0.read()) * sc_bigint<5>(mul_ln1118_1176_fu_57699_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1177_fu_93515_p0() {
    mul_ln1118_1177_fu_93515_p0 =  (sc_lv<3>) (sext_ln1116_177_reg_106460.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1177_fu_93515_p1() {
    mul_ln1118_1177_fu_93515_p1 = tmp_1177_reg_109733.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1177_fu_93515_p2() {
    mul_ln1118_1177_fu_93515_p2 = (!mul_ln1118_1177_fu_93515_p0.read().is_01() || !mul_ln1118_1177_fu_93515_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1177_fu_93515_p0.read()) * sc_bigint<5>(mul_ln1118_1177_fu_93515_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1178_fu_57741_p0() {
    mul_ln1118_1178_fu_57741_p0 =  (sc_lv<3>) (sext_ln1116_178_fu_28373_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1178_fu_57741_p1() {
    mul_ln1118_1178_fu_57741_p1 = tmp_1178_fu_57727_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1178_fu_57741_p2() {
    mul_ln1118_1178_fu_57741_p2 = (!mul_ln1118_1178_fu_57741_p0.read().is_01() || !mul_ln1118_1178_fu_57741_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1178_fu_57741_p0.read()) * sc_bigint<5>(mul_ln1118_1178_fu_57741_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1179_fu_57773_p0() {
    mul_ln1118_1179_fu_57773_p0 =  (sc_lv<3>) (sext_ln1116_179_fu_28417_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1179_fu_57773_p1() {
    mul_ln1118_1179_fu_57773_p1 = tmp_1179_fu_57759_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1179_fu_57773_p2() {
    mul_ln1118_1179_fu_57773_p2 = (!mul_ln1118_1179_fu_57773_p0.read().is_01() || !mul_ln1118_1179_fu_57773_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1179_fu_57773_p0.read()) * sc_bigint<5>(mul_ln1118_1179_fu_57773_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_117_fu_26033_p0() {
    mul_ln1118_117_fu_26033_p0 =  (sc_lv<3>) (sext_ln1116_117_fu_26025_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_117_fu_26033_p1() {
    mul_ln1118_117_fu_26033_p1 = tmp_117_fu_26015_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_117_fu_26033_p2() {
    mul_ln1118_117_fu_26033_p2 = (!mul_ln1118_117_fu_26033_p0.read().is_01() || !mul_ln1118_117_fu_26033_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_117_fu_26033_p0.read()) * sc_bigint<5>(mul_ln1118_117_fu_26033_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1180_fu_57805_p0() {
    mul_ln1118_1180_fu_57805_p0 =  (sc_lv<3>) (sext_ln1116_180_fu_28461_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1180_fu_57805_p1() {
    mul_ln1118_1180_fu_57805_p1 = tmp_1180_fu_57791_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1180_fu_57805_p2() {
    mul_ln1118_1180_fu_57805_p2 = (!mul_ln1118_1180_fu_57805_p0.read().is_01() || !mul_ln1118_1180_fu_57805_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1180_fu_57805_p0.read()) * sc_bigint<5>(mul_ln1118_1180_fu_57805_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1181_fu_57837_p0() {
    mul_ln1118_1181_fu_57837_p0 =  (sc_lv<3>) (sext_ln1116_181_fu_28505_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1181_fu_57837_p1() {
    mul_ln1118_1181_fu_57837_p1 = tmp_1181_fu_57823_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1181_fu_57837_p2() {
    mul_ln1118_1181_fu_57837_p2 = (!mul_ln1118_1181_fu_57837_p0.read().is_01() || !mul_ln1118_1181_fu_57837_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1181_fu_57837_p0.read()) * sc_bigint<5>(mul_ln1118_1181_fu_57837_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1182_fu_57869_p0() {
    mul_ln1118_1182_fu_57869_p0 =  (sc_lv<3>) (sext_ln1116_182_fu_28549_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1182_fu_57869_p1() {
    mul_ln1118_1182_fu_57869_p1 = tmp_1182_fu_57855_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1182_fu_57869_p2() {
    mul_ln1118_1182_fu_57869_p2 = (!mul_ln1118_1182_fu_57869_p0.read().is_01() || !mul_ln1118_1182_fu_57869_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1182_fu_57869_p0.read()) * sc_bigint<5>(mul_ln1118_1182_fu_57869_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1183_fu_57901_p0() {
    mul_ln1118_1183_fu_57901_p0 =  (sc_lv<3>) (sext_ln1116_183_fu_28593_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1183_fu_57901_p1() {
    mul_ln1118_1183_fu_57901_p1 = tmp_1183_fu_57887_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1183_fu_57901_p2() {
    mul_ln1118_1183_fu_57901_p2 = (!mul_ln1118_1183_fu_57901_p0.read().is_01() || !mul_ln1118_1183_fu_57901_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1183_fu_57901_p0.read()) * sc_bigint<5>(mul_ln1118_1183_fu_57901_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1184_fu_57933_p0() {
    mul_ln1118_1184_fu_57933_p0 =  (sc_lv<3>) (sext_ln1116_184_fu_28637_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1184_fu_57933_p1() {
    mul_ln1118_1184_fu_57933_p1 = tmp_1184_fu_57919_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1184_fu_57933_p2() {
    mul_ln1118_1184_fu_57933_p2 = (!mul_ln1118_1184_fu_57933_p0.read().is_01() || !mul_ln1118_1184_fu_57933_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1184_fu_57933_p0.read()) * sc_bigint<5>(mul_ln1118_1184_fu_57933_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1185_fu_57953_p0() {
    mul_ln1118_1185_fu_57953_p0 =  (sc_lv<3>) (sext_ln1116_185_fu_28669_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1185_fu_57953_p1() {
    mul_ln1118_1185_fu_57953_p1 = tmp_1185_fu_57939_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1185_fu_57953_p2() {
    mul_ln1118_1185_fu_57953_p2 = (!mul_ln1118_1185_fu_57953_p0.read().is_01() || !mul_ln1118_1185_fu_57953_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1185_fu_57953_p0.read()) * sc_bigint<5>(mul_ln1118_1185_fu_57953_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1186_fu_57985_p0() {
    mul_ln1118_1186_fu_57985_p0 =  (sc_lv<3>) (sext_ln1116_186_fu_28713_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1186_fu_57985_p1() {
    mul_ln1118_1186_fu_57985_p1 = tmp_1186_fu_57971_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1186_fu_57985_p2() {
    mul_ln1118_1186_fu_57985_p2 = (!mul_ln1118_1186_fu_57985_p0.read().is_01() || !mul_ln1118_1186_fu_57985_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1186_fu_57985_p0.read()) * sc_bigint<5>(mul_ln1118_1186_fu_57985_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1187_fu_58017_p0() {
    mul_ln1118_1187_fu_58017_p0 =  (sc_lv<3>) (sext_ln1116_187_fu_28757_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1187_fu_58017_p1() {
    mul_ln1118_1187_fu_58017_p1 = tmp_1187_fu_58003_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1187_fu_58017_p2() {
    mul_ln1118_1187_fu_58017_p2 = (!mul_ln1118_1187_fu_58017_p0.read().is_01() || !mul_ln1118_1187_fu_58017_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1187_fu_58017_p0.read()) * sc_bigint<5>(mul_ln1118_1187_fu_58017_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1188_fu_58037_p0() {
    mul_ln1118_1188_fu_58037_p0 =  (sc_lv<3>) (sext_ln1116_188_fu_28789_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1188_fu_58037_p1() {
    mul_ln1118_1188_fu_58037_p1 = tmp_1188_fu_58023_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1188_fu_58037_p2() {
    mul_ln1118_1188_fu_58037_p2 = (!mul_ln1118_1188_fu_58037_p0.read().is_01() || !mul_ln1118_1188_fu_58037_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1188_fu_58037_p0.read()) * sc_bigint<5>(mul_ln1118_1188_fu_58037_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1189_fu_58069_p0() {
    mul_ln1118_1189_fu_58069_p0 =  (sc_lv<3>) (sext_ln1116_189_fu_28833_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1189_fu_58069_p1() {
    mul_ln1118_1189_fu_58069_p1 = tmp_1189_fu_58055_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1189_fu_58069_p2() {
    mul_ln1118_1189_fu_58069_p2 = (!mul_ln1118_1189_fu_58069_p0.read().is_01() || !mul_ln1118_1189_fu_58069_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1189_fu_58069_p0.read()) * sc_bigint<5>(mul_ln1118_1189_fu_58069_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_118_fu_82964_p0() {
    mul_ln1118_118_fu_82964_p0 =  (sc_lv<3>) (sext_ln1116_118_reg_106232.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_118_fu_82964_p1() {
    mul_ln1118_118_fu_82964_p1 = tmp_118_reg_106227.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_118_fu_82964_p2() {
    mul_ln1118_118_fu_82964_p2 = (!mul_ln1118_118_fu_82964_p0.read().is_01() || !mul_ln1118_118_fu_82964_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_118_fu_82964_p0.read()) * sc_bigint<5>(mul_ln1118_118_fu_82964_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1190_fu_93557_p0() {
    mul_ln1118_1190_fu_93557_p0 =  (sc_lv<3>) (sext_ln1116_190_reg_106488.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1190_fu_93557_p1() {
    mul_ln1118_1190_fu_93557_p1 = tmp_1190_reg_109748.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1190_fu_93557_p2() {
    mul_ln1118_1190_fu_93557_p2 = (!mul_ln1118_1190_fu_93557_p0.read().is_01() || !mul_ln1118_1190_fu_93557_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1190_fu_93557_p0.read()) * sc_bigint<5>(mul_ln1118_1190_fu_93557_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1191_fu_58111_p0() {
    mul_ln1118_1191_fu_58111_p0 =  (sc_lv<3>) (sext_ln1116_191_fu_28899_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1191_fu_58111_p1() {
    mul_ln1118_1191_fu_58111_p1 = tmp_1191_fu_58097_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1191_fu_58111_p2() {
    mul_ln1118_1191_fu_58111_p2 = (!mul_ln1118_1191_fu_58111_p0.read().is_01() || !mul_ln1118_1191_fu_58111_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1191_fu_58111_p0.read()) * sc_bigint<5>(mul_ln1118_1191_fu_58111_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1192_fu_58143_p0() {
    mul_ln1118_1192_fu_58143_p0 =  (sc_lv<3>) (sext_ln1116_192_fu_28943_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1192_fu_58143_p1() {
    mul_ln1118_1192_fu_58143_p1 = tmp_1192_fu_58129_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1192_fu_58143_p2() {
    mul_ln1118_1192_fu_58143_p2 = (!mul_ln1118_1192_fu_58143_p0.read().is_01() || !mul_ln1118_1192_fu_58143_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1192_fu_58143_p0.read()) * sc_bigint<5>(mul_ln1118_1192_fu_58143_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1193_fu_93577_p0() {
    mul_ln1118_1193_fu_93577_p0 =  (sc_lv<3>) (sext_ln1116_193_reg_106506.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1193_fu_93577_p1() {
    mul_ln1118_1193_fu_93577_p1 = tmp_1193_reg_109753.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1193_fu_93577_p2() {
    mul_ln1118_1193_fu_93577_p2 = (!mul_ln1118_1193_fu_93577_p0.read().is_01() || !mul_ln1118_1193_fu_93577_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1193_fu_93577_p0.read()) * sc_bigint<5>(mul_ln1118_1193_fu_93577_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1194_fu_58185_p0() {
    mul_ln1118_1194_fu_58185_p0 =  (sc_lv<3>) (sext_ln1116_194_fu_29009_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1194_fu_58185_p1() {
    mul_ln1118_1194_fu_58185_p1 = tmp_1194_fu_58171_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1194_fu_58185_p2() {
    mul_ln1118_1194_fu_58185_p2 = (!mul_ln1118_1194_fu_58185_p0.read().is_01() || !mul_ln1118_1194_fu_58185_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1194_fu_58185_p0.read()) * sc_bigint<5>(mul_ln1118_1194_fu_58185_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1195_fu_58217_p0() {
    mul_ln1118_1195_fu_58217_p0 =  (sc_lv<3>) (sext_ln1116_195_fu_29053_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1195_fu_58217_p1() {
    mul_ln1118_1195_fu_58217_p1 = tmp_1195_fu_58203_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1195_fu_58217_p2() {
    mul_ln1118_1195_fu_58217_p2 = (!mul_ln1118_1195_fu_58217_p0.read().is_01() || !mul_ln1118_1195_fu_58217_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1195_fu_58217_p0.read()) * sc_bigint<5>(mul_ln1118_1195_fu_58217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1196_fu_93597_p0() {
    mul_ln1118_1196_fu_93597_p0 =  (sc_lv<3>) (sext_ln1116_196_reg_106524.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1196_fu_93597_p1() {
    mul_ln1118_1196_fu_93597_p1 = tmp_1196_reg_109758.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1196_fu_93597_p2() {
    mul_ln1118_1196_fu_93597_p2 = (!mul_ln1118_1196_fu_93597_p0.read().is_01() || !mul_ln1118_1196_fu_93597_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1196_fu_93597_p0.read()) * sc_bigint<5>(mul_ln1118_1196_fu_93597_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1197_fu_58259_p0() {
    mul_ln1118_1197_fu_58259_p0 =  (sc_lv<3>) (sext_ln1116_197_fu_29119_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1197_fu_58259_p1() {
    mul_ln1118_1197_fu_58259_p1 = tmp_1197_fu_58245_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1197_fu_58259_p2() {
    mul_ln1118_1197_fu_58259_p2 = (!mul_ln1118_1197_fu_58259_p0.read().is_01() || !mul_ln1118_1197_fu_58259_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1197_fu_58259_p0.read()) * sc_bigint<5>(mul_ln1118_1197_fu_58259_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1198_fu_58291_p0() {
    mul_ln1118_1198_fu_58291_p0 =  (sc_lv<3>) (sext_ln1116_198_fu_29163_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1198_fu_58291_p1() {
    mul_ln1118_1198_fu_58291_p1 = tmp_1198_fu_58277_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1198_fu_58291_p2() {
    mul_ln1118_1198_fu_58291_p2 = (!mul_ln1118_1198_fu_58291_p0.read().is_01() || !mul_ln1118_1198_fu_58291_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1198_fu_58291_p0.read()) * sc_bigint<5>(mul_ln1118_1198_fu_58291_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1199_fu_93617_p0() {
    mul_ln1118_1199_fu_93617_p0 =  (sc_lv<3>) (sext_ln1116_199_reg_106542.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1199_fu_93617_p1() {
    mul_ln1118_1199_fu_93617_p1 = tmp_1199_reg_109763.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1199_fu_93617_p2() {
    mul_ln1118_1199_fu_93617_p2 = (!mul_ln1118_1199_fu_93617_p0.read().is_01() || !mul_ln1118_1199_fu_93617_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1199_fu_93617_p0.read()) * sc_bigint<5>(mul_ln1118_1199_fu_93617_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_119_fu_26099_p0() {
    mul_ln1118_119_fu_26099_p0 =  (sc_lv<3>) (sext_ln1116_119_fu_26091_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_119_fu_26099_p1() {
    mul_ln1118_119_fu_26099_p1 = tmp_119_fu_26081_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_119_fu_26099_p2() {
    mul_ln1118_119_fu_26099_p2 = (!mul_ln1118_119_fu_26099_p0.read().is_01() || !mul_ln1118_119_fu_26099_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_119_fu_26099_p0.read()) * sc_bigint<5>(mul_ln1118_119_fu_26099_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_11_fu_21939_p0() {
    mul_ln1118_11_fu_21939_p0 =  (sc_lv<3>) (sext_ln1116_11_fu_21931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_11_fu_21939_p1() {
    mul_ln1118_11_fu_21939_p1 = tmp_12_fu_21921_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_11_fu_21939_p2() {
    mul_ln1118_11_fu_21939_p2 = (!mul_ln1118_11_fu_21939_p0.read().is_01() || !mul_ln1118_11_fu_21939_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_11_fu_21939_p0.read()) * sc_bigint<5>(mul_ln1118_11_fu_21939_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1200_fu_58333_p0() {
    mul_ln1118_1200_fu_58333_p0 =  (sc_lv<3>) (sext_ln1116_200_fu_29229_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1200_fu_58333_p1() {
    mul_ln1118_1200_fu_58333_p1 = tmp_1200_fu_58319_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1200_fu_58333_p2() {
    mul_ln1118_1200_fu_58333_p2 = (!mul_ln1118_1200_fu_58333_p0.read().is_01() || !mul_ln1118_1200_fu_58333_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1200_fu_58333_p0.read()) * sc_bigint<5>(mul_ln1118_1200_fu_58333_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1201_fu_58365_p0() {
    mul_ln1118_1201_fu_58365_p0 =  (sc_lv<3>) (sext_ln1116_201_fu_29273_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1201_fu_58365_p1() {
    mul_ln1118_1201_fu_58365_p1 = tmp_1201_fu_58351_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1201_fu_58365_p2() {
    mul_ln1118_1201_fu_58365_p2 = (!mul_ln1118_1201_fu_58365_p0.read().is_01() || !mul_ln1118_1201_fu_58365_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1201_fu_58365_p0.read()) * sc_bigint<5>(mul_ln1118_1201_fu_58365_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1202_fu_93637_p0() {
    mul_ln1118_1202_fu_93637_p0 =  (sc_lv<3>) (sext_ln1116_202_reg_106560.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1202_fu_93637_p1() {
    mul_ln1118_1202_fu_93637_p1 = tmp_1202_reg_109768.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1202_fu_93637_p2() {
    mul_ln1118_1202_fu_93637_p2 = (!mul_ln1118_1202_fu_93637_p0.read().is_01() || !mul_ln1118_1202_fu_93637_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1202_fu_93637_p0.read()) * sc_bigint<5>(mul_ln1118_1202_fu_93637_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1203_fu_58407_p0() {
    mul_ln1118_1203_fu_58407_p0 =  (sc_lv<3>) (sext_ln1116_203_fu_29339_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1203_fu_58407_p1() {
    mul_ln1118_1203_fu_58407_p1 = tmp_1203_fu_58393_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1203_fu_58407_p2() {
    mul_ln1118_1203_fu_58407_p2 = (!mul_ln1118_1203_fu_58407_p0.read().is_01() || !mul_ln1118_1203_fu_58407_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1203_fu_58407_p0.read()) * sc_bigint<5>(mul_ln1118_1203_fu_58407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1204_fu_58439_p0() {
    mul_ln1118_1204_fu_58439_p0 =  (sc_lv<3>) (sext_ln1116_204_fu_29383_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1204_fu_58439_p1() {
    mul_ln1118_1204_fu_58439_p1 = tmp_1204_fu_58425_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1204_fu_58439_p2() {
    mul_ln1118_1204_fu_58439_p2 = (!mul_ln1118_1204_fu_58439_p0.read().is_01() || !mul_ln1118_1204_fu_58439_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1204_fu_58439_p0.read()) * sc_bigint<5>(mul_ln1118_1204_fu_58439_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1205_fu_58471_p0() {
    mul_ln1118_1205_fu_58471_p0 =  (sc_lv<3>) (sext_ln1116_205_fu_29427_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1205_fu_58471_p1() {
    mul_ln1118_1205_fu_58471_p1 = tmp_1205_fu_58457_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1205_fu_58471_p2() {
    mul_ln1118_1205_fu_58471_p2 = (!mul_ln1118_1205_fu_58471_p0.read().is_01() || !mul_ln1118_1205_fu_58471_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1205_fu_58471_p0.read()) * sc_bigint<5>(mul_ln1118_1205_fu_58471_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1206_fu_58503_p0() {
    mul_ln1118_1206_fu_58503_p0 =  (sc_lv<3>) (sext_ln1116_206_fu_29471_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1206_fu_58503_p1() {
    mul_ln1118_1206_fu_58503_p1 = tmp_1206_fu_58489_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1206_fu_58503_p2() {
    mul_ln1118_1206_fu_58503_p2 = (!mul_ln1118_1206_fu_58503_p0.read().is_01() || !mul_ln1118_1206_fu_58503_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1206_fu_58503_p0.read()) * sc_bigint<5>(mul_ln1118_1206_fu_58503_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1207_fu_58535_p0() {
    mul_ln1118_1207_fu_58535_p0 =  (sc_lv<3>) (sext_ln1116_207_fu_29515_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1207_fu_58535_p1() {
    mul_ln1118_1207_fu_58535_p1 = tmp_1207_fu_58521_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1207_fu_58535_p2() {
    mul_ln1118_1207_fu_58535_p2 = (!mul_ln1118_1207_fu_58535_p0.read().is_01() || !mul_ln1118_1207_fu_58535_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1207_fu_58535_p0.read()) * sc_bigint<5>(mul_ln1118_1207_fu_58535_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1208_fu_58567_p0() {
    mul_ln1118_1208_fu_58567_p0 =  (sc_lv<3>) (sext_ln1116_208_fu_29559_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1208_fu_58567_p1() {
    mul_ln1118_1208_fu_58567_p1 = tmp_1208_fu_58553_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1208_fu_58567_p2() {
    mul_ln1118_1208_fu_58567_p2 = (!mul_ln1118_1208_fu_58567_p0.read().is_01() || !mul_ln1118_1208_fu_58567_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1208_fu_58567_p0.read()) * sc_bigint<5>(mul_ln1118_1208_fu_58567_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1209_fu_59031_p0() {
    mul_ln1118_1209_fu_59031_p0 =  (sc_lv<3>) (sext_ln1116_fu_21855_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1209_fu_59031_p1() {
    mul_ln1118_1209_fu_59031_p1 = tmp_1209_fu_59017_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1209_fu_59031_p2() {
    mul_ln1118_1209_fu_59031_p2 = (!mul_ln1118_1209_fu_59031_p0.read().is_01() || !mul_ln1118_1209_fu_59031_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1209_fu_59031_p0.read()) * sc_bigint<5>(mul_ln1118_1209_fu_59031_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_120_fu_26143_p0() {
    mul_ln1118_120_fu_26143_p0 =  (sc_lv<3>) (sext_ln1116_120_fu_26135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_120_fu_26143_p1() {
    mul_ln1118_120_fu_26143_p1 = tmp_120_fu_26125_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_120_fu_26143_p2() {
    mul_ln1118_120_fu_26143_p2 = (!mul_ln1118_120_fu_26143_p0.read().is_01() || !mul_ln1118_120_fu_26143_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_120_fu_26143_p0.read()) * sc_bigint<5>(mul_ln1118_120_fu_26143_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1210_fu_59051_p0() {
    mul_ln1118_1210_fu_59051_p0 =  (sc_lv<3>) (sext_ln1116_10_fu_21887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1210_fu_59051_p1() {
    mul_ln1118_1210_fu_59051_p1 = tmp_1210_fu_59037_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1210_fu_59051_p2() {
    mul_ln1118_1210_fu_59051_p2 = (!mul_ln1118_1210_fu_59051_p0.read().is_01() || !mul_ln1118_1210_fu_59051_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1210_fu_59051_p0.read()) * sc_bigint<5>(mul_ln1118_1210_fu_59051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1211_fu_59083_p0() {
    mul_ln1118_1211_fu_59083_p0 =  (sc_lv<3>) (sext_ln1116_11_fu_21931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1211_fu_59083_p1() {
    mul_ln1118_1211_fu_59083_p1 = tmp_1211_fu_59069_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1211_fu_59083_p2() {
    mul_ln1118_1211_fu_59083_p2 = (!mul_ln1118_1211_fu_59083_p0.read().is_01() || !mul_ln1118_1211_fu_59083_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1211_fu_59083_p0.read()) * sc_bigint<5>(mul_ln1118_1211_fu_59083_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1212_fu_59115_p0() {
    mul_ln1118_1212_fu_59115_p0 =  (sc_lv<3>) (sext_ln1116_12_fu_21975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1212_fu_59115_p1() {
    mul_ln1118_1212_fu_59115_p1 = tmp_1212_fu_59101_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1212_fu_59115_p2() {
    mul_ln1118_1212_fu_59115_p2 = (!mul_ln1118_1212_fu_59115_p0.read().is_01() || !mul_ln1118_1212_fu_59115_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1212_fu_59115_p0.read()) * sc_bigint<5>(mul_ln1118_1212_fu_59115_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1213_fu_59135_p0() {
    mul_ln1118_1213_fu_59135_p0 =  (sc_lv<3>) (sext_ln1116_13_fu_22007_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1213_fu_59135_p1() {
    mul_ln1118_1213_fu_59135_p1 = tmp_1213_fu_59121_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1213_fu_59135_p2() {
    mul_ln1118_1213_fu_59135_p2 = (!mul_ln1118_1213_fu_59135_p0.read().is_01() || !mul_ln1118_1213_fu_59135_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1213_fu_59135_p0.read()) * sc_bigint<5>(mul_ln1118_1213_fu_59135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1214_fu_59167_p0() {
    mul_ln1118_1214_fu_59167_p0 =  (sc_lv<3>) (sext_ln1116_14_fu_22051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1214_fu_59167_p1() {
    mul_ln1118_1214_fu_59167_p1 = tmp_1214_fu_59153_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1214_fu_59167_p2() {
    mul_ln1118_1214_fu_59167_p2 = (!mul_ln1118_1214_fu_59167_p0.read().is_01() || !mul_ln1118_1214_fu_59167_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1214_fu_59167_p0.read()) * sc_bigint<5>(mul_ln1118_1214_fu_59167_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1215_fu_94787_p0() {
    mul_ln1118_1215_fu_94787_p0 =  (sc_lv<3>) (sext_ln1116_15_fu_82451_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1215_fu_94787_p1() {
    mul_ln1118_1215_fu_94787_p1 = tmp_1215_reg_110143.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1215_fu_94787_p2() {
    mul_ln1118_1215_fu_94787_p2 = (!mul_ln1118_1215_fu_94787_p0.read().is_01() || !mul_ln1118_1215_fu_94787_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1215_fu_94787_p0.read()) * sc_bigint<5>(mul_ln1118_1215_fu_94787_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1216_fu_59209_p0() {
    mul_ln1118_1216_fu_59209_p0 =  (sc_lv<3>) (sext_ln1116_16_fu_22113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1216_fu_59209_p1() {
    mul_ln1118_1216_fu_59209_p1 = tmp_1216_fu_59195_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1216_fu_59209_p2() {
    mul_ln1118_1216_fu_59209_p2 = (!mul_ln1118_1216_fu_59209_p0.read().is_01() || !mul_ln1118_1216_fu_59209_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1216_fu_59209_p0.read()) * sc_bigint<5>(mul_ln1118_1216_fu_59209_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1217_fu_59241_p0() {
    mul_ln1118_1217_fu_59241_p0 =  (sc_lv<3>) (sext_ln1116_17_fu_22157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1217_fu_59241_p1() {
    mul_ln1118_1217_fu_59241_p1 = tmp_1217_fu_59227_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1217_fu_59241_p2() {
    mul_ln1118_1217_fu_59241_p2 = (!mul_ln1118_1217_fu_59241_p0.read().is_01() || !mul_ln1118_1217_fu_59241_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1217_fu_59241_p0.read()) * sc_bigint<5>(mul_ln1118_1217_fu_59241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1218_fu_94808_p0() {
    mul_ln1118_1218_fu_94808_p0 =  (sc_lv<3>) (sext_ln1116_18_fu_82475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1218_fu_94808_p1() {
    mul_ln1118_1218_fu_94808_p1 = tmp_1218_reg_110148.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1218_fu_94808_p2() {
    mul_ln1118_1218_fu_94808_p2 = (!mul_ln1118_1218_fu_94808_p0.read().is_01() || !mul_ln1118_1218_fu_94808_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1218_fu_94808_p0.read()) * sc_bigint<5>(mul_ln1118_1218_fu_94808_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1219_fu_59283_p0() {
    mul_ln1118_1219_fu_59283_p0 =  (sc_lv<3>) (sext_ln1116_19_fu_22219_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1219_fu_59283_p1() {
    mul_ln1118_1219_fu_59283_p1 = tmp_1219_fu_59269_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1219_fu_59283_p2() {
    mul_ln1118_1219_fu_59283_p2 = (!mul_ln1118_1219_fu_59283_p0.read().is_01() || !mul_ln1118_1219_fu_59283_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1219_fu_59283_p0.read()) * sc_bigint<5>(mul_ln1118_1219_fu_59283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_121_fu_82984_p0() {
    mul_ln1118_121_fu_82984_p0 =  (sc_lv<3>) (sext_ln1116_121_reg_106250.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_121_fu_82984_p1() {
    mul_ln1118_121_fu_82984_p1 = tmp_121_reg_106245.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_121_fu_82984_p2() {
    mul_ln1118_121_fu_82984_p2 = (!mul_ln1118_121_fu_82984_p0.read().is_01() || !mul_ln1118_121_fu_82984_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_121_fu_82984_p0.read()) * sc_bigint<5>(mul_ln1118_121_fu_82984_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1220_fu_59315_p0() {
    mul_ln1118_1220_fu_59315_p0 =  (sc_lv<3>) (sext_ln1116_20_fu_22263_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1220_fu_59315_p1() {
    mul_ln1118_1220_fu_59315_p1 = tmp_1220_fu_59301_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1220_fu_59315_p2() {
    mul_ln1118_1220_fu_59315_p2 = (!mul_ln1118_1220_fu_59315_p0.read().is_01() || !mul_ln1118_1220_fu_59315_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1220_fu_59315_p0.read()) * sc_bigint<5>(mul_ln1118_1220_fu_59315_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1221_fu_94829_p0() {
    mul_ln1118_1221_fu_94829_p0 =  (sc_lv<3>) (sext_ln1116_21_fu_82499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1221_fu_94829_p1() {
    mul_ln1118_1221_fu_94829_p1 = tmp_1221_reg_110153.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1221_fu_94829_p2() {
    mul_ln1118_1221_fu_94829_p2 = (!mul_ln1118_1221_fu_94829_p0.read().is_01() || !mul_ln1118_1221_fu_94829_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1221_fu_94829_p0.read()) * sc_bigint<5>(mul_ln1118_1221_fu_94829_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1222_fu_59357_p0() {
    mul_ln1118_1222_fu_59357_p0 =  (sc_lv<3>) (sext_ln1116_22_fu_22325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1222_fu_59357_p1() {
    mul_ln1118_1222_fu_59357_p1 = tmp_1222_fu_59343_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1222_fu_59357_p2() {
    mul_ln1118_1222_fu_59357_p2 = (!mul_ln1118_1222_fu_59357_p0.read().is_01() || !mul_ln1118_1222_fu_59357_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1222_fu_59357_p0.read()) * sc_bigint<5>(mul_ln1118_1222_fu_59357_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1223_fu_59389_p0() {
    mul_ln1118_1223_fu_59389_p0 =  (sc_lv<3>) (sext_ln1116_23_fu_22369_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1223_fu_59389_p1() {
    mul_ln1118_1223_fu_59389_p1 = tmp_1223_fu_59375_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1223_fu_59389_p2() {
    mul_ln1118_1223_fu_59389_p2 = (!mul_ln1118_1223_fu_59389_p0.read().is_01() || !mul_ln1118_1223_fu_59389_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1223_fu_59389_p0.read()) * sc_bigint<5>(mul_ln1118_1223_fu_59389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1224_fu_94850_p0() {
    mul_ln1118_1224_fu_94850_p0 =  (sc_lv<3>) (sext_ln1116_24_fu_82523_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1224_fu_94850_p1() {
    mul_ln1118_1224_fu_94850_p1 = tmp_1224_reg_110158.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1224_fu_94850_p2() {
    mul_ln1118_1224_fu_94850_p2 = (!mul_ln1118_1224_fu_94850_p0.read().is_01() || !mul_ln1118_1224_fu_94850_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1224_fu_94850_p0.read()) * sc_bigint<5>(mul_ln1118_1224_fu_94850_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1225_fu_59431_p0() {
    mul_ln1118_1225_fu_59431_p0 =  (sc_lv<3>) (sext_ln1116_25_fu_22431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1225_fu_59431_p1() {
    mul_ln1118_1225_fu_59431_p1 = tmp_1225_fu_59417_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1225_fu_59431_p2() {
    mul_ln1118_1225_fu_59431_p2 = (!mul_ln1118_1225_fu_59431_p0.read().is_01() || !mul_ln1118_1225_fu_59431_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1225_fu_59431_p0.read()) * sc_bigint<5>(mul_ln1118_1225_fu_59431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1226_fu_59463_p0() {
    mul_ln1118_1226_fu_59463_p0 =  (sc_lv<3>) (sext_ln1116_26_fu_22475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1226_fu_59463_p1() {
    mul_ln1118_1226_fu_59463_p1 = tmp_1226_fu_59449_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1226_fu_59463_p2() {
    mul_ln1118_1226_fu_59463_p2 = (!mul_ln1118_1226_fu_59463_p0.read().is_01() || !mul_ln1118_1226_fu_59463_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1226_fu_59463_p0.read()) * sc_bigint<5>(mul_ln1118_1226_fu_59463_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1227_fu_94871_p0() {
    mul_ln1118_1227_fu_94871_p0 =  (sc_lv<3>) (sext_ln1116_27_fu_82547_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1227_fu_94871_p1() {
    mul_ln1118_1227_fu_94871_p1 = tmp_1227_reg_110163.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1227_fu_94871_p2() {
    mul_ln1118_1227_fu_94871_p2 = (!mul_ln1118_1227_fu_94871_p0.read().is_01() || !mul_ln1118_1227_fu_94871_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1227_fu_94871_p0.read()) * sc_bigint<5>(mul_ln1118_1227_fu_94871_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1228_fu_59505_p0() {
    mul_ln1118_1228_fu_59505_p0 =  (sc_lv<3>) (sext_ln1116_28_fu_22537_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1228_fu_59505_p1() {
    mul_ln1118_1228_fu_59505_p1 = tmp_1228_fu_59491_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1228_fu_59505_p2() {
    mul_ln1118_1228_fu_59505_p2 = (!mul_ln1118_1228_fu_59505_p0.read().is_01() || !mul_ln1118_1228_fu_59505_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1228_fu_59505_p0.read()) * sc_bigint<5>(mul_ln1118_1228_fu_59505_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1229_fu_59537_p0() {
    mul_ln1118_1229_fu_59537_p0 =  (sc_lv<3>) (sext_ln1116_29_fu_22581_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1229_fu_59537_p1() {
    mul_ln1118_1229_fu_59537_p1 = tmp_1229_fu_59523_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1229_fu_59537_p2() {
    mul_ln1118_1229_fu_59537_p2 = (!mul_ln1118_1229_fu_59537_p0.read().is_01() || !mul_ln1118_1229_fu_59537_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1229_fu_59537_p0.read()) * sc_bigint<5>(mul_ln1118_1229_fu_59537_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_122_fu_26209_p0() {
    mul_ln1118_122_fu_26209_p0 =  (sc_lv<3>) (sext_ln1116_122_fu_26201_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_122_fu_26209_p1() {
    mul_ln1118_122_fu_26209_p1 = tmp_122_fu_26191_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_122_fu_26209_p2() {
    mul_ln1118_122_fu_26209_p2 = (!mul_ln1118_122_fu_26209_p0.read().is_01() || !mul_ln1118_122_fu_26209_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_122_fu_26209_p0.read()) * sc_bigint<5>(mul_ln1118_122_fu_26209_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1230_fu_59569_p0() {
    mul_ln1118_1230_fu_59569_p0 =  (sc_lv<3>) (sext_ln1116_30_fu_22625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1230_fu_59569_p1() {
    mul_ln1118_1230_fu_59569_p1 = tmp_1230_fu_59555_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1230_fu_59569_p2() {
    mul_ln1118_1230_fu_59569_p2 = (!mul_ln1118_1230_fu_59569_p0.read().is_01() || !mul_ln1118_1230_fu_59569_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1230_fu_59569_p0.read()) * sc_bigint<5>(mul_ln1118_1230_fu_59569_p1.read());
}

}

