#include "dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_263_V_read289_phi_reg_20048() {
    ap_phi_reg_pp0_iter0_data_263_V_read289_phi_reg_20048 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_264_V_read290_phi_reg_20060() {
    ap_phi_reg_pp0_iter0_data_264_V_read290_phi_reg_20060 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_265_V_read291_phi_reg_20072() {
    ap_phi_reg_pp0_iter0_data_265_V_read291_phi_reg_20072 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_266_V_read292_phi_reg_20084() {
    ap_phi_reg_pp0_iter0_data_266_V_read292_phi_reg_20084 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_267_V_read293_phi_reg_20096() {
    ap_phi_reg_pp0_iter0_data_267_V_read293_phi_reg_20096 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_268_V_read294_phi_reg_20108() {
    ap_phi_reg_pp0_iter0_data_268_V_read294_phi_reg_20108 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_269_V_read295_phi_reg_20120() {
    ap_phi_reg_pp0_iter0_data_269_V_read295_phi_reg_20120 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_26_V_read52_phi_reg_17204() {
    ap_phi_reg_pp0_iter0_data_26_V_read52_phi_reg_17204 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_270_V_read296_phi_reg_20132() {
    ap_phi_reg_pp0_iter0_data_270_V_read296_phi_reg_20132 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_271_V_read297_phi_reg_20144() {
    ap_phi_reg_pp0_iter0_data_271_V_read297_phi_reg_20144 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_272_V_read298_phi_reg_20156() {
    ap_phi_reg_pp0_iter0_data_272_V_read298_phi_reg_20156 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_273_V_read299_phi_reg_20168() {
    ap_phi_reg_pp0_iter0_data_273_V_read299_phi_reg_20168 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_274_V_read300_phi_reg_20180() {
    ap_phi_reg_pp0_iter0_data_274_V_read300_phi_reg_20180 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_275_V_read301_phi_reg_20192() {
    ap_phi_reg_pp0_iter0_data_275_V_read301_phi_reg_20192 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_276_V_read302_phi_reg_20204() {
    ap_phi_reg_pp0_iter0_data_276_V_read302_phi_reg_20204 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_277_V_read303_phi_reg_20216() {
    ap_phi_reg_pp0_iter0_data_277_V_read303_phi_reg_20216 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_278_V_read304_phi_reg_20228() {
    ap_phi_reg_pp0_iter0_data_278_V_read304_phi_reg_20228 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_279_V_read305_phi_reg_20240() {
    ap_phi_reg_pp0_iter0_data_279_V_read305_phi_reg_20240 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_27_V_read53_phi_reg_17216() {
    ap_phi_reg_pp0_iter0_data_27_V_read53_phi_reg_17216 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_280_V_read306_phi_reg_20252() {
    ap_phi_reg_pp0_iter0_data_280_V_read306_phi_reg_20252 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_281_V_read307_phi_reg_20264() {
    ap_phi_reg_pp0_iter0_data_281_V_read307_phi_reg_20264 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_282_V_read308_phi_reg_20276() {
    ap_phi_reg_pp0_iter0_data_282_V_read308_phi_reg_20276 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_283_V_read309_phi_reg_20288() {
    ap_phi_reg_pp0_iter0_data_283_V_read309_phi_reg_20288 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_284_V_read310_phi_reg_20300() {
    ap_phi_reg_pp0_iter0_data_284_V_read310_phi_reg_20300 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_285_V_read311_phi_reg_20312() {
    ap_phi_reg_pp0_iter0_data_285_V_read311_phi_reg_20312 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_286_V_read312_phi_reg_20324() {
    ap_phi_reg_pp0_iter0_data_286_V_read312_phi_reg_20324 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_287_V_read313_phi_reg_20336() {
    ap_phi_reg_pp0_iter0_data_287_V_read313_phi_reg_20336 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_288_V_read314_phi_reg_20348() {
    ap_phi_reg_pp0_iter0_data_288_V_read314_phi_reg_20348 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_289_V_read315_phi_reg_20360() {
    ap_phi_reg_pp0_iter0_data_289_V_read315_phi_reg_20360 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_28_V_read54_phi_reg_17228() {
    ap_phi_reg_pp0_iter0_data_28_V_read54_phi_reg_17228 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_290_V_read316_phi_reg_20372() {
    ap_phi_reg_pp0_iter0_data_290_V_read316_phi_reg_20372 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_291_V_read317_phi_reg_20384() {
    ap_phi_reg_pp0_iter0_data_291_V_read317_phi_reg_20384 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_292_V_read318_phi_reg_20396() {
    ap_phi_reg_pp0_iter0_data_292_V_read318_phi_reg_20396 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_293_V_read319_phi_reg_20408() {
    ap_phi_reg_pp0_iter0_data_293_V_read319_phi_reg_20408 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_294_V_read320_phi_reg_20420() {
    ap_phi_reg_pp0_iter0_data_294_V_read320_phi_reg_20420 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_295_V_read321_phi_reg_20432() {
    ap_phi_reg_pp0_iter0_data_295_V_read321_phi_reg_20432 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_296_V_read322_phi_reg_20444() {
    ap_phi_reg_pp0_iter0_data_296_V_read322_phi_reg_20444 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_297_V_read323_phi_reg_20456() {
    ap_phi_reg_pp0_iter0_data_297_V_read323_phi_reg_20456 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_298_V_read324_phi_reg_20468() {
    ap_phi_reg_pp0_iter0_data_298_V_read324_phi_reg_20468 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_299_V_read325_phi_reg_20480() {
    ap_phi_reg_pp0_iter0_data_299_V_read325_phi_reg_20480 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_29_V_read55_phi_reg_17240() {
    ap_phi_reg_pp0_iter0_data_29_V_read55_phi_reg_17240 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_2_V_read28_phi_reg_16916() {
    ap_phi_reg_pp0_iter0_data_2_V_read28_phi_reg_16916 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_300_V_read326_phi_reg_20492() {
    ap_phi_reg_pp0_iter0_data_300_V_read326_phi_reg_20492 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_301_V_read327_phi_reg_20504() {
    ap_phi_reg_pp0_iter0_data_301_V_read327_phi_reg_20504 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_302_V_read328_phi_reg_20516() {
    ap_phi_reg_pp0_iter0_data_302_V_read328_phi_reg_20516 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_303_V_read329_phi_reg_20528() {
    ap_phi_reg_pp0_iter0_data_303_V_read329_phi_reg_20528 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_304_V_read330_phi_reg_20540() {
    ap_phi_reg_pp0_iter0_data_304_V_read330_phi_reg_20540 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_305_V_read331_phi_reg_20552() {
    ap_phi_reg_pp0_iter0_data_305_V_read331_phi_reg_20552 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_306_V_read332_phi_reg_20564() {
    ap_phi_reg_pp0_iter0_data_306_V_read332_phi_reg_20564 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_307_V_read333_phi_reg_20576() {
    ap_phi_reg_pp0_iter0_data_307_V_read333_phi_reg_20576 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_308_V_read334_phi_reg_20588() {
    ap_phi_reg_pp0_iter0_data_308_V_read334_phi_reg_20588 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_309_V_read335_phi_reg_20600() {
    ap_phi_reg_pp0_iter0_data_309_V_read335_phi_reg_20600 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_30_V_read56_phi_reg_17252() {
    ap_phi_reg_pp0_iter0_data_30_V_read56_phi_reg_17252 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_310_V_read336_phi_reg_20612() {
    ap_phi_reg_pp0_iter0_data_310_V_read336_phi_reg_20612 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_311_V_read337_phi_reg_20624() {
    ap_phi_reg_pp0_iter0_data_311_V_read337_phi_reg_20624 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_312_V_read338_phi_reg_20636() {
    ap_phi_reg_pp0_iter0_data_312_V_read338_phi_reg_20636 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_313_V_read339_phi_reg_20648() {
    ap_phi_reg_pp0_iter0_data_313_V_read339_phi_reg_20648 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_314_V_read340_phi_reg_20660() {
    ap_phi_reg_pp0_iter0_data_314_V_read340_phi_reg_20660 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_315_V_read341_phi_reg_20672() {
    ap_phi_reg_pp0_iter0_data_315_V_read341_phi_reg_20672 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_316_V_read342_phi_reg_20684() {
    ap_phi_reg_pp0_iter0_data_316_V_read342_phi_reg_20684 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_317_V_read343_phi_reg_20696() {
    ap_phi_reg_pp0_iter0_data_317_V_read343_phi_reg_20696 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_318_V_read344_phi_reg_20708() {
    ap_phi_reg_pp0_iter0_data_318_V_read344_phi_reg_20708 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_319_V_read345_phi_reg_20720() {
    ap_phi_reg_pp0_iter0_data_319_V_read345_phi_reg_20720 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_31_V_read57_phi_reg_17264() {
    ap_phi_reg_pp0_iter0_data_31_V_read57_phi_reg_17264 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_320_V_read346_phi_reg_20732() {
    ap_phi_reg_pp0_iter0_data_320_V_read346_phi_reg_20732 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_321_V_read347_phi_reg_20744() {
    ap_phi_reg_pp0_iter0_data_321_V_read347_phi_reg_20744 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_322_V_read348_phi_reg_20756() {
    ap_phi_reg_pp0_iter0_data_322_V_read348_phi_reg_20756 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_323_V_read349_phi_reg_20768() {
    ap_phi_reg_pp0_iter0_data_323_V_read349_phi_reg_20768 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_324_V_read350_phi_reg_20780() {
    ap_phi_reg_pp0_iter0_data_324_V_read350_phi_reg_20780 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_325_V_read351_phi_reg_20792() {
    ap_phi_reg_pp0_iter0_data_325_V_read351_phi_reg_20792 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_326_V_read352_phi_reg_20804() {
    ap_phi_reg_pp0_iter0_data_326_V_read352_phi_reg_20804 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_327_V_read353_phi_reg_20816() {
    ap_phi_reg_pp0_iter0_data_327_V_read353_phi_reg_20816 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_328_V_read354_phi_reg_20828() {
    ap_phi_reg_pp0_iter0_data_328_V_read354_phi_reg_20828 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_329_V_read355_phi_reg_20840() {
    ap_phi_reg_pp0_iter0_data_329_V_read355_phi_reg_20840 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_32_V_read58_phi_reg_17276() {
    ap_phi_reg_pp0_iter0_data_32_V_read58_phi_reg_17276 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_330_V_read356_phi_reg_20852() {
    ap_phi_reg_pp0_iter0_data_330_V_read356_phi_reg_20852 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_331_V_read357_phi_reg_20864() {
    ap_phi_reg_pp0_iter0_data_331_V_read357_phi_reg_20864 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_332_V_read358_phi_reg_20876() {
    ap_phi_reg_pp0_iter0_data_332_V_read358_phi_reg_20876 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_333_V_read359_phi_reg_20888() {
    ap_phi_reg_pp0_iter0_data_333_V_read359_phi_reg_20888 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_334_V_read360_phi_reg_20900() {
    ap_phi_reg_pp0_iter0_data_334_V_read360_phi_reg_20900 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_335_V_read361_phi_reg_20912() {
    ap_phi_reg_pp0_iter0_data_335_V_read361_phi_reg_20912 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_336_V_read362_phi_reg_20924() {
    ap_phi_reg_pp0_iter0_data_336_V_read362_phi_reg_20924 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_337_V_read363_phi_reg_20936() {
    ap_phi_reg_pp0_iter0_data_337_V_read363_phi_reg_20936 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_338_V_read364_phi_reg_20948() {
    ap_phi_reg_pp0_iter0_data_338_V_read364_phi_reg_20948 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_339_V_read365_phi_reg_20960() {
    ap_phi_reg_pp0_iter0_data_339_V_read365_phi_reg_20960 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_33_V_read59_phi_reg_17288() {
    ap_phi_reg_pp0_iter0_data_33_V_read59_phi_reg_17288 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_340_V_read366_phi_reg_20972() {
    ap_phi_reg_pp0_iter0_data_340_V_read366_phi_reg_20972 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_341_V_read367_phi_reg_20984() {
    ap_phi_reg_pp0_iter0_data_341_V_read367_phi_reg_20984 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_342_V_read368_phi_reg_20996() {
    ap_phi_reg_pp0_iter0_data_342_V_read368_phi_reg_20996 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_343_V_read369_phi_reg_21008() {
    ap_phi_reg_pp0_iter0_data_343_V_read369_phi_reg_21008 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_344_V_read370_phi_reg_21020() {
    ap_phi_reg_pp0_iter0_data_344_V_read370_phi_reg_21020 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_345_V_read371_phi_reg_21032() {
    ap_phi_reg_pp0_iter0_data_345_V_read371_phi_reg_21032 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_346_V_read372_phi_reg_21044() {
    ap_phi_reg_pp0_iter0_data_346_V_read372_phi_reg_21044 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_347_V_read373_phi_reg_21056() {
    ap_phi_reg_pp0_iter0_data_347_V_read373_phi_reg_21056 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_348_V_read374_phi_reg_21068() {
    ap_phi_reg_pp0_iter0_data_348_V_read374_phi_reg_21068 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_349_V_read375_phi_reg_21080() {
    ap_phi_reg_pp0_iter0_data_349_V_read375_phi_reg_21080 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_34_V_read60_phi_reg_17300() {
    ap_phi_reg_pp0_iter0_data_34_V_read60_phi_reg_17300 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_350_V_read376_phi_reg_21092() {
    ap_phi_reg_pp0_iter0_data_350_V_read376_phi_reg_21092 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_351_V_read377_phi_reg_21104() {
    ap_phi_reg_pp0_iter0_data_351_V_read377_phi_reg_21104 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_352_V_read378_phi_reg_21116() {
    ap_phi_reg_pp0_iter0_data_352_V_read378_phi_reg_21116 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_353_V_read379_phi_reg_21128() {
    ap_phi_reg_pp0_iter0_data_353_V_read379_phi_reg_21128 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_354_V_read380_phi_reg_21140() {
    ap_phi_reg_pp0_iter0_data_354_V_read380_phi_reg_21140 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_355_V_read381_phi_reg_21152() {
    ap_phi_reg_pp0_iter0_data_355_V_read381_phi_reg_21152 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_356_V_read382_phi_reg_21164() {
    ap_phi_reg_pp0_iter0_data_356_V_read382_phi_reg_21164 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_357_V_read383_phi_reg_21176() {
    ap_phi_reg_pp0_iter0_data_357_V_read383_phi_reg_21176 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_358_V_read384_phi_reg_21188() {
    ap_phi_reg_pp0_iter0_data_358_V_read384_phi_reg_21188 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_359_V_read385_phi_reg_21200() {
    ap_phi_reg_pp0_iter0_data_359_V_read385_phi_reg_21200 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_35_V_read61_phi_reg_17312() {
    ap_phi_reg_pp0_iter0_data_35_V_read61_phi_reg_17312 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_360_V_read386_phi_reg_21212() {
    ap_phi_reg_pp0_iter0_data_360_V_read386_phi_reg_21212 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_361_V_read387_phi_reg_21224() {
    ap_phi_reg_pp0_iter0_data_361_V_read387_phi_reg_21224 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_362_V_read388_phi_reg_21236() {
    ap_phi_reg_pp0_iter0_data_362_V_read388_phi_reg_21236 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_363_V_read389_phi_reg_21248() {
    ap_phi_reg_pp0_iter0_data_363_V_read389_phi_reg_21248 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_364_V_read390_phi_reg_21260() {
    ap_phi_reg_pp0_iter0_data_364_V_read390_phi_reg_21260 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_365_V_read391_phi_reg_21272() {
    ap_phi_reg_pp0_iter0_data_365_V_read391_phi_reg_21272 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_366_V_read392_phi_reg_21284() {
    ap_phi_reg_pp0_iter0_data_366_V_read392_phi_reg_21284 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_367_V_read393_phi_reg_21296() {
    ap_phi_reg_pp0_iter0_data_367_V_read393_phi_reg_21296 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_368_V_read394_phi_reg_21308() {
    ap_phi_reg_pp0_iter0_data_368_V_read394_phi_reg_21308 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_369_V_read395_phi_reg_21320() {
    ap_phi_reg_pp0_iter0_data_369_V_read395_phi_reg_21320 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_36_V_read62_phi_reg_17324() {
    ap_phi_reg_pp0_iter0_data_36_V_read62_phi_reg_17324 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_370_V_read396_phi_reg_21332() {
    ap_phi_reg_pp0_iter0_data_370_V_read396_phi_reg_21332 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_371_V_read397_phi_reg_21344() {
    ap_phi_reg_pp0_iter0_data_371_V_read397_phi_reg_21344 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_372_V_read398_phi_reg_21356() {
    ap_phi_reg_pp0_iter0_data_372_V_read398_phi_reg_21356 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_373_V_read399_phi_reg_21368() {
    ap_phi_reg_pp0_iter0_data_373_V_read399_phi_reg_21368 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_374_V_read400_phi_reg_21380() {
    ap_phi_reg_pp0_iter0_data_374_V_read400_phi_reg_21380 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_375_V_read401_phi_reg_21392() {
    ap_phi_reg_pp0_iter0_data_375_V_read401_phi_reg_21392 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_376_V_read402_phi_reg_21404() {
    ap_phi_reg_pp0_iter0_data_376_V_read402_phi_reg_21404 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_377_V_read403_phi_reg_21416() {
    ap_phi_reg_pp0_iter0_data_377_V_read403_phi_reg_21416 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_378_V_read404_phi_reg_21428() {
    ap_phi_reg_pp0_iter0_data_378_V_read404_phi_reg_21428 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_379_V_read405_phi_reg_21440() {
    ap_phi_reg_pp0_iter0_data_379_V_read405_phi_reg_21440 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_37_V_read63_phi_reg_17336() {
    ap_phi_reg_pp0_iter0_data_37_V_read63_phi_reg_17336 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_380_V_read406_phi_reg_21452() {
    ap_phi_reg_pp0_iter0_data_380_V_read406_phi_reg_21452 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_381_V_read407_phi_reg_21464() {
    ap_phi_reg_pp0_iter0_data_381_V_read407_phi_reg_21464 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_382_V_read408_phi_reg_21476() {
    ap_phi_reg_pp0_iter0_data_382_V_read408_phi_reg_21476 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_383_V_read409_phi_reg_21488() {
    ap_phi_reg_pp0_iter0_data_383_V_read409_phi_reg_21488 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_384_V_read410_phi_reg_21500() {
    ap_phi_reg_pp0_iter0_data_384_V_read410_phi_reg_21500 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_385_V_read411_phi_reg_21512() {
    ap_phi_reg_pp0_iter0_data_385_V_read411_phi_reg_21512 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_386_V_read412_phi_reg_21524() {
    ap_phi_reg_pp0_iter0_data_386_V_read412_phi_reg_21524 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_387_V_read413_phi_reg_21536() {
    ap_phi_reg_pp0_iter0_data_387_V_read413_phi_reg_21536 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_388_V_read414_phi_reg_21548() {
    ap_phi_reg_pp0_iter0_data_388_V_read414_phi_reg_21548 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_389_V_read415_phi_reg_21560() {
    ap_phi_reg_pp0_iter0_data_389_V_read415_phi_reg_21560 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_38_V_read64_phi_reg_17348() {
    ap_phi_reg_pp0_iter0_data_38_V_read64_phi_reg_17348 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_390_V_read416_phi_reg_21572() {
    ap_phi_reg_pp0_iter0_data_390_V_read416_phi_reg_21572 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_391_V_read417_phi_reg_21584() {
    ap_phi_reg_pp0_iter0_data_391_V_read417_phi_reg_21584 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_392_V_read418_phi_reg_21596() {
    ap_phi_reg_pp0_iter0_data_392_V_read418_phi_reg_21596 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_393_V_read419_phi_reg_21608() {
    ap_phi_reg_pp0_iter0_data_393_V_read419_phi_reg_21608 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_394_V_read420_phi_reg_21620() {
    ap_phi_reg_pp0_iter0_data_394_V_read420_phi_reg_21620 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_395_V_read421_phi_reg_21632() {
    ap_phi_reg_pp0_iter0_data_395_V_read421_phi_reg_21632 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_396_V_read422_phi_reg_21644() {
    ap_phi_reg_pp0_iter0_data_396_V_read422_phi_reg_21644 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_397_V_read423_phi_reg_21656() {
    ap_phi_reg_pp0_iter0_data_397_V_read423_phi_reg_21656 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_398_V_read424_phi_reg_21668() {
    ap_phi_reg_pp0_iter0_data_398_V_read424_phi_reg_21668 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_399_V_read425_phi_reg_21680() {
    ap_phi_reg_pp0_iter0_data_399_V_read425_phi_reg_21680 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_39_V_read65_phi_reg_17360() {
    ap_phi_reg_pp0_iter0_data_39_V_read65_phi_reg_17360 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_3_V_read29_phi_reg_16928() {
    ap_phi_reg_pp0_iter0_data_3_V_read29_phi_reg_16928 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_40_V_read66_phi_reg_17372() {
    ap_phi_reg_pp0_iter0_data_40_V_read66_phi_reg_17372 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_41_V_read67_phi_reg_17384() {
    ap_phi_reg_pp0_iter0_data_41_V_read67_phi_reg_17384 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_42_V_read68_phi_reg_17396() {
    ap_phi_reg_pp0_iter0_data_42_V_read68_phi_reg_17396 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_43_V_read69_phi_reg_17408() {
    ap_phi_reg_pp0_iter0_data_43_V_read69_phi_reg_17408 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_44_V_read70_phi_reg_17420() {
    ap_phi_reg_pp0_iter0_data_44_V_read70_phi_reg_17420 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_45_V_read71_phi_reg_17432() {
    ap_phi_reg_pp0_iter0_data_45_V_read71_phi_reg_17432 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_46_V_read72_phi_reg_17444() {
    ap_phi_reg_pp0_iter0_data_46_V_read72_phi_reg_17444 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_47_V_read73_phi_reg_17456() {
    ap_phi_reg_pp0_iter0_data_47_V_read73_phi_reg_17456 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_48_V_read74_phi_reg_17468() {
    ap_phi_reg_pp0_iter0_data_48_V_read74_phi_reg_17468 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_49_V_read75_phi_reg_17480() {
    ap_phi_reg_pp0_iter0_data_49_V_read75_phi_reg_17480 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_4_V_read30_phi_reg_16940() {
    ap_phi_reg_pp0_iter0_data_4_V_read30_phi_reg_16940 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_50_V_read76_phi_reg_17492() {
    ap_phi_reg_pp0_iter0_data_50_V_read76_phi_reg_17492 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_51_V_read77_phi_reg_17504() {
    ap_phi_reg_pp0_iter0_data_51_V_read77_phi_reg_17504 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_52_V_read78_phi_reg_17516() {
    ap_phi_reg_pp0_iter0_data_52_V_read78_phi_reg_17516 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_53_V_read79_phi_reg_17528() {
    ap_phi_reg_pp0_iter0_data_53_V_read79_phi_reg_17528 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_54_V_read80_phi_reg_17540() {
    ap_phi_reg_pp0_iter0_data_54_V_read80_phi_reg_17540 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_55_V_read81_phi_reg_17552() {
    ap_phi_reg_pp0_iter0_data_55_V_read81_phi_reg_17552 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_56_V_read82_phi_reg_17564() {
    ap_phi_reg_pp0_iter0_data_56_V_read82_phi_reg_17564 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_57_V_read83_phi_reg_17576() {
    ap_phi_reg_pp0_iter0_data_57_V_read83_phi_reg_17576 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_58_V_read84_phi_reg_17588() {
    ap_phi_reg_pp0_iter0_data_58_V_read84_phi_reg_17588 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_59_V_read85_phi_reg_17600() {
    ap_phi_reg_pp0_iter0_data_59_V_read85_phi_reg_17600 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_5_V_read31_phi_reg_16952() {
    ap_phi_reg_pp0_iter0_data_5_V_read31_phi_reg_16952 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_60_V_read86_phi_reg_17612() {
    ap_phi_reg_pp0_iter0_data_60_V_read86_phi_reg_17612 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_61_V_read87_phi_reg_17624() {
    ap_phi_reg_pp0_iter0_data_61_V_read87_phi_reg_17624 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_62_V_read88_phi_reg_17636() {
    ap_phi_reg_pp0_iter0_data_62_V_read88_phi_reg_17636 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_63_V_read89_phi_reg_17648() {
    ap_phi_reg_pp0_iter0_data_63_V_read89_phi_reg_17648 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_64_V_read90_phi_reg_17660() {
    ap_phi_reg_pp0_iter0_data_64_V_read90_phi_reg_17660 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_65_V_read91_phi_reg_17672() {
    ap_phi_reg_pp0_iter0_data_65_V_read91_phi_reg_17672 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_66_V_read92_phi_reg_17684() {
    ap_phi_reg_pp0_iter0_data_66_V_read92_phi_reg_17684 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_67_V_read93_phi_reg_17696() {
    ap_phi_reg_pp0_iter0_data_67_V_read93_phi_reg_17696 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_68_V_read94_phi_reg_17708() {
    ap_phi_reg_pp0_iter0_data_68_V_read94_phi_reg_17708 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_69_V_read95_phi_reg_17720() {
    ap_phi_reg_pp0_iter0_data_69_V_read95_phi_reg_17720 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_6_V_read32_phi_reg_16964() {
    ap_phi_reg_pp0_iter0_data_6_V_read32_phi_reg_16964 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_70_V_read96_phi_reg_17732() {
    ap_phi_reg_pp0_iter0_data_70_V_read96_phi_reg_17732 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_71_V_read97_phi_reg_17744() {
    ap_phi_reg_pp0_iter0_data_71_V_read97_phi_reg_17744 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_72_V_read98_phi_reg_17756() {
    ap_phi_reg_pp0_iter0_data_72_V_read98_phi_reg_17756 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_73_V_read99_phi_reg_17768() {
    ap_phi_reg_pp0_iter0_data_73_V_read99_phi_reg_17768 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_74_V_read100_phi_reg_17780() {
    ap_phi_reg_pp0_iter0_data_74_V_read100_phi_reg_17780 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_75_V_read101_phi_reg_17792() {
    ap_phi_reg_pp0_iter0_data_75_V_read101_phi_reg_17792 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_76_V_read102_phi_reg_17804() {
    ap_phi_reg_pp0_iter0_data_76_V_read102_phi_reg_17804 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_77_V_read103_phi_reg_17816() {
    ap_phi_reg_pp0_iter0_data_77_V_read103_phi_reg_17816 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_78_V_read104_phi_reg_17828() {
    ap_phi_reg_pp0_iter0_data_78_V_read104_phi_reg_17828 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_79_V_read105_phi_reg_17840() {
    ap_phi_reg_pp0_iter0_data_79_V_read105_phi_reg_17840 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_7_V_read33_phi_reg_16976() {
    ap_phi_reg_pp0_iter0_data_7_V_read33_phi_reg_16976 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_80_V_read106_phi_reg_17852() {
    ap_phi_reg_pp0_iter0_data_80_V_read106_phi_reg_17852 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_81_V_read107_phi_reg_17864() {
    ap_phi_reg_pp0_iter0_data_81_V_read107_phi_reg_17864 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_82_V_read108_phi_reg_17876() {
    ap_phi_reg_pp0_iter0_data_82_V_read108_phi_reg_17876 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_83_V_read109_phi_reg_17888() {
    ap_phi_reg_pp0_iter0_data_83_V_read109_phi_reg_17888 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_84_V_read110_phi_reg_17900() {
    ap_phi_reg_pp0_iter0_data_84_V_read110_phi_reg_17900 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_85_V_read111_phi_reg_17912() {
    ap_phi_reg_pp0_iter0_data_85_V_read111_phi_reg_17912 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_86_V_read112_phi_reg_17924() {
    ap_phi_reg_pp0_iter0_data_86_V_read112_phi_reg_17924 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_87_V_read113_phi_reg_17936() {
    ap_phi_reg_pp0_iter0_data_87_V_read113_phi_reg_17936 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_88_V_read114_phi_reg_17948() {
    ap_phi_reg_pp0_iter0_data_88_V_read114_phi_reg_17948 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_89_V_read115_phi_reg_17960() {
    ap_phi_reg_pp0_iter0_data_89_V_read115_phi_reg_17960 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_8_V_read34_phi_reg_16988() {
    ap_phi_reg_pp0_iter0_data_8_V_read34_phi_reg_16988 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_90_V_read116_phi_reg_17972() {
    ap_phi_reg_pp0_iter0_data_90_V_read116_phi_reg_17972 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_91_V_read117_phi_reg_17984() {
    ap_phi_reg_pp0_iter0_data_91_V_read117_phi_reg_17984 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_92_V_read118_phi_reg_17996() {
    ap_phi_reg_pp0_iter0_data_92_V_read118_phi_reg_17996 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_93_V_read119_phi_reg_18008() {
    ap_phi_reg_pp0_iter0_data_93_V_read119_phi_reg_18008 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_94_V_read120_phi_reg_18020() {
    ap_phi_reg_pp0_iter0_data_94_V_read120_phi_reg_18020 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_95_V_read121_phi_reg_18032() {
    ap_phi_reg_pp0_iter0_data_95_V_read121_phi_reg_18032 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_96_V_read122_phi_reg_18044() {
    ap_phi_reg_pp0_iter0_data_96_V_read122_phi_reg_18044 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_97_V_read123_phi_reg_18056() {
    ap_phi_reg_pp0_iter0_data_97_V_read123_phi_reg_18056 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_98_V_read124_phi_reg_18068() {
    ap_phi_reg_pp0_iter0_data_98_V_read124_phi_reg_18068 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_99_V_read125_phi_reg_18080() {
    ap_phi_reg_pp0_iter0_data_99_V_read125_phi_reg_18080 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_9_V_read35_phi_reg_17000() {
    ap_phi_reg_pp0_iter0_data_9_V_read35_phi_reg_17000 =  (sc_lv<3>) ("XXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_ready() {
    if ((esl_seteq<1,1,1>(ap_phi_mux_w_index25_phi_fu_11281_p6.read(), ap_const_lv1_1) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        ap_ready = ap_const_logic_1;
    } else {
        ap_ready = ap_const_logic_0;
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_reset_idle_pp0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_idle_pp0_0to2.read()))) {
        ap_reset_idle_pp0 = ap_const_logic_1;
    } else {
        ap_reset_idle_pp0 = ap_const_logic_0;
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_0() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter2_reg.read()))) {
        ap_return_0 = acc_0_V_fu_103412_p2.read();
    } else {
        ap_return_0 = ap_return_0_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_1() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter2_reg.read()))) {
        ap_return_1 = acc_1_V_fu_103462_p2.read();
    } else {
        ap_return_1 = ap_return_1_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_2() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter2_reg.read()))) {
        ap_return_2 = acc_2_V_fu_103512_p2.read();
    } else {
        ap_return_2 = ap_return_2_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_3() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter2_reg.read()))) {
        ap_return_3 = acc_3_V_fu_103562_p2.read();
    } else {
        ap_return_3 = ap_return_3_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_4() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter2_reg.read()))) {
        ap_return_4 = acc_4_V_fu_103612_p2.read();
    } else {
        ap_return_4 = ap_return_4_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_5() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter2_reg.read()))) {
        ap_return_5 = acc_5_V_fu_103662_p2.read();
    } else {
        ap_return_5 = ap_return_5_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter2_reg.read()))) {
        ap_return_6 = acc_6_V_fu_103712_p2.read();
    } else {
        ap_return_6 = ap_return_6_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_7() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter2_reg.read()))) {
        ap_return_7 = acc_7_V_fu_103762_p2.read();
    } else {
        ap_return_7 = ap_return_7_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_8() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter2_reg.read()))) {
        ap_return_8 = acc_8_V_fu_103812_p2.read();
    } else {
        ap_return_8 = ap_return_8_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_9() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11277_pp0_iter2_reg.read()))) {
        ap_return_9 = acc_9_V_fu_103862_p2.read();
    } else {
        ap_return_9 = ap_return_9_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1000_fu_51353_p0() {
    mul_ln1118_1000_fu_51353_p0 =  (sc_lv<3>) (sext_ln1116_200_fu_28969_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1000_fu_51353_p1() {
    mul_ln1118_1000_fu_51353_p1 = tmp_1000_fu_51339_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1000_fu_51353_p2() {
    mul_ln1118_1000_fu_51353_p2 = (!mul_ln1118_1000_fu_51353_p0.read().is_01() || !mul_ln1118_1000_fu_51353_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1000_fu_51353_p0.read()) * sc_bigint<5>(mul_ln1118_1000_fu_51353_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1001_fu_51385_p0() {
    mul_ln1118_1001_fu_51385_p0 =  (sc_lv<3>) (sext_ln1116_201_fu_29013_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1001_fu_51385_p1() {
    mul_ln1118_1001_fu_51385_p1 = tmp_1001_fu_51371_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1001_fu_51385_p2() {
    mul_ln1118_1001_fu_51385_p2 = (!mul_ln1118_1001_fu_51385_p0.read().is_01() || !mul_ln1118_1001_fu_51385_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1001_fu_51385_p0.read()) * sc_bigint<5>(mul_ln1118_1001_fu_51385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1002_fu_90594_p0() {
    mul_ln1118_1002_fu_90594_p0 =  (sc_lv<3>) (sext_ln1116_202_reg_106753.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1002_fu_90594_p1() {
    mul_ln1118_1002_fu_90594_p1 = tmp_1002_reg_109381.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1002_fu_90594_p2() {
    mul_ln1118_1002_fu_90594_p2 = (!mul_ln1118_1002_fu_90594_p0.read().is_01() || !mul_ln1118_1002_fu_90594_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1002_fu_90594_p0.read()) * sc_bigint<5>(mul_ln1118_1002_fu_90594_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1003_fu_51427_p0() {
    mul_ln1118_1003_fu_51427_p0 =  (sc_lv<3>) (sext_ln1116_203_fu_29079_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1003_fu_51427_p1() {
    mul_ln1118_1003_fu_51427_p1 = tmp_1003_fu_51413_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1003_fu_51427_p2() {
    mul_ln1118_1003_fu_51427_p2 = (!mul_ln1118_1003_fu_51427_p0.read().is_01() || !mul_ln1118_1003_fu_51427_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1003_fu_51427_p0.read()) * sc_bigint<5>(mul_ln1118_1003_fu_51427_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1004_fu_51459_p0() {
    mul_ln1118_1004_fu_51459_p0 =  (sc_lv<3>) (sext_ln1116_204_fu_29123_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1004_fu_51459_p1() {
    mul_ln1118_1004_fu_51459_p1 = tmp_1004_fu_51445_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1004_fu_51459_p2() {
    mul_ln1118_1004_fu_51459_p2 = (!mul_ln1118_1004_fu_51459_p0.read().is_01() || !mul_ln1118_1004_fu_51459_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1004_fu_51459_p0.read()) * sc_bigint<5>(mul_ln1118_1004_fu_51459_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1005_fu_51491_p0() {
    mul_ln1118_1005_fu_51491_p0 =  (sc_lv<3>) (sext_ln1116_205_fu_29167_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1005_fu_51491_p1() {
    mul_ln1118_1005_fu_51491_p1 = tmp_1005_fu_51477_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1005_fu_51491_p2() {
    mul_ln1118_1005_fu_51491_p2 = (!mul_ln1118_1005_fu_51491_p0.read().is_01() || !mul_ln1118_1005_fu_51491_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1005_fu_51491_p0.read()) * sc_bigint<5>(mul_ln1118_1005_fu_51491_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1006_fu_51523_p0() {
    mul_ln1118_1006_fu_51523_p0 =  (sc_lv<3>) (sext_ln1116_206_fu_29211_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1006_fu_51523_p1() {
    mul_ln1118_1006_fu_51523_p1 = tmp_1006_fu_51509_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1006_fu_51523_p2() {
    mul_ln1118_1006_fu_51523_p2 = (!mul_ln1118_1006_fu_51523_p0.read().is_01() || !mul_ln1118_1006_fu_51523_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1006_fu_51523_p0.read()) * sc_bigint<5>(mul_ln1118_1006_fu_51523_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1007_fu_51555_p0() {
    mul_ln1118_1007_fu_51555_p0 =  (sc_lv<3>) (sext_ln1116_207_fu_29255_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1007_fu_51555_p1() {
    mul_ln1118_1007_fu_51555_p1 = tmp_1007_fu_51541_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1007_fu_51555_p2() {
    mul_ln1118_1007_fu_51555_p2 = (!mul_ln1118_1007_fu_51555_p0.read().is_01() || !mul_ln1118_1007_fu_51555_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1007_fu_51555_p0.read()) * sc_bigint<5>(mul_ln1118_1007_fu_51555_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1008_fu_51587_p0() {
    mul_ln1118_1008_fu_51587_p0 =  (sc_lv<3>) (sext_ln1116_208_fu_29299_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1008_fu_51587_p1() {
    mul_ln1118_1008_fu_51587_p1 = tmp_1008_fu_51573_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1008_fu_51587_p2() {
    mul_ln1118_1008_fu_51587_p2 = (!mul_ln1118_1008_fu_51587_p0.read().is_01() || !mul_ln1118_1008_fu_51587_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1008_fu_51587_p0.read()) * sc_bigint<5>(mul_ln1118_1008_fu_51587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1009_fu_52033_p0() {
    mul_ln1118_1009_fu_52033_p0 =  (sc_lv<3>) (sext_ln1116_fu_21855_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1009_fu_52033_p1() {
    mul_ln1118_1009_fu_52033_p1 = tmp_1009_fu_52019_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1009_fu_52033_p2() {
    mul_ln1118_1009_fu_52033_p2 = (!mul_ln1118_1009_fu_52033_p0.read().is_01() || !mul_ln1118_1009_fu_52033_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1009_fu_52033_p0.read()) * sc_bigint<5>(mul_ln1118_1009_fu_52033_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_100_fu_25197_p0() {
    mul_ln1118_100_fu_25197_p0 =  (sc_lv<3>) (sext_ln1116_100_fu_25189_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_100_fu_25197_p1() {
    mul_ln1118_100_fu_25197_p1 = tmp_100_fu_25179_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_100_fu_25197_p2() {
    mul_ln1118_100_fu_25197_p2 = (!mul_ln1118_100_fu_25197_p0.read().is_01() || !mul_ln1118_100_fu_25197_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_100_fu_25197_p0.read()) * sc_bigint<5>(mul_ln1118_100_fu_25197_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1010_fu_52053_p0() {
    mul_ln1118_1010_fu_52053_p0 =  (sc_lv<3>) (sext_ln1116_10_fu_21887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1010_fu_52053_p1() {
    mul_ln1118_1010_fu_52053_p1 = tmp_1010_fu_52039_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1010_fu_52053_p2() {
    mul_ln1118_1010_fu_52053_p2 = (!mul_ln1118_1010_fu_52053_p0.read().is_01() || !mul_ln1118_1010_fu_52053_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1010_fu_52053_p0.read()) * sc_bigint<5>(mul_ln1118_1010_fu_52053_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1011_fu_52085_p0() {
    mul_ln1118_1011_fu_52085_p0 =  (sc_lv<3>) (sext_ln1116_11_fu_21931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1011_fu_52085_p1() {
    mul_ln1118_1011_fu_52085_p1 = tmp_1011_fu_52071_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1011_fu_52085_p2() {
    mul_ln1118_1011_fu_52085_p2 = (!mul_ln1118_1011_fu_52085_p0.read().is_01() || !mul_ln1118_1011_fu_52085_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1011_fu_52085_p0.read()) * sc_bigint<5>(mul_ln1118_1011_fu_52085_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1012_fu_52117_p0() {
    mul_ln1118_1012_fu_52117_p0 =  (sc_lv<3>) (sext_ln1116_12_fu_21975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1012_fu_52117_p1() {
    mul_ln1118_1012_fu_52117_p1 = tmp_1012_fu_52103_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1012_fu_52117_p2() {
    mul_ln1118_1012_fu_52117_p2 = (!mul_ln1118_1012_fu_52117_p0.read().is_01() || !mul_ln1118_1012_fu_52117_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1012_fu_52117_p0.read()) * sc_bigint<5>(mul_ln1118_1012_fu_52117_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1013_fu_52137_p0() {
    mul_ln1118_1013_fu_52137_p0 =  (sc_lv<3>) (sext_ln1116_13_fu_22007_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1013_fu_52137_p1() {
    mul_ln1118_1013_fu_52137_p1 = tmp_1013_fu_52123_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1013_fu_52137_p2() {
    mul_ln1118_1013_fu_52137_p2 = (!mul_ln1118_1013_fu_52137_p0.read().is_01() || !mul_ln1118_1013_fu_52137_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1013_fu_52137_p0.read()) * sc_bigint<5>(mul_ln1118_1013_fu_52137_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1014_fu_52169_p0() {
    mul_ln1118_1014_fu_52169_p0 =  (sc_lv<3>) (sext_ln1116_14_fu_22051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1014_fu_52169_p1() {
    mul_ln1118_1014_fu_52169_p1 = tmp_1014_fu_52155_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1014_fu_52169_p2() {
    mul_ln1118_1014_fu_52169_p2 = (!mul_ln1118_1014_fu_52169_p0.read().is_01() || !mul_ln1118_1014_fu_52169_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1014_fu_52169_p0.read()) * sc_bigint<5>(mul_ln1118_1014_fu_52169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1015_fu_91837_p0() {
    mul_ln1118_1015_fu_91837_p0 =  (sc_lv<3>) (sext_ln1116_15_fu_80033_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1015_fu_91837_p1() {
    mul_ln1118_1015_fu_91837_p1 = tmp_1015_reg_109741.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1015_fu_91837_p2() {
    mul_ln1118_1015_fu_91837_p2 = (!mul_ln1118_1015_fu_91837_p0.read().is_01() || !mul_ln1118_1015_fu_91837_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1015_fu_91837_p0.read()) * sc_bigint<5>(mul_ln1118_1015_fu_91837_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1016_fu_52211_p0() {
    mul_ln1118_1016_fu_52211_p0 =  (sc_lv<3>) (sext_ln1116_16_fu_22113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1016_fu_52211_p1() {
    mul_ln1118_1016_fu_52211_p1 = tmp_1016_fu_52197_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1016_fu_52211_p2() {
    mul_ln1118_1016_fu_52211_p2 = (!mul_ln1118_1016_fu_52211_p0.read().is_01() || !mul_ln1118_1016_fu_52211_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1016_fu_52211_p0.read()) * sc_bigint<5>(mul_ln1118_1016_fu_52211_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1017_fu_52243_p0() {
    mul_ln1118_1017_fu_52243_p0 =  (sc_lv<3>) (sext_ln1116_17_fu_22157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1017_fu_52243_p1() {
    mul_ln1118_1017_fu_52243_p1 = tmp_1017_fu_52229_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1017_fu_52243_p2() {
    mul_ln1118_1017_fu_52243_p2 = (!mul_ln1118_1017_fu_52243_p0.read().is_01() || !mul_ln1118_1017_fu_52243_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1017_fu_52243_p0.read()) * sc_bigint<5>(mul_ln1118_1017_fu_52243_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1018_fu_91858_p0() {
    mul_ln1118_1018_fu_91858_p0 =  (sc_lv<3>) (sext_ln1116_18_fu_80057_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1018_fu_91858_p1() {
    mul_ln1118_1018_fu_91858_p1 = tmp_1018_reg_109746.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1018_fu_91858_p2() {
    mul_ln1118_1018_fu_91858_p2 = (!mul_ln1118_1018_fu_91858_p0.read().is_01() || !mul_ln1118_1018_fu_91858_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1018_fu_91858_p0.read()) * sc_bigint<5>(mul_ln1118_1018_fu_91858_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1019_fu_52285_p0() {
    mul_ln1118_1019_fu_52285_p0 =  (sc_lv<3>) (sext_ln1116_19_fu_22219_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1019_fu_52285_p1() {
    mul_ln1118_1019_fu_52285_p1 = tmp_1019_fu_52271_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1019_fu_52285_p2() {
    mul_ln1118_1019_fu_52285_p2 = (!mul_ln1118_1019_fu_52285_p0.read().is_01() || !mul_ln1118_1019_fu_52285_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1019_fu_52285_p0.read()) * sc_bigint<5>(mul_ln1118_1019_fu_52285_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_101_fu_25241_p0() {
    mul_ln1118_101_fu_25241_p0 =  (sc_lv<3>) (sext_ln1116_101_fu_25233_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_101_fu_25241_p1() {
    mul_ln1118_101_fu_25241_p1 = tmp_101_fu_25223_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_101_fu_25241_p2() {
    mul_ln1118_101_fu_25241_p2 = (!mul_ln1118_101_fu_25241_p0.read().is_01() || !mul_ln1118_101_fu_25241_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_101_fu_25241_p0.read()) * sc_bigint<5>(mul_ln1118_101_fu_25241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1020_fu_52317_p0() {
    mul_ln1118_1020_fu_52317_p0 =  (sc_lv<3>) (sext_ln1116_20_fu_22263_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1020_fu_52317_p1() {
    mul_ln1118_1020_fu_52317_p1 = tmp_1020_fu_52303_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1020_fu_52317_p2() {
    mul_ln1118_1020_fu_52317_p2 = (!mul_ln1118_1020_fu_52317_p0.read().is_01() || !mul_ln1118_1020_fu_52317_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1020_fu_52317_p0.read()) * sc_bigint<5>(mul_ln1118_1020_fu_52317_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1021_fu_91879_p0() {
    mul_ln1118_1021_fu_91879_p0 =  (sc_lv<3>) (sext_ln1116_21_fu_80081_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1021_fu_91879_p1() {
    mul_ln1118_1021_fu_91879_p1 = tmp_1021_reg_109751.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1021_fu_91879_p2() {
    mul_ln1118_1021_fu_91879_p2 = (!mul_ln1118_1021_fu_91879_p0.read().is_01() || !mul_ln1118_1021_fu_91879_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1021_fu_91879_p0.read()) * sc_bigint<5>(mul_ln1118_1021_fu_91879_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1022_fu_52359_p0() {
    mul_ln1118_1022_fu_52359_p0 =  (sc_lv<3>) (sext_ln1116_22_fu_22325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1022_fu_52359_p1() {
    mul_ln1118_1022_fu_52359_p1 = tmp_1022_fu_52345_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1022_fu_52359_p2() {
    mul_ln1118_1022_fu_52359_p2 = (!mul_ln1118_1022_fu_52359_p0.read().is_01() || !mul_ln1118_1022_fu_52359_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1022_fu_52359_p0.read()) * sc_bigint<5>(mul_ln1118_1022_fu_52359_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1023_fu_52391_p0() {
    mul_ln1118_1023_fu_52391_p0 =  (sc_lv<3>) (sext_ln1116_23_fu_22369_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1023_fu_52391_p1() {
    mul_ln1118_1023_fu_52391_p1 = tmp_1023_fu_52377_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1023_fu_52391_p2() {
    mul_ln1118_1023_fu_52391_p2 = (!mul_ln1118_1023_fu_52391_p0.read().is_01() || !mul_ln1118_1023_fu_52391_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1023_fu_52391_p0.read()) * sc_bigint<5>(mul_ln1118_1023_fu_52391_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1024_fu_91900_p0() {
    mul_ln1118_1024_fu_91900_p0 =  (sc_lv<3>) (sext_ln1116_24_fu_80105_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1024_fu_91900_p1() {
    mul_ln1118_1024_fu_91900_p1 = tmp_1024_reg_109756.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1024_fu_91900_p2() {
    mul_ln1118_1024_fu_91900_p2 = (!mul_ln1118_1024_fu_91900_p0.read().is_01() || !mul_ln1118_1024_fu_91900_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1024_fu_91900_p0.read()) * sc_bigint<5>(mul_ln1118_1024_fu_91900_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1025_fu_52433_p0() {
    mul_ln1118_1025_fu_52433_p0 =  (sc_lv<3>) (sext_ln1116_25_fu_22431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1025_fu_52433_p1() {
    mul_ln1118_1025_fu_52433_p1 = tmp_1025_fu_52419_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1025_fu_52433_p2() {
    mul_ln1118_1025_fu_52433_p2 = (!mul_ln1118_1025_fu_52433_p0.read().is_01() || !mul_ln1118_1025_fu_52433_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1025_fu_52433_p0.read()) * sc_bigint<5>(mul_ln1118_1025_fu_52433_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1026_fu_52465_p0() {
    mul_ln1118_1026_fu_52465_p0 =  (sc_lv<3>) (sext_ln1116_26_fu_22475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1026_fu_52465_p1() {
    mul_ln1118_1026_fu_52465_p1 = tmp_1026_fu_52451_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1026_fu_52465_p2() {
    mul_ln1118_1026_fu_52465_p2 = (!mul_ln1118_1026_fu_52465_p0.read().is_01() || !mul_ln1118_1026_fu_52465_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1026_fu_52465_p0.read()) * sc_bigint<5>(mul_ln1118_1026_fu_52465_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1027_fu_91921_p0() {
    mul_ln1118_1027_fu_91921_p0 =  (sc_lv<3>) (sext_ln1116_27_fu_80129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1027_fu_91921_p1() {
    mul_ln1118_1027_fu_91921_p1 = tmp_1027_reg_109761.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1027_fu_91921_p2() {
    mul_ln1118_1027_fu_91921_p2 = (!mul_ln1118_1027_fu_91921_p0.read().is_01() || !mul_ln1118_1027_fu_91921_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1027_fu_91921_p0.read()) * sc_bigint<5>(mul_ln1118_1027_fu_91921_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1028_fu_52507_p0() {
    mul_ln1118_1028_fu_52507_p0 =  (sc_lv<3>) (sext_ln1116_28_fu_22537_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1028_fu_52507_p1() {
    mul_ln1118_1028_fu_52507_p1 = tmp_1028_fu_52493_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1028_fu_52507_p2() {
    mul_ln1118_1028_fu_52507_p2 = (!mul_ln1118_1028_fu_52507_p0.read().is_01() || !mul_ln1118_1028_fu_52507_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1028_fu_52507_p0.read()) * sc_bigint<5>(mul_ln1118_1028_fu_52507_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1029_fu_52539_p0() {
    mul_ln1118_1029_fu_52539_p0 =  (sc_lv<3>) (sext_ln1116_29_fu_22581_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1029_fu_52539_p1() {
    mul_ln1118_1029_fu_52539_p1 = tmp_1029_fu_52525_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1029_fu_52539_p2() {
    mul_ln1118_1029_fu_52539_p2 = (!mul_ln1118_1029_fu_52539_p0.read().is_01() || !mul_ln1118_1029_fu_52539_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1029_fu_52539_p0.read()) * sc_bigint<5>(mul_ln1118_1029_fu_52539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_102_fu_80628_p0() {
    mul_ln1118_102_fu_80628_p0 =  (sc_lv<3>) (sext_ln1116_102_reg_106331.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_102_fu_80628_p1() {
    mul_ln1118_102_fu_80628_p1 = tmp_102_reg_106326.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_102_fu_80628_p2() {
    mul_ln1118_102_fu_80628_p2 = (!mul_ln1118_102_fu_80628_p0.read().is_01() || !mul_ln1118_102_fu_80628_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_102_fu_80628_p0.read()) * sc_bigint<5>(mul_ln1118_102_fu_80628_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1030_fu_52571_p0() {
    mul_ln1118_1030_fu_52571_p0 =  (sc_lv<3>) (sext_ln1116_30_fu_22625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1030_fu_52571_p1() {
    mul_ln1118_1030_fu_52571_p1 = tmp_1030_fu_52557_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1030_fu_52571_p2() {
    mul_ln1118_1030_fu_52571_p2 = (!mul_ln1118_1030_fu_52571_p0.read().is_01() || !mul_ln1118_1030_fu_52571_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1030_fu_52571_p0.read()) * sc_bigint<5>(mul_ln1118_1030_fu_52571_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1031_fu_52603_p0() {
    mul_ln1118_1031_fu_52603_p0 =  (sc_lv<3>) (sext_ln1116_31_fu_22669_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1031_fu_52603_p1() {
    mul_ln1118_1031_fu_52603_p1 = tmp_1031_fu_52589_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1031_fu_52603_p2() {
    mul_ln1118_1031_fu_52603_p2 = (!mul_ln1118_1031_fu_52603_p0.read().is_01() || !mul_ln1118_1031_fu_52603_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1031_fu_52603_p0.read()) * sc_bigint<5>(mul_ln1118_1031_fu_52603_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1032_fu_52635_p0() {
    mul_ln1118_1032_fu_52635_p0 =  (sc_lv<3>) (sext_ln1116_32_fu_22713_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1032_fu_52635_p1() {
    mul_ln1118_1032_fu_52635_p1 = tmp_1032_fu_52621_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1032_fu_52635_p2() {
    mul_ln1118_1032_fu_52635_p2 = (!mul_ln1118_1032_fu_52635_p0.read().is_01() || !mul_ln1118_1032_fu_52635_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1032_fu_52635_p0.read()) * sc_bigint<5>(mul_ln1118_1032_fu_52635_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1033_fu_52667_p0() {
    mul_ln1118_1033_fu_52667_p0 =  (sc_lv<3>) (sext_ln1116_33_fu_22757_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1033_fu_52667_p1() {
    mul_ln1118_1033_fu_52667_p1 = tmp_1033_fu_52653_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1033_fu_52667_p2() {
    mul_ln1118_1033_fu_52667_p2 = (!mul_ln1118_1033_fu_52667_p0.read().is_01() || !mul_ln1118_1033_fu_52667_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1033_fu_52667_p0.read()) * sc_bigint<5>(mul_ln1118_1033_fu_52667_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1034_fu_91942_p0() {
    mul_ln1118_1034_fu_91942_p0 =  (sc_lv<3>) (sext_ln1116_34_reg_106007.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1034_fu_91942_p1() {
    mul_ln1118_1034_fu_91942_p1 = tmp_1034_reg_109766.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1034_fu_91942_p2() {
    mul_ln1118_1034_fu_91942_p2 = (!mul_ln1118_1034_fu_91942_p0.read().is_01() || !mul_ln1118_1034_fu_91942_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1034_fu_91942_p0.read()) * sc_bigint<5>(mul_ln1118_1034_fu_91942_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1035_fu_52709_p0() {
    mul_ln1118_1035_fu_52709_p0 =  (sc_lv<3>) (sext_ln1116_35_fu_22823_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1035_fu_52709_p1() {
    mul_ln1118_1035_fu_52709_p1 = tmp_1035_fu_52695_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1035_fu_52709_p2() {
    mul_ln1118_1035_fu_52709_p2 = (!mul_ln1118_1035_fu_52709_p0.read().is_01() || !mul_ln1118_1035_fu_52709_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1035_fu_52709_p0.read()) * sc_bigint<5>(mul_ln1118_1035_fu_52709_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1036_fu_52741_p0() {
    mul_ln1118_1036_fu_52741_p0 =  (sc_lv<3>) (sext_ln1116_36_fu_22867_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1036_fu_52741_p1() {
    mul_ln1118_1036_fu_52741_p1 = tmp_1036_fu_52727_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1036_fu_52741_p2() {
    mul_ln1118_1036_fu_52741_p2 = (!mul_ln1118_1036_fu_52741_p0.read().is_01() || !mul_ln1118_1036_fu_52741_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1036_fu_52741_p0.read()) * sc_bigint<5>(mul_ln1118_1036_fu_52741_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1037_fu_91962_p0() {
    mul_ln1118_1037_fu_91962_p0 =  (sc_lv<3>) (sext_ln1116_37_reg_106025.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1037_fu_91962_p1() {
    mul_ln1118_1037_fu_91962_p1 = tmp_1037_reg_109771.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1037_fu_91962_p2() {
    mul_ln1118_1037_fu_91962_p2 = (!mul_ln1118_1037_fu_91962_p0.read().is_01() || !mul_ln1118_1037_fu_91962_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1037_fu_91962_p0.read()) * sc_bigint<5>(mul_ln1118_1037_fu_91962_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1038_fu_52783_p0() {
    mul_ln1118_1038_fu_52783_p0 =  (sc_lv<3>) (sext_ln1116_38_fu_22933_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1038_fu_52783_p1() {
    mul_ln1118_1038_fu_52783_p1 = tmp_1038_fu_52769_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1038_fu_52783_p2() {
    mul_ln1118_1038_fu_52783_p2 = (!mul_ln1118_1038_fu_52783_p0.read().is_01() || !mul_ln1118_1038_fu_52783_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1038_fu_52783_p0.read()) * sc_bigint<5>(mul_ln1118_1038_fu_52783_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1039_fu_52815_p0() {
    mul_ln1118_1039_fu_52815_p0 =  (sc_lv<3>) (sext_ln1116_39_fu_22977_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1039_fu_52815_p1() {
    mul_ln1118_1039_fu_52815_p1 = tmp_1039_fu_52801_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1039_fu_52815_p2() {
    mul_ln1118_1039_fu_52815_p2 = (!mul_ln1118_1039_fu_52815_p0.read().is_01() || !mul_ln1118_1039_fu_52815_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1039_fu_52815_p0.read()) * sc_bigint<5>(mul_ln1118_1039_fu_52815_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_103_fu_25307_p0() {
    mul_ln1118_103_fu_25307_p0 =  (sc_lv<3>) (sext_ln1116_103_fu_25299_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_103_fu_25307_p1() {
    mul_ln1118_103_fu_25307_p1 = tmp_103_fu_25289_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_103_fu_25307_p2() {
    mul_ln1118_103_fu_25307_p2 = (!mul_ln1118_103_fu_25307_p0.read().is_01() || !mul_ln1118_103_fu_25307_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_103_fu_25307_p0.read()) * sc_bigint<5>(mul_ln1118_103_fu_25307_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1040_fu_91982_p0() {
    mul_ln1118_1040_fu_91982_p0 =  (sc_lv<3>) (sext_ln1116_40_fu_80193_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1040_fu_91982_p1() {
    mul_ln1118_1040_fu_91982_p1 = tmp_1040_reg_109776.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1040_fu_91982_p2() {
    mul_ln1118_1040_fu_91982_p2 = (!mul_ln1118_1040_fu_91982_p0.read().is_01() || !mul_ln1118_1040_fu_91982_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1040_fu_91982_p0.read()) * sc_bigint<5>(mul_ln1118_1040_fu_91982_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1041_fu_92003_p0() {
    mul_ln1118_1041_fu_92003_p0 =  (sc_lv<3>) (sext_ln1116_41_fu_80217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1041_fu_92003_p1() {
    mul_ln1118_1041_fu_92003_p1 = tmp_1041_reg_109781.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1041_fu_92003_p2() {
    mul_ln1118_1041_fu_92003_p2 = (!mul_ln1118_1041_fu_92003_p0.read().is_01() || !mul_ln1118_1041_fu_92003_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1041_fu_92003_p0.read()) * sc_bigint<5>(mul_ln1118_1041_fu_92003_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1042_fu_92024_p0() {
    mul_ln1118_1042_fu_92024_p0 =  (sc_lv<3>) (sext_ln1116_42_fu_80241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1042_fu_92024_p1() {
    mul_ln1118_1042_fu_92024_p1 = tmp_1042_reg_109786.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1042_fu_92024_p2() {
    mul_ln1118_1042_fu_92024_p2 = (!mul_ln1118_1042_fu_92024_p0.read().is_01() || !mul_ln1118_1042_fu_92024_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1042_fu_92024_p0.read()) * sc_bigint<5>(mul_ln1118_1042_fu_92024_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1043_fu_92045_p0() {
    mul_ln1118_1043_fu_92045_p0 =  (sc_lv<3>) (sext_ln1116_43_fu_80265_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1043_fu_92045_p1() {
    mul_ln1118_1043_fu_92045_p1 = tmp_1043_reg_109791.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1043_fu_92045_p2() {
    mul_ln1118_1043_fu_92045_p2 = (!mul_ln1118_1043_fu_92045_p0.read().is_01() || !mul_ln1118_1043_fu_92045_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1043_fu_92045_p0.read()) * sc_bigint<5>(mul_ln1118_1043_fu_92045_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1044_fu_92066_p0() {
    mul_ln1118_1044_fu_92066_p0 =  (sc_lv<3>) (sext_ln1116_44_fu_80289_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1044_fu_92066_p1() {
    mul_ln1118_1044_fu_92066_p1 = tmp_1044_reg_109796.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1044_fu_92066_p2() {
    mul_ln1118_1044_fu_92066_p2 = (!mul_ln1118_1044_fu_92066_p0.read().is_01() || !mul_ln1118_1044_fu_92066_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1044_fu_92066_p0.read()) * sc_bigint<5>(mul_ln1118_1044_fu_92066_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1045_fu_92087_p0() {
    mul_ln1118_1045_fu_92087_p0 =  (sc_lv<3>) (sext_ln1116_45_fu_80313_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1045_fu_92087_p1() {
    mul_ln1118_1045_fu_92087_p1 = tmp_1045_reg_109801.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1045_fu_92087_p2() {
    mul_ln1118_1045_fu_92087_p2 = (!mul_ln1118_1045_fu_92087_p0.read().is_01() || !mul_ln1118_1045_fu_92087_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1045_fu_92087_p0.read()) * sc_bigint<5>(mul_ln1118_1045_fu_92087_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1046_fu_92108_p0() {
    mul_ln1118_1046_fu_92108_p0 =  (sc_lv<3>) (sext_ln1116_46_reg_106103.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1046_fu_92108_p1() {
    mul_ln1118_1046_fu_92108_p1 = tmp_1046_reg_109806.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1046_fu_92108_p2() {
    mul_ln1118_1046_fu_92108_p2 = (!mul_ln1118_1046_fu_92108_p0.read().is_01() || !mul_ln1118_1046_fu_92108_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1046_fu_92108_p0.read()) * sc_bigint<5>(mul_ln1118_1046_fu_92108_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1047_fu_52917_p0() {
    mul_ln1118_1047_fu_52917_p0 =  (sc_lv<3>) (sext_ln1116_47_fu_23151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1047_fu_52917_p1() {
    mul_ln1118_1047_fu_52917_p1 = tmp_1047_fu_52903_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1047_fu_52917_p2() {
    mul_ln1118_1047_fu_52917_p2 = (!mul_ln1118_1047_fu_52917_p0.read().is_01() || !mul_ln1118_1047_fu_52917_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1047_fu_52917_p0.read()) * sc_bigint<5>(mul_ln1118_1047_fu_52917_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1048_fu_52949_p0() {
    mul_ln1118_1048_fu_52949_p0 =  (sc_lv<3>) (sext_ln1116_48_fu_23195_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1048_fu_52949_p1() {
    mul_ln1118_1048_fu_52949_p1 = tmp_1048_fu_52935_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1048_fu_52949_p2() {
    mul_ln1118_1048_fu_52949_p2 = (!mul_ln1118_1048_fu_52949_p0.read().is_01() || !mul_ln1118_1048_fu_52949_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1048_fu_52949_p0.read()) * sc_bigint<5>(mul_ln1118_1048_fu_52949_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1049_fu_92128_p0() {
    mul_ln1118_1049_fu_92128_p0 =  (sc_lv<3>) (sext_ln1116_49_reg_106121.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1049_fu_92128_p1() {
    mul_ln1118_1049_fu_92128_p1 = tmp_1049_reg_109811.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1049_fu_92128_p2() {
    mul_ln1118_1049_fu_92128_p2 = (!mul_ln1118_1049_fu_92128_p0.read().is_01() || !mul_ln1118_1049_fu_92128_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1049_fu_92128_p0.read()) * sc_bigint<5>(mul_ln1118_1049_fu_92128_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_104_fu_25351_p0() {
    mul_ln1118_104_fu_25351_p0 =  (sc_lv<3>) (sext_ln1116_104_fu_25343_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_104_fu_25351_p1() {
    mul_ln1118_104_fu_25351_p1 = tmp_104_fu_25333_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_104_fu_25351_p2() {
    mul_ln1118_104_fu_25351_p2 = (!mul_ln1118_104_fu_25351_p0.read().is_01() || !mul_ln1118_104_fu_25351_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_104_fu_25351_p0.read()) * sc_bigint<5>(mul_ln1118_104_fu_25351_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1050_fu_52991_p0() {
    mul_ln1118_1050_fu_52991_p0 =  (sc_lv<3>) (sext_ln1116_50_fu_23261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1050_fu_52991_p1() {
    mul_ln1118_1050_fu_52991_p1 = tmp_1050_fu_52977_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1050_fu_52991_p2() {
    mul_ln1118_1050_fu_52991_p2 = (!mul_ln1118_1050_fu_52991_p0.read().is_01() || !mul_ln1118_1050_fu_52991_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1050_fu_52991_p0.read()) * sc_bigint<5>(mul_ln1118_1050_fu_52991_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1051_fu_53023_p0() {
    mul_ln1118_1051_fu_53023_p0 =  (sc_lv<3>) (sext_ln1116_51_fu_23305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1051_fu_53023_p1() {
    mul_ln1118_1051_fu_53023_p1 = tmp_1051_fu_53009_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1051_fu_53023_p2() {
    mul_ln1118_1051_fu_53023_p2 = (!mul_ln1118_1051_fu_53023_p0.read().is_01() || !mul_ln1118_1051_fu_53023_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1051_fu_53023_p0.read()) * sc_bigint<5>(mul_ln1118_1051_fu_53023_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1052_fu_92148_p0() {
    mul_ln1118_1052_fu_92148_p0 =  (sc_lv<3>) (sext_ln1116_52_fu_80377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1052_fu_92148_p1() {
    mul_ln1118_1052_fu_92148_p1 = tmp_1052_reg_109816.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1052_fu_92148_p2() {
    mul_ln1118_1052_fu_92148_p2 = (!mul_ln1118_1052_fu_92148_p0.read().is_01() || !mul_ln1118_1052_fu_92148_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1052_fu_92148_p0.read()) * sc_bigint<5>(mul_ln1118_1052_fu_92148_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1053_fu_53065_p0() {
    mul_ln1118_1053_fu_53065_p0 =  (sc_lv<3>) (sext_ln1116_53_fu_23367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1053_fu_53065_p1() {
    mul_ln1118_1053_fu_53065_p1 = tmp_1053_fu_53051_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1053_fu_53065_p2() {
    mul_ln1118_1053_fu_53065_p2 = (!mul_ln1118_1053_fu_53065_p0.read().is_01() || !mul_ln1118_1053_fu_53065_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1053_fu_53065_p0.read()) * sc_bigint<5>(mul_ln1118_1053_fu_53065_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1054_fu_53097_p0() {
    mul_ln1118_1054_fu_53097_p0 =  (sc_lv<3>) (sext_ln1116_54_fu_23411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1054_fu_53097_p1() {
    mul_ln1118_1054_fu_53097_p1 = tmp_1054_fu_53083_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1054_fu_53097_p2() {
    mul_ln1118_1054_fu_53097_p2 = (!mul_ln1118_1054_fu_53097_p0.read().is_01() || !mul_ln1118_1054_fu_53097_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1054_fu_53097_p0.read()) * sc_bigint<5>(mul_ln1118_1054_fu_53097_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1055_fu_53129_p0() {
    mul_ln1118_1055_fu_53129_p0 =  (sc_lv<3>) (sext_ln1116_55_fu_23455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1055_fu_53129_p1() {
    mul_ln1118_1055_fu_53129_p1 = tmp_1055_fu_53115_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1055_fu_53129_p2() {
    mul_ln1118_1055_fu_53129_p2 = (!mul_ln1118_1055_fu_53129_p0.read().is_01() || !mul_ln1118_1055_fu_53129_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1055_fu_53129_p0.read()) * sc_bigint<5>(mul_ln1118_1055_fu_53129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1056_fu_53161_p0() {
    mul_ln1118_1056_fu_53161_p0 =  (sc_lv<3>) (sext_ln1116_56_fu_23499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1056_fu_53161_p1() {
    mul_ln1118_1056_fu_53161_p1 = tmp_1056_fu_53147_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1056_fu_53161_p2() {
    mul_ln1118_1056_fu_53161_p2 = (!mul_ln1118_1056_fu_53161_p0.read().is_01() || !mul_ln1118_1056_fu_53161_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1056_fu_53161_p0.read()) * sc_bigint<5>(mul_ln1118_1056_fu_53161_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1057_fu_53193_p0() {
    mul_ln1118_1057_fu_53193_p0 =  (sc_lv<3>) (sext_ln1116_57_fu_23543_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1057_fu_53193_p1() {
    mul_ln1118_1057_fu_53193_p1 = tmp_1057_fu_53179_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1057_fu_53193_p2() {
    mul_ln1118_1057_fu_53193_p2 = (!mul_ln1118_1057_fu_53193_p0.read().is_01() || !mul_ln1118_1057_fu_53193_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1057_fu_53193_p0.read()) * sc_bigint<5>(mul_ln1118_1057_fu_53193_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1058_fu_53225_p0() {
    mul_ln1118_1058_fu_53225_p0 =  (sc_lv<3>) (sext_ln1116_58_fu_23587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1058_fu_53225_p1() {
    mul_ln1118_1058_fu_53225_p1 = tmp_1058_fu_53211_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1058_fu_53225_p2() {
    mul_ln1118_1058_fu_53225_p2 = (!mul_ln1118_1058_fu_53225_p0.read().is_01() || !mul_ln1118_1058_fu_53225_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1058_fu_53225_p0.read()) * sc_bigint<5>(mul_ln1118_1058_fu_53225_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1059_fu_53257_p0() {
    mul_ln1118_1059_fu_53257_p0 =  (sc_lv<3>) (sext_ln1116_59_fu_23631_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1059_fu_53257_p1() {
    mul_ln1118_1059_fu_53257_p1 = tmp_1059_fu_53243_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1059_fu_53257_p2() {
    mul_ln1118_1059_fu_53257_p2 = (!mul_ln1118_1059_fu_53257_p0.read().is_01() || !mul_ln1118_1059_fu_53257_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1059_fu_53257_p0.read()) * sc_bigint<5>(mul_ln1118_1059_fu_53257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_105_fu_25395_p0() {
    mul_ln1118_105_fu_25395_p0 =  (sc_lv<3>) (sext_ln1116_105_fu_25387_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_105_fu_25395_p1() {
    mul_ln1118_105_fu_25395_p1 = tmp_105_fu_25377_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_105_fu_25395_p2() {
    mul_ln1118_105_fu_25395_p2 = (!mul_ln1118_105_fu_25395_p0.read().is_01() || !mul_ln1118_105_fu_25395_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_105_fu_25395_p0.read()) * sc_bigint<5>(mul_ln1118_105_fu_25395_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1060_fu_53277_p0() {
    mul_ln1118_1060_fu_53277_p0 =  (sc_lv<3>) (sext_ln1116_60_fu_23663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1060_fu_53277_p1() {
    mul_ln1118_1060_fu_53277_p1 = tmp_1060_fu_53263_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1060_fu_53277_p2() {
    mul_ln1118_1060_fu_53277_p2 = (!mul_ln1118_1060_fu_53277_p0.read().is_01() || !mul_ln1118_1060_fu_53277_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1060_fu_53277_p0.read()) * sc_bigint<5>(mul_ln1118_1060_fu_53277_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1061_fu_53309_p0() {
    mul_ln1118_1061_fu_53309_p0 =  (sc_lv<3>) (sext_ln1116_61_fu_23707_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1061_fu_53309_p1() {
    mul_ln1118_1061_fu_53309_p1 = tmp_1061_fu_53295_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1061_fu_53309_p2() {
    mul_ln1118_1061_fu_53309_p2 = (!mul_ln1118_1061_fu_53309_p0.read().is_01() || !mul_ln1118_1061_fu_53309_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1061_fu_53309_p0.read()) * sc_bigint<5>(mul_ln1118_1061_fu_53309_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1062_fu_53341_p0() {
    mul_ln1118_1062_fu_53341_p0 =  (sc_lv<3>) (sext_ln1116_62_fu_23751_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1062_fu_53341_p1() {
    mul_ln1118_1062_fu_53341_p1 = tmp_1062_fu_53327_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1062_fu_53341_p2() {
    mul_ln1118_1062_fu_53341_p2 = (!mul_ln1118_1062_fu_53341_p0.read().is_01() || !mul_ln1118_1062_fu_53341_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1062_fu_53341_p0.read()) * sc_bigint<5>(mul_ln1118_1062_fu_53341_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1063_fu_53361_p0() {
    mul_ln1118_1063_fu_53361_p0 =  (sc_lv<3>) (sext_ln1116_63_fu_23783_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1063_fu_53361_p1() {
    mul_ln1118_1063_fu_53361_p1 = tmp_1063_fu_53347_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1063_fu_53361_p2() {
    mul_ln1118_1063_fu_53361_p2 = (!mul_ln1118_1063_fu_53361_p0.read().is_01() || !mul_ln1118_1063_fu_53361_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1063_fu_53361_p0.read()) * sc_bigint<5>(mul_ln1118_1063_fu_53361_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1064_fu_53393_p0() {
    mul_ln1118_1064_fu_53393_p0 =  (sc_lv<3>) (sext_ln1116_64_fu_23827_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1064_fu_53393_p1() {
    mul_ln1118_1064_fu_53393_p1 = tmp_1064_fu_53379_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1064_fu_53393_p2() {
    mul_ln1118_1064_fu_53393_p2 = (!mul_ln1118_1064_fu_53393_p0.read().is_01() || !mul_ln1118_1064_fu_53393_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1064_fu_53393_p0.read()) * sc_bigint<5>(mul_ln1118_1064_fu_53393_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1065_fu_92191_p0() {
    mul_ln1118_1065_fu_92191_p0 =  (sc_lv<3>) (sext_ln1116_65_reg_106159.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1065_fu_92191_p1() {
    mul_ln1118_1065_fu_92191_p1 = tmp_1065_reg_109831.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1065_fu_92191_p2() {
    mul_ln1118_1065_fu_92191_p2 = (!mul_ln1118_1065_fu_92191_p0.read().is_01() || !mul_ln1118_1065_fu_92191_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1065_fu_92191_p0.read()) * sc_bigint<5>(mul_ln1118_1065_fu_92191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1066_fu_53435_p0() {
    mul_ln1118_1066_fu_53435_p0 =  (sc_lv<3>) (sext_ln1116_66_fu_23893_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1066_fu_53435_p1() {
    mul_ln1118_1066_fu_53435_p1 = tmp_1066_fu_53421_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1066_fu_53435_p2() {
    mul_ln1118_1066_fu_53435_p2 = (!mul_ln1118_1066_fu_53435_p0.read().is_01() || !mul_ln1118_1066_fu_53435_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1066_fu_53435_p0.read()) * sc_bigint<5>(mul_ln1118_1066_fu_53435_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1067_fu_53467_p0() {
    mul_ln1118_1067_fu_53467_p0 =  (sc_lv<3>) (sext_ln1116_67_fu_23937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1067_fu_53467_p1() {
    mul_ln1118_1067_fu_53467_p1 = tmp_1067_fu_53453_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1067_fu_53467_p2() {
    mul_ln1118_1067_fu_53467_p2 = (!mul_ln1118_1067_fu_53467_p0.read().is_01() || !mul_ln1118_1067_fu_53467_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1067_fu_53467_p0.read()) * sc_bigint<5>(mul_ln1118_1067_fu_53467_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1068_fu_92211_p0() {
    mul_ln1118_1068_fu_92211_p0 =  (sc_lv<3>) (sext_ln1116_68_reg_106177.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1068_fu_92211_p1() {
    mul_ln1118_1068_fu_92211_p1 = tmp_1068_reg_109836.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1068_fu_92211_p2() {
    mul_ln1118_1068_fu_92211_p2 = (!mul_ln1118_1068_fu_92211_p0.read().is_01() || !mul_ln1118_1068_fu_92211_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1068_fu_92211_p0.read()) * sc_bigint<5>(mul_ln1118_1068_fu_92211_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1069_fu_53509_p0() {
    mul_ln1118_1069_fu_53509_p0 =  (sc_lv<3>) (sext_ln1116_69_fu_24003_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1069_fu_53509_p1() {
    mul_ln1118_1069_fu_53509_p1 = tmp_1069_fu_53495_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1069_fu_53509_p2() {
    mul_ln1118_1069_fu_53509_p2 = (!mul_ln1118_1069_fu_53509_p0.read().is_01() || !mul_ln1118_1069_fu_53509_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1069_fu_53509_p0.read()) * sc_bigint<5>(mul_ln1118_1069_fu_53509_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_106_fu_25439_p0() {
    mul_ln1118_106_fu_25439_p0 =  (sc_lv<3>) (sext_ln1116_106_fu_25431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_106_fu_25439_p1() {
    mul_ln1118_106_fu_25439_p1 = tmp_106_fu_25421_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_106_fu_25439_p2() {
    mul_ln1118_106_fu_25439_p2 = (!mul_ln1118_106_fu_25439_p0.read().is_01() || !mul_ln1118_106_fu_25439_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_106_fu_25439_p0.read()) * sc_bigint<5>(mul_ln1118_106_fu_25439_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1070_fu_53541_p0() {
    mul_ln1118_1070_fu_53541_p0 =  (sc_lv<3>) (sext_ln1116_70_fu_24047_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1070_fu_53541_p1() {
    mul_ln1118_1070_fu_53541_p1 = tmp_1070_fu_53527_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1070_fu_53541_p2() {
    mul_ln1118_1070_fu_53541_p2 = (!mul_ln1118_1070_fu_53541_p0.read().is_01() || !mul_ln1118_1070_fu_53541_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1070_fu_53541_p0.read()) * sc_bigint<5>(mul_ln1118_1070_fu_53541_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1071_fu_92231_p0() {
    mul_ln1118_1071_fu_92231_p0 =  (sc_lv<3>) (sext_ln1116_71_reg_106195.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1071_fu_92231_p1() {
    mul_ln1118_1071_fu_92231_p1 = tmp_1071_reg_109841.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1071_fu_92231_p2() {
    mul_ln1118_1071_fu_92231_p2 = (!mul_ln1118_1071_fu_92231_p0.read().is_01() || !mul_ln1118_1071_fu_92231_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1071_fu_92231_p0.read()) * sc_bigint<5>(mul_ln1118_1071_fu_92231_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1072_fu_53583_p0() {
    mul_ln1118_1072_fu_53583_p0 =  (sc_lv<3>) (sext_ln1116_72_fu_24113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1072_fu_53583_p1() {
    mul_ln1118_1072_fu_53583_p1 = tmp_1072_fu_53569_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1072_fu_53583_p2() {
    mul_ln1118_1072_fu_53583_p2 = (!mul_ln1118_1072_fu_53583_p0.read().is_01() || !mul_ln1118_1072_fu_53583_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1072_fu_53583_p0.read()) * sc_bigint<5>(mul_ln1118_1072_fu_53583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1073_fu_53615_p0() {
    mul_ln1118_1073_fu_53615_p0 =  (sc_lv<3>) (sext_ln1116_73_fu_24157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1073_fu_53615_p1() {
    mul_ln1118_1073_fu_53615_p1 = tmp_1073_fu_53601_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1073_fu_53615_p2() {
    mul_ln1118_1073_fu_53615_p2 = (!mul_ln1118_1073_fu_53615_p0.read().is_01() || !mul_ln1118_1073_fu_53615_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1073_fu_53615_p0.read()) * sc_bigint<5>(mul_ln1118_1073_fu_53615_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1074_fu_92251_p0() {
    mul_ln1118_1074_fu_92251_p0 =  (sc_lv<3>) (sext_ln1116_74_reg_106213.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1074_fu_92251_p1() {
    mul_ln1118_1074_fu_92251_p1 = tmp_1074_reg_109846.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1074_fu_92251_p2() {
    mul_ln1118_1074_fu_92251_p2 = (!mul_ln1118_1074_fu_92251_p0.read().is_01() || !mul_ln1118_1074_fu_92251_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1074_fu_92251_p0.read()) * sc_bigint<5>(mul_ln1118_1074_fu_92251_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1075_fu_53657_p0() {
    mul_ln1118_1075_fu_53657_p0 =  (sc_lv<3>) (sext_ln1116_75_fu_24223_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1075_fu_53657_p1() {
    mul_ln1118_1075_fu_53657_p1 = tmp_1075_fu_53643_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1075_fu_53657_p2() {
    mul_ln1118_1075_fu_53657_p2 = (!mul_ln1118_1075_fu_53657_p0.read().is_01() || !mul_ln1118_1075_fu_53657_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1075_fu_53657_p0.read()) * sc_bigint<5>(mul_ln1118_1075_fu_53657_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1076_fu_53689_p0() {
    mul_ln1118_1076_fu_53689_p0 =  (sc_lv<3>) (sext_ln1116_76_fu_24267_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1076_fu_53689_p1() {
    mul_ln1118_1076_fu_53689_p1 = tmp_1076_fu_53675_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1076_fu_53689_p2() {
    mul_ln1118_1076_fu_53689_p2 = (!mul_ln1118_1076_fu_53689_p0.read().is_01() || !mul_ln1118_1076_fu_53689_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1076_fu_53689_p0.read()) * sc_bigint<5>(mul_ln1118_1076_fu_53689_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1077_fu_92271_p0() {
    mul_ln1118_1077_fu_92271_p0 =  (sc_lv<3>) (sext_ln1116_77_reg_106231.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1077_fu_92271_p1() {
    mul_ln1118_1077_fu_92271_p1 = tmp_1077_reg_109851.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1077_fu_92271_p2() {
    mul_ln1118_1077_fu_92271_p2 = (!mul_ln1118_1077_fu_92271_p0.read().is_01() || !mul_ln1118_1077_fu_92271_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1077_fu_92271_p0.read()) * sc_bigint<5>(mul_ln1118_1077_fu_92271_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1078_fu_53731_p0() {
    mul_ln1118_1078_fu_53731_p0 =  (sc_lv<3>) (sext_ln1116_78_fu_24333_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1078_fu_53731_p1() {
    mul_ln1118_1078_fu_53731_p1 = tmp_1078_fu_53717_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1078_fu_53731_p2() {
    mul_ln1118_1078_fu_53731_p2 = (!mul_ln1118_1078_fu_53731_p0.read().is_01() || !mul_ln1118_1078_fu_53731_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1078_fu_53731_p0.read()) * sc_bigint<5>(mul_ln1118_1078_fu_53731_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1079_fu_53763_p0() {
    mul_ln1118_1079_fu_53763_p0 =  (sc_lv<3>) (sext_ln1116_79_fu_24377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1079_fu_53763_p1() {
    mul_ln1118_1079_fu_53763_p1 = tmp_1079_fu_53749_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1079_fu_53763_p2() {
    mul_ln1118_1079_fu_53763_p2 = (!mul_ln1118_1079_fu_53763_p0.read().is_01() || !mul_ln1118_1079_fu_53763_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1079_fu_53763_p0.read()) * sc_bigint<5>(mul_ln1118_1079_fu_53763_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_107_fu_25483_p0() {
    mul_ln1118_107_fu_25483_p0 =  (sc_lv<3>) (sext_ln1116_107_fu_25475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_107_fu_25483_p1() {
    mul_ln1118_107_fu_25483_p1 = tmp_107_fu_25465_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_107_fu_25483_p2() {
    mul_ln1118_107_fu_25483_p2 = (!mul_ln1118_107_fu_25483_p0.read().is_01() || !mul_ln1118_107_fu_25483_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_107_fu_25483_p0.read()) * sc_bigint<5>(mul_ln1118_107_fu_25483_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1080_fu_53795_p0() {
    mul_ln1118_1080_fu_53795_p0 =  (sc_lv<3>) (sext_ln1116_80_fu_24421_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1080_fu_53795_p1() {
    mul_ln1118_1080_fu_53795_p1 = tmp_1080_fu_53781_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1080_fu_53795_p2() {
    mul_ln1118_1080_fu_53795_p2 = (!mul_ln1118_1080_fu_53795_p0.read().is_01() || !mul_ln1118_1080_fu_53795_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1080_fu_53795_p0.read()) * sc_bigint<5>(mul_ln1118_1080_fu_53795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1081_fu_53827_p0() {
    mul_ln1118_1081_fu_53827_p0 =  (sc_lv<3>) (sext_ln1116_81_fu_24465_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1081_fu_53827_p1() {
    mul_ln1118_1081_fu_53827_p1 = tmp_1081_fu_53813_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1081_fu_53827_p2() {
    mul_ln1118_1081_fu_53827_p2 = (!mul_ln1118_1081_fu_53827_p0.read().is_01() || !mul_ln1118_1081_fu_53827_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1081_fu_53827_p0.read()) * sc_bigint<5>(mul_ln1118_1081_fu_53827_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1082_fu_53859_p0() {
    mul_ln1118_1082_fu_53859_p0 =  (sc_lv<3>) (sext_ln1116_82_fu_24509_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1082_fu_53859_p1() {
    mul_ln1118_1082_fu_53859_p1 = tmp_1082_fu_53845_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1082_fu_53859_p2() {
    mul_ln1118_1082_fu_53859_p2 = (!mul_ln1118_1082_fu_53859_p0.read().is_01() || !mul_ln1118_1082_fu_53859_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1082_fu_53859_p0.read()) * sc_bigint<5>(mul_ln1118_1082_fu_53859_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1083_fu_53891_p0() {
    mul_ln1118_1083_fu_53891_p0 =  (sc_lv<3>) (sext_ln1116_83_fu_24553_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1083_fu_53891_p1() {
    mul_ln1118_1083_fu_53891_p1 = tmp_1083_fu_53877_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1083_fu_53891_p2() {
    mul_ln1118_1083_fu_53891_p2 = (!mul_ln1118_1083_fu_53891_p0.read().is_01() || !mul_ln1118_1083_fu_53891_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1083_fu_53891_p0.read()) * sc_bigint<5>(mul_ln1118_1083_fu_53891_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1084_fu_53923_p0() {
    mul_ln1118_1084_fu_53923_p0 =  (sc_lv<3>) (sext_ln1116_84_fu_24597_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1084_fu_53923_p1() {
    mul_ln1118_1084_fu_53923_p1 = tmp_1084_fu_53909_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1084_fu_53923_p2() {
    mul_ln1118_1084_fu_53923_p2 = (!mul_ln1118_1084_fu_53923_p0.read().is_01() || !mul_ln1118_1084_fu_53923_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1084_fu_53923_p0.read()) * sc_bigint<5>(mul_ln1118_1084_fu_53923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1085_fu_53943_p0() {
    mul_ln1118_1085_fu_53943_p0 =  (sc_lv<3>) (sext_ln1116_85_fu_24629_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1085_fu_53943_p1() {
    mul_ln1118_1085_fu_53943_p1 = tmp_1085_fu_53929_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1085_fu_53943_p2() {
    mul_ln1118_1085_fu_53943_p2 = (!mul_ln1118_1085_fu_53943_p0.read().is_01() || !mul_ln1118_1085_fu_53943_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1085_fu_53943_p0.read()) * sc_bigint<5>(mul_ln1118_1085_fu_53943_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1086_fu_53975_p0() {
    mul_ln1118_1086_fu_53975_p0 =  (sc_lv<3>) (sext_ln1116_86_fu_24673_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1086_fu_53975_p1() {
    mul_ln1118_1086_fu_53975_p1 = tmp_1086_fu_53961_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1086_fu_53975_p2() {
    mul_ln1118_1086_fu_53975_p2 = (!mul_ln1118_1086_fu_53975_p0.read().is_01() || !mul_ln1118_1086_fu_53975_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1086_fu_53975_p0.read()) * sc_bigint<5>(mul_ln1118_1086_fu_53975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1087_fu_54007_p0() {
    mul_ln1118_1087_fu_54007_p0 =  (sc_lv<3>) (sext_ln1116_87_fu_24717_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1087_fu_54007_p1() {
    mul_ln1118_1087_fu_54007_p1 = tmp_1087_fu_53993_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1087_fu_54007_p2() {
    mul_ln1118_1087_fu_54007_p2 = (!mul_ln1118_1087_fu_54007_p0.read().is_01() || !mul_ln1118_1087_fu_54007_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1087_fu_54007_p0.read()) * sc_bigint<5>(mul_ln1118_1087_fu_54007_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1088_fu_54027_p0() {
    mul_ln1118_1088_fu_54027_p0 =  (sc_lv<3>) (sext_ln1116_88_fu_24749_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1088_fu_54027_p1() {
    mul_ln1118_1088_fu_54027_p1 = tmp_1088_fu_54013_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1088_fu_54027_p2() {
    mul_ln1118_1088_fu_54027_p2 = (!mul_ln1118_1088_fu_54027_p0.read().is_01() || !mul_ln1118_1088_fu_54027_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1088_fu_54027_p0.read()) * sc_bigint<5>(mul_ln1118_1088_fu_54027_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1089_fu_54059_p0() {
    mul_ln1118_1089_fu_54059_p0 =  (sc_lv<3>) (sext_ln1116_89_fu_24793_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1089_fu_54059_p1() {
    mul_ln1118_1089_fu_54059_p1 = tmp_1089_fu_54045_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1089_fu_54059_p2() {
    mul_ln1118_1089_fu_54059_p2 = (!mul_ln1118_1089_fu_54059_p0.read().is_01() || !mul_ln1118_1089_fu_54059_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1089_fu_54059_p0.read()) * sc_bigint<5>(mul_ln1118_1089_fu_54059_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_108_fu_25527_p0() {
    mul_ln1118_108_fu_25527_p0 =  (sc_lv<3>) (sext_ln1116_108_fu_25519_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_108_fu_25527_p1() {
    mul_ln1118_108_fu_25527_p1 = tmp_108_fu_25509_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_108_fu_25527_p2() {
    mul_ln1118_108_fu_25527_p2 = (!mul_ln1118_108_fu_25527_p0.read().is_01() || !mul_ln1118_108_fu_25527_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_108_fu_25527_p0.read()) * sc_bigint<5>(mul_ln1118_108_fu_25527_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1090_fu_92313_p0() {
    mul_ln1118_1090_fu_92313_p0 =  (sc_lv<3>) (sext_ln1116_90_reg_106259.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1090_fu_92313_p1() {
    mul_ln1118_1090_fu_92313_p1 = tmp_1090_reg_109866.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1090_fu_92313_p2() {
    mul_ln1118_1090_fu_92313_p2 = (!mul_ln1118_1090_fu_92313_p0.read().is_01() || !mul_ln1118_1090_fu_92313_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1090_fu_92313_p0.read()) * sc_bigint<5>(mul_ln1118_1090_fu_92313_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1091_fu_54101_p0() {
    mul_ln1118_1091_fu_54101_p0 =  (sc_lv<3>) (sext_ln1116_91_fu_24859_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1091_fu_54101_p1() {
    mul_ln1118_1091_fu_54101_p1 = tmp_1091_fu_54087_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1091_fu_54101_p2() {
    mul_ln1118_1091_fu_54101_p2 = (!mul_ln1118_1091_fu_54101_p0.read().is_01() || !mul_ln1118_1091_fu_54101_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1091_fu_54101_p0.read()) * sc_bigint<5>(mul_ln1118_1091_fu_54101_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1092_fu_54133_p0() {
    mul_ln1118_1092_fu_54133_p0 =  (sc_lv<3>) (sext_ln1116_92_fu_24903_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1092_fu_54133_p1() {
    mul_ln1118_1092_fu_54133_p1 = tmp_1092_fu_54119_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1092_fu_54133_p2() {
    mul_ln1118_1092_fu_54133_p2 = (!mul_ln1118_1092_fu_54133_p0.read().is_01() || !mul_ln1118_1092_fu_54133_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1092_fu_54133_p0.read()) * sc_bigint<5>(mul_ln1118_1092_fu_54133_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1093_fu_92333_p0() {
    mul_ln1118_1093_fu_92333_p0 =  (sc_lv<3>) (sext_ln1116_93_reg_106277.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1093_fu_92333_p1() {
    mul_ln1118_1093_fu_92333_p1 = tmp_1093_reg_109871.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1093_fu_92333_p2() {
    mul_ln1118_1093_fu_92333_p2 = (!mul_ln1118_1093_fu_92333_p0.read().is_01() || !mul_ln1118_1093_fu_92333_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1093_fu_92333_p0.read()) * sc_bigint<5>(mul_ln1118_1093_fu_92333_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1094_fu_54175_p0() {
    mul_ln1118_1094_fu_54175_p0 =  (sc_lv<3>) (sext_ln1116_94_fu_24969_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1094_fu_54175_p1() {
    mul_ln1118_1094_fu_54175_p1 = tmp_1094_fu_54161_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1094_fu_54175_p2() {
    mul_ln1118_1094_fu_54175_p2 = (!mul_ln1118_1094_fu_54175_p0.read().is_01() || !mul_ln1118_1094_fu_54175_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1094_fu_54175_p0.read()) * sc_bigint<5>(mul_ln1118_1094_fu_54175_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1095_fu_54207_p0() {
    mul_ln1118_1095_fu_54207_p0 =  (sc_lv<3>) (sext_ln1116_95_fu_25013_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1095_fu_54207_p1() {
    mul_ln1118_1095_fu_54207_p1 = tmp_1095_fu_54193_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1095_fu_54207_p2() {
    mul_ln1118_1095_fu_54207_p2 = (!mul_ln1118_1095_fu_54207_p0.read().is_01() || !mul_ln1118_1095_fu_54207_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1095_fu_54207_p0.read()) * sc_bigint<5>(mul_ln1118_1095_fu_54207_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1096_fu_92353_p0() {
    mul_ln1118_1096_fu_92353_p0 =  (sc_lv<3>) (sext_ln1116_96_reg_106295.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1096_fu_92353_p1() {
    mul_ln1118_1096_fu_92353_p1 = tmp_1096_reg_109876.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1096_fu_92353_p2() {
    mul_ln1118_1096_fu_92353_p2 = (!mul_ln1118_1096_fu_92353_p0.read().is_01() || !mul_ln1118_1096_fu_92353_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1096_fu_92353_p0.read()) * sc_bigint<5>(mul_ln1118_1096_fu_92353_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1097_fu_54249_p0() {
    mul_ln1118_1097_fu_54249_p0 =  (sc_lv<3>) (sext_ln1116_97_fu_25079_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1097_fu_54249_p1() {
    mul_ln1118_1097_fu_54249_p1 = tmp_1097_fu_54235_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1097_fu_54249_p2() {
    mul_ln1118_1097_fu_54249_p2 = (!mul_ln1118_1097_fu_54249_p0.read().is_01() || !mul_ln1118_1097_fu_54249_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1097_fu_54249_p0.read()) * sc_bigint<5>(mul_ln1118_1097_fu_54249_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1098_fu_54281_p0() {
    mul_ln1118_1098_fu_54281_p0 =  (sc_lv<3>) (sext_ln1116_98_fu_25123_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1098_fu_54281_p1() {
    mul_ln1118_1098_fu_54281_p1 = tmp_1098_fu_54267_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1098_fu_54281_p2() {
    mul_ln1118_1098_fu_54281_p2 = (!mul_ln1118_1098_fu_54281_p0.read().is_01() || !mul_ln1118_1098_fu_54281_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1098_fu_54281_p0.read()) * sc_bigint<5>(mul_ln1118_1098_fu_54281_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1099_fu_92373_p0() {
    mul_ln1118_1099_fu_92373_p0 =  (sc_lv<3>) (sext_ln1116_99_reg_106313.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1099_fu_92373_p1() {
    mul_ln1118_1099_fu_92373_p1 = tmp_1099_reg_109881.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1099_fu_92373_p2() {
    mul_ln1118_1099_fu_92373_p2 = (!mul_ln1118_1099_fu_92373_p0.read().is_01() || !mul_ln1118_1099_fu_92373_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1099_fu_92373_p0.read()) * sc_bigint<5>(mul_ln1118_1099_fu_92373_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_109_fu_25571_p0() {
    mul_ln1118_109_fu_25571_p0 =  (sc_lv<3>) (sext_ln1116_109_fu_25563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_109_fu_25571_p1() {
    mul_ln1118_109_fu_25571_p1 = tmp_109_fu_25553_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_109_fu_25571_p2() {
    mul_ln1118_109_fu_25571_p2 = (!mul_ln1118_109_fu_25571_p0.read().is_01() || !mul_ln1118_109_fu_25571_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_109_fu_25571_p0.read()) * sc_bigint<5>(mul_ln1118_109_fu_25571_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_10_fu_21895_p0() {
    mul_ln1118_10_fu_21895_p0 =  (sc_lv<3>) (sext_ln1116_10_fu_21887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_10_fu_21895_p1() {
    mul_ln1118_10_fu_21895_p1 = tmp_11_fu_21877_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_10_fu_21895_p2() {
    mul_ln1118_10_fu_21895_p2 = (!mul_ln1118_10_fu_21895_p0.read().is_01() || !mul_ln1118_10_fu_21895_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_10_fu_21895_p0.read()) * sc_bigint<5>(mul_ln1118_10_fu_21895_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1100_fu_54323_p0() {
    mul_ln1118_1100_fu_54323_p0 =  (sc_lv<3>) (sext_ln1116_100_fu_25189_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1100_fu_54323_p1() {
    mul_ln1118_1100_fu_54323_p1 = tmp_1100_fu_54309_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1100_fu_54323_p2() {
    mul_ln1118_1100_fu_54323_p2 = (!mul_ln1118_1100_fu_54323_p0.read().is_01() || !mul_ln1118_1100_fu_54323_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1100_fu_54323_p0.read()) * sc_bigint<5>(mul_ln1118_1100_fu_54323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1101_fu_54355_p0() {
    mul_ln1118_1101_fu_54355_p0 =  (sc_lv<3>) (sext_ln1116_101_fu_25233_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1101_fu_54355_p1() {
    mul_ln1118_1101_fu_54355_p1 = tmp_1101_fu_54341_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1101_fu_54355_p2() {
    mul_ln1118_1101_fu_54355_p2 = (!mul_ln1118_1101_fu_54355_p0.read().is_01() || !mul_ln1118_1101_fu_54355_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1101_fu_54355_p0.read()) * sc_bigint<5>(mul_ln1118_1101_fu_54355_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1102_fu_92393_p0() {
    mul_ln1118_1102_fu_92393_p0 =  (sc_lv<3>) (sext_ln1116_102_reg_106331.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1102_fu_92393_p1() {
    mul_ln1118_1102_fu_92393_p1 = tmp_1102_reg_109886.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1102_fu_92393_p2() {
    mul_ln1118_1102_fu_92393_p2 = (!mul_ln1118_1102_fu_92393_p0.read().is_01() || !mul_ln1118_1102_fu_92393_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1102_fu_92393_p0.read()) * sc_bigint<5>(mul_ln1118_1102_fu_92393_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1103_fu_54397_p0() {
    mul_ln1118_1103_fu_54397_p0 =  (sc_lv<3>) (sext_ln1116_103_fu_25299_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1103_fu_54397_p1() {
    mul_ln1118_1103_fu_54397_p1 = tmp_1103_fu_54383_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1103_fu_54397_p2() {
    mul_ln1118_1103_fu_54397_p2 = (!mul_ln1118_1103_fu_54397_p0.read().is_01() || !mul_ln1118_1103_fu_54397_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1103_fu_54397_p0.read()) * sc_bigint<5>(mul_ln1118_1103_fu_54397_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1104_fu_54429_p0() {
    mul_ln1118_1104_fu_54429_p0 =  (sc_lv<3>) (sext_ln1116_104_fu_25343_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1104_fu_54429_p1() {
    mul_ln1118_1104_fu_54429_p1 = tmp_1104_fu_54415_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1104_fu_54429_p2() {
    mul_ln1118_1104_fu_54429_p2 = (!mul_ln1118_1104_fu_54429_p0.read().is_01() || !mul_ln1118_1104_fu_54429_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1104_fu_54429_p0.read()) * sc_bigint<5>(mul_ln1118_1104_fu_54429_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1105_fu_54461_p0() {
    mul_ln1118_1105_fu_54461_p0 =  (sc_lv<3>) (sext_ln1116_105_fu_25387_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1105_fu_54461_p1() {
    mul_ln1118_1105_fu_54461_p1 = tmp_1105_fu_54447_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1105_fu_54461_p2() {
    mul_ln1118_1105_fu_54461_p2 = (!mul_ln1118_1105_fu_54461_p0.read().is_01() || !mul_ln1118_1105_fu_54461_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1105_fu_54461_p0.read()) * sc_bigint<5>(mul_ln1118_1105_fu_54461_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1106_fu_54493_p0() {
    mul_ln1118_1106_fu_54493_p0 =  (sc_lv<3>) (sext_ln1116_106_fu_25431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1106_fu_54493_p1() {
    mul_ln1118_1106_fu_54493_p1 = tmp_1106_fu_54479_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1106_fu_54493_p2() {
    mul_ln1118_1106_fu_54493_p2 = (!mul_ln1118_1106_fu_54493_p0.read().is_01() || !mul_ln1118_1106_fu_54493_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1106_fu_54493_p0.read()) * sc_bigint<5>(mul_ln1118_1106_fu_54493_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1107_fu_54525_p0() {
    mul_ln1118_1107_fu_54525_p0 =  (sc_lv<3>) (sext_ln1116_107_fu_25475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1107_fu_54525_p1() {
    mul_ln1118_1107_fu_54525_p1 = tmp_1107_fu_54511_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1107_fu_54525_p2() {
    mul_ln1118_1107_fu_54525_p2 = (!mul_ln1118_1107_fu_54525_p0.read().is_01() || !mul_ln1118_1107_fu_54525_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1107_fu_54525_p0.read()) * sc_bigint<5>(mul_ln1118_1107_fu_54525_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1108_fu_54557_p0() {
    mul_ln1118_1108_fu_54557_p0 =  (sc_lv<3>) (sext_ln1116_108_fu_25519_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1108_fu_54557_p1() {
    mul_ln1118_1108_fu_54557_p1 = tmp_1108_fu_54543_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1108_fu_54557_p2() {
    mul_ln1118_1108_fu_54557_p2 = (!mul_ln1118_1108_fu_54557_p0.read().is_01() || !mul_ln1118_1108_fu_54557_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1108_fu_54557_p0.read()) * sc_bigint<5>(mul_ln1118_1108_fu_54557_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1109_fu_54589_p0() {
    mul_ln1118_1109_fu_54589_p0 =  (sc_lv<3>) (sext_ln1116_109_fu_25563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1109_fu_54589_p1() {
    mul_ln1118_1109_fu_54589_p1 = tmp_1109_fu_54575_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1109_fu_54589_p2() {
    mul_ln1118_1109_fu_54589_p2 = (!mul_ln1118_1109_fu_54589_p0.read().is_01() || !mul_ln1118_1109_fu_54589_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1109_fu_54589_p0.read()) * sc_bigint<5>(mul_ln1118_1109_fu_54589_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_110_fu_25603_p0() {
    mul_ln1118_110_fu_25603_p0 =  (sc_lv<3>) (sext_ln1116_110_fu_25595_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_110_fu_25603_p1() {
    mul_ln1118_110_fu_25603_p1 = tmp_110_fu_25585_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_110_fu_25603_p2() {
    mul_ln1118_110_fu_25603_p2 = (!mul_ln1118_110_fu_25603_p0.read().is_01() || !mul_ln1118_110_fu_25603_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_110_fu_25603_p0.read()) * sc_bigint<5>(mul_ln1118_110_fu_25603_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1110_fu_54609_p0() {
    mul_ln1118_1110_fu_54609_p0 =  (sc_lv<3>) (sext_ln1116_110_fu_25595_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1110_fu_54609_p1() {
    mul_ln1118_1110_fu_54609_p1 = tmp_1110_fu_54595_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1110_fu_54609_p2() {
    mul_ln1118_1110_fu_54609_p2 = (!mul_ln1118_1110_fu_54609_p0.read().is_01() || !mul_ln1118_1110_fu_54609_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1110_fu_54609_p0.read()) * sc_bigint<5>(mul_ln1118_1110_fu_54609_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1111_fu_54641_p0() {
    mul_ln1118_1111_fu_54641_p0 =  (sc_lv<3>) (sext_ln1116_111_fu_25639_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1111_fu_54641_p1() {
    mul_ln1118_1111_fu_54641_p1 = tmp_1111_fu_54627_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1111_fu_54641_p2() {
    mul_ln1118_1111_fu_54641_p2 = (!mul_ln1118_1111_fu_54641_p0.read().is_01() || !mul_ln1118_1111_fu_54641_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1111_fu_54641_p0.read()) * sc_bigint<5>(mul_ln1118_1111_fu_54641_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1112_fu_54673_p0() {
    mul_ln1118_1112_fu_54673_p0 =  (sc_lv<3>) (sext_ln1116_112_fu_25683_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1112_fu_54673_p1() {
    mul_ln1118_1112_fu_54673_p1 = tmp_1112_fu_54659_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1112_fu_54673_p2() {
    mul_ln1118_1112_fu_54673_p2 = (!mul_ln1118_1112_fu_54673_p0.read().is_01() || !mul_ln1118_1112_fu_54673_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1112_fu_54673_p0.read()) * sc_bigint<5>(mul_ln1118_1112_fu_54673_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1113_fu_54693_p0() {
    mul_ln1118_1113_fu_54693_p0 =  (sc_lv<3>) (sext_ln1116_113_fu_25715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1113_fu_54693_p1() {
    mul_ln1118_1113_fu_54693_p1 = tmp_1113_fu_54679_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1113_fu_54693_p2() {
    mul_ln1118_1113_fu_54693_p2 = (!mul_ln1118_1113_fu_54693_p0.read().is_01() || !mul_ln1118_1113_fu_54693_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1113_fu_54693_p0.read()) * sc_bigint<5>(mul_ln1118_1113_fu_54693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1114_fu_54725_p0() {
    mul_ln1118_1114_fu_54725_p0 =  (sc_lv<3>) (sext_ln1116_114_fu_25759_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1114_fu_54725_p1() {
    mul_ln1118_1114_fu_54725_p1 = tmp_1114_fu_54711_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1114_fu_54725_p2() {
    mul_ln1118_1114_fu_54725_p2 = (!mul_ln1118_1114_fu_54725_p0.read().is_01() || !mul_ln1118_1114_fu_54725_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1114_fu_54725_p0.read()) * sc_bigint<5>(mul_ln1118_1114_fu_54725_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1115_fu_92435_p0() {
    mul_ln1118_1115_fu_92435_p0 =  (sc_lv<3>) (sext_ln1116_115_reg_106359.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1115_fu_92435_p1() {
    mul_ln1118_1115_fu_92435_p1 = tmp_1115_reg_109901.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1115_fu_92435_p2() {
    mul_ln1118_1115_fu_92435_p2 = (!mul_ln1118_1115_fu_92435_p0.read().is_01() || !mul_ln1118_1115_fu_92435_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1115_fu_92435_p0.read()) * sc_bigint<5>(mul_ln1118_1115_fu_92435_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1116_fu_54767_p0() {
    mul_ln1118_1116_fu_54767_p0 =  (sc_lv<3>) (sext_ln1116_116_fu_25825_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1116_fu_54767_p1() {
    mul_ln1118_1116_fu_54767_p1 = tmp_1116_fu_54753_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1116_fu_54767_p2() {
    mul_ln1118_1116_fu_54767_p2 = (!mul_ln1118_1116_fu_54767_p0.read().is_01() || !mul_ln1118_1116_fu_54767_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1116_fu_54767_p0.read()) * sc_bigint<5>(mul_ln1118_1116_fu_54767_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1117_fu_54799_p0() {
    mul_ln1118_1117_fu_54799_p0 =  (sc_lv<3>) (sext_ln1116_117_fu_25869_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1117_fu_54799_p1() {
    mul_ln1118_1117_fu_54799_p1 = tmp_1117_fu_54785_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1117_fu_54799_p2() {
    mul_ln1118_1117_fu_54799_p2 = (!mul_ln1118_1117_fu_54799_p0.read().is_01() || !mul_ln1118_1117_fu_54799_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1117_fu_54799_p0.read()) * sc_bigint<5>(mul_ln1118_1117_fu_54799_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1118_fu_92455_p0() {
    mul_ln1118_1118_fu_92455_p0 =  (sc_lv<3>) (sext_ln1116_118_reg_106377.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1118_fu_92455_p1() {
    mul_ln1118_1118_fu_92455_p1 = tmp_1118_reg_109906.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1118_fu_92455_p2() {
    mul_ln1118_1118_fu_92455_p2 = (!mul_ln1118_1118_fu_92455_p0.read().is_01() || !mul_ln1118_1118_fu_92455_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1118_fu_92455_p0.read()) * sc_bigint<5>(mul_ln1118_1118_fu_92455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1119_fu_54841_p0() {
    mul_ln1118_1119_fu_54841_p0 =  (sc_lv<3>) (sext_ln1116_119_fu_25935_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1119_fu_54841_p1() {
    mul_ln1118_1119_fu_54841_p1 = tmp_1119_fu_54827_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1119_fu_54841_p2() {
    mul_ln1118_1119_fu_54841_p2 = (!mul_ln1118_1119_fu_54841_p0.read().is_01() || !mul_ln1118_1119_fu_54841_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1119_fu_54841_p0.read()) * sc_bigint<5>(mul_ln1118_1119_fu_54841_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_111_fu_25647_p0() {
    mul_ln1118_111_fu_25647_p0 =  (sc_lv<3>) (sext_ln1116_111_fu_25639_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_111_fu_25647_p1() {
    mul_ln1118_111_fu_25647_p1 = tmp_111_fu_25629_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_111_fu_25647_p2() {
    mul_ln1118_111_fu_25647_p2 = (!mul_ln1118_111_fu_25647_p0.read().is_01() || !mul_ln1118_111_fu_25647_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_111_fu_25647_p0.read()) * sc_bigint<5>(mul_ln1118_111_fu_25647_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1120_fu_54873_p0() {
    mul_ln1118_1120_fu_54873_p0 =  (sc_lv<3>) (sext_ln1116_120_fu_25979_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1120_fu_54873_p1() {
    mul_ln1118_1120_fu_54873_p1 = tmp_1120_fu_54859_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1120_fu_54873_p2() {
    mul_ln1118_1120_fu_54873_p2 = (!mul_ln1118_1120_fu_54873_p0.read().is_01() || !mul_ln1118_1120_fu_54873_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1120_fu_54873_p0.read()) * sc_bigint<5>(mul_ln1118_1120_fu_54873_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1121_fu_92475_p0() {
    mul_ln1118_1121_fu_92475_p0 =  (sc_lv<3>) (sext_ln1116_121_reg_106395.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1121_fu_92475_p1() {
    mul_ln1118_1121_fu_92475_p1 = tmp_1121_reg_109911.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1121_fu_92475_p2() {
    mul_ln1118_1121_fu_92475_p2 = (!mul_ln1118_1121_fu_92475_p0.read().is_01() || !mul_ln1118_1121_fu_92475_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1121_fu_92475_p0.read()) * sc_bigint<5>(mul_ln1118_1121_fu_92475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1122_fu_54915_p0() {
    mul_ln1118_1122_fu_54915_p0 =  (sc_lv<3>) (sext_ln1116_122_fu_26045_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1122_fu_54915_p1() {
    mul_ln1118_1122_fu_54915_p1 = tmp_1122_fu_54901_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1122_fu_54915_p2() {
    mul_ln1118_1122_fu_54915_p2 = (!mul_ln1118_1122_fu_54915_p0.read().is_01() || !mul_ln1118_1122_fu_54915_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1122_fu_54915_p0.read()) * sc_bigint<5>(mul_ln1118_1122_fu_54915_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1123_fu_54947_p0() {
    mul_ln1118_1123_fu_54947_p0 =  (sc_lv<3>) (sext_ln1116_123_fu_26089_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1123_fu_54947_p1() {
    mul_ln1118_1123_fu_54947_p1 = tmp_1123_fu_54933_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1123_fu_54947_p2() {
    mul_ln1118_1123_fu_54947_p2 = (!mul_ln1118_1123_fu_54947_p0.read().is_01() || !mul_ln1118_1123_fu_54947_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1123_fu_54947_p0.read()) * sc_bigint<5>(mul_ln1118_1123_fu_54947_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1124_fu_92495_p0() {
    mul_ln1118_1124_fu_92495_p0 =  (sc_lv<3>) (sext_ln1116_124_reg_106413.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1124_fu_92495_p1() {
    mul_ln1118_1124_fu_92495_p1 = tmp_1124_reg_109916.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1124_fu_92495_p2() {
    mul_ln1118_1124_fu_92495_p2 = (!mul_ln1118_1124_fu_92495_p0.read().is_01() || !mul_ln1118_1124_fu_92495_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1124_fu_92495_p0.read()) * sc_bigint<5>(mul_ln1118_1124_fu_92495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1125_fu_54989_p0() {
    mul_ln1118_1125_fu_54989_p0 =  (sc_lv<3>) (sext_ln1116_125_fu_26155_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1125_fu_54989_p1() {
    mul_ln1118_1125_fu_54989_p1 = tmp_1125_fu_54975_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1125_fu_54989_p2() {
    mul_ln1118_1125_fu_54989_p2 = (!mul_ln1118_1125_fu_54989_p0.read().is_01() || !mul_ln1118_1125_fu_54989_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1125_fu_54989_p0.read()) * sc_bigint<5>(mul_ln1118_1125_fu_54989_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1126_fu_55021_p0() {
    mul_ln1118_1126_fu_55021_p0 =  (sc_lv<3>) (sext_ln1116_126_fu_26199_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1126_fu_55021_p1() {
    mul_ln1118_1126_fu_55021_p1 = tmp_1126_fu_55007_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1126_fu_55021_p2() {
    mul_ln1118_1126_fu_55021_p2 = (!mul_ln1118_1126_fu_55021_p0.read().is_01() || !mul_ln1118_1126_fu_55021_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1126_fu_55021_p0.read()) * sc_bigint<5>(mul_ln1118_1126_fu_55021_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1127_fu_92515_p0() {
    mul_ln1118_1127_fu_92515_p0 =  (sc_lv<3>) (sext_ln1116_127_reg_106431.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1127_fu_92515_p1() {
    mul_ln1118_1127_fu_92515_p1 = tmp_1127_reg_109921.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1127_fu_92515_p2() {
    mul_ln1118_1127_fu_92515_p2 = (!mul_ln1118_1127_fu_92515_p0.read().is_01() || !mul_ln1118_1127_fu_92515_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1127_fu_92515_p0.read()) * sc_bigint<5>(mul_ln1118_1127_fu_92515_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1128_fu_55063_p0() {
    mul_ln1118_1128_fu_55063_p0 =  (sc_lv<3>) (sext_ln1116_128_fu_26265_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1128_fu_55063_p1() {
    mul_ln1118_1128_fu_55063_p1 = tmp_1128_fu_55049_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1128_fu_55063_p2() {
    mul_ln1118_1128_fu_55063_p2 = (!mul_ln1118_1128_fu_55063_p0.read().is_01() || !mul_ln1118_1128_fu_55063_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1128_fu_55063_p0.read()) * sc_bigint<5>(mul_ln1118_1128_fu_55063_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1129_fu_55095_p0() {
    mul_ln1118_1129_fu_55095_p0 =  (sc_lv<3>) (sext_ln1116_129_fu_26309_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1129_fu_55095_p1() {
    mul_ln1118_1129_fu_55095_p1 = tmp_1129_fu_55081_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1129_fu_55095_p2() {
    mul_ln1118_1129_fu_55095_p2 = (!mul_ln1118_1129_fu_55095_p0.read().is_01() || !mul_ln1118_1129_fu_55095_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1129_fu_55095_p0.read()) * sc_bigint<5>(mul_ln1118_1129_fu_55095_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_112_fu_25691_p0() {
    mul_ln1118_112_fu_25691_p0 =  (sc_lv<3>) (sext_ln1116_112_fu_25683_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_112_fu_25691_p1() {
    mul_ln1118_112_fu_25691_p1 = tmp_112_fu_25673_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_112_fu_25691_p2() {
    mul_ln1118_112_fu_25691_p2 = (!mul_ln1118_112_fu_25691_p0.read().is_01() || !mul_ln1118_112_fu_25691_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_112_fu_25691_p0.read()) * sc_bigint<5>(mul_ln1118_112_fu_25691_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1130_fu_55127_p0() {
    mul_ln1118_1130_fu_55127_p0 =  (sc_lv<3>) (sext_ln1116_130_fu_26353_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1130_fu_55127_p1() {
    mul_ln1118_1130_fu_55127_p1 = tmp_1130_fu_55113_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1130_fu_55127_p2() {
    mul_ln1118_1130_fu_55127_p2 = (!mul_ln1118_1130_fu_55127_p0.read().is_01() || !mul_ln1118_1130_fu_55127_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1130_fu_55127_p0.read()) * sc_bigint<5>(mul_ln1118_1130_fu_55127_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1131_fu_55159_p0() {
    mul_ln1118_1131_fu_55159_p0 =  (sc_lv<3>) (sext_ln1116_131_fu_26397_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1131_fu_55159_p1() {
    mul_ln1118_1131_fu_55159_p1 = tmp_1131_fu_55145_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1131_fu_55159_p2() {
    mul_ln1118_1131_fu_55159_p2 = (!mul_ln1118_1131_fu_55159_p0.read().is_01() || !mul_ln1118_1131_fu_55159_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1131_fu_55159_p0.read()) * sc_bigint<5>(mul_ln1118_1131_fu_55159_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1132_fu_55191_p0() {
    mul_ln1118_1132_fu_55191_p0 =  (sc_lv<3>) (sext_ln1116_132_fu_26441_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1132_fu_55191_p1() {
    mul_ln1118_1132_fu_55191_p1 = tmp_1132_fu_55177_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1132_fu_55191_p2() {
    mul_ln1118_1132_fu_55191_p2 = (!mul_ln1118_1132_fu_55191_p0.read().is_01() || !mul_ln1118_1132_fu_55191_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1132_fu_55191_p0.read()) * sc_bigint<5>(mul_ln1118_1132_fu_55191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1133_fu_55223_p0() {
    mul_ln1118_1133_fu_55223_p0 =  (sc_lv<3>) (sext_ln1116_133_fu_26485_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1133_fu_55223_p1() {
    mul_ln1118_1133_fu_55223_p1 = tmp_1133_fu_55209_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1133_fu_55223_p2() {
    mul_ln1118_1133_fu_55223_p2 = (!mul_ln1118_1133_fu_55223_p0.read().is_01() || !mul_ln1118_1133_fu_55223_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1133_fu_55223_p0.read()) * sc_bigint<5>(mul_ln1118_1133_fu_55223_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1134_fu_92535_p0() {
    mul_ln1118_1134_fu_92535_p0 =  (sc_lv<3>) (sext_ln1116_134_reg_106449.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1134_fu_92535_p1() {
    mul_ln1118_1134_fu_92535_p1 = tmp_1134_reg_109926.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1134_fu_92535_p2() {
    mul_ln1118_1134_fu_92535_p2 = (!mul_ln1118_1134_fu_92535_p0.read().is_01() || !mul_ln1118_1134_fu_92535_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1134_fu_92535_p0.read()) * sc_bigint<5>(mul_ln1118_1134_fu_92535_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1135_fu_55265_p0() {
    mul_ln1118_1135_fu_55265_p0 =  (sc_lv<3>) (sext_ln1116_135_fu_26551_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1135_fu_55265_p1() {
    mul_ln1118_1135_fu_55265_p1 = tmp_1135_fu_55251_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1135_fu_55265_p2() {
    mul_ln1118_1135_fu_55265_p2 = (!mul_ln1118_1135_fu_55265_p0.read().is_01() || !mul_ln1118_1135_fu_55265_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1135_fu_55265_p0.read()) * sc_bigint<5>(mul_ln1118_1135_fu_55265_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1136_fu_55297_p0() {
    mul_ln1118_1136_fu_55297_p0 =  (sc_lv<3>) (sext_ln1116_136_fu_26595_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1136_fu_55297_p1() {
    mul_ln1118_1136_fu_55297_p1 = tmp_1136_fu_55283_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1136_fu_55297_p2() {
    mul_ln1118_1136_fu_55297_p2 = (!mul_ln1118_1136_fu_55297_p0.read().is_01() || !mul_ln1118_1136_fu_55297_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1136_fu_55297_p0.read()) * sc_bigint<5>(mul_ln1118_1136_fu_55297_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1137_fu_92555_p0() {
    mul_ln1118_1137_fu_92555_p0 =  (sc_lv<3>) (sext_ln1116_137_reg_106467.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1137_fu_92555_p1() {
    mul_ln1118_1137_fu_92555_p1 = tmp_1137_reg_109931.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1137_fu_92555_p2() {
    mul_ln1118_1137_fu_92555_p2 = (!mul_ln1118_1137_fu_92555_p0.read().is_01() || !mul_ln1118_1137_fu_92555_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1137_fu_92555_p0.read()) * sc_bigint<5>(mul_ln1118_1137_fu_92555_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1138_fu_55339_p0() {
    mul_ln1118_1138_fu_55339_p0 =  (sc_lv<3>) (sext_ln1116_138_fu_26661_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1138_fu_55339_p1() {
    mul_ln1118_1138_fu_55339_p1 = tmp_1138_fu_55325_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1138_fu_55339_p2() {
    mul_ln1118_1138_fu_55339_p2 = (!mul_ln1118_1138_fu_55339_p0.read().is_01() || !mul_ln1118_1138_fu_55339_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1138_fu_55339_p0.read()) * sc_bigint<5>(mul_ln1118_1138_fu_55339_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1139_fu_55371_p0() {
    mul_ln1118_1139_fu_55371_p0 =  (sc_lv<3>) (sext_ln1116_139_fu_26705_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1139_fu_55371_p1() {
    mul_ln1118_1139_fu_55371_p1 = tmp_1139_fu_55357_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1139_fu_55371_p2() {
    mul_ln1118_1139_fu_55371_p2 = (!mul_ln1118_1139_fu_55371_p0.read().is_01() || !mul_ln1118_1139_fu_55371_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1139_fu_55371_p0.read()) * sc_bigint<5>(mul_ln1118_1139_fu_55371_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_113_fu_25723_p0() {
    mul_ln1118_113_fu_25723_p0 =  (sc_lv<3>) (sext_ln1116_113_fu_25715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_113_fu_25723_p1() {
    mul_ln1118_113_fu_25723_p1 = tmp_113_fu_25705_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_113_fu_25723_p2() {
    mul_ln1118_113_fu_25723_p2 = (!mul_ln1118_113_fu_25723_p0.read().is_01() || !mul_ln1118_113_fu_25723_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_113_fu_25723_p0.read()) * sc_bigint<5>(mul_ln1118_113_fu_25723_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1140_fu_92575_p0() {
    mul_ln1118_1140_fu_92575_p0 =  (sc_lv<3>) (sext_ln1116_140_fu_80807_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1140_fu_92575_p1() {
    mul_ln1118_1140_fu_92575_p1 = tmp_1140_reg_109936.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1140_fu_92575_p2() {
    mul_ln1118_1140_fu_92575_p2 = (!mul_ln1118_1140_fu_92575_p0.read().is_01() || !mul_ln1118_1140_fu_92575_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1140_fu_92575_p0.read()) * sc_bigint<5>(mul_ln1118_1140_fu_92575_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1141_fu_92596_p0() {
    mul_ln1118_1141_fu_92596_p0 =  (sc_lv<3>) (sext_ln1116_141_fu_80831_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1141_fu_92596_p1() {
    mul_ln1118_1141_fu_92596_p1 = tmp_1141_reg_109941.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1141_fu_92596_p2() {
    mul_ln1118_1141_fu_92596_p2 = (!mul_ln1118_1141_fu_92596_p0.read().is_01() || !mul_ln1118_1141_fu_92596_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1141_fu_92596_p0.read()) * sc_bigint<5>(mul_ln1118_1141_fu_92596_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1142_fu_92617_p0() {
    mul_ln1118_1142_fu_92617_p0 =  (sc_lv<3>) (sext_ln1116_142_fu_80855_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1142_fu_92617_p1() {
    mul_ln1118_1142_fu_92617_p1 = tmp_1142_reg_109946.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1142_fu_92617_p2() {
    mul_ln1118_1142_fu_92617_p2 = (!mul_ln1118_1142_fu_92617_p0.read().is_01() || !mul_ln1118_1142_fu_92617_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1142_fu_92617_p0.read()) * sc_bigint<5>(mul_ln1118_1142_fu_92617_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1143_fu_92638_p0() {
    mul_ln1118_1143_fu_92638_p0 =  (sc_lv<3>) (sext_ln1116_143_fu_80879_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1143_fu_92638_p1() {
    mul_ln1118_1143_fu_92638_p1 = tmp_1143_reg_109951.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1143_fu_92638_p2() {
    mul_ln1118_1143_fu_92638_p2 = (!mul_ln1118_1143_fu_92638_p0.read().is_01() || !mul_ln1118_1143_fu_92638_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1143_fu_92638_p0.read()) * sc_bigint<5>(mul_ln1118_1143_fu_92638_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1144_fu_55443_p0() {
    mul_ln1118_1144_fu_55443_p0 =  (sc_lv<3>) (sext_ln1116_144_fu_26821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1144_fu_55443_p1() {
    mul_ln1118_1144_fu_55443_p1 = tmp_1144_fu_55429_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1144_fu_55443_p2() {
    mul_ln1118_1144_fu_55443_p2 = (!mul_ln1118_1144_fu_55443_p0.read().is_01() || !mul_ln1118_1144_fu_55443_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1144_fu_55443_p0.read()) * sc_bigint<5>(mul_ln1118_1144_fu_55443_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1145_fu_55475_p0() {
    mul_ln1118_1145_fu_55475_p0 =  (sc_lv<3>) (sext_ln1116_145_fu_26865_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1145_fu_55475_p1() {
    mul_ln1118_1145_fu_55475_p1 = tmp_1145_fu_55461_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1145_fu_55475_p2() {
    mul_ln1118_1145_fu_55475_p2 = (!mul_ln1118_1145_fu_55475_p0.read().is_01() || !mul_ln1118_1145_fu_55475_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1145_fu_55475_p0.read()) * sc_bigint<5>(mul_ln1118_1145_fu_55475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1146_fu_92659_p0() {
    mul_ln1118_1146_fu_92659_p0 =  (sc_lv<3>) (sext_ln1116_146_reg_106525.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1146_fu_92659_p1() {
    mul_ln1118_1146_fu_92659_p1 = tmp_1146_reg_109956.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1146_fu_92659_p2() {
    mul_ln1118_1146_fu_92659_p2 = (!mul_ln1118_1146_fu_92659_p0.read().is_01() || !mul_ln1118_1146_fu_92659_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1146_fu_92659_p0.read()) * sc_bigint<5>(mul_ln1118_1146_fu_92659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1147_fu_55517_p0() {
    mul_ln1118_1147_fu_55517_p0 =  (sc_lv<3>) (sext_ln1116_147_fu_26931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1147_fu_55517_p1() {
    mul_ln1118_1147_fu_55517_p1 = tmp_1147_fu_55503_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1147_fu_55517_p2() {
    mul_ln1118_1147_fu_55517_p2 = (!mul_ln1118_1147_fu_55517_p0.read().is_01() || !mul_ln1118_1147_fu_55517_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1147_fu_55517_p0.read()) * sc_bigint<5>(mul_ln1118_1147_fu_55517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1148_fu_55549_p0() {
    mul_ln1118_1148_fu_55549_p0 =  (sc_lv<3>) (sext_ln1116_148_fu_26975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1148_fu_55549_p1() {
    mul_ln1118_1148_fu_55549_p1 = tmp_1148_fu_55535_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1148_fu_55549_p2() {
    mul_ln1118_1148_fu_55549_p2 = (!mul_ln1118_1148_fu_55549_p0.read().is_01() || !mul_ln1118_1148_fu_55549_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1148_fu_55549_p0.read()) * sc_bigint<5>(mul_ln1118_1148_fu_55549_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1149_fu_92679_p0() {
    mul_ln1118_1149_fu_92679_p0 =  (sc_lv<3>) (sext_ln1116_149_reg_106543.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1149_fu_92679_p1() {
    mul_ln1118_1149_fu_92679_p1 = tmp_1149_reg_109961.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1149_fu_92679_p2() {
    mul_ln1118_1149_fu_92679_p2 = (!mul_ln1118_1149_fu_92679_p0.read().is_01() || !mul_ln1118_1149_fu_92679_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1149_fu_92679_p0.read()) * sc_bigint<5>(mul_ln1118_1149_fu_92679_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_114_fu_25767_p0() {
    mul_ln1118_114_fu_25767_p0 =  (sc_lv<3>) (sext_ln1116_114_fu_25759_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_114_fu_25767_p1() {
    mul_ln1118_114_fu_25767_p1 = tmp_114_fu_25749_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_114_fu_25767_p2() {
    mul_ln1118_114_fu_25767_p2 = (!mul_ln1118_114_fu_25767_p0.read().is_01() || !mul_ln1118_114_fu_25767_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_114_fu_25767_p0.read()) * sc_bigint<5>(mul_ln1118_114_fu_25767_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1150_fu_55591_p0() {
    mul_ln1118_1150_fu_55591_p0 =  (sc_lv<3>) (sext_ln1116_150_fu_27041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1150_fu_55591_p1() {
    mul_ln1118_1150_fu_55591_p1 = tmp_1150_fu_55577_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1150_fu_55591_p2() {
    mul_ln1118_1150_fu_55591_p2 = (!mul_ln1118_1150_fu_55591_p0.read().is_01() || !mul_ln1118_1150_fu_55591_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1150_fu_55591_p0.read()) * sc_bigint<5>(mul_ln1118_1150_fu_55591_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1151_fu_55623_p0() {
    mul_ln1118_1151_fu_55623_p0 =  (sc_lv<3>) (sext_ln1116_151_fu_27085_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1151_fu_55623_p1() {
    mul_ln1118_1151_fu_55623_p1 = tmp_1151_fu_55609_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1151_fu_55623_p2() {
    mul_ln1118_1151_fu_55623_p2 = (!mul_ln1118_1151_fu_55623_p0.read().is_01() || !mul_ln1118_1151_fu_55623_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1151_fu_55623_p0.read()) * sc_bigint<5>(mul_ln1118_1151_fu_55623_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1152_fu_92699_p0() {
    mul_ln1118_1152_fu_92699_p0 =  (sc_lv<3>) (sext_ln1116_152_fu_80943_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1152_fu_92699_p1() {
    mul_ln1118_1152_fu_92699_p1 = tmp_1152_reg_109966.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1152_fu_92699_p2() {
    mul_ln1118_1152_fu_92699_p2 = (!mul_ln1118_1152_fu_92699_p0.read().is_01() || !mul_ln1118_1152_fu_92699_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1152_fu_92699_p0.read()) * sc_bigint<5>(mul_ln1118_1152_fu_92699_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1153_fu_55665_p0() {
    mul_ln1118_1153_fu_55665_p0 =  (sc_lv<3>) (sext_ln1116_153_fu_27147_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1153_fu_55665_p1() {
    mul_ln1118_1153_fu_55665_p1 = tmp_1153_fu_55651_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1153_fu_55665_p2() {
    mul_ln1118_1153_fu_55665_p2 = (!mul_ln1118_1153_fu_55665_p0.read().is_01() || !mul_ln1118_1153_fu_55665_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1153_fu_55665_p0.read()) * sc_bigint<5>(mul_ln1118_1153_fu_55665_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1154_fu_55697_p0() {
    mul_ln1118_1154_fu_55697_p0 =  (sc_lv<3>) (sext_ln1116_154_fu_27191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1154_fu_55697_p1() {
    mul_ln1118_1154_fu_55697_p1 = tmp_1154_fu_55683_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1154_fu_55697_p2() {
    mul_ln1118_1154_fu_55697_p2 = (!mul_ln1118_1154_fu_55697_p0.read().is_01() || !mul_ln1118_1154_fu_55697_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1154_fu_55697_p0.read()) * sc_bigint<5>(mul_ln1118_1154_fu_55697_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1155_fu_55729_p0() {
    mul_ln1118_1155_fu_55729_p0 =  (sc_lv<3>) (sext_ln1116_155_fu_27235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1155_fu_55729_p1() {
    mul_ln1118_1155_fu_55729_p1 = tmp_1155_fu_55715_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1155_fu_55729_p2() {
    mul_ln1118_1155_fu_55729_p2 = (!mul_ln1118_1155_fu_55729_p0.read().is_01() || !mul_ln1118_1155_fu_55729_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1155_fu_55729_p0.read()) * sc_bigint<5>(mul_ln1118_1155_fu_55729_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1156_fu_55761_p0() {
    mul_ln1118_1156_fu_55761_p0 =  (sc_lv<3>) (sext_ln1116_156_fu_27279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1156_fu_55761_p1() {
    mul_ln1118_1156_fu_55761_p1 = tmp_1156_fu_55747_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1156_fu_55761_p2() {
    mul_ln1118_1156_fu_55761_p2 = (!mul_ln1118_1156_fu_55761_p0.read().is_01() || !mul_ln1118_1156_fu_55761_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1156_fu_55761_p0.read()) * sc_bigint<5>(mul_ln1118_1156_fu_55761_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1157_fu_55793_p0() {
    mul_ln1118_1157_fu_55793_p0 =  (sc_lv<3>) (sext_ln1116_157_fu_27323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1157_fu_55793_p1() {
    mul_ln1118_1157_fu_55793_p1 = tmp_1157_fu_55779_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1157_fu_55793_p2() {
    mul_ln1118_1157_fu_55793_p2 = (!mul_ln1118_1157_fu_55793_p0.read().is_01() || !mul_ln1118_1157_fu_55793_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1157_fu_55793_p0.read()) * sc_bigint<5>(mul_ln1118_1157_fu_55793_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1158_fu_55825_p0() {
    mul_ln1118_1158_fu_55825_p0 =  (sc_lv<3>) (sext_ln1116_158_fu_27367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1158_fu_55825_p1() {
    mul_ln1118_1158_fu_55825_p1 = tmp_1158_fu_55811_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1158_fu_55825_p2() {
    mul_ln1118_1158_fu_55825_p2 = (!mul_ln1118_1158_fu_55825_p0.read().is_01() || !mul_ln1118_1158_fu_55825_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1158_fu_55825_p0.read()) * sc_bigint<5>(mul_ln1118_1158_fu_55825_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1159_fu_55857_p0() {
    mul_ln1118_1159_fu_55857_p0 =  (sc_lv<3>) (sext_ln1116_159_fu_27411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1159_fu_55857_p1() {
    mul_ln1118_1159_fu_55857_p1 = tmp_1159_fu_55843_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1159_fu_55857_p2() {
    mul_ln1118_1159_fu_55857_p2 = (!mul_ln1118_1159_fu_55857_p0.read().is_01() || !mul_ln1118_1159_fu_55857_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1159_fu_55857_p0.read()) * sc_bigint<5>(mul_ln1118_1159_fu_55857_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_115_fu_80670_p0() {
    mul_ln1118_115_fu_80670_p0 =  (sc_lv<3>) (sext_ln1116_115_reg_106359.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_115_fu_80670_p1() {
    mul_ln1118_115_fu_80670_p1 = tmp_115_reg_106354.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_115_fu_80670_p2() {
    mul_ln1118_115_fu_80670_p2 = (!mul_ln1118_115_fu_80670_p0.read().is_01() || !mul_ln1118_115_fu_80670_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_115_fu_80670_p0.read()) * sc_bigint<5>(mul_ln1118_115_fu_80670_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1160_fu_55877_p0() {
    mul_ln1118_1160_fu_55877_p0 =  (sc_lv<3>) (sext_ln1116_160_fu_27443_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1160_fu_55877_p1() {
    mul_ln1118_1160_fu_55877_p1 = tmp_1160_fu_55863_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1160_fu_55877_p2() {
    mul_ln1118_1160_fu_55877_p2 = (!mul_ln1118_1160_fu_55877_p0.read().is_01() || !mul_ln1118_1160_fu_55877_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1160_fu_55877_p0.read()) * sc_bigint<5>(mul_ln1118_1160_fu_55877_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1161_fu_55909_p0() {
    mul_ln1118_1161_fu_55909_p0 =  (sc_lv<3>) (sext_ln1116_161_fu_27487_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1161_fu_55909_p1() {
    mul_ln1118_1161_fu_55909_p1 = tmp_1161_fu_55895_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1161_fu_55909_p2() {
    mul_ln1118_1161_fu_55909_p2 = (!mul_ln1118_1161_fu_55909_p0.read().is_01() || !mul_ln1118_1161_fu_55909_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1161_fu_55909_p0.read()) * sc_bigint<5>(mul_ln1118_1161_fu_55909_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1162_fu_55941_p0() {
    mul_ln1118_1162_fu_55941_p0 =  (sc_lv<3>) (sext_ln1116_162_fu_27531_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1162_fu_55941_p1() {
    mul_ln1118_1162_fu_55941_p1 = tmp_1162_fu_55927_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1162_fu_55941_p2() {
    mul_ln1118_1162_fu_55941_p2 = (!mul_ln1118_1162_fu_55941_p0.read().is_01() || !mul_ln1118_1162_fu_55941_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1162_fu_55941_p0.read()) * sc_bigint<5>(mul_ln1118_1162_fu_55941_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1163_fu_55961_p0() {
    mul_ln1118_1163_fu_55961_p0 =  (sc_lv<3>) (sext_ln1116_163_fu_27563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1163_fu_55961_p1() {
    mul_ln1118_1163_fu_55961_p1 = tmp_1163_fu_55947_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1163_fu_55961_p2() {
    mul_ln1118_1163_fu_55961_p2 = (!mul_ln1118_1163_fu_55961_p0.read().is_01() || !mul_ln1118_1163_fu_55961_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1163_fu_55961_p0.read()) * sc_bigint<5>(mul_ln1118_1163_fu_55961_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1164_fu_55993_p0() {
    mul_ln1118_1164_fu_55993_p0 =  (sc_lv<3>) (sext_ln1116_164_fu_27607_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1164_fu_55993_p1() {
    mul_ln1118_1164_fu_55993_p1 = tmp_1164_fu_55979_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1164_fu_55993_p2() {
    mul_ln1118_1164_fu_55993_p2 = (!mul_ln1118_1164_fu_55993_p0.read().is_01() || !mul_ln1118_1164_fu_55993_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1164_fu_55993_p0.read()) * sc_bigint<5>(mul_ln1118_1164_fu_55993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1165_fu_92742_p0() {
    mul_ln1118_1165_fu_92742_p0 =  (sc_lv<3>) (sext_ln1116_165_reg_106581.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1165_fu_92742_p1() {
    mul_ln1118_1165_fu_92742_p1 = tmp_1165_reg_109981.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1165_fu_92742_p2() {
    mul_ln1118_1165_fu_92742_p2 = (!mul_ln1118_1165_fu_92742_p0.read().is_01() || !mul_ln1118_1165_fu_92742_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1165_fu_92742_p0.read()) * sc_bigint<5>(mul_ln1118_1165_fu_92742_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1166_fu_56035_p0() {
    mul_ln1118_1166_fu_56035_p0 =  (sc_lv<3>) (sext_ln1116_166_fu_27673_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1166_fu_56035_p1() {
    mul_ln1118_1166_fu_56035_p1 = tmp_1166_fu_56021_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1166_fu_56035_p2() {
    mul_ln1118_1166_fu_56035_p2 = (!mul_ln1118_1166_fu_56035_p0.read().is_01() || !mul_ln1118_1166_fu_56035_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1166_fu_56035_p0.read()) * sc_bigint<5>(mul_ln1118_1166_fu_56035_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1167_fu_56067_p0() {
    mul_ln1118_1167_fu_56067_p0 =  (sc_lv<3>) (sext_ln1116_167_fu_27717_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1167_fu_56067_p1() {
    mul_ln1118_1167_fu_56067_p1 = tmp_1167_fu_56053_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1167_fu_56067_p2() {
    mul_ln1118_1167_fu_56067_p2 = (!mul_ln1118_1167_fu_56067_p0.read().is_01() || !mul_ln1118_1167_fu_56067_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1167_fu_56067_p0.read()) * sc_bigint<5>(mul_ln1118_1167_fu_56067_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1168_fu_92762_p0() {
    mul_ln1118_1168_fu_92762_p0 =  (sc_lv<3>) (sext_ln1116_168_reg_106599.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1168_fu_92762_p1() {
    mul_ln1118_1168_fu_92762_p1 = tmp_1168_reg_109986.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1168_fu_92762_p2() {
    mul_ln1118_1168_fu_92762_p2 = (!mul_ln1118_1168_fu_92762_p0.read().is_01() || !mul_ln1118_1168_fu_92762_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1168_fu_92762_p0.read()) * sc_bigint<5>(mul_ln1118_1168_fu_92762_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1169_fu_56109_p0() {
    mul_ln1118_1169_fu_56109_p0 =  (sc_lv<3>) (sext_ln1116_169_fu_27783_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1169_fu_56109_p1() {
    mul_ln1118_1169_fu_56109_p1 = tmp_1169_fu_56095_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1169_fu_56109_p2() {
    mul_ln1118_1169_fu_56109_p2 = (!mul_ln1118_1169_fu_56109_p0.read().is_01() || !mul_ln1118_1169_fu_56109_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1169_fu_56109_p0.read()) * sc_bigint<5>(mul_ln1118_1169_fu_56109_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_116_fu_25833_p0() {
    mul_ln1118_116_fu_25833_p0 =  (sc_lv<3>) (sext_ln1116_116_fu_25825_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_116_fu_25833_p1() {
    mul_ln1118_116_fu_25833_p1 = tmp_116_fu_25815_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_116_fu_25833_p2() {
    mul_ln1118_116_fu_25833_p2 = (!mul_ln1118_116_fu_25833_p0.read().is_01() || !mul_ln1118_116_fu_25833_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_116_fu_25833_p0.read()) * sc_bigint<5>(mul_ln1118_116_fu_25833_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1170_fu_56141_p0() {
    mul_ln1118_1170_fu_56141_p0 =  (sc_lv<3>) (sext_ln1116_170_fu_27827_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1170_fu_56141_p1() {
    mul_ln1118_1170_fu_56141_p1 = tmp_1170_fu_56127_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1170_fu_56141_p2() {
    mul_ln1118_1170_fu_56141_p2 = (!mul_ln1118_1170_fu_56141_p0.read().is_01() || !mul_ln1118_1170_fu_56141_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1170_fu_56141_p0.read()) * sc_bigint<5>(mul_ln1118_1170_fu_56141_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1171_fu_92782_p0() {
    mul_ln1118_1171_fu_92782_p0 =  (sc_lv<3>) (sext_ln1116_171_reg_106617.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1171_fu_92782_p1() {
    mul_ln1118_1171_fu_92782_p1 = tmp_1171_reg_109991.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1171_fu_92782_p2() {
    mul_ln1118_1171_fu_92782_p2 = (!mul_ln1118_1171_fu_92782_p0.read().is_01() || !mul_ln1118_1171_fu_92782_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1171_fu_92782_p0.read()) * sc_bigint<5>(mul_ln1118_1171_fu_92782_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1172_fu_56183_p0() {
    mul_ln1118_1172_fu_56183_p0 =  (sc_lv<3>) (sext_ln1116_172_fu_27893_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1172_fu_56183_p1() {
    mul_ln1118_1172_fu_56183_p1 = tmp_1172_fu_56169_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1172_fu_56183_p2() {
    mul_ln1118_1172_fu_56183_p2 = (!mul_ln1118_1172_fu_56183_p0.read().is_01() || !mul_ln1118_1172_fu_56183_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1172_fu_56183_p0.read()) * sc_bigint<5>(mul_ln1118_1172_fu_56183_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1173_fu_56215_p0() {
    mul_ln1118_1173_fu_56215_p0 =  (sc_lv<3>) (sext_ln1116_173_fu_27937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1173_fu_56215_p1() {
    mul_ln1118_1173_fu_56215_p1 = tmp_1173_fu_56201_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1173_fu_56215_p2() {
    mul_ln1118_1173_fu_56215_p2 = (!mul_ln1118_1173_fu_56215_p0.read().is_01() || !mul_ln1118_1173_fu_56215_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1173_fu_56215_p0.read()) * sc_bigint<5>(mul_ln1118_1173_fu_56215_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1174_fu_92802_p0() {
    mul_ln1118_1174_fu_92802_p0 =  (sc_lv<3>) (sext_ln1116_174_reg_106635.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1174_fu_92802_p1() {
    mul_ln1118_1174_fu_92802_p1 = tmp_1174_reg_109996.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1174_fu_92802_p2() {
    mul_ln1118_1174_fu_92802_p2 = (!mul_ln1118_1174_fu_92802_p0.read().is_01() || !mul_ln1118_1174_fu_92802_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1174_fu_92802_p0.read()) * sc_bigint<5>(mul_ln1118_1174_fu_92802_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1175_fu_56257_p0() {
    mul_ln1118_1175_fu_56257_p0 =  (sc_lv<3>) (sext_ln1116_175_fu_28003_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1175_fu_56257_p1() {
    mul_ln1118_1175_fu_56257_p1 = tmp_1175_fu_56243_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1175_fu_56257_p2() {
    mul_ln1118_1175_fu_56257_p2 = (!mul_ln1118_1175_fu_56257_p0.read().is_01() || !mul_ln1118_1175_fu_56257_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1175_fu_56257_p0.read()) * sc_bigint<5>(mul_ln1118_1175_fu_56257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1176_fu_56289_p0() {
    mul_ln1118_1176_fu_56289_p0 =  (sc_lv<3>) (sext_ln1116_176_fu_28047_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1176_fu_56289_p1() {
    mul_ln1118_1176_fu_56289_p1 = tmp_1176_fu_56275_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1176_fu_56289_p2() {
    mul_ln1118_1176_fu_56289_p2 = (!mul_ln1118_1176_fu_56289_p0.read().is_01() || !mul_ln1118_1176_fu_56289_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1176_fu_56289_p0.read()) * sc_bigint<5>(mul_ln1118_1176_fu_56289_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1177_fu_92822_p0() {
    mul_ln1118_1177_fu_92822_p0 =  (sc_lv<3>) (sext_ln1116_177_reg_106653.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1177_fu_92822_p1() {
    mul_ln1118_1177_fu_92822_p1 = tmp_1177_reg_110001.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1177_fu_92822_p2() {
    mul_ln1118_1177_fu_92822_p2 = (!mul_ln1118_1177_fu_92822_p0.read().is_01() || !mul_ln1118_1177_fu_92822_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1177_fu_92822_p0.read()) * sc_bigint<5>(mul_ln1118_1177_fu_92822_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1178_fu_56331_p0() {
    mul_ln1118_1178_fu_56331_p0 =  (sc_lv<3>) (sext_ln1116_178_fu_28113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1178_fu_56331_p1() {
    mul_ln1118_1178_fu_56331_p1 = tmp_1178_fu_56317_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1178_fu_56331_p2() {
    mul_ln1118_1178_fu_56331_p2 = (!mul_ln1118_1178_fu_56331_p0.read().is_01() || !mul_ln1118_1178_fu_56331_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1178_fu_56331_p0.read()) * sc_bigint<5>(mul_ln1118_1178_fu_56331_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1179_fu_56363_p0() {
    mul_ln1118_1179_fu_56363_p0 =  (sc_lv<3>) (sext_ln1116_179_fu_28157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1179_fu_56363_p1() {
    mul_ln1118_1179_fu_56363_p1 = tmp_1179_fu_56349_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1179_fu_56363_p2() {
    mul_ln1118_1179_fu_56363_p2 = (!mul_ln1118_1179_fu_56363_p0.read().is_01() || !mul_ln1118_1179_fu_56363_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1179_fu_56363_p0.read()) * sc_bigint<5>(mul_ln1118_1179_fu_56363_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_117_fu_25877_p0() {
    mul_ln1118_117_fu_25877_p0 =  (sc_lv<3>) (sext_ln1116_117_fu_25869_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_117_fu_25877_p1() {
    mul_ln1118_117_fu_25877_p1 = tmp_117_fu_25859_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_117_fu_25877_p2() {
    mul_ln1118_117_fu_25877_p2 = (!mul_ln1118_117_fu_25877_p0.read().is_01() || !mul_ln1118_117_fu_25877_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_117_fu_25877_p0.read()) * sc_bigint<5>(mul_ln1118_117_fu_25877_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1180_fu_56395_p0() {
    mul_ln1118_1180_fu_56395_p0 =  (sc_lv<3>) (sext_ln1116_180_fu_28201_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1180_fu_56395_p1() {
    mul_ln1118_1180_fu_56395_p1 = tmp_1180_fu_56381_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1180_fu_56395_p2() {
    mul_ln1118_1180_fu_56395_p2 = (!mul_ln1118_1180_fu_56395_p0.read().is_01() || !mul_ln1118_1180_fu_56395_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1180_fu_56395_p0.read()) * sc_bigint<5>(mul_ln1118_1180_fu_56395_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1181_fu_56427_p0() {
    mul_ln1118_1181_fu_56427_p0 =  (sc_lv<3>) (sext_ln1116_181_fu_28245_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1181_fu_56427_p1() {
    mul_ln1118_1181_fu_56427_p1 = tmp_1181_fu_56413_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1181_fu_56427_p2() {
    mul_ln1118_1181_fu_56427_p2 = (!mul_ln1118_1181_fu_56427_p0.read().is_01() || !mul_ln1118_1181_fu_56427_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1181_fu_56427_p0.read()) * sc_bigint<5>(mul_ln1118_1181_fu_56427_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1182_fu_56459_p0() {
    mul_ln1118_1182_fu_56459_p0 =  (sc_lv<3>) (sext_ln1116_182_fu_28289_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1182_fu_56459_p1() {
    mul_ln1118_1182_fu_56459_p1 = tmp_1182_fu_56445_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1182_fu_56459_p2() {
    mul_ln1118_1182_fu_56459_p2 = (!mul_ln1118_1182_fu_56459_p0.read().is_01() || !mul_ln1118_1182_fu_56459_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1182_fu_56459_p0.read()) * sc_bigint<5>(mul_ln1118_1182_fu_56459_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1183_fu_56491_p0() {
    mul_ln1118_1183_fu_56491_p0 =  (sc_lv<3>) (sext_ln1116_183_fu_28333_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1183_fu_56491_p1() {
    mul_ln1118_1183_fu_56491_p1 = tmp_1183_fu_56477_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1183_fu_56491_p2() {
    mul_ln1118_1183_fu_56491_p2 = (!mul_ln1118_1183_fu_56491_p0.read().is_01() || !mul_ln1118_1183_fu_56491_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1183_fu_56491_p0.read()) * sc_bigint<5>(mul_ln1118_1183_fu_56491_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1184_fu_56523_p0() {
    mul_ln1118_1184_fu_56523_p0 =  (sc_lv<3>) (sext_ln1116_184_fu_28377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1184_fu_56523_p1() {
    mul_ln1118_1184_fu_56523_p1 = tmp_1184_fu_56509_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1184_fu_56523_p2() {
    mul_ln1118_1184_fu_56523_p2 = (!mul_ln1118_1184_fu_56523_p0.read().is_01() || !mul_ln1118_1184_fu_56523_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1184_fu_56523_p0.read()) * sc_bigint<5>(mul_ln1118_1184_fu_56523_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1185_fu_56543_p0() {
    mul_ln1118_1185_fu_56543_p0 =  (sc_lv<3>) (sext_ln1116_185_fu_28409_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1185_fu_56543_p1() {
    mul_ln1118_1185_fu_56543_p1 = tmp_1185_fu_56529_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1185_fu_56543_p2() {
    mul_ln1118_1185_fu_56543_p2 = (!mul_ln1118_1185_fu_56543_p0.read().is_01() || !mul_ln1118_1185_fu_56543_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1185_fu_56543_p0.read()) * sc_bigint<5>(mul_ln1118_1185_fu_56543_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1186_fu_56575_p0() {
    mul_ln1118_1186_fu_56575_p0 =  (sc_lv<3>) (sext_ln1116_186_fu_28453_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1186_fu_56575_p1() {
    mul_ln1118_1186_fu_56575_p1 = tmp_1186_fu_56561_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1186_fu_56575_p2() {
    mul_ln1118_1186_fu_56575_p2 = (!mul_ln1118_1186_fu_56575_p0.read().is_01() || !mul_ln1118_1186_fu_56575_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1186_fu_56575_p0.read()) * sc_bigint<5>(mul_ln1118_1186_fu_56575_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1187_fu_56607_p0() {
    mul_ln1118_1187_fu_56607_p0 =  (sc_lv<3>) (sext_ln1116_187_fu_28497_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1187_fu_56607_p1() {
    mul_ln1118_1187_fu_56607_p1 = tmp_1187_fu_56593_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1187_fu_56607_p2() {
    mul_ln1118_1187_fu_56607_p2 = (!mul_ln1118_1187_fu_56607_p0.read().is_01() || !mul_ln1118_1187_fu_56607_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1187_fu_56607_p0.read()) * sc_bigint<5>(mul_ln1118_1187_fu_56607_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1188_fu_56627_p0() {
    mul_ln1118_1188_fu_56627_p0 =  (sc_lv<3>) (sext_ln1116_188_fu_28529_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1188_fu_56627_p1() {
    mul_ln1118_1188_fu_56627_p1 = tmp_1188_fu_56613_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1188_fu_56627_p2() {
    mul_ln1118_1188_fu_56627_p2 = (!mul_ln1118_1188_fu_56627_p0.read().is_01() || !mul_ln1118_1188_fu_56627_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1188_fu_56627_p0.read()) * sc_bigint<5>(mul_ln1118_1188_fu_56627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1189_fu_56659_p0() {
    mul_ln1118_1189_fu_56659_p0 =  (sc_lv<3>) (sext_ln1116_189_fu_28573_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1189_fu_56659_p1() {
    mul_ln1118_1189_fu_56659_p1 = tmp_1189_fu_56645_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1189_fu_56659_p2() {
    mul_ln1118_1189_fu_56659_p2 = (!mul_ln1118_1189_fu_56659_p0.read().is_01() || !mul_ln1118_1189_fu_56659_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1189_fu_56659_p0.read()) * sc_bigint<5>(mul_ln1118_1189_fu_56659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_118_fu_80690_p0() {
    mul_ln1118_118_fu_80690_p0 =  (sc_lv<3>) (sext_ln1116_118_reg_106377.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_118_fu_80690_p1() {
    mul_ln1118_118_fu_80690_p1 = tmp_118_reg_106372.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_118_fu_80690_p2() {
    mul_ln1118_118_fu_80690_p2 = (!mul_ln1118_118_fu_80690_p0.read().is_01() || !mul_ln1118_118_fu_80690_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_118_fu_80690_p0.read()) * sc_bigint<5>(mul_ln1118_118_fu_80690_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1190_fu_92864_p0() {
    mul_ln1118_1190_fu_92864_p0 =  (sc_lv<3>) (sext_ln1116_190_reg_106681.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1190_fu_92864_p1() {
    mul_ln1118_1190_fu_92864_p1 = tmp_1190_reg_110016.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1190_fu_92864_p2() {
    mul_ln1118_1190_fu_92864_p2 = (!mul_ln1118_1190_fu_92864_p0.read().is_01() || !mul_ln1118_1190_fu_92864_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1190_fu_92864_p0.read()) * sc_bigint<5>(mul_ln1118_1190_fu_92864_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1191_fu_56701_p0() {
    mul_ln1118_1191_fu_56701_p0 =  (sc_lv<3>) (sext_ln1116_191_fu_28639_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1191_fu_56701_p1() {
    mul_ln1118_1191_fu_56701_p1 = tmp_1191_fu_56687_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1191_fu_56701_p2() {
    mul_ln1118_1191_fu_56701_p2 = (!mul_ln1118_1191_fu_56701_p0.read().is_01() || !mul_ln1118_1191_fu_56701_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1191_fu_56701_p0.read()) * sc_bigint<5>(mul_ln1118_1191_fu_56701_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1192_fu_56733_p0() {
    mul_ln1118_1192_fu_56733_p0 =  (sc_lv<3>) (sext_ln1116_192_fu_28683_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1192_fu_56733_p1() {
    mul_ln1118_1192_fu_56733_p1 = tmp_1192_fu_56719_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1192_fu_56733_p2() {
    mul_ln1118_1192_fu_56733_p2 = (!mul_ln1118_1192_fu_56733_p0.read().is_01() || !mul_ln1118_1192_fu_56733_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1192_fu_56733_p0.read()) * sc_bigint<5>(mul_ln1118_1192_fu_56733_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1193_fu_92884_p0() {
    mul_ln1118_1193_fu_92884_p0 =  (sc_lv<3>) (sext_ln1116_193_reg_106699.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1193_fu_92884_p1() {
    mul_ln1118_1193_fu_92884_p1 = tmp_1193_reg_110021.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1193_fu_92884_p2() {
    mul_ln1118_1193_fu_92884_p2 = (!mul_ln1118_1193_fu_92884_p0.read().is_01() || !mul_ln1118_1193_fu_92884_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1193_fu_92884_p0.read()) * sc_bigint<5>(mul_ln1118_1193_fu_92884_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1194_fu_56775_p0() {
    mul_ln1118_1194_fu_56775_p0 =  (sc_lv<3>) (sext_ln1116_194_fu_28749_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1194_fu_56775_p1() {
    mul_ln1118_1194_fu_56775_p1 = tmp_1194_fu_56761_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1194_fu_56775_p2() {
    mul_ln1118_1194_fu_56775_p2 = (!mul_ln1118_1194_fu_56775_p0.read().is_01() || !mul_ln1118_1194_fu_56775_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1194_fu_56775_p0.read()) * sc_bigint<5>(mul_ln1118_1194_fu_56775_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1195_fu_56807_p0() {
    mul_ln1118_1195_fu_56807_p0 =  (sc_lv<3>) (sext_ln1116_195_fu_28793_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1195_fu_56807_p1() {
    mul_ln1118_1195_fu_56807_p1 = tmp_1195_fu_56793_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1195_fu_56807_p2() {
    mul_ln1118_1195_fu_56807_p2 = (!mul_ln1118_1195_fu_56807_p0.read().is_01() || !mul_ln1118_1195_fu_56807_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1195_fu_56807_p0.read()) * sc_bigint<5>(mul_ln1118_1195_fu_56807_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1196_fu_92904_p0() {
    mul_ln1118_1196_fu_92904_p0 =  (sc_lv<3>) (sext_ln1116_196_reg_106717.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1196_fu_92904_p1() {
    mul_ln1118_1196_fu_92904_p1 = tmp_1196_reg_110026.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1196_fu_92904_p2() {
    mul_ln1118_1196_fu_92904_p2 = (!mul_ln1118_1196_fu_92904_p0.read().is_01() || !mul_ln1118_1196_fu_92904_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1196_fu_92904_p0.read()) * sc_bigint<5>(mul_ln1118_1196_fu_92904_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1197_fu_56849_p0() {
    mul_ln1118_1197_fu_56849_p0 =  (sc_lv<3>) (sext_ln1116_197_fu_28859_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1197_fu_56849_p1() {
    mul_ln1118_1197_fu_56849_p1 = tmp_1197_fu_56835_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1197_fu_56849_p2() {
    mul_ln1118_1197_fu_56849_p2 = (!mul_ln1118_1197_fu_56849_p0.read().is_01() || !mul_ln1118_1197_fu_56849_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1197_fu_56849_p0.read()) * sc_bigint<5>(mul_ln1118_1197_fu_56849_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1198_fu_56881_p0() {
    mul_ln1118_1198_fu_56881_p0 =  (sc_lv<3>) (sext_ln1116_198_fu_28903_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1198_fu_56881_p1() {
    mul_ln1118_1198_fu_56881_p1 = tmp_1198_fu_56867_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1198_fu_56881_p2() {
    mul_ln1118_1198_fu_56881_p2 = (!mul_ln1118_1198_fu_56881_p0.read().is_01() || !mul_ln1118_1198_fu_56881_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1198_fu_56881_p0.read()) * sc_bigint<5>(mul_ln1118_1198_fu_56881_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1199_fu_92924_p0() {
    mul_ln1118_1199_fu_92924_p0 =  (sc_lv<3>) (sext_ln1116_199_reg_106735.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1199_fu_92924_p1() {
    mul_ln1118_1199_fu_92924_p1 = tmp_1199_reg_110031.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1199_fu_92924_p2() {
    mul_ln1118_1199_fu_92924_p2 = (!mul_ln1118_1199_fu_92924_p0.read().is_01() || !mul_ln1118_1199_fu_92924_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1199_fu_92924_p0.read()) * sc_bigint<5>(mul_ln1118_1199_fu_92924_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_119_fu_25943_p0() {
    mul_ln1118_119_fu_25943_p0 =  (sc_lv<3>) (sext_ln1116_119_fu_25935_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_119_fu_25943_p1() {
    mul_ln1118_119_fu_25943_p1 = tmp_119_fu_25925_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_119_fu_25943_p2() {
    mul_ln1118_119_fu_25943_p2 = (!mul_ln1118_119_fu_25943_p0.read().is_01() || !mul_ln1118_119_fu_25943_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_119_fu_25943_p0.read()) * sc_bigint<5>(mul_ln1118_119_fu_25943_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_11_fu_21939_p0() {
    mul_ln1118_11_fu_21939_p0 =  (sc_lv<3>) (sext_ln1116_11_fu_21931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_11_fu_21939_p1() {
    mul_ln1118_11_fu_21939_p1 = tmp_12_fu_21921_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_11_fu_21939_p2() {
    mul_ln1118_11_fu_21939_p2 = (!mul_ln1118_11_fu_21939_p0.read().is_01() || !mul_ln1118_11_fu_21939_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_11_fu_21939_p0.read()) * sc_bigint<5>(mul_ln1118_11_fu_21939_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1200_fu_56923_p0() {
    mul_ln1118_1200_fu_56923_p0 =  (sc_lv<3>) (sext_ln1116_200_fu_28969_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1200_fu_56923_p1() {
    mul_ln1118_1200_fu_56923_p1 = tmp_1200_fu_56909_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1200_fu_56923_p2() {
    mul_ln1118_1200_fu_56923_p2 = (!mul_ln1118_1200_fu_56923_p0.read().is_01() || !mul_ln1118_1200_fu_56923_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1200_fu_56923_p0.read()) * sc_bigint<5>(mul_ln1118_1200_fu_56923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1201_fu_56955_p0() {
    mul_ln1118_1201_fu_56955_p0 =  (sc_lv<3>) (sext_ln1116_201_fu_29013_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1201_fu_56955_p1() {
    mul_ln1118_1201_fu_56955_p1 = tmp_1201_fu_56941_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1201_fu_56955_p2() {
    mul_ln1118_1201_fu_56955_p2 = (!mul_ln1118_1201_fu_56955_p0.read().is_01() || !mul_ln1118_1201_fu_56955_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1201_fu_56955_p0.read()) * sc_bigint<5>(mul_ln1118_1201_fu_56955_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1202_fu_92944_p0() {
    mul_ln1118_1202_fu_92944_p0 =  (sc_lv<3>) (sext_ln1116_202_reg_106753.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1202_fu_92944_p1() {
    mul_ln1118_1202_fu_92944_p1 = tmp_1202_reg_110036.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1202_fu_92944_p2() {
    mul_ln1118_1202_fu_92944_p2 = (!mul_ln1118_1202_fu_92944_p0.read().is_01() || !mul_ln1118_1202_fu_92944_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1202_fu_92944_p0.read()) * sc_bigint<5>(mul_ln1118_1202_fu_92944_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1203_fu_56997_p0() {
    mul_ln1118_1203_fu_56997_p0 =  (sc_lv<3>) (sext_ln1116_203_fu_29079_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1203_fu_56997_p1() {
    mul_ln1118_1203_fu_56997_p1 = tmp_1203_fu_56983_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1203_fu_56997_p2() {
    mul_ln1118_1203_fu_56997_p2 = (!mul_ln1118_1203_fu_56997_p0.read().is_01() || !mul_ln1118_1203_fu_56997_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1203_fu_56997_p0.read()) * sc_bigint<5>(mul_ln1118_1203_fu_56997_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1204_fu_57029_p0() {
    mul_ln1118_1204_fu_57029_p0 =  (sc_lv<3>) (sext_ln1116_204_fu_29123_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1204_fu_57029_p1() {
    mul_ln1118_1204_fu_57029_p1 = tmp_1204_fu_57015_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1204_fu_57029_p2() {
    mul_ln1118_1204_fu_57029_p2 = (!mul_ln1118_1204_fu_57029_p0.read().is_01() || !mul_ln1118_1204_fu_57029_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1204_fu_57029_p0.read()) * sc_bigint<5>(mul_ln1118_1204_fu_57029_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1205_fu_57061_p0() {
    mul_ln1118_1205_fu_57061_p0 =  (sc_lv<3>) (sext_ln1116_205_fu_29167_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1205_fu_57061_p1() {
    mul_ln1118_1205_fu_57061_p1 = tmp_1205_fu_57047_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1205_fu_57061_p2() {
    mul_ln1118_1205_fu_57061_p2 = (!mul_ln1118_1205_fu_57061_p0.read().is_01() || !mul_ln1118_1205_fu_57061_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1205_fu_57061_p0.read()) * sc_bigint<5>(mul_ln1118_1205_fu_57061_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1206_fu_57093_p0() {
    mul_ln1118_1206_fu_57093_p0 =  (sc_lv<3>) (sext_ln1116_206_fu_29211_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1206_fu_57093_p1() {
    mul_ln1118_1206_fu_57093_p1 = tmp_1206_fu_57079_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1206_fu_57093_p2() {
    mul_ln1118_1206_fu_57093_p2 = (!mul_ln1118_1206_fu_57093_p0.read().is_01() || !mul_ln1118_1206_fu_57093_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1206_fu_57093_p0.read()) * sc_bigint<5>(mul_ln1118_1206_fu_57093_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1207_fu_57125_p0() {
    mul_ln1118_1207_fu_57125_p0 =  (sc_lv<3>) (sext_ln1116_207_fu_29255_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1207_fu_57125_p1() {
    mul_ln1118_1207_fu_57125_p1 = tmp_1207_fu_57111_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1207_fu_57125_p2() {
    mul_ln1118_1207_fu_57125_p2 = (!mul_ln1118_1207_fu_57125_p0.read().is_01() || !mul_ln1118_1207_fu_57125_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1207_fu_57125_p0.read()) * sc_bigint<5>(mul_ln1118_1207_fu_57125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1208_fu_57157_p0() {
    mul_ln1118_1208_fu_57157_p0 =  (sc_lv<3>) (sext_ln1116_208_fu_29299_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1208_fu_57157_p1() {
    mul_ln1118_1208_fu_57157_p1 = tmp_1208_fu_57143_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1208_fu_57157_p2() {
    mul_ln1118_1208_fu_57157_p2 = (!mul_ln1118_1208_fu_57157_p0.read().is_01() || !mul_ln1118_1208_fu_57157_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1208_fu_57157_p0.read()) * sc_bigint<5>(mul_ln1118_1208_fu_57157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1209_fu_57603_p0() {
    mul_ln1118_1209_fu_57603_p0 =  (sc_lv<3>) (sext_ln1116_fu_21855_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1209_fu_57603_p1() {
    mul_ln1118_1209_fu_57603_p1 = tmp_1209_fu_57589_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1209_fu_57603_p2() {
    mul_ln1118_1209_fu_57603_p2 = (!mul_ln1118_1209_fu_57603_p0.read().is_01() || !mul_ln1118_1209_fu_57603_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1209_fu_57603_p0.read()) * sc_bigint<5>(mul_ln1118_1209_fu_57603_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_120_fu_25987_p0() {
    mul_ln1118_120_fu_25987_p0 =  (sc_lv<3>) (sext_ln1116_120_fu_25979_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_120_fu_25987_p1() {
    mul_ln1118_120_fu_25987_p1 = tmp_120_fu_25969_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_120_fu_25987_p2() {
    mul_ln1118_120_fu_25987_p2 = (!mul_ln1118_120_fu_25987_p0.read().is_01() || !mul_ln1118_120_fu_25987_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_120_fu_25987_p0.read()) * sc_bigint<5>(mul_ln1118_120_fu_25987_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1210_fu_57623_p0() {
    mul_ln1118_1210_fu_57623_p0 =  (sc_lv<3>) (sext_ln1116_10_fu_21887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1210_fu_57623_p1() {
    mul_ln1118_1210_fu_57623_p1 = tmp_1210_fu_57609_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1210_fu_57623_p2() {
    mul_ln1118_1210_fu_57623_p2 = (!mul_ln1118_1210_fu_57623_p0.read().is_01() || !mul_ln1118_1210_fu_57623_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1210_fu_57623_p0.read()) * sc_bigint<5>(mul_ln1118_1210_fu_57623_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1211_fu_57655_p0() {
    mul_ln1118_1211_fu_57655_p0 =  (sc_lv<3>) (sext_ln1116_11_fu_21931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1211_fu_57655_p1() {
    mul_ln1118_1211_fu_57655_p1 = tmp_1211_fu_57641_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1211_fu_57655_p2() {
    mul_ln1118_1211_fu_57655_p2 = (!mul_ln1118_1211_fu_57655_p0.read().is_01() || !mul_ln1118_1211_fu_57655_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1211_fu_57655_p0.read()) * sc_bigint<5>(mul_ln1118_1211_fu_57655_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1212_fu_57687_p0() {
    mul_ln1118_1212_fu_57687_p0 =  (sc_lv<3>) (sext_ln1116_12_fu_21975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1212_fu_57687_p1() {
    mul_ln1118_1212_fu_57687_p1 = tmp_1212_fu_57673_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1212_fu_57687_p2() {
    mul_ln1118_1212_fu_57687_p2 = (!mul_ln1118_1212_fu_57687_p0.read().is_01() || !mul_ln1118_1212_fu_57687_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1212_fu_57687_p0.read()) * sc_bigint<5>(mul_ln1118_1212_fu_57687_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1213_fu_57707_p0() {
    mul_ln1118_1213_fu_57707_p0 =  (sc_lv<3>) (sext_ln1116_13_fu_22007_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1213_fu_57707_p1() {
    mul_ln1118_1213_fu_57707_p1 = tmp_1213_fu_57693_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1213_fu_57707_p2() {
    mul_ln1118_1213_fu_57707_p2 = (!mul_ln1118_1213_fu_57707_p0.read().is_01() || !mul_ln1118_1213_fu_57707_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1213_fu_57707_p0.read()) * sc_bigint<5>(mul_ln1118_1213_fu_57707_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1214_fu_57739_p0() {
    mul_ln1118_1214_fu_57739_p0 =  (sc_lv<3>) (sext_ln1116_14_fu_22051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1214_fu_57739_p1() {
    mul_ln1118_1214_fu_57739_p1 = tmp_1214_fu_57725_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1214_fu_57739_p2() {
    mul_ln1118_1214_fu_57739_p2 = (!mul_ln1118_1214_fu_57739_p0.read().is_01() || !mul_ln1118_1214_fu_57739_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1214_fu_57739_p0.read()) * sc_bigint<5>(mul_ln1118_1214_fu_57739_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1215_fu_94187_p0() {
    mul_ln1118_1215_fu_94187_p0 =  (sc_lv<3>) (sext_ln1116_15_fu_80033_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1215_fu_94187_p1() {
    mul_ln1118_1215_fu_94187_p1 = tmp_1215_reg_110396.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1215_fu_94187_p2() {
    mul_ln1118_1215_fu_94187_p2 = (!mul_ln1118_1215_fu_94187_p0.read().is_01() || !mul_ln1118_1215_fu_94187_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1215_fu_94187_p0.read()) * sc_bigint<5>(mul_ln1118_1215_fu_94187_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1216_fu_57781_p0() {
    mul_ln1118_1216_fu_57781_p0 =  (sc_lv<3>) (sext_ln1116_16_fu_22113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1216_fu_57781_p1() {
    mul_ln1118_1216_fu_57781_p1 = tmp_1216_fu_57767_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1216_fu_57781_p2() {
    mul_ln1118_1216_fu_57781_p2 = (!mul_ln1118_1216_fu_57781_p0.read().is_01() || !mul_ln1118_1216_fu_57781_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1216_fu_57781_p0.read()) * sc_bigint<5>(mul_ln1118_1216_fu_57781_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1217_fu_57813_p0() {
    mul_ln1118_1217_fu_57813_p0 =  (sc_lv<3>) (sext_ln1116_17_fu_22157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1217_fu_57813_p1() {
    mul_ln1118_1217_fu_57813_p1 = tmp_1217_fu_57799_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1217_fu_57813_p2() {
    mul_ln1118_1217_fu_57813_p2 = (!mul_ln1118_1217_fu_57813_p0.read().is_01() || !mul_ln1118_1217_fu_57813_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1217_fu_57813_p0.read()) * sc_bigint<5>(mul_ln1118_1217_fu_57813_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1218_fu_94208_p0() {
    mul_ln1118_1218_fu_94208_p0 =  (sc_lv<3>) (sext_ln1116_18_fu_80057_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1218_fu_94208_p1() {
    mul_ln1118_1218_fu_94208_p1 = tmp_1218_reg_110401.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1218_fu_94208_p2() {
    mul_ln1118_1218_fu_94208_p2 = (!mul_ln1118_1218_fu_94208_p0.read().is_01() || !mul_ln1118_1218_fu_94208_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1218_fu_94208_p0.read()) * sc_bigint<5>(mul_ln1118_1218_fu_94208_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1219_fu_57855_p0() {
    mul_ln1118_1219_fu_57855_p0 =  (sc_lv<3>) (sext_ln1116_19_fu_22219_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1219_fu_57855_p1() {
    mul_ln1118_1219_fu_57855_p1 = tmp_1219_fu_57841_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1219_fu_57855_p2() {
    mul_ln1118_1219_fu_57855_p2 = (!mul_ln1118_1219_fu_57855_p0.read().is_01() || !mul_ln1118_1219_fu_57855_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1219_fu_57855_p0.read()) * sc_bigint<5>(mul_ln1118_1219_fu_57855_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_121_fu_80710_p0() {
    mul_ln1118_121_fu_80710_p0 =  (sc_lv<3>) (sext_ln1116_121_reg_106395.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_121_fu_80710_p1() {
    mul_ln1118_121_fu_80710_p1 = tmp_121_reg_106390.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_121_fu_80710_p2() {
    mul_ln1118_121_fu_80710_p2 = (!mul_ln1118_121_fu_80710_p0.read().is_01() || !mul_ln1118_121_fu_80710_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_121_fu_80710_p0.read()) * sc_bigint<5>(mul_ln1118_121_fu_80710_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1220_fu_57887_p0() {
    mul_ln1118_1220_fu_57887_p0 =  (sc_lv<3>) (sext_ln1116_20_fu_22263_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1220_fu_57887_p1() {
    mul_ln1118_1220_fu_57887_p1 = tmp_1220_fu_57873_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1220_fu_57887_p2() {
    mul_ln1118_1220_fu_57887_p2 = (!mul_ln1118_1220_fu_57887_p0.read().is_01() || !mul_ln1118_1220_fu_57887_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1220_fu_57887_p0.read()) * sc_bigint<5>(mul_ln1118_1220_fu_57887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1221_fu_94229_p0() {
    mul_ln1118_1221_fu_94229_p0 =  (sc_lv<3>) (sext_ln1116_21_fu_80081_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1221_fu_94229_p1() {
    mul_ln1118_1221_fu_94229_p1 = tmp_1221_reg_110406.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1221_fu_94229_p2() {
    mul_ln1118_1221_fu_94229_p2 = (!mul_ln1118_1221_fu_94229_p0.read().is_01() || !mul_ln1118_1221_fu_94229_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1221_fu_94229_p0.read()) * sc_bigint<5>(mul_ln1118_1221_fu_94229_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1222_fu_57929_p0() {
    mul_ln1118_1222_fu_57929_p0 =  (sc_lv<3>) (sext_ln1116_22_fu_22325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1222_fu_57929_p1() {
    mul_ln1118_1222_fu_57929_p1 = tmp_1222_fu_57915_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1222_fu_57929_p2() {
    mul_ln1118_1222_fu_57929_p2 = (!mul_ln1118_1222_fu_57929_p0.read().is_01() || !mul_ln1118_1222_fu_57929_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1222_fu_57929_p0.read()) * sc_bigint<5>(mul_ln1118_1222_fu_57929_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1223_fu_57961_p0() {
    mul_ln1118_1223_fu_57961_p0 =  (sc_lv<3>) (sext_ln1116_23_fu_22369_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1223_fu_57961_p1() {
    mul_ln1118_1223_fu_57961_p1 = tmp_1223_fu_57947_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1223_fu_57961_p2() {
    mul_ln1118_1223_fu_57961_p2 = (!mul_ln1118_1223_fu_57961_p0.read().is_01() || !mul_ln1118_1223_fu_57961_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1223_fu_57961_p0.read()) * sc_bigint<5>(mul_ln1118_1223_fu_57961_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1224_fu_94250_p0() {
    mul_ln1118_1224_fu_94250_p0 =  (sc_lv<3>) (sext_ln1116_24_fu_80105_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1224_fu_94250_p1() {
    mul_ln1118_1224_fu_94250_p1 = tmp_1224_reg_110411.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1224_fu_94250_p2() {
    mul_ln1118_1224_fu_94250_p2 = (!mul_ln1118_1224_fu_94250_p0.read().is_01() || !mul_ln1118_1224_fu_94250_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1224_fu_94250_p0.read()) * sc_bigint<5>(mul_ln1118_1224_fu_94250_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1225_fu_58003_p0() {
    mul_ln1118_1225_fu_58003_p0 =  (sc_lv<3>) (sext_ln1116_25_fu_22431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1225_fu_58003_p1() {
    mul_ln1118_1225_fu_58003_p1 = tmp_1225_fu_57989_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1225_fu_58003_p2() {
    mul_ln1118_1225_fu_58003_p2 = (!mul_ln1118_1225_fu_58003_p0.read().is_01() || !mul_ln1118_1225_fu_58003_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1225_fu_58003_p0.read()) * sc_bigint<5>(mul_ln1118_1225_fu_58003_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1226_fu_58035_p0() {
    mul_ln1118_1226_fu_58035_p0 =  (sc_lv<3>) (sext_ln1116_26_fu_22475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1226_fu_58035_p1() {
    mul_ln1118_1226_fu_58035_p1 = tmp_1226_fu_58021_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1226_fu_58035_p2() {
    mul_ln1118_1226_fu_58035_p2 = (!mul_ln1118_1226_fu_58035_p0.read().is_01() || !mul_ln1118_1226_fu_58035_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1226_fu_58035_p0.read()) * sc_bigint<5>(mul_ln1118_1226_fu_58035_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1227_fu_94271_p0() {
    mul_ln1118_1227_fu_94271_p0 =  (sc_lv<3>) (sext_ln1116_27_fu_80129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1227_fu_94271_p1() {
    mul_ln1118_1227_fu_94271_p1 = tmp_1227_reg_110416.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1227_fu_94271_p2() {
    mul_ln1118_1227_fu_94271_p2 = (!mul_ln1118_1227_fu_94271_p0.read().is_01() || !mul_ln1118_1227_fu_94271_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1227_fu_94271_p0.read()) * sc_bigint<5>(mul_ln1118_1227_fu_94271_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1228_fu_58077_p0() {
    mul_ln1118_1228_fu_58077_p0 =  (sc_lv<3>) (sext_ln1116_28_fu_22537_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1228_fu_58077_p1() {
    mul_ln1118_1228_fu_58077_p1 = tmp_1228_fu_58063_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1228_fu_58077_p2() {
    mul_ln1118_1228_fu_58077_p2 = (!mul_ln1118_1228_fu_58077_p0.read().is_01() || !mul_ln1118_1228_fu_58077_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1228_fu_58077_p0.read()) * sc_bigint<5>(mul_ln1118_1228_fu_58077_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1229_fu_58109_p0() {
    mul_ln1118_1229_fu_58109_p0 =  (sc_lv<3>) (sext_ln1116_29_fu_22581_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1229_fu_58109_p1() {
    mul_ln1118_1229_fu_58109_p1 = tmp_1229_fu_58095_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1229_fu_58109_p2() {
    mul_ln1118_1229_fu_58109_p2 = (!mul_ln1118_1229_fu_58109_p0.read().is_01() || !mul_ln1118_1229_fu_58109_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1229_fu_58109_p0.read()) * sc_bigint<5>(mul_ln1118_1229_fu_58109_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_122_fu_26053_p0() {
    mul_ln1118_122_fu_26053_p0 =  (sc_lv<3>) (sext_ln1116_122_fu_26045_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_122_fu_26053_p1() {
    mul_ln1118_122_fu_26053_p1 = tmp_122_fu_26035_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_122_fu_26053_p2() {
    mul_ln1118_122_fu_26053_p2 = (!mul_ln1118_122_fu_26053_p0.read().is_01() || !mul_ln1118_122_fu_26053_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_122_fu_26053_p0.read()) * sc_bigint<5>(mul_ln1118_122_fu_26053_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1230_fu_58141_p0() {
    mul_ln1118_1230_fu_58141_p0 =  (sc_lv<3>) (sext_ln1116_30_fu_22625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1230_fu_58141_p1() {
    mul_ln1118_1230_fu_58141_p1 = tmp_1230_fu_58127_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1230_fu_58141_p2() {
    mul_ln1118_1230_fu_58141_p2 = (!mul_ln1118_1230_fu_58141_p0.read().is_01() || !mul_ln1118_1230_fu_58141_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1230_fu_58141_p0.read()) * sc_bigint<5>(mul_ln1118_1230_fu_58141_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1231_fu_58173_p0() {
    mul_ln1118_1231_fu_58173_p0 =  (sc_lv<3>) (sext_ln1116_31_fu_22669_p1.read());
}

}

