#include "dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_270_fu_57626_p4() {
    trunc_ln708_270_fu_57626_p4 = mul_ln1118_252_fu_57621_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_277_fu_57645_p4() {
    trunc_ln708_277_fu_57645_p4 = mul_ln1118_259_fu_57639_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_278_fu_57664_p4() {
    trunc_ln708_278_fu_57664_p4 = mul_ln1118_260_fu_57658_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_279_fu_57683_p4() {
    trunc_ln708_279_fu_57683_p4 = mul_ln1118_261_fu_57677_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_280_fu_57702_p4() {
    trunc_ln708_280_fu_57702_p4 = mul_ln1118_262_fu_57696_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_281_fu_57721_p4() {
    trunc_ln708_281_fu_57721_p4 = mul_ln1118_263_fu_57715_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_282_fu_57740_p4() {
    trunc_ln708_282_fu_57740_p4 = mul_ln1118_264_fu_57734_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_283_fu_57759_p4() {
    trunc_ln708_283_fu_57759_p4 = mul_ln1118_265_fu_57753_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_284_fu_57778_p4() {
    trunc_ln708_284_fu_57778_p4 = mul_ln1118_266_fu_57772_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_285_fu_57797_p4() {
    trunc_ln708_285_fu_57797_p4 = mul_ln1118_267_fu_57791_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_286_fu_57816_p4() {
    trunc_ln708_286_fu_57816_p4 = mul_ln1118_268_fu_57810_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_287_fu_57835_p4() {
    trunc_ln708_287_fu_57835_p4 = mul_ln1118_269_fu_57829_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_288_fu_57854_p4() {
    trunc_ln708_288_fu_57854_p4 = mul_ln1118_270_fu_57848_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_289_fu_57873_p4() {
    trunc_ln708_289_fu_57873_p4 = mul_ln1118_271_fu_57867_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_290_fu_57892_p4() {
    trunc_ln708_290_fu_57892_p4 = mul_ln1118_272_fu_57886_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_291_fu_57911_p4() {
    trunc_ln708_291_fu_57911_p4 = mul_ln1118_273_fu_57905_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_292_fu_57930_p4() {
    trunc_ln708_292_fu_57930_p4 = mul_ln1118_274_fu_57924_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_293_fu_57949_p4() {
    trunc_ln708_293_fu_57949_p4 = mul_ln1118_275_fu_57943_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_294_fu_57968_p4() {
    trunc_ln708_294_fu_57968_p4 = mul_ln1118_276_fu_57962_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_295_fu_57986_p4() {
    trunc_ln708_295_fu_57986_p4 = mul_ln1118_277_fu_57981_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_29_fu_52587_p4() {
    trunc_ln708_29_fu_52587_p4 = mul_ln1118_11_fu_52581_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_302_fu_58005_p4() {
    trunc_ln708_302_fu_58005_p4 = mul_ln1118_284_fu_57999_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_303_fu_58024_p4() {
    trunc_ln708_303_fu_58024_p4 = mul_ln1118_285_fu_58018_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_304_fu_58043_p4() {
    trunc_ln708_304_fu_58043_p4 = mul_ln1118_286_fu_58037_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_305_fu_58062_p4() {
    trunc_ln708_305_fu_58062_p4 = mul_ln1118_287_fu_58056_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_306_fu_58081_p4() {
    trunc_ln708_306_fu_58081_p4 = mul_ln1118_288_fu_58075_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_307_fu_58100_p4() {
    trunc_ln708_307_fu_58100_p4 = mul_ln1118_289_fu_58094_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_308_fu_58119_p4() {
    trunc_ln708_308_fu_58119_p4 = mul_ln1118_290_fu_58113_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_309_fu_58138_p4() {
    trunc_ln708_309_fu_58138_p4 = mul_ln1118_291_fu_58132_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_30_fu_52609_p4() {
    trunc_ln708_30_fu_52609_p4 = mul_ln1118_12_fu_52603_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_310_fu_58157_p4() {
    trunc_ln708_310_fu_58157_p4 = mul_ln1118_292_fu_58151_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_311_fu_58176_p4() {
    trunc_ln708_311_fu_58176_p4 = mul_ln1118_293_fu_58170_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_312_fu_58195_p4() {
    trunc_ln708_312_fu_58195_p4 = mul_ln1118_294_fu_58189_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_313_fu_58214_p4() {
    trunc_ln708_313_fu_58214_p4 = mul_ln1118_295_fu_58208_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_314_fu_58233_p4() {
    trunc_ln708_314_fu_58233_p4 = mul_ln1118_296_fu_58227_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_315_fu_58252_p4() {
    trunc_ln708_315_fu_58252_p4 = mul_ln1118_297_fu_58246_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_316_fu_58271_p4() {
    trunc_ln708_316_fu_58271_p4 = mul_ln1118_298_fu_58265_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_317_fu_58290_p4() {
    trunc_ln708_317_fu_58290_p4 = mul_ln1118_299_fu_58284_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_318_fu_58309_p4() {
    trunc_ln708_318_fu_58309_p4 = mul_ln1118_300_fu_58303_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_319_fu_58328_p4() {
    trunc_ln708_319_fu_58328_p4 = mul_ln1118_301_fu_58322_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_31_fu_52631_p4() {
    trunc_ln708_31_fu_52631_p4 = mul_ln1118_13_fu_52625_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_320_fu_58346_p4() {
    trunc_ln708_320_fu_58346_p4 = mul_ln1118_302_fu_58341_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_327_fu_58365_p4() {
    trunc_ln708_327_fu_58365_p4 = mul_ln1118_309_fu_58359_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_328_fu_58384_p4() {
    trunc_ln708_328_fu_58384_p4 = mul_ln1118_310_fu_58378_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_329_fu_58403_p4() {
    trunc_ln708_329_fu_58403_p4 = mul_ln1118_311_fu_58397_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_32_fu_52653_p4() {
    trunc_ln708_32_fu_52653_p4 = mul_ln1118_14_fu_52647_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_330_fu_58422_p4() {
    trunc_ln708_330_fu_58422_p4 = mul_ln1118_312_fu_58416_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_331_fu_58441_p4() {
    trunc_ln708_331_fu_58441_p4 = mul_ln1118_313_fu_58435_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_332_fu_58460_p4() {
    trunc_ln708_332_fu_58460_p4 = mul_ln1118_314_fu_58454_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_333_fu_58479_p4() {
    trunc_ln708_333_fu_58479_p4 = mul_ln1118_315_fu_58473_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_334_fu_58498_p4() {
    trunc_ln708_334_fu_58498_p4 = mul_ln1118_316_fu_58492_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_335_fu_58517_p4() {
    trunc_ln708_335_fu_58517_p4 = mul_ln1118_317_fu_58511_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_336_fu_58536_p4() {
    trunc_ln708_336_fu_58536_p4 = mul_ln1118_318_fu_58530_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_337_fu_58555_p4() {
    trunc_ln708_337_fu_58555_p4 = mul_ln1118_319_fu_58549_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_338_fu_58574_p4() {
    trunc_ln708_338_fu_58574_p4 = mul_ln1118_320_fu_58568_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_339_fu_58593_p4() {
    trunc_ln708_339_fu_58593_p4 = mul_ln1118_321_fu_58587_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_33_fu_52675_p4() {
    trunc_ln708_33_fu_52675_p4 = mul_ln1118_15_fu_52669_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_340_fu_58612_p4() {
    trunc_ln708_340_fu_58612_p4 = mul_ln1118_322_fu_58606_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_341_fu_58631_p4() {
    trunc_ln708_341_fu_58631_p4 = mul_ln1118_323_fu_58625_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_342_fu_58650_p4() {
    trunc_ln708_342_fu_58650_p4 = mul_ln1118_324_fu_58644_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_343_fu_58669_p4() {
    trunc_ln708_343_fu_58669_p4 = mul_ln1118_325_fu_58663_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_344_fu_58688_p4() {
    trunc_ln708_344_fu_58688_p4 = mul_ln1118_326_fu_58682_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_345_fu_58707_p4() {
    trunc_ln708_345_fu_58707_p4 = mul_ln1118_327_fu_58701_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_346_fu_58726_p4() {
    trunc_ln708_346_fu_58726_p4 = mul_ln1118_328_fu_58720_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_347_fu_58745_p4() {
    trunc_ln708_347_fu_58745_p4 = mul_ln1118_329_fu_58739_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_348_fu_58764_p4() {
    trunc_ln708_348_fu_58764_p4 = mul_ln1118_330_fu_58758_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_349_fu_58783_p4() {
    trunc_ln708_349_fu_58783_p4 = mul_ln1118_331_fu_58777_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_34_fu_52697_p4() {
    trunc_ln708_34_fu_52697_p4 = mul_ln1118_16_fu_52691_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_352_fu_58802_p4() {
    trunc_ln708_352_fu_58802_p4 = mul_ln1118_334_fu_58796_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_353_fu_58821_p4() {
    trunc_ln708_353_fu_58821_p4 = mul_ln1118_335_fu_58815_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_354_fu_58840_p4() {
    trunc_ln708_354_fu_58840_p4 = mul_ln1118_336_fu_58834_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_355_fu_58859_p4() {
    trunc_ln708_355_fu_58859_p4 = mul_ln1118_337_fu_58853_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_356_fu_58878_p4() {
    trunc_ln708_356_fu_58878_p4 = mul_ln1118_338_fu_58872_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_357_fu_58897_p4() {
    trunc_ln708_357_fu_58897_p4 = mul_ln1118_339_fu_58891_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_358_fu_58916_p4() {
    trunc_ln708_358_fu_58916_p4 = mul_ln1118_340_fu_58910_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_359_fu_58935_p4() {
    trunc_ln708_359_fu_58935_p4 = mul_ln1118_341_fu_58929_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_35_fu_52719_p4() {
    trunc_ln708_35_fu_52719_p4 = mul_ln1118_17_fu_52713_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_360_fu_58954_p4() {
    trunc_ln708_360_fu_58954_p4 = mul_ln1118_342_fu_58948_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_361_fu_58973_p4() {
    trunc_ln708_361_fu_58973_p4 = mul_ln1118_343_fu_58967_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_362_fu_58992_p4() {
    trunc_ln708_362_fu_58992_p4 = mul_ln1118_344_fu_58986_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_363_fu_59011_p4() {
    trunc_ln708_363_fu_59011_p4 = mul_ln1118_345_fu_59005_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_364_fu_59030_p4() {
    trunc_ln708_364_fu_59030_p4 = mul_ln1118_346_fu_59024_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_365_fu_59049_p4() {
    trunc_ln708_365_fu_59049_p4 = mul_ln1118_347_fu_59043_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_366_fu_59068_p4() {
    trunc_ln708_366_fu_59068_p4 = mul_ln1118_348_fu_59062_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_367_fu_59087_p4() {
    trunc_ln708_367_fu_59087_p4 = mul_ln1118_349_fu_59081_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_368_fu_59106_p4() {
    trunc_ln708_368_fu_59106_p4 = mul_ln1118_350_fu_59100_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_369_fu_59124_p4() {
    trunc_ln708_369_fu_59124_p4 = mul_ln1118_351_fu_59119_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_36_fu_52741_p4() {
    trunc_ln708_36_fu_52741_p4 = mul_ln1118_18_fu_52735_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_370_fu_59142_p4() {
    trunc_ln708_370_fu_59142_p4 = mul_ln1118_352_fu_59137_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_377_fu_59161_p4() {
    trunc_ln708_377_fu_59161_p4 = mul_ln1118_359_fu_59155_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_378_fu_59180_p4() {
    trunc_ln708_378_fu_59180_p4 = mul_ln1118_360_fu_59174_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_379_fu_59199_p4() {
    trunc_ln708_379_fu_59199_p4 = mul_ln1118_361_fu_59193_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_37_fu_52763_p4() {
    trunc_ln708_37_fu_52763_p4 = mul_ln1118_19_fu_52757_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_380_fu_59218_p4() {
    trunc_ln708_380_fu_59218_p4 = mul_ln1118_362_fu_59212_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_381_fu_59237_p4() {
    trunc_ln708_381_fu_59237_p4 = mul_ln1118_363_fu_59231_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_382_fu_59256_p4() {
    trunc_ln708_382_fu_59256_p4 = mul_ln1118_364_fu_59250_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_383_fu_59275_p4() {
    trunc_ln708_383_fu_59275_p4 = mul_ln1118_365_fu_59269_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_384_fu_59294_p4() {
    trunc_ln708_384_fu_59294_p4 = mul_ln1118_366_fu_59288_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_385_fu_59313_p4() {
    trunc_ln708_385_fu_59313_p4 = mul_ln1118_367_fu_59307_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_386_fu_59332_p4() {
    trunc_ln708_386_fu_59332_p4 = mul_ln1118_368_fu_59326_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_387_fu_59351_p4() {
    trunc_ln708_387_fu_59351_p4 = mul_ln1118_369_fu_59345_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_388_fu_59370_p4() {
    trunc_ln708_388_fu_59370_p4 = mul_ln1118_370_fu_59364_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_389_fu_59389_p4() {
    trunc_ln708_389_fu_59389_p4 = mul_ln1118_371_fu_59383_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_38_fu_52785_p4() {
    trunc_ln708_38_fu_52785_p4 = mul_ln1118_20_fu_52779_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_390_fu_59408_p4() {
    trunc_ln708_390_fu_59408_p4 = mul_ln1118_372_fu_59402_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_391_fu_59427_p4() {
    trunc_ln708_391_fu_59427_p4 = mul_ln1118_373_fu_59421_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_392_fu_59446_p4() {
    trunc_ln708_392_fu_59446_p4 = mul_ln1118_374_fu_59440_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_393_fu_59465_p4() {
    trunc_ln708_393_fu_59465_p4 = mul_ln1118_375_fu_59459_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_394_fu_59483_p4() {
    trunc_ln708_394_fu_59483_p4 = mul_ln1118_376_fu_59478_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_395_fu_59501_p4() {
    trunc_ln708_395_fu_59501_p4 = mul_ln1118_377_fu_59496_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_39_fu_52807_p4() {
    trunc_ln708_39_fu_52807_p4 = mul_ln1118_21_fu_52801_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_402_fu_59520_p4() {
    trunc_ln708_402_fu_59520_p4 = mul_ln1118_384_fu_59514_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_403_fu_59539_p4() {
    trunc_ln708_403_fu_59539_p4 = mul_ln1118_385_fu_59533_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_404_fu_59558_p4() {
    trunc_ln708_404_fu_59558_p4 = mul_ln1118_386_fu_59552_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_405_fu_59577_p4() {
    trunc_ln708_405_fu_59577_p4 = mul_ln1118_387_fu_59571_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_406_fu_59596_p4() {
    trunc_ln708_406_fu_59596_p4 = mul_ln1118_388_fu_59590_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_407_fu_59615_p4() {
    trunc_ln708_407_fu_59615_p4 = mul_ln1118_389_fu_59609_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_408_fu_59634_p4() {
    trunc_ln708_408_fu_59634_p4 = mul_ln1118_390_fu_59628_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_409_fu_59653_p4() {
    trunc_ln708_409_fu_59653_p4 = mul_ln1118_391_fu_59647_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_40_fu_52829_p4() {
    trunc_ln708_40_fu_52829_p4 = mul_ln1118_22_fu_52823_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_410_fu_59672_p4() {
    trunc_ln708_410_fu_59672_p4 = mul_ln1118_392_fu_59666_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_411_fu_59691_p4() {
    trunc_ln708_411_fu_59691_p4 = mul_ln1118_393_fu_59685_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_412_fu_59710_p4() {
    trunc_ln708_412_fu_59710_p4 = mul_ln1118_394_fu_59704_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_413_fu_59729_p4() {
    trunc_ln708_413_fu_59729_p4 = mul_ln1118_395_fu_59723_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_414_fu_59748_p4() {
    trunc_ln708_414_fu_59748_p4 = mul_ln1118_396_fu_59742_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_415_fu_59767_p4() {
    trunc_ln708_415_fu_59767_p4 = mul_ln1118_397_fu_59761_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_416_fu_59786_p4() {
    trunc_ln708_416_fu_59786_p4 = mul_ln1118_398_fu_59780_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_417_fu_59805_p4() {
    trunc_ln708_417_fu_59805_p4 = mul_ln1118_399_fu_59799_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_418_fu_59824_p4() {
    trunc_ln708_418_fu_59824_p4 = mul_ln1118_400_fu_59818_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_419_fu_59842_p4() {
    trunc_ln708_419_fu_59842_p4 = mul_ln1118_401_fu_59837_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_41_fu_52851_p4() {
    trunc_ln708_41_fu_52851_p4 = mul_ln1118_23_fu_52845_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_420_fu_59860_p4() {
    trunc_ln708_420_fu_59860_p4 = mul_ln1118_402_fu_59855_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_427_fu_60867_p4() {
    trunc_ln708_427_fu_60867_p4 = mul_ln1118_409_fu_60861_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_428_fu_60886_p4() {
    trunc_ln708_428_fu_60886_p4 = mul_ln1118_410_fu_60880_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_429_fu_60905_p4() {
    trunc_ln708_429_fu_60905_p4 = mul_ln1118_411_fu_60899_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_42_fu_52873_p4() {
    trunc_ln708_42_fu_52873_p4 = mul_ln1118_24_fu_52867_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_430_fu_60924_p4() {
    trunc_ln708_430_fu_60924_p4 = mul_ln1118_412_fu_60918_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_431_fu_60943_p4() {
    trunc_ln708_431_fu_60943_p4 = mul_ln1118_413_fu_60937_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_432_fu_60962_p4() {
    trunc_ln708_432_fu_60962_p4 = mul_ln1118_414_fu_60956_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_433_fu_60981_p4() {
    trunc_ln708_433_fu_60981_p4 = mul_ln1118_415_fu_60975_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_434_fu_61000_p4() {
    trunc_ln708_434_fu_61000_p4 = mul_ln1118_416_fu_60994_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_435_fu_61019_p4() {
    trunc_ln708_435_fu_61019_p4 = mul_ln1118_417_fu_61013_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_436_fu_61038_p4() {
    trunc_ln708_436_fu_61038_p4 = mul_ln1118_418_fu_61032_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_437_fu_61057_p4() {
    trunc_ln708_437_fu_61057_p4 = mul_ln1118_419_fu_61051_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_438_fu_61076_p4() {
    trunc_ln708_438_fu_61076_p4 = mul_ln1118_420_fu_61070_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_439_fu_61095_p4() {
    trunc_ln708_439_fu_61095_p4 = mul_ln1118_421_fu_61089_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_43_fu_52895_p4() {
    trunc_ln708_43_fu_52895_p4 = mul_ln1118_25_fu_52889_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_440_fu_61114_p4() {
    trunc_ln708_440_fu_61114_p4 = mul_ln1118_422_fu_61108_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_441_fu_61133_p4() {
    trunc_ln708_441_fu_61133_p4 = mul_ln1118_423_fu_61127_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_442_fu_61152_p4() {
    trunc_ln708_442_fu_61152_p4 = mul_ln1118_424_fu_61146_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_443_fu_61171_p4() {
    trunc_ln708_443_fu_61171_p4 = mul_ln1118_425_fu_61165_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_444_fu_61190_p4() {
    trunc_ln708_444_fu_61190_p4 = mul_ln1118_426_fu_61184_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_445_fu_61209_p4() {
    trunc_ln708_445_fu_61209_p4 = mul_ln1118_427_fu_61203_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_44_fu_52917_p4() {
    trunc_ln708_44_fu_52917_p4 = mul_ln1118_26_fu_52911_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_452_fu_61228_p4() {
    trunc_ln708_452_fu_61228_p4 = mul_ln1118_434_fu_61222_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_453_fu_61247_p4() {
    trunc_ln708_453_fu_61247_p4 = mul_ln1118_435_fu_61241_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_454_fu_61266_p4() {
    trunc_ln708_454_fu_61266_p4 = mul_ln1118_436_fu_61260_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_455_fu_61285_p4() {
    trunc_ln708_455_fu_61285_p4 = mul_ln1118_437_fu_61279_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_456_fu_61304_p4() {
    trunc_ln708_456_fu_61304_p4 = mul_ln1118_438_fu_61298_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_457_fu_61323_p4() {
    trunc_ln708_457_fu_61323_p4 = mul_ln1118_439_fu_61317_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_458_fu_61342_p4() {
    trunc_ln708_458_fu_61342_p4 = mul_ln1118_440_fu_61336_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_459_fu_61361_p4() {
    trunc_ln708_459_fu_61361_p4 = mul_ln1118_441_fu_61355_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_45_fu_52939_p4() {
    trunc_ln708_45_fu_52939_p4 = mul_ln1118_27_fu_52933_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_460_fu_61380_p4() {
    trunc_ln708_460_fu_61380_p4 = mul_ln1118_442_fu_61374_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_461_fu_61399_p4() {
    trunc_ln708_461_fu_61399_p4 = mul_ln1118_443_fu_61393_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_462_fu_61418_p4() {
    trunc_ln708_462_fu_61418_p4 = mul_ln1118_444_fu_61412_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_463_fu_61437_p4() {
    trunc_ln708_463_fu_61437_p4 = mul_ln1118_445_fu_61431_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_464_fu_61456_p4() {
    trunc_ln708_464_fu_61456_p4 = mul_ln1118_446_fu_61450_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_465_fu_61475_p4() {
    trunc_ln708_465_fu_61475_p4 = mul_ln1118_447_fu_61469_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_466_fu_61494_p4() {
    trunc_ln708_466_fu_61494_p4 = mul_ln1118_448_fu_61488_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_467_fu_61513_p4() {
    trunc_ln708_467_fu_61513_p4 = mul_ln1118_449_fu_61507_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_468_fu_61532_p4() {
    trunc_ln708_468_fu_61532_p4 = mul_ln1118_450_fu_61526_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_469_fu_61551_p4() {
    trunc_ln708_469_fu_61551_p4 = mul_ln1118_451_fu_61545_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_470_fu_61569_p4() {
    trunc_ln708_470_fu_61569_p4 = mul_ln1118_452_fu_61564_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_477_fu_61588_p4() {
    trunc_ln708_477_fu_61588_p4 = mul_ln1118_459_fu_61582_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_478_fu_61607_p4() {
    trunc_ln708_478_fu_61607_p4 = mul_ln1118_460_fu_61601_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_479_fu_61626_p4() {
    trunc_ln708_479_fu_61626_p4 = mul_ln1118_461_fu_61620_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_480_fu_61645_p4() {
    trunc_ln708_480_fu_61645_p4 = mul_ln1118_462_fu_61639_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_481_fu_61664_p4() {
    trunc_ln708_481_fu_61664_p4 = mul_ln1118_463_fu_61658_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_482_fu_61683_p4() {
    trunc_ln708_482_fu_61683_p4 = mul_ln1118_464_fu_61677_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_483_fu_61702_p4() {
    trunc_ln708_483_fu_61702_p4 = mul_ln1118_465_fu_61696_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_484_fu_61721_p4() {
    trunc_ln708_484_fu_61721_p4 = mul_ln1118_466_fu_61715_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_485_fu_61740_p4() {
    trunc_ln708_485_fu_61740_p4 = mul_ln1118_467_fu_61734_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_486_fu_61759_p4() {
    trunc_ln708_486_fu_61759_p4 = mul_ln1118_468_fu_61753_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_487_fu_61778_p4() {
    trunc_ln708_487_fu_61778_p4 = mul_ln1118_469_fu_61772_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_488_fu_61797_p4() {
    trunc_ln708_488_fu_61797_p4 = mul_ln1118_470_fu_61791_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_489_fu_61816_p4() {
    trunc_ln708_489_fu_61816_p4 = mul_ln1118_471_fu_61810_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_490_fu_61835_p4() {
    trunc_ln708_490_fu_61835_p4 = mul_ln1118_472_fu_61829_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_491_fu_61854_p4() {
    trunc_ln708_491_fu_61854_p4 = mul_ln1118_473_fu_61848_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_492_fu_61873_p4() {
    trunc_ln708_492_fu_61873_p4 = mul_ln1118_474_fu_61867_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_493_fu_61892_p4() {
    trunc_ln708_493_fu_61892_p4 = mul_ln1118_475_fu_61886_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_494_fu_61911_p4() {
    trunc_ln708_494_fu_61911_p4 = mul_ln1118_476_fu_61905_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_495_fu_61929_p4() {
    trunc_ln708_495_fu_61929_p4 = mul_ln1118_477_fu_61924_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_502_fu_61948_p4() {
    trunc_ln708_502_fu_61948_p4 = mul_ln1118_484_fu_61942_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_503_fu_61967_p4() {
    trunc_ln708_503_fu_61967_p4 = mul_ln1118_485_fu_61961_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_504_fu_61986_p4() {
    trunc_ln708_504_fu_61986_p4 = mul_ln1118_486_fu_61980_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_505_fu_62005_p4() {
    trunc_ln708_505_fu_62005_p4 = mul_ln1118_487_fu_61999_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_506_fu_62024_p4() {
    trunc_ln708_506_fu_62024_p4 = mul_ln1118_488_fu_62018_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_507_fu_62043_p4() {
    trunc_ln708_507_fu_62043_p4 = mul_ln1118_489_fu_62037_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_508_fu_62062_p4() {
    trunc_ln708_508_fu_62062_p4 = mul_ln1118_490_fu_62056_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_509_fu_62081_p4() {
    trunc_ln708_509_fu_62081_p4 = mul_ln1118_491_fu_62075_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_510_fu_62100_p4() {
    trunc_ln708_510_fu_62100_p4 = mul_ln1118_492_fu_62094_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_511_fu_62119_p4() {
    trunc_ln708_511_fu_62119_p4 = mul_ln1118_493_fu_62113_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_512_fu_62138_p4() {
    trunc_ln708_512_fu_62138_p4 = mul_ln1118_494_fu_62132_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_513_fu_62157_p4() {
    trunc_ln708_513_fu_62157_p4 = mul_ln1118_495_fu_62151_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_514_fu_62176_p4() {
    trunc_ln708_514_fu_62176_p4 = mul_ln1118_496_fu_62170_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_515_fu_62195_p4() {
    trunc_ln708_515_fu_62195_p4 = mul_ln1118_497_fu_62189_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_516_fu_62214_p4() {
    trunc_ln708_516_fu_62214_p4 = mul_ln1118_498_fu_62208_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_517_fu_62233_p4() {
    trunc_ln708_517_fu_62233_p4 = mul_ln1118_499_fu_62227_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_518_fu_62252_p4() {
    trunc_ln708_518_fu_62252_p4 = mul_ln1118_500_fu_62246_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_519_fu_62271_p4() {
    trunc_ln708_519_fu_62271_p4 = mul_ln1118_501_fu_62265_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_520_fu_62289_p4() {
    trunc_ln708_520_fu_62289_p4 = mul_ln1118_502_fu_62284_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_527_fu_62308_p4() {
    trunc_ln708_527_fu_62308_p4 = mul_ln1118_509_fu_62302_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_528_fu_62327_p4() {
    trunc_ln708_528_fu_62327_p4 = mul_ln1118_510_fu_62321_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_529_fu_62346_p4() {
    trunc_ln708_529_fu_62346_p4 = mul_ln1118_511_fu_62340_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_52_fu_52961_p4() {
    trunc_ln708_52_fu_52961_p4 = mul_ln1118_34_fu_52955_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_530_fu_62365_p4() {
    trunc_ln708_530_fu_62365_p4 = mul_ln1118_512_fu_62359_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_531_fu_62384_p4() {
    trunc_ln708_531_fu_62384_p4 = mul_ln1118_513_fu_62378_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_532_fu_62403_p4() {
    trunc_ln708_532_fu_62403_p4 = mul_ln1118_514_fu_62397_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_533_fu_62422_p4() {
    trunc_ln708_533_fu_62422_p4 = mul_ln1118_515_fu_62416_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_534_fu_62441_p4() {
    trunc_ln708_534_fu_62441_p4 = mul_ln1118_516_fu_62435_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_535_fu_62460_p4() {
    trunc_ln708_535_fu_62460_p4 = mul_ln1118_517_fu_62454_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_536_fu_62479_p4() {
    trunc_ln708_536_fu_62479_p4 = mul_ln1118_518_fu_62473_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_537_fu_62498_p4() {
    trunc_ln708_537_fu_62498_p4 = mul_ln1118_519_fu_62492_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_538_fu_62517_p4() {
    trunc_ln708_538_fu_62517_p4 = mul_ln1118_520_fu_62511_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_539_fu_62536_p4() {
    trunc_ln708_539_fu_62536_p4 = mul_ln1118_521_fu_62530_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_53_fu_52983_p4() {
    trunc_ln708_53_fu_52983_p4 = mul_ln1118_35_fu_52977_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_540_fu_62555_p4() {
    trunc_ln708_540_fu_62555_p4 = mul_ln1118_522_fu_62549_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_541_fu_62574_p4() {
    trunc_ln708_541_fu_62574_p4 = mul_ln1118_523_fu_62568_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_542_fu_62593_p4() {
    trunc_ln708_542_fu_62593_p4 = mul_ln1118_524_fu_62587_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_543_fu_62612_p4() {
    trunc_ln708_543_fu_62612_p4 = mul_ln1118_525_fu_62606_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_544_fu_62631_p4() {
    trunc_ln708_544_fu_62631_p4 = mul_ln1118_526_fu_62625_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_545_fu_62650_p4() {
    trunc_ln708_545_fu_62650_p4 = mul_ln1118_527_fu_62644_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_546_fu_62669_p4() {
    trunc_ln708_546_fu_62669_p4 = mul_ln1118_528_fu_62663_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_547_fu_62688_p4() {
    trunc_ln708_547_fu_62688_p4 = mul_ln1118_529_fu_62682_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_548_fu_62707_p4() {
    trunc_ln708_548_fu_62707_p4 = mul_ln1118_530_fu_62701_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_549_fu_62726_p4() {
    trunc_ln708_549_fu_62726_p4 = mul_ln1118_531_fu_62720_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_54_fu_53005_p4() {
    trunc_ln708_54_fu_53005_p4 = mul_ln1118_36_fu_52999_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_552_fu_62745_p4() {
    trunc_ln708_552_fu_62745_p4 = mul_ln1118_534_fu_62739_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_553_fu_62764_p4() {
    trunc_ln708_553_fu_62764_p4 = mul_ln1118_535_fu_62758_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_554_fu_62783_p4() {
    trunc_ln708_554_fu_62783_p4 = mul_ln1118_536_fu_62777_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_555_fu_62802_p4() {
    trunc_ln708_555_fu_62802_p4 = mul_ln1118_537_fu_62796_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_556_fu_62821_p4() {
    trunc_ln708_556_fu_62821_p4 = mul_ln1118_538_fu_62815_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_557_fu_62840_p4() {
    trunc_ln708_557_fu_62840_p4 = mul_ln1118_539_fu_62834_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_558_fu_62859_p4() {
    trunc_ln708_558_fu_62859_p4 = mul_ln1118_540_fu_62853_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_559_fu_62878_p4() {
    trunc_ln708_559_fu_62878_p4 = mul_ln1118_541_fu_62872_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_55_fu_53027_p4() {
    trunc_ln708_55_fu_53027_p4 = mul_ln1118_37_fu_53021_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_560_fu_62897_p4() {
    trunc_ln708_560_fu_62897_p4 = mul_ln1118_542_fu_62891_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_561_fu_62916_p4() {
    trunc_ln708_561_fu_62916_p4 = mul_ln1118_543_fu_62910_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_562_fu_62935_p4() {
    trunc_ln708_562_fu_62935_p4 = mul_ln1118_544_fu_62929_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_563_fu_62954_p4() {
    trunc_ln708_563_fu_62954_p4 = mul_ln1118_545_fu_62948_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_564_fu_62973_p4() {
    trunc_ln708_564_fu_62973_p4 = mul_ln1118_546_fu_62967_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_565_fu_62992_p4() {
    trunc_ln708_565_fu_62992_p4 = mul_ln1118_547_fu_62986_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_566_fu_63011_p4() {
    trunc_ln708_566_fu_63011_p4 = mul_ln1118_548_fu_63005_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_567_fu_63030_p4() {
    trunc_ln708_567_fu_63030_p4 = mul_ln1118_549_fu_63024_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_568_fu_63049_p4() {
    trunc_ln708_568_fu_63049_p4 = mul_ln1118_550_fu_63043_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_569_fu_63067_p4() {
    trunc_ln708_569_fu_63067_p4 = mul_ln1118_551_fu_63062_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_56_fu_53049_p4() {
    trunc_ln708_56_fu_53049_p4 = mul_ln1118_38_fu_53043_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_570_fu_63085_p4() {
    trunc_ln708_570_fu_63085_p4 = mul_ln1118_552_fu_63080_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_577_fu_63104_p4() {
    trunc_ln708_577_fu_63104_p4 = mul_ln1118_559_fu_63098_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_578_fu_63123_p4() {
    trunc_ln708_578_fu_63123_p4 = mul_ln1118_560_fu_63117_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_579_fu_63142_p4() {
    trunc_ln708_579_fu_63142_p4 = mul_ln1118_561_fu_63136_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_57_fu_53071_p4() {
    trunc_ln708_57_fu_53071_p4 = mul_ln1118_39_fu_53065_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_580_fu_63161_p4() {
    trunc_ln708_580_fu_63161_p4 = mul_ln1118_562_fu_63155_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_581_fu_63180_p4() {
    trunc_ln708_581_fu_63180_p4 = mul_ln1118_563_fu_63174_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_582_fu_63199_p4() {
    trunc_ln708_582_fu_63199_p4 = mul_ln1118_564_fu_63193_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_583_fu_63218_p4() {
    trunc_ln708_583_fu_63218_p4 = mul_ln1118_565_fu_63212_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_584_fu_63237_p4() {
    trunc_ln708_584_fu_63237_p4 = mul_ln1118_566_fu_63231_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_585_fu_63256_p4() {
    trunc_ln708_585_fu_63256_p4 = mul_ln1118_567_fu_63250_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_586_fu_63275_p4() {
    trunc_ln708_586_fu_63275_p4 = mul_ln1118_568_fu_63269_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_587_fu_63294_p4() {
    trunc_ln708_587_fu_63294_p4 = mul_ln1118_569_fu_63288_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_588_fu_63313_p4() {
    trunc_ln708_588_fu_63313_p4 = mul_ln1118_570_fu_63307_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_589_fu_63332_p4() {
    trunc_ln708_589_fu_63332_p4 = mul_ln1118_571_fu_63326_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_58_fu_53093_p4() {
    trunc_ln708_58_fu_53093_p4 = mul_ln1118_40_fu_53087_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_590_fu_63351_p4() {
    trunc_ln708_590_fu_63351_p4 = mul_ln1118_572_fu_63345_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_591_fu_63370_p4() {
    trunc_ln708_591_fu_63370_p4 = mul_ln1118_573_fu_63364_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_592_fu_63389_p4() {
    trunc_ln708_592_fu_63389_p4 = mul_ln1118_574_fu_63383_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_593_fu_63408_p4() {
    trunc_ln708_593_fu_63408_p4 = mul_ln1118_575_fu_63402_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_594_fu_63426_p4() {
    trunc_ln708_594_fu_63426_p4 = mul_ln1118_576_fu_63421_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_595_fu_63444_p4() {
    trunc_ln708_595_fu_63444_p4 = mul_ln1118_577_fu_63439_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_59_fu_53115_p4() {
    trunc_ln708_59_fu_53115_p4 = mul_ln1118_41_fu_53109_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_602_fu_63463_p4() {
    trunc_ln708_602_fu_63463_p4 = mul_ln1118_584_fu_63457_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_603_fu_63482_p4() {
    trunc_ln708_603_fu_63482_p4 = mul_ln1118_585_fu_63476_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_604_fu_63501_p4() {
    trunc_ln708_604_fu_63501_p4 = mul_ln1118_586_fu_63495_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_605_fu_63520_p4() {
    trunc_ln708_605_fu_63520_p4 = mul_ln1118_587_fu_63514_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_606_fu_63539_p4() {
    trunc_ln708_606_fu_63539_p4 = mul_ln1118_588_fu_63533_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_607_fu_63558_p4() {
    trunc_ln708_607_fu_63558_p4 = mul_ln1118_589_fu_63552_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_608_fu_63577_p4() {
    trunc_ln708_608_fu_63577_p4 = mul_ln1118_590_fu_63571_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_609_fu_63596_p4() {
    trunc_ln708_609_fu_63596_p4 = mul_ln1118_591_fu_63590_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_60_fu_53137_p4() {
    trunc_ln708_60_fu_53137_p4 = mul_ln1118_42_fu_53131_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_610_fu_63615_p4() {
    trunc_ln708_610_fu_63615_p4 = mul_ln1118_592_fu_63609_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_611_fu_63634_p4() {
    trunc_ln708_611_fu_63634_p4 = mul_ln1118_593_fu_63628_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_612_fu_63653_p4() {
    trunc_ln708_612_fu_63653_p4 = mul_ln1118_594_fu_63647_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_613_fu_63672_p4() {
    trunc_ln708_613_fu_63672_p4 = mul_ln1118_595_fu_63666_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_614_fu_63691_p4() {
    trunc_ln708_614_fu_63691_p4 = mul_ln1118_596_fu_63685_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_615_fu_63710_p4() {
    trunc_ln708_615_fu_63710_p4 = mul_ln1118_597_fu_63704_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_616_fu_63729_p4() {
    trunc_ln708_616_fu_63729_p4 = mul_ln1118_598_fu_63723_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_617_fu_63748_p4() {
    trunc_ln708_617_fu_63748_p4 = mul_ln1118_599_fu_63742_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_618_fu_63767_p4() {
    trunc_ln708_618_fu_63767_p4 = mul_ln1118_600_fu_63761_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_619_fu_63785_p4() {
    trunc_ln708_619_fu_63785_p4 = mul_ln1118_601_fu_63780_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_61_fu_53159_p4() {
    trunc_ln708_61_fu_53159_p4 = mul_ln1118_43_fu_53153_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_620_fu_63803_p4() {
    trunc_ln708_620_fu_63803_p4 = mul_ln1118_602_fu_63798_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_627_fu_64810_p4() {
    trunc_ln708_627_fu_64810_p4 = mul_ln1118_609_fu_64804_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_628_fu_64829_p4() {
    trunc_ln708_628_fu_64829_p4 = mul_ln1118_610_fu_64823_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_629_fu_64848_p4() {
    trunc_ln708_629_fu_64848_p4 = mul_ln1118_611_fu_64842_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_62_fu_53181_p4() {
    trunc_ln708_62_fu_53181_p4 = mul_ln1118_44_fu_53175_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_630_fu_64867_p4() {
    trunc_ln708_630_fu_64867_p4 = mul_ln1118_612_fu_64861_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_631_fu_64886_p4() {
    trunc_ln708_631_fu_64886_p4 = mul_ln1118_613_fu_64880_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_632_fu_64905_p4() {
    trunc_ln708_632_fu_64905_p4 = mul_ln1118_614_fu_64899_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_633_fu_64924_p4() {
    trunc_ln708_633_fu_64924_p4 = mul_ln1118_615_fu_64918_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_634_fu_64943_p4() {
    trunc_ln708_634_fu_64943_p4 = mul_ln1118_616_fu_64937_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_635_fu_64962_p4() {
    trunc_ln708_635_fu_64962_p4 = mul_ln1118_617_fu_64956_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_636_fu_64981_p4() {
    trunc_ln708_636_fu_64981_p4 = mul_ln1118_618_fu_64975_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_637_fu_65000_p4() {
    trunc_ln708_637_fu_65000_p4 = mul_ln1118_619_fu_64994_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_638_fu_65019_p4() {
    trunc_ln708_638_fu_65019_p4 = mul_ln1118_620_fu_65013_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_639_fu_65038_p4() {
    trunc_ln708_639_fu_65038_p4 = mul_ln1118_621_fu_65032_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_63_fu_53203_p4() {
    trunc_ln708_63_fu_53203_p4 = mul_ln1118_45_fu_53197_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_640_fu_65057_p4() {
    trunc_ln708_640_fu_65057_p4 = mul_ln1118_622_fu_65051_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_641_fu_65076_p4() {
    trunc_ln708_641_fu_65076_p4 = mul_ln1118_623_fu_65070_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_642_fu_65095_p4() {
    trunc_ln708_642_fu_65095_p4 = mul_ln1118_624_fu_65089_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_643_fu_65114_p4() {
    trunc_ln708_643_fu_65114_p4 = mul_ln1118_625_fu_65108_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_644_fu_65133_p4() {
    trunc_ln708_644_fu_65133_p4 = mul_ln1118_626_fu_65127_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_645_fu_65152_p4() {
    trunc_ln708_645_fu_65152_p4 = mul_ln1118_627_fu_65146_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_64_fu_53225_p4() {
    trunc_ln708_64_fu_53225_p4 = mul_ln1118_46_fu_53219_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_652_fu_65171_p4() {
    trunc_ln708_652_fu_65171_p4 = mul_ln1118_634_fu_65165_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_653_fu_65190_p4() {
    trunc_ln708_653_fu_65190_p4 = mul_ln1118_635_fu_65184_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_654_fu_65209_p4() {
    trunc_ln708_654_fu_65209_p4 = mul_ln1118_636_fu_65203_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_655_fu_65228_p4() {
    trunc_ln708_655_fu_65228_p4 = mul_ln1118_637_fu_65222_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_656_fu_65247_p4() {
    trunc_ln708_656_fu_65247_p4 = mul_ln1118_638_fu_65241_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_657_fu_65266_p4() {
    trunc_ln708_657_fu_65266_p4 = mul_ln1118_639_fu_65260_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_658_fu_65285_p4() {
    trunc_ln708_658_fu_65285_p4 = mul_ln1118_640_fu_65279_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_659_fu_65304_p4() {
    trunc_ln708_659_fu_65304_p4 = mul_ln1118_641_fu_65298_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_65_fu_53247_p4() {
    trunc_ln708_65_fu_53247_p4 = mul_ln1118_47_fu_53241_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_660_fu_65323_p4() {
    trunc_ln708_660_fu_65323_p4 = mul_ln1118_642_fu_65317_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_661_fu_65342_p4() {
    trunc_ln708_661_fu_65342_p4 = mul_ln1118_643_fu_65336_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_662_fu_65361_p4() {
    trunc_ln708_662_fu_65361_p4 = mul_ln1118_644_fu_65355_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_663_fu_65380_p4() {
    trunc_ln708_663_fu_65380_p4 = mul_ln1118_645_fu_65374_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_664_fu_65399_p4() {
    trunc_ln708_664_fu_65399_p4 = mul_ln1118_646_fu_65393_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_665_fu_65418_p4() {
    trunc_ln708_665_fu_65418_p4 = mul_ln1118_647_fu_65412_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_666_fu_65437_p4() {
    trunc_ln708_666_fu_65437_p4 = mul_ln1118_648_fu_65431_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_667_fu_65456_p4() {
    trunc_ln708_667_fu_65456_p4 = mul_ln1118_649_fu_65450_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_668_fu_65475_p4() {
    trunc_ln708_668_fu_65475_p4 = mul_ln1118_650_fu_65469_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_669_fu_65494_p4() {
    trunc_ln708_669_fu_65494_p4 = mul_ln1118_651_fu_65488_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_66_fu_53269_p4() {
    trunc_ln708_66_fu_53269_p4 = mul_ln1118_48_fu_53263_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_670_fu_65512_p4() {
    trunc_ln708_670_fu_65512_p4 = mul_ln1118_652_fu_65507_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_677_fu_65531_p4() {
    trunc_ln708_677_fu_65531_p4 = mul_ln1118_659_fu_65525_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_678_fu_65550_p4() {
    trunc_ln708_678_fu_65550_p4 = mul_ln1118_660_fu_65544_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_679_fu_65569_p4() {
    trunc_ln708_679_fu_65569_p4 = mul_ln1118_661_fu_65563_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_67_fu_53291_p4() {
    trunc_ln708_67_fu_53291_p4 = mul_ln1118_49_fu_53285_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_680_fu_65588_p4() {
    trunc_ln708_680_fu_65588_p4 = mul_ln1118_662_fu_65582_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_681_fu_65607_p4() {
    trunc_ln708_681_fu_65607_p4 = mul_ln1118_663_fu_65601_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_682_fu_65626_p4() {
    trunc_ln708_682_fu_65626_p4 = mul_ln1118_664_fu_65620_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_683_fu_65645_p4() {
    trunc_ln708_683_fu_65645_p4 = mul_ln1118_665_fu_65639_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_684_fu_65664_p4() {
    trunc_ln708_684_fu_65664_p4 = mul_ln1118_666_fu_65658_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_685_fu_65683_p4() {
    trunc_ln708_685_fu_65683_p4 = mul_ln1118_667_fu_65677_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_686_fu_65702_p4() {
    trunc_ln708_686_fu_65702_p4 = mul_ln1118_668_fu_65696_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_687_fu_65721_p4() {
    trunc_ln708_687_fu_65721_p4 = mul_ln1118_669_fu_65715_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_688_fu_65740_p4() {
    trunc_ln708_688_fu_65740_p4 = mul_ln1118_670_fu_65734_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_689_fu_65759_p4() {
    trunc_ln708_689_fu_65759_p4 = mul_ln1118_671_fu_65753_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_68_fu_53313_p4() {
    trunc_ln708_68_fu_53313_p4 = mul_ln1118_50_fu_53307_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_690_fu_65778_p4() {
    trunc_ln708_690_fu_65778_p4 = mul_ln1118_672_fu_65772_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_691_fu_65797_p4() {
    trunc_ln708_691_fu_65797_p4 = mul_ln1118_673_fu_65791_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_692_fu_65816_p4() {
    trunc_ln708_692_fu_65816_p4 = mul_ln1118_674_fu_65810_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_693_fu_65835_p4() {
    trunc_ln708_693_fu_65835_p4 = mul_ln1118_675_fu_65829_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_694_fu_65854_p4() {
    trunc_ln708_694_fu_65854_p4 = mul_ln1118_676_fu_65848_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_695_fu_65872_p4() {
    trunc_ln708_695_fu_65872_p4 = mul_ln1118_677_fu_65867_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_69_fu_53335_p4() {
    trunc_ln708_69_fu_53335_p4 = mul_ln1118_51_fu_53329_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_702_fu_65891_p4() {
    trunc_ln708_702_fu_65891_p4 = mul_ln1118_684_fu_65885_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_703_fu_65910_p4() {
    trunc_ln708_703_fu_65910_p4 = mul_ln1118_685_fu_65904_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_704_fu_65929_p4() {
    trunc_ln708_704_fu_65929_p4 = mul_ln1118_686_fu_65923_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_705_fu_65948_p4() {
    trunc_ln708_705_fu_65948_p4 = mul_ln1118_687_fu_65942_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_706_fu_65967_p4() {
    trunc_ln708_706_fu_65967_p4 = mul_ln1118_688_fu_65961_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_707_fu_65986_p4() {
    trunc_ln708_707_fu_65986_p4 = mul_ln1118_689_fu_65980_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_708_fu_66005_p4() {
    trunc_ln708_708_fu_66005_p4 = mul_ln1118_690_fu_65999_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_709_fu_66024_p4() {
    trunc_ln708_709_fu_66024_p4 = mul_ln1118_691_fu_66018_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_70_fu_53353_p4() {
    trunc_ln708_70_fu_53353_p4 = mul_ln1118_52_fu_53348_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_710_fu_66043_p4() {
    trunc_ln708_710_fu_66043_p4 = mul_ln1118_692_fu_66037_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_711_fu_66062_p4() {
    trunc_ln708_711_fu_66062_p4 = mul_ln1118_693_fu_66056_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_712_fu_66081_p4() {
    trunc_ln708_712_fu_66081_p4 = mul_ln1118_694_fu_66075_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_713_fu_66100_p4() {
    trunc_ln708_713_fu_66100_p4 = mul_ln1118_695_fu_66094_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_714_fu_66119_p4() {
    trunc_ln708_714_fu_66119_p4 = mul_ln1118_696_fu_66113_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_715_fu_66138_p4() {
    trunc_ln708_715_fu_66138_p4 = mul_ln1118_697_fu_66132_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_716_fu_66157_p4() {
    trunc_ln708_716_fu_66157_p4 = mul_ln1118_698_fu_66151_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_717_fu_66176_p4() {
    trunc_ln708_717_fu_66176_p4 = mul_ln1118_699_fu_66170_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_718_fu_66195_p4() {
    trunc_ln708_718_fu_66195_p4 = mul_ln1118_700_fu_66189_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_719_fu_66214_p4() {
    trunc_ln708_719_fu_66214_p4 = mul_ln1118_701_fu_66208_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_720_fu_66232_p4() {
    trunc_ln708_720_fu_66232_p4 = mul_ln1118_702_fu_66227_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_727_fu_66251_p4() {
    trunc_ln708_727_fu_66251_p4 = mul_ln1118_709_fu_66245_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_728_fu_66270_p4() {
    trunc_ln708_728_fu_66270_p4 = mul_ln1118_710_fu_66264_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_729_fu_66289_p4() {
    trunc_ln708_729_fu_66289_p4 = mul_ln1118_711_fu_66283_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_730_fu_66308_p4() {
    trunc_ln708_730_fu_66308_p4 = mul_ln1118_712_fu_66302_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_731_fu_66327_p4() {
    trunc_ln708_731_fu_66327_p4 = mul_ln1118_713_fu_66321_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_732_fu_66346_p4() {
    trunc_ln708_732_fu_66346_p4 = mul_ln1118_714_fu_66340_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_733_fu_66365_p4() {
    trunc_ln708_733_fu_66365_p4 = mul_ln1118_715_fu_66359_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_734_fu_66384_p4() {
    trunc_ln708_734_fu_66384_p4 = mul_ln1118_716_fu_66378_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_735_fu_66403_p4() {
    trunc_ln708_735_fu_66403_p4 = mul_ln1118_717_fu_66397_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_736_fu_66422_p4() {
    trunc_ln708_736_fu_66422_p4 = mul_ln1118_718_fu_66416_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_737_fu_66441_p4() {
    trunc_ln708_737_fu_66441_p4 = mul_ln1118_719_fu_66435_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_738_fu_66460_p4() {
    trunc_ln708_738_fu_66460_p4 = mul_ln1118_720_fu_66454_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_739_fu_66479_p4() {
    trunc_ln708_739_fu_66479_p4 = mul_ln1118_721_fu_66473_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_740_fu_66498_p4() {
    trunc_ln708_740_fu_66498_p4 = mul_ln1118_722_fu_66492_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_741_fu_66517_p4() {
    trunc_ln708_741_fu_66517_p4 = mul_ln1118_723_fu_66511_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_742_fu_66536_p4() {
    trunc_ln708_742_fu_66536_p4 = mul_ln1118_724_fu_66530_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_743_fu_66555_p4() {
    trunc_ln708_743_fu_66555_p4 = mul_ln1118_725_fu_66549_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_744_fu_66574_p4() {
    trunc_ln708_744_fu_66574_p4 = mul_ln1118_726_fu_66568_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_745_fu_66593_p4() {
    trunc_ln708_745_fu_66593_p4 = mul_ln1118_727_fu_66587_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_746_fu_66612_p4() {
    trunc_ln708_746_fu_66612_p4 = mul_ln1118_728_fu_66606_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_747_fu_66631_p4() {
    trunc_ln708_747_fu_66631_p4 = mul_ln1118_729_fu_66625_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_748_fu_66650_p4() {
    trunc_ln708_748_fu_66650_p4 = mul_ln1118_730_fu_66644_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_749_fu_66669_p4() {
    trunc_ln708_749_fu_66669_p4 = mul_ln1118_731_fu_66663_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_752_fu_66688_p4() {
    trunc_ln708_752_fu_66688_p4 = mul_ln1118_734_fu_66682_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_753_fu_66707_p4() {
    trunc_ln708_753_fu_66707_p4 = mul_ln1118_735_fu_66701_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_754_fu_66726_p4() {
    trunc_ln708_754_fu_66726_p4 = mul_ln1118_736_fu_66720_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_755_fu_66745_p4() {
    trunc_ln708_755_fu_66745_p4 = mul_ln1118_737_fu_66739_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_756_fu_66764_p4() {
    trunc_ln708_756_fu_66764_p4 = mul_ln1118_738_fu_66758_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_757_fu_66783_p4() {
    trunc_ln708_757_fu_66783_p4 = mul_ln1118_739_fu_66777_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_758_fu_66802_p4() {
    trunc_ln708_758_fu_66802_p4 = mul_ln1118_740_fu_66796_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_759_fu_66821_p4() {
    trunc_ln708_759_fu_66821_p4 = mul_ln1118_741_fu_66815_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_760_fu_66840_p4() {
    trunc_ln708_760_fu_66840_p4 = mul_ln1118_742_fu_66834_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_761_fu_66859_p4() {
    trunc_ln708_761_fu_66859_p4 = mul_ln1118_743_fu_66853_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_762_fu_66878_p4() {
    trunc_ln708_762_fu_66878_p4 = mul_ln1118_744_fu_66872_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_763_fu_66897_p4() {
    trunc_ln708_763_fu_66897_p4 = mul_ln1118_745_fu_66891_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_764_fu_66916_p4() {
    trunc_ln708_764_fu_66916_p4 = mul_ln1118_746_fu_66910_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_765_fu_66935_p4() {
    trunc_ln708_765_fu_66935_p4 = mul_ln1118_747_fu_66929_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_766_fu_66954_p4() {
    trunc_ln708_766_fu_66954_p4 = mul_ln1118_748_fu_66948_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_767_fu_66973_p4() {
    trunc_ln708_767_fu_66973_p4 = mul_ln1118_749_fu_66967_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_768_fu_66992_p4() {
    trunc_ln708_768_fu_66992_p4 = mul_ln1118_750_fu_66986_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_769_fu_67010_p4() {
    trunc_ln708_769_fu_67010_p4 = mul_ln1118_751_fu_67005_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_770_fu_67028_p4() {
    trunc_ln708_770_fu_67028_p4 = mul_ln1118_752_fu_67023_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_777_fu_67047_p4() {
    trunc_ln708_777_fu_67047_p4 = mul_ln1118_759_fu_67041_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_778_fu_67066_p4() {
    trunc_ln708_778_fu_67066_p4 = mul_ln1118_760_fu_67060_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_779_fu_67085_p4() {
    trunc_ln708_779_fu_67085_p4 = mul_ln1118_761_fu_67079_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_77_fu_53375_p4() {
    trunc_ln708_77_fu_53375_p4 = mul_ln1118_59_fu_53369_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_780_fu_67104_p4() {
    trunc_ln708_780_fu_67104_p4 = mul_ln1118_762_fu_67098_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_781_fu_67123_p4() {
    trunc_ln708_781_fu_67123_p4 = mul_ln1118_763_fu_67117_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_782_fu_67142_p4() {
    trunc_ln708_782_fu_67142_p4 = mul_ln1118_764_fu_67136_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_783_fu_67161_p4() {
    trunc_ln708_783_fu_67161_p4 = mul_ln1118_765_fu_67155_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_784_fu_67180_p4() {
    trunc_ln708_784_fu_67180_p4 = mul_ln1118_766_fu_67174_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_785_fu_67199_p4() {
    trunc_ln708_785_fu_67199_p4 = mul_ln1118_767_fu_67193_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_786_fu_67218_p4() {
    trunc_ln708_786_fu_67218_p4 = mul_ln1118_768_fu_67212_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_787_fu_67237_p4() {
    trunc_ln708_787_fu_67237_p4 = mul_ln1118_769_fu_67231_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_788_fu_67256_p4() {
    trunc_ln708_788_fu_67256_p4 = mul_ln1118_770_fu_67250_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_789_fu_67275_p4() {
    trunc_ln708_789_fu_67275_p4 = mul_ln1118_771_fu_67269_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_78_fu_53397_p4() {
    trunc_ln708_78_fu_53397_p4 = mul_ln1118_60_fu_53391_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_790_fu_67294_p4() {
    trunc_ln708_790_fu_67294_p4 = mul_ln1118_772_fu_67288_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_791_fu_67313_p4() {
    trunc_ln708_791_fu_67313_p4 = mul_ln1118_773_fu_67307_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_792_fu_67332_p4() {
    trunc_ln708_792_fu_67332_p4 = mul_ln1118_774_fu_67326_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_793_fu_67351_p4() {
    trunc_ln708_793_fu_67351_p4 = mul_ln1118_775_fu_67345_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_794_fu_67369_p4() {
    trunc_ln708_794_fu_67369_p4 = mul_ln1118_776_fu_67364_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_795_fu_67387_p4() {
    trunc_ln708_795_fu_67387_p4 = mul_ln1118_777_fu_67382_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_79_fu_53419_p4() {
    trunc_ln708_79_fu_53419_p4 = mul_ln1118_61_fu_53413_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_802_fu_67406_p4() {
    trunc_ln708_802_fu_67406_p4 = mul_ln1118_784_fu_67400_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_803_fu_67425_p4() {
    trunc_ln708_803_fu_67425_p4 = mul_ln1118_785_fu_67419_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_804_fu_67444_p4() {
    trunc_ln708_804_fu_67444_p4 = mul_ln1118_786_fu_67438_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_805_fu_67463_p4() {
    trunc_ln708_805_fu_67463_p4 = mul_ln1118_787_fu_67457_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_806_fu_67482_p4() {
    trunc_ln708_806_fu_67482_p4 = mul_ln1118_788_fu_67476_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_807_fu_67501_p4() {
    trunc_ln708_807_fu_67501_p4 = mul_ln1118_789_fu_67495_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_808_fu_67520_p4() {
    trunc_ln708_808_fu_67520_p4 = mul_ln1118_790_fu_67514_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_809_fu_67539_p4() {
    trunc_ln708_809_fu_67539_p4 = mul_ln1118_791_fu_67533_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_80_fu_53441_p4() {
    trunc_ln708_80_fu_53441_p4 = mul_ln1118_62_fu_53435_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_810_fu_67558_p4() {
    trunc_ln708_810_fu_67558_p4 = mul_ln1118_792_fu_67552_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_811_fu_67577_p4() {
    trunc_ln708_811_fu_67577_p4 = mul_ln1118_793_fu_67571_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_812_fu_67596_p4() {
    trunc_ln708_812_fu_67596_p4 = mul_ln1118_794_fu_67590_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_813_fu_67615_p4() {
    trunc_ln708_813_fu_67615_p4 = mul_ln1118_795_fu_67609_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_814_fu_67634_p4() {
    trunc_ln708_814_fu_67634_p4 = mul_ln1118_796_fu_67628_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_815_fu_67653_p4() {
    trunc_ln708_815_fu_67653_p4 = mul_ln1118_797_fu_67647_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_816_fu_67672_p4() {
    trunc_ln708_816_fu_67672_p4 = mul_ln1118_798_fu_67666_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_817_fu_67691_p4() {
    trunc_ln708_817_fu_67691_p4 = mul_ln1118_799_fu_67685_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_818_fu_67710_p4() {
    trunc_ln708_818_fu_67710_p4 = mul_ln1118_800_fu_67704_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_819_fu_67728_p4() {
    trunc_ln708_819_fu_67728_p4 = mul_ln1118_801_fu_67723_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_81_fu_53463_p4() {
    trunc_ln708_81_fu_53463_p4 = mul_ln1118_63_fu_53457_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_820_fu_67746_p4() {
    trunc_ln708_820_fu_67746_p4 = mul_ln1118_802_fu_67741_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_827_fu_68753_p4() {
    trunc_ln708_827_fu_68753_p4 = mul_ln1118_809_fu_68747_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_828_fu_68772_p4() {
    trunc_ln708_828_fu_68772_p4 = mul_ln1118_810_fu_68766_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_829_fu_68791_p4() {
    trunc_ln708_829_fu_68791_p4 = mul_ln1118_811_fu_68785_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_82_fu_53485_p4() {
    trunc_ln708_82_fu_53485_p4 = mul_ln1118_64_fu_53479_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_830_fu_68810_p4() {
    trunc_ln708_830_fu_68810_p4 = mul_ln1118_812_fu_68804_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_831_fu_68829_p4() {
    trunc_ln708_831_fu_68829_p4 = mul_ln1118_813_fu_68823_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_832_fu_68848_p4() {
    trunc_ln708_832_fu_68848_p4 = mul_ln1118_814_fu_68842_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_833_fu_68867_p4() {
    trunc_ln708_833_fu_68867_p4 = mul_ln1118_815_fu_68861_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_834_fu_68886_p4() {
    trunc_ln708_834_fu_68886_p4 = mul_ln1118_816_fu_68880_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_835_fu_68905_p4() {
    trunc_ln708_835_fu_68905_p4 = mul_ln1118_817_fu_68899_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_836_fu_68924_p4() {
    trunc_ln708_836_fu_68924_p4 = mul_ln1118_818_fu_68918_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_837_fu_68943_p4() {
    trunc_ln708_837_fu_68943_p4 = mul_ln1118_819_fu_68937_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_838_fu_68962_p4() {
    trunc_ln708_838_fu_68962_p4 = mul_ln1118_820_fu_68956_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_839_fu_68981_p4() {
    trunc_ln708_839_fu_68981_p4 = mul_ln1118_821_fu_68975_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_83_fu_53507_p4() {
    trunc_ln708_83_fu_53507_p4 = mul_ln1118_65_fu_53501_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_840_fu_69000_p4() {
    trunc_ln708_840_fu_69000_p4 = mul_ln1118_822_fu_68994_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_841_fu_69019_p4() {
    trunc_ln708_841_fu_69019_p4 = mul_ln1118_823_fu_69013_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_842_fu_69038_p4() {
    trunc_ln708_842_fu_69038_p4 = mul_ln1118_824_fu_69032_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_843_fu_69057_p4() {
    trunc_ln708_843_fu_69057_p4 = mul_ln1118_825_fu_69051_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_844_fu_69076_p4() {
    trunc_ln708_844_fu_69076_p4 = mul_ln1118_826_fu_69070_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_845_fu_69095_p4() {
    trunc_ln708_845_fu_69095_p4 = mul_ln1118_827_fu_69089_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_84_fu_53529_p4() {
    trunc_ln708_84_fu_53529_p4 = mul_ln1118_66_fu_53523_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_852_fu_69114_p4() {
    trunc_ln708_852_fu_69114_p4 = mul_ln1118_834_fu_69108_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_853_fu_69133_p4() {
    trunc_ln708_853_fu_69133_p4 = mul_ln1118_835_fu_69127_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_854_fu_69152_p4() {
    trunc_ln708_854_fu_69152_p4 = mul_ln1118_836_fu_69146_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_855_fu_69171_p4() {
    trunc_ln708_855_fu_69171_p4 = mul_ln1118_837_fu_69165_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_856_fu_69190_p4() {
    trunc_ln708_856_fu_69190_p4 = mul_ln1118_838_fu_69184_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_857_fu_69209_p4() {
    trunc_ln708_857_fu_69209_p4 = mul_ln1118_839_fu_69203_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_858_fu_69228_p4() {
    trunc_ln708_858_fu_69228_p4 = mul_ln1118_840_fu_69222_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_859_fu_69247_p4() {
    trunc_ln708_859_fu_69247_p4 = mul_ln1118_841_fu_69241_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_85_fu_53551_p4() {
    trunc_ln708_85_fu_53551_p4 = mul_ln1118_67_fu_53545_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_860_fu_69266_p4() {
    trunc_ln708_860_fu_69266_p4 = mul_ln1118_842_fu_69260_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_861_fu_69285_p4() {
    trunc_ln708_861_fu_69285_p4 = mul_ln1118_843_fu_69279_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_862_fu_69304_p4() {
    trunc_ln708_862_fu_69304_p4 = mul_ln1118_844_fu_69298_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_863_fu_69323_p4() {
    trunc_ln708_863_fu_69323_p4 = mul_ln1118_845_fu_69317_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_864_fu_69342_p4() {
    trunc_ln708_864_fu_69342_p4 = mul_ln1118_846_fu_69336_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_865_fu_69361_p4() {
    trunc_ln708_865_fu_69361_p4 = mul_ln1118_847_fu_69355_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_866_fu_69380_p4() {
    trunc_ln708_866_fu_69380_p4 = mul_ln1118_848_fu_69374_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_867_fu_69399_p4() {
    trunc_ln708_867_fu_69399_p4 = mul_ln1118_849_fu_69393_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_868_fu_69418_p4() {
    trunc_ln708_868_fu_69418_p4 = mul_ln1118_850_fu_69412_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_869_fu_69437_p4() {
    trunc_ln708_869_fu_69437_p4 = mul_ln1118_851_fu_69431_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_86_fu_53573_p4() {
    trunc_ln708_86_fu_53573_p4 = mul_ln1118_68_fu_53567_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_870_fu_69455_p4() {
    trunc_ln708_870_fu_69455_p4 = mul_ln1118_852_fu_69450_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_877_fu_69474_p4() {
    trunc_ln708_877_fu_69474_p4 = mul_ln1118_859_fu_69468_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_878_fu_69493_p4() {
    trunc_ln708_878_fu_69493_p4 = mul_ln1118_860_fu_69487_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_879_fu_69512_p4() {
    trunc_ln708_879_fu_69512_p4 = mul_ln1118_861_fu_69506_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_87_fu_53595_p4() {
    trunc_ln708_87_fu_53595_p4 = mul_ln1118_69_fu_53589_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_880_fu_69531_p4() {
    trunc_ln708_880_fu_69531_p4 = mul_ln1118_862_fu_69525_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_881_fu_69550_p4() {
    trunc_ln708_881_fu_69550_p4 = mul_ln1118_863_fu_69544_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_882_fu_69569_p4() {
    trunc_ln708_882_fu_69569_p4 = mul_ln1118_864_fu_69563_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_883_fu_69588_p4() {
    trunc_ln708_883_fu_69588_p4 = mul_ln1118_865_fu_69582_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_884_fu_69607_p4() {
    trunc_ln708_884_fu_69607_p4 = mul_ln1118_866_fu_69601_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_885_fu_69626_p4() {
    trunc_ln708_885_fu_69626_p4 = mul_ln1118_867_fu_69620_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_886_fu_69645_p4() {
    trunc_ln708_886_fu_69645_p4 = mul_ln1118_868_fu_69639_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_887_fu_69664_p4() {
    trunc_ln708_887_fu_69664_p4 = mul_ln1118_869_fu_69658_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_888_fu_69683_p4() {
    trunc_ln708_888_fu_69683_p4 = mul_ln1118_870_fu_69677_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_889_fu_69702_p4() {
    trunc_ln708_889_fu_69702_p4 = mul_ln1118_871_fu_69696_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_88_fu_53617_p4() {
    trunc_ln708_88_fu_53617_p4 = mul_ln1118_70_fu_53611_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_890_fu_69721_p4() {
    trunc_ln708_890_fu_69721_p4 = mul_ln1118_872_fu_69715_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_891_fu_69740_p4() {
    trunc_ln708_891_fu_69740_p4 = mul_ln1118_873_fu_69734_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_892_fu_69759_p4() {
    trunc_ln708_892_fu_69759_p4 = mul_ln1118_874_fu_69753_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_893_fu_69778_p4() {
    trunc_ln708_893_fu_69778_p4 = mul_ln1118_875_fu_69772_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_894_fu_69797_p4() {
    trunc_ln708_894_fu_69797_p4 = mul_ln1118_876_fu_69791_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_895_fu_69815_p4() {
    trunc_ln708_895_fu_69815_p4 = mul_ln1118_877_fu_69810_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_89_fu_53639_p4() {
    trunc_ln708_89_fu_53639_p4 = mul_ln1118_71_fu_53633_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_902_fu_69834_p4() {
    trunc_ln708_902_fu_69834_p4 = mul_ln1118_884_fu_69828_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_903_fu_69853_p4() {
    trunc_ln708_903_fu_69853_p4 = mul_ln1118_885_fu_69847_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_904_fu_69872_p4() {
    trunc_ln708_904_fu_69872_p4 = mul_ln1118_886_fu_69866_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_905_fu_69891_p4() {
    trunc_ln708_905_fu_69891_p4 = mul_ln1118_887_fu_69885_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_906_fu_69910_p4() {
    trunc_ln708_906_fu_69910_p4 = mul_ln1118_888_fu_69904_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_907_fu_69929_p4() {
    trunc_ln708_907_fu_69929_p4 = mul_ln1118_889_fu_69923_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_908_fu_69948_p4() {
    trunc_ln708_908_fu_69948_p4 = mul_ln1118_890_fu_69942_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_909_fu_69967_p4() {
    trunc_ln708_909_fu_69967_p4 = mul_ln1118_891_fu_69961_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_90_fu_53661_p4() {
    trunc_ln708_90_fu_53661_p4 = mul_ln1118_72_fu_53655_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_910_fu_69986_p4() {
    trunc_ln708_910_fu_69986_p4 = mul_ln1118_892_fu_69980_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_911_fu_70005_p4() {
    trunc_ln708_911_fu_70005_p4 = mul_ln1118_893_fu_69999_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_912_fu_70024_p4() {
    trunc_ln708_912_fu_70024_p4 = mul_ln1118_894_fu_70018_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_913_fu_70043_p4() {
    trunc_ln708_913_fu_70043_p4 = mul_ln1118_895_fu_70037_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_914_fu_70062_p4() {
    trunc_ln708_914_fu_70062_p4 = mul_ln1118_896_fu_70056_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_915_fu_70081_p4() {
    trunc_ln708_915_fu_70081_p4 = mul_ln1118_897_fu_70075_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_916_fu_70100_p4() {
    trunc_ln708_916_fu_70100_p4 = mul_ln1118_898_fu_70094_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_917_fu_70119_p4() {
    trunc_ln708_917_fu_70119_p4 = mul_ln1118_899_fu_70113_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_918_fu_70138_p4() {
    trunc_ln708_918_fu_70138_p4 = mul_ln1118_900_fu_70132_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_919_fu_70157_p4() {
    trunc_ln708_919_fu_70157_p4 = mul_ln1118_901_fu_70151_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_91_fu_53683_p4() {
    trunc_ln708_91_fu_53683_p4 = mul_ln1118_73_fu_53677_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_920_fu_70175_p4() {
    trunc_ln708_920_fu_70175_p4 = mul_ln1118_902_fu_70170_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_927_fu_70194_p4() {
    trunc_ln708_927_fu_70194_p4 = mul_ln1118_909_fu_70188_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_928_fu_70213_p4() {
    trunc_ln708_928_fu_70213_p4 = mul_ln1118_910_fu_70207_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_929_fu_70232_p4() {
    trunc_ln708_929_fu_70232_p4 = mul_ln1118_911_fu_70226_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_92_fu_53705_p4() {
    trunc_ln708_92_fu_53705_p4 = mul_ln1118_74_fu_53699_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_930_fu_70251_p4() {
    trunc_ln708_930_fu_70251_p4 = mul_ln1118_912_fu_70245_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_931_fu_70270_p4() {
    trunc_ln708_931_fu_70270_p4 = mul_ln1118_913_fu_70264_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_932_fu_70289_p4() {
    trunc_ln708_932_fu_70289_p4 = mul_ln1118_914_fu_70283_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_933_fu_70308_p4() {
    trunc_ln708_933_fu_70308_p4 = mul_ln1118_915_fu_70302_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_934_fu_70327_p4() {
    trunc_ln708_934_fu_70327_p4 = mul_ln1118_916_fu_70321_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_935_fu_70346_p4() {
    trunc_ln708_935_fu_70346_p4 = mul_ln1118_917_fu_70340_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_936_fu_70365_p4() {
    trunc_ln708_936_fu_70365_p4 = mul_ln1118_918_fu_70359_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_937_fu_70384_p4() {
    trunc_ln708_937_fu_70384_p4 = mul_ln1118_919_fu_70378_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_938_fu_70403_p4() {
    trunc_ln708_938_fu_70403_p4 = mul_ln1118_920_fu_70397_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_939_fu_70422_p4() {
    trunc_ln708_939_fu_70422_p4 = mul_ln1118_921_fu_70416_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_93_fu_53727_p4() {
    trunc_ln708_93_fu_53727_p4 = mul_ln1118_75_fu_53721_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_940_fu_70441_p4() {
    trunc_ln708_940_fu_70441_p4 = mul_ln1118_922_fu_70435_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_941_fu_70460_p4() {
    trunc_ln708_941_fu_70460_p4 = mul_ln1118_923_fu_70454_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_942_fu_70479_p4() {
    trunc_ln708_942_fu_70479_p4 = mul_ln1118_924_fu_70473_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_943_fu_70498_p4() {
    trunc_ln708_943_fu_70498_p4 = mul_ln1118_925_fu_70492_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_944_fu_70517_p4() {
    trunc_ln708_944_fu_70517_p4 = mul_ln1118_926_fu_70511_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_945_fu_70536_p4() {
    trunc_ln708_945_fu_70536_p4 = mul_ln1118_927_fu_70530_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_946_fu_70555_p4() {
    trunc_ln708_946_fu_70555_p4 = mul_ln1118_928_fu_70549_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_947_fu_70574_p4() {
    trunc_ln708_947_fu_70574_p4 = mul_ln1118_929_fu_70568_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_948_fu_70593_p4() {
    trunc_ln708_948_fu_70593_p4 = mul_ln1118_930_fu_70587_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_949_fu_70612_p4() {
    trunc_ln708_949_fu_70612_p4 = mul_ln1118_931_fu_70606_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_94_fu_53749_p4() {
    trunc_ln708_94_fu_53749_p4 = mul_ln1118_76_fu_53743_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_952_fu_70631_p4() {
    trunc_ln708_952_fu_70631_p4 = mul_ln1118_934_fu_70625_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_953_fu_70650_p4() {
    trunc_ln708_953_fu_70650_p4 = mul_ln1118_935_fu_70644_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_954_fu_70669_p4() {
    trunc_ln708_954_fu_70669_p4 = mul_ln1118_936_fu_70663_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_955_fu_70688_p4() {
    trunc_ln708_955_fu_70688_p4 = mul_ln1118_937_fu_70682_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_956_fu_70707_p4() {
    trunc_ln708_956_fu_70707_p4 = mul_ln1118_938_fu_70701_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_957_fu_70726_p4() {
    trunc_ln708_957_fu_70726_p4 = mul_ln1118_939_fu_70720_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_958_fu_70745_p4() {
    trunc_ln708_958_fu_70745_p4 = mul_ln1118_940_fu_70739_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_959_fu_70764_p4() {
    trunc_ln708_959_fu_70764_p4 = mul_ln1118_941_fu_70758_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_95_fu_53767_p4() {
    trunc_ln708_95_fu_53767_p4 = mul_ln1118_77_fu_53762_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_960_fu_70783_p4() {
    trunc_ln708_960_fu_70783_p4 = mul_ln1118_942_fu_70777_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_961_fu_70802_p4() {
    trunc_ln708_961_fu_70802_p4 = mul_ln1118_943_fu_70796_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_962_fu_70821_p4() {
    trunc_ln708_962_fu_70821_p4 = mul_ln1118_944_fu_70815_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_963_fu_70840_p4() {
    trunc_ln708_963_fu_70840_p4 = mul_ln1118_945_fu_70834_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_964_fu_70859_p4() {
    trunc_ln708_964_fu_70859_p4 = mul_ln1118_946_fu_70853_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_965_fu_70878_p4() {
    trunc_ln708_965_fu_70878_p4 = mul_ln1118_947_fu_70872_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_966_fu_70897_p4() {
    trunc_ln708_966_fu_70897_p4 = mul_ln1118_948_fu_70891_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_967_fu_70916_p4() {
    trunc_ln708_967_fu_70916_p4 = mul_ln1118_949_fu_70910_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_968_fu_70935_p4() {
    trunc_ln708_968_fu_70935_p4 = mul_ln1118_950_fu_70929_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_969_fu_70953_p4() {
    trunc_ln708_969_fu_70953_p4 = mul_ln1118_951_fu_70948_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_970_fu_70971_p4() {
    trunc_ln708_970_fu_70971_p4 = mul_ln1118_952_fu_70966_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_977_fu_70990_p4() {
    trunc_ln708_977_fu_70990_p4 = mul_ln1118_959_fu_70984_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_978_fu_71009_p4() {
    trunc_ln708_978_fu_71009_p4 = mul_ln1118_960_fu_71003_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_979_fu_71028_p4() {
    trunc_ln708_979_fu_71028_p4 = mul_ln1118_961_fu_71022_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_980_fu_71047_p4() {
    trunc_ln708_980_fu_71047_p4 = mul_ln1118_962_fu_71041_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_981_fu_71066_p4() {
    trunc_ln708_981_fu_71066_p4 = mul_ln1118_963_fu_71060_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_982_fu_71085_p4() {
    trunc_ln708_982_fu_71085_p4 = mul_ln1118_964_fu_71079_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_983_fu_71104_p4() {
    trunc_ln708_983_fu_71104_p4 = mul_ln1118_965_fu_71098_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_984_fu_71123_p4() {
    trunc_ln708_984_fu_71123_p4 = mul_ln1118_966_fu_71117_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_985_fu_71142_p4() {
    trunc_ln708_985_fu_71142_p4 = mul_ln1118_967_fu_71136_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_986_fu_71161_p4() {
    trunc_ln708_986_fu_71161_p4 = mul_ln1118_968_fu_71155_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_987_fu_71180_p4() {
    trunc_ln708_987_fu_71180_p4 = mul_ln1118_969_fu_71174_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_988_fu_71199_p4() {
    trunc_ln708_988_fu_71199_p4 = mul_ln1118_970_fu_71193_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_989_fu_71218_p4() {
    trunc_ln708_989_fu_71218_p4 = mul_ln1118_971_fu_71212_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_990_fu_71237_p4() {
    trunc_ln708_990_fu_71237_p4 = mul_ln1118_972_fu_71231_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_991_fu_71256_p4() {
    trunc_ln708_991_fu_71256_p4 = mul_ln1118_973_fu_71250_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_992_fu_71275_p4() {
    trunc_ln708_992_fu_71275_p4 = mul_ln1118_974_fu_71269_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_993_fu_71294_p4() {
    trunc_ln708_993_fu_71294_p4 = mul_ln1118_975_fu_71288_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_994_fu_71312_p4() {
    trunc_ln708_994_fu_71312_p4 = mul_ln1118_976_fu_71307_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_995_fu_71330_p4() {
    trunc_ln708_995_fu_71330_p4 = mul_ln1118_977_fu_71325_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln708_s_fu_52565_p4() {
    trunc_ln708_s_fu_52565_p4 = mul_ln1118_10_fu_52559_p2.read().range(15, 4);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_trunc_ln76_fu_21853_p1() {
    trunc_ln76_fu_21853_p1 = w11_V_q0.read().range(5-1, 0);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_w11_V_address0() {
    w11_V_address0 =  (sc_lv<1>) (zext_ln76_fu_21834_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_w11_V_ce0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        w11_V_ce0 = ap_const_logic_1;
    } else {
        w11_V_ce0 = ap_const_logic_0;
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_w_index_fu_21839_p2() {
    w_index_fu_21839_p2 = (ap_phi_mux_w_index25_phi_fu_11283_p6.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_zext_ln76_fu_21834_p1() {
    zext_ln76_fu_21834_p1 = esl_zext<64,1>(ap_phi_mux_w_index25_phi_fu_11283_p6.read());
}

}

