//Numpy array shape [10]
//Min -0.281250000000
//Max 0.375000000000
//Number of zeros 2

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
bias11_t b11[10];
#else
bias11_t b11[10] = {0.37500, 0.37500, 0.00000, -0.28125, -0.03125, -0.28125, 0.12500, -0.09375, 0.00000, 0.18750};
#endif

#endif
