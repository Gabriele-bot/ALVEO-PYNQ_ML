#include "dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_CS_fsm_state1() {
    ap_CS_fsm_state1 = ap_CS_fsm.read()[0];
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_block_pp0_stage0() {
    ap_block_pp0_stage0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_block_pp0_stage0_11001() {
    ap_block_pp0_stage0_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_block_pp0_stage0_subdone() {
    ap_block_pp0_stage0_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_block_state2_pp0_stage0_iter0() {
    ap_block_state2_pp0_stage0_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_block_state3_pp0_stage0_iter1() {
    ap_block_state3_pp0_stage0_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_block_state4_pp0_stage0_iter2() {
    ap_block_state4_pp0_stage0_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_block_state5_pp0_stage0_iter3() {
    ap_block_state5_pp0_stage0_iter3 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_condition_41() {
    ap_condition_41 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0));
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_condition_7800() {
    ap_condition_7800 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()));
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_condition_7806() {
    ap_condition_7806 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter1.read()) && esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()));
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_done() {
    if (((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read())) || 
         (esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
          esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
          esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11279_pp0_iter2_reg.read())))) {
        ap_done = ap_const_logic_1;
    } else {
        ap_done = ap_const_logic_0;
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_enable_pp0() {
    ap_enable_pp0 = (ap_idle_pp0.read() ^ ap_const_logic_1);
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_enable_reg_pp0_iter0() {
    ap_enable_reg_pp0_iter0 = ap_start.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_idle() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()))) {
        ap_idle = ap_const_logic_1;
    } else {
        ap_idle = ap_const_logic_0;
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_idle_pp0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter2.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter3.read()))) {
        ap_idle_pp0 = ap_const_logic_1;
    } else {
        ap_idle_pp0 = ap_const_logic_0;
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_idle_pp0_0to2() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp0_iter2.read()))) {
        ap_idle_pp0_0to2 = ap_const_logic_1;
    } else {
        ap_idle_pp0_0to2 = ap_const_logic_0;
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_0_V_read26_phi_phi_fu_16898_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_0_V_read26_phi_phi_fu_16898_p4 = ap_phi_mux_data_0_V_read26_rewind_phi_fu_11298_p6.read();
    } else {
        ap_phi_mux_data_0_V_read26_phi_phi_fu_16898_p4 = ap_phi_reg_pp0_iter1_data_0_V_read26_phi_reg_16894.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_0_V_read26_rewind_phi_fu_11298_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_0_V_read26_rewind_phi_fu_11298_p6 = data_0_V_read26_phi_reg_16894.read();
    } else {
        ap_phi_mux_data_0_V_read26_rewind_phi_fu_11298_p6 = data_0_V_read26_rewind_reg_11294.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_100_V_read126_phi_phi_fu_18098_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_100_V_read126_phi_phi_fu_18098_p4 = ap_phi_mux_data_100_V_read126_rewind_phi_fu_12698_p6.read();
    } else {
        ap_phi_mux_data_100_V_read126_phi_phi_fu_18098_p4 = ap_phi_reg_pp0_iter1_data_100_V_read126_phi_reg_18094.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_100_V_read126_rewind_phi_fu_12698_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_100_V_read126_rewind_phi_fu_12698_p6 = data_100_V_read126_phi_reg_18094.read();
    } else {
        ap_phi_mux_data_100_V_read126_rewind_phi_fu_12698_p6 = data_100_V_read126_rewind_reg_12694.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_101_V_read127_phi_phi_fu_18110_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_101_V_read127_phi_phi_fu_18110_p4 = ap_phi_mux_data_101_V_read127_rewind_phi_fu_12712_p6.read();
    } else {
        ap_phi_mux_data_101_V_read127_phi_phi_fu_18110_p4 = ap_phi_reg_pp0_iter1_data_101_V_read127_phi_reg_18106.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_101_V_read127_rewind_phi_fu_12712_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_101_V_read127_rewind_phi_fu_12712_p6 = data_101_V_read127_phi_reg_18106.read();
    } else {
        ap_phi_mux_data_101_V_read127_rewind_phi_fu_12712_p6 = data_101_V_read127_rewind_reg_12708.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_102_V_read128_phi_phi_fu_18122_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_102_V_read128_phi_phi_fu_18122_p4 = ap_phi_mux_data_102_V_read128_rewind_phi_fu_12726_p6.read();
    } else {
        ap_phi_mux_data_102_V_read128_phi_phi_fu_18122_p4 = ap_phi_reg_pp0_iter1_data_102_V_read128_phi_reg_18118.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_102_V_read128_rewind_phi_fu_12726_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_102_V_read128_rewind_phi_fu_12726_p6 = data_102_V_read128_phi_reg_18118.read();
    } else {
        ap_phi_mux_data_102_V_read128_rewind_phi_fu_12726_p6 = data_102_V_read128_rewind_reg_12722.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_103_V_read129_phi_phi_fu_18134_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_103_V_read129_phi_phi_fu_18134_p4 = ap_phi_mux_data_103_V_read129_rewind_phi_fu_12740_p6.read();
    } else {
        ap_phi_mux_data_103_V_read129_phi_phi_fu_18134_p4 = ap_phi_reg_pp0_iter1_data_103_V_read129_phi_reg_18130.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_103_V_read129_rewind_phi_fu_12740_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_103_V_read129_rewind_phi_fu_12740_p6 = data_103_V_read129_phi_reg_18130.read();
    } else {
        ap_phi_mux_data_103_V_read129_rewind_phi_fu_12740_p6 = data_103_V_read129_rewind_reg_12736.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_104_V_read130_phi_phi_fu_18146_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_104_V_read130_phi_phi_fu_18146_p4 = ap_phi_mux_data_104_V_read130_rewind_phi_fu_12754_p6.read();
    } else {
        ap_phi_mux_data_104_V_read130_phi_phi_fu_18146_p4 = ap_phi_reg_pp0_iter1_data_104_V_read130_phi_reg_18142.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_104_V_read130_rewind_phi_fu_12754_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_104_V_read130_rewind_phi_fu_12754_p6 = data_104_V_read130_phi_reg_18142.read();
    } else {
        ap_phi_mux_data_104_V_read130_rewind_phi_fu_12754_p6 = data_104_V_read130_rewind_reg_12750.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_105_V_read131_phi_phi_fu_18158_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_105_V_read131_phi_phi_fu_18158_p4 = ap_phi_mux_data_105_V_read131_rewind_phi_fu_12768_p6.read();
    } else {
        ap_phi_mux_data_105_V_read131_phi_phi_fu_18158_p4 = ap_phi_reg_pp0_iter1_data_105_V_read131_phi_reg_18154.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_105_V_read131_rewind_phi_fu_12768_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_105_V_read131_rewind_phi_fu_12768_p6 = data_105_V_read131_phi_reg_18154.read();
    } else {
        ap_phi_mux_data_105_V_read131_rewind_phi_fu_12768_p6 = data_105_V_read131_rewind_reg_12764.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_106_V_read132_phi_phi_fu_18170_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_106_V_read132_phi_phi_fu_18170_p4 = ap_phi_mux_data_106_V_read132_rewind_phi_fu_12782_p6.read();
    } else {
        ap_phi_mux_data_106_V_read132_phi_phi_fu_18170_p4 = ap_phi_reg_pp0_iter1_data_106_V_read132_phi_reg_18166.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_106_V_read132_rewind_phi_fu_12782_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_106_V_read132_rewind_phi_fu_12782_p6 = data_106_V_read132_phi_reg_18166.read();
    } else {
        ap_phi_mux_data_106_V_read132_rewind_phi_fu_12782_p6 = data_106_V_read132_rewind_reg_12778.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_107_V_read133_phi_phi_fu_18182_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_107_V_read133_phi_phi_fu_18182_p4 = ap_phi_mux_data_107_V_read133_rewind_phi_fu_12796_p6.read();
    } else {
        ap_phi_mux_data_107_V_read133_phi_phi_fu_18182_p4 = ap_phi_reg_pp0_iter1_data_107_V_read133_phi_reg_18178.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_107_V_read133_rewind_phi_fu_12796_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_107_V_read133_rewind_phi_fu_12796_p6 = data_107_V_read133_phi_reg_18178.read();
    } else {
        ap_phi_mux_data_107_V_read133_rewind_phi_fu_12796_p6 = data_107_V_read133_rewind_reg_12792.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_108_V_read134_phi_phi_fu_18194_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_108_V_read134_phi_phi_fu_18194_p4 = ap_phi_mux_data_108_V_read134_rewind_phi_fu_12810_p6.read();
    } else {
        ap_phi_mux_data_108_V_read134_phi_phi_fu_18194_p4 = ap_phi_reg_pp0_iter1_data_108_V_read134_phi_reg_18190.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_108_V_read134_rewind_phi_fu_12810_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_108_V_read134_rewind_phi_fu_12810_p6 = data_108_V_read134_phi_reg_18190.read();
    } else {
        ap_phi_mux_data_108_V_read134_rewind_phi_fu_12810_p6 = data_108_V_read134_rewind_reg_12806.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_109_V_read135_phi_phi_fu_18206_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_109_V_read135_phi_phi_fu_18206_p4 = ap_phi_mux_data_109_V_read135_rewind_phi_fu_12824_p6.read();
    } else {
        ap_phi_mux_data_109_V_read135_phi_phi_fu_18206_p4 = ap_phi_reg_pp0_iter1_data_109_V_read135_phi_reg_18202.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_109_V_read135_rewind_phi_fu_12824_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_109_V_read135_rewind_phi_fu_12824_p6 = data_109_V_read135_phi_reg_18202.read();
    } else {
        ap_phi_mux_data_109_V_read135_rewind_phi_fu_12824_p6 = data_109_V_read135_rewind_reg_12820.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_10_V_read36_phi_phi_fu_17018_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_10_V_read36_phi_phi_fu_17018_p4 = ap_phi_mux_data_10_V_read36_rewind_phi_fu_11438_p6.read();
    } else {
        ap_phi_mux_data_10_V_read36_phi_phi_fu_17018_p4 = ap_phi_reg_pp0_iter1_data_10_V_read36_phi_reg_17014.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_10_V_read36_rewind_phi_fu_11438_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_10_V_read36_rewind_phi_fu_11438_p6 = data_10_V_read36_phi_reg_17014.read();
    } else {
        ap_phi_mux_data_10_V_read36_rewind_phi_fu_11438_p6 = data_10_V_read36_rewind_reg_11434.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_110_V_read136_phi_phi_fu_18218_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_110_V_read136_phi_phi_fu_18218_p4 = ap_phi_mux_data_110_V_read136_rewind_phi_fu_12838_p6.read();
    } else {
        ap_phi_mux_data_110_V_read136_phi_phi_fu_18218_p4 = ap_phi_reg_pp0_iter1_data_110_V_read136_phi_reg_18214.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_110_V_read136_rewind_phi_fu_12838_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_110_V_read136_rewind_phi_fu_12838_p6 = data_110_V_read136_phi_reg_18214.read();
    } else {
        ap_phi_mux_data_110_V_read136_rewind_phi_fu_12838_p6 = data_110_V_read136_rewind_reg_12834.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_111_V_read137_phi_phi_fu_18230_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_111_V_read137_phi_phi_fu_18230_p4 = ap_phi_mux_data_111_V_read137_rewind_phi_fu_12852_p6.read();
    } else {
        ap_phi_mux_data_111_V_read137_phi_phi_fu_18230_p4 = ap_phi_reg_pp0_iter1_data_111_V_read137_phi_reg_18226.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_111_V_read137_rewind_phi_fu_12852_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_111_V_read137_rewind_phi_fu_12852_p6 = data_111_V_read137_phi_reg_18226.read();
    } else {
        ap_phi_mux_data_111_V_read137_rewind_phi_fu_12852_p6 = data_111_V_read137_rewind_reg_12848.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_112_V_read138_phi_phi_fu_18242_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_112_V_read138_phi_phi_fu_18242_p4 = ap_phi_mux_data_112_V_read138_rewind_phi_fu_12866_p6.read();
    } else {
        ap_phi_mux_data_112_V_read138_phi_phi_fu_18242_p4 = ap_phi_reg_pp0_iter1_data_112_V_read138_phi_reg_18238.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_112_V_read138_rewind_phi_fu_12866_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_112_V_read138_rewind_phi_fu_12866_p6 = data_112_V_read138_phi_reg_18238.read();
    } else {
        ap_phi_mux_data_112_V_read138_rewind_phi_fu_12866_p6 = data_112_V_read138_rewind_reg_12862.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_113_V_read139_phi_phi_fu_18254_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_113_V_read139_phi_phi_fu_18254_p4 = ap_phi_mux_data_113_V_read139_rewind_phi_fu_12880_p6.read();
    } else {
        ap_phi_mux_data_113_V_read139_phi_phi_fu_18254_p4 = ap_phi_reg_pp0_iter1_data_113_V_read139_phi_reg_18250.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_113_V_read139_rewind_phi_fu_12880_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_113_V_read139_rewind_phi_fu_12880_p6 = data_113_V_read139_phi_reg_18250.read();
    } else {
        ap_phi_mux_data_113_V_read139_rewind_phi_fu_12880_p6 = data_113_V_read139_rewind_reg_12876.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_114_V_read140_phi_phi_fu_18266_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_114_V_read140_phi_phi_fu_18266_p4 = ap_phi_mux_data_114_V_read140_rewind_phi_fu_12894_p6.read();
    } else {
        ap_phi_mux_data_114_V_read140_phi_phi_fu_18266_p4 = ap_phi_reg_pp0_iter1_data_114_V_read140_phi_reg_18262.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_114_V_read140_rewind_phi_fu_12894_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_114_V_read140_rewind_phi_fu_12894_p6 = data_114_V_read140_phi_reg_18262.read();
    } else {
        ap_phi_mux_data_114_V_read140_rewind_phi_fu_12894_p6 = data_114_V_read140_rewind_reg_12890.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_115_V_read141_phi_phi_fu_18278_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_115_V_read141_phi_phi_fu_18278_p4 = ap_phi_mux_data_115_V_read141_rewind_phi_fu_12908_p6.read();
    } else {
        ap_phi_mux_data_115_V_read141_phi_phi_fu_18278_p4 = ap_phi_reg_pp0_iter1_data_115_V_read141_phi_reg_18274.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_115_V_read141_rewind_phi_fu_12908_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_115_V_read141_rewind_phi_fu_12908_p6 = data_115_V_read141_phi_reg_18274.read();
    } else {
        ap_phi_mux_data_115_V_read141_rewind_phi_fu_12908_p6 = data_115_V_read141_rewind_reg_12904.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_116_V_read142_phi_phi_fu_18290_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_116_V_read142_phi_phi_fu_18290_p4 = ap_phi_mux_data_116_V_read142_rewind_phi_fu_12922_p6.read();
    } else {
        ap_phi_mux_data_116_V_read142_phi_phi_fu_18290_p4 = ap_phi_reg_pp0_iter1_data_116_V_read142_phi_reg_18286.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_116_V_read142_rewind_phi_fu_12922_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_116_V_read142_rewind_phi_fu_12922_p6 = data_116_V_read142_phi_reg_18286.read();
    } else {
        ap_phi_mux_data_116_V_read142_rewind_phi_fu_12922_p6 = data_116_V_read142_rewind_reg_12918.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_117_V_read143_phi_phi_fu_18302_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_117_V_read143_phi_phi_fu_18302_p4 = ap_phi_mux_data_117_V_read143_rewind_phi_fu_12936_p6.read();
    } else {
        ap_phi_mux_data_117_V_read143_phi_phi_fu_18302_p4 = ap_phi_reg_pp0_iter1_data_117_V_read143_phi_reg_18298.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_117_V_read143_rewind_phi_fu_12936_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_117_V_read143_rewind_phi_fu_12936_p6 = data_117_V_read143_phi_reg_18298.read();
    } else {
        ap_phi_mux_data_117_V_read143_rewind_phi_fu_12936_p6 = data_117_V_read143_rewind_reg_12932.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_118_V_read144_phi_phi_fu_18314_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_118_V_read144_phi_phi_fu_18314_p4 = ap_phi_mux_data_118_V_read144_rewind_phi_fu_12950_p6.read();
    } else {
        ap_phi_mux_data_118_V_read144_phi_phi_fu_18314_p4 = ap_phi_reg_pp0_iter1_data_118_V_read144_phi_reg_18310.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_118_V_read144_rewind_phi_fu_12950_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_118_V_read144_rewind_phi_fu_12950_p6 = data_118_V_read144_phi_reg_18310.read();
    } else {
        ap_phi_mux_data_118_V_read144_rewind_phi_fu_12950_p6 = data_118_V_read144_rewind_reg_12946.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_119_V_read145_phi_phi_fu_18326_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_119_V_read145_phi_phi_fu_18326_p4 = ap_phi_mux_data_119_V_read145_rewind_phi_fu_12964_p6.read();
    } else {
        ap_phi_mux_data_119_V_read145_phi_phi_fu_18326_p4 = ap_phi_reg_pp0_iter1_data_119_V_read145_phi_reg_18322.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_119_V_read145_rewind_phi_fu_12964_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_119_V_read145_rewind_phi_fu_12964_p6 = data_119_V_read145_phi_reg_18322.read();
    } else {
        ap_phi_mux_data_119_V_read145_rewind_phi_fu_12964_p6 = data_119_V_read145_rewind_reg_12960.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_11_V_read37_phi_phi_fu_17030_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_11_V_read37_phi_phi_fu_17030_p4 = ap_phi_mux_data_11_V_read37_rewind_phi_fu_11452_p6.read();
    } else {
        ap_phi_mux_data_11_V_read37_phi_phi_fu_17030_p4 = ap_phi_reg_pp0_iter1_data_11_V_read37_phi_reg_17026.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_11_V_read37_rewind_phi_fu_11452_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_11_V_read37_rewind_phi_fu_11452_p6 = data_11_V_read37_phi_reg_17026.read();
    } else {
        ap_phi_mux_data_11_V_read37_rewind_phi_fu_11452_p6 = data_11_V_read37_rewind_reg_11448.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_120_V_read146_phi_phi_fu_18338_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_120_V_read146_phi_phi_fu_18338_p4 = ap_phi_mux_data_120_V_read146_rewind_phi_fu_12978_p6.read();
    } else {
        ap_phi_mux_data_120_V_read146_phi_phi_fu_18338_p4 = ap_phi_reg_pp0_iter1_data_120_V_read146_phi_reg_18334.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_120_V_read146_rewind_phi_fu_12978_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_120_V_read146_rewind_phi_fu_12978_p6 = data_120_V_read146_phi_reg_18334.read();
    } else {
        ap_phi_mux_data_120_V_read146_rewind_phi_fu_12978_p6 = data_120_V_read146_rewind_reg_12974.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_121_V_read147_phi_phi_fu_18350_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_121_V_read147_phi_phi_fu_18350_p4 = ap_phi_mux_data_121_V_read147_rewind_phi_fu_12992_p6.read();
    } else {
        ap_phi_mux_data_121_V_read147_phi_phi_fu_18350_p4 = ap_phi_reg_pp0_iter1_data_121_V_read147_phi_reg_18346.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_121_V_read147_rewind_phi_fu_12992_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_121_V_read147_rewind_phi_fu_12992_p6 = data_121_V_read147_phi_reg_18346.read();
    } else {
        ap_phi_mux_data_121_V_read147_rewind_phi_fu_12992_p6 = data_121_V_read147_rewind_reg_12988.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_122_V_read148_phi_phi_fu_18362_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_122_V_read148_phi_phi_fu_18362_p4 = ap_phi_mux_data_122_V_read148_rewind_phi_fu_13006_p6.read();
    } else {
        ap_phi_mux_data_122_V_read148_phi_phi_fu_18362_p4 = ap_phi_reg_pp0_iter1_data_122_V_read148_phi_reg_18358.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_122_V_read148_rewind_phi_fu_13006_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_122_V_read148_rewind_phi_fu_13006_p6 = data_122_V_read148_phi_reg_18358.read();
    } else {
        ap_phi_mux_data_122_V_read148_rewind_phi_fu_13006_p6 = data_122_V_read148_rewind_reg_13002.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_123_V_read149_phi_phi_fu_18374_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_123_V_read149_phi_phi_fu_18374_p4 = ap_phi_mux_data_123_V_read149_rewind_phi_fu_13020_p6.read();
    } else {
        ap_phi_mux_data_123_V_read149_phi_phi_fu_18374_p4 = ap_phi_reg_pp0_iter1_data_123_V_read149_phi_reg_18370.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_123_V_read149_rewind_phi_fu_13020_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_123_V_read149_rewind_phi_fu_13020_p6 = data_123_V_read149_phi_reg_18370.read();
    } else {
        ap_phi_mux_data_123_V_read149_rewind_phi_fu_13020_p6 = data_123_V_read149_rewind_reg_13016.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_124_V_read150_phi_phi_fu_18386_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_124_V_read150_phi_phi_fu_18386_p4 = ap_phi_mux_data_124_V_read150_rewind_phi_fu_13034_p6.read();
    } else {
        ap_phi_mux_data_124_V_read150_phi_phi_fu_18386_p4 = ap_phi_reg_pp0_iter1_data_124_V_read150_phi_reg_18382.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_124_V_read150_rewind_phi_fu_13034_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_124_V_read150_rewind_phi_fu_13034_p6 = data_124_V_read150_phi_reg_18382.read();
    } else {
        ap_phi_mux_data_124_V_read150_rewind_phi_fu_13034_p6 = data_124_V_read150_rewind_reg_13030.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_125_V_read151_phi_phi_fu_18398_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_125_V_read151_phi_phi_fu_18398_p4 = ap_phi_mux_data_125_V_read151_rewind_phi_fu_13048_p6.read();
    } else {
        ap_phi_mux_data_125_V_read151_phi_phi_fu_18398_p4 = ap_phi_reg_pp0_iter1_data_125_V_read151_phi_reg_18394.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_125_V_read151_rewind_phi_fu_13048_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_125_V_read151_rewind_phi_fu_13048_p6 = data_125_V_read151_phi_reg_18394.read();
    } else {
        ap_phi_mux_data_125_V_read151_rewind_phi_fu_13048_p6 = data_125_V_read151_rewind_reg_13044.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_126_V_read152_phi_phi_fu_18410_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_126_V_read152_phi_phi_fu_18410_p4 = ap_phi_mux_data_126_V_read152_rewind_phi_fu_13062_p6.read();
    } else {
        ap_phi_mux_data_126_V_read152_phi_phi_fu_18410_p4 = ap_phi_reg_pp0_iter1_data_126_V_read152_phi_reg_18406.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_126_V_read152_rewind_phi_fu_13062_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_126_V_read152_rewind_phi_fu_13062_p6 = data_126_V_read152_phi_reg_18406.read();
    } else {
        ap_phi_mux_data_126_V_read152_rewind_phi_fu_13062_p6 = data_126_V_read152_rewind_reg_13058.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_127_V_read153_phi_phi_fu_18422_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_127_V_read153_phi_phi_fu_18422_p4 = ap_phi_mux_data_127_V_read153_rewind_phi_fu_13076_p6.read();
    } else {
        ap_phi_mux_data_127_V_read153_phi_phi_fu_18422_p4 = ap_phi_reg_pp0_iter1_data_127_V_read153_phi_reg_18418.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_127_V_read153_rewind_phi_fu_13076_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_127_V_read153_rewind_phi_fu_13076_p6 = data_127_V_read153_phi_reg_18418.read();
    } else {
        ap_phi_mux_data_127_V_read153_rewind_phi_fu_13076_p6 = data_127_V_read153_rewind_reg_13072.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_128_V_read154_phi_phi_fu_18434_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_128_V_read154_phi_phi_fu_18434_p4 = ap_phi_mux_data_128_V_read154_rewind_phi_fu_13090_p6.read();
    } else {
        ap_phi_mux_data_128_V_read154_phi_phi_fu_18434_p4 = ap_phi_reg_pp0_iter1_data_128_V_read154_phi_reg_18430.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_128_V_read154_rewind_phi_fu_13090_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_128_V_read154_rewind_phi_fu_13090_p6 = data_128_V_read154_phi_reg_18430.read();
    } else {
        ap_phi_mux_data_128_V_read154_rewind_phi_fu_13090_p6 = data_128_V_read154_rewind_reg_13086.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_129_V_read155_phi_phi_fu_18446_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_129_V_read155_phi_phi_fu_18446_p4 = ap_phi_mux_data_129_V_read155_rewind_phi_fu_13104_p6.read();
    } else {
        ap_phi_mux_data_129_V_read155_phi_phi_fu_18446_p4 = ap_phi_reg_pp0_iter1_data_129_V_read155_phi_reg_18442.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_129_V_read155_rewind_phi_fu_13104_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_129_V_read155_rewind_phi_fu_13104_p6 = data_129_V_read155_phi_reg_18442.read();
    } else {
        ap_phi_mux_data_129_V_read155_rewind_phi_fu_13104_p6 = data_129_V_read155_rewind_reg_13100.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_12_V_read38_phi_phi_fu_17042_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_12_V_read38_phi_phi_fu_17042_p4 = ap_phi_mux_data_12_V_read38_rewind_phi_fu_11466_p6.read();
    } else {
        ap_phi_mux_data_12_V_read38_phi_phi_fu_17042_p4 = ap_phi_reg_pp0_iter1_data_12_V_read38_phi_reg_17038.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_12_V_read38_rewind_phi_fu_11466_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_12_V_read38_rewind_phi_fu_11466_p6 = data_12_V_read38_phi_reg_17038.read();
    } else {
        ap_phi_mux_data_12_V_read38_rewind_phi_fu_11466_p6 = data_12_V_read38_rewind_reg_11462.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_130_V_read156_phi_phi_fu_18458_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_130_V_read156_phi_phi_fu_18458_p4 = ap_phi_mux_data_130_V_read156_rewind_phi_fu_13118_p6.read();
    } else {
        ap_phi_mux_data_130_V_read156_phi_phi_fu_18458_p4 = ap_phi_reg_pp0_iter1_data_130_V_read156_phi_reg_18454.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_130_V_read156_rewind_phi_fu_13118_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_130_V_read156_rewind_phi_fu_13118_p6 = data_130_V_read156_phi_reg_18454.read();
    } else {
        ap_phi_mux_data_130_V_read156_rewind_phi_fu_13118_p6 = data_130_V_read156_rewind_reg_13114.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_131_V_read157_phi_phi_fu_18470_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_131_V_read157_phi_phi_fu_18470_p4 = ap_phi_mux_data_131_V_read157_rewind_phi_fu_13132_p6.read();
    } else {
        ap_phi_mux_data_131_V_read157_phi_phi_fu_18470_p4 = ap_phi_reg_pp0_iter1_data_131_V_read157_phi_reg_18466.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_131_V_read157_rewind_phi_fu_13132_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_131_V_read157_rewind_phi_fu_13132_p6 = data_131_V_read157_phi_reg_18466.read();
    } else {
        ap_phi_mux_data_131_V_read157_rewind_phi_fu_13132_p6 = data_131_V_read157_rewind_reg_13128.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_132_V_read158_phi_phi_fu_18482_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_132_V_read158_phi_phi_fu_18482_p4 = ap_phi_mux_data_132_V_read158_rewind_phi_fu_13146_p6.read();
    } else {
        ap_phi_mux_data_132_V_read158_phi_phi_fu_18482_p4 = ap_phi_reg_pp0_iter1_data_132_V_read158_phi_reg_18478.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_132_V_read158_rewind_phi_fu_13146_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_132_V_read158_rewind_phi_fu_13146_p6 = data_132_V_read158_phi_reg_18478.read();
    } else {
        ap_phi_mux_data_132_V_read158_rewind_phi_fu_13146_p6 = data_132_V_read158_rewind_reg_13142.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_133_V_read159_phi_phi_fu_18494_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_133_V_read159_phi_phi_fu_18494_p4 = ap_phi_mux_data_133_V_read159_rewind_phi_fu_13160_p6.read();
    } else {
        ap_phi_mux_data_133_V_read159_phi_phi_fu_18494_p4 = ap_phi_reg_pp0_iter1_data_133_V_read159_phi_reg_18490.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_133_V_read159_rewind_phi_fu_13160_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_133_V_read159_rewind_phi_fu_13160_p6 = data_133_V_read159_phi_reg_18490.read();
    } else {
        ap_phi_mux_data_133_V_read159_rewind_phi_fu_13160_p6 = data_133_V_read159_rewind_reg_13156.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_134_V_read160_phi_phi_fu_18506_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_134_V_read160_phi_phi_fu_18506_p4 = ap_phi_mux_data_134_V_read160_rewind_phi_fu_13174_p6.read();
    } else {
        ap_phi_mux_data_134_V_read160_phi_phi_fu_18506_p4 = ap_phi_reg_pp0_iter1_data_134_V_read160_phi_reg_18502.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_134_V_read160_rewind_phi_fu_13174_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_134_V_read160_rewind_phi_fu_13174_p6 = data_134_V_read160_phi_reg_18502.read();
    } else {
        ap_phi_mux_data_134_V_read160_rewind_phi_fu_13174_p6 = data_134_V_read160_rewind_reg_13170.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_135_V_read161_phi_phi_fu_18518_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_135_V_read161_phi_phi_fu_18518_p4 = ap_phi_mux_data_135_V_read161_rewind_phi_fu_13188_p6.read();
    } else {
        ap_phi_mux_data_135_V_read161_phi_phi_fu_18518_p4 = ap_phi_reg_pp0_iter1_data_135_V_read161_phi_reg_18514.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_135_V_read161_rewind_phi_fu_13188_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_135_V_read161_rewind_phi_fu_13188_p6 = data_135_V_read161_phi_reg_18514.read();
    } else {
        ap_phi_mux_data_135_V_read161_rewind_phi_fu_13188_p6 = data_135_V_read161_rewind_reg_13184.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_136_V_read162_phi_phi_fu_18530_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_136_V_read162_phi_phi_fu_18530_p4 = ap_phi_mux_data_136_V_read162_rewind_phi_fu_13202_p6.read();
    } else {
        ap_phi_mux_data_136_V_read162_phi_phi_fu_18530_p4 = ap_phi_reg_pp0_iter1_data_136_V_read162_phi_reg_18526.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_136_V_read162_rewind_phi_fu_13202_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_136_V_read162_rewind_phi_fu_13202_p6 = data_136_V_read162_phi_reg_18526.read();
    } else {
        ap_phi_mux_data_136_V_read162_rewind_phi_fu_13202_p6 = data_136_V_read162_rewind_reg_13198.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_137_V_read163_phi_phi_fu_18542_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_137_V_read163_phi_phi_fu_18542_p4 = ap_phi_mux_data_137_V_read163_rewind_phi_fu_13216_p6.read();
    } else {
        ap_phi_mux_data_137_V_read163_phi_phi_fu_18542_p4 = ap_phi_reg_pp0_iter1_data_137_V_read163_phi_reg_18538.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_137_V_read163_rewind_phi_fu_13216_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_137_V_read163_rewind_phi_fu_13216_p6 = data_137_V_read163_phi_reg_18538.read();
    } else {
        ap_phi_mux_data_137_V_read163_rewind_phi_fu_13216_p6 = data_137_V_read163_rewind_reg_13212.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_138_V_read164_phi_phi_fu_18554_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_138_V_read164_phi_phi_fu_18554_p4 = ap_phi_mux_data_138_V_read164_rewind_phi_fu_13230_p6.read();
    } else {
        ap_phi_mux_data_138_V_read164_phi_phi_fu_18554_p4 = ap_phi_reg_pp0_iter1_data_138_V_read164_phi_reg_18550.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_138_V_read164_rewind_phi_fu_13230_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_138_V_read164_rewind_phi_fu_13230_p6 = data_138_V_read164_phi_reg_18550.read();
    } else {
        ap_phi_mux_data_138_V_read164_rewind_phi_fu_13230_p6 = data_138_V_read164_rewind_reg_13226.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_139_V_read165_phi_phi_fu_18566_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_139_V_read165_phi_phi_fu_18566_p4 = ap_phi_mux_data_139_V_read165_rewind_phi_fu_13244_p6.read();
    } else {
        ap_phi_mux_data_139_V_read165_phi_phi_fu_18566_p4 = ap_phi_reg_pp0_iter1_data_139_V_read165_phi_reg_18562.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_139_V_read165_rewind_phi_fu_13244_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_139_V_read165_rewind_phi_fu_13244_p6 = data_139_V_read165_phi_reg_18562.read();
    } else {
        ap_phi_mux_data_139_V_read165_rewind_phi_fu_13244_p6 = data_139_V_read165_rewind_reg_13240.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_13_V_read39_phi_phi_fu_17054_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_13_V_read39_phi_phi_fu_17054_p4 = ap_phi_mux_data_13_V_read39_rewind_phi_fu_11480_p6.read();
    } else {
        ap_phi_mux_data_13_V_read39_phi_phi_fu_17054_p4 = ap_phi_reg_pp0_iter1_data_13_V_read39_phi_reg_17050.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_13_V_read39_rewind_phi_fu_11480_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_13_V_read39_rewind_phi_fu_11480_p6 = data_13_V_read39_phi_reg_17050.read();
    } else {
        ap_phi_mux_data_13_V_read39_rewind_phi_fu_11480_p6 = data_13_V_read39_rewind_reg_11476.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_140_V_read166_phi_phi_fu_18578_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_140_V_read166_phi_phi_fu_18578_p4 = ap_phi_mux_data_140_V_read166_rewind_phi_fu_13258_p6.read();
    } else {
        ap_phi_mux_data_140_V_read166_phi_phi_fu_18578_p4 = ap_phi_reg_pp0_iter1_data_140_V_read166_phi_reg_18574.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_140_V_read166_rewind_phi_fu_13258_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_140_V_read166_rewind_phi_fu_13258_p6 = data_140_V_read166_phi_reg_18574.read();
    } else {
        ap_phi_mux_data_140_V_read166_rewind_phi_fu_13258_p6 = data_140_V_read166_rewind_reg_13254.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_141_V_read167_phi_phi_fu_18590_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_141_V_read167_phi_phi_fu_18590_p4 = ap_phi_mux_data_141_V_read167_rewind_phi_fu_13272_p6.read();
    } else {
        ap_phi_mux_data_141_V_read167_phi_phi_fu_18590_p4 = ap_phi_reg_pp0_iter1_data_141_V_read167_phi_reg_18586.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_141_V_read167_rewind_phi_fu_13272_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_141_V_read167_rewind_phi_fu_13272_p6 = data_141_V_read167_phi_reg_18586.read();
    } else {
        ap_phi_mux_data_141_V_read167_rewind_phi_fu_13272_p6 = data_141_V_read167_rewind_reg_13268.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_142_V_read168_phi_phi_fu_18602_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_142_V_read168_phi_phi_fu_18602_p4 = ap_phi_mux_data_142_V_read168_rewind_phi_fu_13286_p6.read();
    } else {
        ap_phi_mux_data_142_V_read168_phi_phi_fu_18602_p4 = ap_phi_reg_pp0_iter1_data_142_V_read168_phi_reg_18598.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_142_V_read168_rewind_phi_fu_13286_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_142_V_read168_rewind_phi_fu_13286_p6 = data_142_V_read168_phi_reg_18598.read();
    } else {
        ap_phi_mux_data_142_V_read168_rewind_phi_fu_13286_p6 = data_142_V_read168_rewind_reg_13282.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_143_V_read169_phi_phi_fu_18614_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_143_V_read169_phi_phi_fu_18614_p4 = ap_phi_mux_data_143_V_read169_rewind_phi_fu_13300_p6.read();
    } else {
        ap_phi_mux_data_143_V_read169_phi_phi_fu_18614_p4 = ap_phi_reg_pp0_iter1_data_143_V_read169_phi_reg_18610.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_143_V_read169_rewind_phi_fu_13300_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_143_V_read169_rewind_phi_fu_13300_p6 = data_143_V_read169_phi_reg_18610.read();
    } else {
        ap_phi_mux_data_143_V_read169_rewind_phi_fu_13300_p6 = data_143_V_read169_rewind_reg_13296.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_144_V_read170_phi_phi_fu_18626_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_144_V_read170_phi_phi_fu_18626_p4 = ap_phi_mux_data_144_V_read170_rewind_phi_fu_13314_p6.read();
    } else {
        ap_phi_mux_data_144_V_read170_phi_phi_fu_18626_p4 = ap_phi_reg_pp0_iter1_data_144_V_read170_phi_reg_18622.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_144_V_read170_rewind_phi_fu_13314_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_144_V_read170_rewind_phi_fu_13314_p6 = data_144_V_read170_phi_reg_18622.read();
    } else {
        ap_phi_mux_data_144_V_read170_rewind_phi_fu_13314_p6 = data_144_V_read170_rewind_reg_13310.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_145_V_read171_phi_phi_fu_18638_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_145_V_read171_phi_phi_fu_18638_p4 = ap_phi_mux_data_145_V_read171_rewind_phi_fu_13328_p6.read();
    } else {
        ap_phi_mux_data_145_V_read171_phi_phi_fu_18638_p4 = ap_phi_reg_pp0_iter1_data_145_V_read171_phi_reg_18634.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_145_V_read171_rewind_phi_fu_13328_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_145_V_read171_rewind_phi_fu_13328_p6 = data_145_V_read171_phi_reg_18634.read();
    } else {
        ap_phi_mux_data_145_V_read171_rewind_phi_fu_13328_p6 = data_145_V_read171_rewind_reg_13324.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_146_V_read172_phi_phi_fu_18650_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_146_V_read172_phi_phi_fu_18650_p4 = ap_phi_mux_data_146_V_read172_rewind_phi_fu_13342_p6.read();
    } else {
        ap_phi_mux_data_146_V_read172_phi_phi_fu_18650_p4 = ap_phi_reg_pp0_iter1_data_146_V_read172_phi_reg_18646.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_146_V_read172_rewind_phi_fu_13342_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_146_V_read172_rewind_phi_fu_13342_p6 = data_146_V_read172_phi_reg_18646.read();
    } else {
        ap_phi_mux_data_146_V_read172_rewind_phi_fu_13342_p6 = data_146_V_read172_rewind_reg_13338.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_147_V_read173_phi_phi_fu_18662_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_147_V_read173_phi_phi_fu_18662_p4 = ap_phi_mux_data_147_V_read173_rewind_phi_fu_13356_p6.read();
    } else {
        ap_phi_mux_data_147_V_read173_phi_phi_fu_18662_p4 = ap_phi_reg_pp0_iter1_data_147_V_read173_phi_reg_18658.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_147_V_read173_rewind_phi_fu_13356_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_147_V_read173_rewind_phi_fu_13356_p6 = data_147_V_read173_phi_reg_18658.read();
    } else {
        ap_phi_mux_data_147_V_read173_rewind_phi_fu_13356_p6 = data_147_V_read173_rewind_reg_13352.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_148_V_read174_phi_phi_fu_18674_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_148_V_read174_phi_phi_fu_18674_p4 = ap_phi_mux_data_148_V_read174_rewind_phi_fu_13370_p6.read();
    } else {
        ap_phi_mux_data_148_V_read174_phi_phi_fu_18674_p4 = ap_phi_reg_pp0_iter1_data_148_V_read174_phi_reg_18670.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_148_V_read174_rewind_phi_fu_13370_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_148_V_read174_rewind_phi_fu_13370_p6 = data_148_V_read174_phi_reg_18670.read();
    } else {
        ap_phi_mux_data_148_V_read174_rewind_phi_fu_13370_p6 = data_148_V_read174_rewind_reg_13366.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_149_V_read175_phi_phi_fu_18686_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_149_V_read175_phi_phi_fu_18686_p4 = ap_phi_mux_data_149_V_read175_rewind_phi_fu_13384_p6.read();
    } else {
        ap_phi_mux_data_149_V_read175_phi_phi_fu_18686_p4 = ap_phi_reg_pp0_iter1_data_149_V_read175_phi_reg_18682.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_149_V_read175_rewind_phi_fu_13384_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_149_V_read175_rewind_phi_fu_13384_p6 = data_149_V_read175_phi_reg_18682.read();
    } else {
        ap_phi_mux_data_149_V_read175_rewind_phi_fu_13384_p6 = data_149_V_read175_rewind_reg_13380.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_14_V_read40_phi_phi_fu_17066_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_14_V_read40_phi_phi_fu_17066_p4 = ap_phi_mux_data_14_V_read40_rewind_phi_fu_11494_p6.read();
    } else {
        ap_phi_mux_data_14_V_read40_phi_phi_fu_17066_p4 = ap_phi_reg_pp0_iter1_data_14_V_read40_phi_reg_17062.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_14_V_read40_rewind_phi_fu_11494_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_14_V_read40_rewind_phi_fu_11494_p6 = data_14_V_read40_phi_reg_17062.read();
    } else {
        ap_phi_mux_data_14_V_read40_rewind_phi_fu_11494_p6 = data_14_V_read40_rewind_reg_11490.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_150_V_read176_phi_phi_fu_18698_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_150_V_read176_phi_phi_fu_18698_p4 = ap_phi_mux_data_150_V_read176_rewind_phi_fu_13398_p6.read();
    } else {
        ap_phi_mux_data_150_V_read176_phi_phi_fu_18698_p4 = ap_phi_reg_pp0_iter1_data_150_V_read176_phi_reg_18694.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_150_V_read176_rewind_phi_fu_13398_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_150_V_read176_rewind_phi_fu_13398_p6 = data_150_V_read176_phi_reg_18694.read();
    } else {
        ap_phi_mux_data_150_V_read176_rewind_phi_fu_13398_p6 = data_150_V_read176_rewind_reg_13394.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_151_V_read177_phi_phi_fu_18710_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_151_V_read177_phi_phi_fu_18710_p4 = ap_phi_mux_data_151_V_read177_rewind_phi_fu_13412_p6.read();
    } else {
        ap_phi_mux_data_151_V_read177_phi_phi_fu_18710_p4 = ap_phi_reg_pp0_iter1_data_151_V_read177_phi_reg_18706.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_151_V_read177_rewind_phi_fu_13412_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_151_V_read177_rewind_phi_fu_13412_p6 = data_151_V_read177_phi_reg_18706.read();
    } else {
        ap_phi_mux_data_151_V_read177_rewind_phi_fu_13412_p6 = data_151_V_read177_rewind_reg_13408.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_152_V_read178_phi_phi_fu_18722_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_152_V_read178_phi_phi_fu_18722_p4 = ap_phi_mux_data_152_V_read178_rewind_phi_fu_13426_p6.read();
    } else {
        ap_phi_mux_data_152_V_read178_phi_phi_fu_18722_p4 = ap_phi_reg_pp0_iter1_data_152_V_read178_phi_reg_18718.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_152_V_read178_rewind_phi_fu_13426_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_152_V_read178_rewind_phi_fu_13426_p6 = data_152_V_read178_phi_reg_18718.read();
    } else {
        ap_phi_mux_data_152_V_read178_rewind_phi_fu_13426_p6 = data_152_V_read178_rewind_reg_13422.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_153_V_read179_phi_phi_fu_18734_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_153_V_read179_phi_phi_fu_18734_p4 = ap_phi_mux_data_153_V_read179_rewind_phi_fu_13440_p6.read();
    } else {
        ap_phi_mux_data_153_V_read179_phi_phi_fu_18734_p4 = ap_phi_reg_pp0_iter1_data_153_V_read179_phi_reg_18730.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_153_V_read179_rewind_phi_fu_13440_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_153_V_read179_rewind_phi_fu_13440_p6 = data_153_V_read179_phi_reg_18730.read();
    } else {
        ap_phi_mux_data_153_V_read179_rewind_phi_fu_13440_p6 = data_153_V_read179_rewind_reg_13436.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_154_V_read180_phi_phi_fu_18746_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_154_V_read180_phi_phi_fu_18746_p4 = ap_phi_mux_data_154_V_read180_rewind_phi_fu_13454_p6.read();
    } else {
        ap_phi_mux_data_154_V_read180_phi_phi_fu_18746_p4 = ap_phi_reg_pp0_iter1_data_154_V_read180_phi_reg_18742.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_154_V_read180_rewind_phi_fu_13454_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_154_V_read180_rewind_phi_fu_13454_p6 = data_154_V_read180_phi_reg_18742.read();
    } else {
        ap_phi_mux_data_154_V_read180_rewind_phi_fu_13454_p6 = data_154_V_read180_rewind_reg_13450.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_155_V_read181_phi_phi_fu_18758_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_155_V_read181_phi_phi_fu_18758_p4 = ap_phi_mux_data_155_V_read181_rewind_phi_fu_13468_p6.read();
    } else {
        ap_phi_mux_data_155_V_read181_phi_phi_fu_18758_p4 = ap_phi_reg_pp0_iter1_data_155_V_read181_phi_reg_18754.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_155_V_read181_rewind_phi_fu_13468_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_155_V_read181_rewind_phi_fu_13468_p6 = data_155_V_read181_phi_reg_18754.read();
    } else {
        ap_phi_mux_data_155_V_read181_rewind_phi_fu_13468_p6 = data_155_V_read181_rewind_reg_13464.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_156_V_read182_phi_phi_fu_18770_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_156_V_read182_phi_phi_fu_18770_p4 = ap_phi_mux_data_156_V_read182_rewind_phi_fu_13482_p6.read();
    } else {
        ap_phi_mux_data_156_V_read182_phi_phi_fu_18770_p4 = ap_phi_reg_pp0_iter1_data_156_V_read182_phi_reg_18766.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_156_V_read182_rewind_phi_fu_13482_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_156_V_read182_rewind_phi_fu_13482_p6 = data_156_V_read182_phi_reg_18766.read();
    } else {
        ap_phi_mux_data_156_V_read182_rewind_phi_fu_13482_p6 = data_156_V_read182_rewind_reg_13478.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_157_V_read183_phi_phi_fu_18782_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_157_V_read183_phi_phi_fu_18782_p4 = ap_phi_mux_data_157_V_read183_rewind_phi_fu_13496_p6.read();
    } else {
        ap_phi_mux_data_157_V_read183_phi_phi_fu_18782_p4 = ap_phi_reg_pp0_iter1_data_157_V_read183_phi_reg_18778.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_157_V_read183_rewind_phi_fu_13496_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_157_V_read183_rewind_phi_fu_13496_p6 = data_157_V_read183_phi_reg_18778.read();
    } else {
        ap_phi_mux_data_157_V_read183_rewind_phi_fu_13496_p6 = data_157_V_read183_rewind_reg_13492.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_158_V_read184_phi_phi_fu_18794_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_158_V_read184_phi_phi_fu_18794_p4 = ap_phi_mux_data_158_V_read184_rewind_phi_fu_13510_p6.read();
    } else {
        ap_phi_mux_data_158_V_read184_phi_phi_fu_18794_p4 = ap_phi_reg_pp0_iter1_data_158_V_read184_phi_reg_18790.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_158_V_read184_rewind_phi_fu_13510_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_158_V_read184_rewind_phi_fu_13510_p6 = data_158_V_read184_phi_reg_18790.read();
    } else {
        ap_phi_mux_data_158_V_read184_rewind_phi_fu_13510_p6 = data_158_V_read184_rewind_reg_13506.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_159_V_read185_phi_phi_fu_18806_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_159_V_read185_phi_phi_fu_18806_p4 = ap_phi_mux_data_159_V_read185_rewind_phi_fu_13524_p6.read();
    } else {
        ap_phi_mux_data_159_V_read185_phi_phi_fu_18806_p4 = ap_phi_reg_pp0_iter1_data_159_V_read185_phi_reg_18802.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_159_V_read185_rewind_phi_fu_13524_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_159_V_read185_rewind_phi_fu_13524_p6 = data_159_V_read185_phi_reg_18802.read();
    } else {
        ap_phi_mux_data_159_V_read185_rewind_phi_fu_13524_p6 = data_159_V_read185_rewind_reg_13520.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_15_V_read41_phi_phi_fu_17078_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_15_V_read41_phi_phi_fu_17078_p4 = ap_phi_mux_data_15_V_read41_rewind_phi_fu_11508_p6.read();
    } else {
        ap_phi_mux_data_15_V_read41_phi_phi_fu_17078_p4 = ap_phi_reg_pp0_iter1_data_15_V_read41_phi_reg_17074.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_15_V_read41_rewind_phi_fu_11508_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_15_V_read41_rewind_phi_fu_11508_p6 = data_15_V_read41_phi_reg_17074.read();
    } else {
        ap_phi_mux_data_15_V_read41_rewind_phi_fu_11508_p6 = data_15_V_read41_rewind_reg_11504.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_160_V_read186_phi_phi_fu_18818_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_160_V_read186_phi_phi_fu_18818_p4 = ap_phi_mux_data_160_V_read186_rewind_phi_fu_13538_p6.read();
    } else {
        ap_phi_mux_data_160_V_read186_phi_phi_fu_18818_p4 = ap_phi_reg_pp0_iter1_data_160_V_read186_phi_reg_18814.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_160_V_read186_rewind_phi_fu_13538_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_160_V_read186_rewind_phi_fu_13538_p6 = data_160_V_read186_phi_reg_18814.read();
    } else {
        ap_phi_mux_data_160_V_read186_rewind_phi_fu_13538_p6 = data_160_V_read186_rewind_reg_13534.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_161_V_read187_phi_phi_fu_18830_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_161_V_read187_phi_phi_fu_18830_p4 = ap_phi_mux_data_161_V_read187_rewind_phi_fu_13552_p6.read();
    } else {
        ap_phi_mux_data_161_V_read187_phi_phi_fu_18830_p4 = ap_phi_reg_pp0_iter1_data_161_V_read187_phi_reg_18826.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_161_V_read187_rewind_phi_fu_13552_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_161_V_read187_rewind_phi_fu_13552_p6 = data_161_V_read187_phi_reg_18826.read();
    } else {
        ap_phi_mux_data_161_V_read187_rewind_phi_fu_13552_p6 = data_161_V_read187_rewind_reg_13548.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_162_V_read188_phi_phi_fu_18842_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_162_V_read188_phi_phi_fu_18842_p4 = ap_phi_mux_data_162_V_read188_rewind_phi_fu_13566_p6.read();
    } else {
        ap_phi_mux_data_162_V_read188_phi_phi_fu_18842_p4 = ap_phi_reg_pp0_iter1_data_162_V_read188_phi_reg_18838.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_162_V_read188_rewind_phi_fu_13566_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_162_V_read188_rewind_phi_fu_13566_p6 = data_162_V_read188_phi_reg_18838.read();
    } else {
        ap_phi_mux_data_162_V_read188_rewind_phi_fu_13566_p6 = data_162_V_read188_rewind_reg_13562.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_163_V_read189_phi_phi_fu_18854_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_163_V_read189_phi_phi_fu_18854_p4 = ap_phi_mux_data_163_V_read189_rewind_phi_fu_13580_p6.read();
    } else {
        ap_phi_mux_data_163_V_read189_phi_phi_fu_18854_p4 = ap_phi_reg_pp0_iter1_data_163_V_read189_phi_reg_18850.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_163_V_read189_rewind_phi_fu_13580_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_163_V_read189_rewind_phi_fu_13580_p6 = data_163_V_read189_phi_reg_18850.read();
    } else {
        ap_phi_mux_data_163_V_read189_rewind_phi_fu_13580_p6 = data_163_V_read189_rewind_reg_13576.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_164_V_read190_phi_phi_fu_18866_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_164_V_read190_phi_phi_fu_18866_p4 = ap_phi_mux_data_164_V_read190_rewind_phi_fu_13594_p6.read();
    } else {
        ap_phi_mux_data_164_V_read190_phi_phi_fu_18866_p4 = ap_phi_reg_pp0_iter1_data_164_V_read190_phi_reg_18862.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_164_V_read190_rewind_phi_fu_13594_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_164_V_read190_rewind_phi_fu_13594_p6 = data_164_V_read190_phi_reg_18862.read();
    } else {
        ap_phi_mux_data_164_V_read190_rewind_phi_fu_13594_p6 = data_164_V_read190_rewind_reg_13590.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_165_V_read191_phi_phi_fu_18878_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_165_V_read191_phi_phi_fu_18878_p4 = ap_phi_mux_data_165_V_read191_rewind_phi_fu_13608_p6.read();
    } else {
        ap_phi_mux_data_165_V_read191_phi_phi_fu_18878_p4 = ap_phi_reg_pp0_iter1_data_165_V_read191_phi_reg_18874.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_165_V_read191_rewind_phi_fu_13608_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_165_V_read191_rewind_phi_fu_13608_p6 = data_165_V_read191_phi_reg_18874.read();
    } else {
        ap_phi_mux_data_165_V_read191_rewind_phi_fu_13608_p6 = data_165_V_read191_rewind_reg_13604.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_166_V_read192_phi_phi_fu_18890_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_166_V_read192_phi_phi_fu_18890_p4 = ap_phi_mux_data_166_V_read192_rewind_phi_fu_13622_p6.read();
    } else {
        ap_phi_mux_data_166_V_read192_phi_phi_fu_18890_p4 = ap_phi_reg_pp0_iter1_data_166_V_read192_phi_reg_18886.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_166_V_read192_rewind_phi_fu_13622_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_166_V_read192_rewind_phi_fu_13622_p6 = data_166_V_read192_phi_reg_18886.read();
    } else {
        ap_phi_mux_data_166_V_read192_rewind_phi_fu_13622_p6 = data_166_V_read192_rewind_reg_13618.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_167_V_read193_phi_phi_fu_18902_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_167_V_read193_phi_phi_fu_18902_p4 = ap_phi_mux_data_167_V_read193_rewind_phi_fu_13636_p6.read();
    } else {
        ap_phi_mux_data_167_V_read193_phi_phi_fu_18902_p4 = ap_phi_reg_pp0_iter1_data_167_V_read193_phi_reg_18898.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_167_V_read193_rewind_phi_fu_13636_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_167_V_read193_rewind_phi_fu_13636_p6 = data_167_V_read193_phi_reg_18898.read();
    } else {
        ap_phi_mux_data_167_V_read193_rewind_phi_fu_13636_p6 = data_167_V_read193_rewind_reg_13632.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_168_V_read194_phi_phi_fu_18914_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_168_V_read194_phi_phi_fu_18914_p4 = ap_phi_mux_data_168_V_read194_rewind_phi_fu_13650_p6.read();
    } else {
        ap_phi_mux_data_168_V_read194_phi_phi_fu_18914_p4 = ap_phi_reg_pp0_iter1_data_168_V_read194_phi_reg_18910.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_168_V_read194_rewind_phi_fu_13650_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_168_V_read194_rewind_phi_fu_13650_p6 = data_168_V_read194_phi_reg_18910.read();
    } else {
        ap_phi_mux_data_168_V_read194_rewind_phi_fu_13650_p6 = data_168_V_read194_rewind_reg_13646.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_169_V_read195_phi_phi_fu_18926_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_169_V_read195_phi_phi_fu_18926_p4 = ap_phi_mux_data_169_V_read195_rewind_phi_fu_13664_p6.read();
    } else {
        ap_phi_mux_data_169_V_read195_phi_phi_fu_18926_p4 = ap_phi_reg_pp0_iter1_data_169_V_read195_phi_reg_18922.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_169_V_read195_rewind_phi_fu_13664_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_169_V_read195_rewind_phi_fu_13664_p6 = data_169_V_read195_phi_reg_18922.read();
    } else {
        ap_phi_mux_data_169_V_read195_rewind_phi_fu_13664_p6 = data_169_V_read195_rewind_reg_13660.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_16_V_read42_phi_phi_fu_17090_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_16_V_read42_phi_phi_fu_17090_p4 = ap_phi_mux_data_16_V_read42_rewind_phi_fu_11522_p6.read();
    } else {
        ap_phi_mux_data_16_V_read42_phi_phi_fu_17090_p4 = ap_phi_reg_pp0_iter1_data_16_V_read42_phi_reg_17086.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_16_V_read42_rewind_phi_fu_11522_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_16_V_read42_rewind_phi_fu_11522_p6 = data_16_V_read42_phi_reg_17086.read();
    } else {
        ap_phi_mux_data_16_V_read42_rewind_phi_fu_11522_p6 = data_16_V_read42_rewind_reg_11518.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_170_V_read196_phi_phi_fu_18938_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_170_V_read196_phi_phi_fu_18938_p4 = ap_phi_mux_data_170_V_read196_rewind_phi_fu_13678_p6.read();
    } else {
        ap_phi_mux_data_170_V_read196_phi_phi_fu_18938_p4 = ap_phi_reg_pp0_iter1_data_170_V_read196_phi_reg_18934.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_170_V_read196_rewind_phi_fu_13678_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_170_V_read196_rewind_phi_fu_13678_p6 = data_170_V_read196_phi_reg_18934.read();
    } else {
        ap_phi_mux_data_170_V_read196_rewind_phi_fu_13678_p6 = data_170_V_read196_rewind_reg_13674.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_171_V_read197_phi_phi_fu_18950_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_171_V_read197_phi_phi_fu_18950_p4 = ap_phi_mux_data_171_V_read197_rewind_phi_fu_13692_p6.read();
    } else {
        ap_phi_mux_data_171_V_read197_phi_phi_fu_18950_p4 = ap_phi_reg_pp0_iter1_data_171_V_read197_phi_reg_18946.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_171_V_read197_rewind_phi_fu_13692_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_171_V_read197_rewind_phi_fu_13692_p6 = data_171_V_read197_phi_reg_18946.read();
    } else {
        ap_phi_mux_data_171_V_read197_rewind_phi_fu_13692_p6 = data_171_V_read197_rewind_reg_13688.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_172_V_read198_phi_phi_fu_18962_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_172_V_read198_phi_phi_fu_18962_p4 = ap_phi_mux_data_172_V_read198_rewind_phi_fu_13706_p6.read();
    } else {
        ap_phi_mux_data_172_V_read198_phi_phi_fu_18962_p4 = ap_phi_reg_pp0_iter1_data_172_V_read198_phi_reg_18958.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_172_V_read198_rewind_phi_fu_13706_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_172_V_read198_rewind_phi_fu_13706_p6 = data_172_V_read198_phi_reg_18958.read();
    } else {
        ap_phi_mux_data_172_V_read198_rewind_phi_fu_13706_p6 = data_172_V_read198_rewind_reg_13702.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_173_V_read199_phi_phi_fu_18974_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_173_V_read199_phi_phi_fu_18974_p4 = ap_phi_mux_data_173_V_read199_rewind_phi_fu_13720_p6.read();
    } else {
        ap_phi_mux_data_173_V_read199_phi_phi_fu_18974_p4 = ap_phi_reg_pp0_iter1_data_173_V_read199_phi_reg_18970.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_173_V_read199_rewind_phi_fu_13720_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_173_V_read199_rewind_phi_fu_13720_p6 = data_173_V_read199_phi_reg_18970.read();
    } else {
        ap_phi_mux_data_173_V_read199_rewind_phi_fu_13720_p6 = data_173_V_read199_rewind_reg_13716.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_174_V_read200_phi_phi_fu_18986_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_174_V_read200_phi_phi_fu_18986_p4 = ap_phi_mux_data_174_V_read200_rewind_phi_fu_13734_p6.read();
    } else {
        ap_phi_mux_data_174_V_read200_phi_phi_fu_18986_p4 = ap_phi_reg_pp0_iter1_data_174_V_read200_phi_reg_18982.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_174_V_read200_rewind_phi_fu_13734_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_174_V_read200_rewind_phi_fu_13734_p6 = data_174_V_read200_phi_reg_18982.read();
    } else {
        ap_phi_mux_data_174_V_read200_rewind_phi_fu_13734_p6 = data_174_V_read200_rewind_reg_13730.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_175_V_read201_phi_phi_fu_18998_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_175_V_read201_phi_phi_fu_18998_p4 = ap_phi_mux_data_175_V_read201_rewind_phi_fu_13748_p6.read();
    } else {
        ap_phi_mux_data_175_V_read201_phi_phi_fu_18998_p4 = ap_phi_reg_pp0_iter1_data_175_V_read201_phi_reg_18994.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_175_V_read201_rewind_phi_fu_13748_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_175_V_read201_rewind_phi_fu_13748_p6 = data_175_V_read201_phi_reg_18994.read();
    } else {
        ap_phi_mux_data_175_V_read201_rewind_phi_fu_13748_p6 = data_175_V_read201_rewind_reg_13744.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_176_V_read202_phi_phi_fu_19010_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_176_V_read202_phi_phi_fu_19010_p4 = ap_phi_mux_data_176_V_read202_rewind_phi_fu_13762_p6.read();
    } else {
        ap_phi_mux_data_176_V_read202_phi_phi_fu_19010_p4 = ap_phi_reg_pp0_iter1_data_176_V_read202_phi_reg_19006.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_176_V_read202_rewind_phi_fu_13762_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_176_V_read202_rewind_phi_fu_13762_p6 = data_176_V_read202_phi_reg_19006.read();
    } else {
        ap_phi_mux_data_176_V_read202_rewind_phi_fu_13762_p6 = data_176_V_read202_rewind_reg_13758.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_177_V_read203_phi_phi_fu_19022_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_177_V_read203_phi_phi_fu_19022_p4 = ap_phi_mux_data_177_V_read203_rewind_phi_fu_13776_p6.read();
    } else {
        ap_phi_mux_data_177_V_read203_phi_phi_fu_19022_p4 = ap_phi_reg_pp0_iter1_data_177_V_read203_phi_reg_19018.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_177_V_read203_rewind_phi_fu_13776_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_177_V_read203_rewind_phi_fu_13776_p6 = data_177_V_read203_phi_reg_19018.read();
    } else {
        ap_phi_mux_data_177_V_read203_rewind_phi_fu_13776_p6 = data_177_V_read203_rewind_reg_13772.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_178_V_read204_phi_phi_fu_19034_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_178_V_read204_phi_phi_fu_19034_p4 = ap_phi_mux_data_178_V_read204_rewind_phi_fu_13790_p6.read();
    } else {
        ap_phi_mux_data_178_V_read204_phi_phi_fu_19034_p4 = ap_phi_reg_pp0_iter1_data_178_V_read204_phi_reg_19030.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_178_V_read204_rewind_phi_fu_13790_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_178_V_read204_rewind_phi_fu_13790_p6 = data_178_V_read204_phi_reg_19030.read();
    } else {
        ap_phi_mux_data_178_V_read204_rewind_phi_fu_13790_p6 = data_178_V_read204_rewind_reg_13786.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_179_V_read205_phi_phi_fu_19046_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_179_V_read205_phi_phi_fu_19046_p4 = ap_phi_mux_data_179_V_read205_rewind_phi_fu_13804_p6.read();
    } else {
        ap_phi_mux_data_179_V_read205_phi_phi_fu_19046_p4 = ap_phi_reg_pp0_iter1_data_179_V_read205_phi_reg_19042.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_179_V_read205_rewind_phi_fu_13804_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_179_V_read205_rewind_phi_fu_13804_p6 = data_179_V_read205_phi_reg_19042.read();
    } else {
        ap_phi_mux_data_179_V_read205_rewind_phi_fu_13804_p6 = data_179_V_read205_rewind_reg_13800.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_17_V_read43_phi_phi_fu_17102_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_17_V_read43_phi_phi_fu_17102_p4 = ap_phi_mux_data_17_V_read43_rewind_phi_fu_11536_p6.read();
    } else {
        ap_phi_mux_data_17_V_read43_phi_phi_fu_17102_p4 = ap_phi_reg_pp0_iter1_data_17_V_read43_phi_reg_17098.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_17_V_read43_rewind_phi_fu_11536_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_17_V_read43_rewind_phi_fu_11536_p6 = data_17_V_read43_phi_reg_17098.read();
    } else {
        ap_phi_mux_data_17_V_read43_rewind_phi_fu_11536_p6 = data_17_V_read43_rewind_reg_11532.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_180_V_read206_phi_phi_fu_19058_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_180_V_read206_phi_phi_fu_19058_p4 = ap_phi_mux_data_180_V_read206_rewind_phi_fu_13818_p6.read();
    } else {
        ap_phi_mux_data_180_V_read206_phi_phi_fu_19058_p4 = ap_phi_reg_pp0_iter1_data_180_V_read206_phi_reg_19054.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_180_V_read206_rewind_phi_fu_13818_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_180_V_read206_rewind_phi_fu_13818_p6 = data_180_V_read206_phi_reg_19054.read();
    } else {
        ap_phi_mux_data_180_V_read206_rewind_phi_fu_13818_p6 = data_180_V_read206_rewind_reg_13814.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_181_V_read207_phi_phi_fu_19070_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_181_V_read207_phi_phi_fu_19070_p4 = ap_phi_mux_data_181_V_read207_rewind_phi_fu_13832_p6.read();
    } else {
        ap_phi_mux_data_181_V_read207_phi_phi_fu_19070_p4 = ap_phi_reg_pp0_iter1_data_181_V_read207_phi_reg_19066.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_181_V_read207_rewind_phi_fu_13832_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_181_V_read207_rewind_phi_fu_13832_p6 = data_181_V_read207_phi_reg_19066.read();
    } else {
        ap_phi_mux_data_181_V_read207_rewind_phi_fu_13832_p6 = data_181_V_read207_rewind_reg_13828.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_182_V_read208_phi_phi_fu_19082_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_182_V_read208_phi_phi_fu_19082_p4 = ap_phi_mux_data_182_V_read208_rewind_phi_fu_13846_p6.read();
    } else {
        ap_phi_mux_data_182_V_read208_phi_phi_fu_19082_p4 = ap_phi_reg_pp0_iter1_data_182_V_read208_phi_reg_19078.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_182_V_read208_rewind_phi_fu_13846_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_182_V_read208_rewind_phi_fu_13846_p6 = data_182_V_read208_phi_reg_19078.read();
    } else {
        ap_phi_mux_data_182_V_read208_rewind_phi_fu_13846_p6 = data_182_V_read208_rewind_reg_13842.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_183_V_read209_phi_phi_fu_19094_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_183_V_read209_phi_phi_fu_19094_p4 = ap_phi_mux_data_183_V_read209_rewind_phi_fu_13860_p6.read();
    } else {
        ap_phi_mux_data_183_V_read209_phi_phi_fu_19094_p4 = ap_phi_reg_pp0_iter1_data_183_V_read209_phi_reg_19090.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_183_V_read209_rewind_phi_fu_13860_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_183_V_read209_rewind_phi_fu_13860_p6 = data_183_V_read209_phi_reg_19090.read();
    } else {
        ap_phi_mux_data_183_V_read209_rewind_phi_fu_13860_p6 = data_183_V_read209_rewind_reg_13856.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_184_V_read210_phi_phi_fu_19106_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_184_V_read210_phi_phi_fu_19106_p4 = ap_phi_mux_data_184_V_read210_rewind_phi_fu_13874_p6.read();
    } else {
        ap_phi_mux_data_184_V_read210_phi_phi_fu_19106_p4 = ap_phi_reg_pp0_iter1_data_184_V_read210_phi_reg_19102.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_184_V_read210_rewind_phi_fu_13874_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_184_V_read210_rewind_phi_fu_13874_p6 = data_184_V_read210_phi_reg_19102.read();
    } else {
        ap_phi_mux_data_184_V_read210_rewind_phi_fu_13874_p6 = data_184_V_read210_rewind_reg_13870.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_185_V_read211_phi_phi_fu_19118_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_185_V_read211_phi_phi_fu_19118_p4 = ap_phi_mux_data_185_V_read211_rewind_phi_fu_13888_p6.read();
    } else {
        ap_phi_mux_data_185_V_read211_phi_phi_fu_19118_p4 = ap_phi_reg_pp0_iter1_data_185_V_read211_phi_reg_19114.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_185_V_read211_rewind_phi_fu_13888_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_185_V_read211_rewind_phi_fu_13888_p6 = data_185_V_read211_phi_reg_19114.read();
    } else {
        ap_phi_mux_data_185_V_read211_rewind_phi_fu_13888_p6 = data_185_V_read211_rewind_reg_13884.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_186_V_read212_phi_phi_fu_19130_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_186_V_read212_phi_phi_fu_19130_p4 = ap_phi_mux_data_186_V_read212_rewind_phi_fu_13902_p6.read();
    } else {
        ap_phi_mux_data_186_V_read212_phi_phi_fu_19130_p4 = ap_phi_reg_pp0_iter1_data_186_V_read212_phi_reg_19126.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_186_V_read212_rewind_phi_fu_13902_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_186_V_read212_rewind_phi_fu_13902_p6 = data_186_V_read212_phi_reg_19126.read();
    } else {
        ap_phi_mux_data_186_V_read212_rewind_phi_fu_13902_p6 = data_186_V_read212_rewind_reg_13898.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_187_V_read213_phi_phi_fu_19142_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_187_V_read213_phi_phi_fu_19142_p4 = ap_phi_mux_data_187_V_read213_rewind_phi_fu_13916_p6.read();
    } else {
        ap_phi_mux_data_187_V_read213_phi_phi_fu_19142_p4 = ap_phi_reg_pp0_iter1_data_187_V_read213_phi_reg_19138.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_187_V_read213_rewind_phi_fu_13916_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_187_V_read213_rewind_phi_fu_13916_p6 = data_187_V_read213_phi_reg_19138.read();
    } else {
        ap_phi_mux_data_187_V_read213_rewind_phi_fu_13916_p6 = data_187_V_read213_rewind_reg_13912.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_188_V_read214_phi_phi_fu_19154_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_188_V_read214_phi_phi_fu_19154_p4 = ap_phi_mux_data_188_V_read214_rewind_phi_fu_13930_p6.read();
    } else {
        ap_phi_mux_data_188_V_read214_phi_phi_fu_19154_p4 = ap_phi_reg_pp0_iter1_data_188_V_read214_phi_reg_19150.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_188_V_read214_rewind_phi_fu_13930_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_188_V_read214_rewind_phi_fu_13930_p6 = data_188_V_read214_phi_reg_19150.read();
    } else {
        ap_phi_mux_data_188_V_read214_rewind_phi_fu_13930_p6 = data_188_V_read214_rewind_reg_13926.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_189_V_read215_phi_phi_fu_19166_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_189_V_read215_phi_phi_fu_19166_p4 = ap_phi_mux_data_189_V_read215_rewind_phi_fu_13944_p6.read();
    } else {
        ap_phi_mux_data_189_V_read215_phi_phi_fu_19166_p4 = ap_phi_reg_pp0_iter1_data_189_V_read215_phi_reg_19162.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_189_V_read215_rewind_phi_fu_13944_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_189_V_read215_rewind_phi_fu_13944_p6 = data_189_V_read215_phi_reg_19162.read();
    } else {
        ap_phi_mux_data_189_V_read215_rewind_phi_fu_13944_p6 = data_189_V_read215_rewind_reg_13940.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_18_V_read44_phi_phi_fu_17114_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_18_V_read44_phi_phi_fu_17114_p4 = ap_phi_mux_data_18_V_read44_rewind_phi_fu_11550_p6.read();
    } else {
        ap_phi_mux_data_18_V_read44_phi_phi_fu_17114_p4 = ap_phi_reg_pp0_iter1_data_18_V_read44_phi_reg_17110.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_18_V_read44_rewind_phi_fu_11550_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_18_V_read44_rewind_phi_fu_11550_p6 = data_18_V_read44_phi_reg_17110.read();
    } else {
        ap_phi_mux_data_18_V_read44_rewind_phi_fu_11550_p6 = data_18_V_read44_rewind_reg_11546.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_190_V_read216_phi_phi_fu_19178_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_190_V_read216_phi_phi_fu_19178_p4 = ap_phi_mux_data_190_V_read216_rewind_phi_fu_13958_p6.read();
    } else {
        ap_phi_mux_data_190_V_read216_phi_phi_fu_19178_p4 = ap_phi_reg_pp0_iter1_data_190_V_read216_phi_reg_19174.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_190_V_read216_rewind_phi_fu_13958_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_190_V_read216_rewind_phi_fu_13958_p6 = data_190_V_read216_phi_reg_19174.read();
    } else {
        ap_phi_mux_data_190_V_read216_rewind_phi_fu_13958_p6 = data_190_V_read216_rewind_reg_13954.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_191_V_read217_phi_phi_fu_19190_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_191_V_read217_phi_phi_fu_19190_p4 = ap_phi_mux_data_191_V_read217_rewind_phi_fu_13972_p6.read();
    } else {
        ap_phi_mux_data_191_V_read217_phi_phi_fu_19190_p4 = ap_phi_reg_pp0_iter1_data_191_V_read217_phi_reg_19186.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_191_V_read217_rewind_phi_fu_13972_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_191_V_read217_rewind_phi_fu_13972_p6 = data_191_V_read217_phi_reg_19186.read();
    } else {
        ap_phi_mux_data_191_V_read217_rewind_phi_fu_13972_p6 = data_191_V_read217_rewind_reg_13968.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_192_V_read218_phi_phi_fu_19202_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_192_V_read218_phi_phi_fu_19202_p4 = ap_phi_mux_data_192_V_read218_rewind_phi_fu_13986_p6.read();
    } else {
        ap_phi_mux_data_192_V_read218_phi_phi_fu_19202_p4 = ap_phi_reg_pp0_iter1_data_192_V_read218_phi_reg_19198.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_192_V_read218_rewind_phi_fu_13986_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_192_V_read218_rewind_phi_fu_13986_p6 = data_192_V_read218_phi_reg_19198.read();
    } else {
        ap_phi_mux_data_192_V_read218_rewind_phi_fu_13986_p6 = data_192_V_read218_rewind_reg_13982.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_193_V_read219_phi_phi_fu_19214_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_193_V_read219_phi_phi_fu_19214_p4 = ap_phi_mux_data_193_V_read219_rewind_phi_fu_14000_p6.read();
    } else {
        ap_phi_mux_data_193_V_read219_phi_phi_fu_19214_p4 = ap_phi_reg_pp0_iter1_data_193_V_read219_phi_reg_19210.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_193_V_read219_rewind_phi_fu_14000_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_193_V_read219_rewind_phi_fu_14000_p6 = data_193_V_read219_phi_reg_19210.read();
    } else {
        ap_phi_mux_data_193_V_read219_rewind_phi_fu_14000_p6 = data_193_V_read219_rewind_reg_13996.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_194_V_read220_phi_phi_fu_19226_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_194_V_read220_phi_phi_fu_19226_p4 = ap_phi_mux_data_194_V_read220_rewind_phi_fu_14014_p6.read();
    } else {
        ap_phi_mux_data_194_V_read220_phi_phi_fu_19226_p4 = ap_phi_reg_pp0_iter1_data_194_V_read220_phi_reg_19222.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_194_V_read220_rewind_phi_fu_14014_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_194_V_read220_rewind_phi_fu_14014_p6 = data_194_V_read220_phi_reg_19222.read();
    } else {
        ap_phi_mux_data_194_V_read220_rewind_phi_fu_14014_p6 = data_194_V_read220_rewind_reg_14010.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_195_V_read221_phi_phi_fu_19238_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_195_V_read221_phi_phi_fu_19238_p4 = ap_phi_mux_data_195_V_read221_rewind_phi_fu_14028_p6.read();
    } else {
        ap_phi_mux_data_195_V_read221_phi_phi_fu_19238_p4 = ap_phi_reg_pp0_iter1_data_195_V_read221_phi_reg_19234.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_195_V_read221_rewind_phi_fu_14028_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_195_V_read221_rewind_phi_fu_14028_p6 = data_195_V_read221_phi_reg_19234.read();
    } else {
        ap_phi_mux_data_195_V_read221_rewind_phi_fu_14028_p6 = data_195_V_read221_rewind_reg_14024.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_196_V_read222_phi_phi_fu_19250_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_196_V_read222_phi_phi_fu_19250_p4 = ap_phi_mux_data_196_V_read222_rewind_phi_fu_14042_p6.read();
    } else {
        ap_phi_mux_data_196_V_read222_phi_phi_fu_19250_p4 = ap_phi_reg_pp0_iter1_data_196_V_read222_phi_reg_19246.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_196_V_read222_rewind_phi_fu_14042_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_196_V_read222_rewind_phi_fu_14042_p6 = data_196_V_read222_phi_reg_19246.read();
    } else {
        ap_phi_mux_data_196_V_read222_rewind_phi_fu_14042_p6 = data_196_V_read222_rewind_reg_14038.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_197_V_read223_phi_phi_fu_19262_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_197_V_read223_phi_phi_fu_19262_p4 = ap_phi_mux_data_197_V_read223_rewind_phi_fu_14056_p6.read();
    } else {
        ap_phi_mux_data_197_V_read223_phi_phi_fu_19262_p4 = ap_phi_reg_pp0_iter1_data_197_V_read223_phi_reg_19258.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_197_V_read223_rewind_phi_fu_14056_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_197_V_read223_rewind_phi_fu_14056_p6 = data_197_V_read223_phi_reg_19258.read();
    } else {
        ap_phi_mux_data_197_V_read223_rewind_phi_fu_14056_p6 = data_197_V_read223_rewind_reg_14052.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_198_V_read224_phi_phi_fu_19274_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_198_V_read224_phi_phi_fu_19274_p4 = ap_phi_mux_data_198_V_read224_rewind_phi_fu_14070_p6.read();
    } else {
        ap_phi_mux_data_198_V_read224_phi_phi_fu_19274_p4 = ap_phi_reg_pp0_iter1_data_198_V_read224_phi_reg_19270.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_198_V_read224_rewind_phi_fu_14070_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_198_V_read224_rewind_phi_fu_14070_p6 = data_198_V_read224_phi_reg_19270.read();
    } else {
        ap_phi_mux_data_198_V_read224_rewind_phi_fu_14070_p6 = data_198_V_read224_rewind_reg_14066.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_199_V_read225_phi_phi_fu_19286_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_199_V_read225_phi_phi_fu_19286_p4 = ap_phi_mux_data_199_V_read225_rewind_phi_fu_14084_p6.read();
    } else {
        ap_phi_mux_data_199_V_read225_phi_phi_fu_19286_p4 = ap_phi_reg_pp0_iter1_data_199_V_read225_phi_reg_19282.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_199_V_read225_rewind_phi_fu_14084_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_199_V_read225_rewind_phi_fu_14084_p6 = data_199_V_read225_phi_reg_19282.read();
    } else {
        ap_phi_mux_data_199_V_read225_rewind_phi_fu_14084_p6 = data_199_V_read225_rewind_reg_14080.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_19_V_read45_phi_phi_fu_17126_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_19_V_read45_phi_phi_fu_17126_p4 = ap_phi_mux_data_19_V_read45_rewind_phi_fu_11564_p6.read();
    } else {
        ap_phi_mux_data_19_V_read45_phi_phi_fu_17126_p4 = ap_phi_reg_pp0_iter1_data_19_V_read45_phi_reg_17122.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_19_V_read45_rewind_phi_fu_11564_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_19_V_read45_rewind_phi_fu_11564_p6 = data_19_V_read45_phi_reg_17122.read();
    } else {
        ap_phi_mux_data_19_V_read45_rewind_phi_fu_11564_p6 = data_19_V_read45_rewind_reg_11560.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_1_V_read27_phi_phi_fu_16910_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_1_V_read27_phi_phi_fu_16910_p4 = ap_phi_mux_data_1_V_read27_rewind_phi_fu_11312_p6.read();
    } else {
        ap_phi_mux_data_1_V_read27_phi_phi_fu_16910_p4 = ap_phi_reg_pp0_iter1_data_1_V_read27_phi_reg_16906.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_1_V_read27_rewind_phi_fu_11312_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_1_V_read27_rewind_phi_fu_11312_p6 = data_1_V_read27_phi_reg_16906.read();
    } else {
        ap_phi_mux_data_1_V_read27_rewind_phi_fu_11312_p6 = data_1_V_read27_rewind_reg_11308.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_200_V_read226_phi_phi_fu_19298_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_200_V_read226_phi_phi_fu_19298_p4 = ap_phi_mux_data_200_V_read226_rewind_phi_fu_14098_p6.read();
    } else {
        ap_phi_mux_data_200_V_read226_phi_phi_fu_19298_p4 = ap_phi_reg_pp0_iter1_data_200_V_read226_phi_reg_19294.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_200_V_read226_rewind_phi_fu_14098_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_200_V_read226_rewind_phi_fu_14098_p6 = data_200_V_read226_phi_reg_19294.read();
    } else {
        ap_phi_mux_data_200_V_read226_rewind_phi_fu_14098_p6 = data_200_V_read226_rewind_reg_14094.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_201_V_read227_phi_phi_fu_19310_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_201_V_read227_phi_phi_fu_19310_p4 = ap_phi_mux_data_201_V_read227_rewind_phi_fu_14112_p6.read();
    } else {
        ap_phi_mux_data_201_V_read227_phi_phi_fu_19310_p4 = ap_phi_reg_pp0_iter1_data_201_V_read227_phi_reg_19306.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_201_V_read227_rewind_phi_fu_14112_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_201_V_read227_rewind_phi_fu_14112_p6 = data_201_V_read227_phi_reg_19306.read();
    } else {
        ap_phi_mux_data_201_V_read227_rewind_phi_fu_14112_p6 = data_201_V_read227_rewind_reg_14108.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_202_V_read228_phi_phi_fu_19322_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_202_V_read228_phi_phi_fu_19322_p4 = ap_phi_mux_data_202_V_read228_rewind_phi_fu_14126_p6.read();
    } else {
        ap_phi_mux_data_202_V_read228_phi_phi_fu_19322_p4 = ap_phi_reg_pp0_iter1_data_202_V_read228_phi_reg_19318.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_202_V_read228_rewind_phi_fu_14126_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_202_V_read228_rewind_phi_fu_14126_p6 = data_202_V_read228_phi_reg_19318.read();
    } else {
        ap_phi_mux_data_202_V_read228_rewind_phi_fu_14126_p6 = data_202_V_read228_rewind_reg_14122.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_203_V_read229_phi_phi_fu_19334_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_203_V_read229_phi_phi_fu_19334_p4 = ap_phi_mux_data_203_V_read229_rewind_phi_fu_14140_p6.read();
    } else {
        ap_phi_mux_data_203_V_read229_phi_phi_fu_19334_p4 = ap_phi_reg_pp0_iter1_data_203_V_read229_phi_reg_19330.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_203_V_read229_rewind_phi_fu_14140_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_203_V_read229_rewind_phi_fu_14140_p6 = data_203_V_read229_phi_reg_19330.read();
    } else {
        ap_phi_mux_data_203_V_read229_rewind_phi_fu_14140_p6 = data_203_V_read229_rewind_reg_14136.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_204_V_read230_phi_phi_fu_19346_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_204_V_read230_phi_phi_fu_19346_p4 = ap_phi_mux_data_204_V_read230_rewind_phi_fu_14154_p6.read();
    } else {
        ap_phi_mux_data_204_V_read230_phi_phi_fu_19346_p4 = ap_phi_reg_pp0_iter1_data_204_V_read230_phi_reg_19342.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_204_V_read230_rewind_phi_fu_14154_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_204_V_read230_rewind_phi_fu_14154_p6 = data_204_V_read230_phi_reg_19342.read();
    } else {
        ap_phi_mux_data_204_V_read230_rewind_phi_fu_14154_p6 = data_204_V_read230_rewind_reg_14150.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_205_V_read231_phi_phi_fu_19358_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_205_V_read231_phi_phi_fu_19358_p4 = ap_phi_mux_data_205_V_read231_rewind_phi_fu_14168_p6.read();
    } else {
        ap_phi_mux_data_205_V_read231_phi_phi_fu_19358_p4 = ap_phi_reg_pp0_iter1_data_205_V_read231_phi_reg_19354.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_205_V_read231_rewind_phi_fu_14168_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_205_V_read231_rewind_phi_fu_14168_p6 = data_205_V_read231_phi_reg_19354.read();
    } else {
        ap_phi_mux_data_205_V_read231_rewind_phi_fu_14168_p6 = data_205_V_read231_rewind_reg_14164.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_206_V_read232_phi_phi_fu_19370_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_206_V_read232_phi_phi_fu_19370_p4 = ap_phi_mux_data_206_V_read232_rewind_phi_fu_14182_p6.read();
    } else {
        ap_phi_mux_data_206_V_read232_phi_phi_fu_19370_p4 = ap_phi_reg_pp0_iter1_data_206_V_read232_phi_reg_19366.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_206_V_read232_rewind_phi_fu_14182_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_206_V_read232_rewind_phi_fu_14182_p6 = data_206_V_read232_phi_reg_19366.read();
    } else {
        ap_phi_mux_data_206_V_read232_rewind_phi_fu_14182_p6 = data_206_V_read232_rewind_reg_14178.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_207_V_read233_phi_phi_fu_19382_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_207_V_read233_phi_phi_fu_19382_p4 = ap_phi_mux_data_207_V_read233_rewind_phi_fu_14196_p6.read();
    } else {
        ap_phi_mux_data_207_V_read233_phi_phi_fu_19382_p4 = ap_phi_reg_pp0_iter1_data_207_V_read233_phi_reg_19378.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_207_V_read233_rewind_phi_fu_14196_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_207_V_read233_rewind_phi_fu_14196_p6 = data_207_V_read233_phi_reg_19378.read();
    } else {
        ap_phi_mux_data_207_V_read233_rewind_phi_fu_14196_p6 = data_207_V_read233_rewind_reg_14192.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_208_V_read234_phi_phi_fu_19394_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_208_V_read234_phi_phi_fu_19394_p4 = ap_phi_mux_data_208_V_read234_rewind_phi_fu_14210_p6.read();
    } else {
        ap_phi_mux_data_208_V_read234_phi_phi_fu_19394_p4 = ap_phi_reg_pp0_iter1_data_208_V_read234_phi_reg_19390.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_208_V_read234_rewind_phi_fu_14210_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_208_V_read234_rewind_phi_fu_14210_p6 = data_208_V_read234_phi_reg_19390.read();
    } else {
        ap_phi_mux_data_208_V_read234_rewind_phi_fu_14210_p6 = data_208_V_read234_rewind_reg_14206.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_209_V_read235_phi_phi_fu_19406_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_209_V_read235_phi_phi_fu_19406_p4 = ap_phi_mux_data_209_V_read235_rewind_phi_fu_14224_p6.read();
    } else {
        ap_phi_mux_data_209_V_read235_phi_phi_fu_19406_p4 = ap_phi_reg_pp0_iter1_data_209_V_read235_phi_reg_19402.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_209_V_read235_rewind_phi_fu_14224_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_209_V_read235_rewind_phi_fu_14224_p6 = data_209_V_read235_phi_reg_19402.read();
    } else {
        ap_phi_mux_data_209_V_read235_rewind_phi_fu_14224_p6 = data_209_V_read235_rewind_reg_14220.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_20_V_read46_phi_phi_fu_17138_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_20_V_read46_phi_phi_fu_17138_p4 = ap_phi_mux_data_20_V_read46_rewind_phi_fu_11578_p6.read();
    } else {
        ap_phi_mux_data_20_V_read46_phi_phi_fu_17138_p4 = ap_phi_reg_pp0_iter1_data_20_V_read46_phi_reg_17134.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_20_V_read46_rewind_phi_fu_11578_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_20_V_read46_rewind_phi_fu_11578_p6 = data_20_V_read46_phi_reg_17134.read();
    } else {
        ap_phi_mux_data_20_V_read46_rewind_phi_fu_11578_p6 = data_20_V_read46_rewind_reg_11574.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_210_V_read236_phi_phi_fu_19418_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_210_V_read236_phi_phi_fu_19418_p4 = ap_phi_mux_data_210_V_read236_rewind_phi_fu_14238_p6.read();
    } else {
        ap_phi_mux_data_210_V_read236_phi_phi_fu_19418_p4 = ap_phi_reg_pp0_iter1_data_210_V_read236_phi_reg_19414.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_210_V_read236_rewind_phi_fu_14238_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_210_V_read236_rewind_phi_fu_14238_p6 = data_210_V_read236_phi_reg_19414.read();
    } else {
        ap_phi_mux_data_210_V_read236_rewind_phi_fu_14238_p6 = data_210_V_read236_rewind_reg_14234.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_211_V_read237_phi_phi_fu_19430_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_211_V_read237_phi_phi_fu_19430_p4 = ap_phi_mux_data_211_V_read237_rewind_phi_fu_14252_p6.read();
    } else {
        ap_phi_mux_data_211_V_read237_phi_phi_fu_19430_p4 = ap_phi_reg_pp0_iter1_data_211_V_read237_phi_reg_19426.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_211_V_read237_rewind_phi_fu_14252_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_211_V_read237_rewind_phi_fu_14252_p6 = data_211_V_read237_phi_reg_19426.read();
    } else {
        ap_phi_mux_data_211_V_read237_rewind_phi_fu_14252_p6 = data_211_V_read237_rewind_reg_14248.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_212_V_read238_phi_phi_fu_19442_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_212_V_read238_phi_phi_fu_19442_p4 = ap_phi_mux_data_212_V_read238_rewind_phi_fu_14266_p6.read();
    } else {
        ap_phi_mux_data_212_V_read238_phi_phi_fu_19442_p4 = ap_phi_reg_pp0_iter1_data_212_V_read238_phi_reg_19438.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_212_V_read238_rewind_phi_fu_14266_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_212_V_read238_rewind_phi_fu_14266_p6 = data_212_V_read238_phi_reg_19438.read();
    } else {
        ap_phi_mux_data_212_V_read238_rewind_phi_fu_14266_p6 = data_212_V_read238_rewind_reg_14262.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_213_V_read239_phi_phi_fu_19454_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_213_V_read239_phi_phi_fu_19454_p4 = ap_phi_mux_data_213_V_read239_rewind_phi_fu_14280_p6.read();
    } else {
        ap_phi_mux_data_213_V_read239_phi_phi_fu_19454_p4 = ap_phi_reg_pp0_iter1_data_213_V_read239_phi_reg_19450.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_213_V_read239_rewind_phi_fu_14280_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_213_V_read239_rewind_phi_fu_14280_p6 = data_213_V_read239_phi_reg_19450.read();
    } else {
        ap_phi_mux_data_213_V_read239_rewind_phi_fu_14280_p6 = data_213_V_read239_rewind_reg_14276.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_214_V_read240_phi_phi_fu_19466_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_214_V_read240_phi_phi_fu_19466_p4 = ap_phi_mux_data_214_V_read240_rewind_phi_fu_14294_p6.read();
    } else {
        ap_phi_mux_data_214_V_read240_phi_phi_fu_19466_p4 = ap_phi_reg_pp0_iter1_data_214_V_read240_phi_reg_19462.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_214_V_read240_rewind_phi_fu_14294_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_214_V_read240_rewind_phi_fu_14294_p6 = data_214_V_read240_phi_reg_19462.read();
    } else {
        ap_phi_mux_data_214_V_read240_rewind_phi_fu_14294_p6 = data_214_V_read240_rewind_reg_14290.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_215_V_read241_phi_phi_fu_19478_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_215_V_read241_phi_phi_fu_19478_p4 = ap_phi_mux_data_215_V_read241_rewind_phi_fu_14308_p6.read();
    } else {
        ap_phi_mux_data_215_V_read241_phi_phi_fu_19478_p4 = ap_phi_reg_pp0_iter1_data_215_V_read241_phi_reg_19474.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_215_V_read241_rewind_phi_fu_14308_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_215_V_read241_rewind_phi_fu_14308_p6 = data_215_V_read241_phi_reg_19474.read();
    } else {
        ap_phi_mux_data_215_V_read241_rewind_phi_fu_14308_p6 = data_215_V_read241_rewind_reg_14304.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_216_V_read242_phi_phi_fu_19490_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_216_V_read242_phi_phi_fu_19490_p4 = ap_phi_mux_data_216_V_read242_rewind_phi_fu_14322_p6.read();
    } else {
        ap_phi_mux_data_216_V_read242_phi_phi_fu_19490_p4 = ap_phi_reg_pp0_iter1_data_216_V_read242_phi_reg_19486.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_216_V_read242_rewind_phi_fu_14322_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_216_V_read242_rewind_phi_fu_14322_p6 = data_216_V_read242_phi_reg_19486.read();
    } else {
        ap_phi_mux_data_216_V_read242_rewind_phi_fu_14322_p6 = data_216_V_read242_rewind_reg_14318.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_217_V_read243_phi_phi_fu_19502_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_217_V_read243_phi_phi_fu_19502_p4 = ap_phi_mux_data_217_V_read243_rewind_phi_fu_14336_p6.read();
    } else {
        ap_phi_mux_data_217_V_read243_phi_phi_fu_19502_p4 = ap_phi_reg_pp0_iter1_data_217_V_read243_phi_reg_19498.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_217_V_read243_rewind_phi_fu_14336_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_217_V_read243_rewind_phi_fu_14336_p6 = data_217_V_read243_phi_reg_19498.read();
    } else {
        ap_phi_mux_data_217_V_read243_rewind_phi_fu_14336_p6 = data_217_V_read243_rewind_reg_14332.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_218_V_read244_phi_phi_fu_19514_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_218_V_read244_phi_phi_fu_19514_p4 = ap_phi_mux_data_218_V_read244_rewind_phi_fu_14350_p6.read();
    } else {
        ap_phi_mux_data_218_V_read244_phi_phi_fu_19514_p4 = ap_phi_reg_pp0_iter1_data_218_V_read244_phi_reg_19510.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_218_V_read244_rewind_phi_fu_14350_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_218_V_read244_rewind_phi_fu_14350_p6 = data_218_V_read244_phi_reg_19510.read();
    } else {
        ap_phi_mux_data_218_V_read244_rewind_phi_fu_14350_p6 = data_218_V_read244_rewind_reg_14346.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_219_V_read245_phi_phi_fu_19526_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_219_V_read245_phi_phi_fu_19526_p4 = ap_phi_mux_data_219_V_read245_rewind_phi_fu_14364_p6.read();
    } else {
        ap_phi_mux_data_219_V_read245_phi_phi_fu_19526_p4 = ap_phi_reg_pp0_iter1_data_219_V_read245_phi_reg_19522.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_219_V_read245_rewind_phi_fu_14364_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_219_V_read245_rewind_phi_fu_14364_p6 = data_219_V_read245_phi_reg_19522.read();
    } else {
        ap_phi_mux_data_219_V_read245_rewind_phi_fu_14364_p6 = data_219_V_read245_rewind_reg_14360.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_21_V_read47_phi_phi_fu_17150_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_21_V_read47_phi_phi_fu_17150_p4 = ap_phi_mux_data_21_V_read47_rewind_phi_fu_11592_p6.read();
    } else {
        ap_phi_mux_data_21_V_read47_phi_phi_fu_17150_p4 = ap_phi_reg_pp0_iter1_data_21_V_read47_phi_reg_17146.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_21_V_read47_rewind_phi_fu_11592_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_21_V_read47_rewind_phi_fu_11592_p6 = data_21_V_read47_phi_reg_17146.read();
    } else {
        ap_phi_mux_data_21_V_read47_rewind_phi_fu_11592_p6 = data_21_V_read47_rewind_reg_11588.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_220_V_read246_phi_phi_fu_19538_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_220_V_read246_phi_phi_fu_19538_p4 = ap_phi_mux_data_220_V_read246_rewind_phi_fu_14378_p6.read();
    } else {
        ap_phi_mux_data_220_V_read246_phi_phi_fu_19538_p4 = ap_phi_reg_pp0_iter1_data_220_V_read246_phi_reg_19534.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_220_V_read246_rewind_phi_fu_14378_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_220_V_read246_rewind_phi_fu_14378_p6 = data_220_V_read246_phi_reg_19534.read();
    } else {
        ap_phi_mux_data_220_V_read246_rewind_phi_fu_14378_p6 = data_220_V_read246_rewind_reg_14374.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_221_V_read247_phi_phi_fu_19550_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_221_V_read247_phi_phi_fu_19550_p4 = ap_phi_mux_data_221_V_read247_rewind_phi_fu_14392_p6.read();
    } else {
        ap_phi_mux_data_221_V_read247_phi_phi_fu_19550_p4 = ap_phi_reg_pp0_iter1_data_221_V_read247_phi_reg_19546.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_221_V_read247_rewind_phi_fu_14392_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_221_V_read247_rewind_phi_fu_14392_p6 = data_221_V_read247_phi_reg_19546.read();
    } else {
        ap_phi_mux_data_221_V_read247_rewind_phi_fu_14392_p6 = data_221_V_read247_rewind_reg_14388.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_222_V_read248_phi_phi_fu_19562_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_222_V_read248_phi_phi_fu_19562_p4 = ap_phi_mux_data_222_V_read248_rewind_phi_fu_14406_p6.read();
    } else {
        ap_phi_mux_data_222_V_read248_phi_phi_fu_19562_p4 = ap_phi_reg_pp0_iter1_data_222_V_read248_phi_reg_19558.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_222_V_read248_rewind_phi_fu_14406_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_222_V_read248_rewind_phi_fu_14406_p6 = data_222_V_read248_phi_reg_19558.read();
    } else {
        ap_phi_mux_data_222_V_read248_rewind_phi_fu_14406_p6 = data_222_V_read248_rewind_reg_14402.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_223_V_read249_phi_phi_fu_19574_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_223_V_read249_phi_phi_fu_19574_p4 = ap_phi_mux_data_223_V_read249_rewind_phi_fu_14420_p6.read();
    } else {
        ap_phi_mux_data_223_V_read249_phi_phi_fu_19574_p4 = ap_phi_reg_pp0_iter1_data_223_V_read249_phi_reg_19570.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_223_V_read249_rewind_phi_fu_14420_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_223_V_read249_rewind_phi_fu_14420_p6 = data_223_V_read249_phi_reg_19570.read();
    } else {
        ap_phi_mux_data_223_V_read249_rewind_phi_fu_14420_p6 = data_223_V_read249_rewind_reg_14416.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_224_V_read250_phi_phi_fu_19586_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_224_V_read250_phi_phi_fu_19586_p4 = ap_phi_mux_data_224_V_read250_rewind_phi_fu_14434_p6.read();
    } else {
        ap_phi_mux_data_224_V_read250_phi_phi_fu_19586_p4 = ap_phi_reg_pp0_iter1_data_224_V_read250_phi_reg_19582.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_224_V_read250_rewind_phi_fu_14434_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_224_V_read250_rewind_phi_fu_14434_p6 = data_224_V_read250_phi_reg_19582.read();
    } else {
        ap_phi_mux_data_224_V_read250_rewind_phi_fu_14434_p6 = data_224_V_read250_rewind_reg_14430.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_225_V_read251_phi_phi_fu_19598_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_225_V_read251_phi_phi_fu_19598_p4 = ap_phi_mux_data_225_V_read251_rewind_phi_fu_14448_p6.read();
    } else {
        ap_phi_mux_data_225_V_read251_phi_phi_fu_19598_p4 = ap_phi_reg_pp0_iter1_data_225_V_read251_phi_reg_19594.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_225_V_read251_rewind_phi_fu_14448_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_225_V_read251_rewind_phi_fu_14448_p6 = data_225_V_read251_phi_reg_19594.read();
    } else {
        ap_phi_mux_data_225_V_read251_rewind_phi_fu_14448_p6 = data_225_V_read251_rewind_reg_14444.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_226_V_read252_phi_phi_fu_19610_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_226_V_read252_phi_phi_fu_19610_p4 = ap_phi_mux_data_226_V_read252_rewind_phi_fu_14462_p6.read();
    } else {
        ap_phi_mux_data_226_V_read252_phi_phi_fu_19610_p4 = ap_phi_reg_pp0_iter1_data_226_V_read252_phi_reg_19606.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_226_V_read252_rewind_phi_fu_14462_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_226_V_read252_rewind_phi_fu_14462_p6 = data_226_V_read252_phi_reg_19606.read();
    } else {
        ap_phi_mux_data_226_V_read252_rewind_phi_fu_14462_p6 = data_226_V_read252_rewind_reg_14458.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_227_V_read253_phi_phi_fu_19622_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_227_V_read253_phi_phi_fu_19622_p4 = ap_phi_mux_data_227_V_read253_rewind_phi_fu_14476_p6.read();
    } else {
        ap_phi_mux_data_227_V_read253_phi_phi_fu_19622_p4 = ap_phi_reg_pp0_iter1_data_227_V_read253_phi_reg_19618.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_227_V_read253_rewind_phi_fu_14476_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_227_V_read253_rewind_phi_fu_14476_p6 = data_227_V_read253_phi_reg_19618.read();
    } else {
        ap_phi_mux_data_227_V_read253_rewind_phi_fu_14476_p6 = data_227_V_read253_rewind_reg_14472.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_228_V_read254_phi_phi_fu_19634_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_228_V_read254_phi_phi_fu_19634_p4 = ap_phi_mux_data_228_V_read254_rewind_phi_fu_14490_p6.read();
    } else {
        ap_phi_mux_data_228_V_read254_phi_phi_fu_19634_p4 = ap_phi_reg_pp0_iter1_data_228_V_read254_phi_reg_19630.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_228_V_read254_rewind_phi_fu_14490_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_228_V_read254_rewind_phi_fu_14490_p6 = data_228_V_read254_phi_reg_19630.read();
    } else {
        ap_phi_mux_data_228_V_read254_rewind_phi_fu_14490_p6 = data_228_V_read254_rewind_reg_14486.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_229_V_read255_phi_phi_fu_19646_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_229_V_read255_phi_phi_fu_19646_p4 = ap_phi_mux_data_229_V_read255_rewind_phi_fu_14504_p6.read();
    } else {
        ap_phi_mux_data_229_V_read255_phi_phi_fu_19646_p4 = ap_phi_reg_pp0_iter1_data_229_V_read255_phi_reg_19642.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_229_V_read255_rewind_phi_fu_14504_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_229_V_read255_rewind_phi_fu_14504_p6 = data_229_V_read255_phi_reg_19642.read();
    } else {
        ap_phi_mux_data_229_V_read255_rewind_phi_fu_14504_p6 = data_229_V_read255_rewind_reg_14500.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_22_V_read48_phi_phi_fu_17162_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_22_V_read48_phi_phi_fu_17162_p4 = ap_phi_mux_data_22_V_read48_rewind_phi_fu_11606_p6.read();
    } else {
        ap_phi_mux_data_22_V_read48_phi_phi_fu_17162_p4 = ap_phi_reg_pp0_iter1_data_22_V_read48_phi_reg_17158.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_22_V_read48_rewind_phi_fu_11606_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_22_V_read48_rewind_phi_fu_11606_p6 = data_22_V_read48_phi_reg_17158.read();
    } else {
        ap_phi_mux_data_22_V_read48_rewind_phi_fu_11606_p6 = data_22_V_read48_rewind_reg_11602.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_230_V_read256_phi_phi_fu_19658_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_230_V_read256_phi_phi_fu_19658_p4 = ap_phi_mux_data_230_V_read256_rewind_phi_fu_14518_p6.read();
    } else {
        ap_phi_mux_data_230_V_read256_phi_phi_fu_19658_p4 = ap_phi_reg_pp0_iter1_data_230_V_read256_phi_reg_19654.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_230_V_read256_rewind_phi_fu_14518_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_230_V_read256_rewind_phi_fu_14518_p6 = data_230_V_read256_phi_reg_19654.read();
    } else {
        ap_phi_mux_data_230_V_read256_rewind_phi_fu_14518_p6 = data_230_V_read256_rewind_reg_14514.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_231_V_read257_phi_phi_fu_19670_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_231_V_read257_phi_phi_fu_19670_p4 = ap_phi_mux_data_231_V_read257_rewind_phi_fu_14532_p6.read();
    } else {
        ap_phi_mux_data_231_V_read257_phi_phi_fu_19670_p4 = ap_phi_reg_pp0_iter1_data_231_V_read257_phi_reg_19666.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_231_V_read257_rewind_phi_fu_14532_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_231_V_read257_rewind_phi_fu_14532_p6 = data_231_V_read257_phi_reg_19666.read();
    } else {
        ap_phi_mux_data_231_V_read257_rewind_phi_fu_14532_p6 = data_231_V_read257_rewind_reg_14528.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_232_V_read258_phi_phi_fu_19682_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_232_V_read258_phi_phi_fu_19682_p4 = ap_phi_mux_data_232_V_read258_rewind_phi_fu_14546_p6.read();
    } else {
        ap_phi_mux_data_232_V_read258_phi_phi_fu_19682_p4 = ap_phi_reg_pp0_iter1_data_232_V_read258_phi_reg_19678.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_232_V_read258_rewind_phi_fu_14546_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_232_V_read258_rewind_phi_fu_14546_p6 = data_232_V_read258_phi_reg_19678.read();
    } else {
        ap_phi_mux_data_232_V_read258_rewind_phi_fu_14546_p6 = data_232_V_read258_rewind_reg_14542.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_233_V_read259_phi_phi_fu_19694_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_233_V_read259_phi_phi_fu_19694_p4 = ap_phi_mux_data_233_V_read259_rewind_phi_fu_14560_p6.read();
    } else {
        ap_phi_mux_data_233_V_read259_phi_phi_fu_19694_p4 = ap_phi_reg_pp0_iter1_data_233_V_read259_phi_reg_19690.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_233_V_read259_rewind_phi_fu_14560_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_233_V_read259_rewind_phi_fu_14560_p6 = data_233_V_read259_phi_reg_19690.read();
    } else {
        ap_phi_mux_data_233_V_read259_rewind_phi_fu_14560_p6 = data_233_V_read259_rewind_reg_14556.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_234_V_read260_phi_phi_fu_19706_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_234_V_read260_phi_phi_fu_19706_p4 = ap_phi_mux_data_234_V_read260_rewind_phi_fu_14574_p6.read();
    } else {
        ap_phi_mux_data_234_V_read260_phi_phi_fu_19706_p4 = ap_phi_reg_pp0_iter1_data_234_V_read260_phi_reg_19702.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_234_V_read260_rewind_phi_fu_14574_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_234_V_read260_rewind_phi_fu_14574_p6 = data_234_V_read260_phi_reg_19702.read();
    } else {
        ap_phi_mux_data_234_V_read260_rewind_phi_fu_14574_p6 = data_234_V_read260_rewind_reg_14570.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_235_V_read261_phi_phi_fu_19718_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_235_V_read261_phi_phi_fu_19718_p4 = ap_phi_mux_data_235_V_read261_rewind_phi_fu_14588_p6.read();
    } else {
        ap_phi_mux_data_235_V_read261_phi_phi_fu_19718_p4 = ap_phi_reg_pp0_iter1_data_235_V_read261_phi_reg_19714.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_235_V_read261_rewind_phi_fu_14588_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_235_V_read261_rewind_phi_fu_14588_p6 = data_235_V_read261_phi_reg_19714.read();
    } else {
        ap_phi_mux_data_235_V_read261_rewind_phi_fu_14588_p6 = data_235_V_read261_rewind_reg_14584.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_236_V_read262_phi_phi_fu_19730_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_236_V_read262_phi_phi_fu_19730_p4 = ap_phi_mux_data_236_V_read262_rewind_phi_fu_14602_p6.read();
    } else {
        ap_phi_mux_data_236_V_read262_phi_phi_fu_19730_p4 = ap_phi_reg_pp0_iter1_data_236_V_read262_phi_reg_19726.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_236_V_read262_rewind_phi_fu_14602_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_236_V_read262_rewind_phi_fu_14602_p6 = data_236_V_read262_phi_reg_19726.read();
    } else {
        ap_phi_mux_data_236_V_read262_rewind_phi_fu_14602_p6 = data_236_V_read262_rewind_reg_14598.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_237_V_read263_phi_phi_fu_19742_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_237_V_read263_phi_phi_fu_19742_p4 = ap_phi_mux_data_237_V_read263_rewind_phi_fu_14616_p6.read();
    } else {
        ap_phi_mux_data_237_V_read263_phi_phi_fu_19742_p4 = ap_phi_reg_pp0_iter1_data_237_V_read263_phi_reg_19738.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_237_V_read263_rewind_phi_fu_14616_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_237_V_read263_rewind_phi_fu_14616_p6 = data_237_V_read263_phi_reg_19738.read();
    } else {
        ap_phi_mux_data_237_V_read263_rewind_phi_fu_14616_p6 = data_237_V_read263_rewind_reg_14612.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_238_V_read264_phi_phi_fu_19754_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_238_V_read264_phi_phi_fu_19754_p4 = ap_phi_mux_data_238_V_read264_rewind_phi_fu_14630_p6.read();
    } else {
        ap_phi_mux_data_238_V_read264_phi_phi_fu_19754_p4 = ap_phi_reg_pp0_iter1_data_238_V_read264_phi_reg_19750.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_238_V_read264_rewind_phi_fu_14630_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_238_V_read264_rewind_phi_fu_14630_p6 = data_238_V_read264_phi_reg_19750.read();
    } else {
        ap_phi_mux_data_238_V_read264_rewind_phi_fu_14630_p6 = data_238_V_read264_rewind_reg_14626.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_239_V_read265_phi_phi_fu_19766_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_239_V_read265_phi_phi_fu_19766_p4 = ap_phi_mux_data_239_V_read265_rewind_phi_fu_14644_p6.read();
    } else {
        ap_phi_mux_data_239_V_read265_phi_phi_fu_19766_p4 = ap_phi_reg_pp0_iter1_data_239_V_read265_phi_reg_19762.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_239_V_read265_rewind_phi_fu_14644_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_239_V_read265_rewind_phi_fu_14644_p6 = data_239_V_read265_phi_reg_19762.read();
    } else {
        ap_phi_mux_data_239_V_read265_rewind_phi_fu_14644_p6 = data_239_V_read265_rewind_reg_14640.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_23_V_read49_phi_phi_fu_17174_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_23_V_read49_phi_phi_fu_17174_p4 = ap_phi_mux_data_23_V_read49_rewind_phi_fu_11620_p6.read();
    } else {
        ap_phi_mux_data_23_V_read49_phi_phi_fu_17174_p4 = ap_phi_reg_pp0_iter1_data_23_V_read49_phi_reg_17170.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_23_V_read49_rewind_phi_fu_11620_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_23_V_read49_rewind_phi_fu_11620_p6 = data_23_V_read49_phi_reg_17170.read();
    } else {
        ap_phi_mux_data_23_V_read49_rewind_phi_fu_11620_p6 = data_23_V_read49_rewind_reg_11616.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_240_V_read266_phi_phi_fu_19778_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_240_V_read266_phi_phi_fu_19778_p4 = ap_phi_mux_data_240_V_read266_rewind_phi_fu_14658_p6.read();
    } else {
        ap_phi_mux_data_240_V_read266_phi_phi_fu_19778_p4 = ap_phi_reg_pp0_iter1_data_240_V_read266_phi_reg_19774.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_240_V_read266_rewind_phi_fu_14658_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_240_V_read266_rewind_phi_fu_14658_p6 = data_240_V_read266_phi_reg_19774.read();
    } else {
        ap_phi_mux_data_240_V_read266_rewind_phi_fu_14658_p6 = data_240_V_read266_rewind_reg_14654.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_241_V_read267_phi_phi_fu_19790_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_241_V_read267_phi_phi_fu_19790_p4 = ap_phi_mux_data_241_V_read267_rewind_phi_fu_14672_p6.read();
    } else {
        ap_phi_mux_data_241_V_read267_phi_phi_fu_19790_p4 = ap_phi_reg_pp0_iter1_data_241_V_read267_phi_reg_19786.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_241_V_read267_rewind_phi_fu_14672_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_241_V_read267_rewind_phi_fu_14672_p6 = data_241_V_read267_phi_reg_19786.read();
    } else {
        ap_phi_mux_data_241_V_read267_rewind_phi_fu_14672_p6 = data_241_V_read267_rewind_reg_14668.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_242_V_read268_phi_phi_fu_19802_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_242_V_read268_phi_phi_fu_19802_p4 = ap_phi_mux_data_242_V_read268_rewind_phi_fu_14686_p6.read();
    } else {
        ap_phi_mux_data_242_V_read268_phi_phi_fu_19802_p4 = ap_phi_reg_pp0_iter1_data_242_V_read268_phi_reg_19798.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_242_V_read268_rewind_phi_fu_14686_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_242_V_read268_rewind_phi_fu_14686_p6 = data_242_V_read268_phi_reg_19798.read();
    } else {
        ap_phi_mux_data_242_V_read268_rewind_phi_fu_14686_p6 = data_242_V_read268_rewind_reg_14682.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_243_V_read269_phi_phi_fu_19814_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_243_V_read269_phi_phi_fu_19814_p4 = ap_phi_mux_data_243_V_read269_rewind_phi_fu_14700_p6.read();
    } else {
        ap_phi_mux_data_243_V_read269_phi_phi_fu_19814_p4 = ap_phi_reg_pp0_iter1_data_243_V_read269_phi_reg_19810.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_243_V_read269_rewind_phi_fu_14700_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_243_V_read269_rewind_phi_fu_14700_p6 = data_243_V_read269_phi_reg_19810.read();
    } else {
        ap_phi_mux_data_243_V_read269_rewind_phi_fu_14700_p6 = data_243_V_read269_rewind_reg_14696.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_244_V_read270_phi_phi_fu_19826_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_244_V_read270_phi_phi_fu_19826_p4 = ap_phi_mux_data_244_V_read270_rewind_phi_fu_14714_p6.read();
    } else {
        ap_phi_mux_data_244_V_read270_phi_phi_fu_19826_p4 = ap_phi_reg_pp0_iter1_data_244_V_read270_phi_reg_19822.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_244_V_read270_rewind_phi_fu_14714_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_244_V_read270_rewind_phi_fu_14714_p6 = data_244_V_read270_phi_reg_19822.read();
    } else {
        ap_phi_mux_data_244_V_read270_rewind_phi_fu_14714_p6 = data_244_V_read270_rewind_reg_14710.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_245_V_read271_phi_phi_fu_19838_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_245_V_read271_phi_phi_fu_19838_p4 = ap_phi_mux_data_245_V_read271_rewind_phi_fu_14728_p6.read();
    } else {
        ap_phi_mux_data_245_V_read271_phi_phi_fu_19838_p4 = ap_phi_reg_pp0_iter1_data_245_V_read271_phi_reg_19834.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_245_V_read271_rewind_phi_fu_14728_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_245_V_read271_rewind_phi_fu_14728_p6 = data_245_V_read271_phi_reg_19834.read();
    } else {
        ap_phi_mux_data_245_V_read271_rewind_phi_fu_14728_p6 = data_245_V_read271_rewind_reg_14724.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_246_V_read272_phi_phi_fu_19850_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_246_V_read272_phi_phi_fu_19850_p4 = ap_phi_mux_data_246_V_read272_rewind_phi_fu_14742_p6.read();
    } else {
        ap_phi_mux_data_246_V_read272_phi_phi_fu_19850_p4 = ap_phi_reg_pp0_iter1_data_246_V_read272_phi_reg_19846.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_246_V_read272_rewind_phi_fu_14742_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_246_V_read272_rewind_phi_fu_14742_p6 = data_246_V_read272_phi_reg_19846.read();
    } else {
        ap_phi_mux_data_246_V_read272_rewind_phi_fu_14742_p6 = data_246_V_read272_rewind_reg_14738.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_247_V_read273_phi_phi_fu_19862_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_247_V_read273_phi_phi_fu_19862_p4 = ap_phi_mux_data_247_V_read273_rewind_phi_fu_14756_p6.read();
    } else {
        ap_phi_mux_data_247_V_read273_phi_phi_fu_19862_p4 = ap_phi_reg_pp0_iter1_data_247_V_read273_phi_reg_19858.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_247_V_read273_rewind_phi_fu_14756_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_247_V_read273_rewind_phi_fu_14756_p6 = data_247_V_read273_phi_reg_19858.read();
    } else {
        ap_phi_mux_data_247_V_read273_rewind_phi_fu_14756_p6 = data_247_V_read273_rewind_reg_14752.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_248_V_read274_phi_phi_fu_19874_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_248_V_read274_phi_phi_fu_19874_p4 = ap_phi_mux_data_248_V_read274_rewind_phi_fu_14770_p6.read();
    } else {
        ap_phi_mux_data_248_V_read274_phi_phi_fu_19874_p4 = ap_phi_reg_pp0_iter1_data_248_V_read274_phi_reg_19870.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_248_V_read274_rewind_phi_fu_14770_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_248_V_read274_rewind_phi_fu_14770_p6 = data_248_V_read274_phi_reg_19870.read();
    } else {
        ap_phi_mux_data_248_V_read274_rewind_phi_fu_14770_p6 = data_248_V_read274_rewind_reg_14766.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_249_V_read275_phi_phi_fu_19886_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_249_V_read275_phi_phi_fu_19886_p4 = ap_phi_mux_data_249_V_read275_rewind_phi_fu_14784_p6.read();
    } else {
        ap_phi_mux_data_249_V_read275_phi_phi_fu_19886_p4 = ap_phi_reg_pp0_iter1_data_249_V_read275_phi_reg_19882.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_249_V_read275_rewind_phi_fu_14784_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_249_V_read275_rewind_phi_fu_14784_p6 = data_249_V_read275_phi_reg_19882.read();
    } else {
        ap_phi_mux_data_249_V_read275_rewind_phi_fu_14784_p6 = data_249_V_read275_rewind_reg_14780.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_24_V_read50_phi_phi_fu_17186_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_24_V_read50_phi_phi_fu_17186_p4 = ap_phi_mux_data_24_V_read50_rewind_phi_fu_11634_p6.read();
    } else {
        ap_phi_mux_data_24_V_read50_phi_phi_fu_17186_p4 = ap_phi_reg_pp0_iter1_data_24_V_read50_phi_reg_17182.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_24_V_read50_rewind_phi_fu_11634_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_24_V_read50_rewind_phi_fu_11634_p6 = data_24_V_read50_phi_reg_17182.read();
    } else {
        ap_phi_mux_data_24_V_read50_rewind_phi_fu_11634_p6 = data_24_V_read50_rewind_reg_11630.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_250_V_read276_phi_phi_fu_19898_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_250_V_read276_phi_phi_fu_19898_p4 = ap_phi_mux_data_250_V_read276_rewind_phi_fu_14798_p6.read();
    } else {
        ap_phi_mux_data_250_V_read276_phi_phi_fu_19898_p4 = ap_phi_reg_pp0_iter1_data_250_V_read276_phi_reg_19894.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_250_V_read276_rewind_phi_fu_14798_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_250_V_read276_rewind_phi_fu_14798_p6 = data_250_V_read276_phi_reg_19894.read();
    } else {
        ap_phi_mux_data_250_V_read276_rewind_phi_fu_14798_p6 = data_250_V_read276_rewind_reg_14794.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_251_V_read277_phi_phi_fu_19910_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_251_V_read277_phi_phi_fu_19910_p4 = ap_phi_mux_data_251_V_read277_rewind_phi_fu_14812_p6.read();
    } else {
        ap_phi_mux_data_251_V_read277_phi_phi_fu_19910_p4 = ap_phi_reg_pp0_iter1_data_251_V_read277_phi_reg_19906.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_251_V_read277_rewind_phi_fu_14812_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_251_V_read277_rewind_phi_fu_14812_p6 = data_251_V_read277_phi_reg_19906.read();
    } else {
        ap_phi_mux_data_251_V_read277_rewind_phi_fu_14812_p6 = data_251_V_read277_rewind_reg_14808.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_252_V_read278_phi_phi_fu_19922_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_252_V_read278_phi_phi_fu_19922_p4 = ap_phi_mux_data_252_V_read278_rewind_phi_fu_14826_p6.read();
    } else {
        ap_phi_mux_data_252_V_read278_phi_phi_fu_19922_p4 = ap_phi_reg_pp0_iter1_data_252_V_read278_phi_reg_19918.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_252_V_read278_rewind_phi_fu_14826_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_252_V_read278_rewind_phi_fu_14826_p6 = data_252_V_read278_phi_reg_19918.read();
    } else {
        ap_phi_mux_data_252_V_read278_rewind_phi_fu_14826_p6 = data_252_V_read278_rewind_reg_14822.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_253_V_read279_phi_phi_fu_19934_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_253_V_read279_phi_phi_fu_19934_p4 = ap_phi_mux_data_253_V_read279_rewind_phi_fu_14840_p6.read();
    } else {
        ap_phi_mux_data_253_V_read279_phi_phi_fu_19934_p4 = ap_phi_reg_pp0_iter1_data_253_V_read279_phi_reg_19930.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_253_V_read279_rewind_phi_fu_14840_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_253_V_read279_rewind_phi_fu_14840_p6 = data_253_V_read279_phi_reg_19930.read();
    } else {
        ap_phi_mux_data_253_V_read279_rewind_phi_fu_14840_p6 = data_253_V_read279_rewind_reg_14836.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_254_V_read280_phi_phi_fu_19946_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_254_V_read280_phi_phi_fu_19946_p4 = ap_phi_mux_data_254_V_read280_rewind_phi_fu_14854_p6.read();
    } else {
        ap_phi_mux_data_254_V_read280_phi_phi_fu_19946_p4 = ap_phi_reg_pp0_iter1_data_254_V_read280_phi_reg_19942.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_254_V_read280_rewind_phi_fu_14854_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_254_V_read280_rewind_phi_fu_14854_p6 = data_254_V_read280_phi_reg_19942.read();
    } else {
        ap_phi_mux_data_254_V_read280_rewind_phi_fu_14854_p6 = data_254_V_read280_rewind_reg_14850.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_255_V_read281_phi_phi_fu_19958_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_255_V_read281_phi_phi_fu_19958_p4 = ap_phi_mux_data_255_V_read281_rewind_phi_fu_14868_p6.read();
    } else {
        ap_phi_mux_data_255_V_read281_phi_phi_fu_19958_p4 = ap_phi_reg_pp0_iter1_data_255_V_read281_phi_reg_19954.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_255_V_read281_rewind_phi_fu_14868_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_255_V_read281_rewind_phi_fu_14868_p6 = data_255_V_read281_phi_reg_19954.read();
    } else {
        ap_phi_mux_data_255_V_read281_rewind_phi_fu_14868_p6 = data_255_V_read281_rewind_reg_14864.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_256_V_read282_phi_phi_fu_19970_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_256_V_read282_phi_phi_fu_19970_p4 = ap_phi_mux_data_256_V_read282_rewind_phi_fu_14882_p6.read();
    } else {
        ap_phi_mux_data_256_V_read282_phi_phi_fu_19970_p4 = ap_phi_reg_pp0_iter1_data_256_V_read282_phi_reg_19966.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_256_V_read282_rewind_phi_fu_14882_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_256_V_read282_rewind_phi_fu_14882_p6 = data_256_V_read282_phi_reg_19966.read();
    } else {
        ap_phi_mux_data_256_V_read282_rewind_phi_fu_14882_p6 = data_256_V_read282_rewind_reg_14878.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_257_V_read283_phi_phi_fu_19982_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_257_V_read283_phi_phi_fu_19982_p4 = ap_phi_mux_data_257_V_read283_rewind_phi_fu_14896_p6.read();
    } else {
        ap_phi_mux_data_257_V_read283_phi_phi_fu_19982_p4 = ap_phi_reg_pp0_iter1_data_257_V_read283_phi_reg_19978.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_257_V_read283_rewind_phi_fu_14896_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_257_V_read283_rewind_phi_fu_14896_p6 = data_257_V_read283_phi_reg_19978.read();
    } else {
        ap_phi_mux_data_257_V_read283_rewind_phi_fu_14896_p6 = data_257_V_read283_rewind_reg_14892.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_258_V_read284_phi_phi_fu_19994_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_258_V_read284_phi_phi_fu_19994_p4 = ap_phi_mux_data_258_V_read284_rewind_phi_fu_14910_p6.read();
    } else {
        ap_phi_mux_data_258_V_read284_phi_phi_fu_19994_p4 = ap_phi_reg_pp0_iter1_data_258_V_read284_phi_reg_19990.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_258_V_read284_rewind_phi_fu_14910_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_258_V_read284_rewind_phi_fu_14910_p6 = data_258_V_read284_phi_reg_19990.read();
    } else {
        ap_phi_mux_data_258_V_read284_rewind_phi_fu_14910_p6 = data_258_V_read284_rewind_reg_14906.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_259_V_read285_phi_phi_fu_20006_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_259_V_read285_phi_phi_fu_20006_p4 = ap_phi_mux_data_259_V_read285_rewind_phi_fu_14924_p6.read();
    } else {
        ap_phi_mux_data_259_V_read285_phi_phi_fu_20006_p4 = ap_phi_reg_pp0_iter1_data_259_V_read285_phi_reg_20002.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_259_V_read285_rewind_phi_fu_14924_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_259_V_read285_rewind_phi_fu_14924_p6 = data_259_V_read285_phi_reg_20002.read();
    } else {
        ap_phi_mux_data_259_V_read285_rewind_phi_fu_14924_p6 = data_259_V_read285_rewind_reg_14920.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_25_V_read51_phi_phi_fu_17198_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_25_V_read51_phi_phi_fu_17198_p4 = ap_phi_mux_data_25_V_read51_rewind_phi_fu_11648_p6.read();
    } else {
        ap_phi_mux_data_25_V_read51_phi_phi_fu_17198_p4 = ap_phi_reg_pp0_iter1_data_25_V_read51_phi_reg_17194.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_25_V_read51_rewind_phi_fu_11648_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_25_V_read51_rewind_phi_fu_11648_p6 = data_25_V_read51_phi_reg_17194.read();
    } else {
        ap_phi_mux_data_25_V_read51_rewind_phi_fu_11648_p6 = data_25_V_read51_rewind_reg_11644.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_260_V_read286_phi_phi_fu_20018_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_260_V_read286_phi_phi_fu_20018_p4 = ap_phi_mux_data_260_V_read286_rewind_phi_fu_14938_p6.read();
    } else {
        ap_phi_mux_data_260_V_read286_phi_phi_fu_20018_p4 = ap_phi_reg_pp0_iter1_data_260_V_read286_phi_reg_20014.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_260_V_read286_rewind_phi_fu_14938_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_260_V_read286_rewind_phi_fu_14938_p6 = data_260_V_read286_phi_reg_20014.read();
    } else {
        ap_phi_mux_data_260_V_read286_rewind_phi_fu_14938_p6 = data_260_V_read286_rewind_reg_14934.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_261_V_read287_phi_phi_fu_20030_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_261_V_read287_phi_phi_fu_20030_p4 = ap_phi_mux_data_261_V_read287_rewind_phi_fu_14952_p6.read();
    } else {
        ap_phi_mux_data_261_V_read287_phi_phi_fu_20030_p4 = ap_phi_reg_pp0_iter1_data_261_V_read287_phi_reg_20026.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_261_V_read287_rewind_phi_fu_14952_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_261_V_read287_rewind_phi_fu_14952_p6 = data_261_V_read287_phi_reg_20026.read();
    } else {
        ap_phi_mux_data_261_V_read287_rewind_phi_fu_14952_p6 = data_261_V_read287_rewind_reg_14948.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_262_V_read288_phi_phi_fu_20042_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_262_V_read288_phi_phi_fu_20042_p4 = ap_phi_mux_data_262_V_read288_rewind_phi_fu_14966_p6.read();
    } else {
        ap_phi_mux_data_262_V_read288_phi_phi_fu_20042_p4 = ap_phi_reg_pp0_iter1_data_262_V_read288_phi_reg_20038.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_262_V_read288_rewind_phi_fu_14966_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_262_V_read288_rewind_phi_fu_14966_p6 = data_262_V_read288_phi_reg_20038.read();
    } else {
        ap_phi_mux_data_262_V_read288_rewind_phi_fu_14966_p6 = data_262_V_read288_rewind_reg_14962.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_263_V_read289_phi_phi_fu_20054_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_263_V_read289_phi_phi_fu_20054_p4 = ap_phi_mux_data_263_V_read289_rewind_phi_fu_14980_p6.read();
    } else {
        ap_phi_mux_data_263_V_read289_phi_phi_fu_20054_p4 = ap_phi_reg_pp0_iter1_data_263_V_read289_phi_reg_20050.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_263_V_read289_rewind_phi_fu_14980_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_263_V_read289_rewind_phi_fu_14980_p6 = data_263_V_read289_phi_reg_20050.read();
    } else {
        ap_phi_mux_data_263_V_read289_rewind_phi_fu_14980_p6 = data_263_V_read289_rewind_reg_14976.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_264_V_read290_phi_phi_fu_20066_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_264_V_read290_phi_phi_fu_20066_p4 = ap_phi_mux_data_264_V_read290_rewind_phi_fu_14994_p6.read();
    } else {
        ap_phi_mux_data_264_V_read290_phi_phi_fu_20066_p4 = ap_phi_reg_pp0_iter1_data_264_V_read290_phi_reg_20062.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_264_V_read290_rewind_phi_fu_14994_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_264_V_read290_rewind_phi_fu_14994_p6 = data_264_V_read290_phi_reg_20062.read();
    } else {
        ap_phi_mux_data_264_V_read290_rewind_phi_fu_14994_p6 = data_264_V_read290_rewind_reg_14990.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_265_V_read291_phi_phi_fu_20078_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_265_V_read291_phi_phi_fu_20078_p4 = ap_phi_mux_data_265_V_read291_rewind_phi_fu_15008_p6.read();
    } else {
        ap_phi_mux_data_265_V_read291_phi_phi_fu_20078_p4 = ap_phi_reg_pp0_iter1_data_265_V_read291_phi_reg_20074.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_265_V_read291_rewind_phi_fu_15008_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_265_V_read291_rewind_phi_fu_15008_p6 = data_265_V_read291_phi_reg_20074.read();
    } else {
        ap_phi_mux_data_265_V_read291_rewind_phi_fu_15008_p6 = data_265_V_read291_rewind_reg_15004.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_266_V_read292_phi_phi_fu_20090_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_266_V_read292_phi_phi_fu_20090_p4 = ap_phi_mux_data_266_V_read292_rewind_phi_fu_15022_p6.read();
    } else {
        ap_phi_mux_data_266_V_read292_phi_phi_fu_20090_p4 = ap_phi_reg_pp0_iter1_data_266_V_read292_phi_reg_20086.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_266_V_read292_rewind_phi_fu_15022_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_266_V_read292_rewind_phi_fu_15022_p6 = data_266_V_read292_phi_reg_20086.read();
    } else {
        ap_phi_mux_data_266_V_read292_rewind_phi_fu_15022_p6 = data_266_V_read292_rewind_reg_15018.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_267_V_read293_phi_phi_fu_20102_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_267_V_read293_phi_phi_fu_20102_p4 = ap_phi_mux_data_267_V_read293_rewind_phi_fu_15036_p6.read();
    } else {
        ap_phi_mux_data_267_V_read293_phi_phi_fu_20102_p4 = ap_phi_reg_pp0_iter1_data_267_V_read293_phi_reg_20098.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_267_V_read293_rewind_phi_fu_15036_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_267_V_read293_rewind_phi_fu_15036_p6 = data_267_V_read293_phi_reg_20098.read();
    } else {
        ap_phi_mux_data_267_V_read293_rewind_phi_fu_15036_p6 = data_267_V_read293_rewind_reg_15032.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_268_V_read294_phi_phi_fu_20114_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_268_V_read294_phi_phi_fu_20114_p4 = ap_phi_mux_data_268_V_read294_rewind_phi_fu_15050_p6.read();
    } else {
        ap_phi_mux_data_268_V_read294_phi_phi_fu_20114_p4 = ap_phi_reg_pp0_iter1_data_268_V_read294_phi_reg_20110.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_268_V_read294_rewind_phi_fu_15050_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_268_V_read294_rewind_phi_fu_15050_p6 = data_268_V_read294_phi_reg_20110.read();
    } else {
        ap_phi_mux_data_268_V_read294_rewind_phi_fu_15050_p6 = data_268_V_read294_rewind_reg_15046.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_269_V_read295_phi_phi_fu_20126_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_269_V_read295_phi_phi_fu_20126_p4 = ap_phi_mux_data_269_V_read295_rewind_phi_fu_15064_p6.read();
    } else {
        ap_phi_mux_data_269_V_read295_phi_phi_fu_20126_p4 = ap_phi_reg_pp0_iter1_data_269_V_read295_phi_reg_20122.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_269_V_read295_rewind_phi_fu_15064_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_269_V_read295_rewind_phi_fu_15064_p6 = data_269_V_read295_phi_reg_20122.read();
    } else {
        ap_phi_mux_data_269_V_read295_rewind_phi_fu_15064_p6 = data_269_V_read295_rewind_reg_15060.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_26_V_read52_phi_phi_fu_17210_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_26_V_read52_phi_phi_fu_17210_p4 = ap_phi_mux_data_26_V_read52_rewind_phi_fu_11662_p6.read();
    } else {
        ap_phi_mux_data_26_V_read52_phi_phi_fu_17210_p4 = ap_phi_reg_pp0_iter1_data_26_V_read52_phi_reg_17206.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_26_V_read52_rewind_phi_fu_11662_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_26_V_read52_rewind_phi_fu_11662_p6 = data_26_V_read52_phi_reg_17206.read();
    } else {
        ap_phi_mux_data_26_V_read52_rewind_phi_fu_11662_p6 = data_26_V_read52_rewind_reg_11658.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_270_V_read296_phi_phi_fu_20138_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_270_V_read296_phi_phi_fu_20138_p4 = ap_phi_mux_data_270_V_read296_rewind_phi_fu_15078_p6.read();
    } else {
        ap_phi_mux_data_270_V_read296_phi_phi_fu_20138_p4 = ap_phi_reg_pp0_iter1_data_270_V_read296_phi_reg_20134.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_270_V_read296_rewind_phi_fu_15078_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_270_V_read296_rewind_phi_fu_15078_p6 = data_270_V_read296_phi_reg_20134.read();
    } else {
        ap_phi_mux_data_270_V_read296_rewind_phi_fu_15078_p6 = data_270_V_read296_rewind_reg_15074.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_271_V_read297_phi_phi_fu_20150_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_271_V_read297_phi_phi_fu_20150_p4 = ap_phi_mux_data_271_V_read297_rewind_phi_fu_15092_p6.read();
    } else {
        ap_phi_mux_data_271_V_read297_phi_phi_fu_20150_p4 = ap_phi_reg_pp0_iter1_data_271_V_read297_phi_reg_20146.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_271_V_read297_rewind_phi_fu_15092_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_271_V_read297_rewind_phi_fu_15092_p6 = data_271_V_read297_phi_reg_20146.read();
    } else {
        ap_phi_mux_data_271_V_read297_rewind_phi_fu_15092_p6 = data_271_V_read297_rewind_reg_15088.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_272_V_read298_phi_phi_fu_20162_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_272_V_read298_phi_phi_fu_20162_p4 = ap_phi_mux_data_272_V_read298_rewind_phi_fu_15106_p6.read();
    } else {
        ap_phi_mux_data_272_V_read298_phi_phi_fu_20162_p4 = ap_phi_reg_pp0_iter1_data_272_V_read298_phi_reg_20158.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_272_V_read298_rewind_phi_fu_15106_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_272_V_read298_rewind_phi_fu_15106_p6 = data_272_V_read298_phi_reg_20158.read();
    } else {
        ap_phi_mux_data_272_V_read298_rewind_phi_fu_15106_p6 = data_272_V_read298_rewind_reg_15102.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_273_V_read299_phi_phi_fu_20174_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_273_V_read299_phi_phi_fu_20174_p4 = ap_phi_mux_data_273_V_read299_rewind_phi_fu_15120_p6.read();
    } else {
        ap_phi_mux_data_273_V_read299_phi_phi_fu_20174_p4 = ap_phi_reg_pp0_iter1_data_273_V_read299_phi_reg_20170.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_273_V_read299_rewind_phi_fu_15120_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_273_V_read299_rewind_phi_fu_15120_p6 = data_273_V_read299_phi_reg_20170.read();
    } else {
        ap_phi_mux_data_273_V_read299_rewind_phi_fu_15120_p6 = data_273_V_read299_rewind_reg_15116.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_274_V_read300_phi_phi_fu_20186_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_274_V_read300_phi_phi_fu_20186_p4 = ap_phi_mux_data_274_V_read300_rewind_phi_fu_15134_p6.read();
    } else {
        ap_phi_mux_data_274_V_read300_phi_phi_fu_20186_p4 = ap_phi_reg_pp0_iter1_data_274_V_read300_phi_reg_20182.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_274_V_read300_rewind_phi_fu_15134_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_274_V_read300_rewind_phi_fu_15134_p6 = data_274_V_read300_phi_reg_20182.read();
    } else {
        ap_phi_mux_data_274_V_read300_rewind_phi_fu_15134_p6 = data_274_V_read300_rewind_reg_15130.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_275_V_read301_phi_phi_fu_20198_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_275_V_read301_phi_phi_fu_20198_p4 = ap_phi_mux_data_275_V_read301_rewind_phi_fu_15148_p6.read();
    } else {
        ap_phi_mux_data_275_V_read301_phi_phi_fu_20198_p4 = ap_phi_reg_pp0_iter1_data_275_V_read301_phi_reg_20194.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_275_V_read301_rewind_phi_fu_15148_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_275_V_read301_rewind_phi_fu_15148_p6 = data_275_V_read301_phi_reg_20194.read();
    } else {
        ap_phi_mux_data_275_V_read301_rewind_phi_fu_15148_p6 = data_275_V_read301_rewind_reg_15144.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_276_V_read302_phi_phi_fu_20210_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_276_V_read302_phi_phi_fu_20210_p4 = ap_phi_mux_data_276_V_read302_rewind_phi_fu_15162_p6.read();
    } else {
        ap_phi_mux_data_276_V_read302_phi_phi_fu_20210_p4 = ap_phi_reg_pp0_iter1_data_276_V_read302_phi_reg_20206.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_276_V_read302_rewind_phi_fu_15162_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_276_V_read302_rewind_phi_fu_15162_p6 = data_276_V_read302_phi_reg_20206.read();
    } else {
        ap_phi_mux_data_276_V_read302_rewind_phi_fu_15162_p6 = data_276_V_read302_rewind_reg_15158.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_277_V_read303_phi_phi_fu_20222_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_277_V_read303_phi_phi_fu_20222_p4 = ap_phi_mux_data_277_V_read303_rewind_phi_fu_15176_p6.read();
    } else {
        ap_phi_mux_data_277_V_read303_phi_phi_fu_20222_p4 = ap_phi_reg_pp0_iter1_data_277_V_read303_phi_reg_20218.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_277_V_read303_rewind_phi_fu_15176_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_277_V_read303_rewind_phi_fu_15176_p6 = data_277_V_read303_phi_reg_20218.read();
    } else {
        ap_phi_mux_data_277_V_read303_rewind_phi_fu_15176_p6 = data_277_V_read303_rewind_reg_15172.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_278_V_read304_phi_phi_fu_20234_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_278_V_read304_phi_phi_fu_20234_p4 = ap_phi_mux_data_278_V_read304_rewind_phi_fu_15190_p6.read();
    } else {
        ap_phi_mux_data_278_V_read304_phi_phi_fu_20234_p4 = ap_phi_reg_pp0_iter1_data_278_V_read304_phi_reg_20230.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_278_V_read304_rewind_phi_fu_15190_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_278_V_read304_rewind_phi_fu_15190_p6 = data_278_V_read304_phi_reg_20230.read();
    } else {
        ap_phi_mux_data_278_V_read304_rewind_phi_fu_15190_p6 = data_278_V_read304_rewind_reg_15186.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_279_V_read305_phi_phi_fu_20246_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_279_V_read305_phi_phi_fu_20246_p4 = ap_phi_mux_data_279_V_read305_rewind_phi_fu_15204_p6.read();
    } else {
        ap_phi_mux_data_279_V_read305_phi_phi_fu_20246_p4 = ap_phi_reg_pp0_iter1_data_279_V_read305_phi_reg_20242.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_279_V_read305_rewind_phi_fu_15204_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_279_V_read305_rewind_phi_fu_15204_p6 = data_279_V_read305_phi_reg_20242.read();
    } else {
        ap_phi_mux_data_279_V_read305_rewind_phi_fu_15204_p6 = data_279_V_read305_rewind_reg_15200.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_27_V_read53_phi_phi_fu_17222_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_27_V_read53_phi_phi_fu_17222_p4 = ap_phi_mux_data_27_V_read53_rewind_phi_fu_11676_p6.read();
    } else {
        ap_phi_mux_data_27_V_read53_phi_phi_fu_17222_p4 = ap_phi_reg_pp0_iter1_data_27_V_read53_phi_reg_17218.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_27_V_read53_rewind_phi_fu_11676_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_27_V_read53_rewind_phi_fu_11676_p6 = data_27_V_read53_phi_reg_17218.read();
    } else {
        ap_phi_mux_data_27_V_read53_rewind_phi_fu_11676_p6 = data_27_V_read53_rewind_reg_11672.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_280_V_read306_phi_phi_fu_20258_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_280_V_read306_phi_phi_fu_20258_p4 = ap_phi_mux_data_280_V_read306_rewind_phi_fu_15218_p6.read();
    } else {
        ap_phi_mux_data_280_V_read306_phi_phi_fu_20258_p4 = ap_phi_reg_pp0_iter1_data_280_V_read306_phi_reg_20254.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_280_V_read306_rewind_phi_fu_15218_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_280_V_read306_rewind_phi_fu_15218_p6 = data_280_V_read306_phi_reg_20254.read();
    } else {
        ap_phi_mux_data_280_V_read306_rewind_phi_fu_15218_p6 = data_280_V_read306_rewind_reg_15214.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_281_V_read307_phi_phi_fu_20270_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_281_V_read307_phi_phi_fu_20270_p4 = ap_phi_mux_data_281_V_read307_rewind_phi_fu_15232_p6.read();
    } else {
        ap_phi_mux_data_281_V_read307_phi_phi_fu_20270_p4 = ap_phi_reg_pp0_iter1_data_281_V_read307_phi_reg_20266.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_281_V_read307_rewind_phi_fu_15232_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_281_V_read307_rewind_phi_fu_15232_p6 = data_281_V_read307_phi_reg_20266.read();
    } else {
        ap_phi_mux_data_281_V_read307_rewind_phi_fu_15232_p6 = data_281_V_read307_rewind_reg_15228.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_282_V_read308_phi_phi_fu_20282_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_282_V_read308_phi_phi_fu_20282_p4 = ap_phi_mux_data_282_V_read308_rewind_phi_fu_15246_p6.read();
    } else {
        ap_phi_mux_data_282_V_read308_phi_phi_fu_20282_p4 = ap_phi_reg_pp0_iter1_data_282_V_read308_phi_reg_20278.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_282_V_read308_rewind_phi_fu_15246_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_282_V_read308_rewind_phi_fu_15246_p6 = data_282_V_read308_phi_reg_20278.read();
    } else {
        ap_phi_mux_data_282_V_read308_rewind_phi_fu_15246_p6 = data_282_V_read308_rewind_reg_15242.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_283_V_read309_phi_phi_fu_20294_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_283_V_read309_phi_phi_fu_20294_p4 = ap_phi_mux_data_283_V_read309_rewind_phi_fu_15260_p6.read();
    } else {
        ap_phi_mux_data_283_V_read309_phi_phi_fu_20294_p4 = ap_phi_reg_pp0_iter1_data_283_V_read309_phi_reg_20290.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_283_V_read309_rewind_phi_fu_15260_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_283_V_read309_rewind_phi_fu_15260_p6 = data_283_V_read309_phi_reg_20290.read();
    } else {
        ap_phi_mux_data_283_V_read309_rewind_phi_fu_15260_p6 = data_283_V_read309_rewind_reg_15256.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_284_V_read310_phi_phi_fu_20306_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_284_V_read310_phi_phi_fu_20306_p4 = ap_phi_mux_data_284_V_read310_rewind_phi_fu_15274_p6.read();
    } else {
        ap_phi_mux_data_284_V_read310_phi_phi_fu_20306_p4 = ap_phi_reg_pp0_iter1_data_284_V_read310_phi_reg_20302.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_284_V_read310_rewind_phi_fu_15274_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_284_V_read310_rewind_phi_fu_15274_p6 = data_284_V_read310_phi_reg_20302.read();
    } else {
        ap_phi_mux_data_284_V_read310_rewind_phi_fu_15274_p6 = data_284_V_read310_rewind_reg_15270.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_285_V_read311_phi_phi_fu_20318_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_285_V_read311_phi_phi_fu_20318_p4 = ap_phi_mux_data_285_V_read311_rewind_phi_fu_15288_p6.read();
    } else {
        ap_phi_mux_data_285_V_read311_phi_phi_fu_20318_p4 = ap_phi_reg_pp0_iter1_data_285_V_read311_phi_reg_20314.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_285_V_read311_rewind_phi_fu_15288_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_285_V_read311_rewind_phi_fu_15288_p6 = data_285_V_read311_phi_reg_20314.read();
    } else {
        ap_phi_mux_data_285_V_read311_rewind_phi_fu_15288_p6 = data_285_V_read311_rewind_reg_15284.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_286_V_read312_phi_phi_fu_20330_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_286_V_read312_phi_phi_fu_20330_p4 = ap_phi_mux_data_286_V_read312_rewind_phi_fu_15302_p6.read();
    } else {
        ap_phi_mux_data_286_V_read312_phi_phi_fu_20330_p4 = ap_phi_reg_pp0_iter1_data_286_V_read312_phi_reg_20326.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_286_V_read312_rewind_phi_fu_15302_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_286_V_read312_rewind_phi_fu_15302_p6 = data_286_V_read312_phi_reg_20326.read();
    } else {
        ap_phi_mux_data_286_V_read312_rewind_phi_fu_15302_p6 = data_286_V_read312_rewind_reg_15298.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_287_V_read313_phi_phi_fu_20342_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_287_V_read313_phi_phi_fu_20342_p4 = ap_phi_mux_data_287_V_read313_rewind_phi_fu_15316_p6.read();
    } else {
        ap_phi_mux_data_287_V_read313_phi_phi_fu_20342_p4 = ap_phi_reg_pp0_iter1_data_287_V_read313_phi_reg_20338.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_287_V_read313_rewind_phi_fu_15316_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_287_V_read313_rewind_phi_fu_15316_p6 = data_287_V_read313_phi_reg_20338.read();
    } else {
        ap_phi_mux_data_287_V_read313_rewind_phi_fu_15316_p6 = data_287_V_read313_rewind_reg_15312.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_288_V_read314_phi_phi_fu_20354_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_288_V_read314_phi_phi_fu_20354_p4 = ap_phi_mux_data_288_V_read314_rewind_phi_fu_15330_p6.read();
    } else {
        ap_phi_mux_data_288_V_read314_phi_phi_fu_20354_p4 = ap_phi_reg_pp0_iter1_data_288_V_read314_phi_reg_20350.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_288_V_read314_rewind_phi_fu_15330_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_288_V_read314_rewind_phi_fu_15330_p6 = data_288_V_read314_phi_reg_20350.read();
    } else {
        ap_phi_mux_data_288_V_read314_rewind_phi_fu_15330_p6 = data_288_V_read314_rewind_reg_15326.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_289_V_read315_phi_phi_fu_20366_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_289_V_read315_phi_phi_fu_20366_p4 = ap_phi_mux_data_289_V_read315_rewind_phi_fu_15344_p6.read();
    } else {
        ap_phi_mux_data_289_V_read315_phi_phi_fu_20366_p4 = ap_phi_reg_pp0_iter1_data_289_V_read315_phi_reg_20362.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_289_V_read315_rewind_phi_fu_15344_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_289_V_read315_rewind_phi_fu_15344_p6 = data_289_V_read315_phi_reg_20362.read();
    } else {
        ap_phi_mux_data_289_V_read315_rewind_phi_fu_15344_p6 = data_289_V_read315_rewind_reg_15340.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_28_V_read54_phi_phi_fu_17234_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_28_V_read54_phi_phi_fu_17234_p4 = ap_phi_mux_data_28_V_read54_rewind_phi_fu_11690_p6.read();
    } else {
        ap_phi_mux_data_28_V_read54_phi_phi_fu_17234_p4 = ap_phi_reg_pp0_iter1_data_28_V_read54_phi_reg_17230.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_28_V_read54_rewind_phi_fu_11690_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_28_V_read54_rewind_phi_fu_11690_p6 = data_28_V_read54_phi_reg_17230.read();
    } else {
        ap_phi_mux_data_28_V_read54_rewind_phi_fu_11690_p6 = data_28_V_read54_rewind_reg_11686.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_290_V_read316_phi_phi_fu_20378_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_290_V_read316_phi_phi_fu_20378_p4 = ap_phi_mux_data_290_V_read316_rewind_phi_fu_15358_p6.read();
    } else {
        ap_phi_mux_data_290_V_read316_phi_phi_fu_20378_p4 = ap_phi_reg_pp0_iter1_data_290_V_read316_phi_reg_20374.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_290_V_read316_rewind_phi_fu_15358_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_290_V_read316_rewind_phi_fu_15358_p6 = data_290_V_read316_phi_reg_20374.read();
    } else {
        ap_phi_mux_data_290_V_read316_rewind_phi_fu_15358_p6 = data_290_V_read316_rewind_reg_15354.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_291_V_read317_phi_phi_fu_20390_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_291_V_read317_phi_phi_fu_20390_p4 = ap_phi_mux_data_291_V_read317_rewind_phi_fu_15372_p6.read();
    } else {
        ap_phi_mux_data_291_V_read317_phi_phi_fu_20390_p4 = ap_phi_reg_pp0_iter1_data_291_V_read317_phi_reg_20386.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_291_V_read317_rewind_phi_fu_15372_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_291_V_read317_rewind_phi_fu_15372_p6 = data_291_V_read317_phi_reg_20386.read();
    } else {
        ap_phi_mux_data_291_V_read317_rewind_phi_fu_15372_p6 = data_291_V_read317_rewind_reg_15368.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_292_V_read318_phi_phi_fu_20402_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_292_V_read318_phi_phi_fu_20402_p4 = ap_phi_mux_data_292_V_read318_rewind_phi_fu_15386_p6.read();
    } else {
        ap_phi_mux_data_292_V_read318_phi_phi_fu_20402_p4 = ap_phi_reg_pp0_iter1_data_292_V_read318_phi_reg_20398.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_292_V_read318_rewind_phi_fu_15386_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_292_V_read318_rewind_phi_fu_15386_p6 = data_292_V_read318_phi_reg_20398.read();
    } else {
        ap_phi_mux_data_292_V_read318_rewind_phi_fu_15386_p6 = data_292_V_read318_rewind_reg_15382.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_293_V_read319_phi_phi_fu_20414_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_293_V_read319_phi_phi_fu_20414_p4 = ap_phi_mux_data_293_V_read319_rewind_phi_fu_15400_p6.read();
    } else {
        ap_phi_mux_data_293_V_read319_phi_phi_fu_20414_p4 = ap_phi_reg_pp0_iter1_data_293_V_read319_phi_reg_20410.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_293_V_read319_rewind_phi_fu_15400_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_293_V_read319_rewind_phi_fu_15400_p6 = data_293_V_read319_phi_reg_20410.read();
    } else {
        ap_phi_mux_data_293_V_read319_rewind_phi_fu_15400_p6 = data_293_V_read319_rewind_reg_15396.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_294_V_read320_phi_phi_fu_20426_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_294_V_read320_phi_phi_fu_20426_p4 = ap_phi_mux_data_294_V_read320_rewind_phi_fu_15414_p6.read();
    } else {
        ap_phi_mux_data_294_V_read320_phi_phi_fu_20426_p4 = ap_phi_reg_pp0_iter1_data_294_V_read320_phi_reg_20422.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_294_V_read320_rewind_phi_fu_15414_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_294_V_read320_rewind_phi_fu_15414_p6 = data_294_V_read320_phi_reg_20422.read();
    } else {
        ap_phi_mux_data_294_V_read320_rewind_phi_fu_15414_p6 = data_294_V_read320_rewind_reg_15410.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_295_V_read321_phi_phi_fu_20438_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_295_V_read321_phi_phi_fu_20438_p4 = ap_phi_mux_data_295_V_read321_rewind_phi_fu_15428_p6.read();
    } else {
        ap_phi_mux_data_295_V_read321_phi_phi_fu_20438_p4 = ap_phi_reg_pp0_iter1_data_295_V_read321_phi_reg_20434.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_295_V_read321_rewind_phi_fu_15428_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_295_V_read321_rewind_phi_fu_15428_p6 = data_295_V_read321_phi_reg_20434.read();
    } else {
        ap_phi_mux_data_295_V_read321_rewind_phi_fu_15428_p6 = data_295_V_read321_rewind_reg_15424.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_296_V_read322_phi_phi_fu_20450_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_296_V_read322_phi_phi_fu_20450_p4 = ap_phi_mux_data_296_V_read322_rewind_phi_fu_15442_p6.read();
    } else {
        ap_phi_mux_data_296_V_read322_phi_phi_fu_20450_p4 = ap_phi_reg_pp0_iter1_data_296_V_read322_phi_reg_20446.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_296_V_read322_rewind_phi_fu_15442_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_296_V_read322_rewind_phi_fu_15442_p6 = data_296_V_read322_phi_reg_20446.read();
    } else {
        ap_phi_mux_data_296_V_read322_rewind_phi_fu_15442_p6 = data_296_V_read322_rewind_reg_15438.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_297_V_read323_phi_phi_fu_20462_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_297_V_read323_phi_phi_fu_20462_p4 = ap_phi_mux_data_297_V_read323_rewind_phi_fu_15456_p6.read();
    } else {
        ap_phi_mux_data_297_V_read323_phi_phi_fu_20462_p4 = ap_phi_reg_pp0_iter1_data_297_V_read323_phi_reg_20458.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_297_V_read323_rewind_phi_fu_15456_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_297_V_read323_rewind_phi_fu_15456_p6 = data_297_V_read323_phi_reg_20458.read();
    } else {
        ap_phi_mux_data_297_V_read323_rewind_phi_fu_15456_p6 = data_297_V_read323_rewind_reg_15452.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_298_V_read324_phi_phi_fu_20474_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_298_V_read324_phi_phi_fu_20474_p4 = ap_phi_mux_data_298_V_read324_rewind_phi_fu_15470_p6.read();
    } else {
        ap_phi_mux_data_298_V_read324_phi_phi_fu_20474_p4 = ap_phi_reg_pp0_iter1_data_298_V_read324_phi_reg_20470.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_298_V_read324_rewind_phi_fu_15470_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_298_V_read324_rewind_phi_fu_15470_p6 = data_298_V_read324_phi_reg_20470.read();
    } else {
        ap_phi_mux_data_298_V_read324_rewind_phi_fu_15470_p6 = data_298_V_read324_rewind_reg_15466.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_299_V_read325_phi_phi_fu_20486_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_299_V_read325_phi_phi_fu_20486_p4 = ap_phi_mux_data_299_V_read325_rewind_phi_fu_15484_p6.read();
    } else {
        ap_phi_mux_data_299_V_read325_phi_phi_fu_20486_p4 = ap_phi_reg_pp0_iter1_data_299_V_read325_phi_reg_20482.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_299_V_read325_rewind_phi_fu_15484_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_299_V_read325_rewind_phi_fu_15484_p6 = data_299_V_read325_phi_reg_20482.read();
    } else {
        ap_phi_mux_data_299_V_read325_rewind_phi_fu_15484_p6 = data_299_V_read325_rewind_reg_15480.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_29_V_read55_phi_phi_fu_17246_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_29_V_read55_phi_phi_fu_17246_p4 = ap_phi_mux_data_29_V_read55_rewind_phi_fu_11704_p6.read();
    } else {
        ap_phi_mux_data_29_V_read55_phi_phi_fu_17246_p4 = ap_phi_reg_pp0_iter1_data_29_V_read55_phi_reg_17242.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_29_V_read55_rewind_phi_fu_11704_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_29_V_read55_rewind_phi_fu_11704_p6 = data_29_V_read55_phi_reg_17242.read();
    } else {
        ap_phi_mux_data_29_V_read55_rewind_phi_fu_11704_p6 = data_29_V_read55_rewind_reg_11700.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_2_V_read28_phi_phi_fu_16922_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_2_V_read28_phi_phi_fu_16922_p4 = ap_phi_mux_data_2_V_read28_rewind_phi_fu_11326_p6.read();
    } else {
        ap_phi_mux_data_2_V_read28_phi_phi_fu_16922_p4 = ap_phi_reg_pp0_iter1_data_2_V_read28_phi_reg_16918.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_2_V_read28_rewind_phi_fu_11326_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_2_V_read28_rewind_phi_fu_11326_p6 = data_2_V_read28_phi_reg_16918.read();
    } else {
        ap_phi_mux_data_2_V_read28_rewind_phi_fu_11326_p6 = data_2_V_read28_rewind_reg_11322.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_300_V_read326_phi_phi_fu_20498_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_300_V_read326_phi_phi_fu_20498_p4 = ap_phi_mux_data_300_V_read326_rewind_phi_fu_15498_p6.read();
    } else {
        ap_phi_mux_data_300_V_read326_phi_phi_fu_20498_p4 = ap_phi_reg_pp0_iter1_data_300_V_read326_phi_reg_20494.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_300_V_read326_rewind_phi_fu_15498_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_300_V_read326_rewind_phi_fu_15498_p6 = data_300_V_read326_phi_reg_20494.read();
    } else {
        ap_phi_mux_data_300_V_read326_rewind_phi_fu_15498_p6 = data_300_V_read326_rewind_reg_15494.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_301_V_read327_phi_phi_fu_20510_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_301_V_read327_phi_phi_fu_20510_p4 = ap_phi_mux_data_301_V_read327_rewind_phi_fu_15512_p6.read();
    } else {
        ap_phi_mux_data_301_V_read327_phi_phi_fu_20510_p4 = ap_phi_reg_pp0_iter1_data_301_V_read327_phi_reg_20506.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_301_V_read327_rewind_phi_fu_15512_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_301_V_read327_rewind_phi_fu_15512_p6 = data_301_V_read327_phi_reg_20506.read();
    } else {
        ap_phi_mux_data_301_V_read327_rewind_phi_fu_15512_p6 = data_301_V_read327_rewind_reg_15508.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_302_V_read328_phi_phi_fu_20522_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_302_V_read328_phi_phi_fu_20522_p4 = ap_phi_mux_data_302_V_read328_rewind_phi_fu_15526_p6.read();
    } else {
        ap_phi_mux_data_302_V_read328_phi_phi_fu_20522_p4 = ap_phi_reg_pp0_iter1_data_302_V_read328_phi_reg_20518.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_302_V_read328_rewind_phi_fu_15526_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_302_V_read328_rewind_phi_fu_15526_p6 = data_302_V_read328_phi_reg_20518.read();
    } else {
        ap_phi_mux_data_302_V_read328_rewind_phi_fu_15526_p6 = data_302_V_read328_rewind_reg_15522.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_303_V_read329_phi_phi_fu_20534_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_303_V_read329_phi_phi_fu_20534_p4 = ap_phi_mux_data_303_V_read329_rewind_phi_fu_15540_p6.read();
    } else {
        ap_phi_mux_data_303_V_read329_phi_phi_fu_20534_p4 = ap_phi_reg_pp0_iter1_data_303_V_read329_phi_reg_20530.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_303_V_read329_rewind_phi_fu_15540_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_303_V_read329_rewind_phi_fu_15540_p6 = data_303_V_read329_phi_reg_20530.read();
    } else {
        ap_phi_mux_data_303_V_read329_rewind_phi_fu_15540_p6 = data_303_V_read329_rewind_reg_15536.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_304_V_read330_phi_phi_fu_20546_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_304_V_read330_phi_phi_fu_20546_p4 = ap_phi_mux_data_304_V_read330_rewind_phi_fu_15554_p6.read();
    } else {
        ap_phi_mux_data_304_V_read330_phi_phi_fu_20546_p4 = ap_phi_reg_pp0_iter1_data_304_V_read330_phi_reg_20542.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_304_V_read330_rewind_phi_fu_15554_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_304_V_read330_rewind_phi_fu_15554_p6 = data_304_V_read330_phi_reg_20542.read();
    } else {
        ap_phi_mux_data_304_V_read330_rewind_phi_fu_15554_p6 = data_304_V_read330_rewind_reg_15550.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_305_V_read331_phi_phi_fu_20558_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_305_V_read331_phi_phi_fu_20558_p4 = ap_phi_mux_data_305_V_read331_rewind_phi_fu_15568_p6.read();
    } else {
        ap_phi_mux_data_305_V_read331_phi_phi_fu_20558_p4 = ap_phi_reg_pp0_iter1_data_305_V_read331_phi_reg_20554.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_305_V_read331_rewind_phi_fu_15568_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_305_V_read331_rewind_phi_fu_15568_p6 = data_305_V_read331_phi_reg_20554.read();
    } else {
        ap_phi_mux_data_305_V_read331_rewind_phi_fu_15568_p6 = data_305_V_read331_rewind_reg_15564.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_306_V_read332_phi_phi_fu_20570_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_306_V_read332_phi_phi_fu_20570_p4 = ap_phi_mux_data_306_V_read332_rewind_phi_fu_15582_p6.read();
    } else {
        ap_phi_mux_data_306_V_read332_phi_phi_fu_20570_p4 = ap_phi_reg_pp0_iter1_data_306_V_read332_phi_reg_20566.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_306_V_read332_rewind_phi_fu_15582_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_306_V_read332_rewind_phi_fu_15582_p6 = data_306_V_read332_phi_reg_20566.read();
    } else {
        ap_phi_mux_data_306_V_read332_rewind_phi_fu_15582_p6 = data_306_V_read332_rewind_reg_15578.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_307_V_read333_phi_phi_fu_20582_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_307_V_read333_phi_phi_fu_20582_p4 = ap_phi_mux_data_307_V_read333_rewind_phi_fu_15596_p6.read();
    } else {
        ap_phi_mux_data_307_V_read333_phi_phi_fu_20582_p4 = ap_phi_reg_pp0_iter1_data_307_V_read333_phi_reg_20578.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_307_V_read333_rewind_phi_fu_15596_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_307_V_read333_rewind_phi_fu_15596_p6 = data_307_V_read333_phi_reg_20578.read();
    } else {
        ap_phi_mux_data_307_V_read333_rewind_phi_fu_15596_p6 = data_307_V_read333_rewind_reg_15592.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_308_V_read334_phi_phi_fu_20594_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_308_V_read334_phi_phi_fu_20594_p4 = ap_phi_mux_data_308_V_read334_rewind_phi_fu_15610_p6.read();
    } else {
        ap_phi_mux_data_308_V_read334_phi_phi_fu_20594_p4 = ap_phi_reg_pp0_iter1_data_308_V_read334_phi_reg_20590.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_308_V_read334_rewind_phi_fu_15610_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_308_V_read334_rewind_phi_fu_15610_p6 = data_308_V_read334_phi_reg_20590.read();
    } else {
        ap_phi_mux_data_308_V_read334_rewind_phi_fu_15610_p6 = data_308_V_read334_rewind_reg_15606.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_309_V_read335_phi_phi_fu_20606_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_309_V_read335_phi_phi_fu_20606_p4 = ap_phi_mux_data_309_V_read335_rewind_phi_fu_15624_p6.read();
    } else {
        ap_phi_mux_data_309_V_read335_phi_phi_fu_20606_p4 = ap_phi_reg_pp0_iter1_data_309_V_read335_phi_reg_20602.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_309_V_read335_rewind_phi_fu_15624_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_309_V_read335_rewind_phi_fu_15624_p6 = data_309_V_read335_phi_reg_20602.read();
    } else {
        ap_phi_mux_data_309_V_read335_rewind_phi_fu_15624_p6 = data_309_V_read335_rewind_reg_15620.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_30_V_read56_phi_phi_fu_17258_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_30_V_read56_phi_phi_fu_17258_p4 = ap_phi_mux_data_30_V_read56_rewind_phi_fu_11718_p6.read();
    } else {
        ap_phi_mux_data_30_V_read56_phi_phi_fu_17258_p4 = ap_phi_reg_pp0_iter1_data_30_V_read56_phi_reg_17254.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_30_V_read56_rewind_phi_fu_11718_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_30_V_read56_rewind_phi_fu_11718_p6 = data_30_V_read56_phi_reg_17254.read();
    } else {
        ap_phi_mux_data_30_V_read56_rewind_phi_fu_11718_p6 = data_30_V_read56_rewind_reg_11714.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_310_V_read336_phi_phi_fu_20618_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_310_V_read336_phi_phi_fu_20618_p4 = ap_phi_mux_data_310_V_read336_rewind_phi_fu_15638_p6.read();
    } else {
        ap_phi_mux_data_310_V_read336_phi_phi_fu_20618_p4 = ap_phi_reg_pp0_iter1_data_310_V_read336_phi_reg_20614.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_310_V_read336_rewind_phi_fu_15638_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_310_V_read336_rewind_phi_fu_15638_p6 = data_310_V_read336_phi_reg_20614.read();
    } else {
        ap_phi_mux_data_310_V_read336_rewind_phi_fu_15638_p6 = data_310_V_read336_rewind_reg_15634.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_311_V_read337_phi_phi_fu_20630_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_311_V_read337_phi_phi_fu_20630_p4 = ap_phi_mux_data_311_V_read337_rewind_phi_fu_15652_p6.read();
    } else {
        ap_phi_mux_data_311_V_read337_phi_phi_fu_20630_p4 = ap_phi_reg_pp0_iter1_data_311_V_read337_phi_reg_20626.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_311_V_read337_rewind_phi_fu_15652_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_311_V_read337_rewind_phi_fu_15652_p6 = data_311_V_read337_phi_reg_20626.read();
    } else {
        ap_phi_mux_data_311_V_read337_rewind_phi_fu_15652_p6 = data_311_V_read337_rewind_reg_15648.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_312_V_read338_phi_phi_fu_20642_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_312_V_read338_phi_phi_fu_20642_p4 = ap_phi_mux_data_312_V_read338_rewind_phi_fu_15666_p6.read();
    } else {
        ap_phi_mux_data_312_V_read338_phi_phi_fu_20642_p4 = ap_phi_reg_pp0_iter1_data_312_V_read338_phi_reg_20638.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_312_V_read338_rewind_phi_fu_15666_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_312_V_read338_rewind_phi_fu_15666_p6 = data_312_V_read338_phi_reg_20638.read();
    } else {
        ap_phi_mux_data_312_V_read338_rewind_phi_fu_15666_p6 = data_312_V_read338_rewind_reg_15662.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_313_V_read339_phi_phi_fu_20654_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_313_V_read339_phi_phi_fu_20654_p4 = ap_phi_mux_data_313_V_read339_rewind_phi_fu_15680_p6.read();
    } else {
        ap_phi_mux_data_313_V_read339_phi_phi_fu_20654_p4 = ap_phi_reg_pp0_iter1_data_313_V_read339_phi_reg_20650.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_313_V_read339_rewind_phi_fu_15680_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_313_V_read339_rewind_phi_fu_15680_p6 = data_313_V_read339_phi_reg_20650.read();
    } else {
        ap_phi_mux_data_313_V_read339_rewind_phi_fu_15680_p6 = data_313_V_read339_rewind_reg_15676.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_314_V_read340_phi_phi_fu_20666_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_314_V_read340_phi_phi_fu_20666_p4 = ap_phi_mux_data_314_V_read340_rewind_phi_fu_15694_p6.read();
    } else {
        ap_phi_mux_data_314_V_read340_phi_phi_fu_20666_p4 = ap_phi_reg_pp0_iter1_data_314_V_read340_phi_reg_20662.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_314_V_read340_rewind_phi_fu_15694_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_314_V_read340_rewind_phi_fu_15694_p6 = data_314_V_read340_phi_reg_20662.read();
    } else {
        ap_phi_mux_data_314_V_read340_rewind_phi_fu_15694_p6 = data_314_V_read340_rewind_reg_15690.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_315_V_read341_phi_phi_fu_20678_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_315_V_read341_phi_phi_fu_20678_p4 = ap_phi_mux_data_315_V_read341_rewind_phi_fu_15708_p6.read();
    } else {
        ap_phi_mux_data_315_V_read341_phi_phi_fu_20678_p4 = ap_phi_reg_pp0_iter1_data_315_V_read341_phi_reg_20674.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_315_V_read341_rewind_phi_fu_15708_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_315_V_read341_rewind_phi_fu_15708_p6 = data_315_V_read341_phi_reg_20674.read();
    } else {
        ap_phi_mux_data_315_V_read341_rewind_phi_fu_15708_p6 = data_315_V_read341_rewind_reg_15704.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_316_V_read342_phi_phi_fu_20690_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_316_V_read342_phi_phi_fu_20690_p4 = ap_phi_mux_data_316_V_read342_rewind_phi_fu_15722_p6.read();
    } else {
        ap_phi_mux_data_316_V_read342_phi_phi_fu_20690_p4 = ap_phi_reg_pp0_iter1_data_316_V_read342_phi_reg_20686.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_316_V_read342_rewind_phi_fu_15722_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_316_V_read342_rewind_phi_fu_15722_p6 = data_316_V_read342_phi_reg_20686.read();
    } else {
        ap_phi_mux_data_316_V_read342_rewind_phi_fu_15722_p6 = data_316_V_read342_rewind_reg_15718.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_317_V_read343_phi_phi_fu_20702_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_317_V_read343_phi_phi_fu_20702_p4 = ap_phi_mux_data_317_V_read343_rewind_phi_fu_15736_p6.read();
    } else {
        ap_phi_mux_data_317_V_read343_phi_phi_fu_20702_p4 = ap_phi_reg_pp0_iter1_data_317_V_read343_phi_reg_20698.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_317_V_read343_rewind_phi_fu_15736_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_317_V_read343_rewind_phi_fu_15736_p6 = data_317_V_read343_phi_reg_20698.read();
    } else {
        ap_phi_mux_data_317_V_read343_rewind_phi_fu_15736_p6 = data_317_V_read343_rewind_reg_15732.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_318_V_read344_phi_phi_fu_20714_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_318_V_read344_phi_phi_fu_20714_p4 = ap_phi_mux_data_318_V_read344_rewind_phi_fu_15750_p6.read();
    } else {
        ap_phi_mux_data_318_V_read344_phi_phi_fu_20714_p4 = ap_phi_reg_pp0_iter1_data_318_V_read344_phi_reg_20710.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_318_V_read344_rewind_phi_fu_15750_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_318_V_read344_rewind_phi_fu_15750_p6 = data_318_V_read344_phi_reg_20710.read();
    } else {
        ap_phi_mux_data_318_V_read344_rewind_phi_fu_15750_p6 = data_318_V_read344_rewind_reg_15746.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_319_V_read345_phi_phi_fu_20726_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_319_V_read345_phi_phi_fu_20726_p4 = ap_phi_mux_data_319_V_read345_rewind_phi_fu_15764_p6.read();
    } else {
        ap_phi_mux_data_319_V_read345_phi_phi_fu_20726_p4 = ap_phi_reg_pp0_iter1_data_319_V_read345_phi_reg_20722.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_319_V_read345_rewind_phi_fu_15764_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_319_V_read345_rewind_phi_fu_15764_p6 = data_319_V_read345_phi_reg_20722.read();
    } else {
        ap_phi_mux_data_319_V_read345_rewind_phi_fu_15764_p6 = data_319_V_read345_rewind_reg_15760.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_31_V_read57_phi_phi_fu_17270_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_31_V_read57_phi_phi_fu_17270_p4 = ap_phi_mux_data_31_V_read57_rewind_phi_fu_11732_p6.read();
    } else {
        ap_phi_mux_data_31_V_read57_phi_phi_fu_17270_p4 = ap_phi_reg_pp0_iter1_data_31_V_read57_phi_reg_17266.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_31_V_read57_rewind_phi_fu_11732_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_31_V_read57_rewind_phi_fu_11732_p6 = data_31_V_read57_phi_reg_17266.read();
    } else {
        ap_phi_mux_data_31_V_read57_rewind_phi_fu_11732_p6 = data_31_V_read57_rewind_reg_11728.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_320_V_read346_phi_phi_fu_20738_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_320_V_read346_phi_phi_fu_20738_p4 = ap_phi_mux_data_320_V_read346_rewind_phi_fu_15778_p6.read();
    } else {
        ap_phi_mux_data_320_V_read346_phi_phi_fu_20738_p4 = ap_phi_reg_pp0_iter1_data_320_V_read346_phi_reg_20734.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_320_V_read346_rewind_phi_fu_15778_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_320_V_read346_rewind_phi_fu_15778_p6 = data_320_V_read346_phi_reg_20734.read();
    } else {
        ap_phi_mux_data_320_V_read346_rewind_phi_fu_15778_p6 = data_320_V_read346_rewind_reg_15774.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_321_V_read347_phi_phi_fu_20750_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_321_V_read347_phi_phi_fu_20750_p4 = ap_phi_mux_data_321_V_read347_rewind_phi_fu_15792_p6.read();
    } else {
        ap_phi_mux_data_321_V_read347_phi_phi_fu_20750_p4 = ap_phi_reg_pp0_iter1_data_321_V_read347_phi_reg_20746.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_321_V_read347_rewind_phi_fu_15792_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_321_V_read347_rewind_phi_fu_15792_p6 = data_321_V_read347_phi_reg_20746.read();
    } else {
        ap_phi_mux_data_321_V_read347_rewind_phi_fu_15792_p6 = data_321_V_read347_rewind_reg_15788.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_322_V_read348_phi_phi_fu_20762_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_322_V_read348_phi_phi_fu_20762_p4 = ap_phi_mux_data_322_V_read348_rewind_phi_fu_15806_p6.read();
    } else {
        ap_phi_mux_data_322_V_read348_phi_phi_fu_20762_p4 = ap_phi_reg_pp0_iter1_data_322_V_read348_phi_reg_20758.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_322_V_read348_rewind_phi_fu_15806_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_322_V_read348_rewind_phi_fu_15806_p6 = data_322_V_read348_phi_reg_20758.read();
    } else {
        ap_phi_mux_data_322_V_read348_rewind_phi_fu_15806_p6 = data_322_V_read348_rewind_reg_15802.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_323_V_read349_phi_phi_fu_20774_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_323_V_read349_phi_phi_fu_20774_p4 = ap_phi_mux_data_323_V_read349_rewind_phi_fu_15820_p6.read();
    } else {
        ap_phi_mux_data_323_V_read349_phi_phi_fu_20774_p4 = ap_phi_reg_pp0_iter1_data_323_V_read349_phi_reg_20770.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_323_V_read349_rewind_phi_fu_15820_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_323_V_read349_rewind_phi_fu_15820_p6 = data_323_V_read349_phi_reg_20770.read();
    } else {
        ap_phi_mux_data_323_V_read349_rewind_phi_fu_15820_p6 = data_323_V_read349_rewind_reg_15816.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_324_V_read350_phi_phi_fu_20786_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_324_V_read350_phi_phi_fu_20786_p4 = ap_phi_mux_data_324_V_read350_rewind_phi_fu_15834_p6.read();
    } else {
        ap_phi_mux_data_324_V_read350_phi_phi_fu_20786_p4 = ap_phi_reg_pp0_iter1_data_324_V_read350_phi_reg_20782.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_324_V_read350_rewind_phi_fu_15834_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_324_V_read350_rewind_phi_fu_15834_p6 = data_324_V_read350_phi_reg_20782.read();
    } else {
        ap_phi_mux_data_324_V_read350_rewind_phi_fu_15834_p6 = data_324_V_read350_rewind_reg_15830.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_325_V_read351_phi_phi_fu_20798_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_325_V_read351_phi_phi_fu_20798_p4 = ap_phi_mux_data_325_V_read351_rewind_phi_fu_15848_p6.read();
    } else {
        ap_phi_mux_data_325_V_read351_phi_phi_fu_20798_p4 = ap_phi_reg_pp0_iter1_data_325_V_read351_phi_reg_20794.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_325_V_read351_rewind_phi_fu_15848_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_325_V_read351_rewind_phi_fu_15848_p6 = data_325_V_read351_phi_reg_20794.read();
    } else {
        ap_phi_mux_data_325_V_read351_rewind_phi_fu_15848_p6 = data_325_V_read351_rewind_reg_15844.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_326_V_read352_phi_phi_fu_20810_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_326_V_read352_phi_phi_fu_20810_p4 = ap_phi_mux_data_326_V_read352_rewind_phi_fu_15862_p6.read();
    } else {
        ap_phi_mux_data_326_V_read352_phi_phi_fu_20810_p4 = ap_phi_reg_pp0_iter1_data_326_V_read352_phi_reg_20806.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_326_V_read352_rewind_phi_fu_15862_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_326_V_read352_rewind_phi_fu_15862_p6 = data_326_V_read352_phi_reg_20806.read();
    } else {
        ap_phi_mux_data_326_V_read352_rewind_phi_fu_15862_p6 = data_326_V_read352_rewind_reg_15858.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_327_V_read353_phi_phi_fu_20822_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_327_V_read353_phi_phi_fu_20822_p4 = ap_phi_mux_data_327_V_read353_rewind_phi_fu_15876_p6.read();
    } else {
        ap_phi_mux_data_327_V_read353_phi_phi_fu_20822_p4 = ap_phi_reg_pp0_iter1_data_327_V_read353_phi_reg_20818.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_327_V_read353_rewind_phi_fu_15876_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_327_V_read353_rewind_phi_fu_15876_p6 = data_327_V_read353_phi_reg_20818.read();
    } else {
        ap_phi_mux_data_327_V_read353_rewind_phi_fu_15876_p6 = data_327_V_read353_rewind_reg_15872.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_328_V_read354_phi_phi_fu_20834_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_328_V_read354_phi_phi_fu_20834_p4 = ap_phi_mux_data_328_V_read354_rewind_phi_fu_15890_p6.read();
    } else {
        ap_phi_mux_data_328_V_read354_phi_phi_fu_20834_p4 = ap_phi_reg_pp0_iter1_data_328_V_read354_phi_reg_20830.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_328_V_read354_rewind_phi_fu_15890_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_328_V_read354_rewind_phi_fu_15890_p6 = data_328_V_read354_phi_reg_20830.read();
    } else {
        ap_phi_mux_data_328_V_read354_rewind_phi_fu_15890_p6 = data_328_V_read354_rewind_reg_15886.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_329_V_read355_phi_phi_fu_20846_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_329_V_read355_phi_phi_fu_20846_p4 = ap_phi_mux_data_329_V_read355_rewind_phi_fu_15904_p6.read();
    } else {
        ap_phi_mux_data_329_V_read355_phi_phi_fu_20846_p4 = ap_phi_reg_pp0_iter1_data_329_V_read355_phi_reg_20842.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_329_V_read355_rewind_phi_fu_15904_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_329_V_read355_rewind_phi_fu_15904_p6 = data_329_V_read355_phi_reg_20842.read();
    } else {
        ap_phi_mux_data_329_V_read355_rewind_phi_fu_15904_p6 = data_329_V_read355_rewind_reg_15900.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_32_V_read58_phi_phi_fu_17282_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_32_V_read58_phi_phi_fu_17282_p4 = ap_phi_mux_data_32_V_read58_rewind_phi_fu_11746_p6.read();
    } else {
        ap_phi_mux_data_32_V_read58_phi_phi_fu_17282_p4 = ap_phi_reg_pp0_iter1_data_32_V_read58_phi_reg_17278.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_32_V_read58_rewind_phi_fu_11746_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_32_V_read58_rewind_phi_fu_11746_p6 = data_32_V_read58_phi_reg_17278.read();
    } else {
        ap_phi_mux_data_32_V_read58_rewind_phi_fu_11746_p6 = data_32_V_read58_rewind_reg_11742.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_330_V_read356_phi_phi_fu_20858_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_330_V_read356_phi_phi_fu_20858_p4 = ap_phi_mux_data_330_V_read356_rewind_phi_fu_15918_p6.read();
    } else {
        ap_phi_mux_data_330_V_read356_phi_phi_fu_20858_p4 = ap_phi_reg_pp0_iter1_data_330_V_read356_phi_reg_20854.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_330_V_read356_rewind_phi_fu_15918_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_330_V_read356_rewind_phi_fu_15918_p6 = data_330_V_read356_phi_reg_20854.read();
    } else {
        ap_phi_mux_data_330_V_read356_rewind_phi_fu_15918_p6 = data_330_V_read356_rewind_reg_15914.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_331_V_read357_phi_phi_fu_20870_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_331_V_read357_phi_phi_fu_20870_p4 = ap_phi_mux_data_331_V_read357_rewind_phi_fu_15932_p6.read();
    } else {
        ap_phi_mux_data_331_V_read357_phi_phi_fu_20870_p4 = ap_phi_reg_pp0_iter1_data_331_V_read357_phi_reg_20866.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_331_V_read357_rewind_phi_fu_15932_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_331_V_read357_rewind_phi_fu_15932_p6 = data_331_V_read357_phi_reg_20866.read();
    } else {
        ap_phi_mux_data_331_V_read357_rewind_phi_fu_15932_p6 = data_331_V_read357_rewind_reg_15928.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_332_V_read358_phi_phi_fu_20882_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_332_V_read358_phi_phi_fu_20882_p4 = ap_phi_mux_data_332_V_read358_rewind_phi_fu_15946_p6.read();
    } else {
        ap_phi_mux_data_332_V_read358_phi_phi_fu_20882_p4 = ap_phi_reg_pp0_iter1_data_332_V_read358_phi_reg_20878.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_332_V_read358_rewind_phi_fu_15946_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_332_V_read358_rewind_phi_fu_15946_p6 = data_332_V_read358_phi_reg_20878.read();
    } else {
        ap_phi_mux_data_332_V_read358_rewind_phi_fu_15946_p6 = data_332_V_read358_rewind_reg_15942.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_333_V_read359_phi_phi_fu_20894_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_333_V_read359_phi_phi_fu_20894_p4 = ap_phi_mux_data_333_V_read359_rewind_phi_fu_15960_p6.read();
    } else {
        ap_phi_mux_data_333_V_read359_phi_phi_fu_20894_p4 = ap_phi_reg_pp0_iter1_data_333_V_read359_phi_reg_20890.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_333_V_read359_rewind_phi_fu_15960_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_333_V_read359_rewind_phi_fu_15960_p6 = data_333_V_read359_phi_reg_20890.read();
    } else {
        ap_phi_mux_data_333_V_read359_rewind_phi_fu_15960_p6 = data_333_V_read359_rewind_reg_15956.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_334_V_read360_phi_phi_fu_20906_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_334_V_read360_phi_phi_fu_20906_p4 = ap_phi_mux_data_334_V_read360_rewind_phi_fu_15974_p6.read();
    } else {
        ap_phi_mux_data_334_V_read360_phi_phi_fu_20906_p4 = ap_phi_reg_pp0_iter1_data_334_V_read360_phi_reg_20902.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_334_V_read360_rewind_phi_fu_15974_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_334_V_read360_rewind_phi_fu_15974_p6 = data_334_V_read360_phi_reg_20902.read();
    } else {
        ap_phi_mux_data_334_V_read360_rewind_phi_fu_15974_p6 = data_334_V_read360_rewind_reg_15970.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_335_V_read361_phi_phi_fu_20918_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_335_V_read361_phi_phi_fu_20918_p4 = ap_phi_mux_data_335_V_read361_rewind_phi_fu_15988_p6.read();
    } else {
        ap_phi_mux_data_335_V_read361_phi_phi_fu_20918_p4 = ap_phi_reg_pp0_iter1_data_335_V_read361_phi_reg_20914.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_335_V_read361_rewind_phi_fu_15988_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_335_V_read361_rewind_phi_fu_15988_p6 = data_335_V_read361_phi_reg_20914.read();
    } else {
        ap_phi_mux_data_335_V_read361_rewind_phi_fu_15988_p6 = data_335_V_read361_rewind_reg_15984.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_336_V_read362_phi_phi_fu_20930_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_336_V_read362_phi_phi_fu_20930_p4 = ap_phi_mux_data_336_V_read362_rewind_phi_fu_16002_p6.read();
    } else {
        ap_phi_mux_data_336_V_read362_phi_phi_fu_20930_p4 = ap_phi_reg_pp0_iter1_data_336_V_read362_phi_reg_20926.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_336_V_read362_rewind_phi_fu_16002_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_336_V_read362_rewind_phi_fu_16002_p6 = data_336_V_read362_phi_reg_20926.read();
    } else {
        ap_phi_mux_data_336_V_read362_rewind_phi_fu_16002_p6 = data_336_V_read362_rewind_reg_15998.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_337_V_read363_phi_phi_fu_20942_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_337_V_read363_phi_phi_fu_20942_p4 = ap_phi_mux_data_337_V_read363_rewind_phi_fu_16016_p6.read();
    } else {
        ap_phi_mux_data_337_V_read363_phi_phi_fu_20942_p4 = ap_phi_reg_pp0_iter1_data_337_V_read363_phi_reg_20938.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_337_V_read363_rewind_phi_fu_16016_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_337_V_read363_rewind_phi_fu_16016_p6 = data_337_V_read363_phi_reg_20938.read();
    } else {
        ap_phi_mux_data_337_V_read363_rewind_phi_fu_16016_p6 = data_337_V_read363_rewind_reg_16012.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_338_V_read364_phi_phi_fu_20954_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_338_V_read364_phi_phi_fu_20954_p4 = ap_phi_mux_data_338_V_read364_rewind_phi_fu_16030_p6.read();
    } else {
        ap_phi_mux_data_338_V_read364_phi_phi_fu_20954_p4 = ap_phi_reg_pp0_iter1_data_338_V_read364_phi_reg_20950.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_338_V_read364_rewind_phi_fu_16030_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_338_V_read364_rewind_phi_fu_16030_p6 = data_338_V_read364_phi_reg_20950.read();
    } else {
        ap_phi_mux_data_338_V_read364_rewind_phi_fu_16030_p6 = data_338_V_read364_rewind_reg_16026.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_339_V_read365_phi_phi_fu_20966_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_339_V_read365_phi_phi_fu_20966_p4 = ap_phi_mux_data_339_V_read365_rewind_phi_fu_16044_p6.read();
    } else {
        ap_phi_mux_data_339_V_read365_phi_phi_fu_20966_p4 = ap_phi_reg_pp0_iter1_data_339_V_read365_phi_reg_20962.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_339_V_read365_rewind_phi_fu_16044_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_339_V_read365_rewind_phi_fu_16044_p6 = data_339_V_read365_phi_reg_20962.read();
    } else {
        ap_phi_mux_data_339_V_read365_rewind_phi_fu_16044_p6 = data_339_V_read365_rewind_reg_16040.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_33_V_read59_phi_phi_fu_17294_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_33_V_read59_phi_phi_fu_17294_p4 = ap_phi_mux_data_33_V_read59_rewind_phi_fu_11760_p6.read();
    } else {
        ap_phi_mux_data_33_V_read59_phi_phi_fu_17294_p4 = ap_phi_reg_pp0_iter1_data_33_V_read59_phi_reg_17290.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_33_V_read59_rewind_phi_fu_11760_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_33_V_read59_rewind_phi_fu_11760_p6 = data_33_V_read59_phi_reg_17290.read();
    } else {
        ap_phi_mux_data_33_V_read59_rewind_phi_fu_11760_p6 = data_33_V_read59_rewind_reg_11756.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_340_V_read366_phi_phi_fu_20978_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_340_V_read366_phi_phi_fu_20978_p4 = ap_phi_mux_data_340_V_read366_rewind_phi_fu_16058_p6.read();
    } else {
        ap_phi_mux_data_340_V_read366_phi_phi_fu_20978_p4 = ap_phi_reg_pp0_iter1_data_340_V_read366_phi_reg_20974.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_340_V_read366_rewind_phi_fu_16058_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_340_V_read366_rewind_phi_fu_16058_p6 = data_340_V_read366_phi_reg_20974.read();
    } else {
        ap_phi_mux_data_340_V_read366_rewind_phi_fu_16058_p6 = data_340_V_read366_rewind_reg_16054.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_341_V_read367_phi_phi_fu_20990_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_341_V_read367_phi_phi_fu_20990_p4 = ap_phi_mux_data_341_V_read367_rewind_phi_fu_16072_p6.read();
    } else {
        ap_phi_mux_data_341_V_read367_phi_phi_fu_20990_p4 = ap_phi_reg_pp0_iter1_data_341_V_read367_phi_reg_20986.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_341_V_read367_rewind_phi_fu_16072_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_341_V_read367_rewind_phi_fu_16072_p6 = data_341_V_read367_phi_reg_20986.read();
    } else {
        ap_phi_mux_data_341_V_read367_rewind_phi_fu_16072_p6 = data_341_V_read367_rewind_reg_16068.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_342_V_read368_phi_phi_fu_21002_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_342_V_read368_phi_phi_fu_21002_p4 = ap_phi_mux_data_342_V_read368_rewind_phi_fu_16086_p6.read();
    } else {
        ap_phi_mux_data_342_V_read368_phi_phi_fu_21002_p4 = ap_phi_reg_pp0_iter1_data_342_V_read368_phi_reg_20998.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_342_V_read368_rewind_phi_fu_16086_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_342_V_read368_rewind_phi_fu_16086_p6 = data_342_V_read368_phi_reg_20998.read();
    } else {
        ap_phi_mux_data_342_V_read368_rewind_phi_fu_16086_p6 = data_342_V_read368_rewind_reg_16082.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_343_V_read369_phi_phi_fu_21014_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_343_V_read369_phi_phi_fu_21014_p4 = ap_phi_mux_data_343_V_read369_rewind_phi_fu_16100_p6.read();
    } else {
        ap_phi_mux_data_343_V_read369_phi_phi_fu_21014_p4 = ap_phi_reg_pp0_iter1_data_343_V_read369_phi_reg_21010.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_343_V_read369_rewind_phi_fu_16100_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_343_V_read369_rewind_phi_fu_16100_p6 = data_343_V_read369_phi_reg_21010.read();
    } else {
        ap_phi_mux_data_343_V_read369_rewind_phi_fu_16100_p6 = data_343_V_read369_rewind_reg_16096.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_344_V_read370_phi_phi_fu_21026_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_344_V_read370_phi_phi_fu_21026_p4 = ap_phi_mux_data_344_V_read370_rewind_phi_fu_16114_p6.read();
    } else {
        ap_phi_mux_data_344_V_read370_phi_phi_fu_21026_p4 = ap_phi_reg_pp0_iter1_data_344_V_read370_phi_reg_21022.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_344_V_read370_rewind_phi_fu_16114_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_344_V_read370_rewind_phi_fu_16114_p6 = data_344_V_read370_phi_reg_21022.read();
    } else {
        ap_phi_mux_data_344_V_read370_rewind_phi_fu_16114_p6 = data_344_V_read370_rewind_reg_16110.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_345_V_read371_phi_phi_fu_21038_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_345_V_read371_phi_phi_fu_21038_p4 = ap_phi_mux_data_345_V_read371_rewind_phi_fu_16128_p6.read();
    } else {
        ap_phi_mux_data_345_V_read371_phi_phi_fu_21038_p4 = ap_phi_reg_pp0_iter1_data_345_V_read371_phi_reg_21034.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_345_V_read371_rewind_phi_fu_16128_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_345_V_read371_rewind_phi_fu_16128_p6 = data_345_V_read371_phi_reg_21034.read();
    } else {
        ap_phi_mux_data_345_V_read371_rewind_phi_fu_16128_p6 = data_345_V_read371_rewind_reg_16124.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_346_V_read372_phi_phi_fu_21050_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_346_V_read372_phi_phi_fu_21050_p4 = ap_phi_mux_data_346_V_read372_rewind_phi_fu_16142_p6.read();
    } else {
        ap_phi_mux_data_346_V_read372_phi_phi_fu_21050_p4 = ap_phi_reg_pp0_iter1_data_346_V_read372_phi_reg_21046.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_346_V_read372_rewind_phi_fu_16142_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_346_V_read372_rewind_phi_fu_16142_p6 = data_346_V_read372_phi_reg_21046.read();
    } else {
        ap_phi_mux_data_346_V_read372_rewind_phi_fu_16142_p6 = data_346_V_read372_rewind_reg_16138.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_347_V_read373_phi_phi_fu_21062_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_347_V_read373_phi_phi_fu_21062_p4 = ap_phi_mux_data_347_V_read373_rewind_phi_fu_16156_p6.read();
    } else {
        ap_phi_mux_data_347_V_read373_phi_phi_fu_21062_p4 = ap_phi_reg_pp0_iter1_data_347_V_read373_phi_reg_21058.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_347_V_read373_rewind_phi_fu_16156_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_347_V_read373_rewind_phi_fu_16156_p6 = data_347_V_read373_phi_reg_21058.read();
    } else {
        ap_phi_mux_data_347_V_read373_rewind_phi_fu_16156_p6 = data_347_V_read373_rewind_reg_16152.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_348_V_read374_phi_phi_fu_21074_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_348_V_read374_phi_phi_fu_21074_p4 = ap_phi_mux_data_348_V_read374_rewind_phi_fu_16170_p6.read();
    } else {
        ap_phi_mux_data_348_V_read374_phi_phi_fu_21074_p4 = ap_phi_reg_pp0_iter1_data_348_V_read374_phi_reg_21070.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_348_V_read374_rewind_phi_fu_16170_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_348_V_read374_rewind_phi_fu_16170_p6 = data_348_V_read374_phi_reg_21070.read();
    } else {
        ap_phi_mux_data_348_V_read374_rewind_phi_fu_16170_p6 = data_348_V_read374_rewind_reg_16166.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_349_V_read375_phi_phi_fu_21086_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_349_V_read375_phi_phi_fu_21086_p4 = ap_phi_mux_data_349_V_read375_rewind_phi_fu_16184_p6.read();
    } else {
        ap_phi_mux_data_349_V_read375_phi_phi_fu_21086_p4 = ap_phi_reg_pp0_iter1_data_349_V_read375_phi_reg_21082.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_349_V_read375_rewind_phi_fu_16184_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_349_V_read375_rewind_phi_fu_16184_p6 = data_349_V_read375_phi_reg_21082.read();
    } else {
        ap_phi_mux_data_349_V_read375_rewind_phi_fu_16184_p6 = data_349_V_read375_rewind_reg_16180.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_34_V_read60_phi_phi_fu_17306_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_34_V_read60_phi_phi_fu_17306_p4 = ap_phi_mux_data_34_V_read60_rewind_phi_fu_11774_p6.read();
    } else {
        ap_phi_mux_data_34_V_read60_phi_phi_fu_17306_p4 = ap_phi_reg_pp0_iter1_data_34_V_read60_phi_reg_17302.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_34_V_read60_rewind_phi_fu_11774_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_34_V_read60_rewind_phi_fu_11774_p6 = data_34_V_read60_phi_reg_17302.read();
    } else {
        ap_phi_mux_data_34_V_read60_rewind_phi_fu_11774_p6 = data_34_V_read60_rewind_reg_11770.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_350_V_read376_phi_phi_fu_21098_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_350_V_read376_phi_phi_fu_21098_p4 = ap_phi_mux_data_350_V_read376_rewind_phi_fu_16198_p6.read();
    } else {
        ap_phi_mux_data_350_V_read376_phi_phi_fu_21098_p4 = ap_phi_reg_pp0_iter1_data_350_V_read376_phi_reg_21094.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_350_V_read376_rewind_phi_fu_16198_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_350_V_read376_rewind_phi_fu_16198_p6 = data_350_V_read376_phi_reg_21094.read();
    } else {
        ap_phi_mux_data_350_V_read376_rewind_phi_fu_16198_p6 = data_350_V_read376_rewind_reg_16194.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_351_V_read377_phi_phi_fu_21110_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_351_V_read377_phi_phi_fu_21110_p4 = ap_phi_mux_data_351_V_read377_rewind_phi_fu_16212_p6.read();
    } else {
        ap_phi_mux_data_351_V_read377_phi_phi_fu_21110_p4 = ap_phi_reg_pp0_iter1_data_351_V_read377_phi_reg_21106.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_351_V_read377_rewind_phi_fu_16212_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_351_V_read377_rewind_phi_fu_16212_p6 = data_351_V_read377_phi_reg_21106.read();
    } else {
        ap_phi_mux_data_351_V_read377_rewind_phi_fu_16212_p6 = data_351_V_read377_rewind_reg_16208.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_352_V_read378_phi_phi_fu_21122_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_352_V_read378_phi_phi_fu_21122_p4 = ap_phi_mux_data_352_V_read378_rewind_phi_fu_16226_p6.read();
    } else {
        ap_phi_mux_data_352_V_read378_phi_phi_fu_21122_p4 = ap_phi_reg_pp0_iter1_data_352_V_read378_phi_reg_21118.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_352_V_read378_rewind_phi_fu_16226_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_352_V_read378_rewind_phi_fu_16226_p6 = data_352_V_read378_phi_reg_21118.read();
    } else {
        ap_phi_mux_data_352_V_read378_rewind_phi_fu_16226_p6 = data_352_V_read378_rewind_reg_16222.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_353_V_read379_phi_phi_fu_21134_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_353_V_read379_phi_phi_fu_21134_p4 = ap_phi_mux_data_353_V_read379_rewind_phi_fu_16240_p6.read();
    } else {
        ap_phi_mux_data_353_V_read379_phi_phi_fu_21134_p4 = ap_phi_reg_pp0_iter1_data_353_V_read379_phi_reg_21130.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_353_V_read379_rewind_phi_fu_16240_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_353_V_read379_rewind_phi_fu_16240_p6 = data_353_V_read379_phi_reg_21130.read();
    } else {
        ap_phi_mux_data_353_V_read379_rewind_phi_fu_16240_p6 = data_353_V_read379_rewind_reg_16236.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_354_V_read380_phi_phi_fu_21146_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_354_V_read380_phi_phi_fu_21146_p4 = ap_phi_mux_data_354_V_read380_rewind_phi_fu_16254_p6.read();
    } else {
        ap_phi_mux_data_354_V_read380_phi_phi_fu_21146_p4 = ap_phi_reg_pp0_iter1_data_354_V_read380_phi_reg_21142.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_354_V_read380_rewind_phi_fu_16254_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_354_V_read380_rewind_phi_fu_16254_p6 = data_354_V_read380_phi_reg_21142.read();
    } else {
        ap_phi_mux_data_354_V_read380_rewind_phi_fu_16254_p6 = data_354_V_read380_rewind_reg_16250.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_355_V_read381_phi_phi_fu_21158_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_355_V_read381_phi_phi_fu_21158_p4 = ap_phi_mux_data_355_V_read381_rewind_phi_fu_16268_p6.read();
    } else {
        ap_phi_mux_data_355_V_read381_phi_phi_fu_21158_p4 = ap_phi_reg_pp0_iter1_data_355_V_read381_phi_reg_21154.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_355_V_read381_rewind_phi_fu_16268_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_355_V_read381_rewind_phi_fu_16268_p6 = data_355_V_read381_phi_reg_21154.read();
    } else {
        ap_phi_mux_data_355_V_read381_rewind_phi_fu_16268_p6 = data_355_V_read381_rewind_reg_16264.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_356_V_read382_phi_phi_fu_21170_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_356_V_read382_phi_phi_fu_21170_p4 = ap_phi_mux_data_356_V_read382_rewind_phi_fu_16282_p6.read();
    } else {
        ap_phi_mux_data_356_V_read382_phi_phi_fu_21170_p4 = ap_phi_reg_pp0_iter1_data_356_V_read382_phi_reg_21166.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_356_V_read382_rewind_phi_fu_16282_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_356_V_read382_rewind_phi_fu_16282_p6 = data_356_V_read382_phi_reg_21166.read();
    } else {
        ap_phi_mux_data_356_V_read382_rewind_phi_fu_16282_p6 = data_356_V_read382_rewind_reg_16278.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_357_V_read383_phi_phi_fu_21182_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_357_V_read383_phi_phi_fu_21182_p4 = ap_phi_mux_data_357_V_read383_rewind_phi_fu_16296_p6.read();
    } else {
        ap_phi_mux_data_357_V_read383_phi_phi_fu_21182_p4 = ap_phi_reg_pp0_iter1_data_357_V_read383_phi_reg_21178.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_357_V_read383_rewind_phi_fu_16296_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_357_V_read383_rewind_phi_fu_16296_p6 = data_357_V_read383_phi_reg_21178.read();
    } else {
        ap_phi_mux_data_357_V_read383_rewind_phi_fu_16296_p6 = data_357_V_read383_rewind_reg_16292.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_358_V_read384_phi_phi_fu_21194_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_358_V_read384_phi_phi_fu_21194_p4 = ap_phi_mux_data_358_V_read384_rewind_phi_fu_16310_p6.read();
    } else {
        ap_phi_mux_data_358_V_read384_phi_phi_fu_21194_p4 = ap_phi_reg_pp0_iter1_data_358_V_read384_phi_reg_21190.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_358_V_read384_rewind_phi_fu_16310_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_358_V_read384_rewind_phi_fu_16310_p6 = data_358_V_read384_phi_reg_21190.read();
    } else {
        ap_phi_mux_data_358_V_read384_rewind_phi_fu_16310_p6 = data_358_V_read384_rewind_reg_16306.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_359_V_read385_phi_phi_fu_21206_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_359_V_read385_phi_phi_fu_21206_p4 = ap_phi_mux_data_359_V_read385_rewind_phi_fu_16324_p6.read();
    } else {
        ap_phi_mux_data_359_V_read385_phi_phi_fu_21206_p4 = ap_phi_reg_pp0_iter1_data_359_V_read385_phi_reg_21202.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_359_V_read385_rewind_phi_fu_16324_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_359_V_read385_rewind_phi_fu_16324_p6 = data_359_V_read385_phi_reg_21202.read();
    } else {
        ap_phi_mux_data_359_V_read385_rewind_phi_fu_16324_p6 = data_359_V_read385_rewind_reg_16320.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_35_V_read61_phi_phi_fu_17318_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_35_V_read61_phi_phi_fu_17318_p4 = ap_phi_mux_data_35_V_read61_rewind_phi_fu_11788_p6.read();
    } else {
        ap_phi_mux_data_35_V_read61_phi_phi_fu_17318_p4 = ap_phi_reg_pp0_iter1_data_35_V_read61_phi_reg_17314.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_35_V_read61_rewind_phi_fu_11788_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_35_V_read61_rewind_phi_fu_11788_p6 = data_35_V_read61_phi_reg_17314.read();
    } else {
        ap_phi_mux_data_35_V_read61_rewind_phi_fu_11788_p6 = data_35_V_read61_rewind_reg_11784.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_360_V_read386_phi_phi_fu_21218_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_360_V_read386_phi_phi_fu_21218_p4 = ap_phi_mux_data_360_V_read386_rewind_phi_fu_16338_p6.read();
    } else {
        ap_phi_mux_data_360_V_read386_phi_phi_fu_21218_p4 = ap_phi_reg_pp0_iter1_data_360_V_read386_phi_reg_21214.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_360_V_read386_rewind_phi_fu_16338_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_360_V_read386_rewind_phi_fu_16338_p6 = data_360_V_read386_phi_reg_21214.read();
    } else {
        ap_phi_mux_data_360_V_read386_rewind_phi_fu_16338_p6 = data_360_V_read386_rewind_reg_16334.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_361_V_read387_phi_phi_fu_21230_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_361_V_read387_phi_phi_fu_21230_p4 = ap_phi_mux_data_361_V_read387_rewind_phi_fu_16352_p6.read();
    } else {
        ap_phi_mux_data_361_V_read387_phi_phi_fu_21230_p4 = ap_phi_reg_pp0_iter1_data_361_V_read387_phi_reg_21226.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_361_V_read387_rewind_phi_fu_16352_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_361_V_read387_rewind_phi_fu_16352_p6 = data_361_V_read387_phi_reg_21226.read();
    } else {
        ap_phi_mux_data_361_V_read387_rewind_phi_fu_16352_p6 = data_361_V_read387_rewind_reg_16348.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_362_V_read388_phi_phi_fu_21242_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_362_V_read388_phi_phi_fu_21242_p4 = ap_phi_mux_data_362_V_read388_rewind_phi_fu_16366_p6.read();
    } else {
        ap_phi_mux_data_362_V_read388_phi_phi_fu_21242_p4 = ap_phi_reg_pp0_iter1_data_362_V_read388_phi_reg_21238.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_362_V_read388_rewind_phi_fu_16366_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_362_V_read388_rewind_phi_fu_16366_p6 = data_362_V_read388_phi_reg_21238.read();
    } else {
        ap_phi_mux_data_362_V_read388_rewind_phi_fu_16366_p6 = data_362_V_read388_rewind_reg_16362.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_363_V_read389_phi_phi_fu_21254_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_363_V_read389_phi_phi_fu_21254_p4 = ap_phi_mux_data_363_V_read389_rewind_phi_fu_16380_p6.read();
    } else {
        ap_phi_mux_data_363_V_read389_phi_phi_fu_21254_p4 = ap_phi_reg_pp0_iter1_data_363_V_read389_phi_reg_21250.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_363_V_read389_rewind_phi_fu_16380_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_363_V_read389_rewind_phi_fu_16380_p6 = data_363_V_read389_phi_reg_21250.read();
    } else {
        ap_phi_mux_data_363_V_read389_rewind_phi_fu_16380_p6 = data_363_V_read389_rewind_reg_16376.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_364_V_read390_phi_phi_fu_21266_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_364_V_read390_phi_phi_fu_21266_p4 = ap_phi_mux_data_364_V_read390_rewind_phi_fu_16394_p6.read();
    } else {
        ap_phi_mux_data_364_V_read390_phi_phi_fu_21266_p4 = ap_phi_reg_pp0_iter1_data_364_V_read390_phi_reg_21262.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_364_V_read390_rewind_phi_fu_16394_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_364_V_read390_rewind_phi_fu_16394_p6 = data_364_V_read390_phi_reg_21262.read();
    } else {
        ap_phi_mux_data_364_V_read390_rewind_phi_fu_16394_p6 = data_364_V_read390_rewind_reg_16390.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_365_V_read391_phi_phi_fu_21278_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_365_V_read391_phi_phi_fu_21278_p4 = ap_phi_mux_data_365_V_read391_rewind_phi_fu_16408_p6.read();
    } else {
        ap_phi_mux_data_365_V_read391_phi_phi_fu_21278_p4 = ap_phi_reg_pp0_iter1_data_365_V_read391_phi_reg_21274.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_365_V_read391_rewind_phi_fu_16408_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_365_V_read391_rewind_phi_fu_16408_p6 = data_365_V_read391_phi_reg_21274.read();
    } else {
        ap_phi_mux_data_365_V_read391_rewind_phi_fu_16408_p6 = data_365_V_read391_rewind_reg_16404.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_366_V_read392_phi_phi_fu_21290_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_366_V_read392_phi_phi_fu_21290_p4 = ap_phi_mux_data_366_V_read392_rewind_phi_fu_16422_p6.read();
    } else {
        ap_phi_mux_data_366_V_read392_phi_phi_fu_21290_p4 = ap_phi_reg_pp0_iter1_data_366_V_read392_phi_reg_21286.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_366_V_read392_rewind_phi_fu_16422_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_366_V_read392_rewind_phi_fu_16422_p6 = data_366_V_read392_phi_reg_21286.read();
    } else {
        ap_phi_mux_data_366_V_read392_rewind_phi_fu_16422_p6 = data_366_V_read392_rewind_reg_16418.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_367_V_read393_phi_phi_fu_21302_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_367_V_read393_phi_phi_fu_21302_p4 = ap_phi_mux_data_367_V_read393_rewind_phi_fu_16436_p6.read();
    } else {
        ap_phi_mux_data_367_V_read393_phi_phi_fu_21302_p4 = ap_phi_reg_pp0_iter1_data_367_V_read393_phi_reg_21298.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_367_V_read393_rewind_phi_fu_16436_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_367_V_read393_rewind_phi_fu_16436_p6 = data_367_V_read393_phi_reg_21298.read();
    } else {
        ap_phi_mux_data_367_V_read393_rewind_phi_fu_16436_p6 = data_367_V_read393_rewind_reg_16432.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_368_V_read394_phi_phi_fu_21314_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_368_V_read394_phi_phi_fu_21314_p4 = ap_phi_mux_data_368_V_read394_rewind_phi_fu_16450_p6.read();
    } else {
        ap_phi_mux_data_368_V_read394_phi_phi_fu_21314_p4 = ap_phi_reg_pp0_iter1_data_368_V_read394_phi_reg_21310.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_368_V_read394_rewind_phi_fu_16450_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_368_V_read394_rewind_phi_fu_16450_p6 = data_368_V_read394_phi_reg_21310.read();
    } else {
        ap_phi_mux_data_368_V_read394_rewind_phi_fu_16450_p6 = data_368_V_read394_rewind_reg_16446.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_369_V_read395_phi_phi_fu_21326_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_369_V_read395_phi_phi_fu_21326_p4 = ap_phi_mux_data_369_V_read395_rewind_phi_fu_16464_p6.read();
    } else {
        ap_phi_mux_data_369_V_read395_phi_phi_fu_21326_p4 = ap_phi_reg_pp0_iter1_data_369_V_read395_phi_reg_21322.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_369_V_read395_rewind_phi_fu_16464_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_369_V_read395_rewind_phi_fu_16464_p6 = data_369_V_read395_phi_reg_21322.read();
    } else {
        ap_phi_mux_data_369_V_read395_rewind_phi_fu_16464_p6 = data_369_V_read395_rewind_reg_16460.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_36_V_read62_phi_phi_fu_17330_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_36_V_read62_phi_phi_fu_17330_p4 = ap_phi_mux_data_36_V_read62_rewind_phi_fu_11802_p6.read();
    } else {
        ap_phi_mux_data_36_V_read62_phi_phi_fu_17330_p4 = ap_phi_reg_pp0_iter1_data_36_V_read62_phi_reg_17326.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_36_V_read62_rewind_phi_fu_11802_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_36_V_read62_rewind_phi_fu_11802_p6 = data_36_V_read62_phi_reg_17326.read();
    } else {
        ap_phi_mux_data_36_V_read62_rewind_phi_fu_11802_p6 = data_36_V_read62_rewind_reg_11798.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_370_V_read396_phi_phi_fu_21338_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_370_V_read396_phi_phi_fu_21338_p4 = ap_phi_mux_data_370_V_read396_rewind_phi_fu_16478_p6.read();
    } else {
        ap_phi_mux_data_370_V_read396_phi_phi_fu_21338_p4 = ap_phi_reg_pp0_iter1_data_370_V_read396_phi_reg_21334.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_370_V_read396_rewind_phi_fu_16478_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_370_V_read396_rewind_phi_fu_16478_p6 = data_370_V_read396_phi_reg_21334.read();
    } else {
        ap_phi_mux_data_370_V_read396_rewind_phi_fu_16478_p6 = data_370_V_read396_rewind_reg_16474.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_371_V_read397_phi_phi_fu_21350_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_371_V_read397_phi_phi_fu_21350_p4 = ap_phi_mux_data_371_V_read397_rewind_phi_fu_16492_p6.read();
    } else {
        ap_phi_mux_data_371_V_read397_phi_phi_fu_21350_p4 = ap_phi_reg_pp0_iter1_data_371_V_read397_phi_reg_21346.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_371_V_read397_rewind_phi_fu_16492_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_371_V_read397_rewind_phi_fu_16492_p6 = data_371_V_read397_phi_reg_21346.read();
    } else {
        ap_phi_mux_data_371_V_read397_rewind_phi_fu_16492_p6 = data_371_V_read397_rewind_reg_16488.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_372_V_read398_phi_phi_fu_21362_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_372_V_read398_phi_phi_fu_21362_p4 = ap_phi_mux_data_372_V_read398_rewind_phi_fu_16506_p6.read();
    } else {
        ap_phi_mux_data_372_V_read398_phi_phi_fu_21362_p4 = ap_phi_reg_pp0_iter1_data_372_V_read398_phi_reg_21358.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_372_V_read398_rewind_phi_fu_16506_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_372_V_read398_rewind_phi_fu_16506_p6 = data_372_V_read398_phi_reg_21358.read();
    } else {
        ap_phi_mux_data_372_V_read398_rewind_phi_fu_16506_p6 = data_372_V_read398_rewind_reg_16502.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_373_V_read399_phi_phi_fu_21374_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_373_V_read399_phi_phi_fu_21374_p4 = ap_phi_mux_data_373_V_read399_rewind_phi_fu_16520_p6.read();
    } else {
        ap_phi_mux_data_373_V_read399_phi_phi_fu_21374_p4 = ap_phi_reg_pp0_iter1_data_373_V_read399_phi_reg_21370.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_373_V_read399_rewind_phi_fu_16520_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_373_V_read399_rewind_phi_fu_16520_p6 = data_373_V_read399_phi_reg_21370.read();
    } else {
        ap_phi_mux_data_373_V_read399_rewind_phi_fu_16520_p6 = data_373_V_read399_rewind_reg_16516.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_374_V_read400_phi_phi_fu_21386_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_374_V_read400_phi_phi_fu_21386_p4 = ap_phi_mux_data_374_V_read400_rewind_phi_fu_16534_p6.read();
    } else {
        ap_phi_mux_data_374_V_read400_phi_phi_fu_21386_p4 = ap_phi_reg_pp0_iter1_data_374_V_read400_phi_reg_21382.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_374_V_read400_rewind_phi_fu_16534_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_374_V_read400_rewind_phi_fu_16534_p6 = data_374_V_read400_phi_reg_21382.read();
    } else {
        ap_phi_mux_data_374_V_read400_rewind_phi_fu_16534_p6 = data_374_V_read400_rewind_reg_16530.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_375_V_read401_phi_phi_fu_21398_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_375_V_read401_phi_phi_fu_21398_p4 = ap_phi_mux_data_375_V_read401_rewind_phi_fu_16548_p6.read();
    } else {
        ap_phi_mux_data_375_V_read401_phi_phi_fu_21398_p4 = ap_phi_reg_pp0_iter1_data_375_V_read401_phi_reg_21394.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_375_V_read401_rewind_phi_fu_16548_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_375_V_read401_rewind_phi_fu_16548_p6 = data_375_V_read401_phi_reg_21394.read();
    } else {
        ap_phi_mux_data_375_V_read401_rewind_phi_fu_16548_p6 = data_375_V_read401_rewind_reg_16544.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_376_V_read402_phi_phi_fu_21410_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_376_V_read402_phi_phi_fu_21410_p4 = ap_phi_mux_data_376_V_read402_rewind_phi_fu_16562_p6.read();
    } else {
        ap_phi_mux_data_376_V_read402_phi_phi_fu_21410_p4 = ap_phi_reg_pp0_iter1_data_376_V_read402_phi_reg_21406.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_376_V_read402_rewind_phi_fu_16562_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_376_V_read402_rewind_phi_fu_16562_p6 = data_376_V_read402_phi_reg_21406.read();
    } else {
        ap_phi_mux_data_376_V_read402_rewind_phi_fu_16562_p6 = data_376_V_read402_rewind_reg_16558.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_377_V_read403_phi_phi_fu_21422_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_377_V_read403_phi_phi_fu_21422_p4 = ap_phi_mux_data_377_V_read403_rewind_phi_fu_16576_p6.read();
    } else {
        ap_phi_mux_data_377_V_read403_phi_phi_fu_21422_p4 = ap_phi_reg_pp0_iter1_data_377_V_read403_phi_reg_21418.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_377_V_read403_rewind_phi_fu_16576_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_377_V_read403_rewind_phi_fu_16576_p6 = data_377_V_read403_phi_reg_21418.read();
    } else {
        ap_phi_mux_data_377_V_read403_rewind_phi_fu_16576_p6 = data_377_V_read403_rewind_reg_16572.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_378_V_read404_phi_phi_fu_21434_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_378_V_read404_phi_phi_fu_21434_p4 = ap_phi_mux_data_378_V_read404_rewind_phi_fu_16590_p6.read();
    } else {
        ap_phi_mux_data_378_V_read404_phi_phi_fu_21434_p4 = ap_phi_reg_pp0_iter1_data_378_V_read404_phi_reg_21430.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_378_V_read404_rewind_phi_fu_16590_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_378_V_read404_rewind_phi_fu_16590_p6 = data_378_V_read404_phi_reg_21430.read();
    } else {
        ap_phi_mux_data_378_V_read404_rewind_phi_fu_16590_p6 = data_378_V_read404_rewind_reg_16586.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_379_V_read405_phi_phi_fu_21446_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_379_V_read405_phi_phi_fu_21446_p4 = ap_phi_mux_data_379_V_read405_rewind_phi_fu_16604_p6.read();
    } else {
        ap_phi_mux_data_379_V_read405_phi_phi_fu_21446_p4 = ap_phi_reg_pp0_iter1_data_379_V_read405_phi_reg_21442.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_379_V_read405_rewind_phi_fu_16604_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_379_V_read405_rewind_phi_fu_16604_p6 = data_379_V_read405_phi_reg_21442.read();
    } else {
        ap_phi_mux_data_379_V_read405_rewind_phi_fu_16604_p6 = data_379_V_read405_rewind_reg_16600.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_37_V_read63_phi_phi_fu_17342_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_37_V_read63_phi_phi_fu_17342_p4 = ap_phi_mux_data_37_V_read63_rewind_phi_fu_11816_p6.read();
    } else {
        ap_phi_mux_data_37_V_read63_phi_phi_fu_17342_p4 = ap_phi_reg_pp0_iter1_data_37_V_read63_phi_reg_17338.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_37_V_read63_rewind_phi_fu_11816_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_37_V_read63_rewind_phi_fu_11816_p6 = data_37_V_read63_phi_reg_17338.read();
    } else {
        ap_phi_mux_data_37_V_read63_rewind_phi_fu_11816_p6 = data_37_V_read63_rewind_reg_11812.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_380_V_read406_phi_phi_fu_21458_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_380_V_read406_phi_phi_fu_21458_p4 = ap_phi_mux_data_380_V_read406_rewind_phi_fu_16618_p6.read();
    } else {
        ap_phi_mux_data_380_V_read406_phi_phi_fu_21458_p4 = ap_phi_reg_pp0_iter1_data_380_V_read406_phi_reg_21454.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_380_V_read406_rewind_phi_fu_16618_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_380_V_read406_rewind_phi_fu_16618_p6 = data_380_V_read406_phi_reg_21454.read();
    } else {
        ap_phi_mux_data_380_V_read406_rewind_phi_fu_16618_p6 = data_380_V_read406_rewind_reg_16614.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_381_V_read407_phi_phi_fu_21470_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_381_V_read407_phi_phi_fu_21470_p4 = ap_phi_mux_data_381_V_read407_rewind_phi_fu_16632_p6.read();
    } else {
        ap_phi_mux_data_381_V_read407_phi_phi_fu_21470_p4 = ap_phi_reg_pp0_iter1_data_381_V_read407_phi_reg_21466.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_381_V_read407_rewind_phi_fu_16632_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_381_V_read407_rewind_phi_fu_16632_p6 = data_381_V_read407_phi_reg_21466.read();
    } else {
        ap_phi_mux_data_381_V_read407_rewind_phi_fu_16632_p6 = data_381_V_read407_rewind_reg_16628.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_382_V_read408_phi_phi_fu_21482_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_382_V_read408_phi_phi_fu_21482_p4 = ap_phi_mux_data_382_V_read408_rewind_phi_fu_16646_p6.read();
    } else {
        ap_phi_mux_data_382_V_read408_phi_phi_fu_21482_p4 = ap_phi_reg_pp0_iter1_data_382_V_read408_phi_reg_21478.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_382_V_read408_rewind_phi_fu_16646_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_382_V_read408_rewind_phi_fu_16646_p6 = data_382_V_read408_phi_reg_21478.read();
    } else {
        ap_phi_mux_data_382_V_read408_rewind_phi_fu_16646_p6 = data_382_V_read408_rewind_reg_16642.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_383_V_read409_phi_phi_fu_21494_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_383_V_read409_phi_phi_fu_21494_p4 = ap_phi_mux_data_383_V_read409_rewind_phi_fu_16660_p6.read();
    } else {
        ap_phi_mux_data_383_V_read409_phi_phi_fu_21494_p4 = ap_phi_reg_pp0_iter1_data_383_V_read409_phi_reg_21490.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_383_V_read409_rewind_phi_fu_16660_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_383_V_read409_rewind_phi_fu_16660_p6 = data_383_V_read409_phi_reg_21490.read();
    } else {
        ap_phi_mux_data_383_V_read409_rewind_phi_fu_16660_p6 = data_383_V_read409_rewind_reg_16656.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_384_V_read410_phi_phi_fu_21506_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_384_V_read410_phi_phi_fu_21506_p4 = ap_phi_mux_data_384_V_read410_rewind_phi_fu_16674_p6.read();
    } else {
        ap_phi_mux_data_384_V_read410_phi_phi_fu_21506_p4 = ap_phi_reg_pp0_iter1_data_384_V_read410_phi_reg_21502.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_384_V_read410_rewind_phi_fu_16674_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_384_V_read410_rewind_phi_fu_16674_p6 = data_384_V_read410_phi_reg_21502.read();
    } else {
        ap_phi_mux_data_384_V_read410_rewind_phi_fu_16674_p6 = data_384_V_read410_rewind_reg_16670.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_385_V_read411_phi_phi_fu_21518_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_385_V_read411_phi_phi_fu_21518_p4 = ap_phi_mux_data_385_V_read411_rewind_phi_fu_16688_p6.read();
    } else {
        ap_phi_mux_data_385_V_read411_phi_phi_fu_21518_p4 = ap_phi_reg_pp0_iter1_data_385_V_read411_phi_reg_21514.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_385_V_read411_rewind_phi_fu_16688_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_385_V_read411_rewind_phi_fu_16688_p6 = data_385_V_read411_phi_reg_21514.read();
    } else {
        ap_phi_mux_data_385_V_read411_rewind_phi_fu_16688_p6 = data_385_V_read411_rewind_reg_16684.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_386_V_read412_phi_phi_fu_21530_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_386_V_read412_phi_phi_fu_21530_p4 = ap_phi_mux_data_386_V_read412_rewind_phi_fu_16702_p6.read();
    } else {
        ap_phi_mux_data_386_V_read412_phi_phi_fu_21530_p4 = ap_phi_reg_pp0_iter1_data_386_V_read412_phi_reg_21526.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_386_V_read412_rewind_phi_fu_16702_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_386_V_read412_rewind_phi_fu_16702_p6 = data_386_V_read412_phi_reg_21526.read();
    } else {
        ap_phi_mux_data_386_V_read412_rewind_phi_fu_16702_p6 = data_386_V_read412_rewind_reg_16698.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_387_V_read413_phi_phi_fu_21542_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_387_V_read413_phi_phi_fu_21542_p4 = ap_phi_mux_data_387_V_read413_rewind_phi_fu_16716_p6.read();
    } else {
        ap_phi_mux_data_387_V_read413_phi_phi_fu_21542_p4 = ap_phi_reg_pp0_iter1_data_387_V_read413_phi_reg_21538.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_387_V_read413_rewind_phi_fu_16716_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_387_V_read413_rewind_phi_fu_16716_p6 = data_387_V_read413_phi_reg_21538.read();
    } else {
        ap_phi_mux_data_387_V_read413_rewind_phi_fu_16716_p6 = data_387_V_read413_rewind_reg_16712.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_388_V_read414_phi_phi_fu_21554_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_388_V_read414_phi_phi_fu_21554_p4 = ap_phi_mux_data_388_V_read414_rewind_phi_fu_16730_p6.read();
    } else {
        ap_phi_mux_data_388_V_read414_phi_phi_fu_21554_p4 = ap_phi_reg_pp0_iter1_data_388_V_read414_phi_reg_21550.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_388_V_read414_rewind_phi_fu_16730_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_388_V_read414_rewind_phi_fu_16730_p6 = data_388_V_read414_phi_reg_21550.read();
    } else {
        ap_phi_mux_data_388_V_read414_rewind_phi_fu_16730_p6 = data_388_V_read414_rewind_reg_16726.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_389_V_read415_phi_phi_fu_21566_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_389_V_read415_phi_phi_fu_21566_p4 = ap_phi_mux_data_389_V_read415_rewind_phi_fu_16744_p6.read();
    } else {
        ap_phi_mux_data_389_V_read415_phi_phi_fu_21566_p4 = ap_phi_reg_pp0_iter1_data_389_V_read415_phi_reg_21562.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_389_V_read415_rewind_phi_fu_16744_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_389_V_read415_rewind_phi_fu_16744_p6 = data_389_V_read415_phi_reg_21562.read();
    } else {
        ap_phi_mux_data_389_V_read415_rewind_phi_fu_16744_p6 = data_389_V_read415_rewind_reg_16740.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_38_V_read64_phi_phi_fu_17354_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_38_V_read64_phi_phi_fu_17354_p4 = ap_phi_mux_data_38_V_read64_rewind_phi_fu_11830_p6.read();
    } else {
        ap_phi_mux_data_38_V_read64_phi_phi_fu_17354_p4 = ap_phi_reg_pp0_iter1_data_38_V_read64_phi_reg_17350.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_38_V_read64_rewind_phi_fu_11830_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_38_V_read64_rewind_phi_fu_11830_p6 = data_38_V_read64_phi_reg_17350.read();
    } else {
        ap_phi_mux_data_38_V_read64_rewind_phi_fu_11830_p6 = data_38_V_read64_rewind_reg_11826.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_390_V_read416_phi_phi_fu_21578_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_390_V_read416_phi_phi_fu_21578_p4 = ap_phi_mux_data_390_V_read416_rewind_phi_fu_16758_p6.read();
    } else {
        ap_phi_mux_data_390_V_read416_phi_phi_fu_21578_p4 = ap_phi_reg_pp0_iter1_data_390_V_read416_phi_reg_21574.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_390_V_read416_rewind_phi_fu_16758_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_390_V_read416_rewind_phi_fu_16758_p6 = data_390_V_read416_phi_reg_21574.read();
    } else {
        ap_phi_mux_data_390_V_read416_rewind_phi_fu_16758_p6 = data_390_V_read416_rewind_reg_16754.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_391_V_read417_phi_phi_fu_21590_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_391_V_read417_phi_phi_fu_21590_p4 = ap_phi_mux_data_391_V_read417_rewind_phi_fu_16772_p6.read();
    } else {
        ap_phi_mux_data_391_V_read417_phi_phi_fu_21590_p4 = ap_phi_reg_pp0_iter1_data_391_V_read417_phi_reg_21586.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_391_V_read417_rewind_phi_fu_16772_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_391_V_read417_rewind_phi_fu_16772_p6 = data_391_V_read417_phi_reg_21586.read();
    } else {
        ap_phi_mux_data_391_V_read417_rewind_phi_fu_16772_p6 = data_391_V_read417_rewind_reg_16768.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_392_V_read418_phi_phi_fu_21602_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_392_V_read418_phi_phi_fu_21602_p4 = ap_phi_mux_data_392_V_read418_rewind_phi_fu_16786_p6.read();
    } else {
        ap_phi_mux_data_392_V_read418_phi_phi_fu_21602_p4 = ap_phi_reg_pp0_iter1_data_392_V_read418_phi_reg_21598.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_392_V_read418_rewind_phi_fu_16786_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_392_V_read418_rewind_phi_fu_16786_p6 = data_392_V_read418_phi_reg_21598.read();
    } else {
        ap_phi_mux_data_392_V_read418_rewind_phi_fu_16786_p6 = data_392_V_read418_rewind_reg_16782.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_393_V_read419_phi_phi_fu_21614_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_393_V_read419_phi_phi_fu_21614_p4 = ap_phi_mux_data_393_V_read419_rewind_phi_fu_16800_p6.read();
    } else {
        ap_phi_mux_data_393_V_read419_phi_phi_fu_21614_p4 = ap_phi_reg_pp0_iter1_data_393_V_read419_phi_reg_21610.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_393_V_read419_rewind_phi_fu_16800_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_393_V_read419_rewind_phi_fu_16800_p6 = data_393_V_read419_phi_reg_21610.read();
    } else {
        ap_phi_mux_data_393_V_read419_rewind_phi_fu_16800_p6 = data_393_V_read419_rewind_reg_16796.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_394_V_read420_phi_phi_fu_21626_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_394_V_read420_phi_phi_fu_21626_p4 = ap_phi_mux_data_394_V_read420_rewind_phi_fu_16814_p6.read();
    } else {
        ap_phi_mux_data_394_V_read420_phi_phi_fu_21626_p4 = ap_phi_reg_pp0_iter1_data_394_V_read420_phi_reg_21622.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_394_V_read420_rewind_phi_fu_16814_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_394_V_read420_rewind_phi_fu_16814_p6 = data_394_V_read420_phi_reg_21622.read();
    } else {
        ap_phi_mux_data_394_V_read420_rewind_phi_fu_16814_p6 = data_394_V_read420_rewind_reg_16810.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_395_V_read421_phi_phi_fu_21638_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_395_V_read421_phi_phi_fu_21638_p4 = ap_phi_mux_data_395_V_read421_rewind_phi_fu_16828_p6.read();
    } else {
        ap_phi_mux_data_395_V_read421_phi_phi_fu_21638_p4 = ap_phi_reg_pp0_iter1_data_395_V_read421_phi_reg_21634.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_395_V_read421_rewind_phi_fu_16828_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_395_V_read421_rewind_phi_fu_16828_p6 = data_395_V_read421_phi_reg_21634.read();
    } else {
        ap_phi_mux_data_395_V_read421_rewind_phi_fu_16828_p6 = data_395_V_read421_rewind_reg_16824.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_396_V_read422_phi_phi_fu_21650_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_396_V_read422_phi_phi_fu_21650_p4 = ap_phi_mux_data_396_V_read422_rewind_phi_fu_16842_p6.read();
    } else {
        ap_phi_mux_data_396_V_read422_phi_phi_fu_21650_p4 = ap_phi_reg_pp0_iter1_data_396_V_read422_phi_reg_21646.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_396_V_read422_rewind_phi_fu_16842_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_396_V_read422_rewind_phi_fu_16842_p6 = data_396_V_read422_phi_reg_21646.read();
    } else {
        ap_phi_mux_data_396_V_read422_rewind_phi_fu_16842_p6 = data_396_V_read422_rewind_reg_16838.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_397_V_read423_phi_phi_fu_21662_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_397_V_read423_phi_phi_fu_21662_p4 = ap_phi_mux_data_397_V_read423_rewind_phi_fu_16856_p6.read();
    } else {
        ap_phi_mux_data_397_V_read423_phi_phi_fu_21662_p4 = ap_phi_reg_pp0_iter1_data_397_V_read423_phi_reg_21658.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_397_V_read423_rewind_phi_fu_16856_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_397_V_read423_rewind_phi_fu_16856_p6 = data_397_V_read423_phi_reg_21658.read();
    } else {
        ap_phi_mux_data_397_V_read423_rewind_phi_fu_16856_p6 = data_397_V_read423_rewind_reg_16852.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_398_V_read424_phi_phi_fu_21674_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_398_V_read424_phi_phi_fu_21674_p4 = ap_phi_mux_data_398_V_read424_rewind_phi_fu_16870_p6.read();
    } else {
        ap_phi_mux_data_398_V_read424_phi_phi_fu_21674_p4 = ap_phi_reg_pp0_iter1_data_398_V_read424_phi_reg_21670.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_398_V_read424_rewind_phi_fu_16870_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_398_V_read424_rewind_phi_fu_16870_p6 = data_398_V_read424_phi_reg_21670.read();
    } else {
        ap_phi_mux_data_398_V_read424_rewind_phi_fu_16870_p6 = data_398_V_read424_rewind_reg_16866.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_399_V_read425_phi_phi_fu_21686_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_399_V_read425_phi_phi_fu_21686_p4 = ap_phi_mux_data_399_V_read425_rewind_phi_fu_16884_p6.read();
    } else {
        ap_phi_mux_data_399_V_read425_phi_phi_fu_21686_p4 = ap_phi_reg_pp0_iter1_data_399_V_read425_phi_reg_21682.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_399_V_read425_rewind_phi_fu_16884_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_399_V_read425_rewind_phi_fu_16884_p6 = data_399_V_read425_phi_reg_21682.read();
    } else {
        ap_phi_mux_data_399_V_read425_rewind_phi_fu_16884_p6 = data_399_V_read425_rewind_reg_16880.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_39_V_read65_phi_phi_fu_17366_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_39_V_read65_phi_phi_fu_17366_p4 = ap_phi_mux_data_39_V_read65_rewind_phi_fu_11844_p6.read();
    } else {
        ap_phi_mux_data_39_V_read65_phi_phi_fu_17366_p4 = ap_phi_reg_pp0_iter1_data_39_V_read65_phi_reg_17362.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_39_V_read65_rewind_phi_fu_11844_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_39_V_read65_rewind_phi_fu_11844_p6 = data_39_V_read65_phi_reg_17362.read();
    } else {
        ap_phi_mux_data_39_V_read65_rewind_phi_fu_11844_p6 = data_39_V_read65_rewind_reg_11840.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_3_V_read29_phi_phi_fu_16934_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_3_V_read29_phi_phi_fu_16934_p4 = ap_phi_mux_data_3_V_read29_rewind_phi_fu_11340_p6.read();
    } else {
        ap_phi_mux_data_3_V_read29_phi_phi_fu_16934_p4 = ap_phi_reg_pp0_iter1_data_3_V_read29_phi_reg_16930.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_3_V_read29_rewind_phi_fu_11340_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_3_V_read29_rewind_phi_fu_11340_p6 = data_3_V_read29_phi_reg_16930.read();
    } else {
        ap_phi_mux_data_3_V_read29_rewind_phi_fu_11340_p6 = data_3_V_read29_rewind_reg_11336.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_40_V_read66_phi_phi_fu_17378_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_40_V_read66_phi_phi_fu_17378_p4 = ap_phi_mux_data_40_V_read66_rewind_phi_fu_11858_p6.read();
    } else {
        ap_phi_mux_data_40_V_read66_phi_phi_fu_17378_p4 = ap_phi_reg_pp0_iter1_data_40_V_read66_phi_reg_17374.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_40_V_read66_rewind_phi_fu_11858_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_40_V_read66_rewind_phi_fu_11858_p6 = data_40_V_read66_phi_reg_17374.read();
    } else {
        ap_phi_mux_data_40_V_read66_rewind_phi_fu_11858_p6 = data_40_V_read66_rewind_reg_11854.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_41_V_read67_phi_phi_fu_17390_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_41_V_read67_phi_phi_fu_17390_p4 = ap_phi_mux_data_41_V_read67_rewind_phi_fu_11872_p6.read();
    } else {
        ap_phi_mux_data_41_V_read67_phi_phi_fu_17390_p4 = ap_phi_reg_pp0_iter1_data_41_V_read67_phi_reg_17386.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_41_V_read67_rewind_phi_fu_11872_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_41_V_read67_rewind_phi_fu_11872_p6 = data_41_V_read67_phi_reg_17386.read();
    } else {
        ap_phi_mux_data_41_V_read67_rewind_phi_fu_11872_p6 = data_41_V_read67_rewind_reg_11868.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_42_V_read68_phi_phi_fu_17402_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_42_V_read68_phi_phi_fu_17402_p4 = ap_phi_mux_data_42_V_read68_rewind_phi_fu_11886_p6.read();
    } else {
        ap_phi_mux_data_42_V_read68_phi_phi_fu_17402_p4 = ap_phi_reg_pp0_iter1_data_42_V_read68_phi_reg_17398.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_42_V_read68_rewind_phi_fu_11886_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_42_V_read68_rewind_phi_fu_11886_p6 = data_42_V_read68_phi_reg_17398.read();
    } else {
        ap_phi_mux_data_42_V_read68_rewind_phi_fu_11886_p6 = data_42_V_read68_rewind_reg_11882.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_43_V_read69_phi_phi_fu_17414_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_43_V_read69_phi_phi_fu_17414_p4 = ap_phi_mux_data_43_V_read69_rewind_phi_fu_11900_p6.read();
    } else {
        ap_phi_mux_data_43_V_read69_phi_phi_fu_17414_p4 = ap_phi_reg_pp0_iter1_data_43_V_read69_phi_reg_17410.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_43_V_read69_rewind_phi_fu_11900_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_43_V_read69_rewind_phi_fu_11900_p6 = data_43_V_read69_phi_reg_17410.read();
    } else {
        ap_phi_mux_data_43_V_read69_rewind_phi_fu_11900_p6 = data_43_V_read69_rewind_reg_11896.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_44_V_read70_phi_phi_fu_17426_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_44_V_read70_phi_phi_fu_17426_p4 = ap_phi_mux_data_44_V_read70_rewind_phi_fu_11914_p6.read();
    } else {
        ap_phi_mux_data_44_V_read70_phi_phi_fu_17426_p4 = ap_phi_reg_pp0_iter1_data_44_V_read70_phi_reg_17422.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_44_V_read70_rewind_phi_fu_11914_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_44_V_read70_rewind_phi_fu_11914_p6 = data_44_V_read70_phi_reg_17422.read();
    } else {
        ap_phi_mux_data_44_V_read70_rewind_phi_fu_11914_p6 = data_44_V_read70_rewind_reg_11910.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_45_V_read71_phi_phi_fu_17438_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_45_V_read71_phi_phi_fu_17438_p4 = ap_phi_mux_data_45_V_read71_rewind_phi_fu_11928_p6.read();
    } else {
        ap_phi_mux_data_45_V_read71_phi_phi_fu_17438_p4 = ap_phi_reg_pp0_iter1_data_45_V_read71_phi_reg_17434.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_45_V_read71_rewind_phi_fu_11928_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_45_V_read71_rewind_phi_fu_11928_p6 = data_45_V_read71_phi_reg_17434.read();
    } else {
        ap_phi_mux_data_45_V_read71_rewind_phi_fu_11928_p6 = data_45_V_read71_rewind_reg_11924.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_46_V_read72_phi_phi_fu_17450_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_46_V_read72_phi_phi_fu_17450_p4 = ap_phi_mux_data_46_V_read72_rewind_phi_fu_11942_p6.read();
    } else {
        ap_phi_mux_data_46_V_read72_phi_phi_fu_17450_p4 = ap_phi_reg_pp0_iter1_data_46_V_read72_phi_reg_17446.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_46_V_read72_rewind_phi_fu_11942_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_46_V_read72_rewind_phi_fu_11942_p6 = data_46_V_read72_phi_reg_17446.read();
    } else {
        ap_phi_mux_data_46_V_read72_rewind_phi_fu_11942_p6 = data_46_V_read72_rewind_reg_11938.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_47_V_read73_phi_phi_fu_17462_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_47_V_read73_phi_phi_fu_17462_p4 = ap_phi_mux_data_47_V_read73_rewind_phi_fu_11956_p6.read();
    } else {
        ap_phi_mux_data_47_V_read73_phi_phi_fu_17462_p4 = ap_phi_reg_pp0_iter1_data_47_V_read73_phi_reg_17458.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_47_V_read73_rewind_phi_fu_11956_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_47_V_read73_rewind_phi_fu_11956_p6 = data_47_V_read73_phi_reg_17458.read();
    } else {
        ap_phi_mux_data_47_V_read73_rewind_phi_fu_11956_p6 = data_47_V_read73_rewind_reg_11952.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_48_V_read74_phi_phi_fu_17474_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_48_V_read74_phi_phi_fu_17474_p4 = ap_phi_mux_data_48_V_read74_rewind_phi_fu_11970_p6.read();
    } else {
        ap_phi_mux_data_48_V_read74_phi_phi_fu_17474_p4 = ap_phi_reg_pp0_iter1_data_48_V_read74_phi_reg_17470.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_48_V_read74_rewind_phi_fu_11970_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_48_V_read74_rewind_phi_fu_11970_p6 = data_48_V_read74_phi_reg_17470.read();
    } else {
        ap_phi_mux_data_48_V_read74_rewind_phi_fu_11970_p6 = data_48_V_read74_rewind_reg_11966.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_49_V_read75_phi_phi_fu_17486_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_49_V_read75_phi_phi_fu_17486_p4 = ap_phi_mux_data_49_V_read75_rewind_phi_fu_11984_p6.read();
    } else {
        ap_phi_mux_data_49_V_read75_phi_phi_fu_17486_p4 = ap_phi_reg_pp0_iter1_data_49_V_read75_phi_reg_17482.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_49_V_read75_rewind_phi_fu_11984_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_49_V_read75_rewind_phi_fu_11984_p6 = data_49_V_read75_phi_reg_17482.read();
    } else {
        ap_phi_mux_data_49_V_read75_rewind_phi_fu_11984_p6 = data_49_V_read75_rewind_reg_11980.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_4_V_read30_phi_phi_fu_16946_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_4_V_read30_phi_phi_fu_16946_p4 = ap_phi_mux_data_4_V_read30_rewind_phi_fu_11354_p6.read();
    } else {
        ap_phi_mux_data_4_V_read30_phi_phi_fu_16946_p4 = ap_phi_reg_pp0_iter1_data_4_V_read30_phi_reg_16942.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_4_V_read30_rewind_phi_fu_11354_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_4_V_read30_rewind_phi_fu_11354_p6 = data_4_V_read30_phi_reg_16942.read();
    } else {
        ap_phi_mux_data_4_V_read30_rewind_phi_fu_11354_p6 = data_4_V_read30_rewind_reg_11350.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_50_V_read76_phi_phi_fu_17498_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_50_V_read76_phi_phi_fu_17498_p4 = ap_phi_mux_data_50_V_read76_rewind_phi_fu_11998_p6.read();
    } else {
        ap_phi_mux_data_50_V_read76_phi_phi_fu_17498_p4 = ap_phi_reg_pp0_iter1_data_50_V_read76_phi_reg_17494.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_50_V_read76_rewind_phi_fu_11998_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_50_V_read76_rewind_phi_fu_11998_p6 = data_50_V_read76_phi_reg_17494.read();
    } else {
        ap_phi_mux_data_50_V_read76_rewind_phi_fu_11998_p6 = data_50_V_read76_rewind_reg_11994.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_51_V_read77_phi_phi_fu_17510_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_51_V_read77_phi_phi_fu_17510_p4 = ap_phi_mux_data_51_V_read77_rewind_phi_fu_12012_p6.read();
    } else {
        ap_phi_mux_data_51_V_read77_phi_phi_fu_17510_p4 = ap_phi_reg_pp0_iter1_data_51_V_read77_phi_reg_17506.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_51_V_read77_rewind_phi_fu_12012_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_51_V_read77_rewind_phi_fu_12012_p6 = data_51_V_read77_phi_reg_17506.read();
    } else {
        ap_phi_mux_data_51_V_read77_rewind_phi_fu_12012_p6 = data_51_V_read77_rewind_reg_12008.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_52_V_read78_phi_phi_fu_17522_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_52_V_read78_phi_phi_fu_17522_p4 = ap_phi_mux_data_52_V_read78_rewind_phi_fu_12026_p6.read();
    } else {
        ap_phi_mux_data_52_V_read78_phi_phi_fu_17522_p4 = ap_phi_reg_pp0_iter1_data_52_V_read78_phi_reg_17518.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_52_V_read78_rewind_phi_fu_12026_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_52_V_read78_rewind_phi_fu_12026_p6 = data_52_V_read78_phi_reg_17518.read();
    } else {
        ap_phi_mux_data_52_V_read78_rewind_phi_fu_12026_p6 = data_52_V_read78_rewind_reg_12022.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_53_V_read79_phi_phi_fu_17534_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_53_V_read79_phi_phi_fu_17534_p4 = ap_phi_mux_data_53_V_read79_rewind_phi_fu_12040_p6.read();
    } else {
        ap_phi_mux_data_53_V_read79_phi_phi_fu_17534_p4 = ap_phi_reg_pp0_iter1_data_53_V_read79_phi_reg_17530.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_53_V_read79_rewind_phi_fu_12040_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_53_V_read79_rewind_phi_fu_12040_p6 = data_53_V_read79_phi_reg_17530.read();
    } else {
        ap_phi_mux_data_53_V_read79_rewind_phi_fu_12040_p6 = data_53_V_read79_rewind_reg_12036.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_54_V_read80_phi_phi_fu_17546_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_54_V_read80_phi_phi_fu_17546_p4 = ap_phi_mux_data_54_V_read80_rewind_phi_fu_12054_p6.read();
    } else {
        ap_phi_mux_data_54_V_read80_phi_phi_fu_17546_p4 = ap_phi_reg_pp0_iter1_data_54_V_read80_phi_reg_17542.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_54_V_read80_rewind_phi_fu_12054_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_54_V_read80_rewind_phi_fu_12054_p6 = data_54_V_read80_phi_reg_17542.read();
    } else {
        ap_phi_mux_data_54_V_read80_rewind_phi_fu_12054_p6 = data_54_V_read80_rewind_reg_12050.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_55_V_read81_phi_phi_fu_17558_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_55_V_read81_phi_phi_fu_17558_p4 = ap_phi_mux_data_55_V_read81_rewind_phi_fu_12068_p6.read();
    } else {
        ap_phi_mux_data_55_V_read81_phi_phi_fu_17558_p4 = ap_phi_reg_pp0_iter1_data_55_V_read81_phi_reg_17554.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_55_V_read81_rewind_phi_fu_12068_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_55_V_read81_rewind_phi_fu_12068_p6 = data_55_V_read81_phi_reg_17554.read();
    } else {
        ap_phi_mux_data_55_V_read81_rewind_phi_fu_12068_p6 = data_55_V_read81_rewind_reg_12064.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_56_V_read82_phi_phi_fu_17570_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_56_V_read82_phi_phi_fu_17570_p4 = ap_phi_mux_data_56_V_read82_rewind_phi_fu_12082_p6.read();
    } else {
        ap_phi_mux_data_56_V_read82_phi_phi_fu_17570_p4 = ap_phi_reg_pp0_iter1_data_56_V_read82_phi_reg_17566.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_56_V_read82_rewind_phi_fu_12082_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_56_V_read82_rewind_phi_fu_12082_p6 = data_56_V_read82_phi_reg_17566.read();
    } else {
        ap_phi_mux_data_56_V_read82_rewind_phi_fu_12082_p6 = data_56_V_read82_rewind_reg_12078.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_57_V_read83_phi_phi_fu_17582_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_57_V_read83_phi_phi_fu_17582_p4 = ap_phi_mux_data_57_V_read83_rewind_phi_fu_12096_p6.read();
    } else {
        ap_phi_mux_data_57_V_read83_phi_phi_fu_17582_p4 = ap_phi_reg_pp0_iter1_data_57_V_read83_phi_reg_17578.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_57_V_read83_rewind_phi_fu_12096_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_57_V_read83_rewind_phi_fu_12096_p6 = data_57_V_read83_phi_reg_17578.read();
    } else {
        ap_phi_mux_data_57_V_read83_rewind_phi_fu_12096_p6 = data_57_V_read83_rewind_reg_12092.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_58_V_read84_phi_phi_fu_17594_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_58_V_read84_phi_phi_fu_17594_p4 = ap_phi_mux_data_58_V_read84_rewind_phi_fu_12110_p6.read();
    } else {
        ap_phi_mux_data_58_V_read84_phi_phi_fu_17594_p4 = ap_phi_reg_pp0_iter1_data_58_V_read84_phi_reg_17590.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_58_V_read84_rewind_phi_fu_12110_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_58_V_read84_rewind_phi_fu_12110_p6 = data_58_V_read84_phi_reg_17590.read();
    } else {
        ap_phi_mux_data_58_V_read84_rewind_phi_fu_12110_p6 = data_58_V_read84_rewind_reg_12106.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_59_V_read85_phi_phi_fu_17606_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_59_V_read85_phi_phi_fu_17606_p4 = ap_phi_mux_data_59_V_read85_rewind_phi_fu_12124_p6.read();
    } else {
        ap_phi_mux_data_59_V_read85_phi_phi_fu_17606_p4 = ap_phi_reg_pp0_iter1_data_59_V_read85_phi_reg_17602.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_59_V_read85_rewind_phi_fu_12124_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_59_V_read85_rewind_phi_fu_12124_p6 = data_59_V_read85_phi_reg_17602.read();
    } else {
        ap_phi_mux_data_59_V_read85_rewind_phi_fu_12124_p6 = data_59_V_read85_rewind_reg_12120.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_5_V_read31_phi_phi_fu_16958_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_5_V_read31_phi_phi_fu_16958_p4 = ap_phi_mux_data_5_V_read31_rewind_phi_fu_11368_p6.read();
    } else {
        ap_phi_mux_data_5_V_read31_phi_phi_fu_16958_p4 = ap_phi_reg_pp0_iter1_data_5_V_read31_phi_reg_16954.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_5_V_read31_rewind_phi_fu_11368_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_5_V_read31_rewind_phi_fu_11368_p6 = data_5_V_read31_phi_reg_16954.read();
    } else {
        ap_phi_mux_data_5_V_read31_rewind_phi_fu_11368_p6 = data_5_V_read31_rewind_reg_11364.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_60_V_read86_phi_phi_fu_17618_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_60_V_read86_phi_phi_fu_17618_p4 = ap_phi_mux_data_60_V_read86_rewind_phi_fu_12138_p6.read();
    } else {
        ap_phi_mux_data_60_V_read86_phi_phi_fu_17618_p4 = ap_phi_reg_pp0_iter1_data_60_V_read86_phi_reg_17614.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_60_V_read86_rewind_phi_fu_12138_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_60_V_read86_rewind_phi_fu_12138_p6 = data_60_V_read86_phi_reg_17614.read();
    } else {
        ap_phi_mux_data_60_V_read86_rewind_phi_fu_12138_p6 = data_60_V_read86_rewind_reg_12134.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_61_V_read87_phi_phi_fu_17630_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_61_V_read87_phi_phi_fu_17630_p4 = ap_phi_mux_data_61_V_read87_rewind_phi_fu_12152_p6.read();
    } else {
        ap_phi_mux_data_61_V_read87_phi_phi_fu_17630_p4 = ap_phi_reg_pp0_iter1_data_61_V_read87_phi_reg_17626.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_61_V_read87_rewind_phi_fu_12152_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_61_V_read87_rewind_phi_fu_12152_p6 = data_61_V_read87_phi_reg_17626.read();
    } else {
        ap_phi_mux_data_61_V_read87_rewind_phi_fu_12152_p6 = data_61_V_read87_rewind_reg_12148.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_62_V_read88_phi_phi_fu_17642_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_62_V_read88_phi_phi_fu_17642_p4 = ap_phi_mux_data_62_V_read88_rewind_phi_fu_12166_p6.read();
    } else {
        ap_phi_mux_data_62_V_read88_phi_phi_fu_17642_p4 = ap_phi_reg_pp0_iter1_data_62_V_read88_phi_reg_17638.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_62_V_read88_rewind_phi_fu_12166_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_62_V_read88_rewind_phi_fu_12166_p6 = data_62_V_read88_phi_reg_17638.read();
    } else {
        ap_phi_mux_data_62_V_read88_rewind_phi_fu_12166_p6 = data_62_V_read88_rewind_reg_12162.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_63_V_read89_phi_phi_fu_17654_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_63_V_read89_phi_phi_fu_17654_p4 = ap_phi_mux_data_63_V_read89_rewind_phi_fu_12180_p6.read();
    } else {
        ap_phi_mux_data_63_V_read89_phi_phi_fu_17654_p4 = ap_phi_reg_pp0_iter1_data_63_V_read89_phi_reg_17650.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_63_V_read89_rewind_phi_fu_12180_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_63_V_read89_rewind_phi_fu_12180_p6 = data_63_V_read89_phi_reg_17650.read();
    } else {
        ap_phi_mux_data_63_V_read89_rewind_phi_fu_12180_p6 = data_63_V_read89_rewind_reg_12176.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_64_V_read90_phi_phi_fu_17666_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_64_V_read90_phi_phi_fu_17666_p4 = ap_phi_mux_data_64_V_read90_rewind_phi_fu_12194_p6.read();
    } else {
        ap_phi_mux_data_64_V_read90_phi_phi_fu_17666_p4 = ap_phi_reg_pp0_iter1_data_64_V_read90_phi_reg_17662.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_64_V_read90_rewind_phi_fu_12194_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_64_V_read90_rewind_phi_fu_12194_p6 = data_64_V_read90_phi_reg_17662.read();
    } else {
        ap_phi_mux_data_64_V_read90_rewind_phi_fu_12194_p6 = data_64_V_read90_rewind_reg_12190.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_65_V_read91_phi_phi_fu_17678_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_65_V_read91_phi_phi_fu_17678_p4 = ap_phi_mux_data_65_V_read91_rewind_phi_fu_12208_p6.read();
    } else {
        ap_phi_mux_data_65_V_read91_phi_phi_fu_17678_p4 = ap_phi_reg_pp0_iter1_data_65_V_read91_phi_reg_17674.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_65_V_read91_rewind_phi_fu_12208_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_65_V_read91_rewind_phi_fu_12208_p6 = data_65_V_read91_phi_reg_17674.read();
    } else {
        ap_phi_mux_data_65_V_read91_rewind_phi_fu_12208_p6 = data_65_V_read91_rewind_reg_12204.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_66_V_read92_phi_phi_fu_17690_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_66_V_read92_phi_phi_fu_17690_p4 = ap_phi_mux_data_66_V_read92_rewind_phi_fu_12222_p6.read();
    } else {
        ap_phi_mux_data_66_V_read92_phi_phi_fu_17690_p4 = ap_phi_reg_pp0_iter1_data_66_V_read92_phi_reg_17686.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_66_V_read92_rewind_phi_fu_12222_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_66_V_read92_rewind_phi_fu_12222_p6 = data_66_V_read92_phi_reg_17686.read();
    } else {
        ap_phi_mux_data_66_V_read92_rewind_phi_fu_12222_p6 = data_66_V_read92_rewind_reg_12218.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_67_V_read93_phi_phi_fu_17702_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_67_V_read93_phi_phi_fu_17702_p4 = ap_phi_mux_data_67_V_read93_rewind_phi_fu_12236_p6.read();
    } else {
        ap_phi_mux_data_67_V_read93_phi_phi_fu_17702_p4 = ap_phi_reg_pp0_iter1_data_67_V_read93_phi_reg_17698.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_67_V_read93_rewind_phi_fu_12236_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_67_V_read93_rewind_phi_fu_12236_p6 = data_67_V_read93_phi_reg_17698.read();
    } else {
        ap_phi_mux_data_67_V_read93_rewind_phi_fu_12236_p6 = data_67_V_read93_rewind_reg_12232.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_68_V_read94_phi_phi_fu_17714_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_68_V_read94_phi_phi_fu_17714_p4 = ap_phi_mux_data_68_V_read94_rewind_phi_fu_12250_p6.read();
    } else {
        ap_phi_mux_data_68_V_read94_phi_phi_fu_17714_p4 = ap_phi_reg_pp0_iter1_data_68_V_read94_phi_reg_17710.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_68_V_read94_rewind_phi_fu_12250_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_68_V_read94_rewind_phi_fu_12250_p6 = data_68_V_read94_phi_reg_17710.read();
    } else {
        ap_phi_mux_data_68_V_read94_rewind_phi_fu_12250_p6 = data_68_V_read94_rewind_reg_12246.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_69_V_read95_phi_phi_fu_17726_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_69_V_read95_phi_phi_fu_17726_p4 = ap_phi_mux_data_69_V_read95_rewind_phi_fu_12264_p6.read();
    } else {
        ap_phi_mux_data_69_V_read95_phi_phi_fu_17726_p4 = ap_phi_reg_pp0_iter1_data_69_V_read95_phi_reg_17722.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_69_V_read95_rewind_phi_fu_12264_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_69_V_read95_rewind_phi_fu_12264_p6 = data_69_V_read95_phi_reg_17722.read();
    } else {
        ap_phi_mux_data_69_V_read95_rewind_phi_fu_12264_p6 = data_69_V_read95_rewind_reg_12260.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_6_V_read32_phi_phi_fu_16970_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_6_V_read32_phi_phi_fu_16970_p4 = ap_phi_mux_data_6_V_read32_rewind_phi_fu_11382_p6.read();
    } else {
        ap_phi_mux_data_6_V_read32_phi_phi_fu_16970_p4 = ap_phi_reg_pp0_iter1_data_6_V_read32_phi_reg_16966.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_6_V_read32_rewind_phi_fu_11382_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_6_V_read32_rewind_phi_fu_11382_p6 = data_6_V_read32_phi_reg_16966.read();
    } else {
        ap_phi_mux_data_6_V_read32_rewind_phi_fu_11382_p6 = data_6_V_read32_rewind_reg_11378.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_70_V_read96_phi_phi_fu_17738_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_70_V_read96_phi_phi_fu_17738_p4 = ap_phi_mux_data_70_V_read96_rewind_phi_fu_12278_p6.read();
    } else {
        ap_phi_mux_data_70_V_read96_phi_phi_fu_17738_p4 = ap_phi_reg_pp0_iter1_data_70_V_read96_phi_reg_17734.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_70_V_read96_rewind_phi_fu_12278_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_70_V_read96_rewind_phi_fu_12278_p6 = data_70_V_read96_phi_reg_17734.read();
    } else {
        ap_phi_mux_data_70_V_read96_rewind_phi_fu_12278_p6 = data_70_V_read96_rewind_reg_12274.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_71_V_read97_phi_phi_fu_17750_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_71_V_read97_phi_phi_fu_17750_p4 = ap_phi_mux_data_71_V_read97_rewind_phi_fu_12292_p6.read();
    } else {
        ap_phi_mux_data_71_V_read97_phi_phi_fu_17750_p4 = ap_phi_reg_pp0_iter1_data_71_V_read97_phi_reg_17746.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_71_V_read97_rewind_phi_fu_12292_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_71_V_read97_rewind_phi_fu_12292_p6 = data_71_V_read97_phi_reg_17746.read();
    } else {
        ap_phi_mux_data_71_V_read97_rewind_phi_fu_12292_p6 = data_71_V_read97_rewind_reg_12288.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_72_V_read98_phi_phi_fu_17762_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_72_V_read98_phi_phi_fu_17762_p4 = ap_phi_mux_data_72_V_read98_rewind_phi_fu_12306_p6.read();
    } else {
        ap_phi_mux_data_72_V_read98_phi_phi_fu_17762_p4 = ap_phi_reg_pp0_iter1_data_72_V_read98_phi_reg_17758.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_72_V_read98_rewind_phi_fu_12306_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_72_V_read98_rewind_phi_fu_12306_p6 = data_72_V_read98_phi_reg_17758.read();
    } else {
        ap_phi_mux_data_72_V_read98_rewind_phi_fu_12306_p6 = data_72_V_read98_rewind_reg_12302.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_73_V_read99_phi_phi_fu_17774_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_73_V_read99_phi_phi_fu_17774_p4 = ap_phi_mux_data_73_V_read99_rewind_phi_fu_12320_p6.read();
    } else {
        ap_phi_mux_data_73_V_read99_phi_phi_fu_17774_p4 = ap_phi_reg_pp0_iter1_data_73_V_read99_phi_reg_17770.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_73_V_read99_rewind_phi_fu_12320_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_73_V_read99_rewind_phi_fu_12320_p6 = data_73_V_read99_phi_reg_17770.read();
    } else {
        ap_phi_mux_data_73_V_read99_rewind_phi_fu_12320_p6 = data_73_V_read99_rewind_reg_12316.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_74_V_read100_phi_phi_fu_17786_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_74_V_read100_phi_phi_fu_17786_p4 = ap_phi_mux_data_74_V_read100_rewind_phi_fu_12334_p6.read();
    } else {
        ap_phi_mux_data_74_V_read100_phi_phi_fu_17786_p4 = ap_phi_reg_pp0_iter1_data_74_V_read100_phi_reg_17782.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_74_V_read100_rewind_phi_fu_12334_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_74_V_read100_rewind_phi_fu_12334_p6 = data_74_V_read100_phi_reg_17782.read();
    } else {
        ap_phi_mux_data_74_V_read100_rewind_phi_fu_12334_p6 = data_74_V_read100_rewind_reg_12330.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_75_V_read101_phi_phi_fu_17798_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_75_V_read101_phi_phi_fu_17798_p4 = ap_phi_mux_data_75_V_read101_rewind_phi_fu_12348_p6.read();
    } else {
        ap_phi_mux_data_75_V_read101_phi_phi_fu_17798_p4 = ap_phi_reg_pp0_iter1_data_75_V_read101_phi_reg_17794.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_75_V_read101_rewind_phi_fu_12348_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_75_V_read101_rewind_phi_fu_12348_p6 = data_75_V_read101_phi_reg_17794.read();
    } else {
        ap_phi_mux_data_75_V_read101_rewind_phi_fu_12348_p6 = data_75_V_read101_rewind_reg_12344.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_76_V_read102_phi_phi_fu_17810_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_76_V_read102_phi_phi_fu_17810_p4 = ap_phi_mux_data_76_V_read102_rewind_phi_fu_12362_p6.read();
    } else {
        ap_phi_mux_data_76_V_read102_phi_phi_fu_17810_p4 = ap_phi_reg_pp0_iter1_data_76_V_read102_phi_reg_17806.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_76_V_read102_rewind_phi_fu_12362_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_76_V_read102_rewind_phi_fu_12362_p6 = data_76_V_read102_phi_reg_17806.read();
    } else {
        ap_phi_mux_data_76_V_read102_rewind_phi_fu_12362_p6 = data_76_V_read102_rewind_reg_12358.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_77_V_read103_phi_phi_fu_17822_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_77_V_read103_phi_phi_fu_17822_p4 = ap_phi_mux_data_77_V_read103_rewind_phi_fu_12376_p6.read();
    } else {
        ap_phi_mux_data_77_V_read103_phi_phi_fu_17822_p4 = ap_phi_reg_pp0_iter1_data_77_V_read103_phi_reg_17818.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_77_V_read103_rewind_phi_fu_12376_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_77_V_read103_rewind_phi_fu_12376_p6 = data_77_V_read103_phi_reg_17818.read();
    } else {
        ap_phi_mux_data_77_V_read103_rewind_phi_fu_12376_p6 = data_77_V_read103_rewind_reg_12372.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_78_V_read104_phi_phi_fu_17834_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_78_V_read104_phi_phi_fu_17834_p4 = ap_phi_mux_data_78_V_read104_rewind_phi_fu_12390_p6.read();
    } else {
        ap_phi_mux_data_78_V_read104_phi_phi_fu_17834_p4 = ap_phi_reg_pp0_iter1_data_78_V_read104_phi_reg_17830.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_78_V_read104_rewind_phi_fu_12390_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_78_V_read104_rewind_phi_fu_12390_p6 = data_78_V_read104_phi_reg_17830.read();
    } else {
        ap_phi_mux_data_78_V_read104_rewind_phi_fu_12390_p6 = data_78_V_read104_rewind_reg_12386.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_79_V_read105_phi_phi_fu_17846_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_79_V_read105_phi_phi_fu_17846_p4 = ap_phi_mux_data_79_V_read105_rewind_phi_fu_12404_p6.read();
    } else {
        ap_phi_mux_data_79_V_read105_phi_phi_fu_17846_p4 = ap_phi_reg_pp0_iter1_data_79_V_read105_phi_reg_17842.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_79_V_read105_rewind_phi_fu_12404_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_79_V_read105_rewind_phi_fu_12404_p6 = data_79_V_read105_phi_reg_17842.read();
    } else {
        ap_phi_mux_data_79_V_read105_rewind_phi_fu_12404_p6 = data_79_V_read105_rewind_reg_12400.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_7_V_read33_phi_phi_fu_16982_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_7_V_read33_phi_phi_fu_16982_p4 = ap_phi_mux_data_7_V_read33_rewind_phi_fu_11396_p6.read();
    } else {
        ap_phi_mux_data_7_V_read33_phi_phi_fu_16982_p4 = ap_phi_reg_pp0_iter1_data_7_V_read33_phi_reg_16978.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_7_V_read33_rewind_phi_fu_11396_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_7_V_read33_rewind_phi_fu_11396_p6 = data_7_V_read33_phi_reg_16978.read();
    } else {
        ap_phi_mux_data_7_V_read33_rewind_phi_fu_11396_p6 = data_7_V_read33_rewind_reg_11392.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_80_V_read106_phi_phi_fu_17858_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_80_V_read106_phi_phi_fu_17858_p4 = ap_phi_mux_data_80_V_read106_rewind_phi_fu_12418_p6.read();
    } else {
        ap_phi_mux_data_80_V_read106_phi_phi_fu_17858_p4 = ap_phi_reg_pp0_iter1_data_80_V_read106_phi_reg_17854.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_80_V_read106_rewind_phi_fu_12418_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_80_V_read106_rewind_phi_fu_12418_p6 = data_80_V_read106_phi_reg_17854.read();
    } else {
        ap_phi_mux_data_80_V_read106_rewind_phi_fu_12418_p6 = data_80_V_read106_rewind_reg_12414.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_81_V_read107_phi_phi_fu_17870_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_81_V_read107_phi_phi_fu_17870_p4 = ap_phi_mux_data_81_V_read107_rewind_phi_fu_12432_p6.read();
    } else {
        ap_phi_mux_data_81_V_read107_phi_phi_fu_17870_p4 = ap_phi_reg_pp0_iter1_data_81_V_read107_phi_reg_17866.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_81_V_read107_rewind_phi_fu_12432_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_81_V_read107_rewind_phi_fu_12432_p6 = data_81_V_read107_phi_reg_17866.read();
    } else {
        ap_phi_mux_data_81_V_read107_rewind_phi_fu_12432_p6 = data_81_V_read107_rewind_reg_12428.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_82_V_read108_phi_phi_fu_17882_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_82_V_read108_phi_phi_fu_17882_p4 = ap_phi_mux_data_82_V_read108_rewind_phi_fu_12446_p6.read();
    } else {
        ap_phi_mux_data_82_V_read108_phi_phi_fu_17882_p4 = ap_phi_reg_pp0_iter1_data_82_V_read108_phi_reg_17878.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_82_V_read108_rewind_phi_fu_12446_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_82_V_read108_rewind_phi_fu_12446_p6 = data_82_V_read108_phi_reg_17878.read();
    } else {
        ap_phi_mux_data_82_V_read108_rewind_phi_fu_12446_p6 = data_82_V_read108_rewind_reg_12442.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_83_V_read109_phi_phi_fu_17894_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_83_V_read109_phi_phi_fu_17894_p4 = ap_phi_mux_data_83_V_read109_rewind_phi_fu_12460_p6.read();
    } else {
        ap_phi_mux_data_83_V_read109_phi_phi_fu_17894_p4 = ap_phi_reg_pp0_iter1_data_83_V_read109_phi_reg_17890.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_83_V_read109_rewind_phi_fu_12460_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_83_V_read109_rewind_phi_fu_12460_p6 = data_83_V_read109_phi_reg_17890.read();
    } else {
        ap_phi_mux_data_83_V_read109_rewind_phi_fu_12460_p6 = data_83_V_read109_rewind_reg_12456.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_84_V_read110_phi_phi_fu_17906_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_84_V_read110_phi_phi_fu_17906_p4 = ap_phi_mux_data_84_V_read110_rewind_phi_fu_12474_p6.read();
    } else {
        ap_phi_mux_data_84_V_read110_phi_phi_fu_17906_p4 = ap_phi_reg_pp0_iter1_data_84_V_read110_phi_reg_17902.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_84_V_read110_rewind_phi_fu_12474_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_84_V_read110_rewind_phi_fu_12474_p6 = data_84_V_read110_phi_reg_17902.read();
    } else {
        ap_phi_mux_data_84_V_read110_rewind_phi_fu_12474_p6 = data_84_V_read110_rewind_reg_12470.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_85_V_read111_phi_phi_fu_17918_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_85_V_read111_phi_phi_fu_17918_p4 = ap_phi_mux_data_85_V_read111_rewind_phi_fu_12488_p6.read();
    } else {
        ap_phi_mux_data_85_V_read111_phi_phi_fu_17918_p4 = ap_phi_reg_pp0_iter1_data_85_V_read111_phi_reg_17914.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_85_V_read111_rewind_phi_fu_12488_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_85_V_read111_rewind_phi_fu_12488_p6 = data_85_V_read111_phi_reg_17914.read();
    } else {
        ap_phi_mux_data_85_V_read111_rewind_phi_fu_12488_p6 = data_85_V_read111_rewind_reg_12484.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_86_V_read112_phi_phi_fu_17930_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_86_V_read112_phi_phi_fu_17930_p4 = ap_phi_mux_data_86_V_read112_rewind_phi_fu_12502_p6.read();
    } else {
        ap_phi_mux_data_86_V_read112_phi_phi_fu_17930_p4 = ap_phi_reg_pp0_iter1_data_86_V_read112_phi_reg_17926.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_86_V_read112_rewind_phi_fu_12502_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_86_V_read112_rewind_phi_fu_12502_p6 = data_86_V_read112_phi_reg_17926.read();
    } else {
        ap_phi_mux_data_86_V_read112_rewind_phi_fu_12502_p6 = data_86_V_read112_rewind_reg_12498.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_87_V_read113_phi_phi_fu_17942_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_87_V_read113_phi_phi_fu_17942_p4 = ap_phi_mux_data_87_V_read113_rewind_phi_fu_12516_p6.read();
    } else {
        ap_phi_mux_data_87_V_read113_phi_phi_fu_17942_p4 = ap_phi_reg_pp0_iter1_data_87_V_read113_phi_reg_17938.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_87_V_read113_rewind_phi_fu_12516_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_87_V_read113_rewind_phi_fu_12516_p6 = data_87_V_read113_phi_reg_17938.read();
    } else {
        ap_phi_mux_data_87_V_read113_rewind_phi_fu_12516_p6 = data_87_V_read113_rewind_reg_12512.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_88_V_read114_phi_phi_fu_17954_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_88_V_read114_phi_phi_fu_17954_p4 = ap_phi_mux_data_88_V_read114_rewind_phi_fu_12530_p6.read();
    } else {
        ap_phi_mux_data_88_V_read114_phi_phi_fu_17954_p4 = ap_phi_reg_pp0_iter1_data_88_V_read114_phi_reg_17950.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_88_V_read114_rewind_phi_fu_12530_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_88_V_read114_rewind_phi_fu_12530_p6 = data_88_V_read114_phi_reg_17950.read();
    } else {
        ap_phi_mux_data_88_V_read114_rewind_phi_fu_12530_p6 = data_88_V_read114_rewind_reg_12526.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_89_V_read115_phi_phi_fu_17966_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_89_V_read115_phi_phi_fu_17966_p4 = ap_phi_mux_data_89_V_read115_rewind_phi_fu_12544_p6.read();
    } else {
        ap_phi_mux_data_89_V_read115_phi_phi_fu_17966_p4 = ap_phi_reg_pp0_iter1_data_89_V_read115_phi_reg_17962.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_89_V_read115_rewind_phi_fu_12544_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_89_V_read115_rewind_phi_fu_12544_p6 = data_89_V_read115_phi_reg_17962.read();
    } else {
        ap_phi_mux_data_89_V_read115_rewind_phi_fu_12544_p6 = data_89_V_read115_rewind_reg_12540.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_8_V_read34_phi_phi_fu_16994_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_8_V_read34_phi_phi_fu_16994_p4 = ap_phi_mux_data_8_V_read34_rewind_phi_fu_11410_p6.read();
    } else {
        ap_phi_mux_data_8_V_read34_phi_phi_fu_16994_p4 = ap_phi_reg_pp0_iter1_data_8_V_read34_phi_reg_16990.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_8_V_read34_rewind_phi_fu_11410_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_8_V_read34_rewind_phi_fu_11410_p6 = data_8_V_read34_phi_reg_16990.read();
    } else {
        ap_phi_mux_data_8_V_read34_rewind_phi_fu_11410_p6 = data_8_V_read34_rewind_reg_11406.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_90_V_read116_phi_phi_fu_17978_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_90_V_read116_phi_phi_fu_17978_p4 = ap_phi_mux_data_90_V_read116_rewind_phi_fu_12558_p6.read();
    } else {
        ap_phi_mux_data_90_V_read116_phi_phi_fu_17978_p4 = ap_phi_reg_pp0_iter1_data_90_V_read116_phi_reg_17974.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_90_V_read116_rewind_phi_fu_12558_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_90_V_read116_rewind_phi_fu_12558_p6 = data_90_V_read116_phi_reg_17974.read();
    } else {
        ap_phi_mux_data_90_V_read116_rewind_phi_fu_12558_p6 = data_90_V_read116_rewind_reg_12554.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_91_V_read117_phi_phi_fu_17990_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_91_V_read117_phi_phi_fu_17990_p4 = ap_phi_mux_data_91_V_read117_rewind_phi_fu_12572_p6.read();
    } else {
        ap_phi_mux_data_91_V_read117_phi_phi_fu_17990_p4 = ap_phi_reg_pp0_iter1_data_91_V_read117_phi_reg_17986.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_91_V_read117_rewind_phi_fu_12572_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_91_V_read117_rewind_phi_fu_12572_p6 = data_91_V_read117_phi_reg_17986.read();
    } else {
        ap_phi_mux_data_91_V_read117_rewind_phi_fu_12572_p6 = data_91_V_read117_rewind_reg_12568.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_92_V_read118_phi_phi_fu_18002_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_92_V_read118_phi_phi_fu_18002_p4 = ap_phi_mux_data_92_V_read118_rewind_phi_fu_12586_p6.read();
    } else {
        ap_phi_mux_data_92_V_read118_phi_phi_fu_18002_p4 = ap_phi_reg_pp0_iter1_data_92_V_read118_phi_reg_17998.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_92_V_read118_rewind_phi_fu_12586_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_92_V_read118_rewind_phi_fu_12586_p6 = data_92_V_read118_phi_reg_17998.read();
    } else {
        ap_phi_mux_data_92_V_read118_rewind_phi_fu_12586_p6 = data_92_V_read118_rewind_reg_12582.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_93_V_read119_phi_phi_fu_18014_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_93_V_read119_phi_phi_fu_18014_p4 = ap_phi_mux_data_93_V_read119_rewind_phi_fu_12600_p6.read();
    } else {
        ap_phi_mux_data_93_V_read119_phi_phi_fu_18014_p4 = ap_phi_reg_pp0_iter1_data_93_V_read119_phi_reg_18010.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_93_V_read119_rewind_phi_fu_12600_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_93_V_read119_rewind_phi_fu_12600_p6 = data_93_V_read119_phi_reg_18010.read();
    } else {
        ap_phi_mux_data_93_V_read119_rewind_phi_fu_12600_p6 = data_93_V_read119_rewind_reg_12596.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_94_V_read120_phi_phi_fu_18026_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_94_V_read120_phi_phi_fu_18026_p4 = ap_phi_mux_data_94_V_read120_rewind_phi_fu_12614_p6.read();
    } else {
        ap_phi_mux_data_94_V_read120_phi_phi_fu_18026_p4 = ap_phi_reg_pp0_iter1_data_94_V_read120_phi_reg_18022.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_94_V_read120_rewind_phi_fu_12614_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_94_V_read120_rewind_phi_fu_12614_p6 = data_94_V_read120_phi_reg_18022.read();
    } else {
        ap_phi_mux_data_94_V_read120_rewind_phi_fu_12614_p6 = data_94_V_read120_rewind_reg_12610.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_95_V_read121_phi_phi_fu_18038_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_95_V_read121_phi_phi_fu_18038_p4 = ap_phi_mux_data_95_V_read121_rewind_phi_fu_12628_p6.read();
    } else {
        ap_phi_mux_data_95_V_read121_phi_phi_fu_18038_p4 = ap_phi_reg_pp0_iter1_data_95_V_read121_phi_reg_18034.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_95_V_read121_rewind_phi_fu_12628_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_95_V_read121_rewind_phi_fu_12628_p6 = data_95_V_read121_phi_reg_18034.read();
    } else {
        ap_phi_mux_data_95_V_read121_rewind_phi_fu_12628_p6 = data_95_V_read121_rewind_reg_12624.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_96_V_read122_phi_phi_fu_18050_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_96_V_read122_phi_phi_fu_18050_p4 = ap_phi_mux_data_96_V_read122_rewind_phi_fu_12642_p6.read();
    } else {
        ap_phi_mux_data_96_V_read122_phi_phi_fu_18050_p4 = ap_phi_reg_pp0_iter1_data_96_V_read122_phi_reg_18046.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_96_V_read122_rewind_phi_fu_12642_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_96_V_read122_rewind_phi_fu_12642_p6 = data_96_V_read122_phi_reg_18046.read();
    } else {
        ap_phi_mux_data_96_V_read122_rewind_phi_fu_12642_p6 = data_96_V_read122_rewind_reg_12638.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_97_V_read123_phi_phi_fu_18062_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_97_V_read123_phi_phi_fu_18062_p4 = ap_phi_mux_data_97_V_read123_rewind_phi_fu_12656_p6.read();
    } else {
        ap_phi_mux_data_97_V_read123_phi_phi_fu_18062_p4 = ap_phi_reg_pp0_iter1_data_97_V_read123_phi_reg_18058.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_97_V_read123_rewind_phi_fu_12656_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_97_V_read123_rewind_phi_fu_12656_p6 = data_97_V_read123_phi_reg_18058.read();
    } else {
        ap_phi_mux_data_97_V_read123_rewind_phi_fu_12656_p6 = data_97_V_read123_rewind_reg_12652.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_98_V_read124_phi_phi_fu_18074_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_98_V_read124_phi_phi_fu_18074_p4 = ap_phi_mux_data_98_V_read124_rewind_phi_fu_12670_p6.read();
    } else {
        ap_phi_mux_data_98_V_read124_phi_phi_fu_18074_p4 = ap_phi_reg_pp0_iter1_data_98_V_read124_phi_reg_18070.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_98_V_read124_rewind_phi_fu_12670_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_98_V_read124_rewind_phi_fu_12670_p6 = data_98_V_read124_phi_reg_18070.read();
    } else {
        ap_phi_mux_data_98_V_read124_rewind_phi_fu_12670_p6 = data_98_V_read124_rewind_reg_12666.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_99_V_read125_phi_phi_fu_18086_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_99_V_read125_phi_phi_fu_18086_p4 = ap_phi_mux_data_99_V_read125_rewind_phi_fu_12684_p6.read();
    } else {
        ap_phi_mux_data_99_V_read125_phi_phi_fu_18086_p4 = ap_phi_reg_pp0_iter1_data_99_V_read125_phi_reg_18082.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_99_V_read125_rewind_phi_fu_12684_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_99_V_read125_rewind_phi_fu_12684_p6 = data_99_V_read125_phi_reg_18082.read();
    } else {
        ap_phi_mux_data_99_V_read125_rewind_phi_fu_12684_p6 = data_99_V_read125_rewind_reg_12680.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_9_V_read35_phi_phi_fu_17006_p4() {
    if (esl_seteq<1,1,1>(do_init_reg_11263.read(), ap_const_lv1_0)) {
        ap_phi_mux_data_9_V_read35_phi_phi_fu_17006_p4 = ap_phi_mux_data_9_V_read35_rewind_phi_fu_11424_p6.read();
    } else {
        ap_phi_mux_data_9_V_read35_phi_phi_fu_17006_p4 = ap_phi_reg_pp0_iter1_data_9_V_read35_phi_reg_17002.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_data_9_V_read35_rewind_phi_fu_11424_p6() {
    if ((esl_seteq<1,1,1>(ap_const_boolean_0, ap_block_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_enable_reg_pp0_iter2.read(), ap_const_logic_1) && 
         esl_seteq<1,1,1>(w_index25_reg_11279_pp0_iter1_reg.read(), ap_const_lv1_0))) {
        ap_phi_mux_data_9_V_read35_rewind_phi_fu_11424_p6 = data_9_V_read35_phi_reg_17002.read();
    } else {
        ap_phi_mux_data_9_V_read35_rewind_phi_fu_11424_p6 = data_9_V_read35_rewind_reg_11420.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_do_init_phi_fu_11267_p6() {
    if (esl_seteq<1,1,1>(ap_condition_7806.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11279.read())) {
            ap_phi_mux_do_init_phi_fu_11267_p6 = ap_const_lv1_1;
        } else if (esl_seteq<1,1,1>(w_index25_reg_11279.read(), ap_const_lv1_0)) {
            ap_phi_mux_do_init_phi_fu_11267_p6 = ap_const_lv1_0;
        } else {
            ap_phi_mux_do_init_phi_fu_11267_p6 = do_init_reg_11263.read();
        }
    } else {
        ap_phi_mux_do_init_phi_fu_11267_p6 = do_init_reg_11263.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_mux_w_index25_phi_fu_11283_p6() {
    if (esl_seteq<1,1,1>(ap_condition_7806.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11279.read())) {
            ap_phi_mux_w_index25_phi_fu_11283_p6 = ap_const_lv1_0;
        } else if (esl_seteq<1,1,1>(w_index25_reg_11279.read(), ap_const_lv1_0)) {
            ap_phi_mux_w_index25_phi_fu_11283_p6 = w_index_reg_95735.read();
        } else {
            ap_phi_mux_w_index25_phi_fu_11283_p6 = w_index25_reg_11279.read();
        }
    } else {
        ap_phi_mux_w_index25_phi_fu_11283_p6 = w_index25_reg_11279.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_0_V_read26_phi_reg_16894() {
    ap_phi_reg_pp0_iter0_data_0_V_read26_phi_reg_16894 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_100_V_read126_phi_reg_18094() {
    ap_phi_reg_pp0_iter0_data_100_V_read126_phi_reg_18094 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_101_V_read127_phi_reg_18106() {
    ap_phi_reg_pp0_iter0_data_101_V_read127_phi_reg_18106 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_102_V_read128_phi_reg_18118() {
    ap_phi_reg_pp0_iter0_data_102_V_read128_phi_reg_18118 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_103_V_read129_phi_reg_18130() {
    ap_phi_reg_pp0_iter0_data_103_V_read129_phi_reg_18130 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_104_V_read130_phi_reg_18142() {
    ap_phi_reg_pp0_iter0_data_104_V_read130_phi_reg_18142 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_105_V_read131_phi_reg_18154() {
    ap_phi_reg_pp0_iter0_data_105_V_read131_phi_reg_18154 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_106_V_read132_phi_reg_18166() {
    ap_phi_reg_pp0_iter0_data_106_V_read132_phi_reg_18166 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_107_V_read133_phi_reg_18178() {
    ap_phi_reg_pp0_iter0_data_107_V_read133_phi_reg_18178 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_108_V_read134_phi_reg_18190() {
    ap_phi_reg_pp0_iter0_data_108_V_read134_phi_reg_18190 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_109_V_read135_phi_reg_18202() {
    ap_phi_reg_pp0_iter0_data_109_V_read135_phi_reg_18202 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_10_V_read36_phi_reg_17014() {
    ap_phi_reg_pp0_iter0_data_10_V_read36_phi_reg_17014 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_110_V_read136_phi_reg_18214() {
    ap_phi_reg_pp0_iter0_data_110_V_read136_phi_reg_18214 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_111_V_read137_phi_reg_18226() {
    ap_phi_reg_pp0_iter0_data_111_V_read137_phi_reg_18226 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_112_V_read138_phi_reg_18238() {
    ap_phi_reg_pp0_iter0_data_112_V_read138_phi_reg_18238 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_113_V_read139_phi_reg_18250() {
    ap_phi_reg_pp0_iter0_data_113_V_read139_phi_reg_18250 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_114_V_read140_phi_reg_18262() {
    ap_phi_reg_pp0_iter0_data_114_V_read140_phi_reg_18262 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_115_V_read141_phi_reg_18274() {
    ap_phi_reg_pp0_iter0_data_115_V_read141_phi_reg_18274 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_116_V_read142_phi_reg_18286() {
    ap_phi_reg_pp0_iter0_data_116_V_read142_phi_reg_18286 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_117_V_read143_phi_reg_18298() {
    ap_phi_reg_pp0_iter0_data_117_V_read143_phi_reg_18298 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_118_V_read144_phi_reg_18310() {
    ap_phi_reg_pp0_iter0_data_118_V_read144_phi_reg_18310 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_119_V_read145_phi_reg_18322() {
    ap_phi_reg_pp0_iter0_data_119_V_read145_phi_reg_18322 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_11_V_read37_phi_reg_17026() {
    ap_phi_reg_pp0_iter0_data_11_V_read37_phi_reg_17026 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_120_V_read146_phi_reg_18334() {
    ap_phi_reg_pp0_iter0_data_120_V_read146_phi_reg_18334 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_121_V_read147_phi_reg_18346() {
    ap_phi_reg_pp0_iter0_data_121_V_read147_phi_reg_18346 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_122_V_read148_phi_reg_18358() {
    ap_phi_reg_pp0_iter0_data_122_V_read148_phi_reg_18358 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_123_V_read149_phi_reg_18370() {
    ap_phi_reg_pp0_iter0_data_123_V_read149_phi_reg_18370 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_124_V_read150_phi_reg_18382() {
    ap_phi_reg_pp0_iter0_data_124_V_read150_phi_reg_18382 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_125_V_read151_phi_reg_18394() {
    ap_phi_reg_pp0_iter0_data_125_V_read151_phi_reg_18394 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_126_V_read152_phi_reg_18406() {
    ap_phi_reg_pp0_iter0_data_126_V_read152_phi_reg_18406 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_127_V_read153_phi_reg_18418() {
    ap_phi_reg_pp0_iter0_data_127_V_read153_phi_reg_18418 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_128_V_read154_phi_reg_18430() {
    ap_phi_reg_pp0_iter0_data_128_V_read154_phi_reg_18430 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_129_V_read155_phi_reg_18442() {
    ap_phi_reg_pp0_iter0_data_129_V_read155_phi_reg_18442 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_12_V_read38_phi_reg_17038() {
    ap_phi_reg_pp0_iter0_data_12_V_read38_phi_reg_17038 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_130_V_read156_phi_reg_18454() {
    ap_phi_reg_pp0_iter0_data_130_V_read156_phi_reg_18454 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_131_V_read157_phi_reg_18466() {
    ap_phi_reg_pp0_iter0_data_131_V_read157_phi_reg_18466 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_132_V_read158_phi_reg_18478() {
    ap_phi_reg_pp0_iter0_data_132_V_read158_phi_reg_18478 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_133_V_read159_phi_reg_18490() {
    ap_phi_reg_pp0_iter0_data_133_V_read159_phi_reg_18490 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_134_V_read160_phi_reg_18502() {
    ap_phi_reg_pp0_iter0_data_134_V_read160_phi_reg_18502 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_135_V_read161_phi_reg_18514() {
    ap_phi_reg_pp0_iter0_data_135_V_read161_phi_reg_18514 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_136_V_read162_phi_reg_18526() {
    ap_phi_reg_pp0_iter0_data_136_V_read162_phi_reg_18526 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_137_V_read163_phi_reg_18538() {
    ap_phi_reg_pp0_iter0_data_137_V_read163_phi_reg_18538 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_138_V_read164_phi_reg_18550() {
    ap_phi_reg_pp0_iter0_data_138_V_read164_phi_reg_18550 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_139_V_read165_phi_reg_18562() {
    ap_phi_reg_pp0_iter0_data_139_V_read165_phi_reg_18562 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_13_V_read39_phi_reg_17050() {
    ap_phi_reg_pp0_iter0_data_13_V_read39_phi_reg_17050 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_140_V_read166_phi_reg_18574() {
    ap_phi_reg_pp0_iter0_data_140_V_read166_phi_reg_18574 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_141_V_read167_phi_reg_18586() {
    ap_phi_reg_pp0_iter0_data_141_V_read167_phi_reg_18586 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_142_V_read168_phi_reg_18598() {
    ap_phi_reg_pp0_iter0_data_142_V_read168_phi_reg_18598 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_143_V_read169_phi_reg_18610() {
    ap_phi_reg_pp0_iter0_data_143_V_read169_phi_reg_18610 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_144_V_read170_phi_reg_18622() {
    ap_phi_reg_pp0_iter0_data_144_V_read170_phi_reg_18622 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_145_V_read171_phi_reg_18634() {
    ap_phi_reg_pp0_iter0_data_145_V_read171_phi_reg_18634 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_146_V_read172_phi_reg_18646() {
    ap_phi_reg_pp0_iter0_data_146_V_read172_phi_reg_18646 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_147_V_read173_phi_reg_18658() {
    ap_phi_reg_pp0_iter0_data_147_V_read173_phi_reg_18658 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_148_V_read174_phi_reg_18670() {
    ap_phi_reg_pp0_iter0_data_148_V_read174_phi_reg_18670 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_149_V_read175_phi_reg_18682() {
    ap_phi_reg_pp0_iter0_data_149_V_read175_phi_reg_18682 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_14_V_read40_phi_reg_17062() {
    ap_phi_reg_pp0_iter0_data_14_V_read40_phi_reg_17062 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_150_V_read176_phi_reg_18694() {
    ap_phi_reg_pp0_iter0_data_150_V_read176_phi_reg_18694 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_151_V_read177_phi_reg_18706() {
    ap_phi_reg_pp0_iter0_data_151_V_read177_phi_reg_18706 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_152_V_read178_phi_reg_18718() {
    ap_phi_reg_pp0_iter0_data_152_V_read178_phi_reg_18718 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_153_V_read179_phi_reg_18730() {
    ap_phi_reg_pp0_iter0_data_153_V_read179_phi_reg_18730 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_154_V_read180_phi_reg_18742() {
    ap_phi_reg_pp0_iter0_data_154_V_read180_phi_reg_18742 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_155_V_read181_phi_reg_18754() {
    ap_phi_reg_pp0_iter0_data_155_V_read181_phi_reg_18754 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_156_V_read182_phi_reg_18766() {
    ap_phi_reg_pp0_iter0_data_156_V_read182_phi_reg_18766 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_157_V_read183_phi_reg_18778() {
    ap_phi_reg_pp0_iter0_data_157_V_read183_phi_reg_18778 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_158_V_read184_phi_reg_18790() {
    ap_phi_reg_pp0_iter0_data_158_V_read184_phi_reg_18790 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_159_V_read185_phi_reg_18802() {
    ap_phi_reg_pp0_iter0_data_159_V_read185_phi_reg_18802 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_15_V_read41_phi_reg_17074() {
    ap_phi_reg_pp0_iter0_data_15_V_read41_phi_reg_17074 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_160_V_read186_phi_reg_18814() {
    ap_phi_reg_pp0_iter0_data_160_V_read186_phi_reg_18814 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_161_V_read187_phi_reg_18826() {
    ap_phi_reg_pp0_iter0_data_161_V_read187_phi_reg_18826 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_162_V_read188_phi_reg_18838() {
    ap_phi_reg_pp0_iter0_data_162_V_read188_phi_reg_18838 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_163_V_read189_phi_reg_18850() {
    ap_phi_reg_pp0_iter0_data_163_V_read189_phi_reg_18850 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_164_V_read190_phi_reg_18862() {
    ap_phi_reg_pp0_iter0_data_164_V_read190_phi_reg_18862 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_165_V_read191_phi_reg_18874() {
    ap_phi_reg_pp0_iter0_data_165_V_read191_phi_reg_18874 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_166_V_read192_phi_reg_18886() {
    ap_phi_reg_pp0_iter0_data_166_V_read192_phi_reg_18886 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_167_V_read193_phi_reg_18898() {
    ap_phi_reg_pp0_iter0_data_167_V_read193_phi_reg_18898 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_168_V_read194_phi_reg_18910() {
    ap_phi_reg_pp0_iter0_data_168_V_read194_phi_reg_18910 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_169_V_read195_phi_reg_18922() {
    ap_phi_reg_pp0_iter0_data_169_V_read195_phi_reg_18922 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_16_V_read42_phi_reg_17086() {
    ap_phi_reg_pp0_iter0_data_16_V_read42_phi_reg_17086 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_170_V_read196_phi_reg_18934() {
    ap_phi_reg_pp0_iter0_data_170_V_read196_phi_reg_18934 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_171_V_read197_phi_reg_18946() {
    ap_phi_reg_pp0_iter0_data_171_V_read197_phi_reg_18946 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_172_V_read198_phi_reg_18958() {
    ap_phi_reg_pp0_iter0_data_172_V_read198_phi_reg_18958 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_173_V_read199_phi_reg_18970() {
    ap_phi_reg_pp0_iter0_data_173_V_read199_phi_reg_18970 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_174_V_read200_phi_reg_18982() {
    ap_phi_reg_pp0_iter0_data_174_V_read200_phi_reg_18982 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_175_V_read201_phi_reg_18994() {
    ap_phi_reg_pp0_iter0_data_175_V_read201_phi_reg_18994 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_176_V_read202_phi_reg_19006() {
    ap_phi_reg_pp0_iter0_data_176_V_read202_phi_reg_19006 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_177_V_read203_phi_reg_19018() {
    ap_phi_reg_pp0_iter0_data_177_V_read203_phi_reg_19018 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_178_V_read204_phi_reg_19030() {
    ap_phi_reg_pp0_iter0_data_178_V_read204_phi_reg_19030 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_179_V_read205_phi_reg_19042() {
    ap_phi_reg_pp0_iter0_data_179_V_read205_phi_reg_19042 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_17_V_read43_phi_reg_17098() {
    ap_phi_reg_pp0_iter0_data_17_V_read43_phi_reg_17098 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_180_V_read206_phi_reg_19054() {
    ap_phi_reg_pp0_iter0_data_180_V_read206_phi_reg_19054 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_181_V_read207_phi_reg_19066() {
    ap_phi_reg_pp0_iter0_data_181_V_read207_phi_reg_19066 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_182_V_read208_phi_reg_19078() {
    ap_phi_reg_pp0_iter0_data_182_V_read208_phi_reg_19078 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_183_V_read209_phi_reg_19090() {
    ap_phi_reg_pp0_iter0_data_183_V_read209_phi_reg_19090 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_184_V_read210_phi_reg_19102() {
    ap_phi_reg_pp0_iter0_data_184_V_read210_phi_reg_19102 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_185_V_read211_phi_reg_19114() {
    ap_phi_reg_pp0_iter0_data_185_V_read211_phi_reg_19114 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_186_V_read212_phi_reg_19126() {
    ap_phi_reg_pp0_iter0_data_186_V_read212_phi_reg_19126 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_187_V_read213_phi_reg_19138() {
    ap_phi_reg_pp0_iter0_data_187_V_read213_phi_reg_19138 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_188_V_read214_phi_reg_19150() {
    ap_phi_reg_pp0_iter0_data_188_V_read214_phi_reg_19150 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_189_V_read215_phi_reg_19162() {
    ap_phi_reg_pp0_iter0_data_189_V_read215_phi_reg_19162 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_18_V_read44_phi_reg_17110() {
    ap_phi_reg_pp0_iter0_data_18_V_read44_phi_reg_17110 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_190_V_read216_phi_reg_19174() {
    ap_phi_reg_pp0_iter0_data_190_V_read216_phi_reg_19174 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_191_V_read217_phi_reg_19186() {
    ap_phi_reg_pp0_iter0_data_191_V_read217_phi_reg_19186 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_192_V_read218_phi_reg_19198() {
    ap_phi_reg_pp0_iter0_data_192_V_read218_phi_reg_19198 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_193_V_read219_phi_reg_19210() {
    ap_phi_reg_pp0_iter0_data_193_V_read219_phi_reg_19210 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_194_V_read220_phi_reg_19222() {
    ap_phi_reg_pp0_iter0_data_194_V_read220_phi_reg_19222 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_195_V_read221_phi_reg_19234() {
    ap_phi_reg_pp0_iter0_data_195_V_read221_phi_reg_19234 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_196_V_read222_phi_reg_19246() {
    ap_phi_reg_pp0_iter0_data_196_V_read222_phi_reg_19246 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_197_V_read223_phi_reg_19258() {
    ap_phi_reg_pp0_iter0_data_197_V_read223_phi_reg_19258 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_198_V_read224_phi_reg_19270() {
    ap_phi_reg_pp0_iter0_data_198_V_read224_phi_reg_19270 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_199_V_read225_phi_reg_19282() {
    ap_phi_reg_pp0_iter0_data_199_V_read225_phi_reg_19282 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_19_V_read45_phi_reg_17122() {
    ap_phi_reg_pp0_iter0_data_19_V_read45_phi_reg_17122 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_1_V_read27_phi_reg_16906() {
    ap_phi_reg_pp0_iter0_data_1_V_read27_phi_reg_16906 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_200_V_read226_phi_reg_19294() {
    ap_phi_reg_pp0_iter0_data_200_V_read226_phi_reg_19294 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_201_V_read227_phi_reg_19306() {
    ap_phi_reg_pp0_iter0_data_201_V_read227_phi_reg_19306 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_202_V_read228_phi_reg_19318() {
    ap_phi_reg_pp0_iter0_data_202_V_read228_phi_reg_19318 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_203_V_read229_phi_reg_19330() {
    ap_phi_reg_pp0_iter0_data_203_V_read229_phi_reg_19330 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_204_V_read230_phi_reg_19342() {
    ap_phi_reg_pp0_iter0_data_204_V_read230_phi_reg_19342 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_205_V_read231_phi_reg_19354() {
    ap_phi_reg_pp0_iter0_data_205_V_read231_phi_reg_19354 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_206_V_read232_phi_reg_19366() {
    ap_phi_reg_pp0_iter0_data_206_V_read232_phi_reg_19366 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_207_V_read233_phi_reg_19378() {
    ap_phi_reg_pp0_iter0_data_207_V_read233_phi_reg_19378 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_208_V_read234_phi_reg_19390() {
    ap_phi_reg_pp0_iter0_data_208_V_read234_phi_reg_19390 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_209_V_read235_phi_reg_19402() {
    ap_phi_reg_pp0_iter0_data_209_V_read235_phi_reg_19402 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_20_V_read46_phi_reg_17134() {
    ap_phi_reg_pp0_iter0_data_20_V_read46_phi_reg_17134 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_210_V_read236_phi_reg_19414() {
    ap_phi_reg_pp0_iter0_data_210_V_read236_phi_reg_19414 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_211_V_read237_phi_reg_19426() {
    ap_phi_reg_pp0_iter0_data_211_V_read237_phi_reg_19426 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_212_V_read238_phi_reg_19438() {
    ap_phi_reg_pp0_iter0_data_212_V_read238_phi_reg_19438 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_213_V_read239_phi_reg_19450() {
    ap_phi_reg_pp0_iter0_data_213_V_read239_phi_reg_19450 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_214_V_read240_phi_reg_19462() {
    ap_phi_reg_pp0_iter0_data_214_V_read240_phi_reg_19462 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_215_V_read241_phi_reg_19474() {
    ap_phi_reg_pp0_iter0_data_215_V_read241_phi_reg_19474 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_216_V_read242_phi_reg_19486() {
    ap_phi_reg_pp0_iter0_data_216_V_read242_phi_reg_19486 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_217_V_read243_phi_reg_19498() {
    ap_phi_reg_pp0_iter0_data_217_V_read243_phi_reg_19498 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_218_V_read244_phi_reg_19510() {
    ap_phi_reg_pp0_iter0_data_218_V_read244_phi_reg_19510 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_219_V_read245_phi_reg_19522() {
    ap_phi_reg_pp0_iter0_data_219_V_read245_phi_reg_19522 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_21_V_read47_phi_reg_17146() {
    ap_phi_reg_pp0_iter0_data_21_V_read47_phi_reg_17146 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_220_V_read246_phi_reg_19534() {
    ap_phi_reg_pp0_iter0_data_220_V_read246_phi_reg_19534 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_221_V_read247_phi_reg_19546() {
    ap_phi_reg_pp0_iter0_data_221_V_read247_phi_reg_19546 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_222_V_read248_phi_reg_19558() {
    ap_phi_reg_pp0_iter0_data_222_V_read248_phi_reg_19558 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_223_V_read249_phi_reg_19570() {
    ap_phi_reg_pp0_iter0_data_223_V_read249_phi_reg_19570 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_224_V_read250_phi_reg_19582() {
    ap_phi_reg_pp0_iter0_data_224_V_read250_phi_reg_19582 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_225_V_read251_phi_reg_19594() {
    ap_phi_reg_pp0_iter0_data_225_V_read251_phi_reg_19594 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_226_V_read252_phi_reg_19606() {
    ap_phi_reg_pp0_iter0_data_226_V_read252_phi_reg_19606 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_227_V_read253_phi_reg_19618() {
    ap_phi_reg_pp0_iter0_data_227_V_read253_phi_reg_19618 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_228_V_read254_phi_reg_19630() {
    ap_phi_reg_pp0_iter0_data_228_V_read254_phi_reg_19630 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_229_V_read255_phi_reg_19642() {
    ap_phi_reg_pp0_iter0_data_229_V_read255_phi_reg_19642 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_22_V_read48_phi_reg_17158() {
    ap_phi_reg_pp0_iter0_data_22_V_read48_phi_reg_17158 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_230_V_read256_phi_reg_19654() {
    ap_phi_reg_pp0_iter0_data_230_V_read256_phi_reg_19654 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_231_V_read257_phi_reg_19666() {
    ap_phi_reg_pp0_iter0_data_231_V_read257_phi_reg_19666 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_232_V_read258_phi_reg_19678() {
    ap_phi_reg_pp0_iter0_data_232_V_read258_phi_reg_19678 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_233_V_read259_phi_reg_19690() {
    ap_phi_reg_pp0_iter0_data_233_V_read259_phi_reg_19690 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_234_V_read260_phi_reg_19702() {
    ap_phi_reg_pp0_iter0_data_234_V_read260_phi_reg_19702 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_235_V_read261_phi_reg_19714() {
    ap_phi_reg_pp0_iter0_data_235_V_read261_phi_reg_19714 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_236_V_read262_phi_reg_19726() {
    ap_phi_reg_pp0_iter0_data_236_V_read262_phi_reg_19726 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_237_V_read263_phi_reg_19738() {
    ap_phi_reg_pp0_iter0_data_237_V_read263_phi_reg_19738 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_238_V_read264_phi_reg_19750() {
    ap_phi_reg_pp0_iter0_data_238_V_read264_phi_reg_19750 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_239_V_read265_phi_reg_19762() {
    ap_phi_reg_pp0_iter0_data_239_V_read265_phi_reg_19762 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_23_V_read49_phi_reg_17170() {
    ap_phi_reg_pp0_iter0_data_23_V_read49_phi_reg_17170 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_240_V_read266_phi_reg_19774() {
    ap_phi_reg_pp0_iter0_data_240_V_read266_phi_reg_19774 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_241_V_read267_phi_reg_19786() {
    ap_phi_reg_pp0_iter0_data_241_V_read267_phi_reg_19786 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_242_V_read268_phi_reg_19798() {
    ap_phi_reg_pp0_iter0_data_242_V_read268_phi_reg_19798 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_243_V_read269_phi_reg_19810() {
    ap_phi_reg_pp0_iter0_data_243_V_read269_phi_reg_19810 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_244_V_read270_phi_reg_19822() {
    ap_phi_reg_pp0_iter0_data_244_V_read270_phi_reg_19822 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_245_V_read271_phi_reg_19834() {
    ap_phi_reg_pp0_iter0_data_245_V_read271_phi_reg_19834 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_246_V_read272_phi_reg_19846() {
    ap_phi_reg_pp0_iter0_data_246_V_read272_phi_reg_19846 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_247_V_read273_phi_reg_19858() {
    ap_phi_reg_pp0_iter0_data_247_V_read273_phi_reg_19858 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_248_V_read274_phi_reg_19870() {
    ap_phi_reg_pp0_iter0_data_248_V_read274_phi_reg_19870 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_249_V_read275_phi_reg_19882() {
    ap_phi_reg_pp0_iter0_data_249_V_read275_phi_reg_19882 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_24_V_read50_phi_reg_17182() {
    ap_phi_reg_pp0_iter0_data_24_V_read50_phi_reg_17182 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_250_V_read276_phi_reg_19894() {
    ap_phi_reg_pp0_iter0_data_250_V_read276_phi_reg_19894 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_251_V_read277_phi_reg_19906() {
    ap_phi_reg_pp0_iter0_data_251_V_read277_phi_reg_19906 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_252_V_read278_phi_reg_19918() {
    ap_phi_reg_pp0_iter0_data_252_V_read278_phi_reg_19918 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_253_V_read279_phi_reg_19930() {
    ap_phi_reg_pp0_iter0_data_253_V_read279_phi_reg_19930 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_254_V_read280_phi_reg_19942() {
    ap_phi_reg_pp0_iter0_data_254_V_read280_phi_reg_19942 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_255_V_read281_phi_reg_19954() {
    ap_phi_reg_pp0_iter0_data_255_V_read281_phi_reg_19954 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_256_V_read282_phi_reg_19966() {
    ap_phi_reg_pp0_iter0_data_256_V_read282_phi_reg_19966 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_257_V_read283_phi_reg_19978() {
    ap_phi_reg_pp0_iter0_data_257_V_read283_phi_reg_19978 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_258_V_read284_phi_reg_19990() {
    ap_phi_reg_pp0_iter0_data_258_V_read284_phi_reg_19990 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_259_V_read285_phi_reg_20002() {
    ap_phi_reg_pp0_iter0_data_259_V_read285_phi_reg_20002 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_25_V_read51_phi_reg_17194() {
    ap_phi_reg_pp0_iter0_data_25_V_read51_phi_reg_17194 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_260_V_read286_phi_reg_20014() {
    ap_phi_reg_pp0_iter0_data_260_V_read286_phi_reg_20014 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_261_V_read287_phi_reg_20026() {
    ap_phi_reg_pp0_iter0_data_261_V_read287_phi_reg_20026 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_262_V_read288_phi_reg_20038() {
    ap_phi_reg_pp0_iter0_data_262_V_read288_phi_reg_20038 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

}

