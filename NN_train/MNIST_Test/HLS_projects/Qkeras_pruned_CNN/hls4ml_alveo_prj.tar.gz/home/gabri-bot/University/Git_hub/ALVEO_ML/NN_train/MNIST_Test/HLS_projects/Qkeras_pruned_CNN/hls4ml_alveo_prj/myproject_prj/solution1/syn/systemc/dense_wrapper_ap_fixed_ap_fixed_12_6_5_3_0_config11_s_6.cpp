#include "dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_263_V_read289_phi_reg_20050() {
    ap_phi_reg_pp0_iter0_data_263_V_read289_phi_reg_20050 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_264_V_read290_phi_reg_20062() {
    ap_phi_reg_pp0_iter0_data_264_V_read290_phi_reg_20062 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_265_V_read291_phi_reg_20074() {
    ap_phi_reg_pp0_iter0_data_265_V_read291_phi_reg_20074 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_266_V_read292_phi_reg_20086() {
    ap_phi_reg_pp0_iter0_data_266_V_read292_phi_reg_20086 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_267_V_read293_phi_reg_20098() {
    ap_phi_reg_pp0_iter0_data_267_V_read293_phi_reg_20098 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_268_V_read294_phi_reg_20110() {
    ap_phi_reg_pp0_iter0_data_268_V_read294_phi_reg_20110 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_269_V_read295_phi_reg_20122() {
    ap_phi_reg_pp0_iter0_data_269_V_read295_phi_reg_20122 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_26_V_read52_phi_reg_17206() {
    ap_phi_reg_pp0_iter0_data_26_V_read52_phi_reg_17206 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_270_V_read296_phi_reg_20134() {
    ap_phi_reg_pp0_iter0_data_270_V_read296_phi_reg_20134 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_271_V_read297_phi_reg_20146() {
    ap_phi_reg_pp0_iter0_data_271_V_read297_phi_reg_20146 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_272_V_read298_phi_reg_20158() {
    ap_phi_reg_pp0_iter0_data_272_V_read298_phi_reg_20158 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_273_V_read299_phi_reg_20170() {
    ap_phi_reg_pp0_iter0_data_273_V_read299_phi_reg_20170 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_274_V_read300_phi_reg_20182() {
    ap_phi_reg_pp0_iter0_data_274_V_read300_phi_reg_20182 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_275_V_read301_phi_reg_20194() {
    ap_phi_reg_pp0_iter0_data_275_V_read301_phi_reg_20194 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_276_V_read302_phi_reg_20206() {
    ap_phi_reg_pp0_iter0_data_276_V_read302_phi_reg_20206 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_277_V_read303_phi_reg_20218() {
    ap_phi_reg_pp0_iter0_data_277_V_read303_phi_reg_20218 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_278_V_read304_phi_reg_20230() {
    ap_phi_reg_pp0_iter0_data_278_V_read304_phi_reg_20230 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_279_V_read305_phi_reg_20242() {
    ap_phi_reg_pp0_iter0_data_279_V_read305_phi_reg_20242 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_27_V_read53_phi_reg_17218() {
    ap_phi_reg_pp0_iter0_data_27_V_read53_phi_reg_17218 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_280_V_read306_phi_reg_20254() {
    ap_phi_reg_pp0_iter0_data_280_V_read306_phi_reg_20254 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_281_V_read307_phi_reg_20266() {
    ap_phi_reg_pp0_iter0_data_281_V_read307_phi_reg_20266 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_282_V_read308_phi_reg_20278() {
    ap_phi_reg_pp0_iter0_data_282_V_read308_phi_reg_20278 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_283_V_read309_phi_reg_20290() {
    ap_phi_reg_pp0_iter0_data_283_V_read309_phi_reg_20290 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_284_V_read310_phi_reg_20302() {
    ap_phi_reg_pp0_iter0_data_284_V_read310_phi_reg_20302 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_285_V_read311_phi_reg_20314() {
    ap_phi_reg_pp0_iter0_data_285_V_read311_phi_reg_20314 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_286_V_read312_phi_reg_20326() {
    ap_phi_reg_pp0_iter0_data_286_V_read312_phi_reg_20326 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_287_V_read313_phi_reg_20338() {
    ap_phi_reg_pp0_iter0_data_287_V_read313_phi_reg_20338 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_288_V_read314_phi_reg_20350() {
    ap_phi_reg_pp0_iter0_data_288_V_read314_phi_reg_20350 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_289_V_read315_phi_reg_20362() {
    ap_phi_reg_pp0_iter0_data_289_V_read315_phi_reg_20362 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_28_V_read54_phi_reg_17230() {
    ap_phi_reg_pp0_iter0_data_28_V_read54_phi_reg_17230 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_290_V_read316_phi_reg_20374() {
    ap_phi_reg_pp0_iter0_data_290_V_read316_phi_reg_20374 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_291_V_read317_phi_reg_20386() {
    ap_phi_reg_pp0_iter0_data_291_V_read317_phi_reg_20386 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_292_V_read318_phi_reg_20398() {
    ap_phi_reg_pp0_iter0_data_292_V_read318_phi_reg_20398 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_293_V_read319_phi_reg_20410() {
    ap_phi_reg_pp0_iter0_data_293_V_read319_phi_reg_20410 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_294_V_read320_phi_reg_20422() {
    ap_phi_reg_pp0_iter0_data_294_V_read320_phi_reg_20422 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_295_V_read321_phi_reg_20434() {
    ap_phi_reg_pp0_iter0_data_295_V_read321_phi_reg_20434 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_296_V_read322_phi_reg_20446() {
    ap_phi_reg_pp0_iter0_data_296_V_read322_phi_reg_20446 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_297_V_read323_phi_reg_20458() {
    ap_phi_reg_pp0_iter0_data_297_V_read323_phi_reg_20458 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_298_V_read324_phi_reg_20470() {
    ap_phi_reg_pp0_iter0_data_298_V_read324_phi_reg_20470 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_299_V_read325_phi_reg_20482() {
    ap_phi_reg_pp0_iter0_data_299_V_read325_phi_reg_20482 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_29_V_read55_phi_reg_17242() {
    ap_phi_reg_pp0_iter0_data_29_V_read55_phi_reg_17242 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_2_V_read28_phi_reg_16918() {
    ap_phi_reg_pp0_iter0_data_2_V_read28_phi_reg_16918 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_300_V_read326_phi_reg_20494() {
    ap_phi_reg_pp0_iter0_data_300_V_read326_phi_reg_20494 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_301_V_read327_phi_reg_20506() {
    ap_phi_reg_pp0_iter0_data_301_V_read327_phi_reg_20506 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_302_V_read328_phi_reg_20518() {
    ap_phi_reg_pp0_iter0_data_302_V_read328_phi_reg_20518 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_303_V_read329_phi_reg_20530() {
    ap_phi_reg_pp0_iter0_data_303_V_read329_phi_reg_20530 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_304_V_read330_phi_reg_20542() {
    ap_phi_reg_pp0_iter0_data_304_V_read330_phi_reg_20542 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_305_V_read331_phi_reg_20554() {
    ap_phi_reg_pp0_iter0_data_305_V_read331_phi_reg_20554 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_306_V_read332_phi_reg_20566() {
    ap_phi_reg_pp0_iter0_data_306_V_read332_phi_reg_20566 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_307_V_read333_phi_reg_20578() {
    ap_phi_reg_pp0_iter0_data_307_V_read333_phi_reg_20578 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_308_V_read334_phi_reg_20590() {
    ap_phi_reg_pp0_iter0_data_308_V_read334_phi_reg_20590 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_309_V_read335_phi_reg_20602() {
    ap_phi_reg_pp0_iter0_data_309_V_read335_phi_reg_20602 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_30_V_read56_phi_reg_17254() {
    ap_phi_reg_pp0_iter0_data_30_V_read56_phi_reg_17254 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_310_V_read336_phi_reg_20614() {
    ap_phi_reg_pp0_iter0_data_310_V_read336_phi_reg_20614 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_311_V_read337_phi_reg_20626() {
    ap_phi_reg_pp0_iter0_data_311_V_read337_phi_reg_20626 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_312_V_read338_phi_reg_20638() {
    ap_phi_reg_pp0_iter0_data_312_V_read338_phi_reg_20638 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_313_V_read339_phi_reg_20650() {
    ap_phi_reg_pp0_iter0_data_313_V_read339_phi_reg_20650 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_314_V_read340_phi_reg_20662() {
    ap_phi_reg_pp0_iter0_data_314_V_read340_phi_reg_20662 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_315_V_read341_phi_reg_20674() {
    ap_phi_reg_pp0_iter0_data_315_V_read341_phi_reg_20674 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_316_V_read342_phi_reg_20686() {
    ap_phi_reg_pp0_iter0_data_316_V_read342_phi_reg_20686 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_317_V_read343_phi_reg_20698() {
    ap_phi_reg_pp0_iter0_data_317_V_read343_phi_reg_20698 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_318_V_read344_phi_reg_20710() {
    ap_phi_reg_pp0_iter0_data_318_V_read344_phi_reg_20710 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_319_V_read345_phi_reg_20722() {
    ap_phi_reg_pp0_iter0_data_319_V_read345_phi_reg_20722 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_31_V_read57_phi_reg_17266() {
    ap_phi_reg_pp0_iter0_data_31_V_read57_phi_reg_17266 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_320_V_read346_phi_reg_20734() {
    ap_phi_reg_pp0_iter0_data_320_V_read346_phi_reg_20734 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_321_V_read347_phi_reg_20746() {
    ap_phi_reg_pp0_iter0_data_321_V_read347_phi_reg_20746 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_322_V_read348_phi_reg_20758() {
    ap_phi_reg_pp0_iter0_data_322_V_read348_phi_reg_20758 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_323_V_read349_phi_reg_20770() {
    ap_phi_reg_pp0_iter0_data_323_V_read349_phi_reg_20770 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_324_V_read350_phi_reg_20782() {
    ap_phi_reg_pp0_iter0_data_324_V_read350_phi_reg_20782 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_325_V_read351_phi_reg_20794() {
    ap_phi_reg_pp0_iter0_data_325_V_read351_phi_reg_20794 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_326_V_read352_phi_reg_20806() {
    ap_phi_reg_pp0_iter0_data_326_V_read352_phi_reg_20806 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_327_V_read353_phi_reg_20818() {
    ap_phi_reg_pp0_iter0_data_327_V_read353_phi_reg_20818 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_328_V_read354_phi_reg_20830() {
    ap_phi_reg_pp0_iter0_data_328_V_read354_phi_reg_20830 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_329_V_read355_phi_reg_20842() {
    ap_phi_reg_pp0_iter0_data_329_V_read355_phi_reg_20842 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_32_V_read58_phi_reg_17278() {
    ap_phi_reg_pp0_iter0_data_32_V_read58_phi_reg_17278 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_330_V_read356_phi_reg_20854() {
    ap_phi_reg_pp0_iter0_data_330_V_read356_phi_reg_20854 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_331_V_read357_phi_reg_20866() {
    ap_phi_reg_pp0_iter0_data_331_V_read357_phi_reg_20866 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_332_V_read358_phi_reg_20878() {
    ap_phi_reg_pp0_iter0_data_332_V_read358_phi_reg_20878 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_333_V_read359_phi_reg_20890() {
    ap_phi_reg_pp0_iter0_data_333_V_read359_phi_reg_20890 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_334_V_read360_phi_reg_20902() {
    ap_phi_reg_pp0_iter0_data_334_V_read360_phi_reg_20902 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_335_V_read361_phi_reg_20914() {
    ap_phi_reg_pp0_iter0_data_335_V_read361_phi_reg_20914 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_336_V_read362_phi_reg_20926() {
    ap_phi_reg_pp0_iter0_data_336_V_read362_phi_reg_20926 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_337_V_read363_phi_reg_20938() {
    ap_phi_reg_pp0_iter0_data_337_V_read363_phi_reg_20938 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_338_V_read364_phi_reg_20950() {
    ap_phi_reg_pp0_iter0_data_338_V_read364_phi_reg_20950 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_339_V_read365_phi_reg_20962() {
    ap_phi_reg_pp0_iter0_data_339_V_read365_phi_reg_20962 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_33_V_read59_phi_reg_17290() {
    ap_phi_reg_pp0_iter0_data_33_V_read59_phi_reg_17290 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_340_V_read366_phi_reg_20974() {
    ap_phi_reg_pp0_iter0_data_340_V_read366_phi_reg_20974 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_341_V_read367_phi_reg_20986() {
    ap_phi_reg_pp0_iter0_data_341_V_read367_phi_reg_20986 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_342_V_read368_phi_reg_20998() {
    ap_phi_reg_pp0_iter0_data_342_V_read368_phi_reg_20998 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_343_V_read369_phi_reg_21010() {
    ap_phi_reg_pp0_iter0_data_343_V_read369_phi_reg_21010 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_344_V_read370_phi_reg_21022() {
    ap_phi_reg_pp0_iter0_data_344_V_read370_phi_reg_21022 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_345_V_read371_phi_reg_21034() {
    ap_phi_reg_pp0_iter0_data_345_V_read371_phi_reg_21034 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_346_V_read372_phi_reg_21046() {
    ap_phi_reg_pp0_iter0_data_346_V_read372_phi_reg_21046 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_347_V_read373_phi_reg_21058() {
    ap_phi_reg_pp0_iter0_data_347_V_read373_phi_reg_21058 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_348_V_read374_phi_reg_21070() {
    ap_phi_reg_pp0_iter0_data_348_V_read374_phi_reg_21070 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_349_V_read375_phi_reg_21082() {
    ap_phi_reg_pp0_iter0_data_349_V_read375_phi_reg_21082 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_34_V_read60_phi_reg_17302() {
    ap_phi_reg_pp0_iter0_data_34_V_read60_phi_reg_17302 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_350_V_read376_phi_reg_21094() {
    ap_phi_reg_pp0_iter0_data_350_V_read376_phi_reg_21094 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_351_V_read377_phi_reg_21106() {
    ap_phi_reg_pp0_iter0_data_351_V_read377_phi_reg_21106 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_352_V_read378_phi_reg_21118() {
    ap_phi_reg_pp0_iter0_data_352_V_read378_phi_reg_21118 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_353_V_read379_phi_reg_21130() {
    ap_phi_reg_pp0_iter0_data_353_V_read379_phi_reg_21130 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_354_V_read380_phi_reg_21142() {
    ap_phi_reg_pp0_iter0_data_354_V_read380_phi_reg_21142 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_355_V_read381_phi_reg_21154() {
    ap_phi_reg_pp0_iter0_data_355_V_read381_phi_reg_21154 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_356_V_read382_phi_reg_21166() {
    ap_phi_reg_pp0_iter0_data_356_V_read382_phi_reg_21166 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_357_V_read383_phi_reg_21178() {
    ap_phi_reg_pp0_iter0_data_357_V_read383_phi_reg_21178 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_358_V_read384_phi_reg_21190() {
    ap_phi_reg_pp0_iter0_data_358_V_read384_phi_reg_21190 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_359_V_read385_phi_reg_21202() {
    ap_phi_reg_pp0_iter0_data_359_V_read385_phi_reg_21202 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_35_V_read61_phi_reg_17314() {
    ap_phi_reg_pp0_iter0_data_35_V_read61_phi_reg_17314 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_360_V_read386_phi_reg_21214() {
    ap_phi_reg_pp0_iter0_data_360_V_read386_phi_reg_21214 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_361_V_read387_phi_reg_21226() {
    ap_phi_reg_pp0_iter0_data_361_V_read387_phi_reg_21226 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_362_V_read388_phi_reg_21238() {
    ap_phi_reg_pp0_iter0_data_362_V_read388_phi_reg_21238 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_363_V_read389_phi_reg_21250() {
    ap_phi_reg_pp0_iter0_data_363_V_read389_phi_reg_21250 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_364_V_read390_phi_reg_21262() {
    ap_phi_reg_pp0_iter0_data_364_V_read390_phi_reg_21262 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_365_V_read391_phi_reg_21274() {
    ap_phi_reg_pp0_iter0_data_365_V_read391_phi_reg_21274 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_366_V_read392_phi_reg_21286() {
    ap_phi_reg_pp0_iter0_data_366_V_read392_phi_reg_21286 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_367_V_read393_phi_reg_21298() {
    ap_phi_reg_pp0_iter0_data_367_V_read393_phi_reg_21298 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_368_V_read394_phi_reg_21310() {
    ap_phi_reg_pp0_iter0_data_368_V_read394_phi_reg_21310 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_369_V_read395_phi_reg_21322() {
    ap_phi_reg_pp0_iter0_data_369_V_read395_phi_reg_21322 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_36_V_read62_phi_reg_17326() {
    ap_phi_reg_pp0_iter0_data_36_V_read62_phi_reg_17326 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_370_V_read396_phi_reg_21334() {
    ap_phi_reg_pp0_iter0_data_370_V_read396_phi_reg_21334 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_371_V_read397_phi_reg_21346() {
    ap_phi_reg_pp0_iter0_data_371_V_read397_phi_reg_21346 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_372_V_read398_phi_reg_21358() {
    ap_phi_reg_pp0_iter0_data_372_V_read398_phi_reg_21358 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_373_V_read399_phi_reg_21370() {
    ap_phi_reg_pp0_iter0_data_373_V_read399_phi_reg_21370 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_374_V_read400_phi_reg_21382() {
    ap_phi_reg_pp0_iter0_data_374_V_read400_phi_reg_21382 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_375_V_read401_phi_reg_21394() {
    ap_phi_reg_pp0_iter0_data_375_V_read401_phi_reg_21394 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_376_V_read402_phi_reg_21406() {
    ap_phi_reg_pp0_iter0_data_376_V_read402_phi_reg_21406 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_377_V_read403_phi_reg_21418() {
    ap_phi_reg_pp0_iter0_data_377_V_read403_phi_reg_21418 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_378_V_read404_phi_reg_21430() {
    ap_phi_reg_pp0_iter0_data_378_V_read404_phi_reg_21430 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_379_V_read405_phi_reg_21442() {
    ap_phi_reg_pp0_iter0_data_379_V_read405_phi_reg_21442 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_37_V_read63_phi_reg_17338() {
    ap_phi_reg_pp0_iter0_data_37_V_read63_phi_reg_17338 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_380_V_read406_phi_reg_21454() {
    ap_phi_reg_pp0_iter0_data_380_V_read406_phi_reg_21454 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_381_V_read407_phi_reg_21466() {
    ap_phi_reg_pp0_iter0_data_381_V_read407_phi_reg_21466 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_382_V_read408_phi_reg_21478() {
    ap_phi_reg_pp0_iter0_data_382_V_read408_phi_reg_21478 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_383_V_read409_phi_reg_21490() {
    ap_phi_reg_pp0_iter0_data_383_V_read409_phi_reg_21490 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_384_V_read410_phi_reg_21502() {
    ap_phi_reg_pp0_iter0_data_384_V_read410_phi_reg_21502 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_385_V_read411_phi_reg_21514() {
    ap_phi_reg_pp0_iter0_data_385_V_read411_phi_reg_21514 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_386_V_read412_phi_reg_21526() {
    ap_phi_reg_pp0_iter0_data_386_V_read412_phi_reg_21526 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_387_V_read413_phi_reg_21538() {
    ap_phi_reg_pp0_iter0_data_387_V_read413_phi_reg_21538 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_388_V_read414_phi_reg_21550() {
    ap_phi_reg_pp0_iter0_data_388_V_read414_phi_reg_21550 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_389_V_read415_phi_reg_21562() {
    ap_phi_reg_pp0_iter0_data_389_V_read415_phi_reg_21562 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_38_V_read64_phi_reg_17350() {
    ap_phi_reg_pp0_iter0_data_38_V_read64_phi_reg_17350 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_390_V_read416_phi_reg_21574() {
    ap_phi_reg_pp0_iter0_data_390_V_read416_phi_reg_21574 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_391_V_read417_phi_reg_21586() {
    ap_phi_reg_pp0_iter0_data_391_V_read417_phi_reg_21586 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_392_V_read418_phi_reg_21598() {
    ap_phi_reg_pp0_iter0_data_392_V_read418_phi_reg_21598 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_393_V_read419_phi_reg_21610() {
    ap_phi_reg_pp0_iter0_data_393_V_read419_phi_reg_21610 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_394_V_read420_phi_reg_21622() {
    ap_phi_reg_pp0_iter0_data_394_V_read420_phi_reg_21622 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_395_V_read421_phi_reg_21634() {
    ap_phi_reg_pp0_iter0_data_395_V_read421_phi_reg_21634 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_396_V_read422_phi_reg_21646() {
    ap_phi_reg_pp0_iter0_data_396_V_read422_phi_reg_21646 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_397_V_read423_phi_reg_21658() {
    ap_phi_reg_pp0_iter0_data_397_V_read423_phi_reg_21658 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_398_V_read424_phi_reg_21670() {
    ap_phi_reg_pp0_iter0_data_398_V_read424_phi_reg_21670 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_399_V_read425_phi_reg_21682() {
    ap_phi_reg_pp0_iter0_data_399_V_read425_phi_reg_21682 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_39_V_read65_phi_reg_17362() {
    ap_phi_reg_pp0_iter0_data_39_V_read65_phi_reg_17362 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_3_V_read29_phi_reg_16930() {
    ap_phi_reg_pp0_iter0_data_3_V_read29_phi_reg_16930 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_40_V_read66_phi_reg_17374() {
    ap_phi_reg_pp0_iter0_data_40_V_read66_phi_reg_17374 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_41_V_read67_phi_reg_17386() {
    ap_phi_reg_pp0_iter0_data_41_V_read67_phi_reg_17386 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_42_V_read68_phi_reg_17398() {
    ap_phi_reg_pp0_iter0_data_42_V_read68_phi_reg_17398 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_43_V_read69_phi_reg_17410() {
    ap_phi_reg_pp0_iter0_data_43_V_read69_phi_reg_17410 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_44_V_read70_phi_reg_17422() {
    ap_phi_reg_pp0_iter0_data_44_V_read70_phi_reg_17422 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_45_V_read71_phi_reg_17434() {
    ap_phi_reg_pp0_iter0_data_45_V_read71_phi_reg_17434 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_46_V_read72_phi_reg_17446() {
    ap_phi_reg_pp0_iter0_data_46_V_read72_phi_reg_17446 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_47_V_read73_phi_reg_17458() {
    ap_phi_reg_pp0_iter0_data_47_V_read73_phi_reg_17458 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_48_V_read74_phi_reg_17470() {
    ap_phi_reg_pp0_iter0_data_48_V_read74_phi_reg_17470 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_49_V_read75_phi_reg_17482() {
    ap_phi_reg_pp0_iter0_data_49_V_read75_phi_reg_17482 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_4_V_read30_phi_reg_16942() {
    ap_phi_reg_pp0_iter0_data_4_V_read30_phi_reg_16942 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_50_V_read76_phi_reg_17494() {
    ap_phi_reg_pp0_iter0_data_50_V_read76_phi_reg_17494 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_51_V_read77_phi_reg_17506() {
    ap_phi_reg_pp0_iter0_data_51_V_read77_phi_reg_17506 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_52_V_read78_phi_reg_17518() {
    ap_phi_reg_pp0_iter0_data_52_V_read78_phi_reg_17518 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_53_V_read79_phi_reg_17530() {
    ap_phi_reg_pp0_iter0_data_53_V_read79_phi_reg_17530 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_54_V_read80_phi_reg_17542() {
    ap_phi_reg_pp0_iter0_data_54_V_read80_phi_reg_17542 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_55_V_read81_phi_reg_17554() {
    ap_phi_reg_pp0_iter0_data_55_V_read81_phi_reg_17554 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_56_V_read82_phi_reg_17566() {
    ap_phi_reg_pp0_iter0_data_56_V_read82_phi_reg_17566 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_57_V_read83_phi_reg_17578() {
    ap_phi_reg_pp0_iter0_data_57_V_read83_phi_reg_17578 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_58_V_read84_phi_reg_17590() {
    ap_phi_reg_pp0_iter0_data_58_V_read84_phi_reg_17590 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_59_V_read85_phi_reg_17602() {
    ap_phi_reg_pp0_iter0_data_59_V_read85_phi_reg_17602 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_5_V_read31_phi_reg_16954() {
    ap_phi_reg_pp0_iter0_data_5_V_read31_phi_reg_16954 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_60_V_read86_phi_reg_17614() {
    ap_phi_reg_pp0_iter0_data_60_V_read86_phi_reg_17614 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_61_V_read87_phi_reg_17626() {
    ap_phi_reg_pp0_iter0_data_61_V_read87_phi_reg_17626 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_62_V_read88_phi_reg_17638() {
    ap_phi_reg_pp0_iter0_data_62_V_read88_phi_reg_17638 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_63_V_read89_phi_reg_17650() {
    ap_phi_reg_pp0_iter0_data_63_V_read89_phi_reg_17650 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_64_V_read90_phi_reg_17662() {
    ap_phi_reg_pp0_iter0_data_64_V_read90_phi_reg_17662 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_65_V_read91_phi_reg_17674() {
    ap_phi_reg_pp0_iter0_data_65_V_read91_phi_reg_17674 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_66_V_read92_phi_reg_17686() {
    ap_phi_reg_pp0_iter0_data_66_V_read92_phi_reg_17686 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_67_V_read93_phi_reg_17698() {
    ap_phi_reg_pp0_iter0_data_67_V_read93_phi_reg_17698 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_68_V_read94_phi_reg_17710() {
    ap_phi_reg_pp0_iter0_data_68_V_read94_phi_reg_17710 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_69_V_read95_phi_reg_17722() {
    ap_phi_reg_pp0_iter0_data_69_V_read95_phi_reg_17722 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_6_V_read32_phi_reg_16966() {
    ap_phi_reg_pp0_iter0_data_6_V_read32_phi_reg_16966 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_70_V_read96_phi_reg_17734() {
    ap_phi_reg_pp0_iter0_data_70_V_read96_phi_reg_17734 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_71_V_read97_phi_reg_17746() {
    ap_phi_reg_pp0_iter0_data_71_V_read97_phi_reg_17746 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_72_V_read98_phi_reg_17758() {
    ap_phi_reg_pp0_iter0_data_72_V_read98_phi_reg_17758 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_73_V_read99_phi_reg_17770() {
    ap_phi_reg_pp0_iter0_data_73_V_read99_phi_reg_17770 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_74_V_read100_phi_reg_17782() {
    ap_phi_reg_pp0_iter0_data_74_V_read100_phi_reg_17782 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_75_V_read101_phi_reg_17794() {
    ap_phi_reg_pp0_iter0_data_75_V_read101_phi_reg_17794 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_76_V_read102_phi_reg_17806() {
    ap_phi_reg_pp0_iter0_data_76_V_read102_phi_reg_17806 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_77_V_read103_phi_reg_17818() {
    ap_phi_reg_pp0_iter0_data_77_V_read103_phi_reg_17818 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_78_V_read104_phi_reg_17830() {
    ap_phi_reg_pp0_iter0_data_78_V_read104_phi_reg_17830 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_79_V_read105_phi_reg_17842() {
    ap_phi_reg_pp0_iter0_data_79_V_read105_phi_reg_17842 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_7_V_read33_phi_reg_16978() {
    ap_phi_reg_pp0_iter0_data_7_V_read33_phi_reg_16978 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_80_V_read106_phi_reg_17854() {
    ap_phi_reg_pp0_iter0_data_80_V_read106_phi_reg_17854 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_81_V_read107_phi_reg_17866() {
    ap_phi_reg_pp0_iter0_data_81_V_read107_phi_reg_17866 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_82_V_read108_phi_reg_17878() {
    ap_phi_reg_pp0_iter0_data_82_V_read108_phi_reg_17878 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_83_V_read109_phi_reg_17890() {
    ap_phi_reg_pp0_iter0_data_83_V_read109_phi_reg_17890 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_84_V_read110_phi_reg_17902() {
    ap_phi_reg_pp0_iter0_data_84_V_read110_phi_reg_17902 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_85_V_read111_phi_reg_17914() {
    ap_phi_reg_pp0_iter0_data_85_V_read111_phi_reg_17914 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_86_V_read112_phi_reg_17926() {
    ap_phi_reg_pp0_iter0_data_86_V_read112_phi_reg_17926 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_87_V_read113_phi_reg_17938() {
    ap_phi_reg_pp0_iter0_data_87_V_read113_phi_reg_17938 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_88_V_read114_phi_reg_17950() {
    ap_phi_reg_pp0_iter0_data_88_V_read114_phi_reg_17950 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_89_V_read115_phi_reg_17962() {
    ap_phi_reg_pp0_iter0_data_89_V_read115_phi_reg_17962 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_8_V_read34_phi_reg_16990() {
    ap_phi_reg_pp0_iter0_data_8_V_read34_phi_reg_16990 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_90_V_read116_phi_reg_17974() {
    ap_phi_reg_pp0_iter0_data_90_V_read116_phi_reg_17974 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_91_V_read117_phi_reg_17986() {
    ap_phi_reg_pp0_iter0_data_91_V_read117_phi_reg_17986 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_92_V_read118_phi_reg_17998() {
    ap_phi_reg_pp0_iter0_data_92_V_read118_phi_reg_17998 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_93_V_read119_phi_reg_18010() {
    ap_phi_reg_pp0_iter0_data_93_V_read119_phi_reg_18010 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_94_V_read120_phi_reg_18022() {
    ap_phi_reg_pp0_iter0_data_94_V_read120_phi_reg_18022 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_95_V_read121_phi_reg_18034() {
    ap_phi_reg_pp0_iter0_data_95_V_read121_phi_reg_18034 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_96_V_read122_phi_reg_18046() {
    ap_phi_reg_pp0_iter0_data_96_V_read122_phi_reg_18046 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_97_V_read123_phi_reg_18058() {
    ap_phi_reg_pp0_iter0_data_97_V_read123_phi_reg_18058 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_98_V_read124_phi_reg_18070() {
    ap_phi_reg_pp0_iter0_data_98_V_read124_phi_reg_18070 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_99_V_read125_phi_reg_18082() {
    ap_phi_reg_pp0_iter0_data_99_V_read125_phi_reg_18082 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_phi_reg_pp0_iter0_data_9_V_read35_phi_reg_17002() {
    ap_phi_reg_pp0_iter0_data_9_V_read35_phi_reg_17002 =  (sc_lv<12>) ("XXXXXXXXXXXX");
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_ready() {
    if ((esl_seteq<1,1,1>(ap_phi_mux_w_index25_phi_fu_11283_p6.read(), ap_const_lv1_1) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp0_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0))) {
        ap_ready = ap_const_logic_1;
    } else {
        ap_ready = ap_const_logic_0;
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_reset_idle_pp0() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_start.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_idle_pp0_0to2.read()))) {
        ap_reset_idle_pp0 = ap_const_logic_1;
    } else {
        ap_reset_idle_pp0 = ap_const_logic_0;
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_0() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11279_pp0_iter2_reg.read()))) {
        ap_return_0 = acc_0_V_fu_92400_p2.read();
    } else {
        ap_return_0 = ap_return_0_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_1() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11279_pp0_iter2_reg.read()))) {
        ap_return_1 = acc_1_V_fu_92540_p2.read();
    } else {
        ap_return_1 = ap_return_1_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_2() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11279_pp0_iter2_reg.read()))) {
        ap_return_2 = acc_2_V_fu_92680_p2.read();
    } else {
        ap_return_2 = ap_return_2_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_3() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11279_pp0_iter2_reg.read()))) {
        ap_return_3 = acc_3_V_fu_92820_p2.read();
    } else {
        ap_return_3 = ap_return_3_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_4() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11279_pp0_iter2_reg.read()))) {
        ap_return_4 = acc_4_V_fu_92960_p2.read();
    } else {
        ap_return_4 = ap_return_4_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_5() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11279_pp0_iter2_reg.read()))) {
        ap_return_5 = acc_5_V_fu_93100_p2.read();
    } else {
        ap_return_5 = ap_return_5_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_6() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11279_pp0_iter2_reg.read()))) {
        ap_return_6 = acc_6_V_fu_93240_p2.read();
    } else {
        ap_return_6 = ap_return_6_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_7() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11279_pp0_iter2_reg.read()))) {
        ap_return_7 = acc_7_V_fu_93380_p2.read();
    } else {
        ap_return_7 = ap_return_7_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_8() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11279_pp0_iter2_reg.read()))) {
        ap_return_8 = acc_8_V_fu_93520_p2.read();
    } else {
        ap_return_8 = ap_return_8_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_ap_return_9() {
    if ((esl_seteq<1,1,1>(ap_block_pp0_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp0_iter3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, w_index25_reg_11279_pp0_iter2_reg.read()))) {
        ap_return_9 = acc_9_V_fu_93660_p2.read();
    } else {
        ap_return_9 = ap_return_9_preg.read();
    }
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1000_fu_71647_p0() {
    mul_ln1118_1000_fu_71647_p0 =  (sc_lv<12>) (sext_ln1116_200_cast_fu_55869_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1000_fu_71647_p1() {
    mul_ln1118_1000_fu_71647_p1 = tmp_1000_reg_101557.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1000_fu_71647_p2() {
    mul_ln1118_1000_fu_71647_p2 = (!mul_ln1118_1000_fu_71647_p0.read().is_01() || !mul_ln1118_1000_fu_71647_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1000_fu_71647_p0.read()) * sc_bigint<5>(mul_ln1118_1000_fu_71647_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1001_fu_71666_p0() {
    mul_ln1118_1001_fu_71666_p0 =  (sc_lv<12>) (sext_ln1116_201_cast_reg_97536.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1001_fu_71666_p1() {
    mul_ln1118_1001_fu_71666_p1 = tmp_1001_reg_101562.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1001_fu_71666_p2() {
    mul_ln1118_1001_fu_71666_p2 = (!mul_ln1118_1001_fu_71666_p0.read().is_01() || !mul_ln1118_1001_fu_71666_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1001_fu_71666_p0.read()) * sc_bigint<5>(mul_ln1118_1001_fu_71666_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1002_fu_71684_p0() {
    mul_ln1118_1002_fu_71684_p0 =  (sc_lv<12>) (sext_ln1116_202_cast_reg_97554.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1002_fu_71684_p1() {
    mul_ln1118_1002_fu_71684_p1 = tmp_1002_reg_101567.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1002_fu_71684_p2() {
    mul_ln1118_1002_fu_71684_p2 = (!mul_ln1118_1002_fu_71684_p0.read().is_01() || !mul_ln1118_1002_fu_71684_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1002_fu_71684_p0.read()) * sc_bigint<5>(mul_ln1118_1002_fu_71684_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1003_fu_37885_p0() {
    mul_ln1118_1003_fu_37885_p0 =  (sc_lv<12>) (sext_ln1116_203_cast_fu_26297_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1003_fu_37885_p1() {
    mul_ln1118_1003_fu_37885_p1 = tmp_1003_fu_37871_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1003_fu_37885_p2() {
    mul_ln1118_1003_fu_37885_p2 = (!mul_ln1118_1003_fu_37885_p0.read().is_01() || !mul_ln1118_1003_fu_37885_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1003_fu_37885_p0.read()) * sc_bigint<5>(mul_ln1118_1003_fu_37885_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1004_fu_37915_p0() {
    mul_ln1118_1004_fu_37915_p0 =  (sc_lv<12>) (sext_ln1116_204_cast_fu_26339_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1004_fu_37915_p1() {
    mul_ln1118_1004_fu_37915_p1 = tmp_1004_fu_37901_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1004_fu_37915_p2() {
    mul_ln1118_1004_fu_37915_p2 = (!mul_ln1118_1004_fu_37915_p0.read().is_01() || !mul_ln1118_1004_fu_37915_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1004_fu_37915_p0.read()) * sc_bigint<5>(mul_ln1118_1004_fu_37915_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1005_fu_37945_p0() {
    mul_ln1118_1005_fu_37945_p0 =  (sc_lv<12>) (sext_ln1116_205_cast_fu_26381_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1005_fu_37945_p1() {
    mul_ln1118_1005_fu_37945_p1 = tmp_1005_fu_37931_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1005_fu_37945_p2() {
    mul_ln1118_1005_fu_37945_p2 = (!mul_ln1118_1005_fu_37945_p0.read().is_01() || !mul_ln1118_1005_fu_37945_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1005_fu_37945_p0.read()) * sc_bigint<5>(mul_ln1118_1005_fu_37945_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1006_fu_37975_p0() {
    mul_ln1118_1006_fu_37975_p0 =  (sc_lv<12>) (sext_ln1116_206_cast_fu_26423_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1006_fu_37975_p1() {
    mul_ln1118_1006_fu_37975_p1 = tmp_1006_fu_37961_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1006_fu_37975_p2() {
    mul_ln1118_1006_fu_37975_p2 = (!mul_ln1118_1006_fu_37975_p0.read().is_01() || !mul_ln1118_1006_fu_37975_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1006_fu_37975_p0.read()) * sc_bigint<5>(mul_ln1118_1006_fu_37975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1007_fu_38005_p0() {
    mul_ln1118_1007_fu_38005_p0 =  (sc_lv<12>) (sext_ln1116_207_cast_fu_26465_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1007_fu_38005_p1() {
    mul_ln1118_1007_fu_38005_p1 = tmp_1007_fu_37991_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1007_fu_38005_p2() {
    mul_ln1118_1007_fu_38005_p2 = (!mul_ln1118_1007_fu_38005_p0.read().is_01() || !mul_ln1118_1007_fu_38005_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1007_fu_38005_p0.read()) * sc_bigint<5>(mul_ln1118_1007_fu_38005_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1008_fu_38035_p0() {
    mul_ln1118_1008_fu_38035_p0 =  (sc_lv<12>) (sext_ln1116_208_cast_fu_26507_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1008_fu_38035_p1() {
    mul_ln1118_1008_fu_38035_p1 = tmp_1008_fu_38021_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1008_fu_38035_p2() {
    mul_ln1118_1008_fu_38035_p2 = (!mul_ln1118_1008_fu_38035_p0.read().is_01() || !mul_ln1118_1008_fu_38035_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1008_fu_38035_p0.read()) * sc_bigint<5>(mul_ln1118_1008_fu_38035_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1009_fu_72690_p0() {
    mul_ln1118_1009_fu_72690_p0 =  (sc_lv<12>) (sext_ln1116_cast_fu_52531_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1009_fu_72690_p1() {
    mul_ln1118_1009_fu_72690_p1 = tmp_1009_reg_101602.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1009_fu_72690_p2() {
    mul_ln1118_1009_fu_72690_p2 = (!mul_ln1118_1009_fu_72690_p0.read().is_01() || !mul_ln1118_1009_fu_72690_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1009_fu_72690_p0.read()) * sc_bigint<5>(mul_ln1118_1009_fu_72690_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_100_fu_54135_p0() {
    mul_ln1118_100_fu_54135_p0 =  (sc_lv<12>) (sext_ln1116_100_cast_fu_54129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_100_fu_54135_p1() {
    mul_ln1118_100_fu_54135_p1 = tmp_100_reg_96586.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_100_fu_54135_p2() {
    mul_ln1118_100_fu_54135_p2 = (!mul_ln1118_100_fu_54135_p0.read().is_01() || !mul_ln1118_100_fu_54135_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_100_fu_54135_p0.read()) * sc_bigint<5>(mul_ln1118_100_fu_54135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1010_fu_72709_p0() {
    mul_ln1118_1010_fu_72709_p0 =  (sc_lv<12>) (sext_ln1116_10_cast_fu_52553_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1010_fu_72709_p1() {
    mul_ln1118_1010_fu_72709_p1 = tmp_1010_reg_101607.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1010_fu_72709_p2() {
    mul_ln1118_1010_fu_72709_p2 = (!mul_ln1118_1010_fu_72709_p0.read().is_01() || !mul_ln1118_1010_fu_72709_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1010_fu_72709_p0.read()) * sc_bigint<5>(mul_ln1118_1010_fu_72709_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1011_fu_72728_p0() {
    mul_ln1118_1011_fu_72728_p0 =  (sc_lv<12>) (sext_ln1116_11_cast_fu_52575_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1011_fu_72728_p1() {
    mul_ln1118_1011_fu_72728_p1 = tmp_1011_reg_101612.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1011_fu_72728_p2() {
    mul_ln1118_1011_fu_72728_p2 = (!mul_ln1118_1011_fu_72728_p0.read().is_01() || !mul_ln1118_1011_fu_72728_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1011_fu_72728_p0.read()) * sc_bigint<5>(mul_ln1118_1011_fu_72728_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1012_fu_72747_p0() {
    mul_ln1118_1012_fu_72747_p0 =  (sc_lv<12>) (sext_ln1116_12_cast_fu_52597_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1012_fu_72747_p1() {
    mul_ln1118_1012_fu_72747_p1 = tmp_1012_reg_101617.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1012_fu_72747_p2() {
    mul_ln1118_1012_fu_72747_p2 = (!mul_ln1118_1012_fu_72747_p0.read().is_01() || !mul_ln1118_1012_fu_72747_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1012_fu_72747_p0.read()) * sc_bigint<5>(mul_ln1118_1012_fu_72747_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1013_fu_72766_p0() {
    mul_ln1118_1013_fu_72766_p0 =  (sc_lv<12>) (sext_ln1116_13_cast_fu_52619_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1013_fu_72766_p1() {
    mul_ln1118_1013_fu_72766_p1 = tmp_1013_reg_101622.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1013_fu_72766_p2() {
    mul_ln1118_1013_fu_72766_p2 = (!mul_ln1118_1013_fu_72766_p0.read().is_01() || !mul_ln1118_1013_fu_72766_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1013_fu_72766_p0.read()) * sc_bigint<5>(mul_ln1118_1013_fu_72766_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1014_fu_72785_p0() {
    mul_ln1118_1014_fu_72785_p0 =  (sc_lv<12>) (sext_ln1116_14_cast_fu_52641_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1014_fu_72785_p1() {
    mul_ln1118_1014_fu_72785_p1 = tmp_1014_reg_101627.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1014_fu_72785_p2() {
    mul_ln1118_1014_fu_72785_p2 = (!mul_ln1118_1014_fu_72785_p0.read().is_01() || !mul_ln1118_1014_fu_72785_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1014_fu_72785_p0.read()) * sc_bigint<5>(mul_ln1118_1014_fu_72785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1015_fu_72804_p0() {
    mul_ln1118_1015_fu_72804_p0 =  (sc_lv<12>) (sext_ln1116_15_cast_fu_52663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1015_fu_72804_p1() {
    mul_ln1118_1015_fu_72804_p1 = tmp_1015_reg_101632.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1015_fu_72804_p2() {
    mul_ln1118_1015_fu_72804_p2 = (!mul_ln1118_1015_fu_72804_p0.read().is_01() || !mul_ln1118_1015_fu_72804_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1015_fu_72804_p0.read()) * sc_bigint<5>(mul_ln1118_1015_fu_72804_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1016_fu_72823_p0() {
    mul_ln1118_1016_fu_72823_p0 =  (sc_lv<12>) (sext_ln1116_16_cast_fu_52685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1016_fu_72823_p1() {
    mul_ln1118_1016_fu_72823_p1 = tmp_1016_reg_101637.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1016_fu_72823_p2() {
    mul_ln1118_1016_fu_72823_p2 = (!mul_ln1118_1016_fu_72823_p0.read().is_01() || !mul_ln1118_1016_fu_72823_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1016_fu_72823_p0.read()) * sc_bigint<5>(mul_ln1118_1016_fu_72823_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1017_fu_72842_p0() {
    mul_ln1118_1017_fu_72842_p0 =  (sc_lv<12>) (sext_ln1116_17_cast_fu_52707_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1017_fu_72842_p1() {
    mul_ln1118_1017_fu_72842_p1 = tmp_1017_reg_101642.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1017_fu_72842_p2() {
    mul_ln1118_1017_fu_72842_p2 = (!mul_ln1118_1017_fu_72842_p0.read().is_01() || !mul_ln1118_1017_fu_72842_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1017_fu_72842_p0.read()) * sc_bigint<5>(mul_ln1118_1017_fu_72842_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1018_fu_72861_p0() {
    mul_ln1118_1018_fu_72861_p0 =  (sc_lv<12>) (sext_ln1116_18_cast_fu_52729_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1018_fu_72861_p1() {
    mul_ln1118_1018_fu_72861_p1 = tmp_1018_reg_101647.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1018_fu_72861_p2() {
    mul_ln1118_1018_fu_72861_p2 = (!mul_ln1118_1018_fu_72861_p0.read().is_01() || !mul_ln1118_1018_fu_72861_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1018_fu_72861_p0.read()) * sc_bigint<5>(mul_ln1118_1018_fu_72861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1019_fu_72880_p0() {
    mul_ln1118_1019_fu_72880_p0 =  (sc_lv<12>) (sext_ln1116_19_cast_fu_52751_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1019_fu_72880_p1() {
    mul_ln1118_1019_fu_72880_p1 = tmp_1019_reg_101652.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1019_fu_72880_p2() {
    mul_ln1118_1019_fu_72880_p2 = (!mul_ln1118_1019_fu_72880_p0.read().is_01() || !mul_ln1118_1019_fu_72880_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1019_fu_72880_p0.read()) * sc_bigint<5>(mul_ln1118_1019_fu_72880_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_101_fu_54157_p0() {
    mul_ln1118_101_fu_54157_p0 =  (sc_lv<12>) (sext_ln1116_101_cast_fu_54151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_101_fu_54157_p1() {
    mul_ln1118_101_fu_54157_p1 = tmp_101_reg_96596.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_101_fu_54157_p2() {
    mul_ln1118_101_fu_54157_p2 = (!mul_ln1118_101_fu_54157_p0.read().is_01() || !mul_ln1118_101_fu_54157_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_101_fu_54157_p0.read()) * sc_bigint<5>(mul_ln1118_101_fu_54157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1020_fu_72899_p0() {
    mul_ln1118_1020_fu_72899_p0 =  (sc_lv<12>) (sext_ln1116_20_cast_fu_52773_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1020_fu_72899_p1() {
    mul_ln1118_1020_fu_72899_p1 = tmp_1020_reg_101657.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1020_fu_72899_p2() {
    mul_ln1118_1020_fu_72899_p2 = (!mul_ln1118_1020_fu_72899_p0.read().is_01() || !mul_ln1118_1020_fu_72899_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1020_fu_72899_p0.read()) * sc_bigint<5>(mul_ln1118_1020_fu_72899_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1021_fu_72918_p0() {
    mul_ln1118_1021_fu_72918_p0 =  (sc_lv<12>) (sext_ln1116_21_cast_fu_52795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1021_fu_72918_p1() {
    mul_ln1118_1021_fu_72918_p1 = tmp_1021_reg_101662.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1021_fu_72918_p2() {
    mul_ln1118_1021_fu_72918_p2 = (!mul_ln1118_1021_fu_72918_p0.read().is_01() || !mul_ln1118_1021_fu_72918_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1021_fu_72918_p0.read()) * sc_bigint<5>(mul_ln1118_1021_fu_72918_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1022_fu_72937_p0() {
    mul_ln1118_1022_fu_72937_p0 =  (sc_lv<12>) (sext_ln1116_22_cast_fu_52817_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1022_fu_72937_p1() {
    mul_ln1118_1022_fu_72937_p1 = tmp_1022_reg_101667.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1022_fu_72937_p2() {
    mul_ln1118_1022_fu_72937_p2 = (!mul_ln1118_1022_fu_72937_p0.read().is_01() || !mul_ln1118_1022_fu_72937_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1022_fu_72937_p0.read()) * sc_bigint<5>(mul_ln1118_1022_fu_72937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1023_fu_72956_p0() {
    mul_ln1118_1023_fu_72956_p0 =  (sc_lv<12>) (sext_ln1116_23_cast_fu_52839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1023_fu_72956_p1() {
    mul_ln1118_1023_fu_72956_p1 = tmp_1023_reg_101672.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1023_fu_72956_p2() {
    mul_ln1118_1023_fu_72956_p2 = (!mul_ln1118_1023_fu_72956_p0.read().is_01() || !mul_ln1118_1023_fu_72956_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1023_fu_72956_p0.read()) * sc_bigint<5>(mul_ln1118_1023_fu_72956_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1024_fu_72975_p0() {
    mul_ln1118_1024_fu_72975_p0 =  (sc_lv<12>) (sext_ln1116_24_cast_fu_52861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1024_fu_72975_p1() {
    mul_ln1118_1024_fu_72975_p1 = tmp_1024_reg_101677.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1024_fu_72975_p2() {
    mul_ln1118_1024_fu_72975_p2 = (!mul_ln1118_1024_fu_72975_p0.read().is_01() || !mul_ln1118_1024_fu_72975_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1024_fu_72975_p0.read()) * sc_bigint<5>(mul_ln1118_1024_fu_72975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1025_fu_72994_p0() {
    mul_ln1118_1025_fu_72994_p0 =  (sc_lv<12>) (sext_ln1116_25_cast_fu_52883_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1025_fu_72994_p1() {
    mul_ln1118_1025_fu_72994_p1 = tmp_1025_reg_101682.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1025_fu_72994_p2() {
    mul_ln1118_1025_fu_72994_p2 = (!mul_ln1118_1025_fu_72994_p0.read().is_01() || !mul_ln1118_1025_fu_72994_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1025_fu_72994_p0.read()) * sc_bigint<5>(mul_ln1118_1025_fu_72994_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1026_fu_73013_p0() {
    mul_ln1118_1026_fu_73013_p0 =  (sc_lv<12>) (sext_ln1116_26_cast_fu_52905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1026_fu_73013_p1() {
    mul_ln1118_1026_fu_73013_p1 = tmp_1026_reg_101687.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1026_fu_73013_p2() {
    mul_ln1118_1026_fu_73013_p2 = (!mul_ln1118_1026_fu_73013_p0.read().is_01() || !mul_ln1118_1026_fu_73013_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1026_fu_73013_p0.read()) * sc_bigint<5>(mul_ln1118_1026_fu_73013_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1027_fu_73032_p0() {
    mul_ln1118_1027_fu_73032_p0 =  (sc_lv<12>) (sext_ln1116_27_cast_fu_52927_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1027_fu_73032_p1() {
    mul_ln1118_1027_fu_73032_p1 = tmp_1027_reg_101692.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1027_fu_73032_p2() {
    mul_ln1118_1027_fu_73032_p2 = (!mul_ln1118_1027_fu_73032_p0.read().is_01() || !mul_ln1118_1027_fu_73032_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1027_fu_73032_p0.read()) * sc_bigint<5>(mul_ln1118_1027_fu_73032_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1028_fu_38255_p0() {
    mul_ln1118_1028_fu_38255_p0 =  (sc_lv<12>) (sext_ln1116_28_cast_fu_22199_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1028_fu_38255_p1() {
    mul_ln1118_1028_fu_38255_p1 = tmp_1028_fu_38241_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1028_fu_38255_p2() {
    mul_ln1118_1028_fu_38255_p2 = (!mul_ln1118_1028_fu_38255_p0.read().is_01() || !mul_ln1118_1028_fu_38255_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1028_fu_38255_p0.read()) * sc_bigint<5>(mul_ln1118_1028_fu_38255_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1029_fu_38285_p0() {
    mul_ln1118_1029_fu_38285_p0 =  (sc_lv<12>) (sext_ln1116_29_cast_fu_22241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1029_fu_38285_p1() {
    mul_ln1118_1029_fu_38285_p1 = tmp_1029_fu_38271_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1029_fu_38285_p2() {
    mul_ln1118_1029_fu_38285_p2 = (!mul_ln1118_1029_fu_38285_p0.read().is_01() || !mul_ln1118_1029_fu_38285_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1029_fu_38285_p0.read()) * sc_bigint<5>(mul_ln1118_1029_fu_38285_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_102_fu_54176_p0() {
    mul_ln1118_102_fu_54176_p0 =  (sc_lv<12>) (sext_ln1116_102_cast_reg_96606.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_102_fu_54176_p1() {
    mul_ln1118_102_fu_54176_p1 = tmp_102_reg_96601.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_102_fu_54176_p2() {
    mul_ln1118_102_fu_54176_p2 = (!mul_ln1118_102_fu_54176_p0.read().is_01() || !mul_ln1118_102_fu_54176_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_102_fu_54176_p0.read()) * sc_bigint<5>(mul_ln1118_102_fu_54176_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1030_fu_38315_p0() {
    mul_ln1118_1030_fu_38315_p0 =  (sc_lv<12>) (sext_ln1116_30_cast_fu_22283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1030_fu_38315_p1() {
    mul_ln1118_1030_fu_38315_p1 = tmp_1030_fu_38301_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1030_fu_38315_p2() {
    mul_ln1118_1030_fu_38315_p2 = (!mul_ln1118_1030_fu_38315_p0.read().is_01() || !mul_ln1118_1030_fu_38315_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1030_fu_38315_p0.read()) * sc_bigint<5>(mul_ln1118_1030_fu_38315_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1031_fu_38345_p0() {
    mul_ln1118_1031_fu_38345_p0 =  (sc_lv<12>) (sext_ln1116_31_cast_fu_22325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1031_fu_38345_p1() {
    mul_ln1118_1031_fu_38345_p1 = tmp_1031_fu_38331_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1031_fu_38345_p2() {
    mul_ln1118_1031_fu_38345_p2 = (!mul_ln1118_1031_fu_38345_p0.read().is_01() || !mul_ln1118_1031_fu_38345_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1031_fu_38345_p0.read()) * sc_bigint<5>(mul_ln1118_1031_fu_38345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1032_fu_38375_p0() {
    mul_ln1118_1032_fu_38375_p0 =  (sc_lv<12>) (sext_ln1116_32_cast_fu_22367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1032_fu_38375_p1() {
    mul_ln1118_1032_fu_38375_p1 = tmp_1032_fu_38361_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1032_fu_38375_p2() {
    mul_ln1118_1032_fu_38375_p2 = (!mul_ln1118_1032_fu_38375_p0.read().is_01() || !mul_ln1118_1032_fu_38375_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1032_fu_38375_p0.read()) * sc_bigint<5>(mul_ln1118_1032_fu_38375_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1033_fu_38405_p0() {
    mul_ln1118_1033_fu_38405_p0 =  (sc_lv<12>) (sext_ln1116_33_cast_fu_22409_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1033_fu_38405_p1() {
    mul_ln1118_1033_fu_38405_p1 = tmp_1033_fu_38391_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1033_fu_38405_p2() {
    mul_ln1118_1033_fu_38405_p2 = (!mul_ln1118_1033_fu_38405_p0.read().is_01() || !mul_ln1118_1033_fu_38405_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1033_fu_38405_p0.read()) * sc_bigint<5>(mul_ln1118_1033_fu_38405_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1034_fu_73051_p0() {
    mul_ln1118_1034_fu_73051_p0 =  (sc_lv<12>) (sext_ln1116_34_cast_fu_52949_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1034_fu_73051_p1() {
    mul_ln1118_1034_fu_73051_p1 = tmp_1034_reg_101727.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1034_fu_73051_p2() {
    mul_ln1118_1034_fu_73051_p2 = (!mul_ln1118_1034_fu_73051_p0.read().is_01() || !mul_ln1118_1034_fu_73051_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1034_fu_73051_p0.read()) * sc_bigint<5>(mul_ln1118_1034_fu_73051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1035_fu_73070_p0() {
    mul_ln1118_1035_fu_73070_p0 =  (sc_lv<12>) (sext_ln1116_35_cast_fu_52971_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1035_fu_73070_p1() {
    mul_ln1118_1035_fu_73070_p1 = tmp_1035_reg_101732.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1035_fu_73070_p2() {
    mul_ln1118_1035_fu_73070_p2 = (!mul_ln1118_1035_fu_73070_p0.read().is_01() || !mul_ln1118_1035_fu_73070_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1035_fu_73070_p0.read()) * sc_bigint<5>(mul_ln1118_1035_fu_73070_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1036_fu_73089_p0() {
    mul_ln1118_1036_fu_73089_p0 =  (sc_lv<12>) (sext_ln1116_36_cast_fu_52993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1036_fu_73089_p1() {
    mul_ln1118_1036_fu_73089_p1 = tmp_1036_reg_101737.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1036_fu_73089_p2() {
    mul_ln1118_1036_fu_73089_p2 = (!mul_ln1118_1036_fu_73089_p0.read().is_01() || !mul_ln1118_1036_fu_73089_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1036_fu_73089_p0.read()) * sc_bigint<5>(mul_ln1118_1036_fu_73089_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1037_fu_73108_p0() {
    mul_ln1118_1037_fu_73108_p0 =  (sc_lv<12>) (sext_ln1116_37_cast_fu_53015_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1037_fu_73108_p1() {
    mul_ln1118_1037_fu_73108_p1 = tmp_1037_reg_101742.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1037_fu_73108_p2() {
    mul_ln1118_1037_fu_73108_p2 = (!mul_ln1118_1037_fu_73108_p0.read().is_01() || !mul_ln1118_1037_fu_73108_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1037_fu_73108_p0.read()) * sc_bigint<5>(mul_ln1118_1037_fu_73108_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1038_fu_73127_p0() {
    mul_ln1118_1038_fu_73127_p0 =  (sc_lv<12>) (sext_ln1116_38_cast_fu_53037_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1038_fu_73127_p1() {
    mul_ln1118_1038_fu_73127_p1 = tmp_1038_reg_101747.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1038_fu_73127_p2() {
    mul_ln1118_1038_fu_73127_p2 = (!mul_ln1118_1038_fu_73127_p0.read().is_01() || !mul_ln1118_1038_fu_73127_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1038_fu_73127_p0.read()) * sc_bigint<5>(mul_ln1118_1038_fu_73127_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1039_fu_73146_p0() {
    mul_ln1118_1039_fu_73146_p0 =  (sc_lv<12>) (sext_ln1116_39_cast_fu_53059_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1039_fu_73146_p1() {
    mul_ln1118_1039_fu_73146_p1 = tmp_1039_reg_101752.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1039_fu_73146_p2() {
    mul_ln1118_1039_fu_73146_p2 = (!mul_ln1118_1039_fu_73146_p0.read().is_01() || !mul_ln1118_1039_fu_73146_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1039_fu_73146_p0.read()) * sc_bigint<5>(mul_ln1118_1039_fu_73146_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_103_fu_24001_p0() {
    mul_ln1118_103_fu_24001_p0 =  (sc_lv<12>) (sext_ln1116_103_cast_fu_23993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_103_fu_24001_p1() {
    mul_ln1118_103_fu_24001_p1 = tmp_103_fu_23983_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_103_fu_24001_p2() {
    mul_ln1118_103_fu_24001_p2 = (!mul_ln1118_103_fu_24001_p0.read().is_01() || !mul_ln1118_103_fu_24001_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_103_fu_24001_p0.read()) * sc_bigint<5>(mul_ln1118_103_fu_24001_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1040_fu_73165_p0() {
    mul_ln1118_1040_fu_73165_p0 =  (sc_lv<12>) (sext_ln1116_40_cast_fu_53081_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1040_fu_73165_p1() {
    mul_ln1118_1040_fu_73165_p1 = tmp_1040_reg_101757.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1040_fu_73165_p2() {
    mul_ln1118_1040_fu_73165_p2 = (!mul_ln1118_1040_fu_73165_p0.read().is_01() || !mul_ln1118_1040_fu_73165_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1040_fu_73165_p0.read()) * sc_bigint<5>(mul_ln1118_1040_fu_73165_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1041_fu_73184_p0() {
    mul_ln1118_1041_fu_73184_p0 =  (sc_lv<12>) (sext_ln1116_41_cast_fu_53103_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1041_fu_73184_p1() {
    mul_ln1118_1041_fu_73184_p1 = tmp_1041_reg_101762.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1041_fu_73184_p2() {
    mul_ln1118_1041_fu_73184_p2 = (!mul_ln1118_1041_fu_73184_p0.read().is_01() || !mul_ln1118_1041_fu_73184_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1041_fu_73184_p0.read()) * sc_bigint<5>(mul_ln1118_1041_fu_73184_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1042_fu_73203_p0() {
    mul_ln1118_1042_fu_73203_p0 =  (sc_lv<12>) (sext_ln1116_42_cast_fu_53125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1042_fu_73203_p1() {
    mul_ln1118_1042_fu_73203_p1 = tmp_1042_reg_101767.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1042_fu_73203_p2() {
    mul_ln1118_1042_fu_73203_p2 = (!mul_ln1118_1042_fu_73203_p0.read().is_01() || !mul_ln1118_1042_fu_73203_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1042_fu_73203_p0.read()) * sc_bigint<5>(mul_ln1118_1042_fu_73203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1043_fu_73222_p0() {
    mul_ln1118_1043_fu_73222_p0 =  (sc_lv<12>) (sext_ln1116_43_cast_fu_53147_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1043_fu_73222_p1() {
    mul_ln1118_1043_fu_73222_p1 = tmp_1043_reg_101772.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1043_fu_73222_p2() {
    mul_ln1118_1043_fu_73222_p2 = (!mul_ln1118_1043_fu_73222_p0.read().is_01() || !mul_ln1118_1043_fu_73222_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1043_fu_73222_p0.read()) * sc_bigint<5>(mul_ln1118_1043_fu_73222_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1044_fu_73241_p0() {
    mul_ln1118_1044_fu_73241_p0 =  (sc_lv<12>) (sext_ln1116_44_cast_fu_53169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1044_fu_73241_p1() {
    mul_ln1118_1044_fu_73241_p1 = tmp_1044_reg_101777.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1044_fu_73241_p2() {
    mul_ln1118_1044_fu_73241_p2 = (!mul_ln1118_1044_fu_73241_p0.read().is_01() || !mul_ln1118_1044_fu_73241_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1044_fu_73241_p0.read()) * sc_bigint<5>(mul_ln1118_1044_fu_73241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1045_fu_73260_p0() {
    mul_ln1118_1045_fu_73260_p0 =  (sc_lv<12>) (sext_ln1116_45_cast_fu_53191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1045_fu_73260_p1() {
    mul_ln1118_1045_fu_73260_p1 = tmp_1045_reg_101782.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1045_fu_73260_p2() {
    mul_ln1118_1045_fu_73260_p2 = (!mul_ln1118_1045_fu_73260_p0.read().is_01() || !mul_ln1118_1045_fu_73260_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1045_fu_73260_p0.read()) * sc_bigint<5>(mul_ln1118_1045_fu_73260_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1046_fu_73279_p0() {
    mul_ln1118_1046_fu_73279_p0 =  (sc_lv<12>) (sext_ln1116_46_cast_fu_53213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1046_fu_73279_p1() {
    mul_ln1118_1046_fu_73279_p1 = tmp_1046_reg_101787.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1046_fu_73279_p2() {
    mul_ln1118_1046_fu_73279_p2 = (!mul_ln1118_1046_fu_73279_p0.read().is_01() || !mul_ln1118_1046_fu_73279_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1046_fu_73279_p0.read()) * sc_bigint<5>(mul_ln1118_1046_fu_73279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1047_fu_73298_p0() {
    mul_ln1118_1047_fu_73298_p0 =  (sc_lv<12>) (sext_ln1116_47_cast_fu_53235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1047_fu_73298_p1() {
    mul_ln1118_1047_fu_73298_p1 = tmp_1047_reg_101792.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1047_fu_73298_p2() {
    mul_ln1118_1047_fu_73298_p2 = (!mul_ln1118_1047_fu_73298_p0.read().is_01() || !mul_ln1118_1047_fu_73298_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1047_fu_73298_p0.read()) * sc_bigint<5>(mul_ln1118_1047_fu_73298_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1048_fu_73317_p0() {
    mul_ln1118_1048_fu_73317_p0 =  (sc_lv<12>) (sext_ln1116_48_cast_fu_53257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1048_fu_73317_p1() {
    mul_ln1118_1048_fu_73317_p1 = tmp_1048_reg_101797.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1048_fu_73317_p2() {
    mul_ln1118_1048_fu_73317_p2 = (!mul_ln1118_1048_fu_73317_p0.read().is_01() || !mul_ln1118_1048_fu_73317_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1048_fu_73317_p0.read()) * sc_bigint<5>(mul_ln1118_1048_fu_73317_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1049_fu_73336_p0() {
    mul_ln1118_1049_fu_73336_p0 =  (sc_lv<12>) (sext_ln1116_49_cast_fu_53279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1049_fu_73336_p1() {
    mul_ln1118_1049_fu_73336_p1 = tmp_1049_reg_101802.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1049_fu_73336_p2() {
    mul_ln1118_1049_fu_73336_p2 = (!mul_ln1118_1049_fu_73336_p0.read().is_01() || !mul_ln1118_1049_fu_73336_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1049_fu_73336_p0.read()) * sc_bigint<5>(mul_ln1118_1049_fu_73336_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_104_fu_24043_p0() {
    mul_ln1118_104_fu_24043_p0 =  (sc_lv<12>) (sext_ln1116_104_cast_fu_24035_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_104_fu_24043_p1() {
    mul_ln1118_104_fu_24043_p1 = tmp_104_fu_24025_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_104_fu_24043_p2() {
    mul_ln1118_104_fu_24043_p2 = (!mul_ln1118_104_fu_24043_p0.read().is_01() || !mul_ln1118_104_fu_24043_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_104_fu_24043_p0.read()) * sc_bigint<5>(mul_ln1118_104_fu_24043_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1050_fu_73355_p0() {
    mul_ln1118_1050_fu_73355_p0 =  (sc_lv<12>) (sext_ln1116_50_cast_fu_53301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1050_fu_73355_p1() {
    mul_ln1118_1050_fu_73355_p1 = tmp_1050_reg_101807.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1050_fu_73355_p2() {
    mul_ln1118_1050_fu_73355_p2 = (!mul_ln1118_1050_fu_73355_p0.read().is_01() || !mul_ln1118_1050_fu_73355_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1050_fu_73355_p0.read()) * sc_bigint<5>(mul_ln1118_1050_fu_73355_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1051_fu_73374_p0() {
    mul_ln1118_1051_fu_73374_p0 =  (sc_lv<12>) (sext_ln1116_51_cast_fu_53323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1051_fu_73374_p1() {
    mul_ln1118_1051_fu_73374_p1 = tmp_1051_reg_101812.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1051_fu_73374_p2() {
    mul_ln1118_1051_fu_73374_p2 = (!mul_ln1118_1051_fu_73374_p0.read().is_01() || !mul_ln1118_1051_fu_73374_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1051_fu_73374_p0.read()) * sc_bigint<5>(mul_ln1118_1051_fu_73374_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1052_fu_73393_p0() {
    mul_ln1118_1052_fu_73393_p0 =  (sc_lv<12>) (sext_ln1116_52_cast_reg_96150.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1052_fu_73393_p1() {
    mul_ln1118_1052_fu_73393_p1 = tmp_1052_reg_101817.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1052_fu_73393_p2() {
    mul_ln1118_1052_fu_73393_p2 = (!mul_ln1118_1052_fu_73393_p0.read().is_01() || !mul_ln1118_1052_fu_73393_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1052_fu_73393_p0.read()) * sc_bigint<5>(mul_ln1118_1052_fu_73393_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1053_fu_38625_p0() {
    mul_ln1118_1053_fu_38625_p0 =  (sc_lv<12>) (sext_ln1116_53_cast_fu_22797_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1053_fu_38625_p1() {
    mul_ln1118_1053_fu_38625_p1 = tmp_1053_fu_38611_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1053_fu_38625_p2() {
    mul_ln1118_1053_fu_38625_p2 = (!mul_ln1118_1053_fu_38625_p0.read().is_01() || !mul_ln1118_1053_fu_38625_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1053_fu_38625_p0.read()) * sc_bigint<5>(mul_ln1118_1053_fu_38625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1054_fu_38655_p0() {
    mul_ln1118_1054_fu_38655_p0 =  (sc_lv<12>) (sext_ln1116_54_cast_fu_22839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1054_fu_38655_p1() {
    mul_ln1118_1054_fu_38655_p1 = tmp_1054_fu_38641_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1054_fu_38655_p2() {
    mul_ln1118_1054_fu_38655_p2 = (!mul_ln1118_1054_fu_38655_p0.read().is_01() || !mul_ln1118_1054_fu_38655_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1054_fu_38655_p0.read()) * sc_bigint<5>(mul_ln1118_1054_fu_38655_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1055_fu_38685_p0() {
    mul_ln1118_1055_fu_38685_p0 =  (sc_lv<12>) (sext_ln1116_55_cast_fu_22881_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1055_fu_38685_p1() {
    mul_ln1118_1055_fu_38685_p1 = tmp_1055_fu_38671_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1055_fu_38685_p2() {
    mul_ln1118_1055_fu_38685_p2 = (!mul_ln1118_1055_fu_38685_p0.read().is_01() || !mul_ln1118_1055_fu_38685_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1055_fu_38685_p0.read()) * sc_bigint<5>(mul_ln1118_1055_fu_38685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1056_fu_38715_p0() {
    mul_ln1118_1056_fu_38715_p0 =  (sc_lv<12>) (sext_ln1116_56_cast_fu_22923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1056_fu_38715_p1() {
    mul_ln1118_1056_fu_38715_p1 = tmp_1056_fu_38701_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1056_fu_38715_p2() {
    mul_ln1118_1056_fu_38715_p2 = (!mul_ln1118_1056_fu_38715_p0.read().is_01() || !mul_ln1118_1056_fu_38715_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1056_fu_38715_p0.read()) * sc_bigint<5>(mul_ln1118_1056_fu_38715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1057_fu_38745_p0() {
    mul_ln1118_1057_fu_38745_p0 =  (sc_lv<12>) (sext_ln1116_57_cast_fu_22965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1057_fu_38745_p1() {
    mul_ln1118_1057_fu_38745_p1 = tmp_1057_fu_38731_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1057_fu_38745_p2() {
    mul_ln1118_1057_fu_38745_p2 = (!mul_ln1118_1057_fu_38745_p0.read().is_01() || !mul_ln1118_1057_fu_38745_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1057_fu_38745_p0.read()) * sc_bigint<5>(mul_ln1118_1057_fu_38745_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1058_fu_38775_p0() {
    mul_ln1118_1058_fu_38775_p0 =  (sc_lv<12>) (sext_ln1116_58_cast_fu_23007_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1058_fu_38775_p1() {
    mul_ln1118_1058_fu_38775_p1 = tmp_1058_fu_38761_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1058_fu_38775_p2() {
    mul_ln1118_1058_fu_38775_p2 = (!mul_ln1118_1058_fu_38775_p0.read().is_01() || !mul_ln1118_1058_fu_38775_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1058_fu_38775_p0.read()) * sc_bigint<5>(mul_ln1118_1058_fu_38775_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1059_fu_73411_p0() {
    mul_ln1118_1059_fu_73411_p0 =  (sc_lv<12>) (sext_ln1116_59_cast_fu_53363_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1059_fu_73411_p1() {
    mul_ln1118_1059_fu_73411_p1 = tmp_1059_reg_101852.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1059_fu_73411_p2() {
    mul_ln1118_1059_fu_73411_p2 = (!mul_ln1118_1059_fu_73411_p0.read().is_01() || !mul_ln1118_1059_fu_73411_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1059_fu_73411_p0.read()) * sc_bigint<5>(mul_ln1118_1059_fu_73411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_105_fu_24085_p0() {
    mul_ln1118_105_fu_24085_p0 =  (sc_lv<12>) (sext_ln1116_105_cast_fu_24077_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_105_fu_24085_p1() {
    mul_ln1118_105_fu_24085_p1 = tmp_105_fu_24067_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_105_fu_24085_p2() {
    mul_ln1118_105_fu_24085_p2 = (!mul_ln1118_105_fu_24085_p0.read().is_01() || !mul_ln1118_105_fu_24085_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_105_fu_24085_p0.read()) * sc_bigint<5>(mul_ln1118_105_fu_24085_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1060_fu_73430_p0() {
    mul_ln1118_1060_fu_73430_p0 =  (sc_lv<12>) (sext_ln1116_60_cast_fu_53385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1060_fu_73430_p1() {
    mul_ln1118_1060_fu_73430_p1 = tmp_1060_reg_101857.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1060_fu_73430_p2() {
    mul_ln1118_1060_fu_73430_p2 = (!mul_ln1118_1060_fu_73430_p0.read().is_01() || !mul_ln1118_1060_fu_73430_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1060_fu_73430_p0.read()) * sc_bigint<5>(mul_ln1118_1060_fu_73430_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1061_fu_73449_p0() {
    mul_ln1118_1061_fu_73449_p0 =  (sc_lv<12>) (sext_ln1116_61_cast_fu_53407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1061_fu_73449_p1() {
    mul_ln1118_1061_fu_73449_p1 = tmp_1061_reg_101862.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1061_fu_73449_p2() {
    mul_ln1118_1061_fu_73449_p2 = (!mul_ln1118_1061_fu_73449_p0.read().is_01() || !mul_ln1118_1061_fu_73449_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1061_fu_73449_p0.read()) * sc_bigint<5>(mul_ln1118_1061_fu_73449_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1062_fu_73468_p0() {
    mul_ln1118_1062_fu_73468_p0 =  (sc_lv<12>) (sext_ln1116_62_cast_fu_53429_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1062_fu_73468_p1() {
    mul_ln1118_1062_fu_73468_p1 = tmp_1062_reg_101867.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1062_fu_73468_p2() {
    mul_ln1118_1062_fu_73468_p2 = (!mul_ln1118_1062_fu_73468_p0.read().is_01() || !mul_ln1118_1062_fu_73468_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1062_fu_73468_p0.read()) * sc_bigint<5>(mul_ln1118_1062_fu_73468_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1063_fu_73487_p0() {
    mul_ln1118_1063_fu_73487_p0 =  (sc_lv<12>) (sext_ln1116_63_cast_fu_53451_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1063_fu_73487_p1() {
    mul_ln1118_1063_fu_73487_p1 = tmp_1063_reg_101872.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1063_fu_73487_p2() {
    mul_ln1118_1063_fu_73487_p2 = (!mul_ln1118_1063_fu_73487_p0.read().is_01() || !mul_ln1118_1063_fu_73487_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1063_fu_73487_p0.read()) * sc_bigint<5>(mul_ln1118_1063_fu_73487_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1064_fu_73506_p0() {
    mul_ln1118_1064_fu_73506_p0 =  (sc_lv<12>) (sext_ln1116_64_cast_fu_53473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1064_fu_73506_p1() {
    mul_ln1118_1064_fu_73506_p1 = tmp_1064_reg_101877.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1064_fu_73506_p2() {
    mul_ln1118_1064_fu_73506_p2 = (!mul_ln1118_1064_fu_73506_p0.read().is_01() || !mul_ln1118_1064_fu_73506_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1064_fu_73506_p0.read()) * sc_bigint<5>(mul_ln1118_1064_fu_73506_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1065_fu_73525_p0() {
    mul_ln1118_1065_fu_73525_p0 =  (sc_lv<12>) (sext_ln1116_65_cast_fu_53495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1065_fu_73525_p1() {
    mul_ln1118_1065_fu_73525_p1 = tmp_1065_reg_101882.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1065_fu_73525_p2() {
    mul_ln1118_1065_fu_73525_p2 = (!mul_ln1118_1065_fu_73525_p0.read().is_01() || !mul_ln1118_1065_fu_73525_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1065_fu_73525_p0.read()) * sc_bigint<5>(mul_ln1118_1065_fu_73525_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1066_fu_73544_p0() {
    mul_ln1118_1066_fu_73544_p0 =  (sc_lv<12>) (sext_ln1116_66_cast_fu_53517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1066_fu_73544_p1() {
    mul_ln1118_1066_fu_73544_p1 = tmp_1066_reg_101887.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1066_fu_73544_p2() {
    mul_ln1118_1066_fu_73544_p2 = (!mul_ln1118_1066_fu_73544_p0.read().is_01() || !mul_ln1118_1066_fu_73544_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1066_fu_73544_p0.read()) * sc_bigint<5>(mul_ln1118_1066_fu_73544_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1067_fu_73563_p0() {
    mul_ln1118_1067_fu_73563_p0 =  (sc_lv<12>) (sext_ln1116_67_cast_fu_53539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1067_fu_73563_p1() {
    mul_ln1118_1067_fu_73563_p1 = tmp_1067_reg_101892.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1067_fu_73563_p2() {
    mul_ln1118_1067_fu_73563_p2 = (!mul_ln1118_1067_fu_73563_p0.read().is_01() || !mul_ln1118_1067_fu_73563_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1067_fu_73563_p0.read()) * sc_bigint<5>(mul_ln1118_1067_fu_73563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1068_fu_73582_p0() {
    mul_ln1118_1068_fu_73582_p0 =  (sc_lv<12>) (sext_ln1116_68_cast_fu_53561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1068_fu_73582_p1() {
    mul_ln1118_1068_fu_73582_p1 = tmp_1068_reg_101897.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1068_fu_73582_p2() {
    mul_ln1118_1068_fu_73582_p2 = (!mul_ln1118_1068_fu_73582_p0.read().is_01() || !mul_ln1118_1068_fu_73582_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1068_fu_73582_p0.read()) * sc_bigint<5>(mul_ln1118_1068_fu_73582_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1069_fu_73601_p0() {
    mul_ln1118_1069_fu_73601_p0 =  (sc_lv<12>) (sext_ln1116_69_cast_fu_53583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1069_fu_73601_p1() {
    mul_ln1118_1069_fu_73601_p1 = tmp_1069_reg_101902.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1069_fu_73601_p2() {
    mul_ln1118_1069_fu_73601_p2 = (!mul_ln1118_1069_fu_73601_p0.read().is_01() || !mul_ln1118_1069_fu_73601_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1069_fu_73601_p0.read()) * sc_bigint<5>(mul_ln1118_1069_fu_73601_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_106_fu_24127_p0() {
    mul_ln1118_106_fu_24127_p0 =  (sc_lv<12>) (sext_ln1116_106_cast_fu_24119_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_106_fu_24127_p1() {
    mul_ln1118_106_fu_24127_p1 = tmp_106_fu_24109_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_106_fu_24127_p2() {
    mul_ln1118_106_fu_24127_p2 = (!mul_ln1118_106_fu_24127_p0.read().is_01() || !mul_ln1118_106_fu_24127_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_106_fu_24127_p0.read()) * sc_bigint<5>(mul_ln1118_106_fu_24127_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1070_fu_73620_p0() {
    mul_ln1118_1070_fu_73620_p0 =  (sc_lv<12>) (sext_ln1116_70_cast_fu_53605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1070_fu_73620_p1() {
    mul_ln1118_1070_fu_73620_p1 = tmp_1070_reg_101907.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1070_fu_73620_p2() {
    mul_ln1118_1070_fu_73620_p2 = (!mul_ln1118_1070_fu_73620_p0.read().is_01() || !mul_ln1118_1070_fu_73620_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1070_fu_73620_p0.read()) * sc_bigint<5>(mul_ln1118_1070_fu_73620_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1071_fu_73639_p0() {
    mul_ln1118_1071_fu_73639_p0 =  (sc_lv<12>) (sext_ln1116_71_cast_fu_53627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1071_fu_73639_p1() {
    mul_ln1118_1071_fu_73639_p1 = tmp_1071_reg_101912.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1071_fu_73639_p2() {
    mul_ln1118_1071_fu_73639_p2 = (!mul_ln1118_1071_fu_73639_p0.read().is_01() || !mul_ln1118_1071_fu_73639_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1071_fu_73639_p0.read()) * sc_bigint<5>(mul_ln1118_1071_fu_73639_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1072_fu_73658_p0() {
    mul_ln1118_1072_fu_73658_p0 =  (sc_lv<12>) (sext_ln1116_72_cast_fu_53649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1072_fu_73658_p1() {
    mul_ln1118_1072_fu_73658_p1 = tmp_1072_reg_101917.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1072_fu_73658_p2() {
    mul_ln1118_1072_fu_73658_p2 = (!mul_ln1118_1072_fu_73658_p0.read().is_01() || !mul_ln1118_1072_fu_73658_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1072_fu_73658_p0.read()) * sc_bigint<5>(mul_ln1118_1072_fu_73658_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1073_fu_73677_p0() {
    mul_ln1118_1073_fu_73677_p0 =  (sc_lv<12>) (sext_ln1116_73_cast_fu_53671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1073_fu_73677_p1() {
    mul_ln1118_1073_fu_73677_p1 = tmp_1073_reg_101922.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1073_fu_73677_p2() {
    mul_ln1118_1073_fu_73677_p2 = (!mul_ln1118_1073_fu_73677_p0.read().is_01() || !mul_ln1118_1073_fu_73677_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1073_fu_73677_p0.read()) * sc_bigint<5>(mul_ln1118_1073_fu_73677_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1074_fu_73696_p0() {
    mul_ln1118_1074_fu_73696_p0 =  (sc_lv<12>) (sext_ln1116_74_cast_fu_53693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1074_fu_73696_p1() {
    mul_ln1118_1074_fu_73696_p1 = tmp_1074_reg_101927.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1074_fu_73696_p2() {
    mul_ln1118_1074_fu_73696_p2 = (!mul_ln1118_1074_fu_73696_p0.read().is_01() || !mul_ln1118_1074_fu_73696_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1074_fu_73696_p0.read()) * sc_bigint<5>(mul_ln1118_1074_fu_73696_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1075_fu_73715_p0() {
    mul_ln1118_1075_fu_73715_p0 =  (sc_lv<12>) (sext_ln1116_75_cast_fu_53715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1075_fu_73715_p1() {
    mul_ln1118_1075_fu_73715_p1 = tmp_1075_reg_101932.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1075_fu_73715_p2() {
    mul_ln1118_1075_fu_73715_p2 = (!mul_ln1118_1075_fu_73715_p0.read().is_01() || !mul_ln1118_1075_fu_73715_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1075_fu_73715_p0.read()) * sc_bigint<5>(mul_ln1118_1075_fu_73715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1076_fu_73734_p0() {
    mul_ln1118_1076_fu_73734_p0 =  (sc_lv<12>) (sext_ln1116_76_cast_fu_53737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1076_fu_73734_p1() {
    mul_ln1118_1076_fu_73734_p1 = tmp_1076_reg_101937.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1076_fu_73734_p2() {
    mul_ln1118_1076_fu_73734_p2 = (!mul_ln1118_1076_fu_73734_p0.read().is_01() || !mul_ln1118_1076_fu_73734_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1076_fu_73734_p0.read()) * sc_bigint<5>(mul_ln1118_1076_fu_73734_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1077_fu_73753_p0() {
    mul_ln1118_1077_fu_73753_p0 =  (sc_lv<12>) (sext_ln1116_77_cast_reg_96378.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1077_fu_73753_p1() {
    mul_ln1118_1077_fu_73753_p1 = tmp_1077_reg_101942.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1077_fu_73753_p2() {
    mul_ln1118_1077_fu_73753_p2 = (!mul_ln1118_1077_fu_73753_p0.read().is_01() || !mul_ln1118_1077_fu_73753_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1077_fu_73753_p0.read()) * sc_bigint<5>(mul_ln1118_1077_fu_73753_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1078_fu_38995_p0() {
    mul_ln1118_1078_fu_38995_p0 =  (sc_lv<12>) (sext_ln1116_78_cast_fu_23395_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1078_fu_38995_p1() {
    mul_ln1118_1078_fu_38995_p1 = tmp_1078_fu_38981_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1078_fu_38995_p2() {
    mul_ln1118_1078_fu_38995_p2 = (!mul_ln1118_1078_fu_38995_p0.read().is_01() || !mul_ln1118_1078_fu_38995_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1078_fu_38995_p0.read()) * sc_bigint<5>(mul_ln1118_1078_fu_38995_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1079_fu_39025_p0() {
    mul_ln1118_1079_fu_39025_p0 =  (sc_lv<12>) (sext_ln1116_79_cast_fu_23437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1079_fu_39025_p1() {
    mul_ln1118_1079_fu_39025_p1 = tmp_1079_fu_39011_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1079_fu_39025_p2() {
    mul_ln1118_1079_fu_39025_p2 = (!mul_ln1118_1079_fu_39025_p0.read().is_01() || !mul_ln1118_1079_fu_39025_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1079_fu_39025_p0.read()) * sc_bigint<5>(mul_ln1118_1079_fu_39025_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_107_fu_24169_p0() {
    mul_ln1118_107_fu_24169_p0 =  (sc_lv<12>) (sext_ln1116_107_cast_fu_24161_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_107_fu_24169_p1() {
    mul_ln1118_107_fu_24169_p1 = tmp_107_fu_24151_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_107_fu_24169_p2() {
    mul_ln1118_107_fu_24169_p2 = (!mul_ln1118_107_fu_24169_p0.read().is_01() || !mul_ln1118_107_fu_24169_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_107_fu_24169_p0.read()) * sc_bigint<5>(mul_ln1118_107_fu_24169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1080_fu_39055_p0() {
    mul_ln1118_1080_fu_39055_p0 =  (sc_lv<12>) (sext_ln1116_80_cast_fu_23479_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1080_fu_39055_p1() {
    mul_ln1118_1080_fu_39055_p1 = tmp_1080_fu_39041_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1080_fu_39055_p2() {
    mul_ln1118_1080_fu_39055_p2 = (!mul_ln1118_1080_fu_39055_p0.read().is_01() || !mul_ln1118_1080_fu_39055_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1080_fu_39055_p0.read()) * sc_bigint<5>(mul_ln1118_1080_fu_39055_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1081_fu_39085_p0() {
    mul_ln1118_1081_fu_39085_p0 =  (sc_lv<12>) (sext_ln1116_81_cast_fu_23521_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1081_fu_39085_p1() {
    mul_ln1118_1081_fu_39085_p1 = tmp_1081_fu_39071_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1081_fu_39085_p2() {
    mul_ln1118_1081_fu_39085_p2 = (!mul_ln1118_1081_fu_39085_p0.read().is_01() || !mul_ln1118_1081_fu_39085_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1081_fu_39085_p0.read()) * sc_bigint<5>(mul_ln1118_1081_fu_39085_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1082_fu_39115_p0() {
    mul_ln1118_1082_fu_39115_p0 =  (sc_lv<12>) (sext_ln1116_82_cast_fu_23563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1082_fu_39115_p1() {
    mul_ln1118_1082_fu_39115_p1 = tmp_1082_fu_39101_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1082_fu_39115_p2() {
    mul_ln1118_1082_fu_39115_p2 = (!mul_ln1118_1082_fu_39115_p0.read().is_01() || !mul_ln1118_1082_fu_39115_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1082_fu_39115_p0.read()) * sc_bigint<5>(mul_ln1118_1082_fu_39115_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1083_fu_39145_p0() {
    mul_ln1118_1083_fu_39145_p0 =  (sc_lv<12>) (sext_ln1116_83_cast_fu_23605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1083_fu_39145_p1() {
    mul_ln1118_1083_fu_39145_p1 = tmp_1083_fu_39131_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1083_fu_39145_p2() {
    mul_ln1118_1083_fu_39145_p2 = (!mul_ln1118_1083_fu_39145_p0.read().is_01() || !mul_ln1118_1083_fu_39145_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1083_fu_39145_p0.read()) * sc_bigint<5>(mul_ln1118_1083_fu_39145_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1084_fu_73771_p0() {
    mul_ln1118_1084_fu_73771_p0 =  (sc_lv<12>) (sext_ln1116_84_cast_fu_53777_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1084_fu_73771_p1() {
    mul_ln1118_1084_fu_73771_p1 = tmp_1084_reg_101977.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1084_fu_73771_p2() {
    mul_ln1118_1084_fu_73771_p2 = (!mul_ln1118_1084_fu_73771_p0.read().is_01() || !mul_ln1118_1084_fu_73771_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1084_fu_73771_p0.read()) * sc_bigint<5>(mul_ln1118_1084_fu_73771_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1085_fu_73790_p0() {
    mul_ln1118_1085_fu_73790_p0 =  (sc_lv<12>) (sext_ln1116_85_cast_fu_53799_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1085_fu_73790_p1() {
    mul_ln1118_1085_fu_73790_p1 = tmp_1085_reg_101982.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1085_fu_73790_p2() {
    mul_ln1118_1085_fu_73790_p2 = (!mul_ln1118_1085_fu_73790_p0.read().is_01() || !mul_ln1118_1085_fu_73790_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1085_fu_73790_p0.read()) * sc_bigint<5>(mul_ln1118_1085_fu_73790_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1086_fu_73809_p0() {
    mul_ln1118_1086_fu_73809_p0 =  (sc_lv<12>) (sext_ln1116_86_cast_fu_53821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1086_fu_73809_p1() {
    mul_ln1118_1086_fu_73809_p1 = tmp_1086_reg_101987.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1086_fu_73809_p2() {
    mul_ln1118_1086_fu_73809_p2 = (!mul_ln1118_1086_fu_73809_p0.read().is_01() || !mul_ln1118_1086_fu_73809_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1086_fu_73809_p0.read()) * sc_bigint<5>(mul_ln1118_1086_fu_73809_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1087_fu_73828_p0() {
    mul_ln1118_1087_fu_73828_p0 =  (sc_lv<12>) (sext_ln1116_87_cast_fu_53843_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1087_fu_73828_p1() {
    mul_ln1118_1087_fu_73828_p1 = tmp_1087_reg_101992.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1087_fu_73828_p2() {
    mul_ln1118_1087_fu_73828_p2 = (!mul_ln1118_1087_fu_73828_p0.read().is_01() || !mul_ln1118_1087_fu_73828_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1087_fu_73828_p0.read()) * sc_bigint<5>(mul_ln1118_1087_fu_73828_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1088_fu_73847_p0() {
    mul_ln1118_1088_fu_73847_p0 =  (sc_lv<12>) (sext_ln1116_88_cast_fu_53865_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1088_fu_73847_p1() {
    mul_ln1118_1088_fu_73847_p1 = tmp_1088_reg_101997.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1088_fu_73847_p2() {
    mul_ln1118_1088_fu_73847_p2 = (!mul_ln1118_1088_fu_73847_p0.read().is_01() || !mul_ln1118_1088_fu_73847_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1088_fu_73847_p0.read()) * sc_bigint<5>(mul_ln1118_1088_fu_73847_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1089_fu_73866_p0() {
    mul_ln1118_1089_fu_73866_p0 =  (sc_lv<12>) (sext_ln1116_89_cast_fu_53887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1089_fu_73866_p1() {
    mul_ln1118_1089_fu_73866_p1 = tmp_1089_reg_102002.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1089_fu_73866_p2() {
    mul_ln1118_1089_fu_73866_p2 = (!mul_ln1118_1089_fu_73866_p0.read().is_01() || !mul_ln1118_1089_fu_73866_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1089_fu_73866_p0.read()) * sc_bigint<5>(mul_ln1118_1089_fu_73866_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_108_fu_24211_p0() {
    mul_ln1118_108_fu_24211_p0 =  (sc_lv<12>) (sext_ln1116_108_cast_fu_24203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_108_fu_24211_p1() {
    mul_ln1118_108_fu_24211_p1 = tmp_108_fu_24193_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_108_fu_24211_p2() {
    mul_ln1118_108_fu_24211_p2 = (!mul_ln1118_108_fu_24211_p0.read().is_01() || !mul_ln1118_108_fu_24211_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_108_fu_24211_p0.read()) * sc_bigint<5>(mul_ln1118_108_fu_24211_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1090_fu_73885_p0() {
    mul_ln1118_1090_fu_73885_p0 =  (sc_lv<12>) (sext_ln1116_90_cast_fu_53909_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1090_fu_73885_p1() {
    mul_ln1118_1090_fu_73885_p1 = tmp_1090_reg_102007.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1090_fu_73885_p2() {
    mul_ln1118_1090_fu_73885_p2 = (!mul_ln1118_1090_fu_73885_p0.read().is_01() || !mul_ln1118_1090_fu_73885_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1090_fu_73885_p0.read()) * sc_bigint<5>(mul_ln1118_1090_fu_73885_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1091_fu_73904_p0() {
    mul_ln1118_1091_fu_73904_p0 =  (sc_lv<12>) (sext_ln1116_91_cast_fu_53931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1091_fu_73904_p1() {
    mul_ln1118_1091_fu_73904_p1 = tmp_1091_reg_102012.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1091_fu_73904_p2() {
    mul_ln1118_1091_fu_73904_p2 = (!mul_ln1118_1091_fu_73904_p0.read().is_01() || !mul_ln1118_1091_fu_73904_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1091_fu_73904_p0.read()) * sc_bigint<5>(mul_ln1118_1091_fu_73904_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1092_fu_73923_p0() {
    mul_ln1118_1092_fu_73923_p0 =  (sc_lv<12>) (sext_ln1116_92_cast_fu_53953_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1092_fu_73923_p1() {
    mul_ln1118_1092_fu_73923_p1 = tmp_1092_reg_102017.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1092_fu_73923_p2() {
    mul_ln1118_1092_fu_73923_p2 = (!mul_ln1118_1092_fu_73923_p0.read().is_01() || !mul_ln1118_1092_fu_73923_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1092_fu_73923_p0.read()) * sc_bigint<5>(mul_ln1118_1092_fu_73923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1093_fu_73942_p0() {
    mul_ln1118_1093_fu_73942_p0 =  (sc_lv<12>) (sext_ln1116_93_cast_fu_53975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1093_fu_73942_p1() {
    mul_ln1118_1093_fu_73942_p1 = tmp_1093_reg_102022.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1093_fu_73942_p2() {
    mul_ln1118_1093_fu_73942_p2 = (!mul_ln1118_1093_fu_73942_p0.read().is_01() || !mul_ln1118_1093_fu_73942_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1093_fu_73942_p0.read()) * sc_bigint<5>(mul_ln1118_1093_fu_73942_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1094_fu_73961_p0() {
    mul_ln1118_1094_fu_73961_p0 =  (sc_lv<12>) (sext_ln1116_94_cast_fu_53997_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1094_fu_73961_p1() {
    mul_ln1118_1094_fu_73961_p1 = tmp_1094_reg_102027.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1094_fu_73961_p2() {
    mul_ln1118_1094_fu_73961_p2 = (!mul_ln1118_1094_fu_73961_p0.read().is_01() || !mul_ln1118_1094_fu_73961_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1094_fu_73961_p0.read()) * sc_bigint<5>(mul_ln1118_1094_fu_73961_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1095_fu_73980_p0() {
    mul_ln1118_1095_fu_73980_p0 =  (sc_lv<12>) (sext_ln1116_95_cast_fu_54019_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1095_fu_73980_p1() {
    mul_ln1118_1095_fu_73980_p1 = tmp_1095_reg_102032.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1095_fu_73980_p2() {
    mul_ln1118_1095_fu_73980_p2 = (!mul_ln1118_1095_fu_73980_p0.read().is_01() || !mul_ln1118_1095_fu_73980_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1095_fu_73980_p0.read()) * sc_bigint<5>(mul_ln1118_1095_fu_73980_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1096_fu_73999_p0() {
    mul_ln1118_1096_fu_73999_p0 =  (sc_lv<12>) (sext_ln1116_96_cast_fu_54041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1096_fu_73999_p1() {
    mul_ln1118_1096_fu_73999_p1 = tmp_1096_reg_102037.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1096_fu_73999_p2() {
    mul_ln1118_1096_fu_73999_p2 = (!mul_ln1118_1096_fu_73999_p0.read().is_01() || !mul_ln1118_1096_fu_73999_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1096_fu_73999_p0.read()) * sc_bigint<5>(mul_ln1118_1096_fu_73999_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1097_fu_74018_p0() {
    mul_ln1118_1097_fu_74018_p0 =  (sc_lv<12>) (sext_ln1116_97_cast_fu_54063_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1097_fu_74018_p1() {
    mul_ln1118_1097_fu_74018_p1 = tmp_1097_reg_102042.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1097_fu_74018_p2() {
    mul_ln1118_1097_fu_74018_p2 = (!mul_ln1118_1097_fu_74018_p0.read().is_01() || !mul_ln1118_1097_fu_74018_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1097_fu_74018_p0.read()) * sc_bigint<5>(mul_ln1118_1097_fu_74018_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1098_fu_74037_p0() {
    mul_ln1118_1098_fu_74037_p0 =  (sc_lv<12>) (sext_ln1116_98_cast_fu_54085_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1098_fu_74037_p1() {
    mul_ln1118_1098_fu_74037_p1 = tmp_1098_reg_102047.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1098_fu_74037_p2() {
    mul_ln1118_1098_fu_74037_p2 = (!mul_ln1118_1098_fu_74037_p0.read().is_01() || !mul_ln1118_1098_fu_74037_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1098_fu_74037_p0.read()) * sc_bigint<5>(mul_ln1118_1098_fu_74037_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1099_fu_74056_p0() {
    mul_ln1118_1099_fu_74056_p0 =  (sc_lv<12>) (sext_ln1116_99_cast_fu_54107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1099_fu_74056_p1() {
    mul_ln1118_1099_fu_74056_p1 = tmp_1099_reg_102052.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1099_fu_74056_p2() {
    mul_ln1118_1099_fu_74056_p2 = (!mul_ln1118_1099_fu_74056_p0.read().is_01() || !mul_ln1118_1099_fu_74056_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1099_fu_74056_p0.read()) * sc_bigint<5>(mul_ln1118_1099_fu_74056_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_109_fu_54197_p0() {
    mul_ln1118_109_fu_54197_p0 =  (sc_lv<12>) (sext_ln1116_109_cast_fu_54191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_109_fu_54197_p1() {
    mul_ln1118_109_fu_54197_p1 = tmp_109_reg_96654.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_109_fu_54197_p2() {
    mul_ln1118_109_fu_54197_p2 = (!mul_ln1118_109_fu_54197_p0.read().is_01() || !mul_ln1118_109_fu_54197_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_109_fu_54197_p0.read()) * sc_bigint<5>(mul_ln1118_109_fu_54197_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_10_fu_52559_p0() {
    mul_ln1118_10_fu_52559_p0 =  (sc_lv<12>) (sext_ln1116_10_cast_fu_52553_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_10_fu_52559_p1() {
    mul_ln1118_10_fu_52559_p1 = tmp_11_reg_95760.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_10_fu_52559_p2() {
    mul_ln1118_10_fu_52559_p2 = (!mul_ln1118_10_fu_52559_p0.read().is_01() || !mul_ln1118_10_fu_52559_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_10_fu_52559_p0.read()) * sc_bigint<5>(mul_ln1118_10_fu_52559_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1100_fu_74075_p0() {
    mul_ln1118_1100_fu_74075_p0 =  (sc_lv<12>) (sext_ln1116_100_cast_fu_54129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1100_fu_74075_p1() {
    mul_ln1118_1100_fu_74075_p1 = tmp_1100_reg_102057.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1100_fu_74075_p2() {
    mul_ln1118_1100_fu_74075_p2 = (!mul_ln1118_1100_fu_74075_p0.read().is_01() || !mul_ln1118_1100_fu_74075_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1100_fu_74075_p0.read()) * sc_bigint<5>(mul_ln1118_1100_fu_74075_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1101_fu_74094_p0() {
    mul_ln1118_1101_fu_74094_p0 =  (sc_lv<12>) (sext_ln1116_101_cast_fu_54151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1101_fu_74094_p1() {
    mul_ln1118_1101_fu_74094_p1 = tmp_1101_reg_102062.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1101_fu_74094_p2() {
    mul_ln1118_1101_fu_74094_p2 = (!mul_ln1118_1101_fu_74094_p0.read().is_01() || !mul_ln1118_1101_fu_74094_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1101_fu_74094_p0.read()) * sc_bigint<5>(mul_ln1118_1101_fu_74094_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1102_fu_74113_p0() {
    mul_ln1118_1102_fu_74113_p0 =  (sc_lv<12>) (sext_ln1116_102_cast_reg_96606.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1102_fu_74113_p1() {
    mul_ln1118_1102_fu_74113_p1 = tmp_1102_reg_102067.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1102_fu_74113_p2() {
    mul_ln1118_1102_fu_74113_p2 = (!mul_ln1118_1102_fu_74113_p0.read().is_01() || !mul_ln1118_1102_fu_74113_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1102_fu_74113_p0.read()) * sc_bigint<5>(mul_ln1118_1102_fu_74113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1103_fu_39365_p0() {
    mul_ln1118_1103_fu_39365_p0 =  (sc_lv<12>) (sext_ln1116_103_cast_fu_23993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1103_fu_39365_p1() {
    mul_ln1118_1103_fu_39365_p1 = tmp_1103_fu_39351_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1103_fu_39365_p2() {
    mul_ln1118_1103_fu_39365_p2 = (!mul_ln1118_1103_fu_39365_p0.read().is_01() || !mul_ln1118_1103_fu_39365_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1103_fu_39365_p0.read()) * sc_bigint<5>(mul_ln1118_1103_fu_39365_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1104_fu_39395_p0() {
    mul_ln1118_1104_fu_39395_p0 =  (sc_lv<12>) (sext_ln1116_104_cast_fu_24035_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1104_fu_39395_p1() {
    mul_ln1118_1104_fu_39395_p1 = tmp_1104_fu_39381_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1104_fu_39395_p2() {
    mul_ln1118_1104_fu_39395_p2 = (!mul_ln1118_1104_fu_39395_p0.read().is_01() || !mul_ln1118_1104_fu_39395_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1104_fu_39395_p0.read()) * sc_bigint<5>(mul_ln1118_1104_fu_39395_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1105_fu_39425_p0() {
    mul_ln1118_1105_fu_39425_p0 =  (sc_lv<12>) (sext_ln1116_105_cast_fu_24077_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1105_fu_39425_p1() {
    mul_ln1118_1105_fu_39425_p1 = tmp_1105_fu_39411_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1105_fu_39425_p2() {
    mul_ln1118_1105_fu_39425_p2 = (!mul_ln1118_1105_fu_39425_p0.read().is_01() || !mul_ln1118_1105_fu_39425_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1105_fu_39425_p0.read()) * sc_bigint<5>(mul_ln1118_1105_fu_39425_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1106_fu_39455_p0() {
    mul_ln1118_1106_fu_39455_p0 =  (sc_lv<12>) (sext_ln1116_106_cast_fu_24119_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1106_fu_39455_p1() {
    mul_ln1118_1106_fu_39455_p1 = tmp_1106_fu_39441_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1106_fu_39455_p2() {
    mul_ln1118_1106_fu_39455_p2 = (!mul_ln1118_1106_fu_39455_p0.read().is_01() || !mul_ln1118_1106_fu_39455_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1106_fu_39455_p0.read()) * sc_bigint<5>(mul_ln1118_1106_fu_39455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1107_fu_39485_p0() {
    mul_ln1118_1107_fu_39485_p0 =  (sc_lv<12>) (sext_ln1116_107_cast_fu_24161_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1107_fu_39485_p1() {
    mul_ln1118_1107_fu_39485_p1 = tmp_1107_fu_39471_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1107_fu_39485_p2() {
    mul_ln1118_1107_fu_39485_p2 = (!mul_ln1118_1107_fu_39485_p0.read().is_01() || !mul_ln1118_1107_fu_39485_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1107_fu_39485_p0.read()) * sc_bigint<5>(mul_ln1118_1107_fu_39485_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1108_fu_39515_p0() {
    mul_ln1118_1108_fu_39515_p0 =  (sc_lv<12>) (sext_ln1116_108_cast_fu_24203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1108_fu_39515_p1() {
    mul_ln1118_1108_fu_39515_p1 = tmp_1108_fu_39501_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1108_fu_39515_p2() {
    mul_ln1118_1108_fu_39515_p2 = (!mul_ln1118_1108_fu_39515_p0.read().is_01() || !mul_ln1118_1108_fu_39515_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1108_fu_39515_p0.read()) * sc_bigint<5>(mul_ln1118_1108_fu_39515_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1109_fu_74131_p0() {
    mul_ln1118_1109_fu_74131_p0 =  (sc_lv<12>) (sext_ln1116_109_cast_fu_54191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1109_fu_74131_p1() {
    mul_ln1118_1109_fu_74131_p1 = tmp_1109_reg_102102.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1109_fu_74131_p2() {
    mul_ln1118_1109_fu_74131_p2 = (!mul_ln1118_1109_fu_74131_p0.read().is_01() || !mul_ln1118_1109_fu_74131_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1109_fu_74131_p0.read()) * sc_bigint<5>(mul_ln1118_1109_fu_74131_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_110_fu_54219_p0() {
    mul_ln1118_110_fu_54219_p0 =  (sc_lv<12>) (sext_ln1116_110_cast_fu_54213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_110_fu_54219_p1() {
    mul_ln1118_110_fu_54219_p1 = tmp_110_reg_96664.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_110_fu_54219_p2() {
    mul_ln1118_110_fu_54219_p2 = (!mul_ln1118_110_fu_54219_p0.read().is_01() || !mul_ln1118_110_fu_54219_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_110_fu_54219_p0.read()) * sc_bigint<5>(mul_ln1118_110_fu_54219_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1110_fu_74150_p0() {
    mul_ln1118_1110_fu_74150_p0 =  (sc_lv<12>) (sext_ln1116_110_cast_fu_54213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1110_fu_74150_p1() {
    mul_ln1118_1110_fu_74150_p1 = tmp_1110_reg_102107.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1110_fu_74150_p2() {
    mul_ln1118_1110_fu_74150_p2 = (!mul_ln1118_1110_fu_74150_p0.read().is_01() || !mul_ln1118_1110_fu_74150_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1110_fu_74150_p0.read()) * sc_bigint<5>(mul_ln1118_1110_fu_74150_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1111_fu_74169_p0() {
    mul_ln1118_1111_fu_74169_p0 =  (sc_lv<12>) (sext_ln1116_111_cast_fu_54235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1111_fu_74169_p1() {
    mul_ln1118_1111_fu_74169_p1 = tmp_1111_reg_102112.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1111_fu_74169_p2() {
    mul_ln1118_1111_fu_74169_p2 = (!mul_ln1118_1111_fu_74169_p0.read().is_01() || !mul_ln1118_1111_fu_74169_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1111_fu_74169_p0.read()) * sc_bigint<5>(mul_ln1118_1111_fu_74169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1112_fu_74188_p0() {
    mul_ln1118_1112_fu_74188_p0 =  (sc_lv<12>) (sext_ln1116_112_cast_fu_54257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1112_fu_74188_p1() {
    mul_ln1118_1112_fu_74188_p1 = tmp_1112_reg_102117.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1112_fu_74188_p2() {
    mul_ln1118_1112_fu_74188_p2 = (!mul_ln1118_1112_fu_74188_p0.read().is_01() || !mul_ln1118_1112_fu_74188_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1112_fu_74188_p0.read()) * sc_bigint<5>(mul_ln1118_1112_fu_74188_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1113_fu_74207_p0() {
    mul_ln1118_1113_fu_74207_p0 =  (sc_lv<12>) (sext_ln1116_113_cast_fu_54279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1113_fu_74207_p1() {
    mul_ln1118_1113_fu_74207_p1 = tmp_1113_reg_102122.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1113_fu_74207_p2() {
    mul_ln1118_1113_fu_74207_p2 = (!mul_ln1118_1113_fu_74207_p0.read().is_01() || !mul_ln1118_1113_fu_74207_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1113_fu_74207_p0.read()) * sc_bigint<5>(mul_ln1118_1113_fu_74207_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1114_fu_74226_p0() {
    mul_ln1118_1114_fu_74226_p0 =  (sc_lv<12>) (sext_ln1116_114_cast_fu_54301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1114_fu_74226_p1() {
    mul_ln1118_1114_fu_74226_p1 = tmp_1114_reg_102127.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1114_fu_74226_p2() {
    mul_ln1118_1114_fu_74226_p2 = (!mul_ln1118_1114_fu_74226_p0.read().is_01() || !mul_ln1118_1114_fu_74226_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1114_fu_74226_p0.read()) * sc_bigint<5>(mul_ln1118_1114_fu_74226_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1115_fu_74245_p0() {
    mul_ln1118_1115_fu_74245_p0 =  (sc_lv<12>) (sext_ln1116_115_cast_fu_54323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1115_fu_74245_p1() {
    mul_ln1118_1115_fu_74245_p1 = tmp_1115_reg_102132.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1115_fu_74245_p2() {
    mul_ln1118_1115_fu_74245_p2 = (!mul_ln1118_1115_fu_74245_p0.read().is_01() || !mul_ln1118_1115_fu_74245_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1115_fu_74245_p0.read()) * sc_bigint<5>(mul_ln1118_1115_fu_74245_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1116_fu_74264_p0() {
    mul_ln1118_1116_fu_74264_p0 =  (sc_lv<12>) (sext_ln1116_116_cast_fu_54345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1116_fu_74264_p1() {
    mul_ln1118_1116_fu_74264_p1 = tmp_1116_reg_102137.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1116_fu_74264_p2() {
    mul_ln1118_1116_fu_74264_p2 = (!mul_ln1118_1116_fu_74264_p0.read().is_01() || !mul_ln1118_1116_fu_74264_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1116_fu_74264_p0.read()) * sc_bigint<5>(mul_ln1118_1116_fu_74264_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1117_fu_74283_p0() {
    mul_ln1118_1117_fu_74283_p0 =  (sc_lv<12>) (sext_ln1116_117_cast_fu_54367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1117_fu_74283_p1() {
    mul_ln1118_1117_fu_74283_p1 = tmp_1117_reg_102142.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1117_fu_74283_p2() {
    mul_ln1118_1117_fu_74283_p2 = (!mul_ln1118_1117_fu_74283_p0.read().is_01() || !mul_ln1118_1117_fu_74283_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1117_fu_74283_p0.read()) * sc_bigint<5>(mul_ln1118_1117_fu_74283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1118_fu_74302_p0() {
    mul_ln1118_1118_fu_74302_p0 =  (sc_lv<12>) (sext_ln1116_118_cast_fu_54389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1118_fu_74302_p1() {
    mul_ln1118_1118_fu_74302_p1 = tmp_1118_reg_102147.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1118_fu_74302_p2() {
    mul_ln1118_1118_fu_74302_p2 = (!mul_ln1118_1118_fu_74302_p0.read().is_01() || !mul_ln1118_1118_fu_74302_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1118_fu_74302_p0.read()) * sc_bigint<5>(mul_ln1118_1118_fu_74302_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1119_fu_74321_p0() {
    mul_ln1118_1119_fu_74321_p0 =  (sc_lv<12>) (sext_ln1116_119_cast_fu_54411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1119_fu_74321_p1() {
    mul_ln1118_1119_fu_74321_p1 = tmp_1119_reg_102152.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1119_fu_74321_p2() {
    mul_ln1118_1119_fu_74321_p2 = (!mul_ln1118_1119_fu_74321_p0.read().is_01() || !mul_ln1118_1119_fu_74321_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1119_fu_74321_p0.read()) * sc_bigint<5>(mul_ln1118_1119_fu_74321_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_111_fu_54241_p0() {
    mul_ln1118_111_fu_54241_p0 =  (sc_lv<12>) (sext_ln1116_111_cast_fu_54235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_111_fu_54241_p1() {
    mul_ln1118_111_fu_54241_p1 = tmp_111_reg_96674.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_111_fu_54241_p2() {
    mul_ln1118_111_fu_54241_p2 = (!mul_ln1118_111_fu_54241_p0.read().is_01() || !mul_ln1118_111_fu_54241_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_111_fu_54241_p0.read()) * sc_bigint<5>(mul_ln1118_111_fu_54241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1120_fu_74340_p0() {
    mul_ln1118_1120_fu_74340_p0 =  (sc_lv<12>) (sext_ln1116_120_cast_fu_54433_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1120_fu_74340_p1() {
    mul_ln1118_1120_fu_74340_p1 = tmp_1120_reg_102157.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1120_fu_74340_p2() {
    mul_ln1118_1120_fu_74340_p2 = (!mul_ln1118_1120_fu_74340_p0.read().is_01() || !mul_ln1118_1120_fu_74340_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1120_fu_74340_p0.read()) * sc_bigint<5>(mul_ln1118_1120_fu_74340_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1121_fu_74359_p0() {
    mul_ln1118_1121_fu_74359_p0 =  (sc_lv<12>) (sext_ln1116_121_cast_fu_54455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1121_fu_74359_p1() {
    mul_ln1118_1121_fu_74359_p1 = tmp_1121_reg_102162.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1121_fu_74359_p2() {
    mul_ln1118_1121_fu_74359_p2 = (!mul_ln1118_1121_fu_74359_p0.read().is_01() || !mul_ln1118_1121_fu_74359_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1121_fu_74359_p0.read()) * sc_bigint<5>(mul_ln1118_1121_fu_74359_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1122_fu_74378_p0() {
    mul_ln1118_1122_fu_74378_p0 =  (sc_lv<12>) (sext_ln1116_122_cast_fu_54477_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1122_fu_74378_p1() {
    mul_ln1118_1122_fu_74378_p1 = tmp_1122_reg_102167.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1122_fu_74378_p2() {
    mul_ln1118_1122_fu_74378_p2 = (!mul_ln1118_1122_fu_74378_p0.read().is_01() || !mul_ln1118_1122_fu_74378_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1122_fu_74378_p0.read()) * sc_bigint<5>(mul_ln1118_1122_fu_74378_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1123_fu_74397_p0() {
    mul_ln1118_1123_fu_74397_p0 =  (sc_lv<12>) (sext_ln1116_123_cast_fu_54499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1123_fu_74397_p1() {
    mul_ln1118_1123_fu_74397_p1 = tmp_1123_reg_102172.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1123_fu_74397_p2() {
    mul_ln1118_1123_fu_74397_p2 = (!mul_ln1118_1123_fu_74397_p0.read().is_01() || !mul_ln1118_1123_fu_74397_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1123_fu_74397_p0.read()) * sc_bigint<5>(mul_ln1118_1123_fu_74397_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1124_fu_74416_p0() {
    mul_ln1118_1124_fu_74416_p0 =  (sc_lv<12>) (sext_ln1116_124_cast_fu_54521_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1124_fu_74416_p1() {
    mul_ln1118_1124_fu_74416_p1 = tmp_1124_reg_102177.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1124_fu_74416_p2() {
    mul_ln1118_1124_fu_74416_p2 = (!mul_ln1118_1124_fu_74416_p0.read().is_01() || !mul_ln1118_1124_fu_74416_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1124_fu_74416_p0.read()) * sc_bigint<5>(mul_ln1118_1124_fu_74416_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1125_fu_74435_p0() {
    mul_ln1118_1125_fu_74435_p0 =  (sc_lv<12>) (sext_ln1116_125_cast_fu_54543_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1125_fu_74435_p1() {
    mul_ln1118_1125_fu_74435_p1 = tmp_1125_reg_102182.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1125_fu_74435_p2() {
    mul_ln1118_1125_fu_74435_p2 = (!mul_ln1118_1125_fu_74435_p0.read().is_01() || !mul_ln1118_1125_fu_74435_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1125_fu_74435_p0.read()) * sc_bigint<5>(mul_ln1118_1125_fu_74435_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1126_fu_74454_p0() {
    mul_ln1118_1126_fu_74454_p0 =  (sc_lv<12>) (sext_ln1116_126_cast_fu_54565_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1126_fu_74454_p1() {
    mul_ln1118_1126_fu_74454_p1 = tmp_1126_reg_102187.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1126_fu_74454_p2() {
    mul_ln1118_1126_fu_74454_p2 = (!mul_ln1118_1126_fu_74454_p0.read().is_01() || !mul_ln1118_1126_fu_74454_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1126_fu_74454_p0.read()) * sc_bigint<5>(mul_ln1118_1126_fu_74454_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1127_fu_74473_p0() {
    mul_ln1118_1127_fu_74473_p0 =  (sc_lv<12>) (sext_ln1116_127_cast_fu_54587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1127_fu_74473_p1() {
    mul_ln1118_1127_fu_74473_p1 = tmp_1127_reg_102192.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1127_fu_74473_p2() {
    mul_ln1118_1127_fu_74473_p2 = (!mul_ln1118_1127_fu_74473_p0.read().is_01() || !mul_ln1118_1127_fu_74473_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1127_fu_74473_p0.read()) * sc_bigint<5>(mul_ln1118_1127_fu_74473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1128_fu_74492_p0() {
    mul_ln1118_1128_fu_74492_p0 =  (sc_lv<12>) (sext_ln1116_128_cast_fu_54609_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1128_fu_74492_p1() {
    mul_ln1118_1128_fu_74492_p1 = tmp_1128_reg_102197.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1128_fu_74492_p2() {
    mul_ln1118_1128_fu_74492_p2 = (!mul_ln1118_1128_fu_74492_p0.read().is_01() || !mul_ln1118_1128_fu_74492_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1128_fu_74492_p0.read()) * sc_bigint<5>(mul_ln1118_1128_fu_74492_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1129_fu_74511_p0() {
    mul_ln1118_1129_fu_74511_p0 =  (sc_lv<12>) (sext_ln1116_129_cast_fu_54631_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1129_fu_74511_p1() {
    mul_ln1118_1129_fu_74511_p1 = tmp_1129_reg_102202.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1129_fu_74511_p2() {
    mul_ln1118_1129_fu_74511_p2 = (!mul_ln1118_1129_fu_74511_p0.read().is_01() || !mul_ln1118_1129_fu_74511_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1129_fu_74511_p0.read()) * sc_bigint<5>(mul_ln1118_1129_fu_74511_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_112_fu_54263_p0() {
    mul_ln1118_112_fu_54263_p0 =  (sc_lv<12>) (sext_ln1116_112_cast_fu_54257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_112_fu_54263_p1() {
    mul_ln1118_112_fu_54263_p1 = tmp_112_reg_96684.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_112_fu_54263_p2() {
    mul_ln1118_112_fu_54263_p2 = (!mul_ln1118_112_fu_54263_p0.read().is_01() || !mul_ln1118_112_fu_54263_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_112_fu_54263_p0.read()) * sc_bigint<5>(mul_ln1118_112_fu_54263_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1130_fu_74530_p0() {
    mul_ln1118_1130_fu_74530_p0 =  (sc_lv<12>) (sext_ln1116_130_cast_fu_54653_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1130_fu_74530_p1() {
    mul_ln1118_1130_fu_74530_p1 = tmp_1130_reg_102207.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1130_fu_74530_p2() {
    mul_ln1118_1130_fu_74530_p2 = (!mul_ln1118_1130_fu_74530_p0.read().is_01() || !mul_ln1118_1130_fu_74530_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1130_fu_74530_p0.read()) * sc_bigint<5>(mul_ln1118_1130_fu_74530_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1131_fu_74549_p0() {
    mul_ln1118_1131_fu_74549_p0 =  (sc_lv<12>) (sext_ln1116_131_cast_fu_54675_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1131_fu_74549_p1() {
    mul_ln1118_1131_fu_74549_p1 = tmp_1131_reg_102212.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1131_fu_74549_p2() {
    mul_ln1118_1131_fu_74549_p2 = (!mul_ln1118_1131_fu_74549_p0.read().is_01() || !mul_ln1118_1131_fu_74549_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1131_fu_74549_p0.read()) * sc_bigint<5>(mul_ln1118_1131_fu_74549_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1132_fu_39775_p0() {
    mul_ln1118_1132_fu_39775_p0 =  (sc_lv<12>) (sext_ln1116_132_cast_fu_24659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1132_fu_39775_p1() {
    mul_ln1118_1132_fu_39775_p1 = tmp_1132_fu_39761_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1132_fu_39775_p2() {
    mul_ln1118_1132_fu_39775_p2 = (!mul_ln1118_1132_fu_39775_p0.read().is_01() || !mul_ln1118_1132_fu_39775_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1132_fu_39775_p0.read()) * sc_bigint<5>(mul_ln1118_1132_fu_39775_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1133_fu_39805_p0() {
    mul_ln1118_1133_fu_39805_p0 =  (sc_lv<12>) (sext_ln1116_133_cast_fu_24701_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1133_fu_39805_p1() {
    mul_ln1118_1133_fu_39805_p1 = tmp_1133_fu_39791_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1133_fu_39805_p2() {
    mul_ln1118_1133_fu_39805_p2 = (!mul_ln1118_1133_fu_39805_p0.read().is_01() || !mul_ln1118_1133_fu_39805_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1133_fu_39805_p0.read()) * sc_bigint<5>(mul_ln1118_1133_fu_39805_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1134_fu_74568_p0() {
    mul_ln1118_1134_fu_74568_p0 =  (sc_lv<12>) (sext_ln1116_134_cast_fu_54697_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1134_fu_74568_p1() {
    mul_ln1118_1134_fu_74568_p1 = tmp_1134_reg_102227.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1134_fu_74568_p2() {
    mul_ln1118_1134_fu_74568_p2 = (!mul_ln1118_1134_fu_74568_p0.read().is_01() || !mul_ln1118_1134_fu_74568_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1134_fu_74568_p0.read()) * sc_bigint<5>(mul_ln1118_1134_fu_74568_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1135_fu_74587_p0() {
    mul_ln1118_1135_fu_74587_p0 =  (sc_lv<12>) (sext_ln1116_135_cast_fu_54719_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1135_fu_74587_p1() {
    mul_ln1118_1135_fu_74587_p1 = tmp_1135_reg_102232.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1135_fu_74587_p2() {
    mul_ln1118_1135_fu_74587_p2 = (!mul_ln1118_1135_fu_74587_p0.read().is_01() || !mul_ln1118_1135_fu_74587_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1135_fu_74587_p0.read()) * sc_bigint<5>(mul_ln1118_1135_fu_74587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1136_fu_74606_p0() {
    mul_ln1118_1136_fu_74606_p0 =  (sc_lv<12>) (sext_ln1116_136_cast_fu_54741_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1136_fu_74606_p1() {
    mul_ln1118_1136_fu_74606_p1 = tmp_1136_reg_102237.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1136_fu_74606_p2() {
    mul_ln1118_1136_fu_74606_p2 = (!mul_ln1118_1136_fu_74606_p0.read().is_01() || !mul_ln1118_1136_fu_74606_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1136_fu_74606_p0.read()) * sc_bigint<5>(mul_ln1118_1136_fu_74606_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1137_fu_74625_p0() {
    mul_ln1118_1137_fu_74625_p0 =  (sc_lv<12>) (sext_ln1116_137_cast_fu_54763_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1137_fu_74625_p1() {
    mul_ln1118_1137_fu_74625_p1 = tmp_1137_reg_102242.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1137_fu_74625_p2() {
    mul_ln1118_1137_fu_74625_p2 = (!mul_ln1118_1137_fu_74625_p0.read().is_01() || !mul_ln1118_1137_fu_74625_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1137_fu_74625_p0.read()) * sc_bigint<5>(mul_ln1118_1137_fu_74625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1138_fu_74644_p0() {
    mul_ln1118_1138_fu_74644_p0 =  (sc_lv<12>) (sext_ln1116_138_cast_fu_54785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1138_fu_74644_p1() {
    mul_ln1118_1138_fu_74644_p1 = tmp_1138_reg_102247.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1138_fu_74644_p2() {
    mul_ln1118_1138_fu_74644_p2 = (!mul_ln1118_1138_fu_74644_p0.read().is_01() || !mul_ln1118_1138_fu_74644_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1138_fu_74644_p0.read()) * sc_bigint<5>(mul_ln1118_1138_fu_74644_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1139_fu_74663_p0() {
    mul_ln1118_1139_fu_74663_p0 =  (sc_lv<12>) (sext_ln1116_139_cast_fu_54807_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1139_fu_74663_p1() {
    mul_ln1118_1139_fu_74663_p1 = tmp_1139_reg_102252.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1139_fu_74663_p2() {
    mul_ln1118_1139_fu_74663_p2 = (!mul_ln1118_1139_fu_74663_p0.read().is_01() || !mul_ln1118_1139_fu_74663_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1139_fu_74663_p0.read()) * sc_bigint<5>(mul_ln1118_1139_fu_74663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_113_fu_54285_p0() {
    mul_ln1118_113_fu_54285_p0 =  (sc_lv<12>) (sext_ln1116_113_cast_fu_54279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_113_fu_54285_p1() {
    mul_ln1118_113_fu_54285_p1 = tmp_113_reg_96694.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_113_fu_54285_p2() {
    mul_ln1118_113_fu_54285_p2 = (!mul_ln1118_113_fu_54285_p0.read().is_01() || !mul_ln1118_113_fu_54285_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_113_fu_54285_p0.read()) * sc_bigint<5>(mul_ln1118_113_fu_54285_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1140_fu_74682_p0() {
    mul_ln1118_1140_fu_74682_p0 =  (sc_lv<12>) (sext_ln1116_140_cast_fu_54829_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1140_fu_74682_p1() {
    mul_ln1118_1140_fu_74682_p1 = tmp_1140_reg_102257.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1140_fu_74682_p2() {
    mul_ln1118_1140_fu_74682_p2 = (!mul_ln1118_1140_fu_74682_p0.read().is_01() || !mul_ln1118_1140_fu_74682_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1140_fu_74682_p0.read()) * sc_bigint<5>(mul_ln1118_1140_fu_74682_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1141_fu_74701_p0() {
    mul_ln1118_1141_fu_74701_p0 =  (sc_lv<12>) (sext_ln1116_141_cast_fu_54851_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1141_fu_74701_p1() {
    mul_ln1118_1141_fu_74701_p1 = tmp_1141_reg_102262.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1141_fu_74701_p2() {
    mul_ln1118_1141_fu_74701_p2 = (!mul_ln1118_1141_fu_74701_p0.read().is_01() || !mul_ln1118_1141_fu_74701_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1141_fu_74701_p0.read()) * sc_bigint<5>(mul_ln1118_1141_fu_74701_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1142_fu_74720_p0() {
    mul_ln1118_1142_fu_74720_p0 =  (sc_lv<12>) (sext_ln1116_142_cast_fu_54873_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1142_fu_74720_p1() {
    mul_ln1118_1142_fu_74720_p1 = tmp_1142_reg_102267.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1142_fu_74720_p2() {
    mul_ln1118_1142_fu_74720_p2 = (!mul_ln1118_1142_fu_74720_p0.read().is_01() || !mul_ln1118_1142_fu_74720_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1142_fu_74720_p0.read()) * sc_bigint<5>(mul_ln1118_1142_fu_74720_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1143_fu_74739_p0() {
    mul_ln1118_1143_fu_74739_p0 =  (sc_lv<12>) (sext_ln1116_143_cast_fu_54895_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1143_fu_74739_p1() {
    mul_ln1118_1143_fu_74739_p1 = tmp_1143_reg_102272.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1143_fu_74739_p2() {
    mul_ln1118_1143_fu_74739_p2 = (!mul_ln1118_1143_fu_74739_p0.read().is_01() || !mul_ln1118_1143_fu_74739_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1143_fu_74739_p0.read()) * sc_bigint<5>(mul_ln1118_1143_fu_74739_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1144_fu_74758_p0() {
    mul_ln1118_1144_fu_74758_p0 =  (sc_lv<12>) (sext_ln1116_144_cast_fu_54917_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1144_fu_74758_p1() {
    mul_ln1118_1144_fu_74758_p1 = tmp_1144_reg_102277.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1144_fu_74758_p2() {
    mul_ln1118_1144_fu_74758_p2 = (!mul_ln1118_1144_fu_74758_p0.read().is_01() || !mul_ln1118_1144_fu_74758_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1144_fu_74758_p0.read()) * sc_bigint<5>(mul_ln1118_1144_fu_74758_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1145_fu_74777_p0() {
    mul_ln1118_1145_fu_74777_p0 =  (sc_lv<12>) (sext_ln1116_145_cast_fu_54939_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1145_fu_74777_p1() {
    mul_ln1118_1145_fu_74777_p1 = tmp_1145_reg_102282.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1145_fu_74777_p2() {
    mul_ln1118_1145_fu_74777_p2 = (!mul_ln1118_1145_fu_74777_p0.read().is_01() || !mul_ln1118_1145_fu_74777_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1145_fu_74777_p0.read()) * sc_bigint<5>(mul_ln1118_1145_fu_74777_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1146_fu_74796_p0() {
    mul_ln1118_1146_fu_74796_p0 =  (sc_lv<12>) (sext_ln1116_146_cast_fu_54961_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1146_fu_74796_p1() {
    mul_ln1118_1146_fu_74796_p1 = tmp_1146_reg_102287.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1146_fu_74796_p2() {
    mul_ln1118_1146_fu_74796_p2 = (!mul_ln1118_1146_fu_74796_p0.read().is_01() || !mul_ln1118_1146_fu_74796_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1146_fu_74796_p0.read()) * sc_bigint<5>(mul_ln1118_1146_fu_74796_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1147_fu_74815_p0() {
    mul_ln1118_1147_fu_74815_p0 =  (sc_lv<12>) (sext_ln1116_147_cast_fu_54983_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1147_fu_74815_p1() {
    mul_ln1118_1147_fu_74815_p1 = tmp_1147_reg_102292.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1147_fu_74815_p2() {
    mul_ln1118_1147_fu_74815_p2 = (!mul_ln1118_1147_fu_74815_p0.read().is_01() || !mul_ln1118_1147_fu_74815_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1147_fu_74815_p0.read()) * sc_bigint<5>(mul_ln1118_1147_fu_74815_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1148_fu_74834_p0() {
    mul_ln1118_1148_fu_74834_p0 =  (sc_lv<12>) (sext_ln1116_148_cast_fu_55005_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1148_fu_74834_p1() {
    mul_ln1118_1148_fu_74834_p1 = tmp_1148_reg_102297.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1148_fu_74834_p2() {
    mul_ln1118_1148_fu_74834_p2 = (!mul_ln1118_1148_fu_74834_p0.read().is_01() || !mul_ln1118_1148_fu_74834_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1148_fu_74834_p0.read()) * sc_bigint<5>(mul_ln1118_1148_fu_74834_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1149_fu_74853_p0() {
    mul_ln1118_1149_fu_74853_p0 =  (sc_lv<12>) (sext_ln1116_149_cast_fu_55027_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1149_fu_74853_p1() {
    mul_ln1118_1149_fu_74853_p1 = tmp_1149_reg_102302.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1149_fu_74853_p2() {
    mul_ln1118_1149_fu_74853_p2 = (!mul_ln1118_1149_fu_74853_p0.read().is_01() || !mul_ln1118_1149_fu_74853_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1149_fu_74853_p0.read()) * sc_bigint<5>(mul_ln1118_1149_fu_74853_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_114_fu_54307_p0() {
    mul_ln1118_114_fu_54307_p0 =  (sc_lv<12>) (sext_ln1116_114_cast_fu_54301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_114_fu_54307_p1() {
    mul_ln1118_114_fu_54307_p1 = tmp_114_reg_96704.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_114_fu_54307_p2() {
    mul_ln1118_114_fu_54307_p2 = (!mul_ln1118_114_fu_54307_p0.read().is_01() || !mul_ln1118_114_fu_54307_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_114_fu_54307_p0.read()) * sc_bigint<5>(mul_ln1118_114_fu_54307_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1150_fu_74872_p0() {
    mul_ln1118_1150_fu_74872_p0 =  (sc_lv<12>) (sext_ln1116_150_cast_fu_55049_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1150_fu_74872_p1() {
    mul_ln1118_1150_fu_74872_p1 = tmp_1150_reg_102307.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1150_fu_74872_p2() {
    mul_ln1118_1150_fu_74872_p2 = (!mul_ln1118_1150_fu_74872_p0.read().is_01() || !mul_ln1118_1150_fu_74872_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1150_fu_74872_p0.read()) * sc_bigint<5>(mul_ln1118_1150_fu_74872_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1151_fu_74891_p0() {
    mul_ln1118_1151_fu_74891_p0 =  (sc_lv<12>) (sext_ln1116_151_cast_reg_97064.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1151_fu_74891_p1() {
    mul_ln1118_1151_fu_74891_p1 = tmp_1151_reg_102312.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1151_fu_74891_p2() {
    mul_ln1118_1151_fu_74891_p2 = (!mul_ln1118_1151_fu_74891_p0.read().is_01() || !mul_ln1118_1151_fu_74891_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1151_fu_74891_p0.read()) * sc_bigint<5>(mul_ln1118_1151_fu_74891_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1152_fu_74909_p0() {
    mul_ln1118_1152_fu_74909_p0 =  (sc_lv<12>) (sext_ln1116_152_cast_reg_97082.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1152_fu_74909_p1() {
    mul_ln1118_1152_fu_74909_p1 = tmp_1152_reg_102317.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1152_fu_74909_p2() {
    mul_ln1118_1152_fu_74909_p2 = (!mul_ln1118_1152_fu_74909_p0.read().is_01() || !mul_ln1118_1152_fu_74909_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1152_fu_74909_p0.read()) * sc_bigint<5>(mul_ln1118_1152_fu_74909_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1153_fu_40025_p0() {
    mul_ln1118_1153_fu_40025_p0 =  (sc_lv<12>) (sext_ln1116_153_cast_fu_25093_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1153_fu_40025_p1() {
    mul_ln1118_1153_fu_40025_p1 = tmp_1153_fu_40011_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1153_fu_40025_p2() {
    mul_ln1118_1153_fu_40025_p2 = (!mul_ln1118_1153_fu_40025_p0.read().is_01() || !mul_ln1118_1153_fu_40025_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1153_fu_40025_p0.read()) * sc_bigint<5>(mul_ln1118_1153_fu_40025_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1154_fu_40055_p0() {
    mul_ln1118_1154_fu_40055_p0 =  (sc_lv<12>) (sext_ln1116_154_cast_fu_25135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1154_fu_40055_p1() {
    mul_ln1118_1154_fu_40055_p1 = tmp_1154_fu_40041_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1154_fu_40055_p2() {
    mul_ln1118_1154_fu_40055_p2 = (!mul_ln1118_1154_fu_40055_p0.read().is_01() || !mul_ln1118_1154_fu_40055_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1154_fu_40055_p0.read()) * sc_bigint<5>(mul_ln1118_1154_fu_40055_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1155_fu_40085_p0() {
    mul_ln1118_1155_fu_40085_p0 =  (sc_lv<12>) (sext_ln1116_155_cast_fu_25177_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1155_fu_40085_p1() {
    mul_ln1118_1155_fu_40085_p1 = tmp_1155_fu_40071_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1155_fu_40085_p2() {
    mul_ln1118_1155_fu_40085_p2 = (!mul_ln1118_1155_fu_40085_p0.read().is_01() || !mul_ln1118_1155_fu_40085_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1155_fu_40085_p0.read()) * sc_bigint<5>(mul_ln1118_1155_fu_40085_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1156_fu_40115_p0() {
    mul_ln1118_1156_fu_40115_p0 =  (sc_lv<12>) (sext_ln1116_156_cast_fu_25219_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1156_fu_40115_p1() {
    mul_ln1118_1156_fu_40115_p1 = tmp_1156_fu_40101_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1156_fu_40115_p2() {
    mul_ln1118_1156_fu_40115_p2 = (!mul_ln1118_1156_fu_40115_p0.read().is_01() || !mul_ln1118_1156_fu_40115_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1156_fu_40115_p0.read()) * sc_bigint<5>(mul_ln1118_1156_fu_40115_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1157_fu_40145_p0() {
    mul_ln1118_1157_fu_40145_p0 =  (sc_lv<12>) (sext_ln1116_157_cast_fu_25261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1157_fu_40145_p1() {
    mul_ln1118_1157_fu_40145_p1 = tmp_1157_fu_40131_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1157_fu_40145_p2() {
    mul_ln1118_1157_fu_40145_p2 = (!mul_ln1118_1157_fu_40145_p0.read().is_01() || !mul_ln1118_1157_fu_40145_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1157_fu_40145_p0.read()) * sc_bigint<5>(mul_ln1118_1157_fu_40145_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1158_fu_40175_p0() {
    mul_ln1118_1158_fu_40175_p0 =  (sc_lv<12>) (sext_ln1116_158_cast_fu_25303_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1158_fu_40175_p1() {
    mul_ln1118_1158_fu_40175_p1 = tmp_1158_fu_40161_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1158_fu_40175_p2() {
    mul_ln1118_1158_fu_40175_p2 = (!mul_ln1118_1158_fu_40175_p0.read().is_01() || !mul_ln1118_1158_fu_40175_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1158_fu_40175_p0.read()) * sc_bigint<5>(mul_ln1118_1158_fu_40175_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1159_fu_74927_p0() {
    mul_ln1118_1159_fu_74927_p0 =  (sc_lv<12>) (sext_ln1116_159_cast_fu_55107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1159_fu_74927_p1() {
    mul_ln1118_1159_fu_74927_p1 = tmp_1159_reg_102352.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1159_fu_74927_p2() {
    mul_ln1118_1159_fu_74927_p2 = (!mul_ln1118_1159_fu_74927_p0.read().is_01() || !mul_ln1118_1159_fu_74927_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1159_fu_74927_p0.read()) * sc_bigint<5>(mul_ln1118_1159_fu_74927_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_115_fu_54329_p0() {
    mul_ln1118_115_fu_54329_p0 =  (sc_lv<12>) (sext_ln1116_115_cast_fu_54323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_115_fu_54329_p1() {
    mul_ln1118_115_fu_54329_p1 = tmp_115_reg_96714.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_115_fu_54329_p2() {
    mul_ln1118_115_fu_54329_p2 = (!mul_ln1118_115_fu_54329_p0.read().is_01() || !mul_ln1118_115_fu_54329_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_115_fu_54329_p0.read()) * sc_bigint<5>(mul_ln1118_115_fu_54329_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1160_fu_74946_p0() {
    mul_ln1118_1160_fu_74946_p0 =  (sc_lv<12>) (sext_ln1116_160_cast_fu_55129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1160_fu_74946_p1() {
    mul_ln1118_1160_fu_74946_p1 = tmp_1160_reg_102357.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1160_fu_74946_p2() {
    mul_ln1118_1160_fu_74946_p2 = (!mul_ln1118_1160_fu_74946_p0.read().is_01() || !mul_ln1118_1160_fu_74946_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1160_fu_74946_p0.read()) * sc_bigint<5>(mul_ln1118_1160_fu_74946_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1161_fu_74965_p0() {
    mul_ln1118_1161_fu_74965_p0 =  (sc_lv<12>) (sext_ln1116_161_cast_fu_55151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1161_fu_74965_p1() {
    mul_ln1118_1161_fu_74965_p1 = tmp_1161_reg_102362.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1161_fu_74965_p2() {
    mul_ln1118_1161_fu_74965_p2 = (!mul_ln1118_1161_fu_74965_p0.read().is_01() || !mul_ln1118_1161_fu_74965_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1161_fu_74965_p0.read()) * sc_bigint<5>(mul_ln1118_1161_fu_74965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1162_fu_74984_p0() {
    mul_ln1118_1162_fu_74984_p0 =  (sc_lv<12>) (sext_ln1116_162_cast_fu_55173_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1162_fu_74984_p1() {
    mul_ln1118_1162_fu_74984_p1 = tmp_1162_reg_102367.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1162_fu_74984_p2() {
    mul_ln1118_1162_fu_74984_p2 = (!mul_ln1118_1162_fu_74984_p0.read().is_01() || !mul_ln1118_1162_fu_74984_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1162_fu_74984_p0.read()) * sc_bigint<5>(mul_ln1118_1162_fu_74984_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1163_fu_75003_p0() {
    mul_ln1118_1163_fu_75003_p0 =  (sc_lv<12>) (sext_ln1116_163_cast_fu_55195_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1163_fu_75003_p1() {
    mul_ln1118_1163_fu_75003_p1 = tmp_1163_reg_102372.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1163_fu_75003_p2() {
    mul_ln1118_1163_fu_75003_p2 = (!mul_ln1118_1163_fu_75003_p0.read().is_01() || !mul_ln1118_1163_fu_75003_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1163_fu_75003_p0.read()) * sc_bigint<5>(mul_ln1118_1163_fu_75003_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1164_fu_75022_p0() {
    mul_ln1118_1164_fu_75022_p0 =  (sc_lv<12>) (sext_ln1116_164_cast_fu_55217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1164_fu_75022_p1() {
    mul_ln1118_1164_fu_75022_p1 = tmp_1164_reg_102377.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1164_fu_75022_p2() {
    mul_ln1118_1164_fu_75022_p2 = (!mul_ln1118_1164_fu_75022_p0.read().is_01() || !mul_ln1118_1164_fu_75022_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1164_fu_75022_p0.read()) * sc_bigint<5>(mul_ln1118_1164_fu_75022_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1165_fu_75041_p0() {
    mul_ln1118_1165_fu_75041_p0 =  (sc_lv<12>) (sext_ln1116_165_cast_fu_55239_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1165_fu_75041_p1() {
    mul_ln1118_1165_fu_75041_p1 = tmp_1165_reg_102382.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1165_fu_75041_p2() {
    mul_ln1118_1165_fu_75041_p2 = (!mul_ln1118_1165_fu_75041_p0.read().is_01() || !mul_ln1118_1165_fu_75041_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1165_fu_75041_p0.read()) * sc_bigint<5>(mul_ln1118_1165_fu_75041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1166_fu_75060_p0() {
    mul_ln1118_1166_fu_75060_p0 =  (sc_lv<12>) (sext_ln1116_166_cast_fu_55261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1166_fu_75060_p1() {
    mul_ln1118_1166_fu_75060_p1 = tmp_1166_reg_102387.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1166_fu_75060_p2() {
    mul_ln1118_1166_fu_75060_p2 = (!mul_ln1118_1166_fu_75060_p0.read().is_01() || !mul_ln1118_1166_fu_75060_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1166_fu_75060_p0.read()) * sc_bigint<5>(mul_ln1118_1166_fu_75060_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1167_fu_75079_p0() {
    mul_ln1118_1167_fu_75079_p0 =  (sc_lv<12>) (sext_ln1116_167_cast_fu_55283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1167_fu_75079_p1() {
    mul_ln1118_1167_fu_75079_p1 = tmp_1167_reg_102392.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1167_fu_75079_p2() {
    mul_ln1118_1167_fu_75079_p2 = (!mul_ln1118_1167_fu_75079_p0.read().is_01() || !mul_ln1118_1167_fu_75079_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1167_fu_75079_p0.read()) * sc_bigint<5>(mul_ln1118_1167_fu_75079_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1168_fu_75098_p0() {
    mul_ln1118_1168_fu_75098_p0 =  (sc_lv<12>) (sext_ln1116_168_cast_fu_55305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1168_fu_75098_p1() {
    mul_ln1118_1168_fu_75098_p1 = tmp_1168_reg_102397.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1168_fu_75098_p2() {
    mul_ln1118_1168_fu_75098_p2 = (!mul_ln1118_1168_fu_75098_p0.read().is_01() || !mul_ln1118_1168_fu_75098_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1168_fu_75098_p0.read()) * sc_bigint<5>(mul_ln1118_1168_fu_75098_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1169_fu_75117_p0() {
    mul_ln1118_1169_fu_75117_p0 =  (sc_lv<12>) (sext_ln1116_169_cast_fu_55327_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1169_fu_75117_p1() {
    mul_ln1118_1169_fu_75117_p1 = tmp_1169_reg_102402.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1169_fu_75117_p2() {
    mul_ln1118_1169_fu_75117_p2 = (!mul_ln1118_1169_fu_75117_p0.read().is_01() || !mul_ln1118_1169_fu_75117_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1169_fu_75117_p0.read()) * sc_bigint<5>(mul_ln1118_1169_fu_75117_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_116_fu_54351_p0() {
    mul_ln1118_116_fu_54351_p0 =  (sc_lv<12>) (sext_ln1116_116_cast_fu_54345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_116_fu_54351_p1() {
    mul_ln1118_116_fu_54351_p1 = tmp_116_reg_96724.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_116_fu_54351_p2() {
    mul_ln1118_116_fu_54351_p2 = (!mul_ln1118_116_fu_54351_p0.read().is_01() || !mul_ln1118_116_fu_54351_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_116_fu_54351_p0.read()) * sc_bigint<5>(mul_ln1118_116_fu_54351_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1170_fu_75136_p0() {
    mul_ln1118_1170_fu_75136_p0 =  (sc_lv<12>) (sext_ln1116_170_cast_fu_55349_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1170_fu_75136_p1() {
    mul_ln1118_1170_fu_75136_p1 = tmp_1170_reg_102407.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1170_fu_75136_p2() {
    mul_ln1118_1170_fu_75136_p2 = (!mul_ln1118_1170_fu_75136_p0.read().is_01() || !mul_ln1118_1170_fu_75136_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1170_fu_75136_p0.read()) * sc_bigint<5>(mul_ln1118_1170_fu_75136_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1171_fu_75155_p0() {
    mul_ln1118_1171_fu_75155_p0 =  (sc_lv<12>) (sext_ln1116_171_cast_fu_55371_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1171_fu_75155_p1() {
    mul_ln1118_1171_fu_75155_p1 = tmp_1171_reg_102412.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1171_fu_75155_p2() {
    mul_ln1118_1171_fu_75155_p2 = (!mul_ln1118_1171_fu_75155_p0.read().is_01() || !mul_ln1118_1171_fu_75155_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1171_fu_75155_p0.read()) * sc_bigint<5>(mul_ln1118_1171_fu_75155_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1172_fu_75174_p0() {
    mul_ln1118_1172_fu_75174_p0 =  (sc_lv<12>) (sext_ln1116_172_cast_fu_55393_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1172_fu_75174_p1() {
    mul_ln1118_1172_fu_75174_p1 = tmp_1172_reg_102417.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1172_fu_75174_p2() {
    mul_ln1118_1172_fu_75174_p2 = (!mul_ln1118_1172_fu_75174_p0.read().is_01() || !mul_ln1118_1172_fu_75174_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1172_fu_75174_p0.read()) * sc_bigint<5>(mul_ln1118_1172_fu_75174_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1173_fu_75193_p0() {
    mul_ln1118_1173_fu_75193_p0 =  (sc_lv<12>) (sext_ln1116_173_cast_fu_55415_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1173_fu_75193_p1() {
    mul_ln1118_1173_fu_75193_p1 = tmp_1173_reg_102422.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1173_fu_75193_p2() {
    mul_ln1118_1173_fu_75193_p2 = (!mul_ln1118_1173_fu_75193_p0.read().is_01() || !mul_ln1118_1173_fu_75193_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1173_fu_75193_p0.read()) * sc_bigint<5>(mul_ln1118_1173_fu_75193_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1174_fu_75212_p0() {
    mul_ln1118_1174_fu_75212_p0 =  (sc_lv<12>) (sext_ln1116_174_cast_fu_55437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1174_fu_75212_p1() {
    mul_ln1118_1174_fu_75212_p1 = tmp_1174_reg_102427.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1174_fu_75212_p2() {
    mul_ln1118_1174_fu_75212_p2 = (!mul_ln1118_1174_fu_75212_p0.read().is_01() || !mul_ln1118_1174_fu_75212_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1174_fu_75212_p0.read()) * sc_bigint<5>(mul_ln1118_1174_fu_75212_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1175_fu_75231_p0() {
    mul_ln1118_1175_fu_75231_p0 =  (sc_lv<12>) (sext_ln1116_175_cast_fu_55459_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1175_fu_75231_p1() {
    mul_ln1118_1175_fu_75231_p1 = tmp_1175_reg_102432.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1175_fu_75231_p2() {
    mul_ln1118_1175_fu_75231_p2 = (!mul_ln1118_1175_fu_75231_p0.read().is_01() || !mul_ln1118_1175_fu_75231_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1175_fu_75231_p0.read()) * sc_bigint<5>(mul_ln1118_1175_fu_75231_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1176_fu_75250_p0() {
    mul_ln1118_1176_fu_75250_p0 =  (sc_lv<12>) (sext_ln1116_176_cast_reg_97300.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1176_fu_75250_p1() {
    mul_ln1118_1176_fu_75250_p1 = tmp_1176_reg_102437.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1176_fu_75250_p2() {
    mul_ln1118_1176_fu_75250_p2 = (!mul_ln1118_1176_fu_75250_p0.read().is_01() || !mul_ln1118_1176_fu_75250_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1176_fu_75250_p0.read()) * sc_bigint<5>(mul_ln1118_1176_fu_75250_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1177_fu_75268_p0() {
    mul_ln1118_1177_fu_75268_p0 =  (sc_lv<12>) (sext_ln1116_177_cast_reg_97318.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1177_fu_75268_p1() {
    mul_ln1118_1177_fu_75268_p1 = tmp_1177_reg_102442.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1177_fu_75268_p2() {
    mul_ln1118_1177_fu_75268_p2 = (!mul_ln1118_1177_fu_75268_p0.read().is_01() || !mul_ln1118_1177_fu_75268_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1177_fu_75268_p0.read()) * sc_bigint<5>(mul_ln1118_1177_fu_75268_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1178_fu_40395_p0() {
    mul_ln1118_1178_fu_40395_p0 =  (sc_lv<12>) (sext_ln1116_178_cast_fu_25695_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1178_fu_40395_p1() {
    mul_ln1118_1178_fu_40395_p1 = tmp_1178_fu_40381_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1178_fu_40395_p2() {
    mul_ln1118_1178_fu_40395_p2 = (!mul_ln1118_1178_fu_40395_p0.read().is_01() || !mul_ln1118_1178_fu_40395_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1178_fu_40395_p0.read()) * sc_bigint<5>(mul_ln1118_1178_fu_40395_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1179_fu_40425_p0() {
    mul_ln1118_1179_fu_40425_p0 =  (sc_lv<12>) (sext_ln1116_179_cast_fu_25737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1179_fu_40425_p1() {
    mul_ln1118_1179_fu_40425_p1 = tmp_1179_fu_40411_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1179_fu_40425_p2() {
    mul_ln1118_1179_fu_40425_p2 = (!mul_ln1118_1179_fu_40425_p0.read().is_01() || !mul_ln1118_1179_fu_40425_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1179_fu_40425_p0.read()) * sc_bigint<5>(mul_ln1118_1179_fu_40425_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_117_fu_54373_p0() {
    mul_ln1118_117_fu_54373_p0 =  (sc_lv<12>) (sext_ln1116_117_cast_fu_54367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_117_fu_54373_p1() {
    mul_ln1118_117_fu_54373_p1 = tmp_117_reg_96734.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_117_fu_54373_p2() {
    mul_ln1118_117_fu_54373_p2 = (!mul_ln1118_117_fu_54373_p0.read().is_01() || !mul_ln1118_117_fu_54373_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_117_fu_54373_p0.read()) * sc_bigint<5>(mul_ln1118_117_fu_54373_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1180_fu_40455_p0() {
    mul_ln1118_1180_fu_40455_p0 =  (sc_lv<12>) (sext_ln1116_180_cast_fu_25779_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1180_fu_40455_p1() {
    mul_ln1118_1180_fu_40455_p1 = tmp_1180_fu_40441_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1180_fu_40455_p2() {
    mul_ln1118_1180_fu_40455_p2 = (!mul_ln1118_1180_fu_40455_p0.read().is_01() || !mul_ln1118_1180_fu_40455_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1180_fu_40455_p0.read()) * sc_bigint<5>(mul_ln1118_1180_fu_40455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1181_fu_40485_p0() {
    mul_ln1118_1181_fu_40485_p0 =  (sc_lv<12>) (sext_ln1116_181_cast_fu_25821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1181_fu_40485_p1() {
    mul_ln1118_1181_fu_40485_p1 = tmp_1181_fu_40471_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1181_fu_40485_p2() {
    mul_ln1118_1181_fu_40485_p2 = (!mul_ln1118_1181_fu_40485_p0.read().is_01() || !mul_ln1118_1181_fu_40485_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1181_fu_40485_p0.read()) * sc_bigint<5>(mul_ln1118_1181_fu_40485_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1182_fu_40515_p0() {
    mul_ln1118_1182_fu_40515_p0 =  (sc_lv<12>) (sext_ln1116_182_cast_fu_25863_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1182_fu_40515_p1() {
    mul_ln1118_1182_fu_40515_p1 = tmp_1182_fu_40501_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1182_fu_40515_p2() {
    mul_ln1118_1182_fu_40515_p2 = (!mul_ln1118_1182_fu_40515_p0.read().is_01() || !mul_ln1118_1182_fu_40515_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1182_fu_40515_p0.read()) * sc_bigint<5>(mul_ln1118_1182_fu_40515_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1183_fu_40545_p0() {
    mul_ln1118_1183_fu_40545_p0 =  (sc_lv<12>) (sext_ln1116_183_cast_fu_25905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1183_fu_40545_p1() {
    mul_ln1118_1183_fu_40545_p1 = tmp_1183_fu_40531_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1183_fu_40545_p2() {
    mul_ln1118_1183_fu_40545_p2 = (!mul_ln1118_1183_fu_40545_p0.read().is_01() || !mul_ln1118_1183_fu_40545_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1183_fu_40545_p0.read()) * sc_bigint<5>(mul_ln1118_1183_fu_40545_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1184_fu_75286_p0() {
    mul_ln1118_1184_fu_75286_p0 =  (sc_lv<12>) (sext_ln1116_184_cast_fu_55517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1184_fu_75286_p1() {
    mul_ln1118_1184_fu_75286_p1 = tmp_1184_reg_102477.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1184_fu_75286_p2() {
    mul_ln1118_1184_fu_75286_p2 = (!mul_ln1118_1184_fu_75286_p0.read().is_01() || !mul_ln1118_1184_fu_75286_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1184_fu_75286_p0.read()) * sc_bigint<5>(mul_ln1118_1184_fu_75286_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1185_fu_75305_p0() {
    mul_ln1118_1185_fu_75305_p0 =  (sc_lv<12>) (sext_ln1116_185_cast_fu_55539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1185_fu_75305_p1() {
    mul_ln1118_1185_fu_75305_p1 = tmp_1185_reg_102482.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1185_fu_75305_p2() {
    mul_ln1118_1185_fu_75305_p2 = (!mul_ln1118_1185_fu_75305_p0.read().is_01() || !mul_ln1118_1185_fu_75305_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1185_fu_75305_p0.read()) * sc_bigint<5>(mul_ln1118_1185_fu_75305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1186_fu_75324_p0() {
    mul_ln1118_1186_fu_75324_p0 =  (sc_lv<12>) (sext_ln1116_186_cast_fu_55561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1186_fu_75324_p1() {
    mul_ln1118_1186_fu_75324_p1 = tmp_1186_reg_102487.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1186_fu_75324_p2() {
    mul_ln1118_1186_fu_75324_p2 = (!mul_ln1118_1186_fu_75324_p0.read().is_01() || !mul_ln1118_1186_fu_75324_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1186_fu_75324_p0.read()) * sc_bigint<5>(mul_ln1118_1186_fu_75324_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1187_fu_75343_p0() {
    mul_ln1118_1187_fu_75343_p0 =  (sc_lv<12>) (sext_ln1116_187_cast_fu_55583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1187_fu_75343_p1() {
    mul_ln1118_1187_fu_75343_p1 = tmp_1187_reg_102492.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1187_fu_75343_p2() {
    mul_ln1118_1187_fu_75343_p2 = (!mul_ln1118_1187_fu_75343_p0.read().is_01() || !mul_ln1118_1187_fu_75343_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1187_fu_75343_p0.read()) * sc_bigint<5>(mul_ln1118_1187_fu_75343_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1188_fu_75362_p0() {
    mul_ln1118_1188_fu_75362_p0 =  (sc_lv<12>) (sext_ln1116_188_cast_fu_55605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1188_fu_75362_p1() {
    mul_ln1118_1188_fu_75362_p1 = tmp_1188_reg_102497.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1188_fu_75362_p2() {
    mul_ln1118_1188_fu_75362_p2 = (!mul_ln1118_1188_fu_75362_p0.read().is_01() || !mul_ln1118_1188_fu_75362_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1188_fu_75362_p0.read()) * sc_bigint<5>(mul_ln1118_1188_fu_75362_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1189_fu_75381_p0() {
    mul_ln1118_1189_fu_75381_p0 =  (sc_lv<12>) (sext_ln1116_189_cast_fu_55627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1189_fu_75381_p1() {
    mul_ln1118_1189_fu_75381_p1 = tmp_1189_reg_102502.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1189_fu_75381_p2() {
    mul_ln1118_1189_fu_75381_p2 = (!mul_ln1118_1189_fu_75381_p0.read().is_01() || !mul_ln1118_1189_fu_75381_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1189_fu_75381_p0.read()) * sc_bigint<5>(mul_ln1118_1189_fu_75381_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_118_fu_54395_p0() {
    mul_ln1118_118_fu_54395_p0 =  (sc_lv<12>) (sext_ln1116_118_cast_fu_54389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_118_fu_54395_p1() {
    mul_ln1118_118_fu_54395_p1 = tmp_118_reg_96744.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_118_fu_54395_p2() {
    mul_ln1118_118_fu_54395_p2 = (!mul_ln1118_118_fu_54395_p0.read().is_01() || !mul_ln1118_118_fu_54395_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_118_fu_54395_p0.read()) * sc_bigint<5>(mul_ln1118_118_fu_54395_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1190_fu_75400_p0() {
    mul_ln1118_1190_fu_75400_p0 =  (sc_lv<12>) (sext_ln1116_190_cast_fu_55649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1190_fu_75400_p1() {
    mul_ln1118_1190_fu_75400_p1 = tmp_1190_reg_102507.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1190_fu_75400_p2() {
    mul_ln1118_1190_fu_75400_p2 = (!mul_ln1118_1190_fu_75400_p0.read().is_01() || !mul_ln1118_1190_fu_75400_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1190_fu_75400_p0.read()) * sc_bigint<5>(mul_ln1118_1190_fu_75400_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1191_fu_75419_p0() {
    mul_ln1118_1191_fu_75419_p0 =  (sc_lv<12>) (sext_ln1116_191_cast_fu_55671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1191_fu_75419_p1() {
    mul_ln1118_1191_fu_75419_p1 = tmp_1191_reg_102512.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1191_fu_75419_p2() {
    mul_ln1118_1191_fu_75419_p2 = (!mul_ln1118_1191_fu_75419_p0.read().is_01() || !mul_ln1118_1191_fu_75419_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1191_fu_75419_p0.read()) * sc_bigint<5>(mul_ln1118_1191_fu_75419_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1192_fu_75438_p0() {
    mul_ln1118_1192_fu_75438_p0 =  (sc_lv<12>) (sext_ln1116_192_cast_fu_55693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1192_fu_75438_p1() {
    mul_ln1118_1192_fu_75438_p1 = tmp_1192_reg_102517.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1192_fu_75438_p2() {
    mul_ln1118_1192_fu_75438_p2 = (!mul_ln1118_1192_fu_75438_p0.read().is_01() || !mul_ln1118_1192_fu_75438_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1192_fu_75438_p0.read()) * sc_bigint<5>(mul_ln1118_1192_fu_75438_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1193_fu_75457_p0() {
    mul_ln1118_1193_fu_75457_p0 =  (sc_lv<12>) (sext_ln1116_193_cast_fu_55715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1193_fu_75457_p1() {
    mul_ln1118_1193_fu_75457_p1 = tmp_1193_reg_102522.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1193_fu_75457_p2() {
    mul_ln1118_1193_fu_75457_p2 = (!mul_ln1118_1193_fu_75457_p0.read().is_01() || !mul_ln1118_1193_fu_75457_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1193_fu_75457_p0.read()) * sc_bigint<5>(mul_ln1118_1193_fu_75457_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1194_fu_75476_p0() {
    mul_ln1118_1194_fu_75476_p0 =  (sc_lv<12>) (sext_ln1116_194_cast_fu_55737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1194_fu_75476_p1() {
    mul_ln1118_1194_fu_75476_p1 = tmp_1194_reg_102527.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1194_fu_75476_p2() {
    mul_ln1118_1194_fu_75476_p2 = (!mul_ln1118_1194_fu_75476_p0.read().is_01() || !mul_ln1118_1194_fu_75476_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1194_fu_75476_p0.read()) * sc_bigint<5>(mul_ln1118_1194_fu_75476_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1195_fu_75495_p0() {
    mul_ln1118_1195_fu_75495_p0 =  (sc_lv<12>) (sext_ln1116_195_cast_fu_55759_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1195_fu_75495_p1() {
    mul_ln1118_1195_fu_75495_p1 = tmp_1195_reg_102532.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1195_fu_75495_p2() {
    mul_ln1118_1195_fu_75495_p2 = (!mul_ln1118_1195_fu_75495_p0.read().is_01() || !mul_ln1118_1195_fu_75495_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1195_fu_75495_p0.read()) * sc_bigint<5>(mul_ln1118_1195_fu_75495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1196_fu_75514_p0() {
    mul_ln1118_1196_fu_75514_p0 =  (sc_lv<12>) (sext_ln1116_196_cast_fu_55781_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1196_fu_75514_p1() {
    mul_ln1118_1196_fu_75514_p1 = tmp_1196_reg_102537.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1196_fu_75514_p2() {
    mul_ln1118_1196_fu_75514_p2 = (!mul_ln1118_1196_fu_75514_p0.read().is_01() || !mul_ln1118_1196_fu_75514_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1196_fu_75514_p0.read()) * sc_bigint<5>(mul_ln1118_1196_fu_75514_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1197_fu_75533_p0() {
    mul_ln1118_1197_fu_75533_p0 =  (sc_lv<12>) (sext_ln1116_197_cast_fu_55803_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1197_fu_75533_p1() {
    mul_ln1118_1197_fu_75533_p1 = tmp_1197_reg_102542.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1197_fu_75533_p2() {
    mul_ln1118_1197_fu_75533_p2 = (!mul_ln1118_1197_fu_75533_p0.read().is_01() || !mul_ln1118_1197_fu_75533_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1197_fu_75533_p0.read()) * sc_bigint<5>(mul_ln1118_1197_fu_75533_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1198_fu_75552_p0() {
    mul_ln1118_1198_fu_75552_p0 =  (sc_lv<12>) (sext_ln1116_198_cast_fu_55825_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1198_fu_75552_p1() {
    mul_ln1118_1198_fu_75552_p1 = tmp_1198_reg_102547.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1198_fu_75552_p2() {
    mul_ln1118_1198_fu_75552_p2 = (!mul_ln1118_1198_fu_75552_p0.read().is_01() || !mul_ln1118_1198_fu_75552_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1198_fu_75552_p0.read()) * sc_bigint<5>(mul_ln1118_1198_fu_75552_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1199_fu_75571_p0() {
    mul_ln1118_1199_fu_75571_p0 =  (sc_lv<12>) (sext_ln1116_199_cast_fu_55847_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1199_fu_75571_p1() {
    mul_ln1118_1199_fu_75571_p1 = tmp_1199_reg_102552.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1199_fu_75571_p2() {
    mul_ln1118_1199_fu_75571_p2 = (!mul_ln1118_1199_fu_75571_p0.read().is_01() || !mul_ln1118_1199_fu_75571_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1199_fu_75571_p0.read()) * sc_bigint<5>(mul_ln1118_1199_fu_75571_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_119_fu_54417_p0() {
    mul_ln1118_119_fu_54417_p0 =  (sc_lv<12>) (sext_ln1116_119_cast_fu_54411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_119_fu_54417_p1() {
    mul_ln1118_119_fu_54417_p1 = tmp_119_reg_96754.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_119_fu_54417_p2() {
    mul_ln1118_119_fu_54417_p2 = (!mul_ln1118_119_fu_54417_p0.read().is_01() || !mul_ln1118_119_fu_54417_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_119_fu_54417_p0.read()) * sc_bigint<5>(mul_ln1118_119_fu_54417_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_11_fu_52581_p0() {
    mul_ln1118_11_fu_52581_p0 =  (sc_lv<12>) (sext_ln1116_11_cast_fu_52575_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_11_fu_52581_p1() {
    mul_ln1118_11_fu_52581_p1 = tmp_12_reg_95770.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_11_fu_52581_p2() {
    mul_ln1118_11_fu_52581_p2 = (!mul_ln1118_11_fu_52581_p0.read().is_01() || !mul_ln1118_11_fu_52581_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_11_fu_52581_p0.read()) * sc_bigint<5>(mul_ln1118_11_fu_52581_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1200_fu_75590_p0() {
    mul_ln1118_1200_fu_75590_p0 =  (sc_lv<12>) (sext_ln1116_200_cast_fu_55869_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1200_fu_75590_p1() {
    mul_ln1118_1200_fu_75590_p1 = tmp_1200_reg_102557.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1200_fu_75590_p2() {
    mul_ln1118_1200_fu_75590_p2 = (!mul_ln1118_1200_fu_75590_p0.read().is_01() || !mul_ln1118_1200_fu_75590_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1200_fu_75590_p0.read()) * sc_bigint<5>(mul_ln1118_1200_fu_75590_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1201_fu_75609_p0() {
    mul_ln1118_1201_fu_75609_p0 =  (sc_lv<12>) (sext_ln1116_201_cast_reg_97536.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1201_fu_75609_p1() {
    mul_ln1118_1201_fu_75609_p1 = tmp_1201_reg_102562.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1201_fu_75609_p2() {
    mul_ln1118_1201_fu_75609_p2 = (!mul_ln1118_1201_fu_75609_p0.read().is_01() || !mul_ln1118_1201_fu_75609_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1201_fu_75609_p0.read()) * sc_bigint<5>(mul_ln1118_1201_fu_75609_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1202_fu_75627_p0() {
    mul_ln1118_1202_fu_75627_p0 =  (sc_lv<12>) (sext_ln1116_202_cast_reg_97554.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1202_fu_75627_p1() {
    mul_ln1118_1202_fu_75627_p1 = tmp_1202_reg_102567.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1202_fu_75627_p2() {
    mul_ln1118_1202_fu_75627_p2 = (!mul_ln1118_1202_fu_75627_p0.read().is_01() || !mul_ln1118_1202_fu_75627_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1202_fu_75627_p0.read()) * sc_bigint<5>(mul_ln1118_1202_fu_75627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1203_fu_40765_p0() {
    mul_ln1118_1203_fu_40765_p0 =  (sc_lv<12>) (sext_ln1116_203_cast_fu_26297_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1203_fu_40765_p1() {
    mul_ln1118_1203_fu_40765_p1 = tmp_1203_fu_40751_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1203_fu_40765_p2() {
    mul_ln1118_1203_fu_40765_p2 = (!mul_ln1118_1203_fu_40765_p0.read().is_01() || !mul_ln1118_1203_fu_40765_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1203_fu_40765_p0.read()) * sc_bigint<5>(mul_ln1118_1203_fu_40765_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1204_fu_40795_p0() {
    mul_ln1118_1204_fu_40795_p0 =  (sc_lv<12>) (sext_ln1116_204_cast_fu_26339_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1204_fu_40795_p1() {
    mul_ln1118_1204_fu_40795_p1 = tmp_1204_fu_40781_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1204_fu_40795_p2() {
    mul_ln1118_1204_fu_40795_p2 = (!mul_ln1118_1204_fu_40795_p0.read().is_01() || !mul_ln1118_1204_fu_40795_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1204_fu_40795_p0.read()) * sc_bigint<5>(mul_ln1118_1204_fu_40795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1205_fu_40825_p0() {
    mul_ln1118_1205_fu_40825_p0 =  (sc_lv<12>) (sext_ln1116_205_cast_fu_26381_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1205_fu_40825_p1() {
    mul_ln1118_1205_fu_40825_p1 = tmp_1205_fu_40811_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1205_fu_40825_p2() {
    mul_ln1118_1205_fu_40825_p2 = (!mul_ln1118_1205_fu_40825_p0.read().is_01() || !mul_ln1118_1205_fu_40825_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1205_fu_40825_p0.read()) * sc_bigint<5>(mul_ln1118_1205_fu_40825_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1206_fu_40855_p0() {
    mul_ln1118_1206_fu_40855_p0 =  (sc_lv<12>) (sext_ln1116_206_cast_fu_26423_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1206_fu_40855_p1() {
    mul_ln1118_1206_fu_40855_p1 = tmp_1206_fu_40841_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1206_fu_40855_p2() {
    mul_ln1118_1206_fu_40855_p2 = (!mul_ln1118_1206_fu_40855_p0.read().is_01() || !mul_ln1118_1206_fu_40855_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1206_fu_40855_p0.read()) * sc_bigint<5>(mul_ln1118_1206_fu_40855_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1207_fu_40885_p0() {
    mul_ln1118_1207_fu_40885_p0 =  (sc_lv<12>) (sext_ln1116_207_cast_fu_26465_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1207_fu_40885_p1() {
    mul_ln1118_1207_fu_40885_p1 = tmp_1207_fu_40871_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1207_fu_40885_p2() {
    mul_ln1118_1207_fu_40885_p2 = (!mul_ln1118_1207_fu_40885_p0.read().is_01() || !mul_ln1118_1207_fu_40885_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1207_fu_40885_p0.read()) * sc_bigint<5>(mul_ln1118_1207_fu_40885_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1208_fu_40915_p0() {
    mul_ln1118_1208_fu_40915_p0 =  (sc_lv<12>) (sext_ln1116_208_cast_fu_26507_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1208_fu_40915_p1() {
    mul_ln1118_1208_fu_40915_p1 = tmp_1208_fu_40901_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1208_fu_40915_p2() {
    mul_ln1118_1208_fu_40915_p2 = (!mul_ln1118_1208_fu_40915_p0.read().is_01() || !mul_ln1118_1208_fu_40915_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1208_fu_40915_p0.read()) * sc_bigint<5>(mul_ln1118_1208_fu_40915_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1209_fu_76633_p0() {
    mul_ln1118_1209_fu_76633_p0 =  (sc_lv<12>) (sext_ln1116_cast_fu_52531_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1209_fu_76633_p1() {
    mul_ln1118_1209_fu_76633_p1 = tmp_1209_reg_102602.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1209_fu_76633_p2() {
    mul_ln1118_1209_fu_76633_p2 = (!mul_ln1118_1209_fu_76633_p0.read().is_01() || !mul_ln1118_1209_fu_76633_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1209_fu_76633_p0.read()) * sc_bigint<5>(mul_ln1118_1209_fu_76633_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_120_fu_54439_p0() {
    mul_ln1118_120_fu_54439_p0 =  (sc_lv<12>) (sext_ln1116_120_cast_fu_54433_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_120_fu_54439_p1() {
    mul_ln1118_120_fu_54439_p1 = tmp_120_reg_96764.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_120_fu_54439_p2() {
    mul_ln1118_120_fu_54439_p2 = (!mul_ln1118_120_fu_54439_p0.read().is_01() || !mul_ln1118_120_fu_54439_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_120_fu_54439_p0.read()) * sc_bigint<5>(mul_ln1118_120_fu_54439_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1210_fu_76652_p0() {
    mul_ln1118_1210_fu_76652_p0 =  (sc_lv<12>) (sext_ln1116_10_cast_fu_52553_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1210_fu_76652_p1() {
    mul_ln1118_1210_fu_76652_p1 = tmp_1210_reg_102607.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1210_fu_76652_p2() {
    mul_ln1118_1210_fu_76652_p2 = (!mul_ln1118_1210_fu_76652_p0.read().is_01() || !mul_ln1118_1210_fu_76652_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1210_fu_76652_p0.read()) * sc_bigint<5>(mul_ln1118_1210_fu_76652_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1211_fu_76671_p0() {
    mul_ln1118_1211_fu_76671_p0 =  (sc_lv<12>) (sext_ln1116_11_cast_fu_52575_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1211_fu_76671_p1() {
    mul_ln1118_1211_fu_76671_p1 = tmp_1211_reg_102612.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1211_fu_76671_p2() {
    mul_ln1118_1211_fu_76671_p2 = (!mul_ln1118_1211_fu_76671_p0.read().is_01() || !mul_ln1118_1211_fu_76671_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1211_fu_76671_p0.read()) * sc_bigint<5>(mul_ln1118_1211_fu_76671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1212_fu_76690_p0() {
    mul_ln1118_1212_fu_76690_p0 =  (sc_lv<12>) (sext_ln1116_12_cast_fu_52597_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1212_fu_76690_p1() {
    mul_ln1118_1212_fu_76690_p1 = tmp_1212_reg_102617.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1212_fu_76690_p2() {
    mul_ln1118_1212_fu_76690_p2 = (!mul_ln1118_1212_fu_76690_p0.read().is_01() || !mul_ln1118_1212_fu_76690_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1212_fu_76690_p0.read()) * sc_bigint<5>(mul_ln1118_1212_fu_76690_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1213_fu_76709_p0() {
    mul_ln1118_1213_fu_76709_p0 =  (sc_lv<12>) (sext_ln1116_13_cast_fu_52619_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1213_fu_76709_p1() {
    mul_ln1118_1213_fu_76709_p1 = tmp_1213_reg_102622.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1213_fu_76709_p2() {
    mul_ln1118_1213_fu_76709_p2 = (!mul_ln1118_1213_fu_76709_p0.read().is_01() || !mul_ln1118_1213_fu_76709_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1213_fu_76709_p0.read()) * sc_bigint<5>(mul_ln1118_1213_fu_76709_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1214_fu_76728_p0() {
    mul_ln1118_1214_fu_76728_p0 =  (sc_lv<12>) (sext_ln1116_14_cast_fu_52641_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1214_fu_76728_p1() {
    mul_ln1118_1214_fu_76728_p1 = tmp_1214_reg_102627.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1214_fu_76728_p2() {
    mul_ln1118_1214_fu_76728_p2 = (!mul_ln1118_1214_fu_76728_p0.read().is_01() || !mul_ln1118_1214_fu_76728_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1214_fu_76728_p0.read()) * sc_bigint<5>(mul_ln1118_1214_fu_76728_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1215_fu_76747_p0() {
    mul_ln1118_1215_fu_76747_p0 =  (sc_lv<12>) (sext_ln1116_15_cast_fu_52663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1215_fu_76747_p1() {
    mul_ln1118_1215_fu_76747_p1 = tmp_1215_reg_102632.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1215_fu_76747_p2() {
    mul_ln1118_1215_fu_76747_p2 = (!mul_ln1118_1215_fu_76747_p0.read().is_01() || !mul_ln1118_1215_fu_76747_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1215_fu_76747_p0.read()) * sc_bigint<5>(mul_ln1118_1215_fu_76747_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1216_fu_76766_p0() {
    mul_ln1118_1216_fu_76766_p0 =  (sc_lv<12>) (sext_ln1116_16_cast_fu_52685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1216_fu_76766_p1() {
    mul_ln1118_1216_fu_76766_p1 = tmp_1216_reg_102637.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1216_fu_76766_p2() {
    mul_ln1118_1216_fu_76766_p2 = (!mul_ln1118_1216_fu_76766_p0.read().is_01() || !mul_ln1118_1216_fu_76766_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1216_fu_76766_p0.read()) * sc_bigint<5>(mul_ln1118_1216_fu_76766_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1217_fu_76785_p0() {
    mul_ln1118_1217_fu_76785_p0 =  (sc_lv<12>) (sext_ln1116_17_cast_fu_52707_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1217_fu_76785_p1() {
    mul_ln1118_1217_fu_76785_p1 = tmp_1217_reg_102642.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1217_fu_76785_p2() {
    mul_ln1118_1217_fu_76785_p2 = (!mul_ln1118_1217_fu_76785_p0.read().is_01() || !mul_ln1118_1217_fu_76785_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1217_fu_76785_p0.read()) * sc_bigint<5>(mul_ln1118_1217_fu_76785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1218_fu_76804_p0() {
    mul_ln1118_1218_fu_76804_p0 =  (sc_lv<12>) (sext_ln1116_18_cast_fu_52729_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1218_fu_76804_p1() {
    mul_ln1118_1218_fu_76804_p1 = tmp_1218_reg_102647.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1218_fu_76804_p2() {
    mul_ln1118_1218_fu_76804_p2 = (!mul_ln1118_1218_fu_76804_p0.read().is_01() || !mul_ln1118_1218_fu_76804_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1218_fu_76804_p0.read()) * sc_bigint<5>(mul_ln1118_1218_fu_76804_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1219_fu_76823_p0() {
    mul_ln1118_1219_fu_76823_p0 =  (sc_lv<12>) (sext_ln1116_19_cast_fu_52751_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1219_fu_76823_p1() {
    mul_ln1118_1219_fu_76823_p1 = tmp_1219_reg_102652.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1219_fu_76823_p2() {
    mul_ln1118_1219_fu_76823_p2 = (!mul_ln1118_1219_fu_76823_p0.read().is_01() || !mul_ln1118_1219_fu_76823_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1219_fu_76823_p0.read()) * sc_bigint<5>(mul_ln1118_1219_fu_76823_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_121_fu_54461_p0() {
    mul_ln1118_121_fu_54461_p0 =  (sc_lv<12>) (sext_ln1116_121_cast_fu_54455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_121_fu_54461_p1() {
    mul_ln1118_121_fu_54461_p1 = tmp_121_reg_96774.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_121_fu_54461_p2() {
    mul_ln1118_121_fu_54461_p2 = (!mul_ln1118_121_fu_54461_p0.read().is_01() || !mul_ln1118_121_fu_54461_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_121_fu_54461_p0.read()) * sc_bigint<5>(mul_ln1118_121_fu_54461_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1220_fu_76842_p0() {
    mul_ln1118_1220_fu_76842_p0 =  (sc_lv<12>) (sext_ln1116_20_cast_fu_52773_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1220_fu_76842_p1() {
    mul_ln1118_1220_fu_76842_p1 = tmp_1220_reg_102657.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1220_fu_76842_p2() {
    mul_ln1118_1220_fu_76842_p2 = (!mul_ln1118_1220_fu_76842_p0.read().is_01() || !mul_ln1118_1220_fu_76842_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1220_fu_76842_p0.read()) * sc_bigint<5>(mul_ln1118_1220_fu_76842_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1221_fu_76861_p0() {
    mul_ln1118_1221_fu_76861_p0 =  (sc_lv<12>) (sext_ln1116_21_cast_fu_52795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1221_fu_76861_p1() {
    mul_ln1118_1221_fu_76861_p1 = tmp_1221_reg_102662.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1221_fu_76861_p2() {
    mul_ln1118_1221_fu_76861_p2 = (!mul_ln1118_1221_fu_76861_p0.read().is_01() || !mul_ln1118_1221_fu_76861_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1221_fu_76861_p0.read()) * sc_bigint<5>(mul_ln1118_1221_fu_76861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1222_fu_76880_p0() {
    mul_ln1118_1222_fu_76880_p0 =  (sc_lv<12>) (sext_ln1116_22_cast_fu_52817_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1222_fu_76880_p1() {
    mul_ln1118_1222_fu_76880_p1 = tmp_1222_reg_102667.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1222_fu_76880_p2() {
    mul_ln1118_1222_fu_76880_p2 = (!mul_ln1118_1222_fu_76880_p0.read().is_01() || !mul_ln1118_1222_fu_76880_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1222_fu_76880_p0.read()) * sc_bigint<5>(mul_ln1118_1222_fu_76880_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1223_fu_76899_p0() {
    mul_ln1118_1223_fu_76899_p0 =  (sc_lv<12>) (sext_ln1116_23_cast_fu_52839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1223_fu_76899_p1() {
    mul_ln1118_1223_fu_76899_p1 = tmp_1223_reg_102672.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1223_fu_76899_p2() {
    mul_ln1118_1223_fu_76899_p2 = (!mul_ln1118_1223_fu_76899_p0.read().is_01() || !mul_ln1118_1223_fu_76899_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1223_fu_76899_p0.read()) * sc_bigint<5>(mul_ln1118_1223_fu_76899_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1224_fu_76918_p0() {
    mul_ln1118_1224_fu_76918_p0 =  (sc_lv<12>) (sext_ln1116_24_cast_fu_52861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1224_fu_76918_p1() {
    mul_ln1118_1224_fu_76918_p1 = tmp_1224_reg_102677.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1224_fu_76918_p2() {
    mul_ln1118_1224_fu_76918_p2 = (!mul_ln1118_1224_fu_76918_p0.read().is_01() || !mul_ln1118_1224_fu_76918_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1224_fu_76918_p0.read()) * sc_bigint<5>(mul_ln1118_1224_fu_76918_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1225_fu_76937_p0() {
    mul_ln1118_1225_fu_76937_p0 =  (sc_lv<12>) (sext_ln1116_25_cast_fu_52883_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1225_fu_76937_p1() {
    mul_ln1118_1225_fu_76937_p1 = tmp_1225_reg_102682.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1225_fu_76937_p2() {
    mul_ln1118_1225_fu_76937_p2 = (!mul_ln1118_1225_fu_76937_p0.read().is_01() || !mul_ln1118_1225_fu_76937_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1225_fu_76937_p0.read()) * sc_bigint<5>(mul_ln1118_1225_fu_76937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1226_fu_76956_p0() {
    mul_ln1118_1226_fu_76956_p0 =  (sc_lv<12>) (sext_ln1116_26_cast_fu_52905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1226_fu_76956_p1() {
    mul_ln1118_1226_fu_76956_p1 = tmp_1226_reg_102687.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1226_fu_76956_p2() {
    mul_ln1118_1226_fu_76956_p2 = (!mul_ln1118_1226_fu_76956_p0.read().is_01() || !mul_ln1118_1226_fu_76956_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1226_fu_76956_p0.read()) * sc_bigint<5>(mul_ln1118_1226_fu_76956_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1227_fu_76975_p0() {
    mul_ln1118_1227_fu_76975_p0 =  (sc_lv<12>) (sext_ln1116_27_cast_fu_52927_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1227_fu_76975_p1() {
    mul_ln1118_1227_fu_76975_p1 = tmp_1227_reg_102692.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1227_fu_76975_p2() {
    mul_ln1118_1227_fu_76975_p2 = (!mul_ln1118_1227_fu_76975_p0.read().is_01() || !mul_ln1118_1227_fu_76975_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1227_fu_76975_p0.read()) * sc_bigint<5>(mul_ln1118_1227_fu_76975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1228_fu_41135_p0() {
    mul_ln1118_1228_fu_41135_p0 =  (sc_lv<12>) (sext_ln1116_28_cast_fu_22199_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1228_fu_41135_p1() {
    mul_ln1118_1228_fu_41135_p1 = tmp_1228_fu_41121_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1228_fu_41135_p2() {
    mul_ln1118_1228_fu_41135_p2 = (!mul_ln1118_1228_fu_41135_p0.read().is_01() || !mul_ln1118_1228_fu_41135_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1228_fu_41135_p0.read()) * sc_bigint<5>(mul_ln1118_1228_fu_41135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1229_fu_41165_p0() {
    mul_ln1118_1229_fu_41165_p0 =  (sc_lv<12>) (sext_ln1116_29_cast_fu_22241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1229_fu_41165_p1() {
    mul_ln1118_1229_fu_41165_p1 = tmp_1229_fu_41151_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1229_fu_41165_p2() {
    mul_ln1118_1229_fu_41165_p2 = (!mul_ln1118_1229_fu_41165_p0.read().is_01() || !mul_ln1118_1229_fu_41165_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1229_fu_41165_p0.read()) * sc_bigint<5>(mul_ln1118_1229_fu_41165_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_122_fu_54483_p0() {
    mul_ln1118_122_fu_54483_p0 =  (sc_lv<12>) (sext_ln1116_122_cast_fu_54477_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_122_fu_54483_p1() {
    mul_ln1118_122_fu_54483_p1 = tmp_122_reg_96784.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_122_fu_54483_p2() {
    mul_ln1118_122_fu_54483_p2 = (!mul_ln1118_122_fu_54483_p0.read().is_01() || !mul_ln1118_122_fu_54483_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_122_fu_54483_p0.read()) * sc_bigint<5>(mul_ln1118_122_fu_54483_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1230_fu_41195_p0() {
    mul_ln1118_1230_fu_41195_p0 =  (sc_lv<12>) (sext_ln1116_30_cast_fu_22283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1230_fu_41195_p1() {
    mul_ln1118_1230_fu_41195_p1 = tmp_1230_fu_41181_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1230_fu_41195_p2() {
    mul_ln1118_1230_fu_41195_p2 = (!mul_ln1118_1230_fu_41195_p0.read().is_01() || !mul_ln1118_1230_fu_41195_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1230_fu_41195_p0.read()) * sc_bigint<5>(mul_ln1118_1230_fu_41195_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1231_fu_41225_p0() {
    mul_ln1118_1231_fu_41225_p0 =  (sc_lv<12>) (sext_ln1116_31_cast_fu_22325_p1.read());
}

}

