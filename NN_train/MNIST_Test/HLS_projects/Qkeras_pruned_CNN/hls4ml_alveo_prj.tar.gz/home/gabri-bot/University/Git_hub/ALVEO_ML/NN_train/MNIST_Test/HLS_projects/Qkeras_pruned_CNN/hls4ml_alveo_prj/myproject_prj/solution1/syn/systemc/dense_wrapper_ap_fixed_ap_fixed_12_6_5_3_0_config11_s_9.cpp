#include "dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1832_fu_49895_p0() {
    mul_ln1118_1832_fu_49895_p0 =  (sc_lv<12>) (sext_ln1116_32_cast_fu_22367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1832_fu_49895_p1() {
    mul_ln1118_1832_fu_49895_p1 = tmp_1832_fu_49881_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1832_fu_49895_p2() {
    mul_ln1118_1832_fu_49895_p2 = (!mul_ln1118_1832_fu_49895_p0.read().is_01() || !mul_ln1118_1832_fu_49895_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1832_fu_49895_p0.read()) * sc_bigint<5>(mul_ln1118_1832_fu_49895_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1833_fu_49925_p0() {
    mul_ln1118_1833_fu_49925_p0 =  (sc_lv<12>) (sext_ln1116_33_cast_fu_22409_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1833_fu_49925_p1() {
    mul_ln1118_1833_fu_49925_p1 = tmp_1833_fu_49911_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1833_fu_49925_p2() {
    mul_ln1118_1833_fu_49925_p2 = (!mul_ln1118_1833_fu_49925_p0.read().is_01() || !mul_ln1118_1833_fu_49925_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1833_fu_49925_p0.read()) * sc_bigint<5>(mul_ln1118_1833_fu_49925_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1834_fu_88823_p0() {
    mul_ln1118_1834_fu_88823_p0 =  (sc_lv<12>) (sext_ln1116_34_cast_fu_52949_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1834_fu_88823_p1() {
    mul_ln1118_1834_fu_88823_p1 = tmp_1834_reg_105727.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1834_fu_88823_p2() {
    mul_ln1118_1834_fu_88823_p2 = (!mul_ln1118_1834_fu_88823_p0.read().is_01() || !mul_ln1118_1834_fu_88823_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1834_fu_88823_p0.read()) * sc_bigint<5>(mul_ln1118_1834_fu_88823_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1835_fu_88842_p0() {
    mul_ln1118_1835_fu_88842_p0 =  (sc_lv<12>) (sext_ln1116_35_cast_fu_52971_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1835_fu_88842_p1() {
    mul_ln1118_1835_fu_88842_p1 = tmp_1835_reg_105732.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1835_fu_88842_p2() {
    mul_ln1118_1835_fu_88842_p2 = (!mul_ln1118_1835_fu_88842_p0.read().is_01() || !mul_ln1118_1835_fu_88842_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1835_fu_88842_p0.read()) * sc_bigint<5>(mul_ln1118_1835_fu_88842_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1836_fu_88861_p0() {
    mul_ln1118_1836_fu_88861_p0 =  (sc_lv<12>) (sext_ln1116_36_cast_fu_52993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1836_fu_88861_p1() {
    mul_ln1118_1836_fu_88861_p1 = tmp_1836_reg_105737.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1836_fu_88861_p2() {
    mul_ln1118_1836_fu_88861_p2 = (!mul_ln1118_1836_fu_88861_p0.read().is_01() || !mul_ln1118_1836_fu_88861_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1836_fu_88861_p0.read()) * sc_bigint<5>(mul_ln1118_1836_fu_88861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1837_fu_88880_p0() {
    mul_ln1118_1837_fu_88880_p0 =  (sc_lv<12>) (sext_ln1116_37_cast_fu_53015_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1837_fu_88880_p1() {
    mul_ln1118_1837_fu_88880_p1 = tmp_1837_reg_105742.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1837_fu_88880_p2() {
    mul_ln1118_1837_fu_88880_p2 = (!mul_ln1118_1837_fu_88880_p0.read().is_01() || !mul_ln1118_1837_fu_88880_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1837_fu_88880_p0.read()) * sc_bigint<5>(mul_ln1118_1837_fu_88880_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1838_fu_88899_p0() {
    mul_ln1118_1838_fu_88899_p0 =  (sc_lv<12>) (sext_ln1116_38_cast_fu_53037_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1838_fu_88899_p1() {
    mul_ln1118_1838_fu_88899_p1 = tmp_1838_reg_105747.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1838_fu_88899_p2() {
    mul_ln1118_1838_fu_88899_p2 = (!mul_ln1118_1838_fu_88899_p0.read().is_01() || !mul_ln1118_1838_fu_88899_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1838_fu_88899_p0.read()) * sc_bigint<5>(mul_ln1118_1838_fu_88899_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1839_fu_88918_p0() {
    mul_ln1118_1839_fu_88918_p0 =  (sc_lv<12>) (sext_ln1116_39_cast_fu_53059_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1839_fu_88918_p1() {
    mul_ln1118_1839_fu_88918_p1 = tmp_1839_reg_105752.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1839_fu_88918_p2() {
    mul_ln1118_1839_fu_88918_p2 = (!mul_ln1118_1839_fu_88918_p0.read().is_01() || !mul_ln1118_1839_fu_88918_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1839_fu_88918_p0.read()) * sc_bigint<5>(mul_ln1118_1839_fu_88918_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_183_fu_25913_p0() {
    mul_ln1118_183_fu_25913_p0 =  (sc_lv<12>) (sext_ln1116_183_cast_fu_25905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_183_fu_25913_p1() {
    mul_ln1118_183_fu_25913_p1 = tmp_183_fu_25895_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_183_fu_25913_p2() {
    mul_ln1118_183_fu_25913_p2 = (!mul_ln1118_183_fu_25913_p0.read().is_01() || !mul_ln1118_183_fu_25913_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_183_fu_25913_p0.read()) * sc_bigint<5>(mul_ln1118_183_fu_25913_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1840_fu_88937_p0() {
    mul_ln1118_1840_fu_88937_p0 =  (sc_lv<12>) (sext_ln1116_40_cast_fu_53081_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1840_fu_88937_p1() {
    mul_ln1118_1840_fu_88937_p1 = tmp_1840_reg_105757.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1840_fu_88937_p2() {
    mul_ln1118_1840_fu_88937_p2 = (!mul_ln1118_1840_fu_88937_p0.read().is_01() || !mul_ln1118_1840_fu_88937_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1840_fu_88937_p0.read()) * sc_bigint<5>(mul_ln1118_1840_fu_88937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1841_fu_88956_p0() {
    mul_ln1118_1841_fu_88956_p0 =  (sc_lv<12>) (sext_ln1116_41_cast_fu_53103_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1841_fu_88956_p1() {
    mul_ln1118_1841_fu_88956_p1 = tmp_1841_reg_105762.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1841_fu_88956_p2() {
    mul_ln1118_1841_fu_88956_p2 = (!mul_ln1118_1841_fu_88956_p0.read().is_01() || !mul_ln1118_1841_fu_88956_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1841_fu_88956_p0.read()) * sc_bigint<5>(mul_ln1118_1841_fu_88956_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1842_fu_88975_p0() {
    mul_ln1118_1842_fu_88975_p0 =  (sc_lv<12>) (sext_ln1116_42_cast_fu_53125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1842_fu_88975_p1() {
    mul_ln1118_1842_fu_88975_p1 = tmp_1842_reg_105767.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1842_fu_88975_p2() {
    mul_ln1118_1842_fu_88975_p2 = (!mul_ln1118_1842_fu_88975_p0.read().is_01() || !mul_ln1118_1842_fu_88975_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1842_fu_88975_p0.read()) * sc_bigint<5>(mul_ln1118_1842_fu_88975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1843_fu_88994_p0() {
    mul_ln1118_1843_fu_88994_p0 =  (sc_lv<12>) (sext_ln1116_43_cast_fu_53147_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1843_fu_88994_p1() {
    mul_ln1118_1843_fu_88994_p1 = tmp_1843_reg_105772.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1843_fu_88994_p2() {
    mul_ln1118_1843_fu_88994_p2 = (!mul_ln1118_1843_fu_88994_p0.read().is_01() || !mul_ln1118_1843_fu_88994_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1843_fu_88994_p0.read()) * sc_bigint<5>(mul_ln1118_1843_fu_88994_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1844_fu_89013_p0() {
    mul_ln1118_1844_fu_89013_p0 =  (sc_lv<12>) (sext_ln1116_44_cast_fu_53169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1844_fu_89013_p1() {
    mul_ln1118_1844_fu_89013_p1 = tmp_1844_reg_105777.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1844_fu_89013_p2() {
    mul_ln1118_1844_fu_89013_p2 = (!mul_ln1118_1844_fu_89013_p0.read().is_01() || !mul_ln1118_1844_fu_89013_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1844_fu_89013_p0.read()) * sc_bigint<5>(mul_ln1118_1844_fu_89013_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1845_fu_89032_p0() {
    mul_ln1118_1845_fu_89032_p0 =  (sc_lv<12>) (sext_ln1116_45_cast_fu_53191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1845_fu_89032_p1() {
    mul_ln1118_1845_fu_89032_p1 = tmp_1845_reg_105782.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1845_fu_89032_p2() {
    mul_ln1118_1845_fu_89032_p2 = (!mul_ln1118_1845_fu_89032_p0.read().is_01() || !mul_ln1118_1845_fu_89032_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1845_fu_89032_p0.read()) * sc_bigint<5>(mul_ln1118_1845_fu_89032_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1846_fu_89051_p0() {
    mul_ln1118_1846_fu_89051_p0 =  (sc_lv<12>) (sext_ln1116_46_cast_fu_53213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1846_fu_89051_p1() {
    mul_ln1118_1846_fu_89051_p1 = tmp_1846_reg_105787.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1846_fu_89051_p2() {
    mul_ln1118_1846_fu_89051_p2 = (!mul_ln1118_1846_fu_89051_p0.read().is_01() || !mul_ln1118_1846_fu_89051_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1846_fu_89051_p0.read()) * sc_bigint<5>(mul_ln1118_1846_fu_89051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1847_fu_89070_p0() {
    mul_ln1118_1847_fu_89070_p0 =  (sc_lv<12>) (sext_ln1116_47_cast_fu_53235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1847_fu_89070_p1() {
    mul_ln1118_1847_fu_89070_p1 = tmp_1847_reg_105792.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1847_fu_89070_p2() {
    mul_ln1118_1847_fu_89070_p2 = (!mul_ln1118_1847_fu_89070_p0.read().is_01() || !mul_ln1118_1847_fu_89070_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1847_fu_89070_p0.read()) * sc_bigint<5>(mul_ln1118_1847_fu_89070_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1848_fu_89089_p0() {
    mul_ln1118_1848_fu_89089_p0 =  (sc_lv<12>) (sext_ln1116_48_cast_fu_53257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1848_fu_89089_p1() {
    mul_ln1118_1848_fu_89089_p1 = tmp_1848_reg_105797.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1848_fu_89089_p2() {
    mul_ln1118_1848_fu_89089_p2 = (!mul_ln1118_1848_fu_89089_p0.read().is_01() || !mul_ln1118_1848_fu_89089_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1848_fu_89089_p0.read()) * sc_bigint<5>(mul_ln1118_1848_fu_89089_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1849_fu_89108_p0() {
    mul_ln1118_1849_fu_89108_p0 =  (sc_lv<12>) (sext_ln1116_49_cast_fu_53279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1849_fu_89108_p1() {
    mul_ln1118_1849_fu_89108_p1 = tmp_1849_reg_105802.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1849_fu_89108_p2() {
    mul_ln1118_1849_fu_89108_p2 = (!mul_ln1118_1849_fu_89108_p0.read().is_01() || !mul_ln1118_1849_fu_89108_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1849_fu_89108_p0.read()) * sc_bigint<5>(mul_ln1118_1849_fu_89108_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_184_fu_55523_p0() {
    mul_ln1118_184_fu_55523_p0 =  (sc_lv<12>) (sext_ln1116_184_cast_fu_55517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_184_fu_55523_p1() {
    mul_ln1118_184_fu_55523_p1 = tmp_184_reg_97366.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_184_fu_55523_p2() {
    mul_ln1118_184_fu_55523_p2 = (!mul_ln1118_184_fu_55523_p0.read().is_01() || !mul_ln1118_184_fu_55523_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_184_fu_55523_p0.read()) * sc_bigint<5>(mul_ln1118_184_fu_55523_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1850_fu_89127_p0() {
    mul_ln1118_1850_fu_89127_p0 =  (sc_lv<12>) (sext_ln1116_50_cast_fu_53301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1850_fu_89127_p1() {
    mul_ln1118_1850_fu_89127_p1 = tmp_1850_reg_105807.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1850_fu_89127_p2() {
    mul_ln1118_1850_fu_89127_p2 = (!mul_ln1118_1850_fu_89127_p0.read().is_01() || !mul_ln1118_1850_fu_89127_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1850_fu_89127_p0.read()) * sc_bigint<5>(mul_ln1118_1850_fu_89127_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1851_fu_89146_p0() {
    mul_ln1118_1851_fu_89146_p0 =  (sc_lv<12>) (sext_ln1116_51_cast_fu_53323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1851_fu_89146_p1() {
    mul_ln1118_1851_fu_89146_p1 = tmp_1851_reg_105812.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1851_fu_89146_p2() {
    mul_ln1118_1851_fu_89146_p2 = (!mul_ln1118_1851_fu_89146_p0.read().is_01() || !mul_ln1118_1851_fu_89146_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1851_fu_89146_p0.read()) * sc_bigint<5>(mul_ln1118_1851_fu_89146_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1852_fu_50135_p0() {
    mul_ln1118_1852_fu_50135_p0 = select_ln76_43_fu_22757_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1852_fu_50135_p1() {
    mul_ln1118_1852_fu_50135_p1 = tmp_1852_fu_50121_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1852_fu_50135_p2() {
    mul_ln1118_1852_fu_50135_p2 = (!mul_ln1118_1852_fu_50135_p0.read().is_01() || !mul_ln1118_1852_fu_50135_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1852_fu_50135_p0.read()) * sc_bigint<5>(mul_ln1118_1852_fu_50135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1853_fu_50165_p0() {
    mul_ln1118_1853_fu_50165_p0 =  (sc_lv<12>) (sext_ln1116_53_cast_fu_22797_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1853_fu_50165_p1() {
    mul_ln1118_1853_fu_50165_p1 = tmp_1853_fu_50151_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1853_fu_50165_p2() {
    mul_ln1118_1853_fu_50165_p2 = (!mul_ln1118_1853_fu_50165_p0.read().is_01() || !mul_ln1118_1853_fu_50165_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1853_fu_50165_p0.read()) * sc_bigint<5>(mul_ln1118_1853_fu_50165_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1854_fu_50195_p0() {
    mul_ln1118_1854_fu_50195_p0 =  (sc_lv<12>) (sext_ln1116_54_cast_fu_22839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1854_fu_50195_p1() {
    mul_ln1118_1854_fu_50195_p1 = tmp_1854_fu_50181_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1854_fu_50195_p2() {
    mul_ln1118_1854_fu_50195_p2 = (!mul_ln1118_1854_fu_50195_p0.read().is_01() || !mul_ln1118_1854_fu_50195_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1854_fu_50195_p0.read()) * sc_bigint<5>(mul_ln1118_1854_fu_50195_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1855_fu_50225_p0() {
    mul_ln1118_1855_fu_50225_p0 =  (sc_lv<12>) (sext_ln1116_55_cast_fu_22881_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1855_fu_50225_p1() {
    mul_ln1118_1855_fu_50225_p1 = tmp_1855_fu_50211_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1855_fu_50225_p2() {
    mul_ln1118_1855_fu_50225_p2 = (!mul_ln1118_1855_fu_50225_p0.read().is_01() || !mul_ln1118_1855_fu_50225_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1855_fu_50225_p0.read()) * sc_bigint<5>(mul_ln1118_1855_fu_50225_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1856_fu_50255_p0() {
    mul_ln1118_1856_fu_50255_p0 =  (sc_lv<12>) (sext_ln1116_56_cast_fu_22923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1856_fu_50255_p1() {
    mul_ln1118_1856_fu_50255_p1 = tmp_1856_fu_50241_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1856_fu_50255_p2() {
    mul_ln1118_1856_fu_50255_p2 = (!mul_ln1118_1856_fu_50255_p0.read().is_01() || !mul_ln1118_1856_fu_50255_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1856_fu_50255_p0.read()) * sc_bigint<5>(mul_ln1118_1856_fu_50255_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1857_fu_50285_p0() {
    mul_ln1118_1857_fu_50285_p0 =  (sc_lv<12>) (sext_ln1116_57_cast_fu_22965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1857_fu_50285_p1() {
    mul_ln1118_1857_fu_50285_p1 = tmp_1857_fu_50271_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1857_fu_50285_p2() {
    mul_ln1118_1857_fu_50285_p2 = (!mul_ln1118_1857_fu_50285_p0.read().is_01() || !mul_ln1118_1857_fu_50285_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1857_fu_50285_p0.read()) * sc_bigint<5>(mul_ln1118_1857_fu_50285_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1858_fu_50315_p0() {
    mul_ln1118_1858_fu_50315_p0 =  (sc_lv<12>) (sext_ln1116_58_cast_fu_23007_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1858_fu_50315_p1() {
    mul_ln1118_1858_fu_50315_p1 = tmp_1858_fu_50301_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1858_fu_50315_p2() {
    mul_ln1118_1858_fu_50315_p2 = (!mul_ln1118_1858_fu_50315_p0.read().is_01() || !mul_ln1118_1858_fu_50315_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1858_fu_50315_p0.read()) * sc_bigint<5>(mul_ln1118_1858_fu_50315_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1859_fu_89165_p0() {
    mul_ln1118_1859_fu_89165_p0 =  (sc_lv<12>) (sext_ln1116_59_cast_fu_53363_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1859_fu_89165_p1() {
    mul_ln1118_1859_fu_89165_p1 = tmp_1859_reg_105852.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1859_fu_89165_p2() {
    mul_ln1118_1859_fu_89165_p2 = (!mul_ln1118_1859_fu_89165_p0.read().is_01() || !mul_ln1118_1859_fu_89165_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1859_fu_89165_p0.read()) * sc_bigint<5>(mul_ln1118_1859_fu_89165_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_185_fu_55545_p0() {
    mul_ln1118_185_fu_55545_p0 =  (sc_lv<12>) (sext_ln1116_185_cast_fu_55539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_185_fu_55545_p1() {
    mul_ln1118_185_fu_55545_p1 = tmp_185_reg_97376.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_185_fu_55545_p2() {
    mul_ln1118_185_fu_55545_p2 = (!mul_ln1118_185_fu_55545_p0.read().is_01() || !mul_ln1118_185_fu_55545_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_185_fu_55545_p0.read()) * sc_bigint<5>(mul_ln1118_185_fu_55545_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1860_fu_89184_p0() {
    mul_ln1118_1860_fu_89184_p0 =  (sc_lv<12>) (sext_ln1116_60_cast_fu_53385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1860_fu_89184_p1() {
    mul_ln1118_1860_fu_89184_p1 = tmp_1860_reg_105857.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1860_fu_89184_p2() {
    mul_ln1118_1860_fu_89184_p2 = (!mul_ln1118_1860_fu_89184_p0.read().is_01() || !mul_ln1118_1860_fu_89184_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1860_fu_89184_p0.read()) * sc_bigint<5>(mul_ln1118_1860_fu_89184_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1861_fu_89203_p0() {
    mul_ln1118_1861_fu_89203_p0 =  (sc_lv<12>) (sext_ln1116_61_cast_fu_53407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1861_fu_89203_p1() {
    mul_ln1118_1861_fu_89203_p1 = tmp_1861_reg_105862.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1861_fu_89203_p2() {
    mul_ln1118_1861_fu_89203_p2 = (!mul_ln1118_1861_fu_89203_p0.read().is_01() || !mul_ln1118_1861_fu_89203_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1861_fu_89203_p0.read()) * sc_bigint<5>(mul_ln1118_1861_fu_89203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1862_fu_89222_p0() {
    mul_ln1118_1862_fu_89222_p0 =  (sc_lv<12>) (sext_ln1116_62_cast_fu_53429_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1862_fu_89222_p1() {
    mul_ln1118_1862_fu_89222_p1 = tmp_1862_reg_105867.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1862_fu_89222_p2() {
    mul_ln1118_1862_fu_89222_p2 = (!mul_ln1118_1862_fu_89222_p0.read().is_01() || !mul_ln1118_1862_fu_89222_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1862_fu_89222_p0.read()) * sc_bigint<5>(mul_ln1118_1862_fu_89222_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1863_fu_89241_p0() {
    mul_ln1118_1863_fu_89241_p0 =  (sc_lv<12>) (sext_ln1116_63_cast_fu_53451_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1863_fu_89241_p1() {
    mul_ln1118_1863_fu_89241_p1 = tmp_1863_reg_105872.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1863_fu_89241_p2() {
    mul_ln1118_1863_fu_89241_p2 = (!mul_ln1118_1863_fu_89241_p0.read().is_01() || !mul_ln1118_1863_fu_89241_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1863_fu_89241_p0.read()) * sc_bigint<5>(mul_ln1118_1863_fu_89241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1864_fu_89260_p0() {
    mul_ln1118_1864_fu_89260_p0 =  (sc_lv<12>) (sext_ln1116_64_cast_fu_53473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1864_fu_89260_p1() {
    mul_ln1118_1864_fu_89260_p1 = tmp_1864_reg_105877.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1864_fu_89260_p2() {
    mul_ln1118_1864_fu_89260_p2 = (!mul_ln1118_1864_fu_89260_p0.read().is_01() || !mul_ln1118_1864_fu_89260_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1864_fu_89260_p0.read()) * sc_bigint<5>(mul_ln1118_1864_fu_89260_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1865_fu_89279_p0() {
    mul_ln1118_1865_fu_89279_p0 =  (sc_lv<12>) (sext_ln1116_65_cast_fu_53495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1865_fu_89279_p1() {
    mul_ln1118_1865_fu_89279_p1 = tmp_1865_reg_105882.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1865_fu_89279_p2() {
    mul_ln1118_1865_fu_89279_p2 = (!mul_ln1118_1865_fu_89279_p0.read().is_01() || !mul_ln1118_1865_fu_89279_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1865_fu_89279_p0.read()) * sc_bigint<5>(mul_ln1118_1865_fu_89279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1866_fu_89298_p0() {
    mul_ln1118_1866_fu_89298_p0 =  (sc_lv<12>) (sext_ln1116_66_cast_fu_53517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1866_fu_89298_p1() {
    mul_ln1118_1866_fu_89298_p1 = tmp_1866_reg_105887.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1866_fu_89298_p2() {
    mul_ln1118_1866_fu_89298_p2 = (!mul_ln1118_1866_fu_89298_p0.read().is_01() || !mul_ln1118_1866_fu_89298_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1866_fu_89298_p0.read()) * sc_bigint<5>(mul_ln1118_1866_fu_89298_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1867_fu_89317_p0() {
    mul_ln1118_1867_fu_89317_p0 =  (sc_lv<12>) (sext_ln1116_67_cast_fu_53539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1867_fu_89317_p1() {
    mul_ln1118_1867_fu_89317_p1 = tmp_1867_reg_105892.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1867_fu_89317_p2() {
    mul_ln1118_1867_fu_89317_p2 = (!mul_ln1118_1867_fu_89317_p0.read().is_01() || !mul_ln1118_1867_fu_89317_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1867_fu_89317_p0.read()) * sc_bigint<5>(mul_ln1118_1867_fu_89317_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1868_fu_89336_p0() {
    mul_ln1118_1868_fu_89336_p0 =  (sc_lv<12>) (sext_ln1116_68_cast_fu_53561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1868_fu_89336_p1() {
    mul_ln1118_1868_fu_89336_p1 = tmp_1868_reg_105897.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1868_fu_89336_p2() {
    mul_ln1118_1868_fu_89336_p2 = (!mul_ln1118_1868_fu_89336_p0.read().is_01() || !mul_ln1118_1868_fu_89336_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1868_fu_89336_p0.read()) * sc_bigint<5>(mul_ln1118_1868_fu_89336_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1869_fu_89355_p0() {
    mul_ln1118_1869_fu_89355_p0 =  (sc_lv<12>) (sext_ln1116_69_cast_fu_53583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1869_fu_89355_p1() {
    mul_ln1118_1869_fu_89355_p1 = tmp_1869_reg_105902.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1869_fu_89355_p2() {
    mul_ln1118_1869_fu_89355_p2 = (!mul_ln1118_1869_fu_89355_p0.read().is_01() || !mul_ln1118_1869_fu_89355_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1869_fu_89355_p0.read()) * sc_bigint<5>(mul_ln1118_1869_fu_89355_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_186_fu_55567_p0() {
    mul_ln1118_186_fu_55567_p0 =  (sc_lv<12>) (sext_ln1116_186_cast_fu_55561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_186_fu_55567_p1() {
    mul_ln1118_186_fu_55567_p1 = tmp_186_reg_97386.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_186_fu_55567_p2() {
    mul_ln1118_186_fu_55567_p2 = (!mul_ln1118_186_fu_55567_p0.read().is_01() || !mul_ln1118_186_fu_55567_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_186_fu_55567_p0.read()) * sc_bigint<5>(mul_ln1118_186_fu_55567_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1870_fu_89374_p0() {
    mul_ln1118_1870_fu_89374_p0 =  (sc_lv<12>) (sext_ln1116_70_cast_fu_53605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1870_fu_89374_p1() {
    mul_ln1118_1870_fu_89374_p1 = tmp_1870_reg_105907.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1870_fu_89374_p2() {
    mul_ln1118_1870_fu_89374_p2 = (!mul_ln1118_1870_fu_89374_p0.read().is_01() || !mul_ln1118_1870_fu_89374_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1870_fu_89374_p0.read()) * sc_bigint<5>(mul_ln1118_1870_fu_89374_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1871_fu_89393_p0() {
    mul_ln1118_1871_fu_89393_p0 =  (sc_lv<12>) (sext_ln1116_71_cast_fu_53627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1871_fu_89393_p1() {
    mul_ln1118_1871_fu_89393_p1 = tmp_1871_reg_105912.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1871_fu_89393_p2() {
    mul_ln1118_1871_fu_89393_p2 = (!mul_ln1118_1871_fu_89393_p0.read().is_01() || !mul_ln1118_1871_fu_89393_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1871_fu_89393_p0.read()) * sc_bigint<5>(mul_ln1118_1871_fu_89393_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1872_fu_89412_p0() {
    mul_ln1118_1872_fu_89412_p0 =  (sc_lv<12>) (sext_ln1116_72_cast_fu_53649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1872_fu_89412_p1() {
    mul_ln1118_1872_fu_89412_p1 = tmp_1872_reg_105917.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1872_fu_89412_p2() {
    mul_ln1118_1872_fu_89412_p2 = (!mul_ln1118_1872_fu_89412_p0.read().is_01() || !mul_ln1118_1872_fu_89412_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1872_fu_89412_p0.read()) * sc_bigint<5>(mul_ln1118_1872_fu_89412_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1873_fu_89431_p0() {
    mul_ln1118_1873_fu_89431_p0 =  (sc_lv<12>) (sext_ln1116_73_cast_fu_53671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1873_fu_89431_p1() {
    mul_ln1118_1873_fu_89431_p1 = tmp_1873_reg_105922.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1873_fu_89431_p2() {
    mul_ln1118_1873_fu_89431_p2 = (!mul_ln1118_1873_fu_89431_p0.read().is_01() || !mul_ln1118_1873_fu_89431_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1873_fu_89431_p0.read()) * sc_bigint<5>(mul_ln1118_1873_fu_89431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1874_fu_89450_p0() {
    mul_ln1118_1874_fu_89450_p0 =  (sc_lv<12>) (sext_ln1116_74_cast_fu_53693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1874_fu_89450_p1() {
    mul_ln1118_1874_fu_89450_p1 = tmp_1874_reg_105927.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1874_fu_89450_p2() {
    mul_ln1118_1874_fu_89450_p2 = (!mul_ln1118_1874_fu_89450_p0.read().is_01() || !mul_ln1118_1874_fu_89450_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1874_fu_89450_p0.read()) * sc_bigint<5>(mul_ln1118_1874_fu_89450_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1875_fu_89469_p0() {
    mul_ln1118_1875_fu_89469_p0 =  (sc_lv<12>) (sext_ln1116_75_cast_fu_53715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1875_fu_89469_p1() {
    mul_ln1118_1875_fu_89469_p1 = tmp_1875_reg_105932.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1875_fu_89469_p2() {
    mul_ln1118_1875_fu_89469_p2 = (!mul_ln1118_1875_fu_89469_p0.read().is_01() || !mul_ln1118_1875_fu_89469_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1875_fu_89469_p0.read()) * sc_bigint<5>(mul_ln1118_1875_fu_89469_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1876_fu_89488_p0() {
    mul_ln1118_1876_fu_89488_p0 =  (sc_lv<12>) (sext_ln1116_76_cast_fu_53737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1876_fu_89488_p1() {
    mul_ln1118_1876_fu_89488_p1 = tmp_1876_reg_105937.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1876_fu_89488_p2() {
    mul_ln1118_1876_fu_89488_p2 = (!mul_ln1118_1876_fu_89488_p0.read().is_01() || !mul_ln1118_1876_fu_89488_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1876_fu_89488_p0.read()) * sc_bigint<5>(mul_ln1118_1876_fu_89488_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1877_fu_50525_p0() {
    mul_ln1118_1877_fu_50525_p0 = select_ln76_68_fu_23355_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1877_fu_50525_p1() {
    mul_ln1118_1877_fu_50525_p1 = tmp_1877_fu_50511_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1877_fu_50525_p2() {
    mul_ln1118_1877_fu_50525_p2 = (!mul_ln1118_1877_fu_50525_p0.read().is_01() || !mul_ln1118_1877_fu_50525_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1877_fu_50525_p0.read()) * sc_bigint<5>(mul_ln1118_1877_fu_50525_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1878_fu_50555_p0() {
    mul_ln1118_1878_fu_50555_p0 =  (sc_lv<12>) (sext_ln1116_78_cast_fu_23395_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1878_fu_50555_p1() {
    mul_ln1118_1878_fu_50555_p1 = tmp_1878_fu_50541_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1878_fu_50555_p2() {
    mul_ln1118_1878_fu_50555_p2 = (!mul_ln1118_1878_fu_50555_p0.read().is_01() || !mul_ln1118_1878_fu_50555_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1878_fu_50555_p0.read()) * sc_bigint<5>(mul_ln1118_1878_fu_50555_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1879_fu_50585_p0() {
    mul_ln1118_1879_fu_50585_p0 =  (sc_lv<12>) (sext_ln1116_79_cast_fu_23437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1879_fu_50585_p1() {
    mul_ln1118_1879_fu_50585_p1 = tmp_1879_fu_50571_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1879_fu_50585_p2() {
    mul_ln1118_1879_fu_50585_p2 = (!mul_ln1118_1879_fu_50585_p0.read().is_01() || !mul_ln1118_1879_fu_50585_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1879_fu_50585_p0.read()) * sc_bigint<5>(mul_ln1118_1879_fu_50585_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_187_fu_55589_p0() {
    mul_ln1118_187_fu_55589_p0 =  (sc_lv<12>) (sext_ln1116_187_cast_fu_55583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_187_fu_55589_p1() {
    mul_ln1118_187_fu_55589_p1 = tmp_187_reg_97396.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_187_fu_55589_p2() {
    mul_ln1118_187_fu_55589_p2 = (!mul_ln1118_187_fu_55589_p0.read().is_01() || !mul_ln1118_187_fu_55589_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_187_fu_55589_p0.read()) * sc_bigint<5>(mul_ln1118_187_fu_55589_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1880_fu_50615_p0() {
    mul_ln1118_1880_fu_50615_p0 =  (sc_lv<12>) (sext_ln1116_80_cast_fu_23479_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1880_fu_50615_p1() {
    mul_ln1118_1880_fu_50615_p1 = tmp_1880_fu_50601_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1880_fu_50615_p2() {
    mul_ln1118_1880_fu_50615_p2 = (!mul_ln1118_1880_fu_50615_p0.read().is_01() || !mul_ln1118_1880_fu_50615_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1880_fu_50615_p0.read()) * sc_bigint<5>(mul_ln1118_1880_fu_50615_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1881_fu_50645_p0() {
    mul_ln1118_1881_fu_50645_p0 =  (sc_lv<12>) (sext_ln1116_81_cast_fu_23521_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1881_fu_50645_p1() {
    mul_ln1118_1881_fu_50645_p1 = tmp_1881_fu_50631_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1881_fu_50645_p2() {
    mul_ln1118_1881_fu_50645_p2 = (!mul_ln1118_1881_fu_50645_p0.read().is_01() || !mul_ln1118_1881_fu_50645_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1881_fu_50645_p0.read()) * sc_bigint<5>(mul_ln1118_1881_fu_50645_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1882_fu_50675_p0() {
    mul_ln1118_1882_fu_50675_p0 =  (sc_lv<12>) (sext_ln1116_82_cast_fu_23563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1882_fu_50675_p1() {
    mul_ln1118_1882_fu_50675_p1 = tmp_1882_fu_50661_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1882_fu_50675_p2() {
    mul_ln1118_1882_fu_50675_p2 = (!mul_ln1118_1882_fu_50675_p0.read().is_01() || !mul_ln1118_1882_fu_50675_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1882_fu_50675_p0.read()) * sc_bigint<5>(mul_ln1118_1882_fu_50675_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1883_fu_50705_p0() {
    mul_ln1118_1883_fu_50705_p0 =  (sc_lv<12>) (sext_ln1116_83_cast_fu_23605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1883_fu_50705_p1() {
    mul_ln1118_1883_fu_50705_p1 = tmp_1883_fu_50691_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1883_fu_50705_p2() {
    mul_ln1118_1883_fu_50705_p2 = (!mul_ln1118_1883_fu_50705_p0.read().is_01() || !mul_ln1118_1883_fu_50705_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1883_fu_50705_p0.read()) * sc_bigint<5>(mul_ln1118_1883_fu_50705_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1884_fu_89507_p0() {
    mul_ln1118_1884_fu_89507_p0 =  (sc_lv<12>) (sext_ln1116_84_cast_fu_53777_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1884_fu_89507_p1() {
    mul_ln1118_1884_fu_89507_p1 = tmp_1884_reg_105977.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1884_fu_89507_p2() {
    mul_ln1118_1884_fu_89507_p2 = (!mul_ln1118_1884_fu_89507_p0.read().is_01() || !mul_ln1118_1884_fu_89507_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1884_fu_89507_p0.read()) * sc_bigint<5>(mul_ln1118_1884_fu_89507_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1885_fu_89526_p0() {
    mul_ln1118_1885_fu_89526_p0 =  (sc_lv<12>) (sext_ln1116_85_cast_fu_53799_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1885_fu_89526_p1() {
    mul_ln1118_1885_fu_89526_p1 = tmp_1885_reg_105982.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1885_fu_89526_p2() {
    mul_ln1118_1885_fu_89526_p2 = (!mul_ln1118_1885_fu_89526_p0.read().is_01() || !mul_ln1118_1885_fu_89526_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1885_fu_89526_p0.read()) * sc_bigint<5>(mul_ln1118_1885_fu_89526_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1886_fu_89545_p0() {
    mul_ln1118_1886_fu_89545_p0 =  (sc_lv<12>) (sext_ln1116_86_cast_fu_53821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1886_fu_89545_p1() {
    mul_ln1118_1886_fu_89545_p1 = tmp_1886_reg_105987.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1886_fu_89545_p2() {
    mul_ln1118_1886_fu_89545_p2 = (!mul_ln1118_1886_fu_89545_p0.read().is_01() || !mul_ln1118_1886_fu_89545_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1886_fu_89545_p0.read()) * sc_bigint<5>(mul_ln1118_1886_fu_89545_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1887_fu_89564_p0() {
    mul_ln1118_1887_fu_89564_p0 =  (sc_lv<12>) (sext_ln1116_87_cast_fu_53843_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1887_fu_89564_p1() {
    mul_ln1118_1887_fu_89564_p1 = tmp_1887_reg_105992.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1887_fu_89564_p2() {
    mul_ln1118_1887_fu_89564_p2 = (!mul_ln1118_1887_fu_89564_p0.read().is_01() || !mul_ln1118_1887_fu_89564_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1887_fu_89564_p0.read()) * sc_bigint<5>(mul_ln1118_1887_fu_89564_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1888_fu_89583_p0() {
    mul_ln1118_1888_fu_89583_p0 =  (sc_lv<12>) (sext_ln1116_88_cast_fu_53865_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1888_fu_89583_p1() {
    mul_ln1118_1888_fu_89583_p1 = tmp_1888_reg_105997.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1888_fu_89583_p2() {
    mul_ln1118_1888_fu_89583_p2 = (!mul_ln1118_1888_fu_89583_p0.read().is_01() || !mul_ln1118_1888_fu_89583_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1888_fu_89583_p0.read()) * sc_bigint<5>(mul_ln1118_1888_fu_89583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1889_fu_89602_p0() {
    mul_ln1118_1889_fu_89602_p0 =  (sc_lv<12>) (sext_ln1116_89_cast_fu_53887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1889_fu_89602_p1() {
    mul_ln1118_1889_fu_89602_p1 = tmp_1889_reg_106002.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1889_fu_89602_p2() {
    mul_ln1118_1889_fu_89602_p2 = (!mul_ln1118_1889_fu_89602_p0.read().is_01() || !mul_ln1118_1889_fu_89602_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1889_fu_89602_p0.read()) * sc_bigint<5>(mul_ln1118_1889_fu_89602_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_188_fu_55611_p0() {
    mul_ln1118_188_fu_55611_p0 =  (sc_lv<12>) (sext_ln1116_188_cast_fu_55605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_188_fu_55611_p1() {
    mul_ln1118_188_fu_55611_p1 = tmp_188_reg_97406.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_188_fu_55611_p2() {
    mul_ln1118_188_fu_55611_p2 = (!mul_ln1118_188_fu_55611_p0.read().is_01() || !mul_ln1118_188_fu_55611_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_188_fu_55611_p0.read()) * sc_bigint<5>(mul_ln1118_188_fu_55611_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1890_fu_89621_p0() {
    mul_ln1118_1890_fu_89621_p0 =  (sc_lv<12>) (sext_ln1116_90_cast_fu_53909_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1890_fu_89621_p1() {
    mul_ln1118_1890_fu_89621_p1 = tmp_1890_reg_106007.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1890_fu_89621_p2() {
    mul_ln1118_1890_fu_89621_p2 = (!mul_ln1118_1890_fu_89621_p0.read().is_01() || !mul_ln1118_1890_fu_89621_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1890_fu_89621_p0.read()) * sc_bigint<5>(mul_ln1118_1890_fu_89621_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1891_fu_89640_p0() {
    mul_ln1118_1891_fu_89640_p0 =  (sc_lv<12>) (sext_ln1116_91_cast_fu_53931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1891_fu_89640_p1() {
    mul_ln1118_1891_fu_89640_p1 = tmp_1891_reg_106012.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1891_fu_89640_p2() {
    mul_ln1118_1891_fu_89640_p2 = (!mul_ln1118_1891_fu_89640_p0.read().is_01() || !mul_ln1118_1891_fu_89640_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1891_fu_89640_p0.read()) * sc_bigint<5>(mul_ln1118_1891_fu_89640_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1892_fu_89659_p0() {
    mul_ln1118_1892_fu_89659_p0 =  (sc_lv<12>) (sext_ln1116_92_cast_fu_53953_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1892_fu_89659_p1() {
    mul_ln1118_1892_fu_89659_p1 = tmp_1892_reg_106017.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1892_fu_89659_p2() {
    mul_ln1118_1892_fu_89659_p2 = (!mul_ln1118_1892_fu_89659_p0.read().is_01() || !mul_ln1118_1892_fu_89659_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1892_fu_89659_p0.read()) * sc_bigint<5>(mul_ln1118_1892_fu_89659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1893_fu_89678_p0() {
    mul_ln1118_1893_fu_89678_p0 =  (sc_lv<12>) (sext_ln1116_93_cast_fu_53975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1893_fu_89678_p1() {
    mul_ln1118_1893_fu_89678_p1 = tmp_1893_reg_106022.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1893_fu_89678_p2() {
    mul_ln1118_1893_fu_89678_p2 = (!mul_ln1118_1893_fu_89678_p0.read().is_01() || !mul_ln1118_1893_fu_89678_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1893_fu_89678_p0.read()) * sc_bigint<5>(mul_ln1118_1893_fu_89678_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1894_fu_89697_p0() {
    mul_ln1118_1894_fu_89697_p0 =  (sc_lv<12>) (sext_ln1116_94_cast_fu_53997_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1894_fu_89697_p1() {
    mul_ln1118_1894_fu_89697_p1 = tmp_1894_reg_106027.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1894_fu_89697_p2() {
    mul_ln1118_1894_fu_89697_p2 = (!mul_ln1118_1894_fu_89697_p0.read().is_01() || !mul_ln1118_1894_fu_89697_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1894_fu_89697_p0.read()) * sc_bigint<5>(mul_ln1118_1894_fu_89697_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1895_fu_89716_p0() {
    mul_ln1118_1895_fu_89716_p0 =  (sc_lv<12>) (sext_ln1116_95_cast_fu_54019_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1895_fu_89716_p1() {
    mul_ln1118_1895_fu_89716_p1 = tmp_1895_reg_106032.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1895_fu_89716_p2() {
    mul_ln1118_1895_fu_89716_p2 = (!mul_ln1118_1895_fu_89716_p0.read().is_01() || !mul_ln1118_1895_fu_89716_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1895_fu_89716_p0.read()) * sc_bigint<5>(mul_ln1118_1895_fu_89716_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1896_fu_89735_p0() {
    mul_ln1118_1896_fu_89735_p0 =  (sc_lv<12>) (sext_ln1116_96_cast_fu_54041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1896_fu_89735_p1() {
    mul_ln1118_1896_fu_89735_p1 = tmp_1896_reg_106037.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1896_fu_89735_p2() {
    mul_ln1118_1896_fu_89735_p2 = (!mul_ln1118_1896_fu_89735_p0.read().is_01() || !mul_ln1118_1896_fu_89735_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1896_fu_89735_p0.read()) * sc_bigint<5>(mul_ln1118_1896_fu_89735_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1897_fu_89754_p0() {
    mul_ln1118_1897_fu_89754_p0 =  (sc_lv<12>) (sext_ln1116_97_cast_fu_54063_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1897_fu_89754_p1() {
    mul_ln1118_1897_fu_89754_p1 = tmp_1897_reg_106042.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1897_fu_89754_p2() {
    mul_ln1118_1897_fu_89754_p2 = (!mul_ln1118_1897_fu_89754_p0.read().is_01() || !mul_ln1118_1897_fu_89754_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1897_fu_89754_p0.read()) * sc_bigint<5>(mul_ln1118_1897_fu_89754_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1898_fu_89773_p0() {
    mul_ln1118_1898_fu_89773_p0 =  (sc_lv<12>) (sext_ln1116_98_cast_fu_54085_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1898_fu_89773_p1() {
    mul_ln1118_1898_fu_89773_p1 = tmp_1898_reg_106047.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1898_fu_89773_p2() {
    mul_ln1118_1898_fu_89773_p2 = (!mul_ln1118_1898_fu_89773_p0.read().is_01() || !mul_ln1118_1898_fu_89773_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1898_fu_89773_p0.read()) * sc_bigint<5>(mul_ln1118_1898_fu_89773_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1899_fu_89792_p0() {
    mul_ln1118_1899_fu_89792_p0 =  (sc_lv<12>) (sext_ln1116_99_cast_fu_54107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1899_fu_89792_p1() {
    mul_ln1118_1899_fu_89792_p1 = tmp_1899_reg_106052.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1899_fu_89792_p2() {
    mul_ln1118_1899_fu_89792_p2 = (!mul_ln1118_1899_fu_89792_p0.read().is_01() || !mul_ln1118_1899_fu_89792_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1899_fu_89792_p0.read()) * sc_bigint<5>(mul_ln1118_1899_fu_89792_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_189_fu_55633_p0() {
    mul_ln1118_189_fu_55633_p0 =  (sc_lv<12>) (sext_ln1116_189_cast_fu_55627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_189_fu_55633_p1() {
    mul_ln1118_189_fu_55633_p1 = tmp_189_reg_97416.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_189_fu_55633_p2() {
    mul_ln1118_189_fu_55633_p2 = (!mul_ln1118_189_fu_55633_p0.read().is_01() || !mul_ln1118_189_fu_55633_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_189_fu_55633_p0.read()) * sc_bigint<5>(mul_ln1118_189_fu_55633_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_18_fu_52735_p0() {
    mul_ln1118_18_fu_52735_p0 =  (sc_lv<12>) (sext_ln1116_18_cast_fu_52729_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_18_fu_52735_p1() {
    mul_ln1118_18_fu_52735_p1 = tmp_19_reg_95840.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_18_fu_52735_p2() {
    mul_ln1118_18_fu_52735_p2 = (!mul_ln1118_18_fu_52735_p0.read().is_01() || !mul_ln1118_18_fu_52735_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_18_fu_52735_p0.read()) * sc_bigint<5>(mul_ln1118_18_fu_52735_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1900_fu_89811_p0() {
    mul_ln1118_1900_fu_89811_p0 =  (sc_lv<12>) (sext_ln1116_100_cast_fu_54129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1900_fu_89811_p1() {
    mul_ln1118_1900_fu_89811_p1 = tmp_1900_reg_106057.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1900_fu_89811_p2() {
    mul_ln1118_1900_fu_89811_p2 = (!mul_ln1118_1900_fu_89811_p0.read().is_01() || !mul_ln1118_1900_fu_89811_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1900_fu_89811_p0.read()) * sc_bigint<5>(mul_ln1118_1900_fu_89811_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1901_fu_89830_p0() {
    mul_ln1118_1901_fu_89830_p0 =  (sc_lv<12>) (sext_ln1116_101_cast_fu_54151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1901_fu_89830_p1() {
    mul_ln1118_1901_fu_89830_p1 = tmp_1901_reg_106062.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1901_fu_89830_p2() {
    mul_ln1118_1901_fu_89830_p2 = (!mul_ln1118_1901_fu_89830_p0.read().is_01() || !mul_ln1118_1901_fu_89830_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1901_fu_89830_p0.read()) * sc_bigint<5>(mul_ln1118_1901_fu_89830_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1902_fu_50915_p0() {
    mul_ln1118_1902_fu_50915_p0 = select_ln76_93_fu_23953_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1902_fu_50915_p1() {
    mul_ln1118_1902_fu_50915_p1 = tmp_1902_fu_50901_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1902_fu_50915_p2() {
    mul_ln1118_1902_fu_50915_p2 = (!mul_ln1118_1902_fu_50915_p0.read().is_01() || !mul_ln1118_1902_fu_50915_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1902_fu_50915_p0.read()) * sc_bigint<5>(mul_ln1118_1902_fu_50915_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1903_fu_50945_p0() {
    mul_ln1118_1903_fu_50945_p0 =  (sc_lv<12>) (sext_ln1116_103_cast_fu_23993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1903_fu_50945_p1() {
    mul_ln1118_1903_fu_50945_p1 = tmp_1903_fu_50931_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1903_fu_50945_p2() {
    mul_ln1118_1903_fu_50945_p2 = (!mul_ln1118_1903_fu_50945_p0.read().is_01() || !mul_ln1118_1903_fu_50945_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1903_fu_50945_p0.read()) * sc_bigint<5>(mul_ln1118_1903_fu_50945_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1904_fu_50975_p0() {
    mul_ln1118_1904_fu_50975_p0 =  (sc_lv<12>) (sext_ln1116_104_cast_fu_24035_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1904_fu_50975_p1() {
    mul_ln1118_1904_fu_50975_p1 = tmp_1904_fu_50961_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1904_fu_50975_p2() {
    mul_ln1118_1904_fu_50975_p2 = (!mul_ln1118_1904_fu_50975_p0.read().is_01() || !mul_ln1118_1904_fu_50975_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1904_fu_50975_p0.read()) * sc_bigint<5>(mul_ln1118_1904_fu_50975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1905_fu_51005_p0() {
    mul_ln1118_1905_fu_51005_p0 =  (sc_lv<12>) (sext_ln1116_105_cast_fu_24077_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1905_fu_51005_p1() {
    mul_ln1118_1905_fu_51005_p1 = tmp_1905_fu_50991_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1905_fu_51005_p2() {
    mul_ln1118_1905_fu_51005_p2 = (!mul_ln1118_1905_fu_51005_p0.read().is_01() || !mul_ln1118_1905_fu_51005_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1905_fu_51005_p0.read()) * sc_bigint<5>(mul_ln1118_1905_fu_51005_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1906_fu_51035_p0() {
    mul_ln1118_1906_fu_51035_p0 =  (sc_lv<12>) (sext_ln1116_106_cast_fu_24119_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1906_fu_51035_p1() {
    mul_ln1118_1906_fu_51035_p1 = tmp_1906_fu_51021_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1906_fu_51035_p2() {
    mul_ln1118_1906_fu_51035_p2 = (!mul_ln1118_1906_fu_51035_p0.read().is_01() || !mul_ln1118_1906_fu_51035_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1906_fu_51035_p0.read()) * sc_bigint<5>(mul_ln1118_1906_fu_51035_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1907_fu_51065_p0() {
    mul_ln1118_1907_fu_51065_p0 =  (sc_lv<12>) (sext_ln1116_107_cast_fu_24161_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1907_fu_51065_p1() {
    mul_ln1118_1907_fu_51065_p1 = tmp_1907_fu_51051_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1907_fu_51065_p2() {
    mul_ln1118_1907_fu_51065_p2 = (!mul_ln1118_1907_fu_51065_p0.read().is_01() || !mul_ln1118_1907_fu_51065_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1907_fu_51065_p0.read()) * sc_bigint<5>(mul_ln1118_1907_fu_51065_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1908_fu_51095_p0() {
    mul_ln1118_1908_fu_51095_p0 =  (sc_lv<12>) (sext_ln1116_108_cast_fu_24203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1908_fu_51095_p1() {
    mul_ln1118_1908_fu_51095_p1 = tmp_1908_fu_51081_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1908_fu_51095_p2() {
    mul_ln1118_1908_fu_51095_p2 = (!mul_ln1118_1908_fu_51095_p0.read().is_01() || !mul_ln1118_1908_fu_51095_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1908_fu_51095_p0.read()) * sc_bigint<5>(mul_ln1118_1908_fu_51095_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1909_fu_89849_p0() {
    mul_ln1118_1909_fu_89849_p0 =  (sc_lv<12>) (sext_ln1116_109_cast_fu_54191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1909_fu_89849_p1() {
    mul_ln1118_1909_fu_89849_p1 = tmp_1909_reg_106102.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1909_fu_89849_p2() {
    mul_ln1118_1909_fu_89849_p2 = (!mul_ln1118_1909_fu_89849_p0.read().is_01() || !mul_ln1118_1909_fu_89849_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1909_fu_89849_p0.read()) * sc_bigint<5>(mul_ln1118_1909_fu_89849_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_190_fu_55655_p0() {
    mul_ln1118_190_fu_55655_p0 =  (sc_lv<12>) (sext_ln1116_190_cast_fu_55649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_190_fu_55655_p1() {
    mul_ln1118_190_fu_55655_p1 = tmp_190_reg_97426.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_190_fu_55655_p2() {
    mul_ln1118_190_fu_55655_p2 = (!mul_ln1118_190_fu_55655_p0.read().is_01() || !mul_ln1118_190_fu_55655_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_190_fu_55655_p0.read()) * sc_bigint<5>(mul_ln1118_190_fu_55655_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1910_fu_89868_p0() {
    mul_ln1118_1910_fu_89868_p0 =  (sc_lv<12>) (sext_ln1116_110_cast_fu_54213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1910_fu_89868_p1() {
    mul_ln1118_1910_fu_89868_p1 = tmp_1910_reg_106107.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1910_fu_89868_p2() {
    mul_ln1118_1910_fu_89868_p2 = (!mul_ln1118_1910_fu_89868_p0.read().is_01() || !mul_ln1118_1910_fu_89868_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1910_fu_89868_p0.read()) * sc_bigint<5>(mul_ln1118_1910_fu_89868_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1911_fu_89887_p0() {
    mul_ln1118_1911_fu_89887_p0 =  (sc_lv<12>) (sext_ln1116_111_cast_fu_54235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1911_fu_89887_p1() {
    mul_ln1118_1911_fu_89887_p1 = tmp_1911_reg_106112.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1911_fu_89887_p2() {
    mul_ln1118_1911_fu_89887_p2 = (!mul_ln1118_1911_fu_89887_p0.read().is_01() || !mul_ln1118_1911_fu_89887_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1911_fu_89887_p0.read()) * sc_bigint<5>(mul_ln1118_1911_fu_89887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1912_fu_89906_p0() {
    mul_ln1118_1912_fu_89906_p0 =  (sc_lv<12>) (sext_ln1116_112_cast_fu_54257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1912_fu_89906_p1() {
    mul_ln1118_1912_fu_89906_p1 = tmp_1912_reg_106117.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1912_fu_89906_p2() {
    mul_ln1118_1912_fu_89906_p2 = (!mul_ln1118_1912_fu_89906_p0.read().is_01() || !mul_ln1118_1912_fu_89906_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1912_fu_89906_p0.read()) * sc_bigint<5>(mul_ln1118_1912_fu_89906_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1913_fu_89925_p0() {
    mul_ln1118_1913_fu_89925_p0 =  (sc_lv<12>) (sext_ln1116_113_cast_fu_54279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1913_fu_89925_p1() {
    mul_ln1118_1913_fu_89925_p1 = tmp_1913_reg_106122.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1913_fu_89925_p2() {
    mul_ln1118_1913_fu_89925_p2 = (!mul_ln1118_1913_fu_89925_p0.read().is_01() || !mul_ln1118_1913_fu_89925_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1913_fu_89925_p0.read()) * sc_bigint<5>(mul_ln1118_1913_fu_89925_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1914_fu_89944_p0() {
    mul_ln1118_1914_fu_89944_p0 =  (sc_lv<12>) (sext_ln1116_114_cast_fu_54301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1914_fu_89944_p1() {
    mul_ln1118_1914_fu_89944_p1 = tmp_1914_reg_106127.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1914_fu_89944_p2() {
    mul_ln1118_1914_fu_89944_p2 = (!mul_ln1118_1914_fu_89944_p0.read().is_01() || !mul_ln1118_1914_fu_89944_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1914_fu_89944_p0.read()) * sc_bigint<5>(mul_ln1118_1914_fu_89944_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1915_fu_89963_p0() {
    mul_ln1118_1915_fu_89963_p0 =  (sc_lv<12>) (sext_ln1116_115_cast_fu_54323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1915_fu_89963_p1() {
    mul_ln1118_1915_fu_89963_p1 = tmp_1915_reg_106132.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1915_fu_89963_p2() {
    mul_ln1118_1915_fu_89963_p2 = (!mul_ln1118_1915_fu_89963_p0.read().is_01() || !mul_ln1118_1915_fu_89963_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1915_fu_89963_p0.read()) * sc_bigint<5>(mul_ln1118_1915_fu_89963_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1916_fu_89982_p0() {
    mul_ln1118_1916_fu_89982_p0 =  (sc_lv<12>) (sext_ln1116_116_cast_fu_54345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1916_fu_89982_p1() {
    mul_ln1118_1916_fu_89982_p1 = tmp_1916_reg_106137.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1916_fu_89982_p2() {
    mul_ln1118_1916_fu_89982_p2 = (!mul_ln1118_1916_fu_89982_p0.read().is_01() || !mul_ln1118_1916_fu_89982_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1916_fu_89982_p0.read()) * sc_bigint<5>(mul_ln1118_1916_fu_89982_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1917_fu_90001_p0() {
    mul_ln1118_1917_fu_90001_p0 =  (sc_lv<12>) (sext_ln1116_117_cast_fu_54367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1917_fu_90001_p1() {
    mul_ln1118_1917_fu_90001_p1 = tmp_1917_reg_106142.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1917_fu_90001_p2() {
    mul_ln1118_1917_fu_90001_p2 = (!mul_ln1118_1917_fu_90001_p0.read().is_01() || !mul_ln1118_1917_fu_90001_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1917_fu_90001_p0.read()) * sc_bigint<5>(mul_ln1118_1917_fu_90001_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1918_fu_90020_p0() {
    mul_ln1118_1918_fu_90020_p0 =  (sc_lv<12>) (sext_ln1116_118_cast_fu_54389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1918_fu_90020_p1() {
    mul_ln1118_1918_fu_90020_p1 = tmp_1918_reg_106147.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1918_fu_90020_p2() {
    mul_ln1118_1918_fu_90020_p2 = (!mul_ln1118_1918_fu_90020_p0.read().is_01() || !mul_ln1118_1918_fu_90020_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1918_fu_90020_p0.read()) * sc_bigint<5>(mul_ln1118_1918_fu_90020_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1919_fu_90039_p0() {
    mul_ln1118_1919_fu_90039_p0 =  (sc_lv<12>) (sext_ln1116_119_cast_fu_54411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1919_fu_90039_p1() {
    mul_ln1118_1919_fu_90039_p1 = tmp_1919_reg_106152.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1919_fu_90039_p2() {
    mul_ln1118_1919_fu_90039_p2 = (!mul_ln1118_1919_fu_90039_p0.read().is_01() || !mul_ln1118_1919_fu_90039_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1919_fu_90039_p0.read()) * sc_bigint<5>(mul_ln1118_1919_fu_90039_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_191_fu_55677_p0() {
    mul_ln1118_191_fu_55677_p0 =  (sc_lv<12>) (sext_ln1116_191_cast_fu_55671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_191_fu_55677_p1() {
    mul_ln1118_191_fu_55677_p1 = tmp_191_reg_97436.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_191_fu_55677_p2() {
    mul_ln1118_191_fu_55677_p2 = (!mul_ln1118_191_fu_55677_p0.read().is_01() || !mul_ln1118_191_fu_55677_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_191_fu_55677_p0.read()) * sc_bigint<5>(mul_ln1118_191_fu_55677_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1920_fu_90058_p0() {
    mul_ln1118_1920_fu_90058_p0 =  (sc_lv<12>) (sext_ln1116_120_cast_fu_54433_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1920_fu_90058_p1() {
    mul_ln1118_1920_fu_90058_p1 = tmp_1920_reg_106157.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1920_fu_90058_p2() {
    mul_ln1118_1920_fu_90058_p2 = (!mul_ln1118_1920_fu_90058_p0.read().is_01() || !mul_ln1118_1920_fu_90058_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1920_fu_90058_p0.read()) * sc_bigint<5>(mul_ln1118_1920_fu_90058_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1921_fu_90077_p0() {
    mul_ln1118_1921_fu_90077_p0 =  (sc_lv<12>) (sext_ln1116_121_cast_fu_54455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1921_fu_90077_p1() {
    mul_ln1118_1921_fu_90077_p1 = tmp_1921_reg_106162.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1921_fu_90077_p2() {
    mul_ln1118_1921_fu_90077_p2 = (!mul_ln1118_1921_fu_90077_p0.read().is_01() || !mul_ln1118_1921_fu_90077_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1921_fu_90077_p0.read()) * sc_bigint<5>(mul_ln1118_1921_fu_90077_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1922_fu_90096_p0() {
    mul_ln1118_1922_fu_90096_p0 =  (sc_lv<12>) (sext_ln1116_122_cast_fu_54477_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1922_fu_90096_p1() {
    mul_ln1118_1922_fu_90096_p1 = tmp_1922_reg_106167.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1922_fu_90096_p2() {
    mul_ln1118_1922_fu_90096_p2 = (!mul_ln1118_1922_fu_90096_p0.read().is_01() || !mul_ln1118_1922_fu_90096_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1922_fu_90096_p0.read()) * sc_bigint<5>(mul_ln1118_1922_fu_90096_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1923_fu_90115_p0() {
    mul_ln1118_1923_fu_90115_p0 =  (sc_lv<12>) (sext_ln1116_123_cast_fu_54499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1923_fu_90115_p1() {
    mul_ln1118_1923_fu_90115_p1 = tmp_1923_reg_106172.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1923_fu_90115_p2() {
    mul_ln1118_1923_fu_90115_p2 = (!mul_ln1118_1923_fu_90115_p0.read().is_01() || !mul_ln1118_1923_fu_90115_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1923_fu_90115_p0.read()) * sc_bigint<5>(mul_ln1118_1923_fu_90115_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1924_fu_90134_p0() {
    mul_ln1118_1924_fu_90134_p0 =  (sc_lv<12>) (sext_ln1116_124_cast_fu_54521_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1924_fu_90134_p1() {
    mul_ln1118_1924_fu_90134_p1 = tmp_1924_reg_106177.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1924_fu_90134_p2() {
    mul_ln1118_1924_fu_90134_p2 = (!mul_ln1118_1924_fu_90134_p0.read().is_01() || !mul_ln1118_1924_fu_90134_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1924_fu_90134_p0.read()) * sc_bigint<5>(mul_ln1118_1924_fu_90134_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1925_fu_90153_p0() {
    mul_ln1118_1925_fu_90153_p0 =  (sc_lv<12>) (sext_ln1116_125_cast_fu_54543_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1925_fu_90153_p1() {
    mul_ln1118_1925_fu_90153_p1 = tmp_1925_reg_106182.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1925_fu_90153_p2() {
    mul_ln1118_1925_fu_90153_p2 = (!mul_ln1118_1925_fu_90153_p0.read().is_01() || !mul_ln1118_1925_fu_90153_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1925_fu_90153_p0.read()) * sc_bigint<5>(mul_ln1118_1925_fu_90153_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1926_fu_90172_p0() {
    mul_ln1118_1926_fu_90172_p0 =  (sc_lv<12>) (sext_ln1116_126_cast_fu_54565_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1926_fu_90172_p1() {
    mul_ln1118_1926_fu_90172_p1 = tmp_1926_reg_106187.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1926_fu_90172_p2() {
    mul_ln1118_1926_fu_90172_p2 = (!mul_ln1118_1926_fu_90172_p0.read().is_01() || !mul_ln1118_1926_fu_90172_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1926_fu_90172_p0.read()) * sc_bigint<5>(mul_ln1118_1926_fu_90172_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1927_fu_90191_p0() {
    mul_ln1118_1927_fu_90191_p0 =  (sc_lv<12>) (sext_ln1116_127_cast_fu_54587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1927_fu_90191_p1() {
    mul_ln1118_1927_fu_90191_p1 = tmp_1927_reg_106192.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1927_fu_90191_p2() {
    mul_ln1118_1927_fu_90191_p2 = (!mul_ln1118_1927_fu_90191_p0.read().is_01() || !mul_ln1118_1927_fu_90191_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1927_fu_90191_p0.read()) * sc_bigint<5>(mul_ln1118_1927_fu_90191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1928_fu_90210_p0() {
    mul_ln1118_1928_fu_90210_p0 =  (sc_lv<12>) (sext_ln1116_128_cast_fu_54609_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1928_fu_90210_p1() {
    mul_ln1118_1928_fu_90210_p1 = tmp_1928_reg_106197.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1928_fu_90210_p2() {
    mul_ln1118_1928_fu_90210_p2 = (!mul_ln1118_1928_fu_90210_p0.read().is_01() || !mul_ln1118_1928_fu_90210_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1928_fu_90210_p0.read()) * sc_bigint<5>(mul_ln1118_1928_fu_90210_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1929_fu_90229_p0() {
    mul_ln1118_1929_fu_90229_p0 =  (sc_lv<12>) (sext_ln1116_129_cast_fu_54631_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1929_fu_90229_p1() {
    mul_ln1118_1929_fu_90229_p1 = tmp_1929_reg_106202.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1929_fu_90229_p2() {
    mul_ln1118_1929_fu_90229_p2 = (!mul_ln1118_1929_fu_90229_p0.read().is_01() || !mul_ln1118_1929_fu_90229_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1929_fu_90229_p0.read()) * sc_bigint<5>(mul_ln1118_1929_fu_90229_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_192_fu_55699_p0() {
    mul_ln1118_192_fu_55699_p0 =  (sc_lv<12>) (sext_ln1116_192_cast_fu_55693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_192_fu_55699_p1() {
    mul_ln1118_192_fu_55699_p1 = tmp_192_reg_97446.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_192_fu_55699_p2() {
    mul_ln1118_192_fu_55699_p2 = (!mul_ln1118_192_fu_55699_p0.read().is_01() || !mul_ln1118_192_fu_55699_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_192_fu_55699_p0.read()) * sc_bigint<5>(mul_ln1118_192_fu_55699_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1930_fu_90248_p0() {
    mul_ln1118_1930_fu_90248_p0 =  (sc_lv<12>) (sext_ln1116_130_cast_fu_54653_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1930_fu_90248_p1() {
    mul_ln1118_1930_fu_90248_p1 = tmp_1930_reg_106207.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1930_fu_90248_p2() {
    mul_ln1118_1930_fu_90248_p2 = (!mul_ln1118_1930_fu_90248_p0.read().is_01() || !mul_ln1118_1930_fu_90248_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1930_fu_90248_p0.read()) * sc_bigint<5>(mul_ln1118_1930_fu_90248_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1931_fu_90267_p0() {
    mul_ln1118_1931_fu_90267_p0 =  (sc_lv<12>) (sext_ln1116_131_cast_fu_54675_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1931_fu_90267_p1() {
    mul_ln1118_1931_fu_90267_p1 = tmp_1931_reg_106212.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1931_fu_90267_p2() {
    mul_ln1118_1931_fu_90267_p2 = (!mul_ln1118_1931_fu_90267_p0.read().is_01() || !mul_ln1118_1931_fu_90267_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1931_fu_90267_p0.read()) * sc_bigint<5>(mul_ln1118_1931_fu_90267_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1932_fu_51355_p0() {
    mul_ln1118_1932_fu_51355_p0 =  (sc_lv<12>) (sext_ln1116_132_cast_fu_24659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1932_fu_51355_p1() {
    mul_ln1118_1932_fu_51355_p1 = tmp_1932_fu_51341_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1932_fu_51355_p2() {
    mul_ln1118_1932_fu_51355_p2 = (!mul_ln1118_1932_fu_51355_p0.read().is_01() || !mul_ln1118_1932_fu_51355_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1932_fu_51355_p0.read()) * sc_bigint<5>(mul_ln1118_1932_fu_51355_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1933_fu_51385_p0() {
    mul_ln1118_1933_fu_51385_p0 =  (sc_lv<12>) (sext_ln1116_133_cast_fu_24701_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1933_fu_51385_p1() {
    mul_ln1118_1933_fu_51385_p1 = tmp_1933_fu_51371_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1933_fu_51385_p2() {
    mul_ln1118_1933_fu_51385_p2 = (!mul_ln1118_1933_fu_51385_p0.read().is_01() || !mul_ln1118_1933_fu_51385_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1933_fu_51385_p0.read()) * sc_bigint<5>(mul_ln1118_1933_fu_51385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1934_fu_90286_p0() {
    mul_ln1118_1934_fu_90286_p0 =  (sc_lv<12>) (sext_ln1116_134_cast_fu_54697_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1934_fu_90286_p1() {
    mul_ln1118_1934_fu_90286_p1 = tmp_1934_reg_106227.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1934_fu_90286_p2() {
    mul_ln1118_1934_fu_90286_p2 = (!mul_ln1118_1934_fu_90286_p0.read().is_01() || !mul_ln1118_1934_fu_90286_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1934_fu_90286_p0.read()) * sc_bigint<5>(mul_ln1118_1934_fu_90286_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1935_fu_90305_p0() {
    mul_ln1118_1935_fu_90305_p0 =  (sc_lv<12>) (sext_ln1116_135_cast_fu_54719_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1935_fu_90305_p1() {
    mul_ln1118_1935_fu_90305_p1 = tmp_1935_reg_106232.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1935_fu_90305_p2() {
    mul_ln1118_1935_fu_90305_p2 = (!mul_ln1118_1935_fu_90305_p0.read().is_01() || !mul_ln1118_1935_fu_90305_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1935_fu_90305_p0.read()) * sc_bigint<5>(mul_ln1118_1935_fu_90305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1936_fu_90324_p0() {
    mul_ln1118_1936_fu_90324_p0 =  (sc_lv<12>) (sext_ln1116_136_cast_fu_54741_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1936_fu_90324_p1() {
    mul_ln1118_1936_fu_90324_p1 = tmp_1936_reg_106237.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1936_fu_90324_p2() {
    mul_ln1118_1936_fu_90324_p2 = (!mul_ln1118_1936_fu_90324_p0.read().is_01() || !mul_ln1118_1936_fu_90324_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1936_fu_90324_p0.read()) * sc_bigint<5>(mul_ln1118_1936_fu_90324_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1937_fu_90343_p0() {
    mul_ln1118_1937_fu_90343_p0 =  (sc_lv<12>) (sext_ln1116_137_cast_fu_54763_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1937_fu_90343_p1() {
    mul_ln1118_1937_fu_90343_p1 = tmp_1937_reg_106242.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1937_fu_90343_p2() {
    mul_ln1118_1937_fu_90343_p2 = (!mul_ln1118_1937_fu_90343_p0.read().is_01() || !mul_ln1118_1937_fu_90343_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1937_fu_90343_p0.read()) * sc_bigint<5>(mul_ln1118_1937_fu_90343_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1938_fu_90362_p0() {
    mul_ln1118_1938_fu_90362_p0 =  (sc_lv<12>) (sext_ln1116_138_cast_fu_54785_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1938_fu_90362_p1() {
    mul_ln1118_1938_fu_90362_p1 = tmp_1938_reg_106247.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1938_fu_90362_p2() {
    mul_ln1118_1938_fu_90362_p2 = (!mul_ln1118_1938_fu_90362_p0.read().is_01() || !mul_ln1118_1938_fu_90362_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1938_fu_90362_p0.read()) * sc_bigint<5>(mul_ln1118_1938_fu_90362_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1939_fu_90381_p0() {
    mul_ln1118_1939_fu_90381_p0 =  (sc_lv<12>) (sext_ln1116_139_cast_fu_54807_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1939_fu_90381_p1() {
    mul_ln1118_1939_fu_90381_p1 = tmp_1939_reg_106252.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1939_fu_90381_p2() {
    mul_ln1118_1939_fu_90381_p2 = (!mul_ln1118_1939_fu_90381_p0.read().is_01() || !mul_ln1118_1939_fu_90381_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1939_fu_90381_p0.read()) * sc_bigint<5>(mul_ln1118_1939_fu_90381_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_193_fu_55721_p0() {
    mul_ln1118_193_fu_55721_p0 =  (sc_lv<12>) (sext_ln1116_193_cast_fu_55715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_193_fu_55721_p1() {
    mul_ln1118_193_fu_55721_p1 = tmp_193_reg_97456.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_193_fu_55721_p2() {
    mul_ln1118_193_fu_55721_p2 = (!mul_ln1118_193_fu_55721_p0.read().is_01() || !mul_ln1118_193_fu_55721_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_193_fu_55721_p0.read()) * sc_bigint<5>(mul_ln1118_193_fu_55721_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1940_fu_90400_p0() {
    mul_ln1118_1940_fu_90400_p0 =  (sc_lv<12>) (sext_ln1116_140_cast_fu_54829_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1940_fu_90400_p1() {
    mul_ln1118_1940_fu_90400_p1 = tmp_1940_reg_106257.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1940_fu_90400_p2() {
    mul_ln1118_1940_fu_90400_p2 = (!mul_ln1118_1940_fu_90400_p0.read().is_01() || !mul_ln1118_1940_fu_90400_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1940_fu_90400_p0.read()) * sc_bigint<5>(mul_ln1118_1940_fu_90400_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1941_fu_90419_p0() {
    mul_ln1118_1941_fu_90419_p0 =  (sc_lv<12>) (sext_ln1116_141_cast_fu_54851_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1941_fu_90419_p1() {
    mul_ln1118_1941_fu_90419_p1 = tmp_1941_reg_106262.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1941_fu_90419_p2() {
    mul_ln1118_1941_fu_90419_p2 = (!mul_ln1118_1941_fu_90419_p0.read().is_01() || !mul_ln1118_1941_fu_90419_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1941_fu_90419_p0.read()) * sc_bigint<5>(mul_ln1118_1941_fu_90419_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1942_fu_90438_p0() {
    mul_ln1118_1942_fu_90438_p0 =  (sc_lv<12>) (sext_ln1116_142_cast_fu_54873_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1942_fu_90438_p1() {
    mul_ln1118_1942_fu_90438_p1 = tmp_1942_reg_106267.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1942_fu_90438_p2() {
    mul_ln1118_1942_fu_90438_p2 = (!mul_ln1118_1942_fu_90438_p0.read().is_01() || !mul_ln1118_1942_fu_90438_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1942_fu_90438_p0.read()) * sc_bigint<5>(mul_ln1118_1942_fu_90438_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1943_fu_90457_p0() {
    mul_ln1118_1943_fu_90457_p0 =  (sc_lv<12>) (sext_ln1116_143_cast_fu_54895_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1943_fu_90457_p1() {
    mul_ln1118_1943_fu_90457_p1 = tmp_1943_reg_106272.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1943_fu_90457_p2() {
    mul_ln1118_1943_fu_90457_p2 = (!mul_ln1118_1943_fu_90457_p0.read().is_01() || !mul_ln1118_1943_fu_90457_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1943_fu_90457_p0.read()) * sc_bigint<5>(mul_ln1118_1943_fu_90457_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1944_fu_90476_p0() {
    mul_ln1118_1944_fu_90476_p0 =  (sc_lv<12>) (sext_ln1116_144_cast_fu_54917_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1944_fu_90476_p1() {
    mul_ln1118_1944_fu_90476_p1 = tmp_1944_reg_106277.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1944_fu_90476_p2() {
    mul_ln1118_1944_fu_90476_p2 = (!mul_ln1118_1944_fu_90476_p0.read().is_01() || !mul_ln1118_1944_fu_90476_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1944_fu_90476_p0.read()) * sc_bigint<5>(mul_ln1118_1944_fu_90476_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1945_fu_90495_p0() {
    mul_ln1118_1945_fu_90495_p0 =  (sc_lv<12>) (sext_ln1116_145_cast_fu_54939_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1945_fu_90495_p1() {
    mul_ln1118_1945_fu_90495_p1 = tmp_1945_reg_106282.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1945_fu_90495_p2() {
    mul_ln1118_1945_fu_90495_p2 = (!mul_ln1118_1945_fu_90495_p0.read().is_01() || !mul_ln1118_1945_fu_90495_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1945_fu_90495_p0.read()) * sc_bigint<5>(mul_ln1118_1945_fu_90495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1946_fu_90514_p0() {
    mul_ln1118_1946_fu_90514_p0 =  (sc_lv<12>) (sext_ln1116_146_cast_fu_54961_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1946_fu_90514_p1() {
    mul_ln1118_1946_fu_90514_p1 = tmp_1946_reg_106287.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1946_fu_90514_p2() {
    mul_ln1118_1946_fu_90514_p2 = (!mul_ln1118_1946_fu_90514_p0.read().is_01() || !mul_ln1118_1946_fu_90514_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1946_fu_90514_p0.read()) * sc_bigint<5>(mul_ln1118_1946_fu_90514_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1947_fu_90533_p0() {
    mul_ln1118_1947_fu_90533_p0 =  (sc_lv<12>) (sext_ln1116_147_cast_fu_54983_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1947_fu_90533_p1() {
    mul_ln1118_1947_fu_90533_p1 = tmp_1947_reg_106292.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1947_fu_90533_p2() {
    mul_ln1118_1947_fu_90533_p2 = (!mul_ln1118_1947_fu_90533_p0.read().is_01() || !mul_ln1118_1947_fu_90533_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1947_fu_90533_p0.read()) * sc_bigint<5>(mul_ln1118_1947_fu_90533_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1948_fu_90552_p0() {
    mul_ln1118_1948_fu_90552_p0 =  (sc_lv<12>) (sext_ln1116_148_cast_fu_55005_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1948_fu_90552_p1() {
    mul_ln1118_1948_fu_90552_p1 = tmp_1948_reg_106297.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1948_fu_90552_p2() {
    mul_ln1118_1948_fu_90552_p2 = (!mul_ln1118_1948_fu_90552_p0.read().is_01() || !mul_ln1118_1948_fu_90552_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1948_fu_90552_p0.read()) * sc_bigint<5>(mul_ln1118_1948_fu_90552_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1949_fu_90571_p0() {
    mul_ln1118_1949_fu_90571_p0 =  (sc_lv<12>) (sext_ln1116_149_cast_fu_55027_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1949_fu_90571_p1() {
    mul_ln1118_1949_fu_90571_p1 = tmp_1949_reg_106302.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1949_fu_90571_p2() {
    mul_ln1118_1949_fu_90571_p2 = (!mul_ln1118_1949_fu_90571_p0.read().is_01() || !mul_ln1118_1949_fu_90571_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1949_fu_90571_p0.read()) * sc_bigint<5>(mul_ln1118_1949_fu_90571_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_194_fu_55743_p0() {
    mul_ln1118_194_fu_55743_p0 =  (sc_lv<12>) (sext_ln1116_194_cast_fu_55737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_194_fu_55743_p1() {
    mul_ln1118_194_fu_55743_p1 = tmp_194_reg_97466.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_194_fu_55743_p2() {
    mul_ln1118_194_fu_55743_p2 = (!mul_ln1118_194_fu_55743_p0.read().is_01() || !mul_ln1118_194_fu_55743_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_194_fu_55743_p0.read()) * sc_bigint<5>(mul_ln1118_194_fu_55743_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1950_fu_90590_p0() {
    mul_ln1118_1950_fu_90590_p0 =  (sc_lv<12>) (sext_ln1116_150_cast_fu_55049_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1950_fu_90590_p1() {
    mul_ln1118_1950_fu_90590_p1 = tmp_1950_reg_106307.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1950_fu_90590_p2() {
    mul_ln1118_1950_fu_90590_p2 = (!mul_ln1118_1950_fu_90590_p0.read().is_01() || !mul_ln1118_1950_fu_90590_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1950_fu_90590_p0.read()) * sc_bigint<5>(mul_ln1118_1950_fu_90590_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1951_fu_51585_p0() {
    mul_ln1118_1951_fu_51585_p0 = select_ln76_142_fu_25031_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1951_fu_51585_p1() {
    mul_ln1118_1951_fu_51585_p1 = tmp_1951_fu_51571_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1951_fu_51585_p2() {
    mul_ln1118_1951_fu_51585_p2 = (!mul_ln1118_1951_fu_51585_p0.read().is_01() || !mul_ln1118_1951_fu_51585_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1951_fu_51585_p0.read()) * sc_bigint<5>(mul_ln1118_1951_fu_51585_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1952_fu_51615_p0() {
    mul_ln1118_1952_fu_51615_p0 = select_ln76_143_fu_25053_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1952_fu_51615_p1() {
    mul_ln1118_1952_fu_51615_p1 = tmp_1952_fu_51601_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1952_fu_51615_p2() {
    mul_ln1118_1952_fu_51615_p2 = (!mul_ln1118_1952_fu_51615_p0.read().is_01() || !mul_ln1118_1952_fu_51615_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1952_fu_51615_p0.read()) * sc_bigint<5>(mul_ln1118_1952_fu_51615_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1953_fu_51645_p0() {
    mul_ln1118_1953_fu_51645_p0 =  (sc_lv<12>) (sext_ln1116_153_cast_fu_25093_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1953_fu_51645_p1() {
    mul_ln1118_1953_fu_51645_p1 = tmp_1953_fu_51631_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1953_fu_51645_p2() {
    mul_ln1118_1953_fu_51645_p2 = (!mul_ln1118_1953_fu_51645_p0.read().is_01() || !mul_ln1118_1953_fu_51645_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1953_fu_51645_p0.read()) * sc_bigint<5>(mul_ln1118_1953_fu_51645_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1954_fu_51675_p0() {
    mul_ln1118_1954_fu_51675_p0 =  (sc_lv<12>) (sext_ln1116_154_cast_fu_25135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1954_fu_51675_p1() {
    mul_ln1118_1954_fu_51675_p1 = tmp_1954_fu_51661_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1954_fu_51675_p2() {
    mul_ln1118_1954_fu_51675_p2 = (!mul_ln1118_1954_fu_51675_p0.read().is_01() || !mul_ln1118_1954_fu_51675_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1954_fu_51675_p0.read()) * sc_bigint<5>(mul_ln1118_1954_fu_51675_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1955_fu_51705_p0() {
    mul_ln1118_1955_fu_51705_p0 =  (sc_lv<12>) (sext_ln1116_155_cast_fu_25177_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1955_fu_51705_p1() {
    mul_ln1118_1955_fu_51705_p1 = tmp_1955_fu_51691_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1955_fu_51705_p2() {
    mul_ln1118_1955_fu_51705_p2 = (!mul_ln1118_1955_fu_51705_p0.read().is_01() || !mul_ln1118_1955_fu_51705_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1955_fu_51705_p0.read()) * sc_bigint<5>(mul_ln1118_1955_fu_51705_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1956_fu_51735_p0() {
    mul_ln1118_1956_fu_51735_p0 =  (sc_lv<12>) (sext_ln1116_156_cast_fu_25219_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1956_fu_51735_p1() {
    mul_ln1118_1956_fu_51735_p1 = tmp_1956_fu_51721_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1956_fu_51735_p2() {
    mul_ln1118_1956_fu_51735_p2 = (!mul_ln1118_1956_fu_51735_p0.read().is_01() || !mul_ln1118_1956_fu_51735_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1956_fu_51735_p0.read()) * sc_bigint<5>(mul_ln1118_1956_fu_51735_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1957_fu_51765_p0() {
    mul_ln1118_1957_fu_51765_p0 =  (sc_lv<12>) (sext_ln1116_157_cast_fu_25261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1957_fu_51765_p1() {
    mul_ln1118_1957_fu_51765_p1 = tmp_1957_fu_51751_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1957_fu_51765_p2() {
    mul_ln1118_1957_fu_51765_p2 = (!mul_ln1118_1957_fu_51765_p0.read().is_01() || !mul_ln1118_1957_fu_51765_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1957_fu_51765_p0.read()) * sc_bigint<5>(mul_ln1118_1957_fu_51765_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1958_fu_51795_p0() {
    mul_ln1118_1958_fu_51795_p0 =  (sc_lv<12>) (sext_ln1116_158_cast_fu_25303_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1958_fu_51795_p1() {
    mul_ln1118_1958_fu_51795_p1 = tmp_1958_fu_51781_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1958_fu_51795_p2() {
    mul_ln1118_1958_fu_51795_p2 = (!mul_ln1118_1958_fu_51795_p0.read().is_01() || !mul_ln1118_1958_fu_51795_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1958_fu_51795_p0.read()) * sc_bigint<5>(mul_ln1118_1958_fu_51795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1959_fu_90609_p0() {
    mul_ln1118_1959_fu_90609_p0 =  (sc_lv<12>) (sext_ln1116_159_cast_fu_55107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1959_fu_90609_p1() {
    mul_ln1118_1959_fu_90609_p1 = tmp_1959_reg_106352.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1959_fu_90609_p2() {
    mul_ln1118_1959_fu_90609_p2 = (!mul_ln1118_1959_fu_90609_p0.read().is_01() || !mul_ln1118_1959_fu_90609_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1959_fu_90609_p0.read()) * sc_bigint<5>(mul_ln1118_1959_fu_90609_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_195_fu_55765_p0() {
    mul_ln1118_195_fu_55765_p0 =  (sc_lv<12>) (sext_ln1116_195_cast_fu_55759_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_195_fu_55765_p1() {
    mul_ln1118_195_fu_55765_p1 = tmp_195_reg_97476.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_195_fu_55765_p2() {
    mul_ln1118_195_fu_55765_p2 = (!mul_ln1118_195_fu_55765_p0.read().is_01() || !mul_ln1118_195_fu_55765_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_195_fu_55765_p0.read()) * sc_bigint<5>(mul_ln1118_195_fu_55765_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1960_fu_90628_p0() {
    mul_ln1118_1960_fu_90628_p0 =  (sc_lv<12>) (sext_ln1116_160_cast_fu_55129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1960_fu_90628_p1() {
    mul_ln1118_1960_fu_90628_p1 = tmp_1960_reg_106357.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1960_fu_90628_p2() {
    mul_ln1118_1960_fu_90628_p2 = (!mul_ln1118_1960_fu_90628_p0.read().is_01() || !mul_ln1118_1960_fu_90628_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1960_fu_90628_p0.read()) * sc_bigint<5>(mul_ln1118_1960_fu_90628_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1961_fu_90647_p0() {
    mul_ln1118_1961_fu_90647_p0 =  (sc_lv<12>) (sext_ln1116_161_cast_fu_55151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1961_fu_90647_p1() {
    mul_ln1118_1961_fu_90647_p1 = tmp_1961_reg_106362.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1961_fu_90647_p2() {
    mul_ln1118_1961_fu_90647_p2 = (!mul_ln1118_1961_fu_90647_p0.read().is_01() || !mul_ln1118_1961_fu_90647_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1961_fu_90647_p0.read()) * sc_bigint<5>(mul_ln1118_1961_fu_90647_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1962_fu_90666_p0() {
    mul_ln1118_1962_fu_90666_p0 =  (sc_lv<12>) (sext_ln1116_162_cast_fu_55173_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1962_fu_90666_p1() {
    mul_ln1118_1962_fu_90666_p1 = tmp_1962_reg_106367.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1962_fu_90666_p2() {
    mul_ln1118_1962_fu_90666_p2 = (!mul_ln1118_1962_fu_90666_p0.read().is_01() || !mul_ln1118_1962_fu_90666_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1962_fu_90666_p0.read()) * sc_bigint<5>(mul_ln1118_1962_fu_90666_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1963_fu_90685_p0() {
    mul_ln1118_1963_fu_90685_p0 =  (sc_lv<12>) (sext_ln1116_163_cast_fu_55195_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1963_fu_90685_p1() {
    mul_ln1118_1963_fu_90685_p1 = tmp_1963_reg_106372.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1963_fu_90685_p2() {
    mul_ln1118_1963_fu_90685_p2 = (!mul_ln1118_1963_fu_90685_p0.read().is_01() || !mul_ln1118_1963_fu_90685_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1963_fu_90685_p0.read()) * sc_bigint<5>(mul_ln1118_1963_fu_90685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1964_fu_90704_p0() {
    mul_ln1118_1964_fu_90704_p0 =  (sc_lv<12>) (sext_ln1116_164_cast_fu_55217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1964_fu_90704_p1() {
    mul_ln1118_1964_fu_90704_p1 = tmp_1964_reg_106377.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1964_fu_90704_p2() {
    mul_ln1118_1964_fu_90704_p2 = (!mul_ln1118_1964_fu_90704_p0.read().is_01() || !mul_ln1118_1964_fu_90704_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1964_fu_90704_p0.read()) * sc_bigint<5>(mul_ln1118_1964_fu_90704_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1965_fu_90723_p0() {
    mul_ln1118_1965_fu_90723_p0 =  (sc_lv<12>) (sext_ln1116_165_cast_fu_55239_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1965_fu_90723_p1() {
    mul_ln1118_1965_fu_90723_p1 = tmp_1965_reg_106382.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1965_fu_90723_p2() {
    mul_ln1118_1965_fu_90723_p2 = (!mul_ln1118_1965_fu_90723_p0.read().is_01() || !mul_ln1118_1965_fu_90723_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1965_fu_90723_p0.read()) * sc_bigint<5>(mul_ln1118_1965_fu_90723_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1966_fu_90742_p0() {
    mul_ln1118_1966_fu_90742_p0 =  (sc_lv<12>) (sext_ln1116_166_cast_fu_55261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1966_fu_90742_p1() {
    mul_ln1118_1966_fu_90742_p1 = tmp_1966_reg_106387.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1966_fu_90742_p2() {
    mul_ln1118_1966_fu_90742_p2 = (!mul_ln1118_1966_fu_90742_p0.read().is_01() || !mul_ln1118_1966_fu_90742_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1966_fu_90742_p0.read()) * sc_bigint<5>(mul_ln1118_1966_fu_90742_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1967_fu_90761_p0() {
    mul_ln1118_1967_fu_90761_p0 =  (sc_lv<12>) (sext_ln1116_167_cast_fu_55283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1967_fu_90761_p1() {
    mul_ln1118_1967_fu_90761_p1 = tmp_1967_reg_106392.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1967_fu_90761_p2() {
    mul_ln1118_1967_fu_90761_p2 = (!mul_ln1118_1967_fu_90761_p0.read().is_01() || !mul_ln1118_1967_fu_90761_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1967_fu_90761_p0.read()) * sc_bigint<5>(mul_ln1118_1967_fu_90761_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1968_fu_90780_p0() {
    mul_ln1118_1968_fu_90780_p0 =  (sc_lv<12>) (sext_ln1116_168_cast_fu_55305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1968_fu_90780_p1() {
    mul_ln1118_1968_fu_90780_p1 = tmp_1968_reg_106397.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1968_fu_90780_p2() {
    mul_ln1118_1968_fu_90780_p2 = (!mul_ln1118_1968_fu_90780_p0.read().is_01() || !mul_ln1118_1968_fu_90780_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1968_fu_90780_p0.read()) * sc_bigint<5>(mul_ln1118_1968_fu_90780_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1969_fu_90799_p0() {
    mul_ln1118_1969_fu_90799_p0 =  (sc_lv<12>) (sext_ln1116_169_cast_fu_55327_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1969_fu_90799_p1() {
    mul_ln1118_1969_fu_90799_p1 = tmp_1969_reg_106402.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1969_fu_90799_p2() {
    mul_ln1118_1969_fu_90799_p2 = (!mul_ln1118_1969_fu_90799_p0.read().is_01() || !mul_ln1118_1969_fu_90799_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1969_fu_90799_p0.read()) * sc_bigint<5>(mul_ln1118_1969_fu_90799_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_196_fu_55787_p0() {
    mul_ln1118_196_fu_55787_p0 =  (sc_lv<12>) (sext_ln1116_196_cast_fu_55781_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_196_fu_55787_p1() {
    mul_ln1118_196_fu_55787_p1 = tmp_196_reg_97486.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_196_fu_55787_p2() {
    mul_ln1118_196_fu_55787_p2 = (!mul_ln1118_196_fu_55787_p0.read().is_01() || !mul_ln1118_196_fu_55787_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_196_fu_55787_p0.read()) * sc_bigint<5>(mul_ln1118_196_fu_55787_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1970_fu_90818_p0() {
    mul_ln1118_1970_fu_90818_p0 =  (sc_lv<12>) (sext_ln1116_170_cast_fu_55349_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1970_fu_90818_p1() {
    mul_ln1118_1970_fu_90818_p1 = tmp_1970_reg_106407.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1970_fu_90818_p2() {
    mul_ln1118_1970_fu_90818_p2 = (!mul_ln1118_1970_fu_90818_p0.read().is_01() || !mul_ln1118_1970_fu_90818_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1970_fu_90818_p0.read()) * sc_bigint<5>(mul_ln1118_1970_fu_90818_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1971_fu_90837_p0() {
    mul_ln1118_1971_fu_90837_p0 =  (sc_lv<12>) (sext_ln1116_171_cast_fu_55371_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1971_fu_90837_p1() {
    mul_ln1118_1971_fu_90837_p1 = tmp_1971_reg_106412.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1971_fu_90837_p2() {
    mul_ln1118_1971_fu_90837_p2 = (!mul_ln1118_1971_fu_90837_p0.read().is_01() || !mul_ln1118_1971_fu_90837_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1971_fu_90837_p0.read()) * sc_bigint<5>(mul_ln1118_1971_fu_90837_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1972_fu_90856_p0() {
    mul_ln1118_1972_fu_90856_p0 =  (sc_lv<12>) (sext_ln1116_172_cast_fu_55393_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1972_fu_90856_p1() {
    mul_ln1118_1972_fu_90856_p1 = tmp_1972_reg_106417.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1972_fu_90856_p2() {
    mul_ln1118_1972_fu_90856_p2 = (!mul_ln1118_1972_fu_90856_p0.read().is_01() || !mul_ln1118_1972_fu_90856_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1972_fu_90856_p0.read()) * sc_bigint<5>(mul_ln1118_1972_fu_90856_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1973_fu_90875_p0() {
    mul_ln1118_1973_fu_90875_p0 =  (sc_lv<12>) (sext_ln1116_173_cast_fu_55415_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1973_fu_90875_p1() {
    mul_ln1118_1973_fu_90875_p1 = tmp_1973_reg_106422.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1973_fu_90875_p2() {
    mul_ln1118_1973_fu_90875_p2 = (!mul_ln1118_1973_fu_90875_p0.read().is_01() || !mul_ln1118_1973_fu_90875_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1973_fu_90875_p0.read()) * sc_bigint<5>(mul_ln1118_1973_fu_90875_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1974_fu_90894_p0() {
    mul_ln1118_1974_fu_90894_p0 =  (sc_lv<12>) (sext_ln1116_174_cast_fu_55437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1974_fu_90894_p1() {
    mul_ln1118_1974_fu_90894_p1 = tmp_1974_reg_106427.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1974_fu_90894_p2() {
    mul_ln1118_1974_fu_90894_p2 = (!mul_ln1118_1974_fu_90894_p0.read().is_01() || !mul_ln1118_1974_fu_90894_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1974_fu_90894_p0.read()) * sc_bigint<5>(mul_ln1118_1974_fu_90894_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1975_fu_90913_p0() {
    mul_ln1118_1975_fu_90913_p0 =  (sc_lv<12>) (sext_ln1116_175_cast_fu_55459_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1975_fu_90913_p1() {
    mul_ln1118_1975_fu_90913_p1 = tmp_1975_reg_106432.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1975_fu_90913_p2() {
    mul_ln1118_1975_fu_90913_p2 = (!mul_ln1118_1975_fu_90913_p0.read().is_01() || !mul_ln1118_1975_fu_90913_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1975_fu_90913_p0.read()) * sc_bigint<5>(mul_ln1118_1975_fu_90913_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1976_fu_51995_p0() {
    mul_ln1118_1976_fu_51995_p0 = select_ln76_167_fu_25633_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1976_fu_51995_p1() {
    mul_ln1118_1976_fu_51995_p1 = tmp_1976_fu_51981_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1976_fu_51995_p2() {
    mul_ln1118_1976_fu_51995_p2 = (!mul_ln1118_1976_fu_51995_p0.read().is_01() || !mul_ln1118_1976_fu_51995_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1976_fu_51995_p0.read()) * sc_bigint<5>(mul_ln1118_1976_fu_51995_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1977_fu_52025_p0() {
    mul_ln1118_1977_fu_52025_p0 = select_ln76_168_fu_25655_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1977_fu_52025_p1() {
    mul_ln1118_1977_fu_52025_p1 = tmp_1977_fu_52011_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1977_fu_52025_p2() {
    mul_ln1118_1977_fu_52025_p2 = (!mul_ln1118_1977_fu_52025_p0.read().is_01() || !mul_ln1118_1977_fu_52025_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1977_fu_52025_p0.read()) * sc_bigint<5>(mul_ln1118_1977_fu_52025_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1978_fu_52055_p0() {
    mul_ln1118_1978_fu_52055_p0 =  (sc_lv<12>) (sext_ln1116_178_cast_fu_25695_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1978_fu_52055_p1() {
    mul_ln1118_1978_fu_52055_p1 = tmp_1978_fu_52041_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1978_fu_52055_p2() {
    mul_ln1118_1978_fu_52055_p2 = (!mul_ln1118_1978_fu_52055_p0.read().is_01() || !mul_ln1118_1978_fu_52055_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1978_fu_52055_p0.read()) * sc_bigint<5>(mul_ln1118_1978_fu_52055_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1979_fu_52085_p0() {
    mul_ln1118_1979_fu_52085_p0 =  (sc_lv<12>) (sext_ln1116_179_cast_fu_25737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1979_fu_52085_p1() {
    mul_ln1118_1979_fu_52085_p1 = tmp_1979_fu_52071_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1979_fu_52085_p2() {
    mul_ln1118_1979_fu_52085_p2 = (!mul_ln1118_1979_fu_52085_p0.read().is_01() || !mul_ln1118_1979_fu_52085_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1979_fu_52085_p0.read()) * sc_bigint<5>(mul_ln1118_1979_fu_52085_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_197_fu_55809_p0() {
    mul_ln1118_197_fu_55809_p0 =  (sc_lv<12>) (sext_ln1116_197_cast_fu_55803_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_197_fu_55809_p1() {
    mul_ln1118_197_fu_55809_p1 = tmp_197_reg_97496.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_197_fu_55809_p2() {
    mul_ln1118_197_fu_55809_p2 = (!mul_ln1118_197_fu_55809_p0.read().is_01() || !mul_ln1118_197_fu_55809_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_197_fu_55809_p0.read()) * sc_bigint<5>(mul_ln1118_197_fu_55809_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1980_fu_52115_p0() {
    mul_ln1118_1980_fu_52115_p0 =  (sc_lv<12>) (sext_ln1116_180_cast_fu_25779_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1980_fu_52115_p1() {
    mul_ln1118_1980_fu_52115_p1 = tmp_1980_fu_52101_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1980_fu_52115_p2() {
    mul_ln1118_1980_fu_52115_p2 = (!mul_ln1118_1980_fu_52115_p0.read().is_01() || !mul_ln1118_1980_fu_52115_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1980_fu_52115_p0.read()) * sc_bigint<5>(mul_ln1118_1980_fu_52115_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1981_fu_52145_p0() {
    mul_ln1118_1981_fu_52145_p0 =  (sc_lv<12>) (sext_ln1116_181_cast_fu_25821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1981_fu_52145_p1() {
    mul_ln1118_1981_fu_52145_p1 = tmp_1981_fu_52131_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1981_fu_52145_p2() {
    mul_ln1118_1981_fu_52145_p2 = (!mul_ln1118_1981_fu_52145_p0.read().is_01() || !mul_ln1118_1981_fu_52145_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1981_fu_52145_p0.read()) * sc_bigint<5>(mul_ln1118_1981_fu_52145_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1982_fu_52175_p0() {
    mul_ln1118_1982_fu_52175_p0 =  (sc_lv<12>) (sext_ln1116_182_cast_fu_25863_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1982_fu_52175_p1() {
    mul_ln1118_1982_fu_52175_p1 = tmp_1982_fu_52161_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1982_fu_52175_p2() {
    mul_ln1118_1982_fu_52175_p2 = (!mul_ln1118_1982_fu_52175_p0.read().is_01() || !mul_ln1118_1982_fu_52175_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1982_fu_52175_p0.read()) * sc_bigint<5>(mul_ln1118_1982_fu_52175_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1983_fu_52205_p0() {
    mul_ln1118_1983_fu_52205_p0 =  (sc_lv<12>) (sext_ln1116_183_cast_fu_25905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1983_fu_52205_p1() {
    mul_ln1118_1983_fu_52205_p1 = tmp_1983_fu_52191_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1983_fu_52205_p2() {
    mul_ln1118_1983_fu_52205_p2 = (!mul_ln1118_1983_fu_52205_p0.read().is_01() || !mul_ln1118_1983_fu_52205_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1983_fu_52205_p0.read()) * sc_bigint<5>(mul_ln1118_1983_fu_52205_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1984_fu_90932_p0() {
    mul_ln1118_1984_fu_90932_p0 =  (sc_lv<12>) (sext_ln1116_184_cast_fu_55517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1984_fu_90932_p1() {
    mul_ln1118_1984_fu_90932_p1 = tmp_1984_reg_106477.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1984_fu_90932_p2() {
    mul_ln1118_1984_fu_90932_p2 = (!mul_ln1118_1984_fu_90932_p0.read().is_01() || !mul_ln1118_1984_fu_90932_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1984_fu_90932_p0.read()) * sc_bigint<5>(mul_ln1118_1984_fu_90932_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1985_fu_90951_p0() {
    mul_ln1118_1985_fu_90951_p0 =  (sc_lv<12>) (sext_ln1116_185_cast_fu_55539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1985_fu_90951_p1() {
    mul_ln1118_1985_fu_90951_p1 = tmp_1985_reg_106482.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1985_fu_90951_p2() {
    mul_ln1118_1985_fu_90951_p2 = (!mul_ln1118_1985_fu_90951_p0.read().is_01() || !mul_ln1118_1985_fu_90951_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1985_fu_90951_p0.read()) * sc_bigint<5>(mul_ln1118_1985_fu_90951_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1986_fu_90970_p0() {
    mul_ln1118_1986_fu_90970_p0 =  (sc_lv<12>) (sext_ln1116_186_cast_fu_55561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1986_fu_90970_p1() {
    mul_ln1118_1986_fu_90970_p1 = tmp_1986_reg_106487.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1986_fu_90970_p2() {
    mul_ln1118_1986_fu_90970_p2 = (!mul_ln1118_1986_fu_90970_p0.read().is_01() || !mul_ln1118_1986_fu_90970_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1986_fu_90970_p0.read()) * sc_bigint<5>(mul_ln1118_1986_fu_90970_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1987_fu_90989_p0() {
    mul_ln1118_1987_fu_90989_p0 =  (sc_lv<12>) (sext_ln1116_187_cast_fu_55583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1987_fu_90989_p1() {
    mul_ln1118_1987_fu_90989_p1 = tmp_1987_reg_106492.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1987_fu_90989_p2() {
    mul_ln1118_1987_fu_90989_p2 = (!mul_ln1118_1987_fu_90989_p0.read().is_01() || !mul_ln1118_1987_fu_90989_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1987_fu_90989_p0.read()) * sc_bigint<5>(mul_ln1118_1987_fu_90989_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1988_fu_91008_p0() {
    mul_ln1118_1988_fu_91008_p0 =  (sc_lv<12>) (sext_ln1116_188_cast_fu_55605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1988_fu_91008_p1() {
    mul_ln1118_1988_fu_91008_p1 = tmp_1988_reg_106497.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1988_fu_91008_p2() {
    mul_ln1118_1988_fu_91008_p2 = (!mul_ln1118_1988_fu_91008_p0.read().is_01() || !mul_ln1118_1988_fu_91008_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1988_fu_91008_p0.read()) * sc_bigint<5>(mul_ln1118_1988_fu_91008_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1989_fu_91027_p0() {
    mul_ln1118_1989_fu_91027_p0 =  (sc_lv<12>) (sext_ln1116_189_cast_fu_55627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1989_fu_91027_p1() {
    mul_ln1118_1989_fu_91027_p1 = tmp_1989_reg_106502.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1989_fu_91027_p2() {
    mul_ln1118_1989_fu_91027_p2 = (!mul_ln1118_1989_fu_91027_p0.read().is_01() || !mul_ln1118_1989_fu_91027_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1989_fu_91027_p0.read()) * sc_bigint<5>(mul_ln1118_1989_fu_91027_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_198_fu_55831_p0() {
    mul_ln1118_198_fu_55831_p0 =  (sc_lv<12>) (sext_ln1116_198_cast_fu_55825_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_198_fu_55831_p1() {
    mul_ln1118_198_fu_55831_p1 = tmp_198_reg_97506.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_198_fu_55831_p2() {
    mul_ln1118_198_fu_55831_p2 = (!mul_ln1118_198_fu_55831_p0.read().is_01() || !mul_ln1118_198_fu_55831_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_198_fu_55831_p0.read()) * sc_bigint<5>(mul_ln1118_198_fu_55831_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1990_fu_91046_p0() {
    mul_ln1118_1990_fu_91046_p0 =  (sc_lv<12>) (sext_ln1116_190_cast_fu_55649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1990_fu_91046_p1() {
    mul_ln1118_1990_fu_91046_p1 = tmp_1990_reg_106507.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1990_fu_91046_p2() {
    mul_ln1118_1990_fu_91046_p2 = (!mul_ln1118_1990_fu_91046_p0.read().is_01() || !mul_ln1118_1990_fu_91046_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1990_fu_91046_p0.read()) * sc_bigint<5>(mul_ln1118_1990_fu_91046_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1991_fu_91065_p0() {
    mul_ln1118_1991_fu_91065_p0 =  (sc_lv<12>) (sext_ln1116_191_cast_fu_55671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1991_fu_91065_p1() {
    mul_ln1118_1991_fu_91065_p1 = tmp_1991_reg_106512.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1991_fu_91065_p2() {
    mul_ln1118_1991_fu_91065_p2 = (!mul_ln1118_1991_fu_91065_p0.read().is_01() || !mul_ln1118_1991_fu_91065_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1991_fu_91065_p0.read()) * sc_bigint<5>(mul_ln1118_1991_fu_91065_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1992_fu_91084_p0() {
    mul_ln1118_1992_fu_91084_p0 =  (sc_lv<12>) (sext_ln1116_192_cast_fu_55693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1992_fu_91084_p1() {
    mul_ln1118_1992_fu_91084_p1 = tmp_1992_reg_106517.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1992_fu_91084_p2() {
    mul_ln1118_1992_fu_91084_p2 = (!mul_ln1118_1992_fu_91084_p0.read().is_01() || !mul_ln1118_1992_fu_91084_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1992_fu_91084_p0.read()) * sc_bigint<5>(mul_ln1118_1992_fu_91084_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1993_fu_91103_p0() {
    mul_ln1118_1993_fu_91103_p0 =  (sc_lv<12>) (sext_ln1116_193_cast_fu_55715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1993_fu_91103_p1() {
    mul_ln1118_1993_fu_91103_p1 = tmp_1993_reg_106522.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1993_fu_91103_p2() {
    mul_ln1118_1993_fu_91103_p2 = (!mul_ln1118_1993_fu_91103_p0.read().is_01() || !mul_ln1118_1993_fu_91103_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1993_fu_91103_p0.read()) * sc_bigint<5>(mul_ln1118_1993_fu_91103_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1994_fu_91122_p0() {
    mul_ln1118_1994_fu_91122_p0 =  (sc_lv<12>) (sext_ln1116_194_cast_fu_55737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1994_fu_91122_p1() {
    mul_ln1118_1994_fu_91122_p1 = tmp_1994_reg_106527.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1994_fu_91122_p2() {
    mul_ln1118_1994_fu_91122_p2 = (!mul_ln1118_1994_fu_91122_p0.read().is_01() || !mul_ln1118_1994_fu_91122_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1994_fu_91122_p0.read()) * sc_bigint<5>(mul_ln1118_1994_fu_91122_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1995_fu_91141_p0() {
    mul_ln1118_1995_fu_91141_p0 =  (sc_lv<12>) (sext_ln1116_195_cast_fu_55759_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1995_fu_91141_p1() {
    mul_ln1118_1995_fu_91141_p1 = tmp_1995_reg_106532.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1995_fu_91141_p2() {
    mul_ln1118_1995_fu_91141_p2 = (!mul_ln1118_1995_fu_91141_p0.read().is_01() || !mul_ln1118_1995_fu_91141_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1995_fu_91141_p0.read()) * sc_bigint<5>(mul_ln1118_1995_fu_91141_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1996_fu_91160_p0() {
    mul_ln1118_1996_fu_91160_p0 =  (sc_lv<12>) (sext_ln1116_196_cast_fu_55781_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1996_fu_91160_p1() {
    mul_ln1118_1996_fu_91160_p1 = tmp_1996_reg_106537.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1996_fu_91160_p2() {
    mul_ln1118_1996_fu_91160_p2 = (!mul_ln1118_1996_fu_91160_p0.read().is_01() || !mul_ln1118_1996_fu_91160_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1996_fu_91160_p0.read()) * sc_bigint<5>(mul_ln1118_1996_fu_91160_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1997_fu_91179_p0() {
    mul_ln1118_1997_fu_91179_p0 =  (sc_lv<12>) (sext_ln1116_197_cast_fu_55803_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1997_fu_91179_p1() {
    mul_ln1118_1997_fu_91179_p1 = tmp_1997_reg_106542.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1997_fu_91179_p2() {
    mul_ln1118_1997_fu_91179_p2 = (!mul_ln1118_1997_fu_91179_p0.read().is_01() || !mul_ln1118_1997_fu_91179_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1997_fu_91179_p0.read()) * sc_bigint<5>(mul_ln1118_1997_fu_91179_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1998_fu_91198_p0() {
    mul_ln1118_1998_fu_91198_p0 =  (sc_lv<12>) (sext_ln1116_198_cast_fu_55825_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1998_fu_91198_p1() {
    mul_ln1118_1998_fu_91198_p1 = tmp_1998_reg_106547.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1998_fu_91198_p2() {
    mul_ln1118_1998_fu_91198_p2 = (!mul_ln1118_1998_fu_91198_p0.read().is_01() || !mul_ln1118_1998_fu_91198_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1998_fu_91198_p0.read()) * sc_bigint<5>(mul_ln1118_1998_fu_91198_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1999_fu_91217_p0() {
    mul_ln1118_1999_fu_91217_p0 =  (sc_lv<12>) (sext_ln1116_199_cast_fu_55847_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1999_fu_91217_p1() {
    mul_ln1118_1999_fu_91217_p1 = tmp_1999_reg_106552.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1999_fu_91217_p2() {
    mul_ln1118_1999_fu_91217_p2 = (!mul_ln1118_1999_fu_91217_p0.read().is_01() || !mul_ln1118_1999_fu_91217_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_1999_fu_91217_p0.read()) * sc_bigint<5>(mul_ln1118_1999_fu_91217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_199_fu_55853_p0() {
    mul_ln1118_199_fu_55853_p0 =  (sc_lv<12>) (sext_ln1116_199_cast_fu_55847_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_199_fu_55853_p1() {
    mul_ln1118_199_fu_55853_p1 = tmp_199_reg_97516.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_199_fu_55853_p2() {
    mul_ln1118_199_fu_55853_p2 = (!mul_ln1118_199_fu_55853_p0.read().is_01() || !mul_ln1118_199_fu_55853_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_199_fu_55853_p0.read()) * sc_bigint<5>(mul_ln1118_199_fu_55853_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_19_fu_52757_p0() {
    mul_ln1118_19_fu_52757_p0 =  (sc_lv<12>) (sext_ln1116_19_cast_fu_52751_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_19_fu_52757_p1() {
    mul_ln1118_19_fu_52757_p1 = tmp_20_reg_95850.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_19_fu_52757_p2() {
    mul_ln1118_19_fu_52757_p2 = (!mul_ln1118_19_fu_52757_p0.read().is_01() || !mul_ln1118_19_fu_52757_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_19_fu_52757_p0.read()) * sc_bigint<5>(mul_ln1118_19_fu_52757_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2000_fu_91236_p0() {
    mul_ln1118_2000_fu_91236_p0 =  (sc_lv<12>) (sext_ln1116_200_cast_fu_55869_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2000_fu_91236_p1() {
    mul_ln1118_2000_fu_91236_p1 = tmp_2000_reg_106557.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2000_fu_91236_p2() {
    mul_ln1118_2000_fu_91236_p2 = (!mul_ln1118_2000_fu_91236_p0.read().is_01() || !mul_ln1118_2000_fu_91236_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_2000_fu_91236_p0.read()) * sc_bigint<5>(mul_ln1118_2000_fu_91236_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2001_fu_52405_p0() {
    mul_ln1118_2001_fu_52405_p0 = select_ln76_192_fu_26235_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2001_fu_52405_p1() {
    mul_ln1118_2001_fu_52405_p1 = tmp_2001_fu_52391_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2001_fu_52405_p2() {
    mul_ln1118_2001_fu_52405_p2 = (!mul_ln1118_2001_fu_52405_p0.read().is_01() || !mul_ln1118_2001_fu_52405_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_2001_fu_52405_p0.read()) * sc_bigint<5>(mul_ln1118_2001_fu_52405_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2002_fu_52435_p0() {
    mul_ln1118_2002_fu_52435_p0 = select_ln76_193_fu_26257_p3.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2002_fu_52435_p1() {
    mul_ln1118_2002_fu_52435_p1 = tmp_2002_fu_52421_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2002_fu_52435_p2() {
    mul_ln1118_2002_fu_52435_p2 = (!mul_ln1118_2002_fu_52435_p0.read().is_01() || !mul_ln1118_2002_fu_52435_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_2002_fu_52435_p0.read()) * sc_bigint<5>(mul_ln1118_2002_fu_52435_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2003_fu_52465_p0() {
    mul_ln1118_2003_fu_52465_p0 =  (sc_lv<12>) (sext_ln1116_203_cast_fu_26297_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2003_fu_52465_p1() {
    mul_ln1118_2003_fu_52465_p1 = tmp_2003_fu_52451_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2003_fu_52465_p2() {
    mul_ln1118_2003_fu_52465_p2 = (!mul_ln1118_2003_fu_52465_p0.read().is_01() || !mul_ln1118_2003_fu_52465_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_2003_fu_52465_p0.read()) * sc_bigint<5>(mul_ln1118_2003_fu_52465_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2004_fu_52495_p0() {
    mul_ln1118_2004_fu_52495_p0 =  (sc_lv<12>) (sext_ln1116_204_cast_fu_26339_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2004_fu_52495_p1() {
    mul_ln1118_2004_fu_52495_p1 = tmp_2004_fu_52481_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2004_fu_52495_p2() {
    mul_ln1118_2004_fu_52495_p2 = (!mul_ln1118_2004_fu_52495_p0.read().is_01() || !mul_ln1118_2004_fu_52495_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_2004_fu_52495_p0.read()) * sc_bigint<5>(mul_ln1118_2004_fu_52495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2005_fu_52525_p0() {
    mul_ln1118_2005_fu_52525_p0 =  (sc_lv<12>) (sext_ln1116_205_cast_fu_26381_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2005_fu_52525_p1() {
    mul_ln1118_2005_fu_52525_p1 = tmp_2005_fu_52511_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_2005_fu_52525_p2() {
    mul_ln1118_2005_fu_52525_p2 = (!mul_ln1118_2005_fu_52525_p0.read().is_01() || !mul_ln1118_2005_fu_52525_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_2005_fu_52525_p0.read()) * sc_bigint<5>(mul_ln1118_2005_fu_52525_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_200_fu_55875_p0() {
    mul_ln1118_200_fu_55875_p0 =  (sc_lv<12>) (sext_ln1116_200_cast_fu_55869_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_200_fu_55875_p1() {
    mul_ln1118_200_fu_55875_p1 = tmp_200_reg_97526.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_200_fu_55875_p2() {
    mul_ln1118_200_fu_55875_p2 = (!mul_ln1118_200_fu_55875_p0.read().is_01() || !mul_ln1118_200_fu_55875_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_200_fu_55875_p0.read()) * sc_bigint<5>(mul_ln1118_200_fu_55875_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_201_fu_55894_p0() {
    mul_ln1118_201_fu_55894_p0 =  (sc_lv<12>) (sext_ln1116_201_cast_reg_97536.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_201_fu_55894_p1() {
    mul_ln1118_201_fu_55894_p1 = tmp_201_reg_97531.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_201_fu_55894_p2() {
    mul_ln1118_201_fu_55894_p2 = (!mul_ln1118_201_fu_55894_p0.read().is_01() || !mul_ln1118_201_fu_55894_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_201_fu_55894_p0.read()) * sc_bigint<5>(mul_ln1118_201_fu_55894_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_202_fu_55912_p0() {
    mul_ln1118_202_fu_55912_p0 =  (sc_lv<12>) (sext_ln1116_202_cast_reg_97554.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_202_fu_55912_p1() {
    mul_ln1118_202_fu_55912_p1 = tmp_202_reg_97549.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_202_fu_55912_p2() {
    mul_ln1118_202_fu_55912_p2 = (!mul_ln1118_202_fu_55912_p0.read().is_01() || !mul_ln1118_202_fu_55912_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_202_fu_55912_p0.read()) * sc_bigint<5>(mul_ln1118_202_fu_55912_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_203_fu_26305_p0() {
    mul_ln1118_203_fu_26305_p0 =  (sc_lv<12>) (sext_ln1116_203_cast_fu_26297_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_203_fu_26305_p1() {
    mul_ln1118_203_fu_26305_p1 = tmp_203_fu_26287_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_203_fu_26305_p2() {
    mul_ln1118_203_fu_26305_p2 = (!mul_ln1118_203_fu_26305_p0.read().is_01() || !mul_ln1118_203_fu_26305_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_203_fu_26305_p0.read()) * sc_bigint<5>(mul_ln1118_203_fu_26305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_204_fu_26347_p0() {
    mul_ln1118_204_fu_26347_p0 =  (sc_lv<12>) (sext_ln1116_204_cast_fu_26339_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_204_fu_26347_p1() {
    mul_ln1118_204_fu_26347_p1 = tmp_204_fu_26329_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_204_fu_26347_p2() {
    mul_ln1118_204_fu_26347_p2 = (!mul_ln1118_204_fu_26347_p0.read().is_01() || !mul_ln1118_204_fu_26347_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_204_fu_26347_p0.read()) * sc_bigint<5>(mul_ln1118_204_fu_26347_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_205_fu_26389_p0() {
    mul_ln1118_205_fu_26389_p0 =  (sc_lv<12>) (sext_ln1116_205_cast_fu_26381_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_205_fu_26389_p1() {
    mul_ln1118_205_fu_26389_p1 = tmp_205_fu_26371_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_205_fu_26389_p2() {
    mul_ln1118_205_fu_26389_p2 = (!mul_ln1118_205_fu_26389_p0.read().is_01() || !mul_ln1118_205_fu_26389_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_205_fu_26389_p0.read()) * sc_bigint<5>(mul_ln1118_205_fu_26389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_206_fu_26431_p0() {
    mul_ln1118_206_fu_26431_p0 =  (sc_lv<12>) (sext_ln1116_206_cast_fu_26423_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_206_fu_26431_p1() {
    mul_ln1118_206_fu_26431_p1 = tmp_206_fu_26413_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_206_fu_26431_p2() {
    mul_ln1118_206_fu_26431_p2 = (!mul_ln1118_206_fu_26431_p0.read().is_01() || !mul_ln1118_206_fu_26431_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_206_fu_26431_p0.read()) * sc_bigint<5>(mul_ln1118_206_fu_26431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_207_fu_26473_p0() {
    mul_ln1118_207_fu_26473_p0 =  (sc_lv<12>) (sext_ln1116_207_cast_fu_26465_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_207_fu_26473_p1() {
    mul_ln1118_207_fu_26473_p1 = tmp_207_fu_26455_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_207_fu_26473_p2() {
    mul_ln1118_207_fu_26473_p2 = (!mul_ln1118_207_fu_26473_p0.read().is_01() || !mul_ln1118_207_fu_26473_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_207_fu_26473_p0.read()) * sc_bigint<5>(mul_ln1118_207_fu_26473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_208_fu_26515_p0() {
    mul_ln1118_208_fu_26515_p0 =  (sc_lv<12>) (sext_ln1116_208_cast_fu_26507_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_208_fu_26515_p1() {
    mul_ln1118_208_fu_26515_p1 = tmp_208_fu_26497_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_208_fu_26515_p2() {
    mul_ln1118_208_fu_26515_p2 = (!mul_ln1118_208_fu_26515_p0.read().is_01() || !mul_ln1118_208_fu_26515_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_208_fu_26515_p0.read()) * sc_bigint<5>(mul_ln1118_208_fu_26515_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_209_fu_56918_p0() {
    mul_ln1118_209_fu_56918_p0 =  (sc_lv<12>) (sext_ln1116_cast_fu_52531_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_209_fu_56918_p1() {
    mul_ln1118_209_fu_56918_p1 = tmp_209_reg_97602.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_209_fu_56918_p2() {
    mul_ln1118_209_fu_56918_p2 = (!mul_ln1118_209_fu_56918_p0.read().is_01() || !mul_ln1118_209_fu_56918_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_209_fu_56918_p0.read()) * sc_bigint<5>(mul_ln1118_209_fu_56918_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_20_fu_52779_p0() {
    mul_ln1118_20_fu_52779_p0 =  (sc_lv<12>) (sext_ln1116_20_cast_fu_52773_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_20_fu_52779_p1() {
    mul_ln1118_20_fu_52779_p1 = tmp_s_reg_95860.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_20_fu_52779_p2() {
    mul_ln1118_20_fu_52779_p2 = (!mul_ln1118_20_fu_52779_p0.read().is_01() || !mul_ln1118_20_fu_52779_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_20_fu_52779_p0.read()) * sc_bigint<5>(mul_ln1118_20_fu_52779_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_210_fu_56937_p0() {
    mul_ln1118_210_fu_56937_p0 =  (sc_lv<12>) (sext_ln1116_10_cast_fu_52553_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_210_fu_56937_p1() {
    mul_ln1118_210_fu_56937_p1 = tmp_210_reg_97607.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_210_fu_56937_p2() {
    mul_ln1118_210_fu_56937_p2 = (!mul_ln1118_210_fu_56937_p0.read().is_01() || !mul_ln1118_210_fu_56937_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_210_fu_56937_p0.read()) * sc_bigint<5>(mul_ln1118_210_fu_56937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_211_fu_56956_p0() {
    mul_ln1118_211_fu_56956_p0 =  (sc_lv<12>) (sext_ln1116_11_cast_fu_52575_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_211_fu_56956_p1() {
    mul_ln1118_211_fu_56956_p1 = tmp_211_reg_97612.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_211_fu_56956_p2() {
    mul_ln1118_211_fu_56956_p2 = (!mul_ln1118_211_fu_56956_p0.read().is_01() || !mul_ln1118_211_fu_56956_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_211_fu_56956_p0.read()) * sc_bigint<5>(mul_ln1118_211_fu_56956_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_212_fu_56975_p0() {
    mul_ln1118_212_fu_56975_p0 =  (sc_lv<12>) (sext_ln1116_12_cast_fu_52597_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_212_fu_56975_p1() {
    mul_ln1118_212_fu_56975_p1 = tmp_212_reg_97617.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_212_fu_56975_p2() {
    mul_ln1118_212_fu_56975_p2 = (!mul_ln1118_212_fu_56975_p0.read().is_01() || !mul_ln1118_212_fu_56975_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_212_fu_56975_p0.read()) * sc_bigint<5>(mul_ln1118_212_fu_56975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_213_fu_56994_p0() {
    mul_ln1118_213_fu_56994_p0 =  (sc_lv<12>) (sext_ln1116_13_cast_fu_52619_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_213_fu_56994_p1() {
    mul_ln1118_213_fu_56994_p1 = tmp_213_reg_97622.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_213_fu_56994_p2() {
    mul_ln1118_213_fu_56994_p2 = (!mul_ln1118_213_fu_56994_p0.read().is_01() || !mul_ln1118_213_fu_56994_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_213_fu_56994_p0.read()) * sc_bigint<5>(mul_ln1118_213_fu_56994_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_214_fu_57013_p0() {
    mul_ln1118_214_fu_57013_p0 =  (sc_lv<12>) (sext_ln1116_14_cast_fu_52641_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_214_fu_57013_p1() {
    mul_ln1118_214_fu_57013_p1 = tmp_214_reg_97627.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_214_fu_57013_p2() {
    mul_ln1118_214_fu_57013_p2 = (!mul_ln1118_214_fu_57013_p0.read().is_01() || !mul_ln1118_214_fu_57013_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_214_fu_57013_p0.read()) * sc_bigint<5>(mul_ln1118_214_fu_57013_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_215_fu_57032_p0() {
    mul_ln1118_215_fu_57032_p0 =  (sc_lv<12>) (sext_ln1116_15_cast_fu_52663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_215_fu_57032_p1() {
    mul_ln1118_215_fu_57032_p1 = tmp_215_reg_97632.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_215_fu_57032_p2() {
    mul_ln1118_215_fu_57032_p2 = (!mul_ln1118_215_fu_57032_p0.read().is_01() || !mul_ln1118_215_fu_57032_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_215_fu_57032_p0.read()) * sc_bigint<5>(mul_ln1118_215_fu_57032_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_216_fu_57051_p0() {
    mul_ln1118_216_fu_57051_p0 =  (sc_lv<12>) (sext_ln1116_16_cast_fu_52685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_216_fu_57051_p1() {
    mul_ln1118_216_fu_57051_p1 = tmp_216_reg_97637.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_216_fu_57051_p2() {
    mul_ln1118_216_fu_57051_p2 = (!mul_ln1118_216_fu_57051_p0.read().is_01() || !mul_ln1118_216_fu_57051_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_216_fu_57051_p0.read()) * sc_bigint<5>(mul_ln1118_216_fu_57051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_217_fu_57070_p0() {
    mul_ln1118_217_fu_57070_p0 =  (sc_lv<12>) (sext_ln1116_17_cast_fu_52707_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_217_fu_57070_p1() {
    mul_ln1118_217_fu_57070_p1 = tmp_217_reg_97642.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_217_fu_57070_p2() {
    mul_ln1118_217_fu_57070_p2 = (!mul_ln1118_217_fu_57070_p0.read().is_01() || !mul_ln1118_217_fu_57070_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_217_fu_57070_p0.read()) * sc_bigint<5>(mul_ln1118_217_fu_57070_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_218_fu_57089_p0() {
    mul_ln1118_218_fu_57089_p0 =  (sc_lv<12>) (sext_ln1116_18_cast_fu_52729_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_218_fu_57089_p1() {
    mul_ln1118_218_fu_57089_p1 = tmp_218_reg_97647.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_218_fu_57089_p2() {
    mul_ln1118_218_fu_57089_p2 = (!mul_ln1118_218_fu_57089_p0.read().is_01() || !mul_ln1118_218_fu_57089_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_218_fu_57089_p0.read()) * sc_bigint<5>(mul_ln1118_218_fu_57089_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_219_fu_57108_p0() {
    mul_ln1118_219_fu_57108_p0 =  (sc_lv<12>) (sext_ln1116_19_cast_fu_52751_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_219_fu_57108_p1() {
    mul_ln1118_219_fu_57108_p1 = tmp_219_reg_97652.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_219_fu_57108_p2() {
    mul_ln1118_219_fu_57108_p2 = (!mul_ln1118_219_fu_57108_p0.read().is_01() || !mul_ln1118_219_fu_57108_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_219_fu_57108_p0.read()) * sc_bigint<5>(mul_ln1118_219_fu_57108_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_21_fu_52801_p0() {
    mul_ln1118_21_fu_52801_p0 =  (sc_lv<12>) (sext_ln1116_21_cast_fu_52795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_21_fu_52801_p1() {
    mul_ln1118_21_fu_52801_p1 = tmp_21_reg_95870.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_21_fu_52801_p2() {
    mul_ln1118_21_fu_52801_p2 = (!mul_ln1118_21_fu_52801_p0.read().is_01() || !mul_ln1118_21_fu_52801_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_21_fu_52801_p0.read()) * sc_bigint<5>(mul_ln1118_21_fu_52801_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_220_fu_57127_p0() {
    mul_ln1118_220_fu_57127_p0 =  (sc_lv<12>) (sext_ln1116_20_cast_fu_52773_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_220_fu_57127_p1() {
    mul_ln1118_220_fu_57127_p1 = tmp_220_reg_97657.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_220_fu_57127_p2() {
    mul_ln1118_220_fu_57127_p2 = (!mul_ln1118_220_fu_57127_p0.read().is_01() || !mul_ln1118_220_fu_57127_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_220_fu_57127_p0.read()) * sc_bigint<5>(mul_ln1118_220_fu_57127_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_221_fu_57146_p0() {
    mul_ln1118_221_fu_57146_p0 =  (sc_lv<12>) (sext_ln1116_21_cast_fu_52795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_221_fu_57146_p1() {
    mul_ln1118_221_fu_57146_p1 = tmp_221_reg_97662.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_221_fu_57146_p2() {
    mul_ln1118_221_fu_57146_p2 = (!mul_ln1118_221_fu_57146_p0.read().is_01() || !mul_ln1118_221_fu_57146_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_221_fu_57146_p0.read()) * sc_bigint<5>(mul_ln1118_221_fu_57146_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_222_fu_57165_p0() {
    mul_ln1118_222_fu_57165_p0 =  (sc_lv<12>) (sext_ln1116_22_cast_fu_52817_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_222_fu_57165_p1() {
    mul_ln1118_222_fu_57165_p1 = tmp_222_reg_97667.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_222_fu_57165_p2() {
    mul_ln1118_222_fu_57165_p2 = (!mul_ln1118_222_fu_57165_p0.read().is_01() || !mul_ln1118_222_fu_57165_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_222_fu_57165_p0.read()) * sc_bigint<5>(mul_ln1118_222_fu_57165_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_223_fu_57184_p0() {
    mul_ln1118_223_fu_57184_p0 =  (sc_lv<12>) (sext_ln1116_23_cast_fu_52839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_223_fu_57184_p1() {
    mul_ln1118_223_fu_57184_p1 = tmp_223_reg_97672.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_223_fu_57184_p2() {
    mul_ln1118_223_fu_57184_p2 = (!mul_ln1118_223_fu_57184_p0.read().is_01() || !mul_ln1118_223_fu_57184_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_223_fu_57184_p0.read()) * sc_bigint<5>(mul_ln1118_223_fu_57184_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_224_fu_57203_p0() {
    mul_ln1118_224_fu_57203_p0 =  (sc_lv<12>) (sext_ln1116_24_cast_fu_52861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_224_fu_57203_p1() {
    mul_ln1118_224_fu_57203_p1 = tmp_224_reg_97677.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_224_fu_57203_p2() {
    mul_ln1118_224_fu_57203_p2 = (!mul_ln1118_224_fu_57203_p0.read().is_01() || !mul_ln1118_224_fu_57203_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_224_fu_57203_p0.read()) * sc_bigint<5>(mul_ln1118_224_fu_57203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_225_fu_57222_p0() {
    mul_ln1118_225_fu_57222_p0 =  (sc_lv<12>) (sext_ln1116_25_cast_fu_52883_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_225_fu_57222_p1() {
    mul_ln1118_225_fu_57222_p1 = tmp_225_reg_97682.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_225_fu_57222_p2() {
    mul_ln1118_225_fu_57222_p2 = (!mul_ln1118_225_fu_57222_p0.read().is_01() || !mul_ln1118_225_fu_57222_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_225_fu_57222_p0.read()) * sc_bigint<5>(mul_ln1118_225_fu_57222_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_226_fu_57241_p0() {
    mul_ln1118_226_fu_57241_p0 =  (sc_lv<12>) (sext_ln1116_26_cast_fu_52905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_226_fu_57241_p1() {
    mul_ln1118_226_fu_57241_p1 = tmp_226_reg_97687.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_226_fu_57241_p2() {
    mul_ln1118_226_fu_57241_p2 = (!mul_ln1118_226_fu_57241_p0.read().is_01() || !mul_ln1118_226_fu_57241_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_226_fu_57241_p0.read()) * sc_bigint<5>(mul_ln1118_226_fu_57241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_227_fu_57260_p0() {
    mul_ln1118_227_fu_57260_p0 =  (sc_lv<12>) (sext_ln1116_27_cast_fu_52927_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_227_fu_57260_p1() {
    mul_ln1118_227_fu_57260_p1 = tmp_227_reg_97692.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_227_fu_57260_p2() {
    mul_ln1118_227_fu_57260_p2 = (!mul_ln1118_227_fu_57260_p0.read().is_01() || !mul_ln1118_227_fu_57260_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_227_fu_57260_p0.read()) * sc_bigint<5>(mul_ln1118_227_fu_57260_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_228_fu_26735_p0() {
    mul_ln1118_228_fu_26735_p0 =  (sc_lv<12>) (sext_ln1116_28_cast_fu_22199_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_228_fu_26735_p1() {
    mul_ln1118_228_fu_26735_p1 = tmp_228_fu_26721_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_228_fu_26735_p2() {
    mul_ln1118_228_fu_26735_p2 = (!mul_ln1118_228_fu_26735_p0.read().is_01() || !mul_ln1118_228_fu_26735_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_228_fu_26735_p0.read()) * sc_bigint<5>(mul_ln1118_228_fu_26735_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_229_fu_26765_p0() {
    mul_ln1118_229_fu_26765_p0 =  (sc_lv<12>) (sext_ln1116_29_cast_fu_22241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_229_fu_26765_p1() {
    mul_ln1118_229_fu_26765_p1 = tmp_229_fu_26751_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_229_fu_26765_p2() {
    mul_ln1118_229_fu_26765_p2 = (!mul_ln1118_229_fu_26765_p0.read().is_01() || !mul_ln1118_229_fu_26765_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_229_fu_26765_p0.read()) * sc_bigint<5>(mul_ln1118_229_fu_26765_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_22_fu_52823_p0() {
    mul_ln1118_22_fu_52823_p0 =  (sc_lv<12>) (sext_ln1116_22_cast_fu_52817_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_22_fu_52823_p1() {
    mul_ln1118_22_fu_52823_p1 = tmp_22_reg_95880.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_22_fu_52823_p2() {
    mul_ln1118_22_fu_52823_p2 = (!mul_ln1118_22_fu_52823_p0.read().is_01() || !mul_ln1118_22_fu_52823_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_22_fu_52823_p0.read()) * sc_bigint<5>(mul_ln1118_22_fu_52823_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_230_fu_26795_p0() {
    mul_ln1118_230_fu_26795_p0 =  (sc_lv<12>) (sext_ln1116_30_cast_fu_22283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_230_fu_26795_p1() {
    mul_ln1118_230_fu_26795_p1 = tmp_230_fu_26781_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_230_fu_26795_p2() {
    mul_ln1118_230_fu_26795_p2 = (!mul_ln1118_230_fu_26795_p0.read().is_01() || !mul_ln1118_230_fu_26795_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_230_fu_26795_p0.read()) * sc_bigint<5>(mul_ln1118_230_fu_26795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_231_fu_26825_p0() {
    mul_ln1118_231_fu_26825_p0 =  (sc_lv<12>) (sext_ln1116_31_cast_fu_22325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_231_fu_26825_p1() {
    mul_ln1118_231_fu_26825_p1 = tmp_231_fu_26811_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_231_fu_26825_p2() {
    mul_ln1118_231_fu_26825_p2 = (!mul_ln1118_231_fu_26825_p0.read().is_01() || !mul_ln1118_231_fu_26825_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_231_fu_26825_p0.read()) * sc_bigint<5>(mul_ln1118_231_fu_26825_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_232_fu_26855_p0() {
    mul_ln1118_232_fu_26855_p0 =  (sc_lv<12>) (sext_ln1116_32_cast_fu_22367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_232_fu_26855_p1() {
    mul_ln1118_232_fu_26855_p1 = tmp_232_fu_26841_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_232_fu_26855_p2() {
    mul_ln1118_232_fu_26855_p2 = (!mul_ln1118_232_fu_26855_p0.read().is_01() || !mul_ln1118_232_fu_26855_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_232_fu_26855_p0.read()) * sc_bigint<5>(mul_ln1118_232_fu_26855_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_233_fu_26885_p0() {
    mul_ln1118_233_fu_26885_p0 =  (sc_lv<12>) (sext_ln1116_33_cast_fu_22409_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_233_fu_26885_p1() {
    mul_ln1118_233_fu_26885_p1 = tmp_233_fu_26871_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_233_fu_26885_p2() {
    mul_ln1118_233_fu_26885_p2 = (!mul_ln1118_233_fu_26885_p0.read().is_01() || !mul_ln1118_233_fu_26885_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_233_fu_26885_p0.read()) * sc_bigint<5>(mul_ln1118_233_fu_26885_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_234_fu_57279_p0() {
    mul_ln1118_234_fu_57279_p0 =  (sc_lv<12>) (sext_ln1116_34_cast_fu_52949_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_234_fu_57279_p1() {
    mul_ln1118_234_fu_57279_p1 = tmp_234_reg_97727.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_234_fu_57279_p2() {
    mul_ln1118_234_fu_57279_p2 = (!mul_ln1118_234_fu_57279_p0.read().is_01() || !mul_ln1118_234_fu_57279_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_234_fu_57279_p0.read()) * sc_bigint<5>(mul_ln1118_234_fu_57279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_235_fu_57298_p0() {
    mul_ln1118_235_fu_57298_p0 =  (sc_lv<12>) (sext_ln1116_35_cast_fu_52971_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_235_fu_57298_p1() {
    mul_ln1118_235_fu_57298_p1 = tmp_235_reg_97732.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_235_fu_57298_p2() {
    mul_ln1118_235_fu_57298_p2 = (!mul_ln1118_235_fu_57298_p0.read().is_01() || !mul_ln1118_235_fu_57298_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_235_fu_57298_p0.read()) * sc_bigint<5>(mul_ln1118_235_fu_57298_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_236_fu_57317_p0() {
    mul_ln1118_236_fu_57317_p0 =  (sc_lv<12>) (sext_ln1116_36_cast_fu_52993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_236_fu_57317_p1() {
    mul_ln1118_236_fu_57317_p1 = tmp_236_reg_97737.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_236_fu_57317_p2() {
    mul_ln1118_236_fu_57317_p2 = (!mul_ln1118_236_fu_57317_p0.read().is_01() || !mul_ln1118_236_fu_57317_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_236_fu_57317_p0.read()) * sc_bigint<5>(mul_ln1118_236_fu_57317_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_237_fu_57336_p0() {
    mul_ln1118_237_fu_57336_p0 =  (sc_lv<12>) (sext_ln1116_37_cast_fu_53015_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_237_fu_57336_p1() {
    mul_ln1118_237_fu_57336_p1 = tmp_237_reg_97742.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_237_fu_57336_p2() {
    mul_ln1118_237_fu_57336_p2 = (!mul_ln1118_237_fu_57336_p0.read().is_01() || !mul_ln1118_237_fu_57336_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_237_fu_57336_p0.read()) * sc_bigint<5>(mul_ln1118_237_fu_57336_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_238_fu_57355_p0() {
    mul_ln1118_238_fu_57355_p0 =  (sc_lv<12>) (sext_ln1116_38_cast_fu_53037_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_238_fu_57355_p1() {
    mul_ln1118_238_fu_57355_p1 = tmp_238_reg_97747.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_238_fu_57355_p2() {
    mul_ln1118_238_fu_57355_p2 = (!mul_ln1118_238_fu_57355_p0.read().is_01() || !mul_ln1118_238_fu_57355_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_238_fu_57355_p0.read()) * sc_bigint<5>(mul_ln1118_238_fu_57355_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_239_fu_57374_p0() {
    mul_ln1118_239_fu_57374_p0 =  (sc_lv<12>) (sext_ln1116_39_cast_fu_53059_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_239_fu_57374_p1() {
    mul_ln1118_239_fu_57374_p1 = tmp_239_reg_97752.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_239_fu_57374_p2() {
    mul_ln1118_239_fu_57374_p2 = (!mul_ln1118_239_fu_57374_p0.read().is_01() || !mul_ln1118_239_fu_57374_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_239_fu_57374_p0.read()) * sc_bigint<5>(mul_ln1118_239_fu_57374_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_23_fu_52845_p0() {
    mul_ln1118_23_fu_52845_p0 =  (sc_lv<12>) (sext_ln1116_23_cast_fu_52839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_23_fu_52845_p1() {
    mul_ln1118_23_fu_52845_p1 = tmp_23_reg_95890.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_23_fu_52845_p2() {
    mul_ln1118_23_fu_52845_p2 = (!mul_ln1118_23_fu_52845_p0.read().is_01() || !mul_ln1118_23_fu_52845_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_23_fu_52845_p0.read()) * sc_bigint<5>(mul_ln1118_23_fu_52845_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_240_fu_57393_p0() {
    mul_ln1118_240_fu_57393_p0 =  (sc_lv<12>) (sext_ln1116_40_cast_fu_53081_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_240_fu_57393_p1() {
    mul_ln1118_240_fu_57393_p1 = tmp_240_reg_97757.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_240_fu_57393_p2() {
    mul_ln1118_240_fu_57393_p2 = (!mul_ln1118_240_fu_57393_p0.read().is_01() || !mul_ln1118_240_fu_57393_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_240_fu_57393_p0.read()) * sc_bigint<5>(mul_ln1118_240_fu_57393_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_241_fu_57412_p0() {
    mul_ln1118_241_fu_57412_p0 =  (sc_lv<12>) (sext_ln1116_41_cast_fu_53103_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_241_fu_57412_p1() {
    mul_ln1118_241_fu_57412_p1 = tmp_241_reg_97762.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_241_fu_57412_p2() {
    mul_ln1118_241_fu_57412_p2 = (!mul_ln1118_241_fu_57412_p0.read().is_01() || !mul_ln1118_241_fu_57412_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_241_fu_57412_p0.read()) * sc_bigint<5>(mul_ln1118_241_fu_57412_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_242_fu_57431_p0() {
    mul_ln1118_242_fu_57431_p0 =  (sc_lv<12>) (sext_ln1116_42_cast_fu_53125_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_242_fu_57431_p1() {
    mul_ln1118_242_fu_57431_p1 = tmp_242_reg_97767.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_242_fu_57431_p2() {
    mul_ln1118_242_fu_57431_p2 = (!mul_ln1118_242_fu_57431_p0.read().is_01() || !mul_ln1118_242_fu_57431_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_242_fu_57431_p0.read()) * sc_bigint<5>(mul_ln1118_242_fu_57431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_243_fu_57450_p0() {
    mul_ln1118_243_fu_57450_p0 =  (sc_lv<12>) (sext_ln1116_43_cast_fu_53147_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_243_fu_57450_p1() {
    mul_ln1118_243_fu_57450_p1 = tmp_243_reg_97772.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_243_fu_57450_p2() {
    mul_ln1118_243_fu_57450_p2 = (!mul_ln1118_243_fu_57450_p0.read().is_01() || !mul_ln1118_243_fu_57450_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_243_fu_57450_p0.read()) * sc_bigint<5>(mul_ln1118_243_fu_57450_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_244_fu_57469_p0() {
    mul_ln1118_244_fu_57469_p0 =  (sc_lv<12>) (sext_ln1116_44_cast_fu_53169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_244_fu_57469_p1() {
    mul_ln1118_244_fu_57469_p1 = tmp_244_reg_97777.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_244_fu_57469_p2() {
    mul_ln1118_244_fu_57469_p2 = (!mul_ln1118_244_fu_57469_p0.read().is_01() || !mul_ln1118_244_fu_57469_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_244_fu_57469_p0.read()) * sc_bigint<5>(mul_ln1118_244_fu_57469_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_245_fu_57488_p0() {
    mul_ln1118_245_fu_57488_p0 =  (sc_lv<12>) (sext_ln1116_45_cast_fu_53191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_245_fu_57488_p1() {
    mul_ln1118_245_fu_57488_p1 = tmp_245_reg_97782.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_245_fu_57488_p2() {
    mul_ln1118_245_fu_57488_p2 = (!mul_ln1118_245_fu_57488_p0.read().is_01() || !mul_ln1118_245_fu_57488_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_245_fu_57488_p0.read()) * sc_bigint<5>(mul_ln1118_245_fu_57488_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_246_fu_57507_p0() {
    mul_ln1118_246_fu_57507_p0 =  (sc_lv<12>) (sext_ln1116_46_cast_fu_53213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_246_fu_57507_p1() {
    mul_ln1118_246_fu_57507_p1 = tmp_246_reg_97787.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_246_fu_57507_p2() {
    mul_ln1118_246_fu_57507_p2 = (!mul_ln1118_246_fu_57507_p0.read().is_01() || !mul_ln1118_246_fu_57507_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_246_fu_57507_p0.read()) * sc_bigint<5>(mul_ln1118_246_fu_57507_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_247_fu_57526_p0() {
    mul_ln1118_247_fu_57526_p0 =  (sc_lv<12>) (sext_ln1116_47_cast_fu_53235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_247_fu_57526_p1() {
    mul_ln1118_247_fu_57526_p1 = tmp_247_reg_97792.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_247_fu_57526_p2() {
    mul_ln1118_247_fu_57526_p2 = (!mul_ln1118_247_fu_57526_p0.read().is_01() || !mul_ln1118_247_fu_57526_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_247_fu_57526_p0.read()) * sc_bigint<5>(mul_ln1118_247_fu_57526_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_248_fu_57545_p0() {
    mul_ln1118_248_fu_57545_p0 =  (sc_lv<12>) (sext_ln1116_48_cast_fu_53257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_248_fu_57545_p1() {
    mul_ln1118_248_fu_57545_p1 = tmp_248_reg_97797.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_248_fu_57545_p2() {
    mul_ln1118_248_fu_57545_p2 = (!mul_ln1118_248_fu_57545_p0.read().is_01() || !mul_ln1118_248_fu_57545_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_248_fu_57545_p0.read()) * sc_bigint<5>(mul_ln1118_248_fu_57545_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_249_fu_57564_p0() {
    mul_ln1118_249_fu_57564_p0 =  (sc_lv<12>) (sext_ln1116_49_cast_fu_53279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_249_fu_57564_p1() {
    mul_ln1118_249_fu_57564_p1 = tmp_249_reg_97802.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_249_fu_57564_p2() {
    mul_ln1118_249_fu_57564_p2 = (!mul_ln1118_249_fu_57564_p0.read().is_01() || !mul_ln1118_249_fu_57564_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_249_fu_57564_p0.read()) * sc_bigint<5>(mul_ln1118_249_fu_57564_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_24_fu_52867_p0() {
    mul_ln1118_24_fu_52867_p0 =  (sc_lv<12>) (sext_ln1116_24_cast_fu_52861_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_24_fu_52867_p1() {
    mul_ln1118_24_fu_52867_p1 = tmp_24_reg_95900.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_24_fu_52867_p2() {
    mul_ln1118_24_fu_52867_p2 = (!mul_ln1118_24_fu_52867_p0.read().is_01() || !mul_ln1118_24_fu_52867_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_24_fu_52867_p0.read()) * sc_bigint<5>(mul_ln1118_24_fu_52867_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_250_fu_57583_p0() {
    mul_ln1118_250_fu_57583_p0 =  (sc_lv<12>) (sext_ln1116_50_cast_fu_53301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_250_fu_57583_p1() {
    mul_ln1118_250_fu_57583_p1 = tmp_250_reg_97807.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_250_fu_57583_p2() {
    mul_ln1118_250_fu_57583_p2 = (!mul_ln1118_250_fu_57583_p0.read().is_01() || !mul_ln1118_250_fu_57583_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_250_fu_57583_p0.read()) * sc_bigint<5>(mul_ln1118_250_fu_57583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_251_fu_57602_p0() {
    mul_ln1118_251_fu_57602_p0 =  (sc_lv<12>) (sext_ln1116_51_cast_fu_53323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_251_fu_57602_p1() {
    mul_ln1118_251_fu_57602_p1 = tmp_251_reg_97812.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_251_fu_57602_p2() {
    mul_ln1118_251_fu_57602_p2 = (!mul_ln1118_251_fu_57602_p0.read().is_01() || !mul_ln1118_251_fu_57602_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_251_fu_57602_p0.read()) * sc_bigint<5>(mul_ln1118_251_fu_57602_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_252_fu_57621_p0() {
    mul_ln1118_252_fu_57621_p0 =  (sc_lv<12>) (sext_ln1116_52_cast_reg_96150.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_252_fu_57621_p1() {
    mul_ln1118_252_fu_57621_p1 = tmp_252_reg_97817.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_252_fu_57621_p2() {
    mul_ln1118_252_fu_57621_p2 = (!mul_ln1118_252_fu_57621_p0.read().is_01() || !mul_ln1118_252_fu_57621_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_252_fu_57621_p0.read()) * sc_bigint<5>(mul_ln1118_252_fu_57621_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_253_fu_27105_p0() {
    mul_ln1118_253_fu_27105_p0 =  (sc_lv<12>) (sext_ln1116_53_cast_fu_22797_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_253_fu_27105_p1() {
    mul_ln1118_253_fu_27105_p1 = tmp_253_fu_27091_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_253_fu_27105_p2() {
    mul_ln1118_253_fu_27105_p2 = (!mul_ln1118_253_fu_27105_p0.read().is_01() || !mul_ln1118_253_fu_27105_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_253_fu_27105_p0.read()) * sc_bigint<5>(mul_ln1118_253_fu_27105_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_254_fu_27135_p0() {
    mul_ln1118_254_fu_27135_p0 =  (sc_lv<12>) (sext_ln1116_54_cast_fu_22839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_254_fu_27135_p1() {
    mul_ln1118_254_fu_27135_p1 = tmp_254_fu_27121_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_254_fu_27135_p2() {
    mul_ln1118_254_fu_27135_p2 = (!mul_ln1118_254_fu_27135_p0.read().is_01() || !mul_ln1118_254_fu_27135_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_254_fu_27135_p0.read()) * sc_bigint<5>(mul_ln1118_254_fu_27135_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_255_fu_27165_p0() {
    mul_ln1118_255_fu_27165_p0 =  (sc_lv<12>) (sext_ln1116_55_cast_fu_22881_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_255_fu_27165_p1() {
    mul_ln1118_255_fu_27165_p1 = tmp_255_fu_27151_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_255_fu_27165_p2() {
    mul_ln1118_255_fu_27165_p2 = (!mul_ln1118_255_fu_27165_p0.read().is_01() || !mul_ln1118_255_fu_27165_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_255_fu_27165_p0.read()) * sc_bigint<5>(mul_ln1118_255_fu_27165_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_256_fu_27195_p0() {
    mul_ln1118_256_fu_27195_p0 =  (sc_lv<12>) (sext_ln1116_56_cast_fu_22923_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_256_fu_27195_p1() {
    mul_ln1118_256_fu_27195_p1 = tmp_256_fu_27181_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_256_fu_27195_p2() {
    mul_ln1118_256_fu_27195_p2 = (!mul_ln1118_256_fu_27195_p0.read().is_01() || !mul_ln1118_256_fu_27195_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_256_fu_27195_p0.read()) * sc_bigint<5>(mul_ln1118_256_fu_27195_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_257_fu_27225_p0() {
    mul_ln1118_257_fu_27225_p0 =  (sc_lv<12>) (sext_ln1116_57_cast_fu_22965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_257_fu_27225_p1() {
    mul_ln1118_257_fu_27225_p1 = tmp_257_fu_27211_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_257_fu_27225_p2() {
    mul_ln1118_257_fu_27225_p2 = (!mul_ln1118_257_fu_27225_p0.read().is_01() || !mul_ln1118_257_fu_27225_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_257_fu_27225_p0.read()) * sc_bigint<5>(mul_ln1118_257_fu_27225_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_258_fu_27255_p0() {
    mul_ln1118_258_fu_27255_p0 =  (sc_lv<12>) (sext_ln1116_58_cast_fu_23007_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_258_fu_27255_p1() {
    mul_ln1118_258_fu_27255_p1 = tmp_258_fu_27241_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_258_fu_27255_p2() {
    mul_ln1118_258_fu_27255_p2 = (!mul_ln1118_258_fu_27255_p0.read().is_01() || !mul_ln1118_258_fu_27255_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_258_fu_27255_p0.read()) * sc_bigint<5>(mul_ln1118_258_fu_27255_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_259_fu_57639_p0() {
    mul_ln1118_259_fu_57639_p0 =  (sc_lv<12>) (sext_ln1116_59_cast_fu_53363_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_259_fu_57639_p1() {
    mul_ln1118_259_fu_57639_p1 = tmp_259_reg_97852.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_259_fu_57639_p2() {
    mul_ln1118_259_fu_57639_p2 = (!mul_ln1118_259_fu_57639_p0.read().is_01() || !mul_ln1118_259_fu_57639_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_259_fu_57639_p0.read()) * sc_bigint<5>(mul_ln1118_259_fu_57639_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_25_fu_52889_p0() {
    mul_ln1118_25_fu_52889_p0 =  (sc_lv<12>) (sext_ln1116_25_cast_fu_52883_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_25_fu_52889_p1() {
    mul_ln1118_25_fu_52889_p1 = tmp_25_reg_95910.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_25_fu_52889_p2() {
    mul_ln1118_25_fu_52889_p2 = (!mul_ln1118_25_fu_52889_p0.read().is_01() || !mul_ln1118_25_fu_52889_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_25_fu_52889_p0.read()) * sc_bigint<5>(mul_ln1118_25_fu_52889_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_260_fu_57658_p0() {
    mul_ln1118_260_fu_57658_p0 =  (sc_lv<12>) (sext_ln1116_60_cast_fu_53385_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_260_fu_57658_p1() {
    mul_ln1118_260_fu_57658_p1 = tmp_260_reg_97857.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_260_fu_57658_p2() {
    mul_ln1118_260_fu_57658_p2 = (!mul_ln1118_260_fu_57658_p0.read().is_01() || !mul_ln1118_260_fu_57658_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_260_fu_57658_p0.read()) * sc_bigint<5>(mul_ln1118_260_fu_57658_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_261_fu_57677_p0() {
    mul_ln1118_261_fu_57677_p0 =  (sc_lv<12>) (sext_ln1116_61_cast_fu_53407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_261_fu_57677_p1() {
    mul_ln1118_261_fu_57677_p1 = tmp_261_reg_97862.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_261_fu_57677_p2() {
    mul_ln1118_261_fu_57677_p2 = (!mul_ln1118_261_fu_57677_p0.read().is_01() || !mul_ln1118_261_fu_57677_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_261_fu_57677_p0.read()) * sc_bigint<5>(mul_ln1118_261_fu_57677_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_262_fu_57696_p0() {
    mul_ln1118_262_fu_57696_p0 =  (sc_lv<12>) (sext_ln1116_62_cast_fu_53429_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_262_fu_57696_p1() {
    mul_ln1118_262_fu_57696_p1 = tmp_262_reg_97867.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_262_fu_57696_p2() {
    mul_ln1118_262_fu_57696_p2 = (!mul_ln1118_262_fu_57696_p0.read().is_01() || !mul_ln1118_262_fu_57696_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_262_fu_57696_p0.read()) * sc_bigint<5>(mul_ln1118_262_fu_57696_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_263_fu_57715_p0() {
    mul_ln1118_263_fu_57715_p0 =  (sc_lv<12>) (sext_ln1116_63_cast_fu_53451_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_263_fu_57715_p1() {
    mul_ln1118_263_fu_57715_p1 = tmp_263_reg_97872.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_263_fu_57715_p2() {
    mul_ln1118_263_fu_57715_p2 = (!mul_ln1118_263_fu_57715_p0.read().is_01() || !mul_ln1118_263_fu_57715_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_263_fu_57715_p0.read()) * sc_bigint<5>(mul_ln1118_263_fu_57715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_264_fu_57734_p0() {
    mul_ln1118_264_fu_57734_p0 =  (sc_lv<12>) (sext_ln1116_64_cast_fu_53473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_264_fu_57734_p1() {
    mul_ln1118_264_fu_57734_p1 = tmp_264_reg_97877.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_264_fu_57734_p2() {
    mul_ln1118_264_fu_57734_p2 = (!mul_ln1118_264_fu_57734_p0.read().is_01() || !mul_ln1118_264_fu_57734_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_264_fu_57734_p0.read()) * sc_bigint<5>(mul_ln1118_264_fu_57734_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_265_fu_57753_p0() {
    mul_ln1118_265_fu_57753_p0 =  (sc_lv<12>) (sext_ln1116_65_cast_fu_53495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_265_fu_57753_p1() {
    mul_ln1118_265_fu_57753_p1 = tmp_265_reg_97882.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_265_fu_57753_p2() {
    mul_ln1118_265_fu_57753_p2 = (!mul_ln1118_265_fu_57753_p0.read().is_01() || !mul_ln1118_265_fu_57753_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_265_fu_57753_p0.read()) * sc_bigint<5>(mul_ln1118_265_fu_57753_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_266_fu_57772_p0() {
    mul_ln1118_266_fu_57772_p0 =  (sc_lv<12>) (sext_ln1116_66_cast_fu_53517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_266_fu_57772_p1() {
    mul_ln1118_266_fu_57772_p1 = tmp_266_reg_97887.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_266_fu_57772_p2() {
    mul_ln1118_266_fu_57772_p2 = (!mul_ln1118_266_fu_57772_p0.read().is_01() || !mul_ln1118_266_fu_57772_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_266_fu_57772_p0.read()) * sc_bigint<5>(mul_ln1118_266_fu_57772_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_267_fu_57791_p0() {
    mul_ln1118_267_fu_57791_p0 =  (sc_lv<12>) (sext_ln1116_67_cast_fu_53539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_267_fu_57791_p1() {
    mul_ln1118_267_fu_57791_p1 = tmp_267_reg_97892.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_267_fu_57791_p2() {
    mul_ln1118_267_fu_57791_p2 = (!mul_ln1118_267_fu_57791_p0.read().is_01() || !mul_ln1118_267_fu_57791_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_267_fu_57791_p0.read()) * sc_bigint<5>(mul_ln1118_267_fu_57791_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_268_fu_57810_p0() {
    mul_ln1118_268_fu_57810_p0 =  (sc_lv<12>) (sext_ln1116_68_cast_fu_53561_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_268_fu_57810_p1() {
    mul_ln1118_268_fu_57810_p1 = tmp_268_reg_97897.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_268_fu_57810_p2() {
    mul_ln1118_268_fu_57810_p2 = (!mul_ln1118_268_fu_57810_p0.read().is_01() || !mul_ln1118_268_fu_57810_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_268_fu_57810_p0.read()) * sc_bigint<5>(mul_ln1118_268_fu_57810_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_269_fu_57829_p0() {
    mul_ln1118_269_fu_57829_p0 =  (sc_lv<12>) (sext_ln1116_69_cast_fu_53583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_269_fu_57829_p1() {
    mul_ln1118_269_fu_57829_p1 = tmp_269_reg_97902.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_269_fu_57829_p2() {
    mul_ln1118_269_fu_57829_p2 = (!mul_ln1118_269_fu_57829_p0.read().is_01() || !mul_ln1118_269_fu_57829_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_269_fu_57829_p0.read()) * sc_bigint<5>(mul_ln1118_269_fu_57829_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_26_fu_52911_p0() {
    mul_ln1118_26_fu_52911_p0 =  (sc_lv<12>) (sext_ln1116_26_cast_fu_52905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_26_fu_52911_p1() {
    mul_ln1118_26_fu_52911_p1 = tmp_26_reg_95920.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_26_fu_52911_p2() {
    mul_ln1118_26_fu_52911_p2 = (!mul_ln1118_26_fu_52911_p0.read().is_01() || !mul_ln1118_26_fu_52911_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_26_fu_52911_p0.read()) * sc_bigint<5>(mul_ln1118_26_fu_52911_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_270_fu_57848_p0() {
    mul_ln1118_270_fu_57848_p0 =  (sc_lv<12>) (sext_ln1116_70_cast_fu_53605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_270_fu_57848_p1() {
    mul_ln1118_270_fu_57848_p1 = tmp_270_reg_97907.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_270_fu_57848_p2() {
    mul_ln1118_270_fu_57848_p2 = (!mul_ln1118_270_fu_57848_p0.read().is_01() || !mul_ln1118_270_fu_57848_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_270_fu_57848_p0.read()) * sc_bigint<5>(mul_ln1118_270_fu_57848_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_271_fu_57867_p0() {
    mul_ln1118_271_fu_57867_p0 =  (sc_lv<12>) (sext_ln1116_71_cast_fu_53627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_271_fu_57867_p1() {
    mul_ln1118_271_fu_57867_p1 = tmp_271_reg_97912.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_271_fu_57867_p2() {
    mul_ln1118_271_fu_57867_p2 = (!mul_ln1118_271_fu_57867_p0.read().is_01() || !mul_ln1118_271_fu_57867_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_271_fu_57867_p0.read()) * sc_bigint<5>(mul_ln1118_271_fu_57867_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_272_fu_57886_p0() {
    mul_ln1118_272_fu_57886_p0 =  (sc_lv<12>) (sext_ln1116_72_cast_fu_53649_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_272_fu_57886_p1() {
    mul_ln1118_272_fu_57886_p1 = tmp_272_reg_97917.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_272_fu_57886_p2() {
    mul_ln1118_272_fu_57886_p2 = (!mul_ln1118_272_fu_57886_p0.read().is_01() || !mul_ln1118_272_fu_57886_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_272_fu_57886_p0.read()) * sc_bigint<5>(mul_ln1118_272_fu_57886_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_273_fu_57905_p0() {
    mul_ln1118_273_fu_57905_p0 =  (sc_lv<12>) (sext_ln1116_73_cast_fu_53671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_273_fu_57905_p1() {
    mul_ln1118_273_fu_57905_p1 = tmp_273_reg_97922.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_273_fu_57905_p2() {
    mul_ln1118_273_fu_57905_p2 = (!mul_ln1118_273_fu_57905_p0.read().is_01() || !mul_ln1118_273_fu_57905_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_273_fu_57905_p0.read()) * sc_bigint<5>(mul_ln1118_273_fu_57905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_274_fu_57924_p0() {
    mul_ln1118_274_fu_57924_p0 =  (sc_lv<12>) (sext_ln1116_74_cast_fu_53693_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_274_fu_57924_p1() {
    mul_ln1118_274_fu_57924_p1 = tmp_274_reg_97927.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_274_fu_57924_p2() {
    mul_ln1118_274_fu_57924_p2 = (!mul_ln1118_274_fu_57924_p0.read().is_01() || !mul_ln1118_274_fu_57924_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_274_fu_57924_p0.read()) * sc_bigint<5>(mul_ln1118_274_fu_57924_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_275_fu_57943_p0() {
    mul_ln1118_275_fu_57943_p0 =  (sc_lv<12>) (sext_ln1116_75_cast_fu_53715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_275_fu_57943_p1() {
    mul_ln1118_275_fu_57943_p1 = tmp_275_reg_97932.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_275_fu_57943_p2() {
    mul_ln1118_275_fu_57943_p2 = (!mul_ln1118_275_fu_57943_p0.read().is_01() || !mul_ln1118_275_fu_57943_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_275_fu_57943_p0.read()) * sc_bigint<5>(mul_ln1118_275_fu_57943_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_276_fu_57962_p0() {
    mul_ln1118_276_fu_57962_p0 =  (sc_lv<12>) (sext_ln1116_76_cast_fu_53737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_276_fu_57962_p1() {
    mul_ln1118_276_fu_57962_p1 = tmp_276_reg_97937.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_276_fu_57962_p2() {
    mul_ln1118_276_fu_57962_p2 = (!mul_ln1118_276_fu_57962_p0.read().is_01() || !mul_ln1118_276_fu_57962_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_276_fu_57962_p0.read()) * sc_bigint<5>(mul_ln1118_276_fu_57962_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_277_fu_57981_p0() {
    mul_ln1118_277_fu_57981_p0 =  (sc_lv<12>) (sext_ln1116_77_cast_reg_96378.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_277_fu_57981_p1() {
    mul_ln1118_277_fu_57981_p1 = tmp_277_reg_97942.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_277_fu_57981_p2() {
    mul_ln1118_277_fu_57981_p2 = (!mul_ln1118_277_fu_57981_p0.read().is_01() || !mul_ln1118_277_fu_57981_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_277_fu_57981_p0.read()) * sc_bigint<5>(mul_ln1118_277_fu_57981_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_278_fu_27475_p0() {
    mul_ln1118_278_fu_27475_p0 =  (sc_lv<12>) (sext_ln1116_78_cast_fu_23395_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_278_fu_27475_p1() {
    mul_ln1118_278_fu_27475_p1 = tmp_278_fu_27461_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_278_fu_27475_p2() {
    mul_ln1118_278_fu_27475_p2 = (!mul_ln1118_278_fu_27475_p0.read().is_01() || !mul_ln1118_278_fu_27475_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_278_fu_27475_p0.read()) * sc_bigint<5>(mul_ln1118_278_fu_27475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_279_fu_27505_p0() {
    mul_ln1118_279_fu_27505_p0 =  (sc_lv<12>) (sext_ln1116_79_cast_fu_23437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_279_fu_27505_p1() {
    mul_ln1118_279_fu_27505_p1 = tmp_279_fu_27491_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_279_fu_27505_p2() {
    mul_ln1118_279_fu_27505_p2 = (!mul_ln1118_279_fu_27505_p0.read().is_01() || !mul_ln1118_279_fu_27505_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_279_fu_27505_p0.read()) * sc_bigint<5>(mul_ln1118_279_fu_27505_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_27_fu_52933_p0() {
    mul_ln1118_27_fu_52933_p0 =  (sc_lv<12>) (sext_ln1116_27_cast_fu_52927_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_27_fu_52933_p1() {
    mul_ln1118_27_fu_52933_p1 = tmp_27_reg_95930.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_27_fu_52933_p2() {
    mul_ln1118_27_fu_52933_p2 = (!mul_ln1118_27_fu_52933_p0.read().is_01() || !mul_ln1118_27_fu_52933_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_27_fu_52933_p0.read()) * sc_bigint<5>(mul_ln1118_27_fu_52933_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_280_fu_27535_p0() {
    mul_ln1118_280_fu_27535_p0 =  (sc_lv<12>) (sext_ln1116_80_cast_fu_23479_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_280_fu_27535_p1() {
    mul_ln1118_280_fu_27535_p1 = tmp_280_fu_27521_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_280_fu_27535_p2() {
    mul_ln1118_280_fu_27535_p2 = (!mul_ln1118_280_fu_27535_p0.read().is_01() || !mul_ln1118_280_fu_27535_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_280_fu_27535_p0.read()) * sc_bigint<5>(mul_ln1118_280_fu_27535_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_281_fu_27565_p0() {
    mul_ln1118_281_fu_27565_p0 =  (sc_lv<12>) (sext_ln1116_81_cast_fu_23521_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_281_fu_27565_p1() {
    mul_ln1118_281_fu_27565_p1 = tmp_281_fu_27551_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_281_fu_27565_p2() {
    mul_ln1118_281_fu_27565_p2 = (!mul_ln1118_281_fu_27565_p0.read().is_01() || !mul_ln1118_281_fu_27565_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_281_fu_27565_p0.read()) * sc_bigint<5>(mul_ln1118_281_fu_27565_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_282_fu_27595_p0() {
    mul_ln1118_282_fu_27595_p0 =  (sc_lv<12>) (sext_ln1116_82_cast_fu_23563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_282_fu_27595_p1() {
    mul_ln1118_282_fu_27595_p1 = tmp_282_fu_27581_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_282_fu_27595_p2() {
    mul_ln1118_282_fu_27595_p2 = (!mul_ln1118_282_fu_27595_p0.read().is_01() || !mul_ln1118_282_fu_27595_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_282_fu_27595_p0.read()) * sc_bigint<5>(mul_ln1118_282_fu_27595_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_283_fu_27625_p0() {
    mul_ln1118_283_fu_27625_p0 =  (sc_lv<12>) (sext_ln1116_83_cast_fu_23605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_283_fu_27625_p1() {
    mul_ln1118_283_fu_27625_p1 = tmp_283_fu_27611_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_283_fu_27625_p2() {
    mul_ln1118_283_fu_27625_p2 = (!mul_ln1118_283_fu_27625_p0.read().is_01() || !mul_ln1118_283_fu_27625_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_283_fu_27625_p0.read()) * sc_bigint<5>(mul_ln1118_283_fu_27625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_284_fu_57999_p0() {
    mul_ln1118_284_fu_57999_p0 =  (sc_lv<12>) (sext_ln1116_84_cast_fu_53777_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_284_fu_57999_p1() {
    mul_ln1118_284_fu_57999_p1 = tmp_284_reg_97977.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_284_fu_57999_p2() {
    mul_ln1118_284_fu_57999_p2 = (!mul_ln1118_284_fu_57999_p0.read().is_01() || !mul_ln1118_284_fu_57999_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_284_fu_57999_p0.read()) * sc_bigint<5>(mul_ln1118_284_fu_57999_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_285_fu_58018_p0() {
    mul_ln1118_285_fu_58018_p0 =  (sc_lv<12>) (sext_ln1116_85_cast_fu_53799_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_285_fu_58018_p1() {
    mul_ln1118_285_fu_58018_p1 = tmp_285_reg_97982.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_285_fu_58018_p2() {
    mul_ln1118_285_fu_58018_p2 = (!mul_ln1118_285_fu_58018_p0.read().is_01() || !mul_ln1118_285_fu_58018_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_285_fu_58018_p0.read()) * sc_bigint<5>(mul_ln1118_285_fu_58018_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_286_fu_58037_p0() {
    mul_ln1118_286_fu_58037_p0 =  (sc_lv<12>) (sext_ln1116_86_cast_fu_53821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_286_fu_58037_p1() {
    mul_ln1118_286_fu_58037_p1 = tmp_286_reg_97987.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_286_fu_58037_p2() {
    mul_ln1118_286_fu_58037_p2 = (!mul_ln1118_286_fu_58037_p0.read().is_01() || !mul_ln1118_286_fu_58037_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_286_fu_58037_p0.read()) * sc_bigint<5>(mul_ln1118_286_fu_58037_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_287_fu_58056_p0() {
    mul_ln1118_287_fu_58056_p0 =  (sc_lv<12>) (sext_ln1116_87_cast_fu_53843_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_287_fu_58056_p1() {
    mul_ln1118_287_fu_58056_p1 = tmp_287_reg_97992.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_287_fu_58056_p2() {
    mul_ln1118_287_fu_58056_p2 = (!mul_ln1118_287_fu_58056_p0.read().is_01() || !mul_ln1118_287_fu_58056_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_287_fu_58056_p0.read()) * sc_bigint<5>(mul_ln1118_287_fu_58056_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_288_fu_58075_p0() {
    mul_ln1118_288_fu_58075_p0 =  (sc_lv<12>) (sext_ln1116_88_cast_fu_53865_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_288_fu_58075_p1() {
    mul_ln1118_288_fu_58075_p1 = tmp_288_reg_97997.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_288_fu_58075_p2() {
    mul_ln1118_288_fu_58075_p2 = (!mul_ln1118_288_fu_58075_p0.read().is_01() || !mul_ln1118_288_fu_58075_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_288_fu_58075_p0.read()) * sc_bigint<5>(mul_ln1118_288_fu_58075_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_289_fu_58094_p0() {
    mul_ln1118_289_fu_58094_p0 =  (sc_lv<12>) (sext_ln1116_89_cast_fu_53887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_289_fu_58094_p1() {
    mul_ln1118_289_fu_58094_p1 = tmp_289_reg_98002.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_289_fu_58094_p2() {
    mul_ln1118_289_fu_58094_p2 = (!mul_ln1118_289_fu_58094_p0.read().is_01() || !mul_ln1118_289_fu_58094_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_289_fu_58094_p0.read()) * sc_bigint<5>(mul_ln1118_289_fu_58094_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_28_fu_22207_p0() {
    mul_ln1118_28_fu_22207_p0 =  (sc_lv<12>) (sext_ln1116_28_cast_fu_22199_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_28_fu_22207_p1() {
    mul_ln1118_28_fu_22207_p1 = tmp_28_fu_22189_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_28_fu_22207_p2() {
    mul_ln1118_28_fu_22207_p2 = (!mul_ln1118_28_fu_22207_p0.read().is_01() || !mul_ln1118_28_fu_22207_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_28_fu_22207_p0.read()) * sc_bigint<5>(mul_ln1118_28_fu_22207_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_290_fu_58113_p0() {
    mul_ln1118_290_fu_58113_p0 =  (sc_lv<12>) (sext_ln1116_90_cast_fu_53909_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_290_fu_58113_p1() {
    mul_ln1118_290_fu_58113_p1 = tmp_290_reg_98007.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_290_fu_58113_p2() {
    mul_ln1118_290_fu_58113_p2 = (!mul_ln1118_290_fu_58113_p0.read().is_01() || !mul_ln1118_290_fu_58113_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_290_fu_58113_p0.read()) * sc_bigint<5>(mul_ln1118_290_fu_58113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_291_fu_58132_p0() {
    mul_ln1118_291_fu_58132_p0 =  (sc_lv<12>) (sext_ln1116_91_cast_fu_53931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_291_fu_58132_p1() {
    mul_ln1118_291_fu_58132_p1 = tmp_291_reg_98012.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_291_fu_58132_p2() {
    mul_ln1118_291_fu_58132_p2 = (!mul_ln1118_291_fu_58132_p0.read().is_01() || !mul_ln1118_291_fu_58132_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_291_fu_58132_p0.read()) * sc_bigint<5>(mul_ln1118_291_fu_58132_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_292_fu_58151_p0() {
    mul_ln1118_292_fu_58151_p0 =  (sc_lv<12>) (sext_ln1116_92_cast_fu_53953_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_292_fu_58151_p1() {
    mul_ln1118_292_fu_58151_p1 = tmp_292_reg_98017.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_292_fu_58151_p2() {
    mul_ln1118_292_fu_58151_p2 = (!mul_ln1118_292_fu_58151_p0.read().is_01() || !mul_ln1118_292_fu_58151_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_292_fu_58151_p0.read()) * sc_bigint<5>(mul_ln1118_292_fu_58151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_293_fu_58170_p0() {
    mul_ln1118_293_fu_58170_p0 =  (sc_lv<12>) (sext_ln1116_93_cast_fu_53975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_293_fu_58170_p1() {
    mul_ln1118_293_fu_58170_p1 = tmp_293_reg_98022.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_293_fu_58170_p2() {
    mul_ln1118_293_fu_58170_p2 = (!mul_ln1118_293_fu_58170_p0.read().is_01() || !mul_ln1118_293_fu_58170_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_293_fu_58170_p0.read()) * sc_bigint<5>(mul_ln1118_293_fu_58170_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_294_fu_58189_p0() {
    mul_ln1118_294_fu_58189_p0 =  (sc_lv<12>) (sext_ln1116_94_cast_fu_53997_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_294_fu_58189_p1() {
    mul_ln1118_294_fu_58189_p1 = tmp_294_reg_98027.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_294_fu_58189_p2() {
    mul_ln1118_294_fu_58189_p2 = (!mul_ln1118_294_fu_58189_p0.read().is_01() || !mul_ln1118_294_fu_58189_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_294_fu_58189_p0.read()) * sc_bigint<5>(mul_ln1118_294_fu_58189_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_295_fu_58208_p0() {
    mul_ln1118_295_fu_58208_p0 =  (sc_lv<12>) (sext_ln1116_95_cast_fu_54019_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_295_fu_58208_p1() {
    mul_ln1118_295_fu_58208_p1 = tmp_295_reg_98032.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_295_fu_58208_p2() {
    mul_ln1118_295_fu_58208_p2 = (!mul_ln1118_295_fu_58208_p0.read().is_01() || !mul_ln1118_295_fu_58208_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_295_fu_58208_p0.read()) * sc_bigint<5>(mul_ln1118_295_fu_58208_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_296_fu_58227_p0() {
    mul_ln1118_296_fu_58227_p0 =  (sc_lv<12>) (sext_ln1116_96_cast_fu_54041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_296_fu_58227_p1() {
    mul_ln1118_296_fu_58227_p1 = tmp_296_reg_98037.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_296_fu_58227_p2() {
    mul_ln1118_296_fu_58227_p2 = (!mul_ln1118_296_fu_58227_p0.read().is_01() || !mul_ln1118_296_fu_58227_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_296_fu_58227_p0.read()) * sc_bigint<5>(mul_ln1118_296_fu_58227_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_297_fu_58246_p0() {
    mul_ln1118_297_fu_58246_p0 =  (sc_lv<12>) (sext_ln1116_97_cast_fu_54063_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_297_fu_58246_p1() {
    mul_ln1118_297_fu_58246_p1 = tmp_297_reg_98042.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_297_fu_58246_p2() {
    mul_ln1118_297_fu_58246_p2 = (!mul_ln1118_297_fu_58246_p0.read().is_01() || !mul_ln1118_297_fu_58246_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_297_fu_58246_p0.read()) * sc_bigint<5>(mul_ln1118_297_fu_58246_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_298_fu_58265_p0() {
    mul_ln1118_298_fu_58265_p0 =  (sc_lv<12>) (sext_ln1116_98_cast_fu_54085_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_298_fu_58265_p1() {
    mul_ln1118_298_fu_58265_p1 = tmp_298_reg_98047.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_298_fu_58265_p2() {
    mul_ln1118_298_fu_58265_p2 = (!mul_ln1118_298_fu_58265_p0.read().is_01() || !mul_ln1118_298_fu_58265_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_298_fu_58265_p0.read()) * sc_bigint<5>(mul_ln1118_298_fu_58265_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_299_fu_58284_p0() {
    mul_ln1118_299_fu_58284_p0 =  (sc_lv<12>) (sext_ln1116_99_cast_fu_54107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_299_fu_58284_p1() {
    mul_ln1118_299_fu_58284_p1 = tmp_299_reg_98052.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_299_fu_58284_p2() {
    mul_ln1118_299_fu_58284_p2 = (!mul_ln1118_299_fu_58284_p0.read().is_01() || !mul_ln1118_299_fu_58284_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_299_fu_58284_p0.read()) * sc_bigint<5>(mul_ln1118_299_fu_58284_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_29_fu_22249_p0() {
    mul_ln1118_29_fu_22249_p0 =  (sc_lv<12>) (sext_ln1116_29_cast_fu_22241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_29_fu_22249_p1() {
    mul_ln1118_29_fu_22249_p1 = tmp_29_fu_22231_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_29_fu_22249_p2() {
    mul_ln1118_29_fu_22249_p2 = (!mul_ln1118_29_fu_22249_p0.read().is_01() || !mul_ln1118_29_fu_22249_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_29_fu_22249_p0.read()) * sc_bigint<5>(mul_ln1118_29_fu_22249_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_300_fu_58303_p0() {
    mul_ln1118_300_fu_58303_p0 =  (sc_lv<12>) (sext_ln1116_100_cast_fu_54129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_300_fu_58303_p1() {
    mul_ln1118_300_fu_58303_p1 = tmp_300_reg_98057.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_300_fu_58303_p2() {
    mul_ln1118_300_fu_58303_p2 = (!mul_ln1118_300_fu_58303_p0.read().is_01() || !mul_ln1118_300_fu_58303_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_300_fu_58303_p0.read()) * sc_bigint<5>(mul_ln1118_300_fu_58303_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_301_fu_58322_p0() {
    mul_ln1118_301_fu_58322_p0 =  (sc_lv<12>) (sext_ln1116_101_cast_fu_54151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_301_fu_58322_p1() {
    mul_ln1118_301_fu_58322_p1 = tmp_301_reg_98062.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_301_fu_58322_p2() {
    mul_ln1118_301_fu_58322_p2 = (!mul_ln1118_301_fu_58322_p0.read().is_01() || !mul_ln1118_301_fu_58322_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_301_fu_58322_p0.read()) * sc_bigint<5>(mul_ln1118_301_fu_58322_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_302_fu_58341_p0() {
    mul_ln1118_302_fu_58341_p0 =  (sc_lv<12>) (sext_ln1116_102_cast_reg_96606.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_302_fu_58341_p1() {
    mul_ln1118_302_fu_58341_p1 = tmp_302_reg_98067.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_302_fu_58341_p2() {
    mul_ln1118_302_fu_58341_p2 = (!mul_ln1118_302_fu_58341_p0.read().is_01() || !mul_ln1118_302_fu_58341_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_302_fu_58341_p0.read()) * sc_bigint<5>(mul_ln1118_302_fu_58341_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_303_fu_27845_p0() {
    mul_ln1118_303_fu_27845_p0 =  (sc_lv<12>) (sext_ln1116_103_cast_fu_23993_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_303_fu_27845_p1() {
    mul_ln1118_303_fu_27845_p1 = tmp_303_fu_27831_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_303_fu_27845_p2() {
    mul_ln1118_303_fu_27845_p2 = (!mul_ln1118_303_fu_27845_p0.read().is_01() || !mul_ln1118_303_fu_27845_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_303_fu_27845_p0.read()) * sc_bigint<5>(mul_ln1118_303_fu_27845_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_304_fu_27875_p0() {
    mul_ln1118_304_fu_27875_p0 =  (sc_lv<12>) (sext_ln1116_104_cast_fu_24035_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_304_fu_27875_p1() {
    mul_ln1118_304_fu_27875_p1 = tmp_304_fu_27861_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_304_fu_27875_p2() {
    mul_ln1118_304_fu_27875_p2 = (!mul_ln1118_304_fu_27875_p0.read().is_01() || !mul_ln1118_304_fu_27875_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_304_fu_27875_p0.read()) * sc_bigint<5>(mul_ln1118_304_fu_27875_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_305_fu_27905_p0() {
    mul_ln1118_305_fu_27905_p0 =  (sc_lv<12>) (sext_ln1116_105_cast_fu_24077_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_305_fu_27905_p1() {
    mul_ln1118_305_fu_27905_p1 = tmp_305_fu_27891_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_305_fu_27905_p2() {
    mul_ln1118_305_fu_27905_p2 = (!mul_ln1118_305_fu_27905_p0.read().is_01() || !mul_ln1118_305_fu_27905_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_305_fu_27905_p0.read()) * sc_bigint<5>(mul_ln1118_305_fu_27905_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_306_fu_27935_p0() {
    mul_ln1118_306_fu_27935_p0 =  (sc_lv<12>) (sext_ln1116_106_cast_fu_24119_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_306_fu_27935_p1() {
    mul_ln1118_306_fu_27935_p1 = tmp_306_fu_27921_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_306_fu_27935_p2() {
    mul_ln1118_306_fu_27935_p2 = (!mul_ln1118_306_fu_27935_p0.read().is_01() || !mul_ln1118_306_fu_27935_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_306_fu_27935_p0.read()) * sc_bigint<5>(mul_ln1118_306_fu_27935_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_307_fu_27965_p0() {
    mul_ln1118_307_fu_27965_p0 =  (sc_lv<12>) (sext_ln1116_107_cast_fu_24161_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_307_fu_27965_p1() {
    mul_ln1118_307_fu_27965_p1 = tmp_307_fu_27951_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_307_fu_27965_p2() {
    mul_ln1118_307_fu_27965_p2 = (!mul_ln1118_307_fu_27965_p0.read().is_01() || !mul_ln1118_307_fu_27965_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_307_fu_27965_p0.read()) * sc_bigint<5>(mul_ln1118_307_fu_27965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_308_fu_27995_p0() {
    mul_ln1118_308_fu_27995_p0 =  (sc_lv<12>) (sext_ln1116_108_cast_fu_24203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_308_fu_27995_p1() {
    mul_ln1118_308_fu_27995_p1 = tmp_308_fu_27981_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_308_fu_27995_p2() {
    mul_ln1118_308_fu_27995_p2 = (!mul_ln1118_308_fu_27995_p0.read().is_01() || !mul_ln1118_308_fu_27995_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_308_fu_27995_p0.read()) * sc_bigint<5>(mul_ln1118_308_fu_27995_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_309_fu_58359_p0() {
    mul_ln1118_309_fu_58359_p0 =  (sc_lv<12>) (sext_ln1116_109_cast_fu_54191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_309_fu_58359_p1() {
    mul_ln1118_309_fu_58359_p1 = tmp_309_reg_98102.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_309_fu_58359_p2() {
    mul_ln1118_309_fu_58359_p2 = (!mul_ln1118_309_fu_58359_p0.read().is_01() || !mul_ln1118_309_fu_58359_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_309_fu_58359_p0.read()) * sc_bigint<5>(mul_ln1118_309_fu_58359_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_30_fu_22291_p0() {
    mul_ln1118_30_fu_22291_p0 =  (sc_lv<12>) (sext_ln1116_30_cast_fu_22283_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_30_fu_22291_p1() {
    mul_ln1118_30_fu_22291_p1 = tmp_30_fu_22273_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_30_fu_22291_p2() {
    mul_ln1118_30_fu_22291_p2 = (!mul_ln1118_30_fu_22291_p0.read().is_01() || !mul_ln1118_30_fu_22291_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_30_fu_22291_p0.read()) * sc_bigint<5>(mul_ln1118_30_fu_22291_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_310_fu_58378_p0() {
    mul_ln1118_310_fu_58378_p0 =  (sc_lv<12>) (sext_ln1116_110_cast_fu_54213_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_310_fu_58378_p1() {
    mul_ln1118_310_fu_58378_p1 = tmp_310_reg_98107.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_310_fu_58378_p2() {
    mul_ln1118_310_fu_58378_p2 = (!mul_ln1118_310_fu_58378_p0.read().is_01() || !mul_ln1118_310_fu_58378_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_310_fu_58378_p0.read()) * sc_bigint<5>(mul_ln1118_310_fu_58378_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_311_fu_58397_p0() {
    mul_ln1118_311_fu_58397_p0 =  (sc_lv<12>) (sext_ln1116_111_cast_fu_54235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_311_fu_58397_p1() {
    mul_ln1118_311_fu_58397_p1 = tmp_311_reg_98112.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_311_fu_58397_p2() {
    mul_ln1118_311_fu_58397_p2 = (!mul_ln1118_311_fu_58397_p0.read().is_01() || !mul_ln1118_311_fu_58397_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_311_fu_58397_p0.read()) * sc_bigint<5>(mul_ln1118_311_fu_58397_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_312_fu_58416_p0() {
    mul_ln1118_312_fu_58416_p0 =  (sc_lv<12>) (sext_ln1116_112_cast_fu_54257_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_312_fu_58416_p1() {
    mul_ln1118_312_fu_58416_p1 = tmp_312_reg_98117.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_312_fu_58416_p2() {
    mul_ln1118_312_fu_58416_p2 = (!mul_ln1118_312_fu_58416_p0.read().is_01() || !mul_ln1118_312_fu_58416_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_312_fu_58416_p0.read()) * sc_bigint<5>(mul_ln1118_312_fu_58416_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_313_fu_58435_p0() {
    mul_ln1118_313_fu_58435_p0 =  (sc_lv<12>) (sext_ln1116_113_cast_fu_54279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_313_fu_58435_p1() {
    mul_ln1118_313_fu_58435_p1 = tmp_313_reg_98122.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_313_fu_58435_p2() {
    mul_ln1118_313_fu_58435_p2 = (!mul_ln1118_313_fu_58435_p0.read().is_01() || !mul_ln1118_313_fu_58435_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_313_fu_58435_p0.read()) * sc_bigint<5>(mul_ln1118_313_fu_58435_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_314_fu_58454_p0() {
    mul_ln1118_314_fu_58454_p0 =  (sc_lv<12>) (sext_ln1116_114_cast_fu_54301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_314_fu_58454_p1() {
    mul_ln1118_314_fu_58454_p1 = tmp_314_reg_98127.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_314_fu_58454_p2() {
    mul_ln1118_314_fu_58454_p2 = (!mul_ln1118_314_fu_58454_p0.read().is_01() || !mul_ln1118_314_fu_58454_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_314_fu_58454_p0.read()) * sc_bigint<5>(mul_ln1118_314_fu_58454_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_315_fu_58473_p0() {
    mul_ln1118_315_fu_58473_p0 =  (sc_lv<12>) (sext_ln1116_115_cast_fu_54323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_315_fu_58473_p1() {
    mul_ln1118_315_fu_58473_p1 = tmp_315_reg_98132.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_315_fu_58473_p2() {
    mul_ln1118_315_fu_58473_p2 = (!mul_ln1118_315_fu_58473_p0.read().is_01() || !mul_ln1118_315_fu_58473_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_315_fu_58473_p0.read()) * sc_bigint<5>(mul_ln1118_315_fu_58473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_316_fu_58492_p0() {
    mul_ln1118_316_fu_58492_p0 =  (sc_lv<12>) (sext_ln1116_116_cast_fu_54345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_316_fu_58492_p1() {
    mul_ln1118_316_fu_58492_p1 = tmp_316_reg_98137.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_316_fu_58492_p2() {
    mul_ln1118_316_fu_58492_p2 = (!mul_ln1118_316_fu_58492_p0.read().is_01() || !mul_ln1118_316_fu_58492_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_316_fu_58492_p0.read()) * sc_bigint<5>(mul_ln1118_316_fu_58492_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_317_fu_58511_p0() {
    mul_ln1118_317_fu_58511_p0 =  (sc_lv<12>) (sext_ln1116_117_cast_fu_54367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_317_fu_58511_p1() {
    mul_ln1118_317_fu_58511_p1 = tmp_317_reg_98142.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_317_fu_58511_p2() {
    mul_ln1118_317_fu_58511_p2 = (!mul_ln1118_317_fu_58511_p0.read().is_01() || !mul_ln1118_317_fu_58511_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_317_fu_58511_p0.read()) * sc_bigint<5>(mul_ln1118_317_fu_58511_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_318_fu_58530_p0() {
    mul_ln1118_318_fu_58530_p0 =  (sc_lv<12>) (sext_ln1116_118_cast_fu_54389_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_318_fu_58530_p1() {
    mul_ln1118_318_fu_58530_p1 = tmp_318_reg_98147.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_318_fu_58530_p2() {
    mul_ln1118_318_fu_58530_p2 = (!mul_ln1118_318_fu_58530_p0.read().is_01() || !mul_ln1118_318_fu_58530_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_318_fu_58530_p0.read()) * sc_bigint<5>(mul_ln1118_318_fu_58530_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_319_fu_58549_p0() {
    mul_ln1118_319_fu_58549_p0 =  (sc_lv<12>) (sext_ln1116_119_cast_fu_54411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_319_fu_58549_p1() {
    mul_ln1118_319_fu_58549_p1 = tmp_319_reg_98152.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_319_fu_58549_p2() {
    mul_ln1118_319_fu_58549_p2 = (!mul_ln1118_319_fu_58549_p0.read().is_01() || !mul_ln1118_319_fu_58549_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_319_fu_58549_p0.read()) * sc_bigint<5>(mul_ln1118_319_fu_58549_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_31_fu_22333_p0() {
    mul_ln1118_31_fu_22333_p0 =  (sc_lv<12>) (sext_ln1116_31_cast_fu_22325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_31_fu_22333_p1() {
    mul_ln1118_31_fu_22333_p1 = tmp_31_fu_22315_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_31_fu_22333_p2() {
    mul_ln1118_31_fu_22333_p2 = (!mul_ln1118_31_fu_22333_p0.read().is_01() || !mul_ln1118_31_fu_22333_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_31_fu_22333_p0.read()) * sc_bigint<5>(mul_ln1118_31_fu_22333_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_320_fu_58568_p0() {
    mul_ln1118_320_fu_58568_p0 =  (sc_lv<12>) (sext_ln1116_120_cast_fu_54433_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_320_fu_58568_p1() {
    mul_ln1118_320_fu_58568_p1 = tmp_320_reg_98157.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_320_fu_58568_p2() {
    mul_ln1118_320_fu_58568_p2 = (!mul_ln1118_320_fu_58568_p0.read().is_01() || !mul_ln1118_320_fu_58568_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_320_fu_58568_p0.read()) * sc_bigint<5>(mul_ln1118_320_fu_58568_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_321_fu_58587_p0() {
    mul_ln1118_321_fu_58587_p0 =  (sc_lv<12>) (sext_ln1116_121_cast_fu_54455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_321_fu_58587_p1() {
    mul_ln1118_321_fu_58587_p1 = tmp_321_reg_98162.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_321_fu_58587_p2() {
    mul_ln1118_321_fu_58587_p2 = (!mul_ln1118_321_fu_58587_p0.read().is_01() || !mul_ln1118_321_fu_58587_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_321_fu_58587_p0.read()) * sc_bigint<5>(mul_ln1118_321_fu_58587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_322_fu_58606_p0() {
    mul_ln1118_322_fu_58606_p0 =  (sc_lv<12>) (sext_ln1116_122_cast_fu_54477_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_322_fu_58606_p1() {
    mul_ln1118_322_fu_58606_p1 = tmp_322_reg_98167.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_322_fu_58606_p2() {
    mul_ln1118_322_fu_58606_p2 = (!mul_ln1118_322_fu_58606_p0.read().is_01() || !mul_ln1118_322_fu_58606_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_322_fu_58606_p0.read()) * sc_bigint<5>(mul_ln1118_322_fu_58606_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_323_fu_58625_p0() {
    mul_ln1118_323_fu_58625_p0 =  (sc_lv<12>) (sext_ln1116_123_cast_fu_54499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_323_fu_58625_p1() {
    mul_ln1118_323_fu_58625_p1 = tmp_323_reg_98172.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_323_fu_58625_p2() {
    mul_ln1118_323_fu_58625_p2 = (!mul_ln1118_323_fu_58625_p0.read().is_01() || !mul_ln1118_323_fu_58625_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_323_fu_58625_p0.read()) * sc_bigint<5>(mul_ln1118_323_fu_58625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_324_fu_58644_p0() {
    mul_ln1118_324_fu_58644_p0 =  (sc_lv<12>) (sext_ln1116_124_cast_fu_54521_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_324_fu_58644_p1() {
    mul_ln1118_324_fu_58644_p1 = tmp_324_reg_98177.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_324_fu_58644_p2() {
    mul_ln1118_324_fu_58644_p2 = (!mul_ln1118_324_fu_58644_p0.read().is_01() || !mul_ln1118_324_fu_58644_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_324_fu_58644_p0.read()) * sc_bigint<5>(mul_ln1118_324_fu_58644_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_325_fu_58663_p0() {
    mul_ln1118_325_fu_58663_p0 =  (sc_lv<12>) (sext_ln1116_125_cast_fu_54543_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_325_fu_58663_p1() {
    mul_ln1118_325_fu_58663_p1 = tmp_325_reg_98182.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_325_fu_58663_p2() {
    mul_ln1118_325_fu_58663_p2 = (!mul_ln1118_325_fu_58663_p0.read().is_01() || !mul_ln1118_325_fu_58663_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_325_fu_58663_p0.read()) * sc_bigint<5>(mul_ln1118_325_fu_58663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_326_fu_58682_p0() {
    mul_ln1118_326_fu_58682_p0 =  (sc_lv<12>) (sext_ln1116_126_cast_fu_54565_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_326_fu_58682_p1() {
    mul_ln1118_326_fu_58682_p1 = tmp_326_reg_98187.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_326_fu_58682_p2() {
    mul_ln1118_326_fu_58682_p2 = (!mul_ln1118_326_fu_58682_p0.read().is_01() || !mul_ln1118_326_fu_58682_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_326_fu_58682_p0.read()) * sc_bigint<5>(mul_ln1118_326_fu_58682_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_327_fu_58701_p0() {
    mul_ln1118_327_fu_58701_p0 =  (sc_lv<12>) (sext_ln1116_127_cast_fu_54587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_327_fu_58701_p1() {
    mul_ln1118_327_fu_58701_p1 = tmp_327_reg_98192.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_327_fu_58701_p2() {
    mul_ln1118_327_fu_58701_p2 = (!mul_ln1118_327_fu_58701_p0.read().is_01() || !mul_ln1118_327_fu_58701_p1.read().is_01())? sc_lv<16>(): sc_bigint<12>(mul_ln1118_327_fu_58701_p0.read()) * sc_bigint<5>(mul_ln1118_327_fu_58701_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_328_fu_58720_p0() {
    mul_ln1118_328_fu_58720_p0 =  (sc_lv<12>) (sext_ln1116_128_cast_fu_54609_p1.read());
}

}

