#include "dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1531_fu_66299_p2() {
    mul_ln1118_1531_fu_66299_p2 = (!mul_ln1118_1531_fu_66299_p0.read().is_01() || !mul_ln1118_1531_fu_66299_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1531_fu_66299_p0.read()) * sc_bigint<5>(mul_ln1118_1531_fu_66299_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1532_fu_66331_p0() {
    mul_ln1118_1532_fu_66331_p0 =  (sc_lv<3>) (sext_ln1116_132_fu_26441_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1532_fu_66331_p1() {
    mul_ln1118_1532_fu_66331_p1 = tmp_1532_fu_66317_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1532_fu_66331_p2() {
    mul_ln1118_1532_fu_66331_p2 = (!mul_ln1118_1532_fu_66331_p0.read().is_01() || !mul_ln1118_1532_fu_66331_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1532_fu_66331_p0.read()) * sc_bigint<5>(mul_ln1118_1532_fu_66331_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1533_fu_66363_p0() {
    mul_ln1118_1533_fu_66363_p0 =  (sc_lv<3>) (sext_ln1116_133_fu_26485_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1533_fu_66363_p1() {
    mul_ln1118_1533_fu_66363_p1 = tmp_1533_fu_66349_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1533_fu_66363_p2() {
    mul_ln1118_1533_fu_66363_p2 = (!mul_ln1118_1533_fu_66363_p0.read().is_01() || !mul_ln1118_1533_fu_66363_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1533_fu_66363_p0.read()) * sc_bigint<5>(mul_ln1118_1533_fu_66363_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1534_fu_97235_p0() {
    mul_ln1118_1534_fu_97235_p0 =  (sc_lv<3>) (sext_ln1116_134_reg_106449.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1534_fu_97235_p1() {
    mul_ln1118_1534_fu_97235_p1 = tmp_1534_reg_111236.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1534_fu_97235_p2() {
    mul_ln1118_1534_fu_97235_p2 = (!mul_ln1118_1534_fu_97235_p0.read().is_01() || !mul_ln1118_1534_fu_97235_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1534_fu_97235_p0.read()) * sc_bigint<5>(mul_ln1118_1534_fu_97235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1535_fu_66405_p0() {
    mul_ln1118_1535_fu_66405_p0 =  (sc_lv<3>) (sext_ln1116_135_fu_26551_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1535_fu_66405_p1() {
    mul_ln1118_1535_fu_66405_p1 = tmp_1535_fu_66391_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1535_fu_66405_p2() {
    mul_ln1118_1535_fu_66405_p2 = (!mul_ln1118_1535_fu_66405_p0.read().is_01() || !mul_ln1118_1535_fu_66405_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1535_fu_66405_p0.read()) * sc_bigint<5>(mul_ln1118_1535_fu_66405_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1536_fu_66437_p0() {
    mul_ln1118_1536_fu_66437_p0 =  (sc_lv<3>) (sext_ln1116_136_fu_26595_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1536_fu_66437_p1() {
    mul_ln1118_1536_fu_66437_p1 = tmp_1536_fu_66423_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1536_fu_66437_p2() {
    mul_ln1118_1536_fu_66437_p2 = (!mul_ln1118_1536_fu_66437_p0.read().is_01() || !mul_ln1118_1536_fu_66437_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1536_fu_66437_p0.read()) * sc_bigint<5>(mul_ln1118_1536_fu_66437_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1537_fu_97255_p0() {
    mul_ln1118_1537_fu_97255_p0 =  (sc_lv<3>) (sext_ln1116_137_reg_106467.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1537_fu_97255_p1() {
    mul_ln1118_1537_fu_97255_p1 = tmp_1537_reg_111241.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1537_fu_97255_p2() {
    mul_ln1118_1537_fu_97255_p2 = (!mul_ln1118_1537_fu_97255_p0.read().is_01() || !mul_ln1118_1537_fu_97255_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1537_fu_97255_p0.read()) * sc_bigint<5>(mul_ln1118_1537_fu_97255_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1538_fu_66479_p0() {
    mul_ln1118_1538_fu_66479_p0 =  (sc_lv<3>) (sext_ln1116_138_fu_26661_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1538_fu_66479_p1() {
    mul_ln1118_1538_fu_66479_p1 = tmp_1538_fu_66465_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1538_fu_66479_p2() {
    mul_ln1118_1538_fu_66479_p2 = (!mul_ln1118_1538_fu_66479_p0.read().is_01() || !mul_ln1118_1538_fu_66479_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1538_fu_66479_p0.read()) * sc_bigint<5>(mul_ln1118_1538_fu_66479_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1539_fu_66511_p0() {
    mul_ln1118_1539_fu_66511_p0 =  (sc_lv<3>) (sext_ln1116_139_fu_26705_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1539_fu_66511_p1() {
    mul_ln1118_1539_fu_66511_p1 = tmp_1539_fu_66497_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1539_fu_66511_p2() {
    mul_ln1118_1539_fu_66511_p2 = (!mul_ln1118_1539_fu_66511_p0.read().is_01() || !mul_ln1118_1539_fu_66511_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1539_fu_66511_p0.read()) * sc_bigint<5>(mul_ln1118_1539_fu_66511_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_153_fu_27155_p0() {
    mul_ln1118_153_fu_27155_p0 =  (sc_lv<3>) (sext_ln1116_153_fu_27147_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_153_fu_27155_p1() {
    mul_ln1118_153_fu_27155_p1 = tmp_153_fu_27137_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_153_fu_27155_p2() {
    mul_ln1118_153_fu_27155_p2 = (!mul_ln1118_153_fu_27155_p0.read().is_01() || !mul_ln1118_153_fu_27155_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_153_fu_27155_p0.read()) * sc_bigint<5>(mul_ln1118_153_fu_27155_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1540_fu_97275_p0() {
    mul_ln1118_1540_fu_97275_p0 =  (sc_lv<3>) (sext_ln1116_140_fu_80807_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1540_fu_97275_p1() {
    mul_ln1118_1540_fu_97275_p1 = tmp_1540_reg_111246.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1540_fu_97275_p2() {
    mul_ln1118_1540_fu_97275_p2 = (!mul_ln1118_1540_fu_97275_p0.read().is_01() || !mul_ln1118_1540_fu_97275_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1540_fu_97275_p0.read()) * sc_bigint<5>(mul_ln1118_1540_fu_97275_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1541_fu_97296_p0() {
    mul_ln1118_1541_fu_97296_p0 =  (sc_lv<3>) (sext_ln1116_141_fu_80831_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1541_fu_97296_p1() {
    mul_ln1118_1541_fu_97296_p1 = tmp_1541_reg_111251.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1541_fu_97296_p2() {
    mul_ln1118_1541_fu_97296_p2 = (!mul_ln1118_1541_fu_97296_p0.read().is_01() || !mul_ln1118_1541_fu_97296_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1541_fu_97296_p0.read()) * sc_bigint<5>(mul_ln1118_1541_fu_97296_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1542_fu_97317_p0() {
    mul_ln1118_1542_fu_97317_p0 =  (sc_lv<3>) (sext_ln1116_142_fu_80855_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1542_fu_97317_p1() {
    mul_ln1118_1542_fu_97317_p1 = tmp_1542_reg_111256.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1542_fu_97317_p2() {
    mul_ln1118_1542_fu_97317_p2 = (!mul_ln1118_1542_fu_97317_p0.read().is_01() || !mul_ln1118_1542_fu_97317_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1542_fu_97317_p0.read()) * sc_bigint<5>(mul_ln1118_1542_fu_97317_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1543_fu_97338_p0() {
    mul_ln1118_1543_fu_97338_p0 =  (sc_lv<3>) (sext_ln1116_143_fu_80879_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1543_fu_97338_p1() {
    mul_ln1118_1543_fu_97338_p1 = tmp_1543_reg_111261.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1543_fu_97338_p2() {
    mul_ln1118_1543_fu_97338_p2 = (!mul_ln1118_1543_fu_97338_p0.read().is_01() || !mul_ln1118_1543_fu_97338_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1543_fu_97338_p0.read()) * sc_bigint<5>(mul_ln1118_1543_fu_97338_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1544_fu_66583_p0() {
    mul_ln1118_1544_fu_66583_p0 =  (sc_lv<3>) (sext_ln1116_144_fu_26821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1544_fu_66583_p1() {
    mul_ln1118_1544_fu_66583_p1 = tmp_1544_fu_66569_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1544_fu_66583_p2() {
    mul_ln1118_1544_fu_66583_p2 = (!mul_ln1118_1544_fu_66583_p0.read().is_01() || !mul_ln1118_1544_fu_66583_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1544_fu_66583_p0.read()) * sc_bigint<5>(mul_ln1118_1544_fu_66583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1545_fu_66615_p0() {
    mul_ln1118_1545_fu_66615_p0 =  (sc_lv<3>) (sext_ln1116_145_fu_26865_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1545_fu_66615_p1() {
    mul_ln1118_1545_fu_66615_p1 = tmp_1545_fu_66601_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1545_fu_66615_p2() {
    mul_ln1118_1545_fu_66615_p2 = (!mul_ln1118_1545_fu_66615_p0.read().is_01() || !mul_ln1118_1545_fu_66615_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1545_fu_66615_p0.read()) * sc_bigint<5>(mul_ln1118_1545_fu_66615_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1546_fu_97359_p0() {
    mul_ln1118_1546_fu_97359_p0 =  (sc_lv<3>) (sext_ln1116_146_reg_106525.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1546_fu_97359_p1() {
    mul_ln1118_1546_fu_97359_p1 = tmp_1546_reg_111266.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1546_fu_97359_p2() {
    mul_ln1118_1546_fu_97359_p2 = (!mul_ln1118_1546_fu_97359_p0.read().is_01() || !mul_ln1118_1546_fu_97359_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1546_fu_97359_p0.read()) * sc_bigint<5>(mul_ln1118_1546_fu_97359_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1547_fu_66657_p0() {
    mul_ln1118_1547_fu_66657_p0 =  (sc_lv<3>) (sext_ln1116_147_fu_26931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1547_fu_66657_p1() {
    mul_ln1118_1547_fu_66657_p1 = tmp_1547_fu_66643_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1547_fu_66657_p2() {
    mul_ln1118_1547_fu_66657_p2 = (!mul_ln1118_1547_fu_66657_p0.read().is_01() || !mul_ln1118_1547_fu_66657_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1547_fu_66657_p0.read()) * sc_bigint<5>(mul_ln1118_1547_fu_66657_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1548_fu_66689_p0() {
    mul_ln1118_1548_fu_66689_p0 =  (sc_lv<3>) (sext_ln1116_148_fu_26975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1548_fu_66689_p1() {
    mul_ln1118_1548_fu_66689_p1 = tmp_1548_fu_66675_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1548_fu_66689_p2() {
    mul_ln1118_1548_fu_66689_p2 = (!mul_ln1118_1548_fu_66689_p0.read().is_01() || !mul_ln1118_1548_fu_66689_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1548_fu_66689_p0.read()) * sc_bigint<5>(mul_ln1118_1548_fu_66689_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1549_fu_97379_p0() {
    mul_ln1118_1549_fu_97379_p0 =  (sc_lv<3>) (sext_ln1116_149_reg_106543.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1549_fu_97379_p1() {
    mul_ln1118_1549_fu_97379_p1 = tmp_1549_reg_111271.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1549_fu_97379_p2() {
    mul_ln1118_1549_fu_97379_p2 = (!mul_ln1118_1549_fu_97379_p0.read().is_01() || !mul_ln1118_1549_fu_97379_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1549_fu_97379_p0.read()) * sc_bigint<5>(mul_ln1118_1549_fu_97379_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_154_fu_27199_p0() {
    mul_ln1118_154_fu_27199_p0 =  (sc_lv<3>) (sext_ln1116_154_fu_27191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_154_fu_27199_p1() {
    mul_ln1118_154_fu_27199_p1 = tmp_154_fu_27181_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_154_fu_27199_p2() {
    mul_ln1118_154_fu_27199_p2 = (!mul_ln1118_154_fu_27199_p0.read().is_01() || !mul_ln1118_154_fu_27199_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_154_fu_27199_p0.read()) * sc_bigint<5>(mul_ln1118_154_fu_27199_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1550_fu_66731_p0() {
    mul_ln1118_1550_fu_66731_p0 =  (sc_lv<3>) (sext_ln1116_150_fu_27041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1550_fu_66731_p1() {
    mul_ln1118_1550_fu_66731_p1 = tmp_1550_fu_66717_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1550_fu_66731_p2() {
    mul_ln1118_1550_fu_66731_p2 = (!mul_ln1118_1550_fu_66731_p0.read().is_01() || !mul_ln1118_1550_fu_66731_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1550_fu_66731_p0.read()) * sc_bigint<5>(mul_ln1118_1550_fu_66731_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1551_fu_66763_p0() {
    mul_ln1118_1551_fu_66763_p0 =  (sc_lv<3>) (sext_ln1116_151_fu_27085_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1551_fu_66763_p1() {
    mul_ln1118_1551_fu_66763_p1 = tmp_1551_fu_66749_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1551_fu_66763_p2() {
    mul_ln1118_1551_fu_66763_p2 = (!mul_ln1118_1551_fu_66763_p0.read().is_01() || !mul_ln1118_1551_fu_66763_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1551_fu_66763_p0.read()) * sc_bigint<5>(mul_ln1118_1551_fu_66763_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1552_fu_97399_p0() {
    mul_ln1118_1552_fu_97399_p0 =  (sc_lv<3>) (sext_ln1116_152_fu_80943_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1552_fu_97399_p1() {
    mul_ln1118_1552_fu_97399_p1 = tmp_1552_reg_111276.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1552_fu_97399_p2() {
    mul_ln1118_1552_fu_97399_p2 = (!mul_ln1118_1552_fu_97399_p0.read().is_01() || !mul_ln1118_1552_fu_97399_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1552_fu_97399_p0.read()) * sc_bigint<5>(mul_ln1118_1552_fu_97399_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1553_fu_66805_p0() {
    mul_ln1118_1553_fu_66805_p0 =  (sc_lv<3>) (sext_ln1116_153_fu_27147_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1553_fu_66805_p1() {
    mul_ln1118_1553_fu_66805_p1 = tmp_1553_fu_66791_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1553_fu_66805_p2() {
    mul_ln1118_1553_fu_66805_p2 = (!mul_ln1118_1553_fu_66805_p0.read().is_01() || !mul_ln1118_1553_fu_66805_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1553_fu_66805_p0.read()) * sc_bigint<5>(mul_ln1118_1553_fu_66805_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1554_fu_66837_p0() {
    mul_ln1118_1554_fu_66837_p0 =  (sc_lv<3>) (sext_ln1116_154_fu_27191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1554_fu_66837_p1() {
    mul_ln1118_1554_fu_66837_p1 = tmp_1554_fu_66823_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1554_fu_66837_p2() {
    mul_ln1118_1554_fu_66837_p2 = (!mul_ln1118_1554_fu_66837_p0.read().is_01() || !mul_ln1118_1554_fu_66837_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1554_fu_66837_p0.read()) * sc_bigint<5>(mul_ln1118_1554_fu_66837_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1555_fu_66869_p0() {
    mul_ln1118_1555_fu_66869_p0 =  (sc_lv<3>) (sext_ln1116_155_fu_27235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1555_fu_66869_p1() {
    mul_ln1118_1555_fu_66869_p1 = tmp_1555_fu_66855_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1555_fu_66869_p2() {
    mul_ln1118_1555_fu_66869_p2 = (!mul_ln1118_1555_fu_66869_p0.read().is_01() || !mul_ln1118_1555_fu_66869_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1555_fu_66869_p0.read()) * sc_bigint<5>(mul_ln1118_1555_fu_66869_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1556_fu_66901_p0() {
    mul_ln1118_1556_fu_66901_p0 =  (sc_lv<3>) (sext_ln1116_156_fu_27279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1556_fu_66901_p1() {
    mul_ln1118_1556_fu_66901_p1 = tmp_1556_fu_66887_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1556_fu_66901_p2() {
    mul_ln1118_1556_fu_66901_p2 = (!mul_ln1118_1556_fu_66901_p0.read().is_01() || !mul_ln1118_1556_fu_66901_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1556_fu_66901_p0.read()) * sc_bigint<5>(mul_ln1118_1556_fu_66901_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1557_fu_66933_p0() {
    mul_ln1118_1557_fu_66933_p0 =  (sc_lv<3>) (sext_ln1116_157_fu_27323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1557_fu_66933_p1() {
    mul_ln1118_1557_fu_66933_p1 = tmp_1557_fu_66919_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1557_fu_66933_p2() {
    mul_ln1118_1557_fu_66933_p2 = (!mul_ln1118_1557_fu_66933_p0.read().is_01() || !mul_ln1118_1557_fu_66933_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1557_fu_66933_p0.read()) * sc_bigint<5>(mul_ln1118_1557_fu_66933_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1558_fu_66965_p0() {
    mul_ln1118_1558_fu_66965_p0 =  (sc_lv<3>) (sext_ln1116_158_fu_27367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1558_fu_66965_p1() {
    mul_ln1118_1558_fu_66965_p1 = tmp_1558_fu_66951_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1558_fu_66965_p2() {
    mul_ln1118_1558_fu_66965_p2 = (!mul_ln1118_1558_fu_66965_p0.read().is_01() || !mul_ln1118_1558_fu_66965_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1558_fu_66965_p0.read()) * sc_bigint<5>(mul_ln1118_1558_fu_66965_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1559_fu_66997_p0() {
    mul_ln1118_1559_fu_66997_p0 =  (sc_lv<3>) (sext_ln1116_159_fu_27411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1559_fu_66997_p1() {
    mul_ln1118_1559_fu_66997_p1 = tmp_1559_fu_66983_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1559_fu_66997_p2() {
    mul_ln1118_1559_fu_66997_p2 = (!mul_ln1118_1559_fu_66997_p0.read().is_01() || !mul_ln1118_1559_fu_66997_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1559_fu_66997_p0.read()) * sc_bigint<5>(mul_ln1118_1559_fu_66997_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_155_fu_27243_p0() {
    mul_ln1118_155_fu_27243_p0 =  (sc_lv<3>) (sext_ln1116_155_fu_27235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_155_fu_27243_p1() {
    mul_ln1118_155_fu_27243_p1 = tmp_155_fu_27225_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_155_fu_27243_p2() {
    mul_ln1118_155_fu_27243_p2 = (!mul_ln1118_155_fu_27243_p0.read().is_01() || !mul_ln1118_155_fu_27243_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_155_fu_27243_p0.read()) * sc_bigint<5>(mul_ln1118_155_fu_27243_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1560_fu_67017_p0() {
    mul_ln1118_1560_fu_67017_p0 =  (sc_lv<3>) (sext_ln1116_160_fu_27443_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1560_fu_67017_p1() {
    mul_ln1118_1560_fu_67017_p1 = tmp_1560_fu_67003_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1560_fu_67017_p2() {
    mul_ln1118_1560_fu_67017_p2 = (!mul_ln1118_1560_fu_67017_p0.read().is_01() || !mul_ln1118_1560_fu_67017_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1560_fu_67017_p0.read()) * sc_bigint<5>(mul_ln1118_1560_fu_67017_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1561_fu_67049_p0() {
    mul_ln1118_1561_fu_67049_p0 =  (sc_lv<3>) (sext_ln1116_161_fu_27487_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1561_fu_67049_p1() {
    mul_ln1118_1561_fu_67049_p1 = tmp_1561_fu_67035_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1561_fu_67049_p2() {
    mul_ln1118_1561_fu_67049_p2 = (!mul_ln1118_1561_fu_67049_p0.read().is_01() || !mul_ln1118_1561_fu_67049_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1561_fu_67049_p0.read()) * sc_bigint<5>(mul_ln1118_1561_fu_67049_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1562_fu_67081_p0() {
    mul_ln1118_1562_fu_67081_p0 =  (sc_lv<3>) (sext_ln1116_162_fu_27531_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1562_fu_67081_p1() {
    mul_ln1118_1562_fu_67081_p1 = tmp_1562_fu_67067_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1562_fu_67081_p2() {
    mul_ln1118_1562_fu_67081_p2 = (!mul_ln1118_1562_fu_67081_p0.read().is_01() || !mul_ln1118_1562_fu_67081_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1562_fu_67081_p0.read()) * sc_bigint<5>(mul_ln1118_1562_fu_67081_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1563_fu_67101_p0() {
    mul_ln1118_1563_fu_67101_p0 =  (sc_lv<3>) (sext_ln1116_163_fu_27563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1563_fu_67101_p1() {
    mul_ln1118_1563_fu_67101_p1 = tmp_1563_fu_67087_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1563_fu_67101_p2() {
    mul_ln1118_1563_fu_67101_p2 = (!mul_ln1118_1563_fu_67101_p0.read().is_01() || !mul_ln1118_1563_fu_67101_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1563_fu_67101_p0.read()) * sc_bigint<5>(mul_ln1118_1563_fu_67101_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1564_fu_67133_p0() {
    mul_ln1118_1564_fu_67133_p0 =  (sc_lv<3>) (sext_ln1116_164_fu_27607_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1564_fu_67133_p1() {
    mul_ln1118_1564_fu_67133_p1 = tmp_1564_fu_67119_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1564_fu_67133_p2() {
    mul_ln1118_1564_fu_67133_p2 = (!mul_ln1118_1564_fu_67133_p0.read().is_01() || !mul_ln1118_1564_fu_67133_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1564_fu_67133_p0.read()) * sc_bigint<5>(mul_ln1118_1564_fu_67133_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1565_fu_97442_p0() {
    mul_ln1118_1565_fu_97442_p0 =  (sc_lv<3>) (sext_ln1116_165_reg_106581.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1565_fu_97442_p1() {
    mul_ln1118_1565_fu_97442_p1 = tmp_1565_reg_111291.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1565_fu_97442_p2() {
    mul_ln1118_1565_fu_97442_p2 = (!mul_ln1118_1565_fu_97442_p0.read().is_01() || !mul_ln1118_1565_fu_97442_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1565_fu_97442_p0.read()) * sc_bigint<5>(mul_ln1118_1565_fu_97442_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1566_fu_67175_p0() {
    mul_ln1118_1566_fu_67175_p0 =  (sc_lv<3>) (sext_ln1116_166_fu_27673_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1566_fu_67175_p1() {
    mul_ln1118_1566_fu_67175_p1 = tmp_1566_fu_67161_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1566_fu_67175_p2() {
    mul_ln1118_1566_fu_67175_p2 = (!mul_ln1118_1566_fu_67175_p0.read().is_01() || !mul_ln1118_1566_fu_67175_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1566_fu_67175_p0.read()) * sc_bigint<5>(mul_ln1118_1566_fu_67175_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1567_fu_67207_p0() {
    mul_ln1118_1567_fu_67207_p0 =  (sc_lv<3>) (sext_ln1116_167_fu_27717_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1567_fu_67207_p1() {
    mul_ln1118_1567_fu_67207_p1 = tmp_1567_fu_67193_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1567_fu_67207_p2() {
    mul_ln1118_1567_fu_67207_p2 = (!mul_ln1118_1567_fu_67207_p0.read().is_01() || !mul_ln1118_1567_fu_67207_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1567_fu_67207_p0.read()) * sc_bigint<5>(mul_ln1118_1567_fu_67207_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1568_fu_97462_p0() {
    mul_ln1118_1568_fu_97462_p0 =  (sc_lv<3>) (sext_ln1116_168_reg_106599.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1568_fu_97462_p1() {
    mul_ln1118_1568_fu_97462_p1 = tmp_1568_reg_111296.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1568_fu_97462_p2() {
    mul_ln1118_1568_fu_97462_p2 = (!mul_ln1118_1568_fu_97462_p0.read().is_01() || !mul_ln1118_1568_fu_97462_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1568_fu_97462_p0.read()) * sc_bigint<5>(mul_ln1118_1568_fu_97462_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1569_fu_67249_p0() {
    mul_ln1118_1569_fu_67249_p0 =  (sc_lv<3>) (sext_ln1116_169_fu_27783_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1569_fu_67249_p1() {
    mul_ln1118_1569_fu_67249_p1 = tmp_1569_fu_67235_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1569_fu_67249_p2() {
    mul_ln1118_1569_fu_67249_p2 = (!mul_ln1118_1569_fu_67249_p0.read().is_01() || !mul_ln1118_1569_fu_67249_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1569_fu_67249_p0.read()) * sc_bigint<5>(mul_ln1118_1569_fu_67249_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_156_fu_27287_p0() {
    mul_ln1118_156_fu_27287_p0 =  (sc_lv<3>) (sext_ln1116_156_fu_27279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_156_fu_27287_p1() {
    mul_ln1118_156_fu_27287_p1 = tmp_156_fu_27269_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_156_fu_27287_p2() {
    mul_ln1118_156_fu_27287_p2 = (!mul_ln1118_156_fu_27287_p0.read().is_01() || !mul_ln1118_156_fu_27287_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_156_fu_27287_p0.read()) * sc_bigint<5>(mul_ln1118_156_fu_27287_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1570_fu_67281_p0() {
    mul_ln1118_1570_fu_67281_p0 =  (sc_lv<3>) (sext_ln1116_170_fu_27827_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1570_fu_67281_p1() {
    mul_ln1118_1570_fu_67281_p1 = tmp_1570_fu_67267_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1570_fu_67281_p2() {
    mul_ln1118_1570_fu_67281_p2 = (!mul_ln1118_1570_fu_67281_p0.read().is_01() || !mul_ln1118_1570_fu_67281_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1570_fu_67281_p0.read()) * sc_bigint<5>(mul_ln1118_1570_fu_67281_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1571_fu_97482_p0() {
    mul_ln1118_1571_fu_97482_p0 =  (sc_lv<3>) (sext_ln1116_171_reg_106617.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1571_fu_97482_p1() {
    mul_ln1118_1571_fu_97482_p1 = tmp_1571_reg_111301.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1571_fu_97482_p2() {
    mul_ln1118_1571_fu_97482_p2 = (!mul_ln1118_1571_fu_97482_p0.read().is_01() || !mul_ln1118_1571_fu_97482_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1571_fu_97482_p0.read()) * sc_bigint<5>(mul_ln1118_1571_fu_97482_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1572_fu_67323_p0() {
    mul_ln1118_1572_fu_67323_p0 =  (sc_lv<3>) (sext_ln1116_172_fu_27893_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1572_fu_67323_p1() {
    mul_ln1118_1572_fu_67323_p1 = tmp_1572_fu_67309_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1572_fu_67323_p2() {
    mul_ln1118_1572_fu_67323_p2 = (!mul_ln1118_1572_fu_67323_p0.read().is_01() || !mul_ln1118_1572_fu_67323_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1572_fu_67323_p0.read()) * sc_bigint<5>(mul_ln1118_1572_fu_67323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1573_fu_67355_p0() {
    mul_ln1118_1573_fu_67355_p0 =  (sc_lv<3>) (sext_ln1116_173_fu_27937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1573_fu_67355_p1() {
    mul_ln1118_1573_fu_67355_p1 = tmp_1573_fu_67341_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1573_fu_67355_p2() {
    mul_ln1118_1573_fu_67355_p2 = (!mul_ln1118_1573_fu_67355_p0.read().is_01() || !mul_ln1118_1573_fu_67355_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1573_fu_67355_p0.read()) * sc_bigint<5>(mul_ln1118_1573_fu_67355_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1574_fu_97502_p0() {
    mul_ln1118_1574_fu_97502_p0 =  (sc_lv<3>) (sext_ln1116_174_reg_106635.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1574_fu_97502_p1() {
    mul_ln1118_1574_fu_97502_p1 = tmp_1574_reg_111306.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1574_fu_97502_p2() {
    mul_ln1118_1574_fu_97502_p2 = (!mul_ln1118_1574_fu_97502_p0.read().is_01() || !mul_ln1118_1574_fu_97502_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1574_fu_97502_p0.read()) * sc_bigint<5>(mul_ln1118_1574_fu_97502_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1575_fu_67397_p0() {
    mul_ln1118_1575_fu_67397_p0 =  (sc_lv<3>) (sext_ln1116_175_fu_28003_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1575_fu_67397_p1() {
    mul_ln1118_1575_fu_67397_p1 = tmp_1575_fu_67383_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1575_fu_67397_p2() {
    mul_ln1118_1575_fu_67397_p2 = (!mul_ln1118_1575_fu_67397_p0.read().is_01() || !mul_ln1118_1575_fu_67397_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1575_fu_67397_p0.read()) * sc_bigint<5>(mul_ln1118_1575_fu_67397_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1576_fu_67429_p0() {
    mul_ln1118_1576_fu_67429_p0 =  (sc_lv<3>) (sext_ln1116_176_fu_28047_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1576_fu_67429_p1() {
    mul_ln1118_1576_fu_67429_p1 = tmp_1576_fu_67415_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1576_fu_67429_p2() {
    mul_ln1118_1576_fu_67429_p2 = (!mul_ln1118_1576_fu_67429_p0.read().is_01() || !mul_ln1118_1576_fu_67429_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1576_fu_67429_p0.read()) * sc_bigint<5>(mul_ln1118_1576_fu_67429_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1577_fu_97522_p0() {
    mul_ln1118_1577_fu_97522_p0 =  (sc_lv<3>) (sext_ln1116_177_reg_106653.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1577_fu_97522_p1() {
    mul_ln1118_1577_fu_97522_p1 = tmp_1577_reg_111311.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1577_fu_97522_p2() {
    mul_ln1118_1577_fu_97522_p2 = (!mul_ln1118_1577_fu_97522_p0.read().is_01() || !mul_ln1118_1577_fu_97522_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1577_fu_97522_p0.read()) * sc_bigint<5>(mul_ln1118_1577_fu_97522_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1578_fu_67471_p0() {
    mul_ln1118_1578_fu_67471_p0 =  (sc_lv<3>) (sext_ln1116_178_fu_28113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1578_fu_67471_p1() {
    mul_ln1118_1578_fu_67471_p1 = tmp_1578_fu_67457_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1578_fu_67471_p2() {
    mul_ln1118_1578_fu_67471_p2 = (!mul_ln1118_1578_fu_67471_p0.read().is_01() || !mul_ln1118_1578_fu_67471_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1578_fu_67471_p0.read()) * sc_bigint<5>(mul_ln1118_1578_fu_67471_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1579_fu_67503_p0() {
    mul_ln1118_1579_fu_67503_p0 =  (sc_lv<3>) (sext_ln1116_179_fu_28157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1579_fu_67503_p1() {
    mul_ln1118_1579_fu_67503_p1 = tmp_1579_fu_67489_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1579_fu_67503_p2() {
    mul_ln1118_1579_fu_67503_p2 = (!mul_ln1118_1579_fu_67503_p0.read().is_01() || !mul_ln1118_1579_fu_67503_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1579_fu_67503_p0.read()) * sc_bigint<5>(mul_ln1118_1579_fu_67503_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_157_fu_27331_p0() {
    mul_ln1118_157_fu_27331_p0 =  (sc_lv<3>) (sext_ln1116_157_fu_27323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_157_fu_27331_p1() {
    mul_ln1118_157_fu_27331_p1 = tmp_157_fu_27313_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_157_fu_27331_p2() {
    mul_ln1118_157_fu_27331_p2 = (!mul_ln1118_157_fu_27331_p0.read().is_01() || !mul_ln1118_157_fu_27331_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_157_fu_27331_p0.read()) * sc_bigint<5>(mul_ln1118_157_fu_27331_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1580_fu_67535_p0() {
    mul_ln1118_1580_fu_67535_p0 =  (sc_lv<3>) (sext_ln1116_180_fu_28201_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1580_fu_67535_p1() {
    mul_ln1118_1580_fu_67535_p1 = tmp_1580_fu_67521_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1580_fu_67535_p2() {
    mul_ln1118_1580_fu_67535_p2 = (!mul_ln1118_1580_fu_67535_p0.read().is_01() || !mul_ln1118_1580_fu_67535_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1580_fu_67535_p0.read()) * sc_bigint<5>(mul_ln1118_1580_fu_67535_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1581_fu_67567_p0() {
    mul_ln1118_1581_fu_67567_p0 =  (sc_lv<3>) (sext_ln1116_181_fu_28245_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1581_fu_67567_p1() {
    mul_ln1118_1581_fu_67567_p1 = tmp_1581_fu_67553_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1581_fu_67567_p2() {
    mul_ln1118_1581_fu_67567_p2 = (!mul_ln1118_1581_fu_67567_p0.read().is_01() || !mul_ln1118_1581_fu_67567_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1581_fu_67567_p0.read()) * sc_bigint<5>(mul_ln1118_1581_fu_67567_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1582_fu_67599_p0() {
    mul_ln1118_1582_fu_67599_p0 =  (sc_lv<3>) (sext_ln1116_182_fu_28289_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1582_fu_67599_p1() {
    mul_ln1118_1582_fu_67599_p1 = tmp_1582_fu_67585_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1582_fu_67599_p2() {
    mul_ln1118_1582_fu_67599_p2 = (!mul_ln1118_1582_fu_67599_p0.read().is_01() || !mul_ln1118_1582_fu_67599_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1582_fu_67599_p0.read()) * sc_bigint<5>(mul_ln1118_1582_fu_67599_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1583_fu_67631_p0() {
    mul_ln1118_1583_fu_67631_p0 =  (sc_lv<3>) (sext_ln1116_183_fu_28333_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1583_fu_67631_p1() {
    mul_ln1118_1583_fu_67631_p1 = tmp_1583_fu_67617_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1583_fu_67631_p2() {
    mul_ln1118_1583_fu_67631_p2 = (!mul_ln1118_1583_fu_67631_p0.read().is_01() || !mul_ln1118_1583_fu_67631_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1583_fu_67631_p0.read()) * sc_bigint<5>(mul_ln1118_1583_fu_67631_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1584_fu_67663_p0() {
    mul_ln1118_1584_fu_67663_p0 =  (sc_lv<3>) (sext_ln1116_184_fu_28377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1584_fu_67663_p1() {
    mul_ln1118_1584_fu_67663_p1 = tmp_1584_fu_67649_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1584_fu_67663_p2() {
    mul_ln1118_1584_fu_67663_p2 = (!mul_ln1118_1584_fu_67663_p0.read().is_01() || !mul_ln1118_1584_fu_67663_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1584_fu_67663_p0.read()) * sc_bigint<5>(mul_ln1118_1584_fu_67663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1585_fu_67683_p0() {
    mul_ln1118_1585_fu_67683_p0 =  (sc_lv<3>) (sext_ln1116_185_fu_28409_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1585_fu_67683_p1() {
    mul_ln1118_1585_fu_67683_p1 = tmp_1585_fu_67669_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1585_fu_67683_p2() {
    mul_ln1118_1585_fu_67683_p2 = (!mul_ln1118_1585_fu_67683_p0.read().is_01() || !mul_ln1118_1585_fu_67683_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1585_fu_67683_p0.read()) * sc_bigint<5>(mul_ln1118_1585_fu_67683_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1586_fu_67715_p0() {
    mul_ln1118_1586_fu_67715_p0 =  (sc_lv<3>) (sext_ln1116_186_fu_28453_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1586_fu_67715_p1() {
    mul_ln1118_1586_fu_67715_p1 = tmp_1586_fu_67701_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1586_fu_67715_p2() {
    mul_ln1118_1586_fu_67715_p2 = (!mul_ln1118_1586_fu_67715_p0.read().is_01() || !mul_ln1118_1586_fu_67715_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1586_fu_67715_p0.read()) * sc_bigint<5>(mul_ln1118_1586_fu_67715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1587_fu_67747_p0() {
    mul_ln1118_1587_fu_67747_p0 =  (sc_lv<3>) (sext_ln1116_187_fu_28497_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1587_fu_67747_p1() {
    mul_ln1118_1587_fu_67747_p1 = tmp_1587_fu_67733_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1587_fu_67747_p2() {
    mul_ln1118_1587_fu_67747_p2 = (!mul_ln1118_1587_fu_67747_p0.read().is_01() || !mul_ln1118_1587_fu_67747_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1587_fu_67747_p0.read()) * sc_bigint<5>(mul_ln1118_1587_fu_67747_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1588_fu_67767_p0() {
    mul_ln1118_1588_fu_67767_p0 =  (sc_lv<3>) (sext_ln1116_188_fu_28529_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1588_fu_67767_p1() {
    mul_ln1118_1588_fu_67767_p1 = tmp_1588_fu_67753_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1588_fu_67767_p2() {
    mul_ln1118_1588_fu_67767_p2 = (!mul_ln1118_1588_fu_67767_p0.read().is_01() || !mul_ln1118_1588_fu_67767_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1588_fu_67767_p0.read()) * sc_bigint<5>(mul_ln1118_1588_fu_67767_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1589_fu_67799_p0() {
    mul_ln1118_1589_fu_67799_p0 =  (sc_lv<3>) (sext_ln1116_189_fu_28573_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1589_fu_67799_p1() {
    mul_ln1118_1589_fu_67799_p1 = tmp_1589_fu_67785_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1589_fu_67799_p2() {
    mul_ln1118_1589_fu_67799_p2 = (!mul_ln1118_1589_fu_67799_p0.read().is_01() || !mul_ln1118_1589_fu_67799_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1589_fu_67799_p0.read()) * sc_bigint<5>(mul_ln1118_1589_fu_67799_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_158_fu_27375_p0() {
    mul_ln1118_158_fu_27375_p0 =  (sc_lv<3>) (sext_ln1116_158_fu_27367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_158_fu_27375_p1() {
    mul_ln1118_158_fu_27375_p1 = tmp_158_fu_27357_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_158_fu_27375_p2() {
    mul_ln1118_158_fu_27375_p2 = (!mul_ln1118_158_fu_27375_p0.read().is_01() || !mul_ln1118_158_fu_27375_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_158_fu_27375_p0.read()) * sc_bigint<5>(mul_ln1118_158_fu_27375_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1590_fu_97564_p0() {
    mul_ln1118_1590_fu_97564_p0 =  (sc_lv<3>) (sext_ln1116_190_reg_106681.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1590_fu_97564_p1() {
    mul_ln1118_1590_fu_97564_p1 = tmp_1590_reg_111326.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1590_fu_97564_p2() {
    mul_ln1118_1590_fu_97564_p2 = (!mul_ln1118_1590_fu_97564_p0.read().is_01() || !mul_ln1118_1590_fu_97564_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1590_fu_97564_p0.read()) * sc_bigint<5>(mul_ln1118_1590_fu_97564_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1591_fu_67841_p0() {
    mul_ln1118_1591_fu_67841_p0 =  (sc_lv<3>) (sext_ln1116_191_fu_28639_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1591_fu_67841_p1() {
    mul_ln1118_1591_fu_67841_p1 = tmp_1591_fu_67827_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1591_fu_67841_p2() {
    mul_ln1118_1591_fu_67841_p2 = (!mul_ln1118_1591_fu_67841_p0.read().is_01() || !mul_ln1118_1591_fu_67841_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1591_fu_67841_p0.read()) * sc_bigint<5>(mul_ln1118_1591_fu_67841_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1592_fu_67873_p0() {
    mul_ln1118_1592_fu_67873_p0 =  (sc_lv<3>) (sext_ln1116_192_fu_28683_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1592_fu_67873_p1() {
    mul_ln1118_1592_fu_67873_p1 = tmp_1592_fu_67859_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1592_fu_67873_p2() {
    mul_ln1118_1592_fu_67873_p2 = (!mul_ln1118_1592_fu_67873_p0.read().is_01() || !mul_ln1118_1592_fu_67873_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1592_fu_67873_p0.read()) * sc_bigint<5>(mul_ln1118_1592_fu_67873_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1593_fu_97584_p0() {
    mul_ln1118_1593_fu_97584_p0 =  (sc_lv<3>) (sext_ln1116_193_reg_106699.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1593_fu_97584_p1() {
    mul_ln1118_1593_fu_97584_p1 = tmp_1593_reg_111331.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1593_fu_97584_p2() {
    mul_ln1118_1593_fu_97584_p2 = (!mul_ln1118_1593_fu_97584_p0.read().is_01() || !mul_ln1118_1593_fu_97584_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1593_fu_97584_p0.read()) * sc_bigint<5>(mul_ln1118_1593_fu_97584_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1594_fu_67915_p0() {
    mul_ln1118_1594_fu_67915_p0 =  (sc_lv<3>) (sext_ln1116_194_fu_28749_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1594_fu_67915_p1() {
    mul_ln1118_1594_fu_67915_p1 = tmp_1594_fu_67901_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1594_fu_67915_p2() {
    mul_ln1118_1594_fu_67915_p2 = (!mul_ln1118_1594_fu_67915_p0.read().is_01() || !mul_ln1118_1594_fu_67915_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1594_fu_67915_p0.read()) * sc_bigint<5>(mul_ln1118_1594_fu_67915_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1595_fu_67947_p0() {
    mul_ln1118_1595_fu_67947_p0 =  (sc_lv<3>) (sext_ln1116_195_fu_28793_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1595_fu_67947_p1() {
    mul_ln1118_1595_fu_67947_p1 = tmp_1595_fu_67933_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1595_fu_67947_p2() {
    mul_ln1118_1595_fu_67947_p2 = (!mul_ln1118_1595_fu_67947_p0.read().is_01() || !mul_ln1118_1595_fu_67947_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1595_fu_67947_p0.read()) * sc_bigint<5>(mul_ln1118_1595_fu_67947_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1596_fu_97604_p0() {
    mul_ln1118_1596_fu_97604_p0 =  (sc_lv<3>) (sext_ln1116_196_reg_106717.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1596_fu_97604_p1() {
    mul_ln1118_1596_fu_97604_p1 = tmp_1596_reg_111336.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1596_fu_97604_p2() {
    mul_ln1118_1596_fu_97604_p2 = (!mul_ln1118_1596_fu_97604_p0.read().is_01() || !mul_ln1118_1596_fu_97604_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1596_fu_97604_p0.read()) * sc_bigint<5>(mul_ln1118_1596_fu_97604_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1597_fu_67989_p0() {
    mul_ln1118_1597_fu_67989_p0 =  (sc_lv<3>) (sext_ln1116_197_fu_28859_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1597_fu_67989_p1() {
    mul_ln1118_1597_fu_67989_p1 = tmp_1597_fu_67975_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1597_fu_67989_p2() {
    mul_ln1118_1597_fu_67989_p2 = (!mul_ln1118_1597_fu_67989_p0.read().is_01() || !mul_ln1118_1597_fu_67989_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1597_fu_67989_p0.read()) * sc_bigint<5>(mul_ln1118_1597_fu_67989_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1598_fu_68021_p0() {
    mul_ln1118_1598_fu_68021_p0 =  (sc_lv<3>) (sext_ln1116_198_fu_28903_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1598_fu_68021_p1() {
    mul_ln1118_1598_fu_68021_p1 = tmp_1598_fu_68007_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1598_fu_68021_p2() {
    mul_ln1118_1598_fu_68021_p2 = (!mul_ln1118_1598_fu_68021_p0.read().is_01() || !mul_ln1118_1598_fu_68021_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1598_fu_68021_p0.read()) * sc_bigint<5>(mul_ln1118_1598_fu_68021_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1599_fu_97624_p0() {
    mul_ln1118_1599_fu_97624_p0 =  (sc_lv<3>) (sext_ln1116_199_reg_106735.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1599_fu_97624_p1() {
    mul_ln1118_1599_fu_97624_p1 = tmp_1599_reg_111341.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1599_fu_97624_p2() {
    mul_ln1118_1599_fu_97624_p2 = (!mul_ln1118_1599_fu_97624_p0.read().is_01() || !mul_ln1118_1599_fu_97624_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1599_fu_97624_p0.read()) * sc_bigint<5>(mul_ln1118_1599_fu_97624_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_159_fu_27419_p0() {
    mul_ln1118_159_fu_27419_p0 =  (sc_lv<3>) (sext_ln1116_159_fu_27411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_159_fu_27419_p1() {
    mul_ln1118_159_fu_27419_p1 = tmp_159_fu_27401_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_159_fu_27419_p2() {
    mul_ln1118_159_fu_27419_p2 = (!mul_ln1118_159_fu_27419_p0.read().is_01() || !mul_ln1118_159_fu_27419_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_159_fu_27419_p0.read()) * sc_bigint<5>(mul_ln1118_159_fu_27419_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_15_fu_80039_p0() {
    mul_ln1118_15_fu_80039_p0 =  (sc_lv<3>) (sext_ln1116_15_fu_80033_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_15_fu_80039_p1() {
    mul_ln1118_15_fu_80039_p1 = tmp_16_reg_105957.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_15_fu_80039_p2() {
    mul_ln1118_15_fu_80039_p2 = (!mul_ln1118_15_fu_80039_p0.read().is_01() || !mul_ln1118_15_fu_80039_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_15_fu_80039_p0.read()) * sc_bigint<5>(mul_ln1118_15_fu_80039_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1600_fu_68063_p0() {
    mul_ln1118_1600_fu_68063_p0 =  (sc_lv<3>) (sext_ln1116_200_fu_28969_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1600_fu_68063_p1() {
    mul_ln1118_1600_fu_68063_p1 = tmp_1600_fu_68049_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1600_fu_68063_p2() {
    mul_ln1118_1600_fu_68063_p2 = (!mul_ln1118_1600_fu_68063_p0.read().is_01() || !mul_ln1118_1600_fu_68063_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1600_fu_68063_p0.read()) * sc_bigint<5>(mul_ln1118_1600_fu_68063_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1601_fu_68095_p0() {
    mul_ln1118_1601_fu_68095_p0 =  (sc_lv<3>) (sext_ln1116_201_fu_29013_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1601_fu_68095_p1() {
    mul_ln1118_1601_fu_68095_p1 = tmp_1601_fu_68081_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1601_fu_68095_p2() {
    mul_ln1118_1601_fu_68095_p2 = (!mul_ln1118_1601_fu_68095_p0.read().is_01() || !mul_ln1118_1601_fu_68095_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1601_fu_68095_p0.read()) * sc_bigint<5>(mul_ln1118_1601_fu_68095_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1602_fu_97644_p0() {
    mul_ln1118_1602_fu_97644_p0 =  (sc_lv<3>) (sext_ln1116_202_reg_106753.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1602_fu_97644_p1() {
    mul_ln1118_1602_fu_97644_p1 = tmp_1602_reg_111346.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1602_fu_97644_p2() {
    mul_ln1118_1602_fu_97644_p2 = (!mul_ln1118_1602_fu_97644_p0.read().is_01() || !mul_ln1118_1602_fu_97644_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1602_fu_97644_p0.read()) * sc_bigint<5>(mul_ln1118_1602_fu_97644_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1603_fu_68137_p0() {
    mul_ln1118_1603_fu_68137_p0 =  (sc_lv<3>) (sext_ln1116_203_fu_29079_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1603_fu_68137_p1() {
    mul_ln1118_1603_fu_68137_p1 = tmp_1603_fu_68123_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1603_fu_68137_p2() {
    mul_ln1118_1603_fu_68137_p2 = (!mul_ln1118_1603_fu_68137_p0.read().is_01() || !mul_ln1118_1603_fu_68137_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1603_fu_68137_p0.read()) * sc_bigint<5>(mul_ln1118_1603_fu_68137_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1604_fu_68169_p0() {
    mul_ln1118_1604_fu_68169_p0 =  (sc_lv<3>) (sext_ln1116_204_fu_29123_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1604_fu_68169_p1() {
    mul_ln1118_1604_fu_68169_p1 = tmp_1604_fu_68155_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1604_fu_68169_p2() {
    mul_ln1118_1604_fu_68169_p2 = (!mul_ln1118_1604_fu_68169_p0.read().is_01() || !mul_ln1118_1604_fu_68169_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1604_fu_68169_p0.read()) * sc_bigint<5>(mul_ln1118_1604_fu_68169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1605_fu_68201_p0() {
    mul_ln1118_1605_fu_68201_p0 =  (sc_lv<3>) (sext_ln1116_205_fu_29167_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1605_fu_68201_p1() {
    mul_ln1118_1605_fu_68201_p1 = tmp_1605_fu_68187_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1605_fu_68201_p2() {
    mul_ln1118_1605_fu_68201_p2 = (!mul_ln1118_1605_fu_68201_p0.read().is_01() || !mul_ln1118_1605_fu_68201_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1605_fu_68201_p0.read()) * sc_bigint<5>(mul_ln1118_1605_fu_68201_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1606_fu_68233_p0() {
    mul_ln1118_1606_fu_68233_p0 =  (sc_lv<3>) (sext_ln1116_206_fu_29211_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1606_fu_68233_p1() {
    mul_ln1118_1606_fu_68233_p1 = tmp_1606_fu_68219_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1606_fu_68233_p2() {
    mul_ln1118_1606_fu_68233_p2 = (!mul_ln1118_1606_fu_68233_p0.read().is_01() || !mul_ln1118_1606_fu_68233_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1606_fu_68233_p0.read()) * sc_bigint<5>(mul_ln1118_1606_fu_68233_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1607_fu_68265_p0() {
    mul_ln1118_1607_fu_68265_p0 =  (sc_lv<3>) (sext_ln1116_207_fu_29255_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1607_fu_68265_p1() {
    mul_ln1118_1607_fu_68265_p1 = tmp_1607_fu_68251_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1607_fu_68265_p2() {
    mul_ln1118_1607_fu_68265_p2 = (!mul_ln1118_1607_fu_68265_p0.read().is_01() || !mul_ln1118_1607_fu_68265_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1607_fu_68265_p0.read()) * sc_bigint<5>(mul_ln1118_1607_fu_68265_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1608_fu_68297_p0() {
    mul_ln1118_1608_fu_68297_p0 =  (sc_lv<3>) (sext_ln1116_208_fu_29299_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1608_fu_68297_p1() {
    mul_ln1118_1608_fu_68297_p1 = tmp_1608_fu_68283_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1608_fu_68297_p2() {
    mul_ln1118_1608_fu_68297_p2 = (!mul_ln1118_1608_fu_68297_p0.read().is_01() || !mul_ln1118_1608_fu_68297_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1608_fu_68297_p0.read()) * sc_bigint<5>(mul_ln1118_1608_fu_68297_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1609_fu_68743_p0() {
    mul_ln1118_1609_fu_68743_p0 =  (sc_lv<3>) (sext_ln1116_fu_21855_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1609_fu_68743_p1() {
    mul_ln1118_1609_fu_68743_p1 = tmp_1609_fu_68729_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1609_fu_68743_p2() {
    mul_ln1118_1609_fu_68743_p2 = (!mul_ln1118_1609_fu_68743_p0.read().is_01() || !mul_ln1118_1609_fu_68743_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1609_fu_68743_p0.read()) * sc_bigint<5>(mul_ln1118_1609_fu_68743_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_160_fu_27451_p0() {
    mul_ln1118_160_fu_27451_p0 =  (sc_lv<3>) (sext_ln1116_160_fu_27443_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_160_fu_27451_p1() {
    mul_ln1118_160_fu_27451_p1 = tmp_160_fu_27433_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_160_fu_27451_p2() {
    mul_ln1118_160_fu_27451_p2 = (!mul_ln1118_160_fu_27451_p0.read().is_01() || !mul_ln1118_160_fu_27451_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_160_fu_27451_p0.read()) * sc_bigint<5>(mul_ln1118_160_fu_27451_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1610_fu_68763_p0() {
    mul_ln1118_1610_fu_68763_p0 =  (sc_lv<3>) (sext_ln1116_10_fu_21887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1610_fu_68763_p1() {
    mul_ln1118_1610_fu_68763_p1 = tmp_1610_fu_68749_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1610_fu_68763_p2() {
    mul_ln1118_1610_fu_68763_p2 = (!mul_ln1118_1610_fu_68763_p0.read().is_01() || !mul_ln1118_1610_fu_68763_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1610_fu_68763_p0.read()) * sc_bigint<5>(mul_ln1118_1610_fu_68763_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1611_fu_68795_p0() {
    mul_ln1118_1611_fu_68795_p0 =  (sc_lv<3>) (sext_ln1116_11_fu_21931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1611_fu_68795_p1() {
    mul_ln1118_1611_fu_68795_p1 = tmp_1611_fu_68781_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1611_fu_68795_p2() {
    mul_ln1118_1611_fu_68795_p2 = (!mul_ln1118_1611_fu_68795_p0.read().is_01() || !mul_ln1118_1611_fu_68795_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1611_fu_68795_p0.read()) * sc_bigint<5>(mul_ln1118_1611_fu_68795_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1612_fu_68827_p0() {
    mul_ln1118_1612_fu_68827_p0 =  (sc_lv<3>) (sext_ln1116_12_fu_21975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1612_fu_68827_p1() {
    mul_ln1118_1612_fu_68827_p1 = tmp_1612_fu_68813_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1612_fu_68827_p2() {
    mul_ln1118_1612_fu_68827_p2 = (!mul_ln1118_1612_fu_68827_p0.read().is_01() || !mul_ln1118_1612_fu_68827_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1612_fu_68827_p0.read()) * sc_bigint<5>(mul_ln1118_1612_fu_68827_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1613_fu_68847_p0() {
    mul_ln1118_1613_fu_68847_p0 =  (sc_lv<3>) (sext_ln1116_13_fu_22007_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1613_fu_68847_p1() {
    mul_ln1118_1613_fu_68847_p1 = tmp_1613_fu_68833_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1613_fu_68847_p2() {
    mul_ln1118_1613_fu_68847_p2 = (!mul_ln1118_1613_fu_68847_p0.read().is_01() || !mul_ln1118_1613_fu_68847_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1613_fu_68847_p0.read()) * sc_bigint<5>(mul_ln1118_1613_fu_68847_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1614_fu_68879_p0() {
    mul_ln1118_1614_fu_68879_p0 =  (sc_lv<3>) (sext_ln1116_14_fu_22051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1614_fu_68879_p1() {
    mul_ln1118_1614_fu_68879_p1 = tmp_1614_fu_68865_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1614_fu_68879_p2() {
    mul_ln1118_1614_fu_68879_p2 = (!mul_ln1118_1614_fu_68879_p0.read().is_01() || !mul_ln1118_1614_fu_68879_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1614_fu_68879_p0.read()) * sc_bigint<5>(mul_ln1118_1614_fu_68879_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1615_fu_98887_p0() {
    mul_ln1118_1615_fu_98887_p0 =  (sc_lv<3>) (sext_ln1116_15_fu_80033_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1615_fu_98887_p1() {
    mul_ln1118_1615_fu_98887_p1 = tmp_1615_reg_111706.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1615_fu_98887_p2() {
    mul_ln1118_1615_fu_98887_p2 = (!mul_ln1118_1615_fu_98887_p0.read().is_01() || !mul_ln1118_1615_fu_98887_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1615_fu_98887_p0.read()) * sc_bigint<5>(mul_ln1118_1615_fu_98887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1616_fu_68921_p0() {
    mul_ln1118_1616_fu_68921_p0 =  (sc_lv<3>) (sext_ln1116_16_fu_22113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1616_fu_68921_p1() {
    mul_ln1118_1616_fu_68921_p1 = tmp_1616_fu_68907_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1616_fu_68921_p2() {
    mul_ln1118_1616_fu_68921_p2 = (!mul_ln1118_1616_fu_68921_p0.read().is_01() || !mul_ln1118_1616_fu_68921_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1616_fu_68921_p0.read()) * sc_bigint<5>(mul_ln1118_1616_fu_68921_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1617_fu_68953_p0() {
    mul_ln1118_1617_fu_68953_p0 =  (sc_lv<3>) (sext_ln1116_17_fu_22157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1617_fu_68953_p1() {
    mul_ln1118_1617_fu_68953_p1 = tmp_1617_fu_68939_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1617_fu_68953_p2() {
    mul_ln1118_1617_fu_68953_p2 = (!mul_ln1118_1617_fu_68953_p0.read().is_01() || !mul_ln1118_1617_fu_68953_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1617_fu_68953_p0.read()) * sc_bigint<5>(mul_ln1118_1617_fu_68953_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1618_fu_98908_p0() {
    mul_ln1118_1618_fu_98908_p0 =  (sc_lv<3>) (sext_ln1116_18_fu_80057_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1618_fu_98908_p1() {
    mul_ln1118_1618_fu_98908_p1 = tmp_1618_reg_111711.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1618_fu_98908_p2() {
    mul_ln1118_1618_fu_98908_p2 = (!mul_ln1118_1618_fu_98908_p0.read().is_01() || !mul_ln1118_1618_fu_98908_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1618_fu_98908_p0.read()) * sc_bigint<5>(mul_ln1118_1618_fu_98908_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1619_fu_68995_p0() {
    mul_ln1118_1619_fu_68995_p0 =  (sc_lv<3>) (sext_ln1116_19_fu_22219_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1619_fu_68995_p1() {
    mul_ln1118_1619_fu_68995_p1 = tmp_1619_fu_68981_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1619_fu_68995_p2() {
    mul_ln1118_1619_fu_68995_p2 = (!mul_ln1118_1619_fu_68995_p0.read().is_01() || !mul_ln1118_1619_fu_68995_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1619_fu_68995_p0.read()) * sc_bigint<5>(mul_ln1118_1619_fu_68995_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_161_fu_27495_p0() {
    mul_ln1118_161_fu_27495_p0 =  (sc_lv<3>) (sext_ln1116_161_fu_27487_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_161_fu_27495_p1() {
    mul_ln1118_161_fu_27495_p1 = tmp_161_fu_27477_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_161_fu_27495_p2() {
    mul_ln1118_161_fu_27495_p2 = (!mul_ln1118_161_fu_27495_p0.read().is_01() || !mul_ln1118_161_fu_27495_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_161_fu_27495_p0.read()) * sc_bigint<5>(mul_ln1118_161_fu_27495_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1620_fu_69027_p0() {
    mul_ln1118_1620_fu_69027_p0 =  (sc_lv<3>) (sext_ln1116_20_fu_22263_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1620_fu_69027_p1() {
    mul_ln1118_1620_fu_69027_p1 = tmp_1620_fu_69013_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1620_fu_69027_p2() {
    mul_ln1118_1620_fu_69027_p2 = (!mul_ln1118_1620_fu_69027_p0.read().is_01() || !mul_ln1118_1620_fu_69027_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1620_fu_69027_p0.read()) * sc_bigint<5>(mul_ln1118_1620_fu_69027_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1621_fu_98929_p0() {
    mul_ln1118_1621_fu_98929_p0 =  (sc_lv<3>) (sext_ln1116_21_fu_80081_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1621_fu_98929_p1() {
    mul_ln1118_1621_fu_98929_p1 = tmp_1621_reg_111716.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1621_fu_98929_p2() {
    mul_ln1118_1621_fu_98929_p2 = (!mul_ln1118_1621_fu_98929_p0.read().is_01() || !mul_ln1118_1621_fu_98929_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1621_fu_98929_p0.read()) * sc_bigint<5>(mul_ln1118_1621_fu_98929_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1622_fu_69069_p0() {
    mul_ln1118_1622_fu_69069_p0 =  (sc_lv<3>) (sext_ln1116_22_fu_22325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1622_fu_69069_p1() {
    mul_ln1118_1622_fu_69069_p1 = tmp_1622_fu_69055_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1622_fu_69069_p2() {
    mul_ln1118_1622_fu_69069_p2 = (!mul_ln1118_1622_fu_69069_p0.read().is_01() || !mul_ln1118_1622_fu_69069_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1622_fu_69069_p0.read()) * sc_bigint<5>(mul_ln1118_1622_fu_69069_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1623_fu_69101_p0() {
    mul_ln1118_1623_fu_69101_p0 =  (sc_lv<3>) (sext_ln1116_23_fu_22369_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1623_fu_69101_p1() {
    mul_ln1118_1623_fu_69101_p1 = tmp_1623_fu_69087_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1623_fu_69101_p2() {
    mul_ln1118_1623_fu_69101_p2 = (!mul_ln1118_1623_fu_69101_p0.read().is_01() || !mul_ln1118_1623_fu_69101_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1623_fu_69101_p0.read()) * sc_bigint<5>(mul_ln1118_1623_fu_69101_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1624_fu_98950_p0() {
    mul_ln1118_1624_fu_98950_p0 =  (sc_lv<3>) (sext_ln1116_24_fu_80105_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1624_fu_98950_p1() {
    mul_ln1118_1624_fu_98950_p1 = tmp_1624_reg_111721.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1624_fu_98950_p2() {
    mul_ln1118_1624_fu_98950_p2 = (!mul_ln1118_1624_fu_98950_p0.read().is_01() || !mul_ln1118_1624_fu_98950_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1624_fu_98950_p0.read()) * sc_bigint<5>(mul_ln1118_1624_fu_98950_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1625_fu_69143_p0() {
    mul_ln1118_1625_fu_69143_p0 =  (sc_lv<3>) (sext_ln1116_25_fu_22431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1625_fu_69143_p1() {
    mul_ln1118_1625_fu_69143_p1 = tmp_1625_fu_69129_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1625_fu_69143_p2() {
    mul_ln1118_1625_fu_69143_p2 = (!mul_ln1118_1625_fu_69143_p0.read().is_01() || !mul_ln1118_1625_fu_69143_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1625_fu_69143_p0.read()) * sc_bigint<5>(mul_ln1118_1625_fu_69143_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1626_fu_69175_p0() {
    mul_ln1118_1626_fu_69175_p0 =  (sc_lv<3>) (sext_ln1116_26_fu_22475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1626_fu_69175_p1() {
    mul_ln1118_1626_fu_69175_p1 = tmp_1626_fu_69161_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1626_fu_69175_p2() {
    mul_ln1118_1626_fu_69175_p2 = (!mul_ln1118_1626_fu_69175_p0.read().is_01() || !mul_ln1118_1626_fu_69175_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1626_fu_69175_p0.read()) * sc_bigint<5>(mul_ln1118_1626_fu_69175_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1627_fu_98971_p0() {
    mul_ln1118_1627_fu_98971_p0 =  (sc_lv<3>) (sext_ln1116_27_fu_80129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1627_fu_98971_p1() {
    mul_ln1118_1627_fu_98971_p1 = tmp_1627_reg_111726.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1627_fu_98971_p2() {
    mul_ln1118_1627_fu_98971_p2 = (!mul_ln1118_1627_fu_98971_p0.read().is_01() || !mul_ln1118_1627_fu_98971_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1627_fu_98971_p0.read()) * sc_bigint<5>(mul_ln1118_1627_fu_98971_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1628_fu_69217_p0() {
    mul_ln1118_1628_fu_69217_p0 =  (sc_lv<3>) (sext_ln1116_28_fu_22537_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1628_fu_69217_p1() {
    mul_ln1118_1628_fu_69217_p1 = tmp_1628_fu_69203_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1628_fu_69217_p2() {
    mul_ln1118_1628_fu_69217_p2 = (!mul_ln1118_1628_fu_69217_p0.read().is_01() || !mul_ln1118_1628_fu_69217_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1628_fu_69217_p0.read()) * sc_bigint<5>(mul_ln1118_1628_fu_69217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1629_fu_69249_p0() {
    mul_ln1118_1629_fu_69249_p0 =  (sc_lv<3>) (sext_ln1116_29_fu_22581_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1629_fu_69249_p1() {
    mul_ln1118_1629_fu_69249_p1 = tmp_1629_fu_69235_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1629_fu_69249_p2() {
    mul_ln1118_1629_fu_69249_p2 = (!mul_ln1118_1629_fu_69249_p0.read().is_01() || !mul_ln1118_1629_fu_69249_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1629_fu_69249_p0.read()) * sc_bigint<5>(mul_ln1118_1629_fu_69249_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_162_fu_27539_p0() {
    mul_ln1118_162_fu_27539_p0 =  (sc_lv<3>) (sext_ln1116_162_fu_27531_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_162_fu_27539_p1() {
    mul_ln1118_162_fu_27539_p1 = tmp_162_fu_27521_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_162_fu_27539_p2() {
    mul_ln1118_162_fu_27539_p2 = (!mul_ln1118_162_fu_27539_p0.read().is_01() || !mul_ln1118_162_fu_27539_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_162_fu_27539_p0.read()) * sc_bigint<5>(mul_ln1118_162_fu_27539_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1630_fu_69281_p0() {
    mul_ln1118_1630_fu_69281_p0 =  (sc_lv<3>) (sext_ln1116_30_fu_22625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1630_fu_69281_p1() {
    mul_ln1118_1630_fu_69281_p1 = tmp_1630_fu_69267_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1630_fu_69281_p2() {
    mul_ln1118_1630_fu_69281_p2 = (!mul_ln1118_1630_fu_69281_p0.read().is_01() || !mul_ln1118_1630_fu_69281_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1630_fu_69281_p0.read()) * sc_bigint<5>(mul_ln1118_1630_fu_69281_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1631_fu_69313_p0() {
    mul_ln1118_1631_fu_69313_p0 =  (sc_lv<3>) (sext_ln1116_31_fu_22669_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1631_fu_69313_p1() {
    mul_ln1118_1631_fu_69313_p1 = tmp_1631_fu_69299_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1631_fu_69313_p2() {
    mul_ln1118_1631_fu_69313_p2 = (!mul_ln1118_1631_fu_69313_p0.read().is_01() || !mul_ln1118_1631_fu_69313_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1631_fu_69313_p0.read()) * sc_bigint<5>(mul_ln1118_1631_fu_69313_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1632_fu_69345_p0() {
    mul_ln1118_1632_fu_69345_p0 =  (sc_lv<3>) (sext_ln1116_32_fu_22713_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1632_fu_69345_p1() {
    mul_ln1118_1632_fu_69345_p1 = tmp_1632_fu_69331_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1632_fu_69345_p2() {
    mul_ln1118_1632_fu_69345_p2 = (!mul_ln1118_1632_fu_69345_p0.read().is_01() || !mul_ln1118_1632_fu_69345_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1632_fu_69345_p0.read()) * sc_bigint<5>(mul_ln1118_1632_fu_69345_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1633_fu_69377_p0() {
    mul_ln1118_1633_fu_69377_p0 =  (sc_lv<3>) (sext_ln1116_33_fu_22757_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1633_fu_69377_p1() {
    mul_ln1118_1633_fu_69377_p1 = tmp_1633_fu_69363_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1633_fu_69377_p2() {
    mul_ln1118_1633_fu_69377_p2 = (!mul_ln1118_1633_fu_69377_p0.read().is_01() || !mul_ln1118_1633_fu_69377_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1633_fu_69377_p0.read()) * sc_bigint<5>(mul_ln1118_1633_fu_69377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1634_fu_98992_p0() {
    mul_ln1118_1634_fu_98992_p0 =  (sc_lv<3>) (sext_ln1116_34_reg_106007.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1634_fu_98992_p1() {
    mul_ln1118_1634_fu_98992_p1 = tmp_1634_reg_111731.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1634_fu_98992_p2() {
    mul_ln1118_1634_fu_98992_p2 = (!mul_ln1118_1634_fu_98992_p0.read().is_01() || !mul_ln1118_1634_fu_98992_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1634_fu_98992_p0.read()) * sc_bigint<5>(mul_ln1118_1634_fu_98992_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1635_fu_69419_p0() {
    mul_ln1118_1635_fu_69419_p0 =  (sc_lv<3>) (sext_ln1116_35_fu_22823_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1635_fu_69419_p1() {
    mul_ln1118_1635_fu_69419_p1 = tmp_1635_fu_69405_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1635_fu_69419_p2() {
    mul_ln1118_1635_fu_69419_p2 = (!mul_ln1118_1635_fu_69419_p0.read().is_01() || !mul_ln1118_1635_fu_69419_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1635_fu_69419_p0.read()) * sc_bigint<5>(mul_ln1118_1635_fu_69419_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1636_fu_69451_p0() {
    mul_ln1118_1636_fu_69451_p0 =  (sc_lv<3>) (sext_ln1116_36_fu_22867_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1636_fu_69451_p1() {
    mul_ln1118_1636_fu_69451_p1 = tmp_1636_fu_69437_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1636_fu_69451_p2() {
    mul_ln1118_1636_fu_69451_p2 = (!mul_ln1118_1636_fu_69451_p0.read().is_01() || !mul_ln1118_1636_fu_69451_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1636_fu_69451_p0.read()) * sc_bigint<5>(mul_ln1118_1636_fu_69451_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1637_fu_99012_p0() {
    mul_ln1118_1637_fu_99012_p0 =  (sc_lv<3>) (sext_ln1116_37_reg_106025.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1637_fu_99012_p1() {
    mul_ln1118_1637_fu_99012_p1 = tmp_1637_reg_111736.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1637_fu_99012_p2() {
    mul_ln1118_1637_fu_99012_p2 = (!mul_ln1118_1637_fu_99012_p0.read().is_01() || !mul_ln1118_1637_fu_99012_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1637_fu_99012_p0.read()) * sc_bigint<5>(mul_ln1118_1637_fu_99012_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1638_fu_69493_p0() {
    mul_ln1118_1638_fu_69493_p0 =  (sc_lv<3>) (sext_ln1116_38_fu_22933_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1638_fu_69493_p1() {
    mul_ln1118_1638_fu_69493_p1 = tmp_1638_fu_69479_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1638_fu_69493_p2() {
    mul_ln1118_1638_fu_69493_p2 = (!mul_ln1118_1638_fu_69493_p0.read().is_01() || !mul_ln1118_1638_fu_69493_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1638_fu_69493_p0.read()) * sc_bigint<5>(mul_ln1118_1638_fu_69493_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1639_fu_69525_p0() {
    mul_ln1118_1639_fu_69525_p0 =  (sc_lv<3>) (sext_ln1116_39_fu_22977_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1639_fu_69525_p1() {
    mul_ln1118_1639_fu_69525_p1 = tmp_1639_fu_69511_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1639_fu_69525_p2() {
    mul_ln1118_1639_fu_69525_p2 = (!mul_ln1118_1639_fu_69525_p0.read().is_01() || !mul_ln1118_1639_fu_69525_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1639_fu_69525_p0.read()) * sc_bigint<5>(mul_ln1118_1639_fu_69525_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_163_fu_27571_p0() {
    mul_ln1118_163_fu_27571_p0 =  (sc_lv<3>) (sext_ln1116_163_fu_27563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_163_fu_27571_p1() {
    mul_ln1118_163_fu_27571_p1 = tmp_163_fu_27553_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_163_fu_27571_p2() {
    mul_ln1118_163_fu_27571_p2 = (!mul_ln1118_163_fu_27571_p0.read().is_01() || !mul_ln1118_163_fu_27571_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_163_fu_27571_p0.read()) * sc_bigint<5>(mul_ln1118_163_fu_27571_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1640_fu_99032_p0() {
    mul_ln1118_1640_fu_99032_p0 =  (sc_lv<3>) (sext_ln1116_40_fu_80193_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1640_fu_99032_p1() {
    mul_ln1118_1640_fu_99032_p1 = tmp_1640_reg_111741.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1640_fu_99032_p2() {
    mul_ln1118_1640_fu_99032_p2 = (!mul_ln1118_1640_fu_99032_p0.read().is_01() || !mul_ln1118_1640_fu_99032_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1640_fu_99032_p0.read()) * sc_bigint<5>(mul_ln1118_1640_fu_99032_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1641_fu_99053_p0() {
    mul_ln1118_1641_fu_99053_p0 =  (sc_lv<3>) (sext_ln1116_41_fu_80217_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1641_fu_99053_p1() {
    mul_ln1118_1641_fu_99053_p1 = tmp_1641_reg_111746.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1641_fu_99053_p2() {
    mul_ln1118_1641_fu_99053_p2 = (!mul_ln1118_1641_fu_99053_p0.read().is_01() || !mul_ln1118_1641_fu_99053_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1641_fu_99053_p0.read()) * sc_bigint<5>(mul_ln1118_1641_fu_99053_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1642_fu_99074_p0() {
    mul_ln1118_1642_fu_99074_p0 =  (sc_lv<3>) (sext_ln1116_42_fu_80241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1642_fu_99074_p1() {
    mul_ln1118_1642_fu_99074_p1 = tmp_1642_reg_111751.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1642_fu_99074_p2() {
    mul_ln1118_1642_fu_99074_p2 = (!mul_ln1118_1642_fu_99074_p0.read().is_01() || !mul_ln1118_1642_fu_99074_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1642_fu_99074_p0.read()) * sc_bigint<5>(mul_ln1118_1642_fu_99074_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1643_fu_99095_p0() {
    mul_ln1118_1643_fu_99095_p0 =  (sc_lv<3>) (sext_ln1116_43_fu_80265_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1643_fu_99095_p1() {
    mul_ln1118_1643_fu_99095_p1 = tmp_1643_reg_111756.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1643_fu_99095_p2() {
    mul_ln1118_1643_fu_99095_p2 = (!mul_ln1118_1643_fu_99095_p0.read().is_01() || !mul_ln1118_1643_fu_99095_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1643_fu_99095_p0.read()) * sc_bigint<5>(mul_ln1118_1643_fu_99095_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1644_fu_99116_p0() {
    mul_ln1118_1644_fu_99116_p0 =  (sc_lv<3>) (sext_ln1116_44_fu_80289_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1644_fu_99116_p1() {
    mul_ln1118_1644_fu_99116_p1 = tmp_1644_reg_111761.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1644_fu_99116_p2() {
    mul_ln1118_1644_fu_99116_p2 = (!mul_ln1118_1644_fu_99116_p0.read().is_01() || !mul_ln1118_1644_fu_99116_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1644_fu_99116_p0.read()) * sc_bigint<5>(mul_ln1118_1644_fu_99116_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1645_fu_99137_p0() {
    mul_ln1118_1645_fu_99137_p0 =  (sc_lv<3>) (sext_ln1116_45_fu_80313_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1645_fu_99137_p1() {
    mul_ln1118_1645_fu_99137_p1 = tmp_1645_reg_111766.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1645_fu_99137_p2() {
    mul_ln1118_1645_fu_99137_p2 = (!mul_ln1118_1645_fu_99137_p0.read().is_01() || !mul_ln1118_1645_fu_99137_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1645_fu_99137_p0.read()) * sc_bigint<5>(mul_ln1118_1645_fu_99137_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1646_fu_99158_p0() {
    mul_ln1118_1646_fu_99158_p0 =  (sc_lv<3>) (sext_ln1116_46_reg_106103.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1646_fu_99158_p1() {
    mul_ln1118_1646_fu_99158_p1 = tmp_1646_reg_111771.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1646_fu_99158_p2() {
    mul_ln1118_1646_fu_99158_p2 = (!mul_ln1118_1646_fu_99158_p0.read().is_01() || !mul_ln1118_1646_fu_99158_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1646_fu_99158_p0.read()) * sc_bigint<5>(mul_ln1118_1646_fu_99158_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1647_fu_69627_p0() {
    mul_ln1118_1647_fu_69627_p0 =  (sc_lv<3>) (sext_ln1116_47_fu_23151_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1647_fu_69627_p1() {
    mul_ln1118_1647_fu_69627_p1 = tmp_1647_fu_69613_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1647_fu_69627_p2() {
    mul_ln1118_1647_fu_69627_p2 = (!mul_ln1118_1647_fu_69627_p0.read().is_01() || !mul_ln1118_1647_fu_69627_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1647_fu_69627_p0.read()) * sc_bigint<5>(mul_ln1118_1647_fu_69627_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1648_fu_69659_p0() {
    mul_ln1118_1648_fu_69659_p0 =  (sc_lv<3>) (sext_ln1116_48_fu_23195_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1648_fu_69659_p1() {
    mul_ln1118_1648_fu_69659_p1 = tmp_1648_fu_69645_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1648_fu_69659_p2() {
    mul_ln1118_1648_fu_69659_p2 = (!mul_ln1118_1648_fu_69659_p0.read().is_01() || !mul_ln1118_1648_fu_69659_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1648_fu_69659_p0.read()) * sc_bigint<5>(mul_ln1118_1648_fu_69659_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1649_fu_99178_p0() {
    mul_ln1118_1649_fu_99178_p0 =  (sc_lv<3>) (sext_ln1116_49_reg_106121.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1649_fu_99178_p1() {
    mul_ln1118_1649_fu_99178_p1 = tmp_1649_reg_111776.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1649_fu_99178_p2() {
    mul_ln1118_1649_fu_99178_p2 = (!mul_ln1118_1649_fu_99178_p0.read().is_01() || !mul_ln1118_1649_fu_99178_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1649_fu_99178_p0.read()) * sc_bigint<5>(mul_ln1118_1649_fu_99178_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_164_fu_27615_p0() {
    mul_ln1118_164_fu_27615_p0 =  (sc_lv<3>) (sext_ln1116_164_fu_27607_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_164_fu_27615_p1() {
    mul_ln1118_164_fu_27615_p1 = tmp_164_fu_27597_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_164_fu_27615_p2() {
    mul_ln1118_164_fu_27615_p2 = (!mul_ln1118_164_fu_27615_p0.read().is_01() || !mul_ln1118_164_fu_27615_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_164_fu_27615_p0.read()) * sc_bigint<5>(mul_ln1118_164_fu_27615_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1650_fu_69701_p0() {
    mul_ln1118_1650_fu_69701_p0 =  (sc_lv<3>) (sext_ln1116_50_fu_23261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1650_fu_69701_p1() {
    mul_ln1118_1650_fu_69701_p1 = tmp_1650_fu_69687_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1650_fu_69701_p2() {
    mul_ln1118_1650_fu_69701_p2 = (!mul_ln1118_1650_fu_69701_p0.read().is_01() || !mul_ln1118_1650_fu_69701_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1650_fu_69701_p0.read()) * sc_bigint<5>(mul_ln1118_1650_fu_69701_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1651_fu_69733_p0() {
    mul_ln1118_1651_fu_69733_p0 =  (sc_lv<3>) (sext_ln1116_51_fu_23305_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1651_fu_69733_p1() {
    mul_ln1118_1651_fu_69733_p1 = tmp_1651_fu_69719_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1651_fu_69733_p2() {
    mul_ln1118_1651_fu_69733_p2 = (!mul_ln1118_1651_fu_69733_p0.read().is_01() || !mul_ln1118_1651_fu_69733_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1651_fu_69733_p0.read()) * sc_bigint<5>(mul_ln1118_1651_fu_69733_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1652_fu_99198_p0() {
    mul_ln1118_1652_fu_99198_p0 =  (sc_lv<3>) (sext_ln1116_52_fu_80377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1652_fu_99198_p1() {
    mul_ln1118_1652_fu_99198_p1 = tmp_1652_reg_111781.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1652_fu_99198_p2() {
    mul_ln1118_1652_fu_99198_p2 = (!mul_ln1118_1652_fu_99198_p0.read().is_01() || !mul_ln1118_1652_fu_99198_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1652_fu_99198_p0.read()) * sc_bigint<5>(mul_ln1118_1652_fu_99198_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1653_fu_69775_p0() {
    mul_ln1118_1653_fu_69775_p0 =  (sc_lv<3>) (sext_ln1116_53_fu_23367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1653_fu_69775_p1() {
    mul_ln1118_1653_fu_69775_p1 = tmp_1653_fu_69761_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1653_fu_69775_p2() {
    mul_ln1118_1653_fu_69775_p2 = (!mul_ln1118_1653_fu_69775_p0.read().is_01() || !mul_ln1118_1653_fu_69775_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1653_fu_69775_p0.read()) * sc_bigint<5>(mul_ln1118_1653_fu_69775_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1654_fu_69807_p0() {
    mul_ln1118_1654_fu_69807_p0 =  (sc_lv<3>) (sext_ln1116_54_fu_23411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1654_fu_69807_p1() {
    mul_ln1118_1654_fu_69807_p1 = tmp_1654_fu_69793_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1654_fu_69807_p2() {
    mul_ln1118_1654_fu_69807_p2 = (!mul_ln1118_1654_fu_69807_p0.read().is_01() || !mul_ln1118_1654_fu_69807_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1654_fu_69807_p0.read()) * sc_bigint<5>(mul_ln1118_1654_fu_69807_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1655_fu_69839_p0() {
    mul_ln1118_1655_fu_69839_p0 =  (sc_lv<3>) (sext_ln1116_55_fu_23455_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1655_fu_69839_p1() {
    mul_ln1118_1655_fu_69839_p1 = tmp_1655_fu_69825_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1655_fu_69839_p2() {
    mul_ln1118_1655_fu_69839_p2 = (!mul_ln1118_1655_fu_69839_p0.read().is_01() || !mul_ln1118_1655_fu_69839_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1655_fu_69839_p0.read()) * sc_bigint<5>(mul_ln1118_1655_fu_69839_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1656_fu_69871_p0() {
    mul_ln1118_1656_fu_69871_p0 =  (sc_lv<3>) (sext_ln1116_56_fu_23499_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1656_fu_69871_p1() {
    mul_ln1118_1656_fu_69871_p1 = tmp_1656_fu_69857_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1656_fu_69871_p2() {
    mul_ln1118_1656_fu_69871_p2 = (!mul_ln1118_1656_fu_69871_p0.read().is_01() || !mul_ln1118_1656_fu_69871_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1656_fu_69871_p0.read()) * sc_bigint<5>(mul_ln1118_1656_fu_69871_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1657_fu_69903_p0() {
    mul_ln1118_1657_fu_69903_p0 =  (sc_lv<3>) (sext_ln1116_57_fu_23543_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1657_fu_69903_p1() {
    mul_ln1118_1657_fu_69903_p1 = tmp_1657_fu_69889_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1657_fu_69903_p2() {
    mul_ln1118_1657_fu_69903_p2 = (!mul_ln1118_1657_fu_69903_p0.read().is_01() || !mul_ln1118_1657_fu_69903_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1657_fu_69903_p0.read()) * sc_bigint<5>(mul_ln1118_1657_fu_69903_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1658_fu_69935_p0() {
    mul_ln1118_1658_fu_69935_p0 =  (sc_lv<3>) (sext_ln1116_58_fu_23587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1658_fu_69935_p1() {
    mul_ln1118_1658_fu_69935_p1 = tmp_1658_fu_69921_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1658_fu_69935_p2() {
    mul_ln1118_1658_fu_69935_p2 = (!mul_ln1118_1658_fu_69935_p0.read().is_01() || !mul_ln1118_1658_fu_69935_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1658_fu_69935_p0.read()) * sc_bigint<5>(mul_ln1118_1658_fu_69935_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1659_fu_69967_p0() {
    mul_ln1118_1659_fu_69967_p0 =  (sc_lv<3>) (sext_ln1116_59_fu_23631_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1659_fu_69967_p1() {
    mul_ln1118_1659_fu_69967_p1 = tmp_1659_fu_69953_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1659_fu_69967_p2() {
    mul_ln1118_1659_fu_69967_p2 = (!mul_ln1118_1659_fu_69967_p0.read().is_01() || !mul_ln1118_1659_fu_69967_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1659_fu_69967_p0.read()) * sc_bigint<5>(mul_ln1118_1659_fu_69967_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_165_fu_80992_p0() {
    mul_ln1118_165_fu_80992_p0 =  (sc_lv<3>) (sext_ln1116_165_reg_106581.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_165_fu_80992_p1() {
    mul_ln1118_165_fu_80992_p1 = tmp_165_reg_106576.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_165_fu_80992_p2() {
    mul_ln1118_165_fu_80992_p2 = (!mul_ln1118_165_fu_80992_p0.read().is_01() || !mul_ln1118_165_fu_80992_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_165_fu_80992_p0.read()) * sc_bigint<5>(mul_ln1118_165_fu_80992_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1660_fu_69987_p0() {
    mul_ln1118_1660_fu_69987_p0 =  (sc_lv<3>) (sext_ln1116_60_fu_23663_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1660_fu_69987_p1() {
    mul_ln1118_1660_fu_69987_p1 = tmp_1660_fu_69973_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1660_fu_69987_p2() {
    mul_ln1118_1660_fu_69987_p2 = (!mul_ln1118_1660_fu_69987_p0.read().is_01() || !mul_ln1118_1660_fu_69987_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1660_fu_69987_p0.read()) * sc_bigint<5>(mul_ln1118_1660_fu_69987_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1661_fu_70019_p0() {
    mul_ln1118_1661_fu_70019_p0 =  (sc_lv<3>) (sext_ln1116_61_fu_23707_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1661_fu_70019_p1() {
    mul_ln1118_1661_fu_70019_p1 = tmp_1661_fu_70005_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1661_fu_70019_p2() {
    mul_ln1118_1661_fu_70019_p2 = (!mul_ln1118_1661_fu_70019_p0.read().is_01() || !mul_ln1118_1661_fu_70019_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1661_fu_70019_p0.read()) * sc_bigint<5>(mul_ln1118_1661_fu_70019_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1662_fu_70051_p0() {
    mul_ln1118_1662_fu_70051_p0 =  (sc_lv<3>) (sext_ln1116_62_fu_23751_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1662_fu_70051_p1() {
    mul_ln1118_1662_fu_70051_p1 = tmp_1662_fu_70037_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1662_fu_70051_p2() {
    mul_ln1118_1662_fu_70051_p2 = (!mul_ln1118_1662_fu_70051_p0.read().is_01() || !mul_ln1118_1662_fu_70051_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1662_fu_70051_p0.read()) * sc_bigint<5>(mul_ln1118_1662_fu_70051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1663_fu_70071_p0() {
    mul_ln1118_1663_fu_70071_p0 =  (sc_lv<3>) (sext_ln1116_63_fu_23783_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1663_fu_70071_p1() {
    mul_ln1118_1663_fu_70071_p1 = tmp_1663_fu_70057_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1663_fu_70071_p2() {
    mul_ln1118_1663_fu_70071_p2 = (!mul_ln1118_1663_fu_70071_p0.read().is_01() || !mul_ln1118_1663_fu_70071_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1663_fu_70071_p0.read()) * sc_bigint<5>(mul_ln1118_1663_fu_70071_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1664_fu_70103_p0() {
    mul_ln1118_1664_fu_70103_p0 =  (sc_lv<3>) (sext_ln1116_64_fu_23827_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1664_fu_70103_p1() {
    mul_ln1118_1664_fu_70103_p1 = tmp_1664_fu_70089_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1664_fu_70103_p2() {
    mul_ln1118_1664_fu_70103_p2 = (!mul_ln1118_1664_fu_70103_p0.read().is_01() || !mul_ln1118_1664_fu_70103_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1664_fu_70103_p0.read()) * sc_bigint<5>(mul_ln1118_1664_fu_70103_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1665_fu_99241_p0() {
    mul_ln1118_1665_fu_99241_p0 =  (sc_lv<3>) (sext_ln1116_65_reg_106159.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1665_fu_99241_p1() {
    mul_ln1118_1665_fu_99241_p1 = tmp_1665_reg_111796.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1665_fu_99241_p2() {
    mul_ln1118_1665_fu_99241_p2 = (!mul_ln1118_1665_fu_99241_p0.read().is_01() || !mul_ln1118_1665_fu_99241_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1665_fu_99241_p0.read()) * sc_bigint<5>(mul_ln1118_1665_fu_99241_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1666_fu_70145_p0() {
    mul_ln1118_1666_fu_70145_p0 =  (sc_lv<3>) (sext_ln1116_66_fu_23893_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1666_fu_70145_p1() {
    mul_ln1118_1666_fu_70145_p1 = tmp_1666_fu_70131_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1666_fu_70145_p2() {
    mul_ln1118_1666_fu_70145_p2 = (!mul_ln1118_1666_fu_70145_p0.read().is_01() || !mul_ln1118_1666_fu_70145_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1666_fu_70145_p0.read()) * sc_bigint<5>(mul_ln1118_1666_fu_70145_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1667_fu_70177_p0() {
    mul_ln1118_1667_fu_70177_p0 =  (sc_lv<3>) (sext_ln1116_67_fu_23937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1667_fu_70177_p1() {
    mul_ln1118_1667_fu_70177_p1 = tmp_1667_fu_70163_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1667_fu_70177_p2() {
    mul_ln1118_1667_fu_70177_p2 = (!mul_ln1118_1667_fu_70177_p0.read().is_01() || !mul_ln1118_1667_fu_70177_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1667_fu_70177_p0.read()) * sc_bigint<5>(mul_ln1118_1667_fu_70177_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1668_fu_99261_p0() {
    mul_ln1118_1668_fu_99261_p0 =  (sc_lv<3>) (sext_ln1116_68_reg_106177.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1668_fu_99261_p1() {
    mul_ln1118_1668_fu_99261_p1 = tmp_1668_reg_111801.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1668_fu_99261_p2() {
    mul_ln1118_1668_fu_99261_p2 = (!mul_ln1118_1668_fu_99261_p0.read().is_01() || !mul_ln1118_1668_fu_99261_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1668_fu_99261_p0.read()) * sc_bigint<5>(mul_ln1118_1668_fu_99261_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1669_fu_70219_p0() {
    mul_ln1118_1669_fu_70219_p0 =  (sc_lv<3>) (sext_ln1116_69_fu_24003_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1669_fu_70219_p1() {
    mul_ln1118_1669_fu_70219_p1 = tmp_1669_fu_70205_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1669_fu_70219_p2() {
    mul_ln1118_1669_fu_70219_p2 = (!mul_ln1118_1669_fu_70219_p0.read().is_01() || !mul_ln1118_1669_fu_70219_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1669_fu_70219_p0.read()) * sc_bigint<5>(mul_ln1118_1669_fu_70219_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_166_fu_27681_p0() {
    mul_ln1118_166_fu_27681_p0 =  (sc_lv<3>) (sext_ln1116_166_fu_27673_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_166_fu_27681_p1() {
    mul_ln1118_166_fu_27681_p1 = tmp_166_fu_27663_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_166_fu_27681_p2() {
    mul_ln1118_166_fu_27681_p2 = (!mul_ln1118_166_fu_27681_p0.read().is_01() || !mul_ln1118_166_fu_27681_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_166_fu_27681_p0.read()) * sc_bigint<5>(mul_ln1118_166_fu_27681_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1670_fu_70251_p0() {
    mul_ln1118_1670_fu_70251_p0 =  (sc_lv<3>) (sext_ln1116_70_fu_24047_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1670_fu_70251_p1() {
    mul_ln1118_1670_fu_70251_p1 = tmp_1670_fu_70237_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1670_fu_70251_p2() {
    mul_ln1118_1670_fu_70251_p2 = (!mul_ln1118_1670_fu_70251_p0.read().is_01() || !mul_ln1118_1670_fu_70251_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1670_fu_70251_p0.read()) * sc_bigint<5>(mul_ln1118_1670_fu_70251_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1671_fu_99281_p0() {
    mul_ln1118_1671_fu_99281_p0 =  (sc_lv<3>) (sext_ln1116_71_reg_106195.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1671_fu_99281_p1() {
    mul_ln1118_1671_fu_99281_p1 = tmp_1671_reg_111806.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1671_fu_99281_p2() {
    mul_ln1118_1671_fu_99281_p2 = (!mul_ln1118_1671_fu_99281_p0.read().is_01() || !mul_ln1118_1671_fu_99281_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1671_fu_99281_p0.read()) * sc_bigint<5>(mul_ln1118_1671_fu_99281_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1672_fu_70293_p0() {
    mul_ln1118_1672_fu_70293_p0 =  (sc_lv<3>) (sext_ln1116_72_fu_24113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1672_fu_70293_p1() {
    mul_ln1118_1672_fu_70293_p1 = tmp_1672_fu_70279_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1672_fu_70293_p2() {
    mul_ln1118_1672_fu_70293_p2 = (!mul_ln1118_1672_fu_70293_p0.read().is_01() || !mul_ln1118_1672_fu_70293_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1672_fu_70293_p0.read()) * sc_bigint<5>(mul_ln1118_1672_fu_70293_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1673_fu_70325_p0() {
    mul_ln1118_1673_fu_70325_p0 =  (sc_lv<3>) (sext_ln1116_73_fu_24157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1673_fu_70325_p1() {
    mul_ln1118_1673_fu_70325_p1 = tmp_1673_fu_70311_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1673_fu_70325_p2() {
    mul_ln1118_1673_fu_70325_p2 = (!mul_ln1118_1673_fu_70325_p0.read().is_01() || !mul_ln1118_1673_fu_70325_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1673_fu_70325_p0.read()) * sc_bigint<5>(mul_ln1118_1673_fu_70325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1674_fu_99301_p0() {
    mul_ln1118_1674_fu_99301_p0 =  (sc_lv<3>) (sext_ln1116_74_reg_106213.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1674_fu_99301_p1() {
    mul_ln1118_1674_fu_99301_p1 = tmp_1674_reg_111811.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1674_fu_99301_p2() {
    mul_ln1118_1674_fu_99301_p2 = (!mul_ln1118_1674_fu_99301_p0.read().is_01() || !mul_ln1118_1674_fu_99301_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1674_fu_99301_p0.read()) * sc_bigint<5>(mul_ln1118_1674_fu_99301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1675_fu_70367_p0() {
    mul_ln1118_1675_fu_70367_p0 =  (sc_lv<3>) (sext_ln1116_75_fu_24223_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1675_fu_70367_p1() {
    mul_ln1118_1675_fu_70367_p1 = tmp_1675_fu_70353_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1675_fu_70367_p2() {
    mul_ln1118_1675_fu_70367_p2 = (!mul_ln1118_1675_fu_70367_p0.read().is_01() || !mul_ln1118_1675_fu_70367_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1675_fu_70367_p0.read()) * sc_bigint<5>(mul_ln1118_1675_fu_70367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1676_fu_70399_p0() {
    mul_ln1118_1676_fu_70399_p0 =  (sc_lv<3>) (sext_ln1116_76_fu_24267_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1676_fu_70399_p1() {
    mul_ln1118_1676_fu_70399_p1 = tmp_1676_fu_70385_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1676_fu_70399_p2() {
    mul_ln1118_1676_fu_70399_p2 = (!mul_ln1118_1676_fu_70399_p0.read().is_01() || !mul_ln1118_1676_fu_70399_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1676_fu_70399_p0.read()) * sc_bigint<5>(mul_ln1118_1676_fu_70399_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1677_fu_99321_p0() {
    mul_ln1118_1677_fu_99321_p0 =  (sc_lv<3>) (sext_ln1116_77_reg_106231.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1677_fu_99321_p1() {
    mul_ln1118_1677_fu_99321_p1 = tmp_1677_reg_111816.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1677_fu_99321_p2() {
    mul_ln1118_1677_fu_99321_p2 = (!mul_ln1118_1677_fu_99321_p0.read().is_01() || !mul_ln1118_1677_fu_99321_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1677_fu_99321_p0.read()) * sc_bigint<5>(mul_ln1118_1677_fu_99321_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1678_fu_70441_p0() {
    mul_ln1118_1678_fu_70441_p0 =  (sc_lv<3>) (sext_ln1116_78_fu_24333_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1678_fu_70441_p1() {
    mul_ln1118_1678_fu_70441_p1 = tmp_1678_fu_70427_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1678_fu_70441_p2() {
    mul_ln1118_1678_fu_70441_p2 = (!mul_ln1118_1678_fu_70441_p0.read().is_01() || !mul_ln1118_1678_fu_70441_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1678_fu_70441_p0.read()) * sc_bigint<5>(mul_ln1118_1678_fu_70441_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1679_fu_70473_p0() {
    mul_ln1118_1679_fu_70473_p0 =  (sc_lv<3>) (sext_ln1116_79_fu_24377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1679_fu_70473_p1() {
    mul_ln1118_1679_fu_70473_p1 = tmp_1679_fu_70459_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1679_fu_70473_p2() {
    mul_ln1118_1679_fu_70473_p2 = (!mul_ln1118_1679_fu_70473_p0.read().is_01() || !mul_ln1118_1679_fu_70473_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1679_fu_70473_p0.read()) * sc_bigint<5>(mul_ln1118_1679_fu_70473_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_167_fu_27725_p0() {
    mul_ln1118_167_fu_27725_p0 =  (sc_lv<3>) (sext_ln1116_167_fu_27717_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_167_fu_27725_p1() {
    mul_ln1118_167_fu_27725_p1 = tmp_167_fu_27707_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_167_fu_27725_p2() {
    mul_ln1118_167_fu_27725_p2 = (!mul_ln1118_167_fu_27725_p0.read().is_01() || !mul_ln1118_167_fu_27725_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_167_fu_27725_p0.read()) * sc_bigint<5>(mul_ln1118_167_fu_27725_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1680_fu_70505_p0() {
    mul_ln1118_1680_fu_70505_p0 =  (sc_lv<3>) (sext_ln1116_80_fu_24421_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1680_fu_70505_p1() {
    mul_ln1118_1680_fu_70505_p1 = tmp_1680_fu_70491_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1680_fu_70505_p2() {
    mul_ln1118_1680_fu_70505_p2 = (!mul_ln1118_1680_fu_70505_p0.read().is_01() || !mul_ln1118_1680_fu_70505_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1680_fu_70505_p0.read()) * sc_bigint<5>(mul_ln1118_1680_fu_70505_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1681_fu_70537_p0() {
    mul_ln1118_1681_fu_70537_p0 =  (sc_lv<3>) (sext_ln1116_81_fu_24465_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1681_fu_70537_p1() {
    mul_ln1118_1681_fu_70537_p1 = tmp_1681_fu_70523_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1681_fu_70537_p2() {
    mul_ln1118_1681_fu_70537_p2 = (!mul_ln1118_1681_fu_70537_p0.read().is_01() || !mul_ln1118_1681_fu_70537_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1681_fu_70537_p0.read()) * sc_bigint<5>(mul_ln1118_1681_fu_70537_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1682_fu_70569_p0() {
    mul_ln1118_1682_fu_70569_p0 =  (sc_lv<3>) (sext_ln1116_82_fu_24509_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1682_fu_70569_p1() {
    mul_ln1118_1682_fu_70569_p1 = tmp_1682_fu_70555_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1682_fu_70569_p2() {
    mul_ln1118_1682_fu_70569_p2 = (!mul_ln1118_1682_fu_70569_p0.read().is_01() || !mul_ln1118_1682_fu_70569_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1682_fu_70569_p0.read()) * sc_bigint<5>(mul_ln1118_1682_fu_70569_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1683_fu_70601_p0() {
    mul_ln1118_1683_fu_70601_p0 =  (sc_lv<3>) (sext_ln1116_83_fu_24553_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1683_fu_70601_p1() {
    mul_ln1118_1683_fu_70601_p1 = tmp_1683_fu_70587_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1683_fu_70601_p2() {
    mul_ln1118_1683_fu_70601_p2 = (!mul_ln1118_1683_fu_70601_p0.read().is_01() || !mul_ln1118_1683_fu_70601_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1683_fu_70601_p0.read()) * sc_bigint<5>(mul_ln1118_1683_fu_70601_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1684_fu_70633_p0() {
    mul_ln1118_1684_fu_70633_p0 =  (sc_lv<3>) (sext_ln1116_84_fu_24597_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1684_fu_70633_p1() {
    mul_ln1118_1684_fu_70633_p1 = tmp_1684_fu_70619_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1684_fu_70633_p2() {
    mul_ln1118_1684_fu_70633_p2 = (!mul_ln1118_1684_fu_70633_p0.read().is_01() || !mul_ln1118_1684_fu_70633_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1684_fu_70633_p0.read()) * sc_bigint<5>(mul_ln1118_1684_fu_70633_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1685_fu_70653_p0() {
    mul_ln1118_1685_fu_70653_p0 =  (sc_lv<3>) (sext_ln1116_85_fu_24629_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1685_fu_70653_p1() {
    mul_ln1118_1685_fu_70653_p1 = tmp_1685_fu_70639_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1685_fu_70653_p2() {
    mul_ln1118_1685_fu_70653_p2 = (!mul_ln1118_1685_fu_70653_p0.read().is_01() || !mul_ln1118_1685_fu_70653_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1685_fu_70653_p0.read()) * sc_bigint<5>(mul_ln1118_1685_fu_70653_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1686_fu_70685_p0() {
    mul_ln1118_1686_fu_70685_p0 =  (sc_lv<3>) (sext_ln1116_86_fu_24673_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1686_fu_70685_p1() {
    mul_ln1118_1686_fu_70685_p1 = tmp_1686_fu_70671_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1686_fu_70685_p2() {
    mul_ln1118_1686_fu_70685_p2 = (!mul_ln1118_1686_fu_70685_p0.read().is_01() || !mul_ln1118_1686_fu_70685_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1686_fu_70685_p0.read()) * sc_bigint<5>(mul_ln1118_1686_fu_70685_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1687_fu_70717_p0() {
    mul_ln1118_1687_fu_70717_p0 =  (sc_lv<3>) (sext_ln1116_87_fu_24717_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1687_fu_70717_p1() {
    mul_ln1118_1687_fu_70717_p1 = tmp_1687_fu_70703_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1687_fu_70717_p2() {
    mul_ln1118_1687_fu_70717_p2 = (!mul_ln1118_1687_fu_70717_p0.read().is_01() || !mul_ln1118_1687_fu_70717_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1687_fu_70717_p0.read()) * sc_bigint<5>(mul_ln1118_1687_fu_70717_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1688_fu_70737_p0() {
    mul_ln1118_1688_fu_70737_p0 =  (sc_lv<3>) (sext_ln1116_88_fu_24749_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1688_fu_70737_p1() {
    mul_ln1118_1688_fu_70737_p1 = tmp_1688_fu_70723_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1688_fu_70737_p2() {
    mul_ln1118_1688_fu_70737_p2 = (!mul_ln1118_1688_fu_70737_p0.read().is_01() || !mul_ln1118_1688_fu_70737_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1688_fu_70737_p0.read()) * sc_bigint<5>(mul_ln1118_1688_fu_70737_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1689_fu_70769_p0() {
    mul_ln1118_1689_fu_70769_p0 =  (sc_lv<3>) (sext_ln1116_89_fu_24793_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1689_fu_70769_p1() {
    mul_ln1118_1689_fu_70769_p1 = tmp_1689_fu_70755_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1689_fu_70769_p2() {
    mul_ln1118_1689_fu_70769_p2 = (!mul_ln1118_1689_fu_70769_p0.read().is_01() || !mul_ln1118_1689_fu_70769_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1689_fu_70769_p0.read()) * sc_bigint<5>(mul_ln1118_1689_fu_70769_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_168_fu_81012_p0() {
    mul_ln1118_168_fu_81012_p0 =  (sc_lv<3>) (sext_ln1116_168_reg_106599.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_168_fu_81012_p1() {
    mul_ln1118_168_fu_81012_p1 = tmp_168_reg_106594.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_168_fu_81012_p2() {
    mul_ln1118_168_fu_81012_p2 = (!mul_ln1118_168_fu_81012_p0.read().is_01() || !mul_ln1118_168_fu_81012_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_168_fu_81012_p0.read()) * sc_bigint<5>(mul_ln1118_168_fu_81012_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1690_fu_99363_p0() {
    mul_ln1118_1690_fu_99363_p0 =  (sc_lv<3>) (sext_ln1116_90_reg_106259.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1690_fu_99363_p1() {
    mul_ln1118_1690_fu_99363_p1 = tmp_1690_reg_111831.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1690_fu_99363_p2() {
    mul_ln1118_1690_fu_99363_p2 = (!mul_ln1118_1690_fu_99363_p0.read().is_01() || !mul_ln1118_1690_fu_99363_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1690_fu_99363_p0.read()) * sc_bigint<5>(mul_ln1118_1690_fu_99363_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1691_fu_70811_p0() {
    mul_ln1118_1691_fu_70811_p0 =  (sc_lv<3>) (sext_ln1116_91_fu_24859_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1691_fu_70811_p1() {
    mul_ln1118_1691_fu_70811_p1 = tmp_1691_fu_70797_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1691_fu_70811_p2() {
    mul_ln1118_1691_fu_70811_p2 = (!mul_ln1118_1691_fu_70811_p0.read().is_01() || !mul_ln1118_1691_fu_70811_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1691_fu_70811_p0.read()) * sc_bigint<5>(mul_ln1118_1691_fu_70811_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1692_fu_70843_p0() {
    mul_ln1118_1692_fu_70843_p0 =  (sc_lv<3>) (sext_ln1116_92_fu_24903_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1692_fu_70843_p1() {
    mul_ln1118_1692_fu_70843_p1 = tmp_1692_fu_70829_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1692_fu_70843_p2() {
    mul_ln1118_1692_fu_70843_p2 = (!mul_ln1118_1692_fu_70843_p0.read().is_01() || !mul_ln1118_1692_fu_70843_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1692_fu_70843_p0.read()) * sc_bigint<5>(mul_ln1118_1692_fu_70843_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1693_fu_99383_p0() {
    mul_ln1118_1693_fu_99383_p0 =  (sc_lv<3>) (sext_ln1116_93_reg_106277.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1693_fu_99383_p1() {
    mul_ln1118_1693_fu_99383_p1 = tmp_1693_reg_111836.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1693_fu_99383_p2() {
    mul_ln1118_1693_fu_99383_p2 = (!mul_ln1118_1693_fu_99383_p0.read().is_01() || !mul_ln1118_1693_fu_99383_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1693_fu_99383_p0.read()) * sc_bigint<5>(mul_ln1118_1693_fu_99383_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1694_fu_70885_p0() {
    mul_ln1118_1694_fu_70885_p0 =  (sc_lv<3>) (sext_ln1116_94_fu_24969_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1694_fu_70885_p1() {
    mul_ln1118_1694_fu_70885_p1 = tmp_1694_fu_70871_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1694_fu_70885_p2() {
    mul_ln1118_1694_fu_70885_p2 = (!mul_ln1118_1694_fu_70885_p0.read().is_01() || !mul_ln1118_1694_fu_70885_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1694_fu_70885_p0.read()) * sc_bigint<5>(mul_ln1118_1694_fu_70885_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1695_fu_70917_p0() {
    mul_ln1118_1695_fu_70917_p0 =  (sc_lv<3>) (sext_ln1116_95_fu_25013_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1695_fu_70917_p1() {
    mul_ln1118_1695_fu_70917_p1 = tmp_1695_fu_70903_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1695_fu_70917_p2() {
    mul_ln1118_1695_fu_70917_p2 = (!mul_ln1118_1695_fu_70917_p0.read().is_01() || !mul_ln1118_1695_fu_70917_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1695_fu_70917_p0.read()) * sc_bigint<5>(mul_ln1118_1695_fu_70917_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1696_fu_99403_p0() {
    mul_ln1118_1696_fu_99403_p0 =  (sc_lv<3>) (sext_ln1116_96_reg_106295.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1696_fu_99403_p1() {
    mul_ln1118_1696_fu_99403_p1 = tmp_1696_reg_111841.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1696_fu_99403_p2() {
    mul_ln1118_1696_fu_99403_p2 = (!mul_ln1118_1696_fu_99403_p0.read().is_01() || !mul_ln1118_1696_fu_99403_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1696_fu_99403_p0.read()) * sc_bigint<5>(mul_ln1118_1696_fu_99403_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1697_fu_70959_p0() {
    mul_ln1118_1697_fu_70959_p0 =  (sc_lv<3>) (sext_ln1116_97_fu_25079_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1697_fu_70959_p1() {
    mul_ln1118_1697_fu_70959_p1 = tmp_1697_fu_70945_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1697_fu_70959_p2() {
    mul_ln1118_1697_fu_70959_p2 = (!mul_ln1118_1697_fu_70959_p0.read().is_01() || !mul_ln1118_1697_fu_70959_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1697_fu_70959_p0.read()) * sc_bigint<5>(mul_ln1118_1697_fu_70959_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1698_fu_70991_p0() {
    mul_ln1118_1698_fu_70991_p0 =  (sc_lv<3>) (sext_ln1116_98_fu_25123_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1698_fu_70991_p1() {
    mul_ln1118_1698_fu_70991_p1 = tmp_1698_fu_70977_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1698_fu_70991_p2() {
    mul_ln1118_1698_fu_70991_p2 = (!mul_ln1118_1698_fu_70991_p0.read().is_01() || !mul_ln1118_1698_fu_70991_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1698_fu_70991_p0.read()) * sc_bigint<5>(mul_ln1118_1698_fu_70991_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1699_fu_99423_p0() {
    mul_ln1118_1699_fu_99423_p0 =  (sc_lv<3>) (sext_ln1116_99_reg_106313.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1699_fu_99423_p1() {
    mul_ln1118_1699_fu_99423_p1 = tmp_1699_reg_111846.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1699_fu_99423_p2() {
    mul_ln1118_1699_fu_99423_p2 = (!mul_ln1118_1699_fu_99423_p0.read().is_01() || !mul_ln1118_1699_fu_99423_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1699_fu_99423_p0.read()) * sc_bigint<5>(mul_ln1118_1699_fu_99423_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_169_fu_27791_p0() {
    mul_ln1118_169_fu_27791_p0 =  (sc_lv<3>) (sext_ln1116_169_fu_27783_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_169_fu_27791_p1() {
    mul_ln1118_169_fu_27791_p1 = tmp_169_fu_27773_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_169_fu_27791_p2() {
    mul_ln1118_169_fu_27791_p2 = (!mul_ln1118_169_fu_27791_p0.read().is_01() || !mul_ln1118_169_fu_27791_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_169_fu_27791_p0.read()) * sc_bigint<5>(mul_ln1118_169_fu_27791_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_16_fu_22121_p0() {
    mul_ln1118_16_fu_22121_p0 =  (sc_lv<3>) (sext_ln1116_16_fu_22113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_16_fu_22121_p1() {
    mul_ln1118_16_fu_22121_p1 = tmp_17_fu_22103_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_16_fu_22121_p2() {
    mul_ln1118_16_fu_22121_p2 = (!mul_ln1118_16_fu_22121_p0.read().is_01() || !mul_ln1118_16_fu_22121_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_16_fu_22121_p0.read()) * sc_bigint<5>(mul_ln1118_16_fu_22121_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1700_fu_71033_p0() {
    mul_ln1118_1700_fu_71033_p0 =  (sc_lv<3>) (sext_ln1116_100_fu_25189_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1700_fu_71033_p1() {
    mul_ln1118_1700_fu_71033_p1 = tmp_1700_fu_71019_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1700_fu_71033_p2() {
    mul_ln1118_1700_fu_71033_p2 = (!mul_ln1118_1700_fu_71033_p0.read().is_01() || !mul_ln1118_1700_fu_71033_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1700_fu_71033_p0.read()) * sc_bigint<5>(mul_ln1118_1700_fu_71033_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1701_fu_71065_p0() {
    mul_ln1118_1701_fu_71065_p0 =  (sc_lv<3>) (sext_ln1116_101_fu_25233_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1701_fu_71065_p1() {
    mul_ln1118_1701_fu_71065_p1 = tmp_1701_fu_71051_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1701_fu_71065_p2() {
    mul_ln1118_1701_fu_71065_p2 = (!mul_ln1118_1701_fu_71065_p0.read().is_01() || !mul_ln1118_1701_fu_71065_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1701_fu_71065_p0.read()) * sc_bigint<5>(mul_ln1118_1701_fu_71065_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1702_fu_99443_p0() {
    mul_ln1118_1702_fu_99443_p0 =  (sc_lv<3>) (sext_ln1116_102_reg_106331.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1702_fu_99443_p1() {
    mul_ln1118_1702_fu_99443_p1 = tmp_1702_reg_111851.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1702_fu_99443_p2() {
    mul_ln1118_1702_fu_99443_p2 = (!mul_ln1118_1702_fu_99443_p0.read().is_01() || !mul_ln1118_1702_fu_99443_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1702_fu_99443_p0.read()) * sc_bigint<5>(mul_ln1118_1702_fu_99443_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1703_fu_71107_p0() {
    mul_ln1118_1703_fu_71107_p0 =  (sc_lv<3>) (sext_ln1116_103_fu_25299_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1703_fu_71107_p1() {
    mul_ln1118_1703_fu_71107_p1 = tmp_1703_fu_71093_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1703_fu_71107_p2() {
    mul_ln1118_1703_fu_71107_p2 = (!mul_ln1118_1703_fu_71107_p0.read().is_01() || !mul_ln1118_1703_fu_71107_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1703_fu_71107_p0.read()) * sc_bigint<5>(mul_ln1118_1703_fu_71107_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1704_fu_71139_p0() {
    mul_ln1118_1704_fu_71139_p0 =  (sc_lv<3>) (sext_ln1116_104_fu_25343_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1704_fu_71139_p1() {
    mul_ln1118_1704_fu_71139_p1 = tmp_1704_fu_71125_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1704_fu_71139_p2() {
    mul_ln1118_1704_fu_71139_p2 = (!mul_ln1118_1704_fu_71139_p0.read().is_01() || !mul_ln1118_1704_fu_71139_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1704_fu_71139_p0.read()) * sc_bigint<5>(mul_ln1118_1704_fu_71139_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1705_fu_71171_p0() {
    mul_ln1118_1705_fu_71171_p0 =  (sc_lv<3>) (sext_ln1116_105_fu_25387_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1705_fu_71171_p1() {
    mul_ln1118_1705_fu_71171_p1 = tmp_1705_fu_71157_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1705_fu_71171_p2() {
    mul_ln1118_1705_fu_71171_p2 = (!mul_ln1118_1705_fu_71171_p0.read().is_01() || !mul_ln1118_1705_fu_71171_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1705_fu_71171_p0.read()) * sc_bigint<5>(mul_ln1118_1705_fu_71171_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1706_fu_71203_p0() {
    mul_ln1118_1706_fu_71203_p0 =  (sc_lv<3>) (sext_ln1116_106_fu_25431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1706_fu_71203_p1() {
    mul_ln1118_1706_fu_71203_p1 = tmp_1706_fu_71189_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1706_fu_71203_p2() {
    mul_ln1118_1706_fu_71203_p2 = (!mul_ln1118_1706_fu_71203_p0.read().is_01() || !mul_ln1118_1706_fu_71203_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1706_fu_71203_p0.read()) * sc_bigint<5>(mul_ln1118_1706_fu_71203_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1707_fu_71235_p0() {
    mul_ln1118_1707_fu_71235_p0 =  (sc_lv<3>) (sext_ln1116_107_fu_25475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1707_fu_71235_p1() {
    mul_ln1118_1707_fu_71235_p1 = tmp_1707_fu_71221_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1707_fu_71235_p2() {
    mul_ln1118_1707_fu_71235_p2 = (!mul_ln1118_1707_fu_71235_p0.read().is_01() || !mul_ln1118_1707_fu_71235_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1707_fu_71235_p0.read()) * sc_bigint<5>(mul_ln1118_1707_fu_71235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1708_fu_71267_p0() {
    mul_ln1118_1708_fu_71267_p0 =  (sc_lv<3>) (sext_ln1116_108_fu_25519_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1708_fu_71267_p1() {
    mul_ln1118_1708_fu_71267_p1 = tmp_1708_fu_71253_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1708_fu_71267_p2() {
    mul_ln1118_1708_fu_71267_p2 = (!mul_ln1118_1708_fu_71267_p0.read().is_01() || !mul_ln1118_1708_fu_71267_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1708_fu_71267_p0.read()) * sc_bigint<5>(mul_ln1118_1708_fu_71267_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1709_fu_71299_p0() {
    mul_ln1118_1709_fu_71299_p0 =  (sc_lv<3>) (sext_ln1116_109_fu_25563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1709_fu_71299_p1() {
    mul_ln1118_1709_fu_71299_p1 = tmp_1709_fu_71285_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1709_fu_71299_p2() {
    mul_ln1118_1709_fu_71299_p2 = (!mul_ln1118_1709_fu_71299_p0.read().is_01() || !mul_ln1118_1709_fu_71299_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1709_fu_71299_p0.read()) * sc_bigint<5>(mul_ln1118_1709_fu_71299_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_170_fu_27835_p0() {
    mul_ln1118_170_fu_27835_p0 =  (sc_lv<3>) (sext_ln1116_170_fu_27827_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_170_fu_27835_p1() {
    mul_ln1118_170_fu_27835_p1 = tmp_170_fu_27817_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_170_fu_27835_p2() {
    mul_ln1118_170_fu_27835_p2 = (!mul_ln1118_170_fu_27835_p0.read().is_01() || !mul_ln1118_170_fu_27835_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_170_fu_27835_p0.read()) * sc_bigint<5>(mul_ln1118_170_fu_27835_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1710_fu_71319_p0() {
    mul_ln1118_1710_fu_71319_p0 =  (sc_lv<3>) (sext_ln1116_110_fu_25595_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1710_fu_71319_p1() {
    mul_ln1118_1710_fu_71319_p1 = tmp_1710_fu_71305_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1710_fu_71319_p2() {
    mul_ln1118_1710_fu_71319_p2 = (!mul_ln1118_1710_fu_71319_p0.read().is_01() || !mul_ln1118_1710_fu_71319_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1710_fu_71319_p0.read()) * sc_bigint<5>(mul_ln1118_1710_fu_71319_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1711_fu_71351_p0() {
    mul_ln1118_1711_fu_71351_p0 =  (sc_lv<3>) (sext_ln1116_111_fu_25639_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1711_fu_71351_p1() {
    mul_ln1118_1711_fu_71351_p1 = tmp_1711_fu_71337_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1711_fu_71351_p2() {
    mul_ln1118_1711_fu_71351_p2 = (!mul_ln1118_1711_fu_71351_p0.read().is_01() || !mul_ln1118_1711_fu_71351_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1711_fu_71351_p0.read()) * sc_bigint<5>(mul_ln1118_1711_fu_71351_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1712_fu_71383_p0() {
    mul_ln1118_1712_fu_71383_p0 =  (sc_lv<3>) (sext_ln1116_112_fu_25683_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1712_fu_71383_p1() {
    mul_ln1118_1712_fu_71383_p1 = tmp_1712_fu_71369_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1712_fu_71383_p2() {
    mul_ln1118_1712_fu_71383_p2 = (!mul_ln1118_1712_fu_71383_p0.read().is_01() || !mul_ln1118_1712_fu_71383_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1712_fu_71383_p0.read()) * sc_bigint<5>(mul_ln1118_1712_fu_71383_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1713_fu_71403_p0() {
    mul_ln1118_1713_fu_71403_p0 =  (sc_lv<3>) (sext_ln1116_113_fu_25715_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1713_fu_71403_p1() {
    mul_ln1118_1713_fu_71403_p1 = tmp_1713_fu_71389_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1713_fu_71403_p2() {
    mul_ln1118_1713_fu_71403_p2 = (!mul_ln1118_1713_fu_71403_p0.read().is_01() || !mul_ln1118_1713_fu_71403_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1713_fu_71403_p0.read()) * sc_bigint<5>(mul_ln1118_1713_fu_71403_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1714_fu_71435_p0() {
    mul_ln1118_1714_fu_71435_p0 =  (sc_lv<3>) (sext_ln1116_114_fu_25759_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1714_fu_71435_p1() {
    mul_ln1118_1714_fu_71435_p1 = tmp_1714_fu_71421_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1714_fu_71435_p2() {
    mul_ln1118_1714_fu_71435_p2 = (!mul_ln1118_1714_fu_71435_p0.read().is_01() || !mul_ln1118_1714_fu_71435_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1714_fu_71435_p0.read()) * sc_bigint<5>(mul_ln1118_1714_fu_71435_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1715_fu_99485_p0() {
    mul_ln1118_1715_fu_99485_p0 =  (sc_lv<3>) (sext_ln1116_115_reg_106359.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1715_fu_99485_p1() {
    mul_ln1118_1715_fu_99485_p1 = tmp_1715_reg_111866.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1715_fu_99485_p2() {
    mul_ln1118_1715_fu_99485_p2 = (!mul_ln1118_1715_fu_99485_p0.read().is_01() || !mul_ln1118_1715_fu_99485_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1715_fu_99485_p0.read()) * sc_bigint<5>(mul_ln1118_1715_fu_99485_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1716_fu_71477_p0() {
    mul_ln1118_1716_fu_71477_p0 =  (sc_lv<3>) (sext_ln1116_116_fu_25825_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1716_fu_71477_p1() {
    mul_ln1118_1716_fu_71477_p1 = tmp_1716_fu_71463_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1716_fu_71477_p2() {
    mul_ln1118_1716_fu_71477_p2 = (!mul_ln1118_1716_fu_71477_p0.read().is_01() || !mul_ln1118_1716_fu_71477_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1716_fu_71477_p0.read()) * sc_bigint<5>(mul_ln1118_1716_fu_71477_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1717_fu_71509_p0() {
    mul_ln1118_1717_fu_71509_p0 =  (sc_lv<3>) (sext_ln1116_117_fu_25869_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1717_fu_71509_p1() {
    mul_ln1118_1717_fu_71509_p1 = tmp_1717_fu_71495_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1717_fu_71509_p2() {
    mul_ln1118_1717_fu_71509_p2 = (!mul_ln1118_1717_fu_71509_p0.read().is_01() || !mul_ln1118_1717_fu_71509_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1717_fu_71509_p0.read()) * sc_bigint<5>(mul_ln1118_1717_fu_71509_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1718_fu_99505_p0() {
    mul_ln1118_1718_fu_99505_p0 =  (sc_lv<3>) (sext_ln1116_118_reg_106377.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1718_fu_99505_p1() {
    mul_ln1118_1718_fu_99505_p1 = tmp_1718_reg_111871.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1718_fu_99505_p2() {
    mul_ln1118_1718_fu_99505_p2 = (!mul_ln1118_1718_fu_99505_p0.read().is_01() || !mul_ln1118_1718_fu_99505_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1718_fu_99505_p0.read()) * sc_bigint<5>(mul_ln1118_1718_fu_99505_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1719_fu_71551_p0() {
    mul_ln1118_1719_fu_71551_p0 =  (sc_lv<3>) (sext_ln1116_119_fu_25935_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1719_fu_71551_p1() {
    mul_ln1118_1719_fu_71551_p1 = tmp_1719_fu_71537_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1719_fu_71551_p2() {
    mul_ln1118_1719_fu_71551_p2 = (!mul_ln1118_1719_fu_71551_p0.read().is_01() || !mul_ln1118_1719_fu_71551_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1719_fu_71551_p0.read()) * sc_bigint<5>(mul_ln1118_1719_fu_71551_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_171_fu_81032_p0() {
    mul_ln1118_171_fu_81032_p0 =  (sc_lv<3>) (sext_ln1116_171_reg_106617.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_171_fu_81032_p1() {
    mul_ln1118_171_fu_81032_p1 = tmp_171_reg_106612.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_171_fu_81032_p2() {
    mul_ln1118_171_fu_81032_p2 = (!mul_ln1118_171_fu_81032_p0.read().is_01() || !mul_ln1118_171_fu_81032_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_171_fu_81032_p0.read()) * sc_bigint<5>(mul_ln1118_171_fu_81032_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1720_fu_71583_p0() {
    mul_ln1118_1720_fu_71583_p0 =  (sc_lv<3>) (sext_ln1116_120_fu_25979_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1720_fu_71583_p1() {
    mul_ln1118_1720_fu_71583_p1 = tmp_1720_fu_71569_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1720_fu_71583_p2() {
    mul_ln1118_1720_fu_71583_p2 = (!mul_ln1118_1720_fu_71583_p0.read().is_01() || !mul_ln1118_1720_fu_71583_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1720_fu_71583_p0.read()) * sc_bigint<5>(mul_ln1118_1720_fu_71583_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1721_fu_99525_p0() {
    mul_ln1118_1721_fu_99525_p0 =  (sc_lv<3>) (sext_ln1116_121_reg_106395.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1721_fu_99525_p1() {
    mul_ln1118_1721_fu_99525_p1 = tmp_1721_reg_111876.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1721_fu_99525_p2() {
    mul_ln1118_1721_fu_99525_p2 = (!mul_ln1118_1721_fu_99525_p0.read().is_01() || !mul_ln1118_1721_fu_99525_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1721_fu_99525_p0.read()) * sc_bigint<5>(mul_ln1118_1721_fu_99525_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1722_fu_71625_p0() {
    mul_ln1118_1722_fu_71625_p0 =  (sc_lv<3>) (sext_ln1116_122_fu_26045_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1722_fu_71625_p1() {
    mul_ln1118_1722_fu_71625_p1 = tmp_1722_fu_71611_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1722_fu_71625_p2() {
    mul_ln1118_1722_fu_71625_p2 = (!mul_ln1118_1722_fu_71625_p0.read().is_01() || !mul_ln1118_1722_fu_71625_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1722_fu_71625_p0.read()) * sc_bigint<5>(mul_ln1118_1722_fu_71625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1723_fu_71657_p0() {
    mul_ln1118_1723_fu_71657_p0 =  (sc_lv<3>) (sext_ln1116_123_fu_26089_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1723_fu_71657_p1() {
    mul_ln1118_1723_fu_71657_p1 = tmp_1723_fu_71643_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1723_fu_71657_p2() {
    mul_ln1118_1723_fu_71657_p2 = (!mul_ln1118_1723_fu_71657_p0.read().is_01() || !mul_ln1118_1723_fu_71657_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1723_fu_71657_p0.read()) * sc_bigint<5>(mul_ln1118_1723_fu_71657_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1724_fu_99545_p0() {
    mul_ln1118_1724_fu_99545_p0 =  (sc_lv<3>) (sext_ln1116_124_reg_106413.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1724_fu_99545_p1() {
    mul_ln1118_1724_fu_99545_p1 = tmp_1724_reg_111881.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1724_fu_99545_p2() {
    mul_ln1118_1724_fu_99545_p2 = (!mul_ln1118_1724_fu_99545_p0.read().is_01() || !mul_ln1118_1724_fu_99545_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1724_fu_99545_p0.read()) * sc_bigint<5>(mul_ln1118_1724_fu_99545_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1725_fu_71699_p0() {
    mul_ln1118_1725_fu_71699_p0 =  (sc_lv<3>) (sext_ln1116_125_fu_26155_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1725_fu_71699_p1() {
    mul_ln1118_1725_fu_71699_p1 = tmp_1725_fu_71685_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1725_fu_71699_p2() {
    mul_ln1118_1725_fu_71699_p2 = (!mul_ln1118_1725_fu_71699_p0.read().is_01() || !mul_ln1118_1725_fu_71699_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1725_fu_71699_p0.read()) * sc_bigint<5>(mul_ln1118_1725_fu_71699_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1726_fu_71731_p0() {
    mul_ln1118_1726_fu_71731_p0 =  (sc_lv<3>) (sext_ln1116_126_fu_26199_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1726_fu_71731_p1() {
    mul_ln1118_1726_fu_71731_p1 = tmp_1726_fu_71717_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1726_fu_71731_p2() {
    mul_ln1118_1726_fu_71731_p2 = (!mul_ln1118_1726_fu_71731_p0.read().is_01() || !mul_ln1118_1726_fu_71731_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1726_fu_71731_p0.read()) * sc_bigint<5>(mul_ln1118_1726_fu_71731_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1727_fu_99565_p0() {
    mul_ln1118_1727_fu_99565_p0 =  (sc_lv<3>) (sext_ln1116_127_reg_106431.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1727_fu_99565_p1() {
    mul_ln1118_1727_fu_99565_p1 = tmp_1727_reg_111886.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1727_fu_99565_p2() {
    mul_ln1118_1727_fu_99565_p2 = (!mul_ln1118_1727_fu_99565_p0.read().is_01() || !mul_ln1118_1727_fu_99565_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1727_fu_99565_p0.read()) * sc_bigint<5>(mul_ln1118_1727_fu_99565_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1728_fu_71773_p0() {
    mul_ln1118_1728_fu_71773_p0 =  (sc_lv<3>) (sext_ln1116_128_fu_26265_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1728_fu_71773_p1() {
    mul_ln1118_1728_fu_71773_p1 = tmp_1728_fu_71759_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1728_fu_71773_p2() {
    mul_ln1118_1728_fu_71773_p2 = (!mul_ln1118_1728_fu_71773_p0.read().is_01() || !mul_ln1118_1728_fu_71773_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1728_fu_71773_p0.read()) * sc_bigint<5>(mul_ln1118_1728_fu_71773_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1729_fu_71805_p0() {
    mul_ln1118_1729_fu_71805_p0 =  (sc_lv<3>) (sext_ln1116_129_fu_26309_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1729_fu_71805_p1() {
    mul_ln1118_1729_fu_71805_p1 = tmp_1729_fu_71791_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1729_fu_71805_p2() {
    mul_ln1118_1729_fu_71805_p2 = (!mul_ln1118_1729_fu_71805_p0.read().is_01() || !mul_ln1118_1729_fu_71805_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1729_fu_71805_p0.read()) * sc_bigint<5>(mul_ln1118_1729_fu_71805_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_172_fu_27901_p0() {
    mul_ln1118_172_fu_27901_p0 =  (sc_lv<3>) (sext_ln1116_172_fu_27893_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_172_fu_27901_p1() {
    mul_ln1118_172_fu_27901_p1 = tmp_172_fu_27883_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_172_fu_27901_p2() {
    mul_ln1118_172_fu_27901_p2 = (!mul_ln1118_172_fu_27901_p0.read().is_01() || !mul_ln1118_172_fu_27901_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_172_fu_27901_p0.read()) * sc_bigint<5>(mul_ln1118_172_fu_27901_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1730_fu_71837_p0() {
    mul_ln1118_1730_fu_71837_p0 =  (sc_lv<3>) (sext_ln1116_130_fu_26353_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1730_fu_71837_p1() {
    mul_ln1118_1730_fu_71837_p1 = tmp_1730_fu_71823_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1730_fu_71837_p2() {
    mul_ln1118_1730_fu_71837_p2 = (!mul_ln1118_1730_fu_71837_p0.read().is_01() || !mul_ln1118_1730_fu_71837_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1730_fu_71837_p0.read()) * sc_bigint<5>(mul_ln1118_1730_fu_71837_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1731_fu_71869_p0() {
    mul_ln1118_1731_fu_71869_p0 =  (sc_lv<3>) (sext_ln1116_131_fu_26397_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1731_fu_71869_p1() {
    mul_ln1118_1731_fu_71869_p1 = tmp_1731_fu_71855_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1731_fu_71869_p2() {
    mul_ln1118_1731_fu_71869_p2 = (!mul_ln1118_1731_fu_71869_p0.read().is_01() || !mul_ln1118_1731_fu_71869_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1731_fu_71869_p0.read()) * sc_bigint<5>(mul_ln1118_1731_fu_71869_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1732_fu_71901_p0() {
    mul_ln1118_1732_fu_71901_p0 =  (sc_lv<3>) (sext_ln1116_132_fu_26441_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1732_fu_71901_p1() {
    mul_ln1118_1732_fu_71901_p1 = tmp_1732_fu_71887_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1732_fu_71901_p2() {
    mul_ln1118_1732_fu_71901_p2 = (!mul_ln1118_1732_fu_71901_p0.read().is_01() || !mul_ln1118_1732_fu_71901_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1732_fu_71901_p0.read()) * sc_bigint<5>(mul_ln1118_1732_fu_71901_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1733_fu_71933_p0() {
    mul_ln1118_1733_fu_71933_p0 =  (sc_lv<3>) (sext_ln1116_133_fu_26485_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1733_fu_71933_p1() {
    mul_ln1118_1733_fu_71933_p1 = tmp_1733_fu_71919_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1733_fu_71933_p2() {
    mul_ln1118_1733_fu_71933_p2 = (!mul_ln1118_1733_fu_71933_p0.read().is_01() || !mul_ln1118_1733_fu_71933_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1733_fu_71933_p0.read()) * sc_bigint<5>(mul_ln1118_1733_fu_71933_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1734_fu_99585_p0() {
    mul_ln1118_1734_fu_99585_p0 =  (sc_lv<3>) (sext_ln1116_134_reg_106449.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1734_fu_99585_p1() {
    mul_ln1118_1734_fu_99585_p1 = tmp_1734_reg_111891.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1734_fu_99585_p2() {
    mul_ln1118_1734_fu_99585_p2 = (!mul_ln1118_1734_fu_99585_p0.read().is_01() || !mul_ln1118_1734_fu_99585_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1734_fu_99585_p0.read()) * sc_bigint<5>(mul_ln1118_1734_fu_99585_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1735_fu_71975_p0() {
    mul_ln1118_1735_fu_71975_p0 =  (sc_lv<3>) (sext_ln1116_135_fu_26551_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1735_fu_71975_p1() {
    mul_ln1118_1735_fu_71975_p1 = tmp_1735_fu_71961_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1735_fu_71975_p2() {
    mul_ln1118_1735_fu_71975_p2 = (!mul_ln1118_1735_fu_71975_p0.read().is_01() || !mul_ln1118_1735_fu_71975_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1735_fu_71975_p0.read()) * sc_bigint<5>(mul_ln1118_1735_fu_71975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1736_fu_72007_p0() {
    mul_ln1118_1736_fu_72007_p0 =  (sc_lv<3>) (sext_ln1116_136_fu_26595_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1736_fu_72007_p1() {
    mul_ln1118_1736_fu_72007_p1 = tmp_1736_fu_71993_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1736_fu_72007_p2() {
    mul_ln1118_1736_fu_72007_p2 = (!mul_ln1118_1736_fu_72007_p0.read().is_01() || !mul_ln1118_1736_fu_72007_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1736_fu_72007_p0.read()) * sc_bigint<5>(mul_ln1118_1736_fu_72007_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1737_fu_99605_p0() {
    mul_ln1118_1737_fu_99605_p0 =  (sc_lv<3>) (sext_ln1116_137_reg_106467.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1737_fu_99605_p1() {
    mul_ln1118_1737_fu_99605_p1 = tmp_1737_reg_111896.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1737_fu_99605_p2() {
    mul_ln1118_1737_fu_99605_p2 = (!mul_ln1118_1737_fu_99605_p0.read().is_01() || !mul_ln1118_1737_fu_99605_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1737_fu_99605_p0.read()) * sc_bigint<5>(mul_ln1118_1737_fu_99605_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1738_fu_72049_p0() {
    mul_ln1118_1738_fu_72049_p0 =  (sc_lv<3>) (sext_ln1116_138_fu_26661_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1738_fu_72049_p1() {
    mul_ln1118_1738_fu_72049_p1 = tmp_1738_fu_72035_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1738_fu_72049_p2() {
    mul_ln1118_1738_fu_72049_p2 = (!mul_ln1118_1738_fu_72049_p0.read().is_01() || !mul_ln1118_1738_fu_72049_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1738_fu_72049_p0.read()) * sc_bigint<5>(mul_ln1118_1738_fu_72049_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1739_fu_72081_p0() {
    mul_ln1118_1739_fu_72081_p0 =  (sc_lv<3>) (sext_ln1116_139_fu_26705_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1739_fu_72081_p1() {
    mul_ln1118_1739_fu_72081_p1 = tmp_1739_fu_72067_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1739_fu_72081_p2() {
    mul_ln1118_1739_fu_72081_p2 = (!mul_ln1118_1739_fu_72081_p0.read().is_01() || !mul_ln1118_1739_fu_72081_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1739_fu_72081_p0.read()) * sc_bigint<5>(mul_ln1118_1739_fu_72081_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_173_fu_27945_p0() {
    mul_ln1118_173_fu_27945_p0 =  (sc_lv<3>) (sext_ln1116_173_fu_27937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_173_fu_27945_p1() {
    mul_ln1118_173_fu_27945_p1 = tmp_173_fu_27927_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_173_fu_27945_p2() {
    mul_ln1118_173_fu_27945_p2 = (!mul_ln1118_173_fu_27945_p0.read().is_01() || !mul_ln1118_173_fu_27945_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_173_fu_27945_p0.read()) * sc_bigint<5>(mul_ln1118_173_fu_27945_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1740_fu_99625_p0() {
    mul_ln1118_1740_fu_99625_p0 =  (sc_lv<3>) (sext_ln1116_140_fu_80807_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1740_fu_99625_p1() {
    mul_ln1118_1740_fu_99625_p1 = tmp_1740_reg_111901.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1740_fu_99625_p2() {
    mul_ln1118_1740_fu_99625_p2 = (!mul_ln1118_1740_fu_99625_p0.read().is_01() || !mul_ln1118_1740_fu_99625_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1740_fu_99625_p0.read()) * sc_bigint<5>(mul_ln1118_1740_fu_99625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1741_fu_99646_p0() {
    mul_ln1118_1741_fu_99646_p0 =  (sc_lv<3>) (sext_ln1116_141_fu_80831_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1741_fu_99646_p1() {
    mul_ln1118_1741_fu_99646_p1 = tmp_1741_reg_111906.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1741_fu_99646_p2() {
    mul_ln1118_1741_fu_99646_p2 = (!mul_ln1118_1741_fu_99646_p0.read().is_01() || !mul_ln1118_1741_fu_99646_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1741_fu_99646_p0.read()) * sc_bigint<5>(mul_ln1118_1741_fu_99646_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1742_fu_99667_p0() {
    mul_ln1118_1742_fu_99667_p0 =  (sc_lv<3>) (sext_ln1116_142_fu_80855_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1742_fu_99667_p1() {
    mul_ln1118_1742_fu_99667_p1 = tmp_1742_reg_111911.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1742_fu_99667_p2() {
    mul_ln1118_1742_fu_99667_p2 = (!mul_ln1118_1742_fu_99667_p0.read().is_01() || !mul_ln1118_1742_fu_99667_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1742_fu_99667_p0.read()) * sc_bigint<5>(mul_ln1118_1742_fu_99667_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1743_fu_99688_p0() {
    mul_ln1118_1743_fu_99688_p0 =  (sc_lv<3>) (sext_ln1116_143_fu_80879_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1743_fu_99688_p1() {
    mul_ln1118_1743_fu_99688_p1 = tmp_1743_reg_111916.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1743_fu_99688_p2() {
    mul_ln1118_1743_fu_99688_p2 = (!mul_ln1118_1743_fu_99688_p0.read().is_01() || !mul_ln1118_1743_fu_99688_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1743_fu_99688_p0.read()) * sc_bigint<5>(mul_ln1118_1743_fu_99688_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1744_fu_72153_p0() {
    mul_ln1118_1744_fu_72153_p0 =  (sc_lv<3>) (sext_ln1116_144_fu_26821_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1744_fu_72153_p1() {
    mul_ln1118_1744_fu_72153_p1 = tmp_1744_fu_72139_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1744_fu_72153_p2() {
    mul_ln1118_1744_fu_72153_p2 = (!mul_ln1118_1744_fu_72153_p0.read().is_01() || !mul_ln1118_1744_fu_72153_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1744_fu_72153_p0.read()) * sc_bigint<5>(mul_ln1118_1744_fu_72153_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1745_fu_72185_p0() {
    mul_ln1118_1745_fu_72185_p0 =  (sc_lv<3>) (sext_ln1116_145_fu_26865_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1745_fu_72185_p1() {
    mul_ln1118_1745_fu_72185_p1 = tmp_1745_fu_72171_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1745_fu_72185_p2() {
    mul_ln1118_1745_fu_72185_p2 = (!mul_ln1118_1745_fu_72185_p0.read().is_01() || !mul_ln1118_1745_fu_72185_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1745_fu_72185_p0.read()) * sc_bigint<5>(mul_ln1118_1745_fu_72185_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1746_fu_99709_p0() {
    mul_ln1118_1746_fu_99709_p0 =  (sc_lv<3>) (sext_ln1116_146_reg_106525.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1746_fu_99709_p1() {
    mul_ln1118_1746_fu_99709_p1 = tmp_1746_reg_111921.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1746_fu_99709_p2() {
    mul_ln1118_1746_fu_99709_p2 = (!mul_ln1118_1746_fu_99709_p0.read().is_01() || !mul_ln1118_1746_fu_99709_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1746_fu_99709_p0.read()) * sc_bigint<5>(mul_ln1118_1746_fu_99709_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1747_fu_72227_p0() {
    mul_ln1118_1747_fu_72227_p0 =  (sc_lv<3>) (sext_ln1116_147_fu_26931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1747_fu_72227_p1() {
    mul_ln1118_1747_fu_72227_p1 = tmp_1747_fu_72213_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1747_fu_72227_p2() {
    mul_ln1118_1747_fu_72227_p2 = (!mul_ln1118_1747_fu_72227_p0.read().is_01() || !mul_ln1118_1747_fu_72227_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1747_fu_72227_p0.read()) * sc_bigint<5>(mul_ln1118_1747_fu_72227_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1748_fu_72259_p0() {
    mul_ln1118_1748_fu_72259_p0 =  (sc_lv<3>) (sext_ln1116_148_fu_26975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1748_fu_72259_p1() {
    mul_ln1118_1748_fu_72259_p1 = tmp_1748_fu_72245_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1748_fu_72259_p2() {
    mul_ln1118_1748_fu_72259_p2 = (!mul_ln1118_1748_fu_72259_p0.read().is_01() || !mul_ln1118_1748_fu_72259_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1748_fu_72259_p0.read()) * sc_bigint<5>(mul_ln1118_1748_fu_72259_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1749_fu_99729_p0() {
    mul_ln1118_1749_fu_99729_p0 =  (sc_lv<3>) (sext_ln1116_149_reg_106543.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1749_fu_99729_p1() {
    mul_ln1118_1749_fu_99729_p1 = tmp_1749_reg_111926.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1749_fu_99729_p2() {
    mul_ln1118_1749_fu_99729_p2 = (!mul_ln1118_1749_fu_99729_p0.read().is_01() || !mul_ln1118_1749_fu_99729_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1749_fu_99729_p0.read()) * sc_bigint<5>(mul_ln1118_1749_fu_99729_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_174_fu_81052_p0() {
    mul_ln1118_174_fu_81052_p0 =  (sc_lv<3>) (sext_ln1116_174_reg_106635.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_174_fu_81052_p1() {
    mul_ln1118_174_fu_81052_p1 = tmp_174_reg_106630.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_174_fu_81052_p2() {
    mul_ln1118_174_fu_81052_p2 = (!mul_ln1118_174_fu_81052_p0.read().is_01() || !mul_ln1118_174_fu_81052_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_174_fu_81052_p0.read()) * sc_bigint<5>(mul_ln1118_174_fu_81052_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1750_fu_72301_p0() {
    mul_ln1118_1750_fu_72301_p0 =  (sc_lv<3>) (sext_ln1116_150_fu_27041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1750_fu_72301_p1() {
    mul_ln1118_1750_fu_72301_p1 = tmp_1750_fu_72287_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1750_fu_72301_p2() {
    mul_ln1118_1750_fu_72301_p2 = (!mul_ln1118_1750_fu_72301_p0.read().is_01() || !mul_ln1118_1750_fu_72301_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1750_fu_72301_p0.read()) * sc_bigint<5>(mul_ln1118_1750_fu_72301_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1751_fu_72333_p0() {
    mul_ln1118_1751_fu_72333_p0 =  (sc_lv<3>) (sext_ln1116_151_fu_27085_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1751_fu_72333_p1() {
    mul_ln1118_1751_fu_72333_p1 = tmp_1751_fu_72319_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1751_fu_72333_p2() {
    mul_ln1118_1751_fu_72333_p2 = (!mul_ln1118_1751_fu_72333_p0.read().is_01() || !mul_ln1118_1751_fu_72333_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1751_fu_72333_p0.read()) * sc_bigint<5>(mul_ln1118_1751_fu_72333_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1752_fu_99749_p0() {
    mul_ln1118_1752_fu_99749_p0 =  (sc_lv<3>) (sext_ln1116_152_fu_80943_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1752_fu_99749_p1() {
    mul_ln1118_1752_fu_99749_p1 = tmp_1752_reg_111931.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1752_fu_99749_p2() {
    mul_ln1118_1752_fu_99749_p2 = (!mul_ln1118_1752_fu_99749_p0.read().is_01() || !mul_ln1118_1752_fu_99749_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1752_fu_99749_p0.read()) * sc_bigint<5>(mul_ln1118_1752_fu_99749_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1753_fu_72375_p0() {
    mul_ln1118_1753_fu_72375_p0 =  (sc_lv<3>) (sext_ln1116_153_fu_27147_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1753_fu_72375_p1() {
    mul_ln1118_1753_fu_72375_p1 = tmp_1753_fu_72361_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1753_fu_72375_p2() {
    mul_ln1118_1753_fu_72375_p2 = (!mul_ln1118_1753_fu_72375_p0.read().is_01() || !mul_ln1118_1753_fu_72375_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1753_fu_72375_p0.read()) * sc_bigint<5>(mul_ln1118_1753_fu_72375_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1754_fu_72407_p0() {
    mul_ln1118_1754_fu_72407_p0 =  (sc_lv<3>) (sext_ln1116_154_fu_27191_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1754_fu_72407_p1() {
    mul_ln1118_1754_fu_72407_p1 = tmp_1754_fu_72393_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1754_fu_72407_p2() {
    mul_ln1118_1754_fu_72407_p2 = (!mul_ln1118_1754_fu_72407_p0.read().is_01() || !mul_ln1118_1754_fu_72407_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1754_fu_72407_p0.read()) * sc_bigint<5>(mul_ln1118_1754_fu_72407_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1755_fu_72439_p0() {
    mul_ln1118_1755_fu_72439_p0 =  (sc_lv<3>) (sext_ln1116_155_fu_27235_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1755_fu_72439_p1() {
    mul_ln1118_1755_fu_72439_p1 = tmp_1755_fu_72425_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1755_fu_72439_p2() {
    mul_ln1118_1755_fu_72439_p2 = (!mul_ln1118_1755_fu_72439_p0.read().is_01() || !mul_ln1118_1755_fu_72439_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1755_fu_72439_p0.read()) * sc_bigint<5>(mul_ln1118_1755_fu_72439_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1756_fu_72471_p0() {
    mul_ln1118_1756_fu_72471_p0 =  (sc_lv<3>) (sext_ln1116_156_fu_27279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1756_fu_72471_p1() {
    mul_ln1118_1756_fu_72471_p1 = tmp_1756_fu_72457_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1756_fu_72471_p2() {
    mul_ln1118_1756_fu_72471_p2 = (!mul_ln1118_1756_fu_72471_p0.read().is_01() || !mul_ln1118_1756_fu_72471_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1756_fu_72471_p0.read()) * sc_bigint<5>(mul_ln1118_1756_fu_72471_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1757_fu_72503_p0() {
    mul_ln1118_1757_fu_72503_p0 =  (sc_lv<3>) (sext_ln1116_157_fu_27323_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1757_fu_72503_p1() {
    mul_ln1118_1757_fu_72503_p1 = tmp_1757_fu_72489_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1757_fu_72503_p2() {
    mul_ln1118_1757_fu_72503_p2 = (!mul_ln1118_1757_fu_72503_p0.read().is_01() || !mul_ln1118_1757_fu_72503_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1757_fu_72503_p0.read()) * sc_bigint<5>(mul_ln1118_1757_fu_72503_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1758_fu_72535_p0() {
    mul_ln1118_1758_fu_72535_p0 =  (sc_lv<3>) (sext_ln1116_158_fu_27367_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1758_fu_72535_p1() {
    mul_ln1118_1758_fu_72535_p1 = tmp_1758_fu_72521_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1758_fu_72535_p2() {
    mul_ln1118_1758_fu_72535_p2 = (!mul_ln1118_1758_fu_72535_p0.read().is_01() || !mul_ln1118_1758_fu_72535_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1758_fu_72535_p0.read()) * sc_bigint<5>(mul_ln1118_1758_fu_72535_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1759_fu_72567_p0() {
    mul_ln1118_1759_fu_72567_p0 =  (sc_lv<3>) (sext_ln1116_159_fu_27411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1759_fu_72567_p1() {
    mul_ln1118_1759_fu_72567_p1 = tmp_1759_fu_72553_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1759_fu_72567_p2() {
    mul_ln1118_1759_fu_72567_p2 = (!mul_ln1118_1759_fu_72567_p0.read().is_01() || !mul_ln1118_1759_fu_72567_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1759_fu_72567_p0.read()) * sc_bigint<5>(mul_ln1118_1759_fu_72567_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_175_fu_28011_p0() {
    mul_ln1118_175_fu_28011_p0 =  (sc_lv<3>) (sext_ln1116_175_fu_28003_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_175_fu_28011_p1() {
    mul_ln1118_175_fu_28011_p1 = tmp_175_fu_27993_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_175_fu_28011_p2() {
    mul_ln1118_175_fu_28011_p2 = (!mul_ln1118_175_fu_28011_p0.read().is_01() || !mul_ln1118_175_fu_28011_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_175_fu_28011_p0.read()) * sc_bigint<5>(mul_ln1118_175_fu_28011_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1760_fu_72587_p0() {
    mul_ln1118_1760_fu_72587_p0 =  (sc_lv<3>) (sext_ln1116_160_fu_27443_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1760_fu_72587_p1() {
    mul_ln1118_1760_fu_72587_p1 = tmp_1760_fu_72573_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1760_fu_72587_p2() {
    mul_ln1118_1760_fu_72587_p2 = (!mul_ln1118_1760_fu_72587_p0.read().is_01() || !mul_ln1118_1760_fu_72587_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1760_fu_72587_p0.read()) * sc_bigint<5>(mul_ln1118_1760_fu_72587_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1761_fu_72619_p0() {
    mul_ln1118_1761_fu_72619_p0 =  (sc_lv<3>) (sext_ln1116_161_fu_27487_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1761_fu_72619_p1() {
    mul_ln1118_1761_fu_72619_p1 = tmp_1761_fu_72605_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1761_fu_72619_p2() {
    mul_ln1118_1761_fu_72619_p2 = (!mul_ln1118_1761_fu_72619_p0.read().is_01() || !mul_ln1118_1761_fu_72619_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1761_fu_72619_p0.read()) * sc_bigint<5>(mul_ln1118_1761_fu_72619_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1762_fu_72651_p0() {
    mul_ln1118_1762_fu_72651_p0 =  (sc_lv<3>) (sext_ln1116_162_fu_27531_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1762_fu_72651_p1() {
    mul_ln1118_1762_fu_72651_p1 = tmp_1762_fu_72637_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1762_fu_72651_p2() {
    mul_ln1118_1762_fu_72651_p2 = (!mul_ln1118_1762_fu_72651_p0.read().is_01() || !mul_ln1118_1762_fu_72651_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1762_fu_72651_p0.read()) * sc_bigint<5>(mul_ln1118_1762_fu_72651_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1763_fu_72671_p0() {
    mul_ln1118_1763_fu_72671_p0 =  (sc_lv<3>) (sext_ln1116_163_fu_27563_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1763_fu_72671_p1() {
    mul_ln1118_1763_fu_72671_p1 = tmp_1763_fu_72657_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1763_fu_72671_p2() {
    mul_ln1118_1763_fu_72671_p2 = (!mul_ln1118_1763_fu_72671_p0.read().is_01() || !mul_ln1118_1763_fu_72671_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1763_fu_72671_p0.read()) * sc_bigint<5>(mul_ln1118_1763_fu_72671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1764_fu_72703_p0() {
    mul_ln1118_1764_fu_72703_p0 =  (sc_lv<3>) (sext_ln1116_164_fu_27607_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1764_fu_72703_p1() {
    mul_ln1118_1764_fu_72703_p1 = tmp_1764_fu_72689_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1764_fu_72703_p2() {
    mul_ln1118_1764_fu_72703_p2 = (!mul_ln1118_1764_fu_72703_p0.read().is_01() || !mul_ln1118_1764_fu_72703_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1764_fu_72703_p0.read()) * sc_bigint<5>(mul_ln1118_1764_fu_72703_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1765_fu_99792_p0() {
    mul_ln1118_1765_fu_99792_p0 =  (sc_lv<3>) (sext_ln1116_165_reg_106581.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1765_fu_99792_p1() {
    mul_ln1118_1765_fu_99792_p1 = tmp_1765_reg_111946.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1765_fu_99792_p2() {
    mul_ln1118_1765_fu_99792_p2 = (!mul_ln1118_1765_fu_99792_p0.read().is_01() || !mul_ln1118_1765_fu_99792_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1765_fu_99792_p0.read()) * sc_bigint<5>(mul_ln1118_1765_fu_99792_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1766_fu_72745_p0() {
    mul_ln1118_1766_fu_72745_p0 =  (sc_lv<3>) (sext_ln1116_166_fu_27673_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1766_fu_72745_p1() {
    mul_ln1118_1766_fu_72745_p1 = tmp_1766_fu_72731_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1766_fu_72745_p2() {
    mul_ln1118_1766_fu_72745_p2 = (!mul_ln1118_1766_fu_72745_p0.read().is_01() || !mul_ln1118_1766_fu_72745_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1766_fu_72745_p0.read()) * sc_bigint<5>(mul_ln1118_1766_fu_72745_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1767_fu_72777_p0() {
    mul_ln1118_1767_fu_72777_p0 =  (sc_lv<3>) (sext_ln1116_167_fu_27717_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1767_fu_72777_p1() {
    mul_ln1118_1767_fu_72777_p1 = tmp_1767_fu_72763_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1767_fu_72777_p2() {
    mul_ln1118_1767_fu_72777_p2 = (!mul_ln1118_1767_fu_72777_p0.read().is_01() || !mul_ln1118_1767_fu_72777_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1767_fu_72777_p0.read()) * sc_bigint<5>(mul_ln1118_1767_fu_72777_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1768_fu_99812_p0() {
    mul_ln1118_1768_fu_99812_p0 =  (sc_lv<3>) (sext_ln1116_168_reg_106599.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1768_fu_99812_p1() {
    mul_ln1118_1768_fu_99812_p1 = tmp_1768_reg_111951.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1768_fu_99812_p2() {
    mul_ln1118_1768_fu_99812_p2 = (!mul_ln1118_1768_fu_99812_p0.read().is_01() || !mul_ln1118_1768_fu_99812_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1768_fu_99812_p0.read()) * sc_bigint<5>(mul_ln1118_1768_fu_99812_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1769_fu_72819_p0() {
    mul_ln1118_1769_fu_72819_p0 =  (sc_lv<3>) (sext_ln1116_169_fu_27783_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1769_fu_72819_p1() {
    mul_ln1118_1769_fu_72819_p1 = tmp_1769_fu_72805_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1769_fu_72819_p2() {
    mul_ln1118_1769_fu_72819_p2 = (!mul_ln1118_1769_fu_72819_p0.read().is_01() || !mul_ln1118_1769_fu_72819_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1769_fu_72819_p0.read()) * sc_bigint<5>(mul_ln1118_1769_fu_72819_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_176_fu_28055_p0() {
    mul_ln1118_176_fu_28055_p0 =  (sc_lv<3>) (sext_ln1116_176_fu_28047_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_176_fu_28055_p1() {
    mul_ln1118_176_fu_28055_p1 = tmp_176_fu_28037_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_176_fu_28055_p2() {
    mul_ln1118_176_fu_28055_p2 = (!mul_ln1118_176_fu_28055_p0.read().is_01() || !mul_ln1118_176_fu_28055_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_176_fu_28055_p0.read()) * sc_bigint<5>(mul_ln1118_176_fu_28055_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1770_fu_72851_p0() {
    mul_ln1118_1770_fu_72851_p0 =  (sc_lv<3>) (sext_ln1116_170_fu_27827_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1770_fu_72851_p1() {
    mul_ln1118_1770_fu_72851_p1 = tmp_1770_fu_72837_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1770_fu_72851_p2() {
    mul_ln1118_1770_fu_72851_p2 = (!mul_ln1118_1770_fu_72851_p0.read().is_01() || !mul_ln1118_1770_fu_72851_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1770_fu_72851_p0.read()) * sc_bigint<5>(mul_ln1118_1770_fu_72851_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1771_fu_99832_p0() {
    mul_ln1118_1771_fu_99832_p0 =  (sc_lv<3>) (sext_ln1116_171_reg_106617.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1771_fu_99832_p1() {
    mul_ln1118_1771_fu_99832_p1 = tmp_1771_reg_111956.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1771_fu_99832_p2() {
    mul_ln1118_1771_fu_99832_p2 = (!mul_ln1118_1771_fu_99832_p0.read().is_01() || !mul_ln1118_1771_fu_99832_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1771_fu_99832_p0.read()) * sc_bigint<5>(mul_ln1118_1771_fu_99832_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1772_fu_72893_p0() {
    mul_ln1118_1772_fu_72893_p0 =  (sc_lv<3>) (sext_ln1116_172_fu_27893_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1772_fu_72893_p1() {
    mul_ln1118_1772_fu_72893_p1 = tmp_1772_fu_72879_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1772_fu_72893_p2() {
    mul_ln1118_1772_fu_72893_p2 = (!mul_ln1118_1772_fu_72893_p0.read().is_01() || !mul_ln1118_1772_fu_72893_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1772_fu_72893_p0.read()) * sc_bigint<5>(mul_ln1118_1772_fu_72893_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1773_fu_72925_p0() {
    mul_ln1118_1773_fu_72925_p0 =  (sc_lv<3>) (sext_ln1116_173_fu_27937_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1773_fu_72925_p1() {
    mul_ln1118_1773_fu_72925_p1 = tmp_1773_fu_72911_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1773_fu_72925_p2() {
    mul_ln1118_1773_fu_72925_p2 = (!mul_ln1118_1773_fu_72925_p0.read().is_01() || !mul_ln1118_1773_fu_72925_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1773_fu_72925_p0.read()) * sc_bigint<5>(mul_ln1118_1773_fu_72925_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1774_fu_99852_p0() {
    mul_ln1118_1774_fu_99852_p0 =  (sc_lv<3>) (sext_ln1116_174_reg_106635.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1774_fu_99852_p1() {
    mul_ln1118_1774_fu_99852_p1 = tmp_1774_reg_111961.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1774_fu_99852_p2() {
    mul_ln1118_1774_fu_99852_p2 = (!mul_ln1118_1774_fu_99852_p0.read().is_01() || !mul_ln1118_1774_fu_99852_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1774_fu_99852_p0.read()) * sc_bigint<5>(mul_ln1118_1774_fu_99852_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1775_fu_72967_p0() {
    mul_ln1118_1775_fu_72967_p0 =  (sc_lv<3>) (sext_ln1116_175_fu_28003_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1775_fu_72967_p1() {
    mul_ln1118_1775_fu_72967_p1 = tmp_1775_fu_72953_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1775_fu_72967_p2() {
    mul_ln1118_1775_fu_72967_p2 = (!mul_ln1118_1775_fu_72967_p0.read().is_01() || !mul_ln1118_1775_fu_72967_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1775_fu_72967_p0.read()) * sc_bigint<5>(mul_ln1118_1775_fu_72967_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1776_fu_72999_p0() {
    mul_ln1118_1776_fu_72999_p0 =  (sc_lv<3>) (sext_ln1116_176_fu_28047_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1776_fu_72999_p1() {
    mul_ln1118_1776_fu_72999_p1 = tmp_1776_fu_72985_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1776_fu_72999_p2() {
    mul_ln1118_1776_fu_72999_p2 = (!mul_ln1118_1776_fu_72999_p0.read().is_01() || !mul_ln1118_1776_fu_72999_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1776_fu_72999_p0.read()) * sc_bigint<5>(mul_ln1118_1776_fu_72999_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1777_fu_99872_p0() {
    mul_ln1118_1777_fu_99872_p0 =  (sc_lv<3>) (sext_ln1116_177_reg_106653.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1777_fu_99872_p1() {
    mul_ln1118_1777_fu_99872_p1 = tmp_1777_reg_111966.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1777_fu_99872_p2() {
    mul_ln1118_1777_fu_99872_p2 = (!mul_ln1118_1777_fu_99872_p0.read().is_01() || !mul_ln1118_1777_fu_99872_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1777_fu_99872_p0.read()) * sc_bigint<5>(mul_ln1118_1777_fu_99872_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1778_fu_73041_p0() {
    mul_ln1118_1778_fu_73041_p0 =  (sc_lv<3>) (sext_ln1116_178_fu_28113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1778_fu_73041_p1() {
    mul_ln1118_1778_fu_73041_p1 = tmp_1778_fu_73027_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1778_fu_73041_p2() {
    mul_ln1118_1778_fu_73041_p2 = (!mul_ln1118_1778_fu_73041_p0.read().is_01() || !mul_ln1118_1778_fu_73041_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1778_fu_73041_p0.read()) * sc_bigint<5>(mul_ln1118_1778_fu_73041_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1779_fu_73073_p0() {
    mul_ln1118_1779_fu_73073_p0 =  (sc_lv<3>) (sext_ln1116_179_fu_28157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1779_fu_73073_p1() {
    mul_ln1118_1779_fu_73073_p1 = tmp_1779_fu_73059_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1779_fu_73073_p2() {
    mul_ln1118_1779_fu_73073_p2 = (!mul_ln1118_1779_fu_73073_p0.read().is_01() || !mul_ln1118_1779_fu_73073_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1779_fu_73073_p0.read()) * sc_bigint<5>(mul_ln1118_1779_fu_73073_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_177_fu_81072_p0() {
    mul_ln1118_177_fu_81072_p0 =  (sc_lv<3>) (sext_ln1116_177_reg_106653.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_177_fu_81072_p1() {
    mul_ln1118_177_fu_81072_p1 = tmp_177_reg_106648.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_177_fu_81072_p2() {
    mul_ln1118_177_fu_81072_p2 = (!mul_ln1118_177_fu_81072_p0.read().is_01() || !mul_ln1118_177_fu_81072_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_177_fu_81072_p0.read()) * sc_bigint<5>(mul_ln1118_177_fu_81072_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1780_fu_73105_p0() {
    mul_ln1118_1780_fu_73105_p0 =  (sc_lv<3>) (sext_ln1116_180_fu_28201_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1780_fu_73105_p1() {
    mul_ln1118_1780_fu_73105_p1 = tmp_1780_fu_73091_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1780_fu_73105_p2() {
    mul_ln1118_1780_fu_73105_p2 = (!mul_ln1118_1780_fu_73105_p0.read().is_01() || !mul_ln1118_1780_fu_73105_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1780_fu_73105_p0.read()) * sc_bigint<5>(mul_ln1118_1780_fu_73105_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1781_fu_73137_p0() {
    mul_ln1118_1781_fu_73137_p0 =  (sc_lv<3>) (sext_ln1116_181_fu_28245_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1781_fu_73137_p1() {
    mul_ln1118_1781_fu_73137_p1 = tmp_1781_fu_73123_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1781_fu_73137_p2() {
    mul_ln1118_1781_fu_73137_p2 = (!mul_ln1118_1781_fu_73137_p0.read().is_01() || !mul_ln1118_1781_fu_73137_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1781_fu_73137_p0.read()) * sc_bigint<5>(mul_ln1118_1781_fu_73137_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1782_fu_73169_p0() {
    mul_ln1118_1782_fu_73169_p0 =  (sc_lv<3>) (sext_ln1116_182_fu_28289_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1782_fu_73169_p1() {
    mul_ln1118_1782_fu_73169_p1 = tmp_1782_fu_73155_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1782_fu_73169_p2() {
    mul_ln1118_1782_fu_73169_p2 = (!mul_ln1118_1782_fu_73169_p0.read().is_01() || !mul_ln1118_1782_fu_73169_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1782_fu_73169_p0.read()) * sc_bigint<5>(mul_ln1118_1782_fu_73169_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1783_fu_73201_p0() {
    mul_ln1118_1783_fu_73201_p0 =  (sc_lv<3>) (sext_ln1116_183_fu_28333_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1783_fu_73201_p1() {
    mul_ln1118_1783_fu_73201_p1 = tmp_1783_fu_73187_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1783_fu_73201_p2() {
    mul_ln1118_1783_fu_73201_p2 = (!mul_ln1118_1783_fu_73201_p0.read().is_01() || !mul_ln1118_1783_fu_73201_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1783_fu_73201_p0.read()) * sc_bigint<5>(mul_ln1118_1783_fu_73201_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1784_fu_73233_p0() {
    mul_ln1118_1784_fu_73233_p0 =  (sc_lv<3>) (sext_ln1116_184_fu_28377_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1784_fu_73233_p1() {
    mul_ln1118_1784_fu_73233_p1 = tmp_1784_fu_73219_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1784_fu_73233_p2() {
    mul_ln1118_1784_fu_73233_p2 = (!mul_ln1118_1784_fu_73233_p0.read().is_01() || !mul_ln1118_1784_fu_73233_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1784_fu_73233_p0.read()) * sc_bigint<5>(mul_ln1118_1784_fu_73233_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1785_fu_73253_p0() {
    mul_ln1118_1785_fu_73253_p0 =  (sc_lv<3>) (sext_ln1116_185_fu_28409_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1785_fu_73253_p1() {
    mul_ln1118_1785_fu_73253_p1 = tmp_1785_fu_73239_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1785_fu_73253_p2() {
    mul_ln1118_1785_fu_73253_p2 = (!mul_ln1118_1785_fu_73253_p0.read().is_01() || !mul_ln1118_1785_fu_73253_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1785_fu_73253_p0.read()) * sc_bigint<5>(mul_ln1118_1785_fu_73253_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1786_fu_73285_p0() {
    mul_ln1118_1786_fu_73285_p0 =  (sc_lv<3>) (sext_ln1116_186_fu_28453_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1786_fu_73285_p1() {
    mul_ln1118_1786_fu_73285_p1 = tmp_1786_fu_73271_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1786_fu_73285_p2() {
    mul_ln1118_1786_fu_73285_p2 = (!mul_ln1118_1786_fu_73285_p0.read().is_01() || !mul_ln1118_1786_fu_73285_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1786_fu_73285_p0.read()) * sc_bigint<5>(mul_ln1118_1786_fu_73285_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1787_fu_73317_p0() {
    mul_ln1118_1787_fu_73317_p0 =  (sc_lv<3>) (sext_ln1116_187_fu_28497_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1787_fu_73317_p1() {
    mul_ln1118_1787_fu_73317_p1 = tmp_1787_fu_73303_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1787_fu_73317_p2() {
    mul_ln1118_1787_fu_73317_p2 = (!mul_ln1118_1787_fu_73317_p0.read().is_01() || !mul_ln1118_1787_fu_73317_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1787_fu_73317_p0.read()) * sc_bigint<5>(mul_ln1118_1787_fu_73317_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1788_fu_73337_p0() {
    mul_ln1118_1788_fu_73337_p0 =  (sc_lv<3>) (sext_ln1116_188_fu_28529_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1788_fu_73337_p1() {
    mul_ln1118_1788_fu_73337_p1 = tmp_1788_fu_73323_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1788_fu_73337_p2() {
    mul_ln1118_1788_fu_73337_p2 = (!mul_ln1118_1788_fu_73337_p0.read().is_01() || !mul_ln1118_1788_fu_73337_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1788_fu_73337_p0.read()) * sc_bigint<5>(mul_ln1118_1788_fu_73337_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1789_fu_73369_p0() {
    mul_ln1118_1789_fu_73369_p0 =  (sc_lv<3>) (sext_ln1116_189_fu_28573_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1789_fu_73369_p1() {
    mul_ln1118_1789_fu_73369_p1 = tmp_1789_fu_73355_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1789_fu_73369_p2() {
    mul_ln1118_1789_fu_73369_p2 = (!mul_ln1118_1789_fu_73369_p0.read().is_01() || !mul_ln1118_1789_fu_73369_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1789_fu_73369_p0.read()) * sc_bigint<5>(mul_ln1118_1789_fu_73369_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_178_fu_28121_p0() {
    mul_ln1118_178_fu_28121_p0 =  (sc_lv<3>) (sext_ln1116_178_fu_28113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_178_fu_28121_p1() {
    mul_ln1118_178_fu_28121_p1 = tmp_178_fu_28103_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_178_fu_28121_p2() {
    mul_ln1118_178_fu_28121_p2 = (!mul_ln1118_178_fu_28121_p0.read().is_01() || !mul_ln1118_178_fu_28121_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_178_fu_28121_p0.read()) * sc_bigint<5>(mul_ln1118_178_fu_28121_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1790_fu_99914_p0() {
    mul_ln1118_1790_fu_99914_p0 =  (sc_lv<3>) (sext_ln1116_190_reg_106681.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1790_fu_99914_p1() {
    mul_ln1118_1790_fu_99914_p1 = tmp_1790_reg_111981.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1790_fu_99914_p2() {
    mul_ln1118_1790_fu_99914_p2 = (!mul_ln1118_1790_fu_99914_p0.read().is_01() || !mul_ln1118_1790_fu_99914_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1790_fu_99914_p0.read()) * sc_bigint<5>(mul_ln1118_1790_fu_99914_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1791_fu_73411_p0() {
    mul_ln1118_1791_fu_73411_p0 =  (sc_lv<3>) (sext_ln1116_191_fu_28639_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1791_fu_73411_p1() {
    mul_ln1118_1791_fu_73411_p1 = tmp_1791_fu_73397_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1791_fu_73411_p2() {
    mul_ln1118_1791_fu_73411_p2 = (!mul_ln1118_1791_fu_73411_p0.read().is_01() || !mul_ln1118_1791_fu_73411_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1791_fu_73411_p0.read()) * sc_bigint<5>(mul_ln1118_1791_fu_73411_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1792_fu_73443_p0() {
    mul_ln1118_1792_fu_73443_p0 =  (sc_lv<3>) (sext_ln1116_192_fu_28683_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1792_fu_73443_p1() {
    mul_ln1118_1792_fu_73443_p1 = tmp_1792_fu_73429_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1792_fu_73443_p2() {
    mul_ln1118_1792_fu_73443_p2 = (!mul_ln1118_1792_fu_73443_p0.read().is_01() || !mul_ln1118_1792_fu_73443_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1792_fu_73443_p0.read()) * sc_bigint<5>(mul_ln1118_1792_fu_73443_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1793_fu_99934_p0() {
    mul_ln1118_1793_fu_99934_p0 =  (sc_lv<3>) (sext_ln1116_193_reg_106699.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1793_fu_99934_p1() {
    mul_ln1118_1793_fu_99934_p1 = tmp_1793_reg_111986.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1793_fu_99934_p2() {
    mul_ln1118_1793_fu_99934_p2 = (!mul_ln1118_1793_fu_99934_p0.read().is_01() || !mul_ln1118_1793_fu_99934_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1793_fu_99934_p0.read()) * sc_bigint<5>(mul_ln1118_1793_fu_99934_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1794_fu_73485_p0() {
    mul_ln1118_1794_fu_73485_p0 =  (sc_lv<3>) (sext_ln1116_194_fu_28749_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1794_fu_73485_p1() {
    mul_ln1118_1794_fu_73485_p1 = tmp_1794_fu_73471_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1794_fu_73485_p2() {
    mul_ln1118_1794_fu_73485_p2 = (!mul_ln1118_1794_fu_73485_p0.read().is_01() || !mul_ln1118_1794_fu_73485_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1794_fu_73485_p0.read()) * sc_bigint<5>(mul_ln1118_1794_fu_73485_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1795_fu_73517_p0() {
    mul_ln1118_1795_fu_73517_p0 =  (sc_lv<3>) (sext_ln1116_195_fu_28793_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1795_fu_73517_p1() {
    mul_ln1118_1795_fu_73517_p1 = tmp_1795_fu_73503_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1795_fu_73517_p2() {
    mul_ln1118_1795_fu_73517_p2 = (!mul_ln1118_1795_fu_73517_p0.read().is_01() || !mul_ln1118_1795_fu_73517_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1795_fu_73517_p0.read()) * sc_bigint<5>(mul_ln1118_1795_fu_73517_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1796_fu_99954_p0() {
    mul_ln1118_1796_fu_99954_p0 =  (sc_lv<3>) (sext_ln1116_196_reg_106717.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1796_fu_99954_p1() {
    mul_ln1118_1796_fu_99954_p1 = tmp_1796_reg_111991.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1796_fu_99954_p2() {
    mul_ln1118_1796_fu_99954_p2 = (!mul_ln1118_1796_fu_99954_p0.read().is_01() || !mul_ln1118_1796_fu_99954_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1796_fu_99954_p0.read()) * sc_bigint<5>(mul_ln1118_1796_fu_99954_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1797_fu_73559_p0() {
    mul_ln1118_1797_fu_73559_p0 =  (sc_lv<3>) (sext_ln1116_197_fu_28859_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1797_fu_73559_p1() {
    mul_ln1118_1797_fu_73559_p1 = tmp_1797_fu_73545_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1797_fu_73559_p2() {
    mul_ln1118_1797_fu_73559_p2 = (!mul_ln1118_1797_fu_73559_p0.read().is_01() || !mul_ln1118_1797_fu_73559_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1797_fu_73559_p0.read()) * sc_bigint<5>(mul_ln1118_1797_fu_73559_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1798_fu_73591_p0() {
    mul_ln1118_1798_fu_73591_p0 =  (sc_lv<3>) (sext_ln1116_198_fu_28903_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1798_fu_73591_p1() {
    mul_ln1118_1798_fu_73591_p1 = tmp_1798_fu_73577_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1798_fu_73591_p2() {
    mul_ln1118_1798_fu_73591_p2 = (!mul_ln1118_1798_fu_73591_p0.read().is_01() || !mul_ln1118_1798_fu_73591_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1798_fu_73591_p0.read()) * sc_bigint<5>(mul_ln1118_1798_fu_73591_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1799_fu_99974_p0() {
    mul_ln1118_1799_fu_99974_p0 =  (sc_lv<3>) (sext_ln1116_199_reg_106735.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1799_fu_99974_p1() {
    mul_ln1118_1799_fu_99974_p1 = tmp_1799_reg_111996.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1799_fu_99974_p2() {
    mul_ln1118_1799_fu_99974_p2 = (!mul_ln1118_1799_fu_99974_p0.read().is_01() || !mul_ln1118_1799_fu_99974_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1799_fu_99974_p0.read()) * sc_bigint<5>(mul_ln1118_1799_fu_99974_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_179_fu_28165_p0() {
    mul_ln1118_179_fu_28165_p0 =  (sc_lv<3>) (sext_ln1116_179_fu_28157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_179_fu_28165_p1() {
    mul_ln1118_179_fu_28165_p1 = tmp_179_fu_28147_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_179_fu_28165_p2() {
    mul_ln1118_179_fu_28165_p2 = (!mul_ln1118_179_fu_28165_p0.read().is_01() || !mul_ln1118_179_fu_28165_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_179_fu_28165_p0.read()) * sc_bigint<5>(mul_ln1118_179_fu_28165_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_17_fu_22165_p0() {
    mul_ln1118_17_fu_22165_p0 =  (sc_lv<3>) (sext_ln1116_17_fu_22157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_17_fu_22165_p1() {
    mul_ln1118_17_fu_22165_p1 = tmp_18_fu_22147_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_17_fu_22165_p2() {
    mul_ln1118_17_fu_22165_p2 = (!mul_ln1118_17_fu_22165_p0.read().is_01() || !mul_ln1118_17_fu_22165_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_17_fu_22165_p0.read()) * sc_bigint<5>(mul_ln1118_17_fu_22165_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1800_fu_73633_p0() {
    mul_ln1118_1800_fu_73633_p0 =  (sc_lv<3>) (sext_ln1116_200_fu_28969_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1800_fu_73633_p1() {
    mul_ln1118_1800_fu_73633_p1 = tmp_1800_fu_73619_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1800_fu_73633_p2() {
    mul_ln1118_1800_fu_73633_p2 = (!mul_ln1118_1800_fu_73633_p0.read().is_01() || !mul_ln1118_1800_fu_73633_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1800_fu_73633_p0.read()) * sc_bigint<5>(mul_ln1118_1800_fu_73633_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1801_fu_73665_p0() {
    mul_ln1118_1801_fu_73665_p0 =  (sc_lv<3>) (sext_ln1116_201_fu_29013_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1801_fu_73665_p1() {
    mul_ln1118_1801_fu_73665_p1 = tmp_1801_fu_73651_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1801_fu_73665_p2() {
    mul_ln1118_1801_fu_73665_p2 = (!mul_ln1118_1801_fu_73665_p0.read().is_01() || !mul_ln1118_1801_fu_73665_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1801_fu_73665_p0.read()) * sc_bigint<5>(mul_ln1118_1801_fu_73665_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1802_fu_99994_p0() {
    mul_ln1118_1802_fu_99994_p0 =  (sc_lv<3>) (sext_ln1116_202_reg_106753.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1802_fu_99994_p1() {
    mul_ln1118_1802_fu_99994_p1 = tmp_1802_reg_112001.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1802_fu_99994_p2() {
    mul_ln1118_1802_fu_99994_p2 = (!mul_ln1118_1802_fu_99994_p0.read().is_01() || !mul_ln1118_1802_fu_99994_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1802_fu_99994_p0.read()) * sc_bigint<5>(mul_ln1118_1802_fu_99994_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1803_fu_73707_p0() {
    mul_ln1118_1803_fu_73707_p0 =  (sc_lv<3>) (sext_ln1116_203_fu_29079_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1803_fu_73707_p1() {
    mul_ln1118_1803_fu_73707_p1 = tmp_1803_fu_73693_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1803_fu_73707_p2() {
    mul_ln1118_1803_fu_73707_p2 = (!mul_ln1118_1803_fu_73707_p0.read().is_01() || !mul_ln1118_1803_fu_73707_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1803_fu_73707_p0.read()) * sc_bigint<5>(mul_ln1118_1803_fu_73707_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1804_fu_73739_p0() {
    mul_ln1118_1804_fu_73739_p0 =  (sc_lv<3>) (sext_ln1116_204_fu_29123_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1804_fu_73739_p1() {
    mul_ln1118_1804_fu_73739_p1 = tmp_1804_fu_73725_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1804_fu_73739_p2() {
    mul_ln1118_1804_fu_73739_p2 = (!mul_ln1118_1804_fu_73739_p0.read().is_01() || !mul_ln1118_1804_fu_73739_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1804_fu_73739_p0.read()) * sc_bigint<5>(mul_ln1118_1804_fu_73739_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1805_fu_73771_p0() {
    mul_ln1118_1805_fu_73771_p0 =  (sc_lv<3>) (sext_ln1116_205_fu_29167_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1805_fu_73771_p1() {
    mul_ln1118_1805_fu_73771_p1 = tmp_1805_fu_73757_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1805_fu_73771_p2() {
    mul_ln1118_1805_fu_73771_p2 = (!mul_ln1118_1805_fu_73771_p0.read().is_01() || !mul_ln1118_1805_fu_73771_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1805_fu_73771_p0.read()) * sc_bigint<5>(mul_ln1118_1805_fu_73771_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1806_fu_73803_p0() {
    mul_ln1118_1806_fu_73803_p0 =  (sc_lv<3>) (sext_ln1116_206_fu_29211_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1806_fu_73803_p1() {
    mul_ln1118_1806_fu_73803_p1 = tmp_1806_fu_73789_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1806_fu_73803_p2() {
    mul_ln1118_1806_fu_73803_p2 = (!mul_ln1118_1806_fu_73803_p0.read().is_01() || !mul_ln1118_1806_fu_73803_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1806_fu_73803_p0.read()) * sc_bigint<5>(mul_ln1118_1806_fu_73803_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1807_fu_73835_p0() {
    mul_ln1118_1807_fu_73835_p0 =  (sc_lv<3>) (sext_ln1116_207_fu_29255_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1807_fu_73835_p1() {
    mul_ln1118_1807_fu_73835_p1 = tmp_1807_fu_73821_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1807_fu_73835_p2() {
    mul_ln1118_1807_fu_73835_p2 = (!mul_ln1118_1807_fu_73835_p0.read().is_01() || !mul_ln1118_1807_fu_73835_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1807_fu_73835_p0.read()) * sc_bigint<5>(mul_ln1118_1807_fu_73835_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1808_fu_73867_p0() {
    mul_ln1118_1808_fu_73867_p0 =  (sc_lv<3>) (sext_ln1116_208_fu_29299_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1808_fu_73867_p1() {
    mul_ln1118_1808_fu_73867_p1 = tmp_1808_fu_73853_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1808_fu_73867_p2() {
    mul_ln1118_1808_fu_73867_p2 = (!mul_ln1118_1808_fu_73867_p0.read().is_01() || !mul_ln1118_1808_fu_73867_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1808_fu_73867_p0.read()) * sc_bigint<5>(mul_ln1118_1808_fu_73867_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1809_fu_74313_p0() {
    mul_ln1118_1809_fu_74313_p0 =  (sc_lv<3>) (sext_ln1116_fu_21855_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1809_fu_74313_p1() {
    mul_ln1118_1809_fu_74313_p1 = tmp_1809_fu_74299_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1809_fu_74313_p2() {
    mul_ln1118_1809_fu_74313_p2 = (!mul_ln1118_1809_fu_74313_p0.read().is_01() || !mul_ln1118_1809_fu_74313_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1809_fu_74313_p0.read()) * sc_bigint<5>(mul_ln1118_1809_fu_74313_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_180_fu_28209_p0() {
    mul_ln1118_180_fu_28209_p0 =  (sc_lv<3>) (sext_ln1116_180_fu_28201_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_180_fu_28209_p1() {
    mul_ln1118_180_fu_28209_p1 = tmp_180_fu_28191_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_180_fu_28209_p2() {
    mul_ln1118_180_fu_28209_p2 = (!mul_ln1118_180_fu_28209_p0.read().is_01() || !mul_ln1118_180_fu_28209_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_180_fu_28209_p0.read()) * sc_bigint<5>(mul_ln1118_180_fu_28209_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1810_fu_74333_p0() {
    mul_ln1118_1810_fu_74333_p0 =  (sc_lv<3>) (sext_ln1116_10_fu_21887_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1810_fu_74333_p1() {
    mul_ln1118_1810_fu_74333_p1 = tmp_1810_fu_74319_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1810_fu_74333_p2() {
    mul_ln1118_1810_fu_74333_p2 = (!mul_ln1118_1810_fu_74333_p0.read().is_01() || !mul_ln1118_1810_fu_74333_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1810_fu_74333_p0.read()) * sc_bigint<5>(mul_ln1118_1810_fu_74333_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1811_fu_74365_p0() {
    mul_ln1118_1811_fu_74365_p0 =  (sc_lv<3>) (sext_ln1116_11_fu_21931_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1811_fu_74365_p1() {
    mul_ln1118_1811_fu_74365_p1 = tmp_1811_fu_74351_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1811_fu_74365_p2() {
    mul_ln1118_1811_fu_74365_p2 = (!mul_ln1118_1811_fu_74365_p0.read().is_01() || !mul_ln1118_1811_fu_74365_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1811_fu_74365_p0.read()) * sc_bigint<5>(mul_ln1118_1811_fu_74365_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1812_fu_74397_p0() {
    mul_ln1118_1812_fu_74397_p0 =  (sc_lv<3>) (sext_ln1116_12_fu_21975_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1812_fu_74397_p1() {
    mul_ln1118_1812_fu_74397_p1 = tmp_1812_fu_74383_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1812_fu_74397_p2() {
    mul_ln1118_1812_fu_74397_p2 = (!mul_ln1118_1812_fu_74397_p0.read().is_01() || !mul_ln1118_1812_fu_74397_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1812_fu_74397_p0.read()) * sc_bigint<5>(mul_ln1118_1812_fu_74397_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1813_fu_74417_p0() {
    mul_ln1118_1813_fu_74417_p0 =  (sc_lv<3>) (sext_ln1116_13_fu_22007_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1813_fu_74417_p1() {
    mul_ln1118_1813_fu_74417_p1 = tmp_1813_fu_74403_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1813_fu_74417_p2() {
    mul_ln1118_1813_fu_74417_p2 = (!mul_ln1118_1813_fu_74417_p0.read().is_01() || !mul_ln1118_1813_fu_74417_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1813_fu_74417_p0.read()) * sc_bigint<5>(mul_ln1118_1813_fu_74417_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1814_fu_74449_p0() {
    mul_ln1118_1814_fu_74449_p0 =  (sc_lv<3>) (sext_ln1116_14_fu_22051_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1814_fu_74449_p1() {
    mul_ln1118_1814_fu_74449_p1 = tmp_1814_fu_74435_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1814_fu_74449_p2() {
    mul_ln1118_1814_fu_74449_p2 = (!mul_ln1118_1814_fu_74449_p0.read().is_01() || !mul_ln1118_1814_fu_74449_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1814_fu_74449_p0.read()) * sc_bigint<5>(mul_ln1118_1814_fu_74449_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1815_fu_101237_p0() {
    mul_ln1118_1815_fu_101237_p0 =  (sc_lv<3>) (sext_ln1116_15_fu_80033_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1815_fu_101237_p1() {
    mul_ln1118_1815_fu_101237_p1 = tmp_1815_reg_112361.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1815_fu_101237_p2() {
    mul_ln1118_1815_fu_101237_p2 = (!mul_ln1118_1815_fu_101237_p0.read().is_01() || !mul_ln1118_1815_fu_101237_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1815_fu_101237_p0.read()) * sc_bigint<5>(mul_ln1118_1815_fu_101237_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1816_fu_74491_p0() {
    mul_ln1118_1816_fu_74491_p0 =  (sc_lv<3>) (sext_ln1116_16_fu_22113_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1816_fu_74491_p1() {
    mul_ln1118_1816_fu_74491_p1 = tmp_1816_fu_74477_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1816_fu_74491_p2() {
    mul_ln1118_1816_fu_74491_p2 = (!mul_ln1118_1816_fu_74491_p0.read().is_01() || !mul_ln1118_1816_fu_74491_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1816_fu_74491_p0.read()) * sc_bigint<5>(mul_ln1118_1816_fu_74491_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1817_fu_74523_p0() {
    mul_ln1118_1817_fu_74523_p0 =  (sc_lv<3>) (sext_ln1116_17_fu_22157_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1817_fu_74523_p1() {
    mul_ln1118_1817_fu_74523_p1 = tmp_1817_fu_74509_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1817_fu_74523_p2() {
    mul_ln1118_1817_fu_74523_p2 = (!mul_ln1118_1817_fu_74523_p0.read().is_01() || !mul_ln1118_1817_fu_74523_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1817_fu_74523_p0.read()) * sc_bigint<5>(mul_ln1118_1817_fu_74523_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1818_fu_101258_p0() {
    mul_ln1118_1818_fu_101258_p0 =  (sc_lv<3>) (sext_ln1116_18_fu_80057_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1818_fu_101258_p1() {
    mul_ln1118_1818_fu_101258_p1 = tmp_1818_reg_112366.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1818_fu_101258_p2() {
    mul_ln1118_1818_fu_101258_p2 = (!mul_ln1118_1818_fu_101258_p0.read().is_01() || !mul_ln1118_1818_fu_101258_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1818_fu_101258_p0.read()) * sc_bigint<5>(mul_ln1118_1818_fu_101258_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1819_fu_74565_p0() {
    mul_ln1118_1819_fu_74565_p0 =  (sc_lv<3>) (sext_ln1116_19_fu_22219_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1819_fu_74565_p1() {
    mul_ln1118_1819_fu_74565_p1 = tmp_1819_fu_74551_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1819_fu_74565_p2() {
    mul_ln1118_1819_fu_74565_p2 = (!mul_ln1118_1819_fu_74565_p0.read().is_01() || !mul_ln1118_1819_fu_74565_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1819_fu_74565_p0.read()) * sc_bigint<5>(mul_ln1118_1819_fu_74565_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_181_fu_28253_p0() {
    mul_ln1118_181_fu_28253_p0 =  (sc_lv<3>) (sext_ln1116_181_fu_28245_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_181_fu_28253_p1() {
    mul_ln1118_181_fu_28253_p1 = tmp_181_fu_28235_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_181_fu_28253_p2() {
    mul_ln1118_181_fu_28253_p2 = (!mul_ln1118_181_fu_28253_p0.read().is_01() || !mul_ln1118_181_fu_28253_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_181_fu_28253_p0.read()) * sc_bigint<5>(mul_ln1118_181_fu_28253_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1820_fu_74597_p0() {
    mul_ln1118_1820_fu_74597_p0 =  (sc_lv<3>) (sext_ln1116_20_fu_22263_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1820_fu_74597_p1() {
    mul_ln1118_1820_fu_74597_p1 = tmp_1820_fu_74583_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1820_fu_74597_p2() {
    mul_ln1118_1820_fu_74597_p2 = (!mul_ln1118_1820_fu_74597_p0.read().is_01() || !mul_ln1118_1820_fu_74597_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1820_fu_74597_p0.read()) * sc_bigint<5>(mul_ln1118_1820_fu_74597_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1821_fu_101279_p0() {
    mul_ln1118_1821_fu_101279_p0 =  (sc_lv<3>) (sext_ln1116_21_fu_80081_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1821_fu_101279_p1() {
    mul_ln1118_1821_fu_101279_p1 = tmp_1821_reg_112371.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1821_fu_101279_p2() {
    mul_ln1118_1821_fu_101279_p2 = (!mul_ln1118_1821_fu_101279_p0.read().is_01() || !mul_ln1118_1821_fu_101279_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1821_fu_101279_p0.read()) * sc_bigint<5>(mul_ln1118_1821_fu_101279_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1822_fu_74639_p0() {
    mul_ln1118_1822_fu_74639_p0 =  (sc_lv<3>) (sext_ln1116_22_fu_22325_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1822_fu_74639_p1() {
    mul_ln1118_1822_fu_74639_p1 = tmp_1822_fu_74625_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1822_fu_74639_p2() {
    mul_ln1118_1822_fu_74639_p2 = (!mul_ln1118_1822_fu_74639_p0.read().is_01() || !mul_ln1118_1822_fu_74639_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1822_fu_74639_p0.read()) * sc_bigint<5>(mul_ln1118_1822_fu_74639_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1823_fu_74671_p0() {
    mul_ln1118_1823_fu_74671_p0 =  (sc_lv<3>) (sext_ln1116_23_fu_22369_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1823_fu_74671_p1() {
    mul_ln1118_1823_fu_74671_p1 = tmp_1823_fu_74657_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1823_fu_74671_p2() {
    mul_ln1118_1823_fu_74671_p2 = (!mul_ln1118_1823_fu_74671_p0.read().is_01() || !mul_ln1118_1823_fu_74671_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1823_fu_74671_p0.read()) * sc_bigint<5>(mul_ln1118_1823_fu_74671_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1824_fu_101300_p0() {
    mul_ln1118_1824_fu_101300_p0 =  (sc_lv<3>) (sext_ln1116_24_fu_80105_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1824_fu_101300_p1() {
    mul_ln1118_1824_fu_101300_p1 = tmp_1824_reg_112376.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1824_fu_101300_p2() {
    mul_ln1118_1824_fu_101300_p2 = (!mul_ln1118_1824_fu_101300_p0.read().is_01() || !mul_ln1118_1824_fu_101300_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1824_fu_101300_p0.read()) * sc_bigint<5>(mul_ln1118_1824_fu_101300_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1825_fu_74713_p0() {
    mul_ln1118_1825_fu_74713_p0 =  (sc_lv<3>) (sext_ln1116_25_fu_22431_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1825_fu_74713_p1() {
    mul_ln1118_1825_fu_74713_p1 = tmp_1825_fu_74699_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1825_fu_74713_p2() {
    mul_ln1118_1825_fu_74713_p2 = (!mul_ln1118_1825_fu_74713_p0.read().is_01() || !mul_ln1118_1825_fu_74713_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1825_fu_74713_p0.read()) * sc_bigint<5>(mul_ln1118_1825_fu_74713_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1826_fu_74745_p0() {
    mul_ln1118_1826_fu_74745_p0 =  (sc_lv<3>) (sext_ln1116_26_fu_22475_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1826_fu_74745_p1() {
    mul_ln1118_1826_fu_74745_p1 = tmp_1826_fu_74731_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1826_fu_74745_p2() {
    mul_ln1118_1826_fu_74745_p2 = (!mul_ln1118_1826_fu_74745_p0.read().is_01() || !mul_ln1118_1826_fu_74745_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1826_fu_74745_p0.read()) * sc_bigint<5>(mul_ln1118_1826_fu_74745_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1827_fu_101321_p0() {
    mul_ln1118_1827_fu_101321_p0 =  (sc_lv<3>) (sext_ln1116_27_fu_80129_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1827_fu_101321_p1() {
    mul_ln1118_1827_fu_101321_p1 = tmp_1827_reg_112381.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1827_fu_101321_p2() {
    mul_ln1118_1827_fu_101321_p2 = (!mul_ln1118_1827_fu_101321_p0.read().is_01() || !mul_ln1118_1827_fu_101321_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1827_fu_101321_p0.read()) * sc_bigint<5>(mul_ln1118_1827_fu_101321_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1828_fu_74787_p0() {
    mul_ln1118_1828_fu_74787_p0 =  (sc_lv<3>) (sext_ln1116_28_fu_22537_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1828_fu_74787_p1() {
    mul_ln1118_1828_fu_74787_p1 = tmp_1828_fu_74773_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1828_fu_74787_p2() {
    mul_ln1118_1828_fu_74787_p2 = (!mul_ln1118_1828_fu_74787_p0.read().is_01() || !mul_ln1118_1828_fu_74787_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1828_fu_74787_p0.read()) * sc_bigint<5>(mul_ln1118_1828_fu_74787_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1829_fu_74819_p0() {
    mul_ln1118_1829_fu_74819_p0 =  (sc_lv<3>) (sext_ln1116_29_fu_22581_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1829_fu_74819_p1() {
    mul_ln1118_1829_fu_74819_p1 = tmp_1829_fu_74805_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1829_fu_74819_p2() {
    mul_ln1118_1829_fu_74819_p2 = (!mul_ln1118_1829_fu_74819_p0.read().is_01() || !mul_ln1118_1829_fu_74819_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1829_fu_74819_p0.read()) * sc_bigint<5>(mul_ln1118_1829_fu_74819_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_182_fu_28297_p0() {
    mul_ln1118_182_fu_28297_p0 =  (sc_lv<3>) (sext_ln1116_182_fu_28289_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_182_fu_28297_p1() {
    mul_ln1118_182_fu_28297_p1 = tmp_182_fu_28279_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_182_fu_28297_p2() {
    mul_ln1118_182_fu_28297_p2 = (!mul_ln1118_182_fu_28297_p0.read().is_01() || !mul_ln1118_182_fu_28297_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_182_fu_28297_p0.read()) * sc_bigint<5>(mul_ln1118_182_fu_28297_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1830_fu_74851_p0() {
    mul_ln1118_1830_fu_74851_p0 =  (sc_lv<3>) (sext_ln1116_30_fu_22625_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1830_fu_74851_p1() {
    mul_ln1118_1830_fu_74851_p1 = tmp_1830_fu_74837_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1830_fu_74851_p2() {
    mul_ln1118_1830_fu_74851_p2 = (!mul_ln1118_1830_fu_74851_p0.read().is_01() || !mul_ln1118_1830_fu_74851_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1830_fu_74851_p0.read()) * sc_bigint<5>(mul_ln1118_1830_fu_74851_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1831_fu_74871_p0() {
    mul_ln1118_1831_fu_74871_p0 =  (sc_lv<3>) (sext_ln1116_31_fu_22669_p1.read());
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1831_fu_74871_p1() {
    mul_ln1118_1831_fu_74871_p1 = tmp_1831_fu_74857_p4.read();
}

void dense_wrapper_ap_fixed_ap_fixed_12_6_5_3_0_config11_s::thread_mul_ln1118_1831_fu_74871_p2() {
    mul_ln1118_1831_fu_74871_p2 = (!mul_ln1118_1831_fu_74871_p0.read().is_01() || !mul_ln1118_1831_fu_74871_p1.read().is_01())? sc_lv<8>(): sc_bigint<3>(mul_ln1118_1831_fu_74871_p0.read()) * sc_bigint<5>(mul_ln1118_1831_fu_74871_p1.read());
}

}

